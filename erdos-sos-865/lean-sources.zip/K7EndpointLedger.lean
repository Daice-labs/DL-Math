import K7HistoricalRows
import K7O2Dispatch
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

theorem eventually_exceeds_O2_bound (β:ℝ) (hb:0<β) : ∃n₀:ℕ,∀n:ℕ,n₀≤n →
    (3/2:ℝ)*(Real.log ((n/4:ℕ):ℝ)/Real.log 2)+1<β*n := by
  obtain ⟨U,hU⟩:=uniform_window_threshold β hb
  refine ⟨U,?_⟩
  intro n hn
  obtain ⟨ha,hb'⟩:=hU n hn
  let H:=n/4
  let L:=logLevels H
  have hp:H<4^L:=Nat.lt_pow_succ_log_self (by decide) _
  have hpow:(H:ℝ)≤(4:ℝ)^L:=by exact_mod_cast hp.le
  have lH:=Real.log_le_log (show 0<(H:ℝ) by exact_mod_cast (show 0<H by dsimp [H];omega)) hpow
  rw [Real.log_pow,show (4:ℝ)=2*2 by norm_num,Real.log_mul (by norm_num) (by norm_num)] at lH
  have htwo:0<Real.log 2:=Real.log_pos (by norm_num)
  have bound:Real.log (H:ℝ)/Real.log 2 ≤ 2*(L:ℝ):=by
    apply (div_le_iff₀ htwo).mpr;nlinarith only [lH]
  change 10*(L:ℝ)+1000≤β*n at hb'
  change (3/2:ℝ)*(Real.log (H:ℝ)/Real.log 2)+1<β*n
  have l0:0≤(L:ℝ):=by positivity
  linarith only [bound,hb',l0]

theorem o2_goal_iff_row9 : ActualO2Goal ↔ RowExclusion 9 := by
  constructor
  · intro hO β hb
    obtain ⟨U,hU⟩:=hO β hb
    obtain ⟨V,hV⟩:=eventually_exceeds_O2_bound β hb
    refine ⟨max U V,?_⟩
    intro n hn B hsub hf hd hg S hs hr
    have h:=hU n (by omega) B hsub hf hd hg (row9_implies_seed hs hr)
    have g:=hV n (by omega)
    have hq:0≤(totalBudget n B:ℝ):=by positivity
    linarith only [h,g,hq]
  · intro hr β hb
    obtain ⟨U,hU⟩:=hr β hb
    refine ⟨U,?_⟩;intro n hn B hsub hf hd hg hseed
    obtain ⟨S,hs,hi⟩:=seed_implies_row9 hseed
    exact (hU n hn B hsub hf hd hg S hs hi).elim

def otherUnprovedRows:Finset ℕ:=outstandingRows.erase 9

theorem normalized_from_O2_and_other_rows (hD:Dousse7) (o2:ActualO2Goal)
    (h:∀i∈otherUnprovedRows,RowExclusion i) : NormalizedK7Goal := by
  apply normalized_of_outstanding_rows hD
  intro i hi
  by_cases eq:i=9
  · exact eq ▸ o2_goal_iff_row9.mp o2
  · exact h i (mem_erase.mpr ⟨eq,hi⟩)

theorem limit_from_O2_and_other_rows (hD:Dousse7) (o2:ActualO2Goal)
    (h:∀i∈otherUnprovedRows,RowExclusion i) : SharpK7Limit :=
  limit_of_normalized hD (normalized_from_O2_and_other_rows hD o2 h)

end OP02.SharpK7

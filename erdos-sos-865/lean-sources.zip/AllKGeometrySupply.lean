import AllKGeometryWindow

open Finset OP02.SharpK8
namespace OP02.AllOrders

def lossDen (k : ℕ) : ℕ := 3*4^(k-1)

/-- The real deficit hypothesis in integral units. -/
theorem budget_integer {k T K : ℕ} (h : (K:ℝ)<((2/3:ℝ)-coeff k)*T) :
    lossDen k*K<2*T := by
  have hden : (0:ℝ)<3*(4:ℝ)^(k-1) := by positivity
  have eq : (2/3:ℝ)-coeff k=2/(3*4^(k-1)) := by
    unfold coeff
    rw [one_div_pow]
    field_simp
    <;> ring
  rw [eq,div_mul_eq_mul_div] at h
  have h' := (lt_div_iff₀ hden).mp h
  unfold lossDen
  exact_mod_cast (show (3*(4:ℝ)^(k-1))*(K:ℝ)<2*(T:ℝ) by linarith)

private theorem tail_surplus (k : ℕ) (hk : 11≤k) :
    2*(k*(k-1))*8192 < lossDen k := by
  induction k, hk using Nat.le_induction with
  | base => decide
  | succ k hk ih =>
    have ex : k=(k-1)+1 := by omega
    have recur : lossDen (k+1)=4*lossDen k := by
      unfold lossDen
      rw [Nat.add_sub_cancel, show (4:ℕ)^k=4^(k-1)*4 by conv_lhs => rw [ex,pow_succ]]
      omega
    have frac : (k+1)*k ≤ 4*(k*(k-1)) := by
      calc (k+1)*k ≤ (4*(k-1))*k := Nat.mul_le_mul_right _ (by omega)
           _ = _ := by ring
    rw [recur]
    simp only [Nat.add_sub_cancel]
    calc 2*((k+1)*k)*8192 ≤ 2*(4*(k*(k-1)))*8192 := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ frac)
         _ = 4*(2*(k*(k-1))*8192) := by ring
         _ < _ := Nat.mul_lt_mul_of_pos_left ih (by decide)

private theorem rate_surplus {k t d : ℕ} (hk : 8≤k) (td : t≤k)
    (ds : d=8 ∨ d=32) (ds32 : d=32 → t+2≤k) :
    2*(k+(k-2)*t)*(4*widthDen k*d)<lossDen k := by
  by_cases tail : 11≤k
  · have h := tail_surplus k tail
    have w : widthDen k=64 := by unfold widthDen; split_ifs <;> omega
    have c : k+(k-2)*t≤k*(k-1) := by
      have n := Nat.mul_le_mul_left (k-2) td
      have e : k*(k-1)=k+(k-2)*k := by
        rw [show k-1=(k-2)+1 by omega,Nat.mul_add]; ring
      omega
    have wle : 4*widthDen k*d≤8192 := by rw [w]; omega
    exact lt_of_le_of_lt (Nat.mul_le_mul (Nat.mul_le_mul_left 2 c) wle) h
  · have cases : k=8 ∨ k=9 ∨ k=10 := by omega
    rcases cases with rfl|rfl|rfl <;> rcases ds with rfl|rfl <;>
      norm_num [widthDen,lossDen] at * <;> omega

private theorem room_from_rate {D K T b q : ℕ} (h : D*K<2*T)
    (rate : 2*b*q<D) (big : 10000*D≤T) : b*K*q+10000≤T := by
  have a := Nat.mul_le_mul_right (b*q) h.le
  have c := Nat.mul_le_mul_right T (Nat.succ_le_of_lt rate)
  have temp : D*(b*K*q+10000)≤D*T := by
    nlinarith only [a,c,big]
  exact Nat.le_of_mul_le_mul_left temp (by omega)

/-- Strict room for both selections, with a threshold independent of the role choices. -/
theorem window_supply {k T K t d : ℕ} (hk : 8≤k) (ht : t≤k)
    (ds : d=8 ∨ d=32) (t32 : d=32 → t+2≤k)
    (big : 10000*lossDen k≤T) (budget : (K:ℝ)<((2/3:ℝ)-coeff k)*T) :
    (k+(k-2)*t)*K<((T/4/widthDen k-4)/d) ∧ k*K<(9*T/16-T/2)/8 := by
  have rate := rate_surplus hk ht ds t32
  have room := room_from_rate (budget_integer budget) rate big
  have dw : widthDen k=4 ∨ widthDen k=8 ∨ widthDen k=32 ∨ widthDen k=64 := by
    unfold widthDen; split_ifs <;> simp_all
  have second : 2*k*128<lossDen k := by
    have dle : 128≤4*widthDen k*d := by
      rcases dw with h|h|h|h <;> rw [h] <;> omega
    exact lt_of_le_of_lt (Nat.mul_le_mul (Nat.mul_le_mul_left 2 (Nat.le_add_right _ _)) dle) rate
  have sroom := room_from_rate (budget_integer budget) second big
  refine ⟨?_,by omega⟩
  rcases dw with h|h|h|h <;> rw [h] at room ⊢ <;> rcases ds with rfl|rfl <;> omega

end OP02.AllOrders

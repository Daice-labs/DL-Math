import K5Profile
open Finset
namespace OP02.SharpK6
open OP02.SharpK5
set_option maxHeartbeats 8000000

theorem triangle_missing_residue_pivot : ∀a b c:Fin 4,
 (∃j:Fin 4,j.val≠0 ∧ a≠j ∧ b≠j ∧ c≠j) →
 ∃p:Fin 4,p.val%4≠2 ∧ (p.val+a.val)%4≠2 ∧
 (p.val+b.val)%4≠2 ∧ (p.val+c.val)%4≠2 ∧
 ((if p.val%2=0 then 1 else 0)+(if (p.val+a.val)%2=0 then 1 else 0)+
 (if (p.val+b.val)%2=0 then 1 else 0)+(if (p.val+c.val)%2=0 then 1 else 0))≤3 := by decide

theorem triangle_profile_pivot (S:Finset ℕ) (hc:S.card=3) (hz:0∉S)
    (hm:∃j<4,∀s∈insert 0 S,s%4≠j) :
    ∃b<4,(∀s∈insert 0 S,(b+s)%4≠2) ∧
      ((insert 0 S).filter (fun s=>(b+s)%2=0)).card≤3 := by
  classical
  obtain ⟨a,b,c,hab,hac,hbc,hS⟩ := card_eq_three.mp hc
  obtain ⟨j,hj,hmiss⟩ := hm
  have hj0:j≠0 := by have := hmiss 0 (by simp); omega
  have ha:a∈S := by simp [hS]
  have hb:b∈S := by simp [hS]
  have hc:c∈S := by simp [hS]
  have hma:=hmiss a (mem_insert_of_mem ha)
  have hmb:=hmiss b (mem_insert_of_mem hb)
  have hmc:=hmiss c (mem_insert_of_mem hc)
  obtain ⟨p,hp0,hpa,hpb,hpc,hcount⟩ := triangle_missing_residue_pivot
    ⟨a%4,by omega⟩ ⟨b%4,by omega⟩ ⟨c%4,by omega⟩
    ⟨⟨j,hj⟩,hj0,by intro he; have := congrArg Fin.val he; exact hma this,
      by intro he; have := congrArg Fin.val he; exact hmb this,
      by intro he; have := congrArg Fin.val he; exact hmc this⟩
  dsimp only at hpa hpb hpc hcount
  refine ⟨p.val,p.isLt,?_,?_⟩
  · intro s hs
    simp only [hS,mem_insert,mem_singleton] at hs
    rcases hs with rfl|rfl|rfl|rfl <;> omega
  · have ha0:0≠a := by intro he; exact hz (he ▸ ha)
    have hb0:0≠b := by intro he; exact hz (he ▸ hb)
    have hc0:0≠c := by intro he; exact hz (he ▸ hc)
    have he : ((insert 0 S).filter (fun s=>(p.val+s)%2=0)).card=
        (if p.val%2=0 then 1 else 0)+(if (p.val+a)%2=0 then 1 else 0)+
        (if (p.val+b)%2=0 then 1 else 0)+(if (p.val+c)%2=0 then 1 else 0) := by
      rw [card_eq_sum_ones,sum_filter]
      simp only [hS,sum_insert,mem_insert,mem_singleton,ha0,hb0,hc0,hab,hac,hbc,
        false_or,not_false_eq_true,sum_singleton,Nat.add_zero,Nat.add_assoc]
    rw [he]
    have hma:(p.val+a)%2=(p.val+a%4)%2 := by omega
    have hmb:(p.val+b)%2=(p.val+b%4)%2 := by omega
    have hmc:(p.val+c)%2=(p.val+c%4)%2 := by omega
    simpa only [hma,hmb,hmc] using hcount


#print axioms triangle_profile_pivot
end OP02.SharpK6

import K8RothSpec

open Finset
namespace OP02.Midpoint

/-- Three positive differences chosen successively, with all 27 sums in the original set. -/
def TernaryBox (A : Finset ℕ) (x a b c : ℕ) : Prop :=
  ∀ i j k : ℕ, i≤2 → j≤2 → k≤2 → x+k*c+j*b+i*a ∈ A

theorem step_three {A : Finset ℕ} {d x : ℕ} (h : x∈tripleStarts A d)
    (i : ℕ) (hi : i≤2) : x+i*d∈A := by
  obtain ⟨h0,h1,h2⟩ := mem_tripleStarts h
  rcases (show i=0 ∨ i=1 ∨ i=2 by omega) with rfl|rfl|rfl
  · simpa using h0
  · simpa using h1
  · exact h2

theorem box_of_starts {A : Finset ℕ} {x a b c : ℕ}
    (h : x∈tripleStarts (tripleStarts (tripleStarts A a) b) c) : TernaryBox A x a b c := by
  intro i j k hi hj hk
  exact step_three (step_three (step_three h k hk) j hj) i hi

abbrev Bits3 := Fin 2 × Fin 2 × Fin 2

def corner (x a b c : ℕ) (t : Bits3) : ℕ :=
  x+(2*t.2.2.val)*c+(2*t.2.1.val)*b+(2*t.1.val)*a

set_option maxHeartbeats 1500000 in
theorem corners_injective {x a b c : ℕ} (ha : 0<a) (hb : a<b) (hc : a+b<c) :
    Function.Injective (corner x a b c) := by
  rintro ⟨i,j,k⟩ ⟨l,m,r⟩ he
  fin_cases i <;> fin_cases j <;> fin_cases k <;> fin_cases l <;> fin_cases m <;> fin_cases r <;>
    norm_num [corner] at he ⊢ <;> omega

theorem eight_of_box {A : Finset ℕ} {x a b c : ℕ}
    (ha : 0<a) (hb : a<b) (hc : a+b<c) (box : TernaryBox A x a b c) :
    ∃ S⊆A, S.card=8 ∧ ∀ y∈S, ∀ z∈S, y≠z → ∃ w∈A, y+z=2*w := by
  classical
  let S := (univ : Finset Bits3).image (corner x a b c)
  refine ⟨S,?_,?_,?_⟩
  · intro y hy
    obtain ⟨i,_,rfl⟩ := mem_image.mp hy
    exact box (2*i.1.val) (2*i.2.1.val) (2*i.2.2.val) (by omega) (by omega) (by omega)
  · change ((univ : Finset Bits3).image (corner x a b c)).card=8
    rw [card_image_of_injective _ (corners_injective ha hb hc)]
    decide
  · intro y hy z hz _
    obtain ⟨i,_,rfl⟩ := mem_image.mp hy
    obtain ⟨j,_,rfl⟩ := mem_image.mp hz
    refine ⟨_,box (i.1.val+j.1.val) (i.2.1.val+j.2.1.val) (i.2.2.val+j.2.2.val)
      (by omega) (by omega) (by omega),?_⟩
    unfold corner
    ring

theorem box_uniform (hp : PopularBound) (k : ℕ) (hk : 0<k) :
    ∃ N₀ : ℕ, 1≤N₀ ∧ ∀ N : ℕ, N₀≤N → ∀ A : Finset ℕ, A⊆Icc 1 N → N≤k*A.card →
      ∃ x a b c : ℕ, 0<a ∧ a<b ∧ a+b<c ∧ TernaryBox A x a b c := by
  obtain ⟨k1,M1,hk1,_,step1⟩ := hp k hk
  obtain ⟨k2,M2,hk2,_,step2⟩ := hp k1 hk1
  obtain ⟨k3,M3,_,_,step3⟩ := hp k2 hk2
  let L2 := M1+1
  let L3 := M1+L2*M2+1
  obtain ⟨U,hU⟩ := step1 1 (by omega)
  obtain ⟨V,hV⟩ := step2 L2 (by dsimp [L2];omega)
  obtain ⟨W,hW⟩ := step3 L3 (by dsimp [L3];omega)
  refine ⟨max 1 (max U (max V W)),by omega,?_⟩
  intro N hN A hA hmass
  obtain ⟨a,ha,aTop,ma⟩ := hU N (by omega) A hA hmass
  let Aa := tripleStarts A a
  have sA : Aa⊆Icc 1 N := Subset.trans (tripleStarts_subset A a) hA
  obtain ⟨b,hb,bTop,mb⟩ := hV N (by omega) Aa sA ma
  let Aab := tripleStarts Aa b
  have sAB : Aab⊆Icc 1 N := Subset.trans (tripleStarts_subset Aa b) sA
  obtain ⟨c,hc,_,mc⟩ := hW N (by omega) Aab sAB mb
  have hcard : 0<(tripleStarts Aab c).card := by
    by_contra! bad
    have eq : (tripleStarts Aab c).card=0 := by omega
    rw [eq,Nat.mul_zero] at mc
    omega
  obtain ⟨x,hx⟩ := card_pos.mp hcard
  dsimp only [L2] at hb
  dsimp only [L3] at hc
  simp only [one_mul] at aTop
  exact ⟨x,a,b,c,by omega,by omega,by omega,box_of_starts hx⟩

theorem dousse8_of_popular (hp : PopularBound) : OP02.SharpK8.Dousse8 := by
  intro δ hδ
  obtain ⟨k,hk⟩ := exists_nat_gt (1/δ)
  have hkδ : 1 < (k:ℝ)*δ := (div_lt_iff₀ hδ).mp hk
  have hK : 0<k := by
    by_contra! h
    have hh : k=0 := by omega
    subst k
    norm_num at hkδ
  obtain ⟨N0,hN0,box⟩ := box_uniform hp k hK
  refine ⟨N0,hN0,?_⟩
  intro N hn A hA hd
  have mass : N ≤ k*A.card := by
    have t : (N:ℝ) ≤ (k:ℝ) * A.card := calc
      (N:ℝ) ≤ ((k:ℝ)*δ)*N := by nlinarith only [mul_nonneg (sub_nonneg.mpr hkδ.le) (show (0:ℝ)≤N by positivity)]
      _ = (k:ℝ)*(δ*N) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left hd (by positivity)
    exact_mod_cast t
  obtain ⟨x,a,b,c,ha,hb,hc,hbox⟩ := box N hn A hA mass
  exact eight_of_box ha hb hc hbox

end OP02.Midpoint

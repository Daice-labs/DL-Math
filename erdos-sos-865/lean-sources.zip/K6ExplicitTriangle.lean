import K6Roots
open Finset
namespace OP02.SharpK6
open OP02.FewHole OP02.SmallExcess
set_option maxHeartbeats 2000000

/-- Qualified vertices, ambient D labels: this is the accepted clarification.
No qualification of the pair-sum labels against u or v is required. -/
theorem qualified_triangle_explicit_clique (n u v:ℕ) (B T:Finset ℕ)
    (hu:u∈B) (hv:v∈B) (huv:u≠v) (huo:u%2=1) (hvo:v%2=1)
    (hsum:u+v∈B) (hT:T⊆quarterD n B) (hTc:T.card=3)
    (hpair:∀x∈T,∀y∈T,x≠y→x+y∈quarterD n B)
    (hqual:∀x∈T,u+4*x∈B ∧ v+4*x∈B) :
    let S:=insert u (insert v (T.image (fun x=>4*x)))
    S⊆B ∧ S.card=5 ∧ ∀x∈S,∀y∈S,x≠y→x+y∈B := by
  classical
  let Q:=T.image (fun x=>4*x)
  have hQ:Q⊆B := by
    intro x hx
    obtain ⟨r,hr,rfl⟩:=mem_image.mp hx
    exact (mem_filter.mp (hT hr)).2
  have hQc:Q.card=3 := by
    have hi:Function.Injective (fun x:ℕ=>4*x) := by intro x y h; change 4*x=4*y at h; omega
    rw [card_image_of_injective _ hi,hTc]
  have huQ:u∉Q := by
    intro hx
    obtain ⟨r,hr,he⟩:=mem_image.mp hx
    change 4*r=u at he
    omega
  have hvQ:v∉Q := by
    intro hx
    obtain ⟨r,hr,he⟩:=mem_image.mp hx
    change 4*r=v at he
    omega
  have hqp:∀x∈Q,∀y∈Q,x≠y→x+y∈B := by
    intro x hx y hy hxy
    obtain ⟨r,hr,rfl⟩:=mem_image.mp hx
    obtain ⟨s,hs,rfl⟩:=mem_image.mp hy
    have hh:=(mem_filter.mp (hpair r hr s hs (by omega))).2
    simpa only [Nat.mul_add] using hh
  have huq:∀x∈Q,u+x∈B := by
    intro x hx
    obtain ⟨r,hr,rfl⟩:=mem_image.mp hx
    exact (hqual r hr).1
  have hvq:∀x∈Q,v+x∈B := by
    intro x hx
    obtain ⟨r,hr,rfl⟩:=mem_image.mp hx
    exact (hqual r hr).2
  refine ⟨insert_subset hu (insert_subset hv hQ),?_,?_⟩
  · change (insert u (insert v Q)).card=5
    simp [huv,huQ,hvQ,hQc]
  · intro x hx y hy hxy
    rcases mem_insert.mp hx with hxu|hxV
    · subst x
      rcases mem_insert.mp hy with hyu|hyV
      · exact False.elim (hxy hyu.symm)
      · rcases mem_insert.mp hyV with hyv|hyQ
        · subst y; exact hsum
        · exact huq y hyQ
    · rcases mem_insert.mp hxV with hxv|hxQ
      · subst x
        rcases mem_insert.mp hy with hyu|hyV
        · subst y; simpa only [Nat.add_comm] using hsum
        · rcases mem_insert.mp hyV with hyv|hyQ
          · exact False.elim (hxy hyv.symm)
          · exact hvq y hyQ
      · rcases mem_insert.mp hy with hyu|hyV
        · subst y; simpa only [Nat.add_comm] using huq x hxQ
        · rcases mem_insert.mp hyV with hyv|hyQ
          · subst y; simpa only [Nat.add_comm] using hvq x hxQ
          · exact hqp x hxQ y hyQ hxy

#print axioms qualified_triangle_explicit_clique
end OP02.SharpK6

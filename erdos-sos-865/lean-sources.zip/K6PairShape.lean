import K6CanonicalProfiles
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.PositivePivot
set_option maxHeartbeats 2000000

theorem pair_shape (n:ℕ) (S:Finset ℕ) (hS:S⊆Icc 1 n) (hc:S.card=5)
    (hp:∀x∈S,∀y∈S,x≠y → x+y≤n)
    (hcase:((S.filter (fun x=>x%2=1)).card=2 ∧ ∃x∈S,∃y∈S,x%2=1 ∧ y%2=1 ∧ x%4≠y%4) ∨
      ((S.filter (fun x=>x%2=1)).card=4 ∧ ∃v∈S,v%4=2)) :
    ∃u∈insert 0 S,∃v∈S,u<v ∧ 2*u<n ∧ (u+2)%4=v%4 ∧
      (∀x∈insert 0 S\{u,v},x%2≠u%2) ∧
      (∀j:ℕ,((insert 0 S\{u,v}).filter (fun x=>x%4=j)).card≤4) := by
  classical
  have hz:0∉S := by intro h; have:=(mem_Icc.mp (hS h)).1; omega
  have hU:(insert 0 S).card=6 := by simp [hz,hc]
  have hload (u v:ℕ) (hu:u∈insert 0 S) (hv:v∈insert 0 S) (hne:u≠v):
      ∀j:ℕ,((insert 0 S\{u,v}).filter (fun x=>x%4=j)).card≤4 := by
    intro j
    apply le_trans (card_filter_le _ _)
    rw [card_sdiff_of_subset (by intro x hx; simp only [mem_insert,mem_singleton] at hx; rcases hx with rfl|rfl <;> assumption)]
    simp [hU,hne]
  rcases hcase with ⟨hcard,x,hx,y,hy,hxo,hyo,hxy⟩|⟨hcard,v,hv,hv4⟩
  · have he:(S.filter (fun z=>z%2=1))={x,y} := by
      symm
      apply eq_of_subset_of_card_le
      · intro z hz; simp only [mem_insert,mem_singleton] at hz
        rcases hz with rfl|rfl <;> exact mem_filter.mpr ⟨by assumption,by assumption⟩
      · simp [hcard,show x≠y by omega]
    have hother:∀z∈insert 0 S\{x,y},z%2≠x%2 := by
      intro z hz heven
      obtain ⟨hzU,hzne⟩:=mem_sdiff.mp hz
      rcases mem_insert.mp hzU with rfl|hzS
      · omega
      · have hzO:z∈S.filter (fun z=>z%2=1):=mem_filter.mpr ⟨hzS,show z%2=1 by omega⟩
        rw [he] at hzO
        exact hzne hzO
    have hsum:=hp x hx y hy (by omega)
    by_cases hlt:x<y
    · exact ⟨x,mem_insert_of_mem hx,y,hy,hlt,by omega,by omega,hother,hload x y (mem_insert_of_mem hx) (mem_insert_of_mem hy) (by omega)⟩
    · refine ⟨y,mem_insert_of_mem hy,x,hx,by omega,by omega,by omega,?_,hload y x (mem_insert_of_mem hy) (mem_insert_of_mem hx) (by omega)⟩
      intro z hz
      have:=hother z (by simpa only [pair_comm] using hz)
      omega
  · have hpart:S.card=(S.filter (fun z=>z%2=0)).card+(S.filter (fun z=>z%2=1)).card := by
      apply partition_card
      · intro z; simp only [mem_filter]; constructor
        · intro hz; by_cases he:z%2=0
          · exact Or.inl ⟨hz,he⟩
          · exact Or.inr ⟨hz,by omega⟩
        · tauto
      · intro z hz hz'; have:=(mem_filter.mp hz).2; have:=(mem_filter.mp hz').2; omega
    have he:S.filter (fun z=>z%2=0)={v} := by
      symm
      apply eq_of_subset_of_card_le
      · intro z hz; have he:=mem_singleton.mp hz; subst z; exact mem_filter.mpr ⟨hv,by omega⟩
      · simp only [card_singleton]; omega
    have hvI:=mem_Icc.mp (hS hv)
    refine ⟨0,by simp,v,hv,by omega,by omega,by omega,?_,hload 0 v (by simp) (mem_insert_of_mem hv) (by omega)⟩
    intro z hz heven
    obtain ⟨hzU,hzne⟩:=mem_sdiff.mp hz
    rcases mem_insert.mp hzU with h0|hzS
    · exact hzne (by simp [h0])
    · have hzE:z∈S.filter (fun z=>z%2=0):=mem_filter.mpr ⟨hzS,show z%2=0 by omega⟩
      rw [he] at hzE
      exact hzne (by simp [mem_singleton.mp hzE])
#print axioms pair_shape
end OP02.SharpK6

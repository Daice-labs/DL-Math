import K8FixedFourReplacement
import K8UpperSixComplement

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK7
namespace OP02.SharpK8

/-- The two singleton residues of one parity, with every offset keeping its actual value. -/
structure GapPair (O : Finset ℕ) (a b : ℕ) : Prop where
  left_mem : a∈O
  right_mem : b∈O
  same : a%2=b%2
  different : a%4≠b%4
  only : ∀s∈O, s%2=a%2 → s=a ∨ s=b
  load : ∀r z : ℕ, (O.filter (fun s => (r+s)%2=z%2)).card≤3

theorem GapPair.flip {O a b} (h : GapPair O a b) : GapPair O b a :=
  ⟨h.right_mem,h.left_mem,h.same.symm,h.different.symm,
   fun s hs he => (h.only s hs (he.trans h.same.symm)).symm,h.load⟩

theorem gap_pair_of_full {O : Finset ℕ} (hc : O.card=5)
    (full : ∀j<4,∃s∈O,s%4=j) : ∃ a b, GapPair O a b := by
  classical
  obtain ⟨a,ha,ar⟩ := full 0 (by decide)
  obtain ⟨b,hb,br⟩ := full 2 (by decide)
  obtain ⟨v,hv,vr⟩ := full 1 (by decide)
  obtain ⟨w,hw,wr⟩ := full 3 (by decide)
  let E := O.filter (fun s=>s%2=0)
  let F := O.filter (fun s=>s%2=1)
  have smallE : ({a,b}:Finset ℕ)⊆E := by
    intro s hs
    rcases mem_insert.mp hs with rfl|hh
    · exact mem_filter.mpr ⟨ha,by omega⟩
    · have e := mem_singleton.mp hh; subst s; exact mem_filter.mpr ⟨hb,by omega⟩
  have smallF : ({v,w}:Finset ℕ)⊆F := by
    intro s hs
    rcases mem_insert.mp hs with rfl|hh
    · exact mem_filter.mpr ⟨hv,by omega⟩
    · have e := mem_singleton.mp hh; subst s; exact mem_filter.mpr ⟨hw,by omega⟩
  have ec : ({a,b}:Finset ℕ).card=2 := by simp [show a≠b by omega]
  have fc : ({v,w}:Finset ℕ).card=2 := by simp [show v≠w by omega]
  have E2 := card_le_card smallE
  have F2 := card_le_card smallF
  have part : E.card+F.card=5 := by
    have e : O.filter (fun s=>¬s%2=0)=F := by
      ext x; simp only [F,mem_filter]; apply and_congr_right; intro _; omega
    have h := card_filter_add_card_filter_not (s:=O) (fun s=>s%2=0)
    rw [e,hc] at h; exact h
  have hload (r z : ℕ) : (O.filter (fun s=>(r+s)%2=z%2)).card≤3 := by
    by_cases e : r%2=z%2
    · have eq : O.filter (fun s=>(r+s)%2=z%2)=E := by ext s; simp only [E,mem_filter]; apply and_congr_right; intro _; rw [Nat.add_mod]; omega
      rw [eq]; omega
    · have eq : O.filter (fun s=>(r+s)%2=z%2)=F := by ext s; simp only [F,mem_filter]; apply and_congr_right; intro _; rw [Nat.add_mod]; omega
      rw [eq]; omega
  by_cases eq : E.card=2
  · have ident := eq_of_subset_of_card_le smallE (by omega)
    refine ⟨a,b,ha,hb,by omega,by omega,?_,hload⟩
    intro s hs hsp
    have hm : s∈E := mem_filter.mpr ⟨hs,by omega⟩
    rwa [←ident,mem_insert,mem_singleton] at hm
  · have ident := eq_of_subset_of_card_le smallF (by omega)
    refine ⟨v,w,hv,hw,by omega,by omega,?_,hload⟩
    intro s hs hsp
    have hm : s∈F := mem_filter.mpr ⟨hs,by omega⟩
    rwa [←ident,mem_insert,mem_singleton] at hm

def gapYHi (H : ℕ) := (128*(H/4)-5*H)/128
def gapLo (H a : ℕ) := ((H/4)/2+a)/2
def gapHi (H a : ℕ) := (gapYHi H+a)/2
def gapResidue (a b : ℕ) := ((12+a%8-b%8)%8)/2
def gapTrials (H a b : ℕ) := progression (gapLo H a) (gapHi H a) 4 (gapResidue a b)
def missingGap (H : ℕ) (D : Finset ℕ) (a b : ℕ) :=
  (gapTrials H a b).filter (fun g=>g∉D)

theorem gap_residue_rules {a b : ℕ} (same : a%2=b%2) (diff : a%4≠b%4) :
    gapResidue a b < 4 ∧ gapResidue a b%2=1 ∧
    gapResidue a b + gapResidue b a = 4 := by
  dsimp only [gapResidue]
  omega

theorem gap_pivot_data {H a b g : ℕ} (hH : 65536≤H) (same : a%2=b%2)
    (diff : a%4≠b%4) (hg : g∈gapTrials H a b) :
    (H/4)/2 < 2*g-a ∧ 128*(2*g-a)+5*H≤128*(H/4) ∧
    (2*g-a+b)%8=4 ∧ (2*g-a)%2=a%2 ∧ (2*g-a)+a=2*g := by
  obtain ⟨hi,hres⟩ := mem_filter.mp hg
  obtain ⟨lo,up⟩ := mem_Ioc.mp hi
  dsimp only [gapLo,gapHi,gapYHi] at lo up
  dsimp only [gapResidue] at hres
  exact ⟨by omega,by omega,by omega,by omega,by omega⟩

end OP02.SharpK8

import K7ReplacementRows
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7
set_option maxHeartbeats 1000000

private theorem larger_two {r l:ℕ} (h:r<l) : largest ({2*r,2*l}:Finset ℕ)=2*l:=by
  simp [largest,show 2*r≤2*l by omega]

theorem seed_implies_row9 {n:ℕ} {B:Finset ℕ} (hs:ActualO2Seed (n/4) (B∩Icc 1 (n/4))) :
    ∃S,InternalFive (B∩Icc 1 (n/4)) S ∧ rowNumber n B S=9 := by
  classical
  obtain ⟨u,v,h,k,l,hu,hv,hop,hh,hk,hl,hkl,hlow,hS⟩:=hs
  have uo:=Nat.odd_iff.mp hu
  have vo:=Nat.odd_iff.mp hv
  have ko:=Nat.odd_iff.mp hk
  have lo:=Nat.odd_iff.mp hl
  let S:Finset ℕ:={u,v,4*h,2*k,2*l}
  have huu:u≠v:=by omega
  have hkk:2*k≠2*l:=by omega
  have hodd:oddOffsets S={u,v}:=by
    ext x;simp only [oddOffsets,S,mem_filter,mem_insert,mem_singleton];omega
  have htwo:twoOffsets S={2*k,2*l}:=by
    ext x;simp only [twoOffsets,S,mem_filter,mem_insert,mem_singleton];omega
  have nmono:¬sameOdd S:=by
    rintro ⟨r,_,_,ha⟩
    exact hop ((ha u (by simp [S]) uo).trans (ha v (by simp [S]) vo).symm)
  have nocut:¬3*(2*l)≤2*(n/4):=by omega
  exact ⟨S,hS,by simp [rowNumber,hodd,htwo,larger_two hkl,huu,hkk,nmono,nocut]⟩

theorem row9_implies_seed {n:ℕ} {B S:Finset ℕ} (hs:InternalFive (B∩Icc 1 (n/4)) S)
    (hr:rowNumber n B S=9) : ActualO2Seed (n/4) (B∩Icc 1 (n/4)) := by
  classical
  have facts:(oddOffsets S).card=2 ∧ ¬sameOdd S ∧ (twoOffsets S).card=2 ∧
      2*(n/4)<3*largest (twoOffsets S):=by
    unfold rowNumber at hr;dsimp only at hr
    split_ifs at hr <;> first | omega | exact ⟨by assumption,by assumption,by assumption,by omega⟩
  obtain ⟨u,v,huv,hO⟩:=card_eq_two.mp facts.1
  obtain ⟨i,j,hij,hT⟩:=card_eq_two.mp facts.2.2.1
  have uO:u∈oddOffsets S:=by simp [hO]
  have vO:v∈oddOffsets S:=by simp [hO]
  have iT:i∈twoOffsets S:=by simp [hT]
  have jT:j∈twoOffsets S:=by simp [hT]
  have ud:=mem_filter.mp uO;have vd:=mem_filter.mp vO
  have id':=mem_filter.mp iT;have jd:=mem_filter.mp jT
  have uo:u%2=1:=ud.2;have vo:v%2=1:=vd.2
  have ir:i%4=2:=id'.2;have jr:j%4=2:=jd.2
  have op:u%4≠v%4:=by
    intro heq;apply facts.2.1
    refine ⟨u%4,by omega,by omega,?_⟩
    intro x hx hodd;have hx':x∈oddOffsets S:=mem_filter.mpr ⟨hx,hodd⟩
    simp only [hO,mem_insert,mem_singleton] at hx';omega
  let E:=oddOffsets S∪twoOffsets S
  have hdis:Disjoint (oddOffsets S) (twoOffsets S):=by
    apply disjoint_left.mpr;intro x ho ht
    have h1:x%2=1:=(mem_filter.mp ho).2;have h2:x%4=2:=(mem_filter.mp ht).2;omega
  have es:E⊆S:=union_subset (filter_subset _ _) (filter_subset _ _)
  have ecard:E.card=4:=by rw [show E=oddOffsets S∪twoOffsets S by rfl,card_union_of_disjoint hdis,facts.1,facts.2.2.1]
  have rest:(S\E).card=1:=by have :=card_sdiff_add_card_eq_card es;have :=hs.1;omega
  obtain ⟨x,hx⟩:=card_eq_one.mp rest
  have hxr:x∈S\E:=by simp [hx]
  obtain ⟨xS,xn⟩:=mem_sdiff.mp hxr
  have xzero:x%4=0:=by
    by_contra bad;apply xn
    by_cases odd:x%2=1
    · exact mem_union_left _ (mem_filter.mpr ⟨xS,odd⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨xS,by omega⟩)
  have xpos:0<x:=(mem_Icc.mp (mem_inter.mp (hs.2.1 xS)).2).1
  have hset:S={u,v,x,i,j}:=by
    ext a;simp only [mem_insert,mem_singleton]
    constructor
    · intro ha
      by_cases he:a∈E
      · rcases mem_union.mp he with ho|ht
        · simp only [hO,mem_insert,mem_singleton] at ho;tauto
        · simp only [hT,mem_insert,mem_singleton] at ht;tauto
      · have hmem:a∈S\E:=mem_sdiff.mpr ⟨ha,he⟩
        rw [hx,mem_singleton] at hmem;tauto
    · rintro (rfl|rfl|rfl|rfl|rfl) <;> first | assumption | exact ud.1 | exact vd.1 | exact id'.1 | exact jd.1
  have swapped:({u,v,x,i,j}:Finset ℕ)={u,v,x,j,i}:=by rw [show ({i,j}:Finset ℕ)={j,i} from Finset.pair_comm i j]
  have hhi:=facts.2.2.2
  have ix:2*(i/2)=i:=by omega
  have jx:2*(j/2)=j:=by omega
  have xx:4*(x/4)=x:=by omega
  by_cases cmp:i<j
  · have hm:largest (twoOffsets S)=j:=by simp [hT,largest,show i ≤ j by omega]
    have hcl:InternalFive (B∩Icc 1 (n/4)) {u,v,4*(x/4),2*(i/2),2*(j/2)}:=by rwa [xx,ix,jx,←hset]
    exact ⟨u,v,x/4,i/2,j/2,Nat.odd_iff.mpr uo,Nat.odd_iff.mpr vo,op,by omega,
      Nat.odd_iff.mpr (by omega),Nat.odd_iff.mpr (by omega),by omega,by omega,hcl⟩
  · have hm:largest (twoOffsets S)=i:=by simp [hT,largest,show j ≤ i by omega]
    have hcl:InternalFive (B∩Icc 1 (n/4)) {u,v,4*(x/4),2*(j/2),2*(i/2)}:=by rwa [xx,jx,ix,←swapped,←hset]
    exact ⟨u,v,x/4,j/2,i/2,Nat.odd_iff.mpr uo,Nat.odd_iff.mpr vo,op,by omega,
      Nat.odd_iff.mpr (by omega),Nat.odd_iff.mpr (by omega),by omega,by omega,hcl⟩

theorem row9_iff_actual_O2 (n:ℕ) (B:Finset ℕ) :
    ActualO2Seed (n/4) (B∩Icc 1 (n/4)) ↔
    ∃S,InternalFive (B∩Icc 1 (n/4)) S ∧ rowNumber n B S=9 :=
  ⟨seed_implies_row9,fun ⟨_,hs,hnum⟩=>row9_implies_seed hs hnum⟩

end OP02.SharpK7

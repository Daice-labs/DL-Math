import K7OddForcing
import K7OnWindow

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

/-- A replacement with the retained odd class and with its new odd vertex strictly largest. -/
def oddReplacement (n t t' h k : ℕ) (B : Finset ℕ) : Prop :=
  ∃ x∈oddBases (n/4) t t', InternalFive (B∩Icc 1 (n/4)) (insert x {t,t',4*h,2*k}) ∧
    x%4=t%4 ∧ ∀z∈({t,t',4*h,2*k}:Finset ℕ),z<x

private theorem tested_repr {n e b : ℕ} {B:Finset ℕ} {Y:Finset ℕ} {g:ℤ}
    (hg:g∈testedIndices (Y.image (fun x:ℕ=>((x/8:ℕ):ℤ)))
      ((retainedEndpoints n B e b).image (fun a:ℕ=>(a:ℤ))) (e:ℤ)) :
    ∃x∈Y,∃d:ℕ,d≤n/4/64 ∧ g=((x/8:ℕ):ℤ)+(d:ℤ) := by
  rcases mem_union.mp hg with hg|hg
  · obtain ⟨x,hx,rfl⟩:=mem_image.mp hg; exact ⟨x,hx,0,by omega,by simp⟩
  · obtain ⟨g',hg',hs⟩:=mem_biUnion.mp hg
    obtain ⟨x,hx,rfl⟩:=mem_image.mp hg'
    rcases mem_union.mp hs with hs|hs
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp hs
      obtain ⟨u,hu,heu⟩:=mem_image.mp ha
      subst a
      have hh:=(mem_filter.mp (mem_filter.mp hu).1).1
      exact ⟨x,hx,u,(mem_Icc.mp (mem_inter.mp hh).2).2,rfl⟩
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp hs
      obtain ⟨u,hu,heu⟩:=mem_image.mp ha
      subst a
      obtain ⟨_,_,hac,hc⟩:=mem_filter.mp (mem_filter.mp hu).1
      exact ⟨x,hx,e-u,(mem_Icc.mp (mem_inter.mp hc).2).2,by omega⟩

/-- For an actual short odd largest companion, the physical window is long
enough for interpolation. Either the original four companions admit their
new largest odd vertex, or the five J0 vertices and all ten sums are present. -/
theorem short_odd_window_qualified {β:ℝ} {n s t t' h k:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {t,t',4*h,2*k}))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (ho:t%2=1) (ho':t'%2=1) (hopp:t%4≠t'%4) (hk:k%2=1)
    (hm₀:∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤t) (ht:t≤17*(n/4/64)) :
    oddReplacement n t t' h k B ∨ qualifiedJ0 n B := by
  classical
  by_cases hex:oddReplacement n t t' h k B
  · exact Or.inl hex
  right
  let H:=n/4
  let N:=H/64
  let R:=(12-t'%8)%8
  let Y:=progression (max (H/2) (3*H/4-t)) (H-t-8*N) 8 R
  let I:=Y.image (fun x:ℕ=>((x/8:ℕ):ℤ))
  let p₀:ℤ:=((R+t)/2:ℕ)
  have hR:R<8:=by dsimp [R];omega
  have hRv:R%2=1 ∧ (R+t)%4=2:=by dsimp [R];omega
  have hn:6*lambdaBudget n B+6000<N:=by
    have h:=(signed_supply β n B hd hg (by omega) hl).2.1
    have h₀:(0:ℝ)≤(midOddLoss n B).card:=by positivity
    exact_mod_cast (show 6*(lambdaBudget n B:ℝ)+6000<(n/4/64:ℕ) by linarith only [h,h₀])
  have hHt : H=64*N+H%64:=by dsimp [N];omega
  have htN:t≤17*N:=ht
  have hm:3*t≤n/4:=by change 3*t≤H;omega
  have ht':=hm₀ t' (by simp)
  have hh:=hm₀ (4*h) (by simp)
  have hk':=hm₀ (2*k) (by simp)
  have hlow:=odd_base_failures hd ho ho' hopp hk hm (le_refl t) ht' hh hk'
  have ydata {x:ℕ} (hx:x∈Y) :
      max (H/2) (3*H/4-t)<x ∧ x≤H-t-8*N ∧ x%8=R := by
    obtain ⟨hI,hr⟩:=mem_filter.mp hx
    exact ⟨(mem_Ioc.mp hI).1,(mem_Ioc.mp hI).2,hr⟩
  have hIeq:I.card=Y.card:= by
    apply card_image_of_injOn;intro x hx y hy he
    have h1:=ydata hx;have h2:=ydata hy
    change ((x/8:ℕ):ℤ)=((y/8:ℕ):ℤ) at he
    omega
  have hlen:5*lambdaBudget n B<I.card:=by
    rw [hIeq]
    have hdY:=progression_lower (max (H/2) (3*H/4-t)) (H-t-8*N) 8 R (by decide) hR
    change _ / 8 ≤ Y.card at hdY
    omega
  obtain ⟨e,he,hee,hmax,w,hw,hj⟩:=many_retained β n B hd hg hscale hl
  let A:=retainedEndpoints n B e (4*w)
  let U:=latticeBad H B p₀ e I (A.image (fun a:ℕ=>(a:ℤ)))
  let V:=latticeVeto H B p₀ (4*w) I
  have data {x:ℕ} (hx:x∈Y) {d:ℕ} (hD:d≤N) :
      x+8*d∈oddBases H t t' ∧
      p₀+4*(((x/8:ℕ):ℤ)+d)=(((x+8*d+t)/2:ℕ):ℤ) := by
    have hxy:=ydata hx
    constructor
    · apply mem_filter.mpr
      exact ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by change (x+8*d)%8=R;omega⟩
    · dsimp only [p₀];omega
  have hU:U.card≤A_loss n B+2*T_loss n B+G_loss n B := by
    apply le_trans _ hlow
    apply card_le_card_of_injOn (fun g:ℤ=>((R:ℤ)+8*g).toNat)
    · intro g hgu
      obtain ⟨hgt,hmiss⟩:=mem_filter.mp hgu
      obtain ⟨x,hx,d,hdN,hgi⟩:=tested_repr hgt
      have hxy:=ydata hx
      have hgpos:((R:ℤ)+8*g).toNat=x+8*d := by omega
      change ((R:ℤ)+8*g).toNat ∈ (oddBases (n/4) t t').filter (fun x=>¬oddTests n t t' h k x B)
      rw [hgpos]
      obtain ⟨had,haeq⟩:=data hx hdN
      apply mem_filter.mpr;refine ⟨had,?_⟩;intro hpass
      rcases odd_base_alternative hs hm hm₀ ho ho' hopp had hpass with hp|hc
      · apply hmiss;apply mem_image.mpr
        refine ⟨(x+8*d+t)/2,mem_inter.mpr ⟨hp,mem_Icc.mpr ⟨by omega,by omega⟩⟩,?_⟩
        rw [hgi];exact haeq.symm
      · exact hex ⟨x+8*d,had,hc⟩
    · intro g hg g' hg' hEq
      obtain ⟨x,hx,d,hdN,heq⟩:=tested_repr (mem_filter.mp hg).1
      obtain ⟨y,hy,v,hvN,heq'⟩:=tested_repr (mem_filter.mp hg').1
      change ((R:ℤ)+8*g).toNat=((R:ℤ)+8*g').toNat at hEq
      omega
  have hw':=rigid_bounds (mem_filter.mp hw).1
  have base {g:ℤ} (hgI:g∈I) : ∃p:ℕ,(p:ℤ)=p₀+4*g ∧ p%2=1 ∧
       3*H≤8*p ∧ p+4*N≤H/2 := by
    obtain ⟨x,hx,rfl⟩:=mem_image.mp hgI
    have hxy:=ydata hx
    refine ⟨(x+t)/2,?_,by omega,by omega,by omega⟩
    dsimp only [p₀];omega
  have hV:V.card≤T_loss n B := by
    apply le_trans _ (absent_top_cost n B hd)
    apply card_le_card_of_injOn (fun g:ℤ=>(p₀+4*g+4*(4*w)).toNat)
    · intro g hbad
      obtain ⟨hI,hnmem⟩:=mem_filter.mp hbad
      obtain ⟨p,hp,ho,pmin,pmax⟩:=base hI
      have h2:N/2<w ∧ w≤(3*N+1)/4:=⟨hw'.1,hw'.2.1⟩
      have heq:(p₀+4*g+4*(4*w)).toNat=p+16*w:=by omega
      change (p₀+4*g+4*(4*w)).toNat∈absentTop n B
      rw [heq];apply mem_filter.mpr
      refine ⟨mem_Ioc.mpr ⟨?_,?_⟩,by omega,?_⟩
      · change H/2<p+16*w;omega
      · change p+16*w≤H;omega
      · intro htB;apply hnmem;apply mem_image.mpr
        exact ⟨p+16*w,mem_inter.mpr ⟨htB,mem_Icc.mpr ⟨by omega,by omega⟩⟩,by omega⟩
    · intro i hi j hj hEq
      obtain ⟨p,hp,_⟩:=base (mem_filter.mp hi).1
      obtain ⟨p',hp',_⟩:=base (mem_filter.mp hj).1
      change (p₀+4*i+4*(4*w)).toNat=(p₀+4*j+4*(4*w)).toNat at hEq
      omega
  have inv:=common_inventory n B
  have jpos:lambdaBudget n B<A.card:=hj
  apply qualified_j0_on_window hd hg hscale hl he hee hw hj p₀ I
  · change (V.card:ℤ)+max (U.card:ℤ) (3*(U.card:ℤ)-2*(A.card:ℤ)+2)<(I.card:ℤ)
    omega
  · intro g hgI
    obtain ⟨p,hp,hodd,hlo,hup⟩:=base hgI
    exact ⟨p,hp,hodd,hlo,by change 2*p≤H;omega,standard_partner_width hd hg hscale hl hup⟩

theorem short_odd_window {β:ℝ} {n s t t' h k:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {t,t',4*h,2*k}))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (ho:t%2=1) (ho':t'%2=1) (hopp:t%4≠t'%4) (hk:k%2=1)
    (hm₀:∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤t) (ht:t≤17*(n/4/64)) :
    oddReplacement n t t' h k B ∨ j0Witness n B :=
  (short_odd_window_qualified hd hg hs hscale hl ho ho' hopp hk hm₀ ht).imp_right forget_qualification

end OP02.SharpK7

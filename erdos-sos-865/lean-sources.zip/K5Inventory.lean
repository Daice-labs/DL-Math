import K5Roots
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 3000000

def emptyPairs (n : ℕ) (B : Finset ℕ) :=
  (oddSlots n).filter (fun u=>2*u≤n ∧ u∉B ∧ 2*u∉B)

/-- The manuscript's paired and singleton deficits are the retained actual deficit. -/
theorem deficit_split (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    deficit n B=(emptyPairs n B).card+(missingTopOdd n B).card := by
  classical
  let im := (residueR n B).image compress
  have him : im⊆oddSlots n := by
    intro y hy
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hy
    exact compression_mem n B hx
  have hmissing : oddSlots n\im=emptyPairs n B∪missingTopOdd n B := by
    ext u
    constructor
    · intro hu
      obtain ⟨huO,huI⟩ := mem_sdiff.mp hu
      have huB : u∉B := by
        intro huB
        apply huI
        apply mem_image.mpr
        refine ⟨u,mem_filter.mpr ⟨mem_inter.mpr ⟨huB,(mem_filter.mp huO).1⟩,?_⟩,?_⟩
        · have := (mem_filter.mp huO).2; omega
        · simp [compress,(mem_filter.mp huO).2]
      by_cases hn : 2*u≤n
      · apply mem_union_left
        refine mem_filter.mpr ⟨huO,hn,huB,?_⟩
        intro h2
        apply huI
        apply mem_image.mpr
        refine ⟨2*u,mem_filter.mpr ⟨mem_inter.mpr ⟨h2,mem_Icc.mpr ⟨?_,hn⟩⟩,?_⟩,?_⟩
        · have := (mem_Icc.mp (mem_filter.mp huO).1).1; omega
        · have := (mem_filter.mp huO).2; omega
        · simp [compress]
      · exact mem_union_right _ (mem_filter.mpr ⟨huO,by omega,huB⟩)
    · intro hu
      rcases mem_union.mp hu with hu|hu
      · obtain ⟨huO,hn,huB,h2⟩ := mem_filter.mp hu
        refine mem_sdiff.mpr ⟨huO,?_⟩
        intro huim
        obtain ⟨x,hx,hxu⟩ := mem_image.mp huim
        have hxB := (mem_inter.mp (mem_filter.mp hx).1).1
        have hx4 := (mem_filter.mp hx).2
        unfold compress at hxu
        split_ifs at hxu
        · exact huB (hxu ▸ hxB)
        · have he : x=2*u := by omega
          exact h2 (he ▸ hxB)
      · obtain ⟨huO,hn,huB⟩ := mem_filter.mp hu
        refine mem_sdiff.mpr ⟨huO,?_⟩
        intro huim
        obtain ⟨x,hx,hxu⟩ := mem_image.mp huim
        have hxB := (mem_inter.mp (mem_filter.mp hx).1).1
        have hxn := (mem_Icc.mp (mem_inter.mp (mem_filter.mp hx).1).2).2
        unfold compress at hxu
        split_ifs at hxu
        · exact huB (hxu ▸ hxB)
        · omega
  have hdis : Disjoint (emptyPairs n B) (missingTopOdd n B) := by
    apply disjoint_left.mpr
    intro u hu hv
    have := (mem_filter.mp hu).2
    have := (mem_filter.mp hv).2
    omega
  have hc := congrArg Finset.card hmissing
  rw [card_sdiff_of_subset him,card_union_of_disjoint hdis,oddSlots_card] at hc
  have hi : im.card=(residueR n B).card := card_image_of_injOn (compression_injective n B hd)
  simpa only [hi,deficit] using hc

theorem middle_two_le_singleton (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    ((middle n B).filter (fun x=>x%4=2)).card≤(missingTopOdd n B).card := by
  classical
  apply card_le_card_of_injOn (fun x=>x/2)
  · intro x hx
    obtain ⟨hxM,hx4⟩ := mem_filter.mp hx
    obtain ⟨hxB,hxI⟩ := mem_inter.mp hxM
    obtain ⟨hxl,hxu⟩ := mem_Icc.mp hxI
    change x/2∈missingTopOdd n B
    refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega,?_⟩
    intro hh
    have he : 2*(x/2)=x := by omega
    apply hd (x/2) hh
    rw [he]
    exact hxB
  · intro x hx y hy hxy
    change x/2=y/2 at hxy
    have := (mem_filter.mp hx).2
    have := (mem_filter.mp hy).2
    omega

/-- No FourFree hypothesis: this identity is valid in the actual k5 setting. -/
theorem exact_inventory (n : ℕ) (B : Finset ℕ) (hs : B⊆Icc 1 (4*n))
    (hd : DoublingFree B) :
    B.card+deficit n B+(excessHoles n B).card=2*n+(n+1)/2+(quarterD n B).card := by
  have h1 := counting_identity n B hs hd
  have h2 := lower_card_eq n B
  have h3 := residue_card_le n B hd
  unfold deficit
  omega

#print axioms deficit_split
#print axioms middle_two_le_singleton
#print axioms exact_inventory
end OP02.SharpK5

import K7OddNearMax
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7.LongOddTask

/-- All sizes in the largest-2k placement with h even and odd-only supply.
The even-vertex replacement and its shifts lie in their original slots. -/
theorem odd_only_two_k {β:ℝ} {n s u v h k:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {u,v,4*h,2*k}))
    (sc:16384≤n/4/64) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (uo:u%2=1) (vo:v%2=1) (op:u%4≠v%4) (ko:k%2=1) (ho:h%2=0)
    (hm:∀z∈({u,v,4*h,2*k}:Finset ℕ),z≤2*k) (upper:3*(2*k)<n/4)
    (pure:¬ActiveEvenSupply n B):
    evenReplacement n u v h k B ∨ qualifiedJ0 n B := by
  classical
  by_cases rep:evenReplacement n u v h k B
  · exact Or.inl rep
  right
  let H:=n/4
  let N:=H/64
  let L:=lambdaBudget n B
  let start:=(max (H/8) ((3*H+15)/16-k/2))/2+1
  let z (i:ℕ):=2*i+1
  let p (i:ℕ):=k+2*z i
  let P:=evenBases H (2*k)
  -- The variable w below indexes the replacing multiple of four.
  let faults:=P.filter (fun w=>¬evenTests n u v h k w B)
  let F:=faults.image (fun w:ℕ=>w/2)
  have sc₀:64≤n/4:=by omega
  have signed:=signed_units hd hg sc₀ hl
  have inv:=common_inventory n B
  have signed' : 6*L+6000<N := by change 6*lambdaBudget n B+6000<n/4/64;omega
  have rem : H=64*N+H%64:=by dsimp [N];omega
  have hm' : 6*k<H:=by change _<n/4;omega
  have cap:=even_base_failures hd uo vo op ho ko (Nat.le_of_lt upper) (hm _ (by simp)) (hm _ (by simp))
    (hm _ (by simp)) (by omega : 2*k≤2*k)
  have fcap:F.card≤2*L:=by
    have raw:F.card≤faults.card:=card_image_le
    change faults.card ≤ _ at cap;dsimp only [L];omega
  have bounds (g:ℕ) (gi:g∈Icc start (start+2*L+1)):
      H/8<z g ∧ 3*H≤8*p g ∧ 4*z g+8*N+2*k≤H := by
    have eq:=mem_Icc.mp gi
    dsimp only [start] at eq
    dsimp only [p,z];omega
  apply odd_only_select (start:=start) hd hg sc₀ hl pure F p fcap
  · intro g gi;obtain ⟨_,low,up⟩:=bounds g gi
    exact ⟨low,by change k+2*z g+4*N≤H/2;omega,by dsimp [p];omega⟩
  · intro g gi a ha good
    have bo:=bounds g gi;have an:a≤N:=ha
    let w:=z g+2*a
    have wp:w∈P:=by
      apply mem_filter.mpr
      exact ⟨mem_Ioc.mpr ⟨by dsimp [w];omega, by dsimp [w];omega⟩,by dsimp [w,z];omega⟩
    have tests:evenTests n u v h k w B:=by
      by_contra no;apply good;apply mem_image.mpr
      exact ⟨w,mem_filter.mpr ⟨wp,no⟩,by dsimp [w,z];omega⟩
    rcases even_base_alternative hs (Nat.le_of_lt upper) hm ko wp tests with occ|row
    · rwa [show p g+4*a=k+2*w by dsimp [p,w];omega]
    · exact (rep ⟨w,wp,row⟩).elim
end OP02.SharpK7.LongOddTask

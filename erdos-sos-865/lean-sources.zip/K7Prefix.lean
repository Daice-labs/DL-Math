import K7Dousse
import K7Budget

open Finset OP02.SmallExcess OP02.FewHole OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- In (floor(n/4),n] a lower element is identified by its double and an
upper element by itself. This handles the stray tail at n = 2 or 3 mod 4. -/
theorem prefix_card (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    (quarterD n B).card + (excessHoles n B).card ≤
      (B ∩ Icc 1 (n/4)).card + totalBudget n B := by
  classical
  let Y := outerMembers n B
  let f (x : ℕ) := if x ≤ n/2 then 2*x else x
  have hmap (x : ℕ) (hx : x∈Y) : f x∈Ioc (n/2) n := by
    have hh := mem_Ioc.mp (mem_inter.mp hx).2
    simp only [f,mem_Ioc];split_ifs <;> omega
  have hi : Set.InjOn f (Y : Set ℕ) := by
    intro x hx y hy h
    have h1 := hd x (mem_inter.mp hx).1
    have h2 := hd y (mem_inter.mp hy).1
    have hxB := (mem_inter.mp hx).1;have hyB := (mem_inter.mp hy).1
    unfold f at h
    split_ifs at h <;> first | omega | subst x;contradiction | subst y;contradiction
  have hcount := card_le_card_of_injOn f hmap hi
  rw [Nat.card_Ioc] at hcount
  have htail := shell_count n B hd
  have he := exact_outer_partition n B hd
  change Y.card + _ = _ at he
  have hL := lower_card_eq n B
  change (prefixRoots n B).card = _ at hL
  have hr := residue_card_le n B hd
  unfold totalBudget deficit
  change _ ≤ (prefixRoots (n/4) B).card + _
  omega

theorem prefix_admission (hD : Dousse7) (β : ℝ) (hb : 0<β) :
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀≤n → ∀ B : Finset ℕ, DoublingFree B →
      (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
      ∃ S : Finset ℕ, InternalFive (B ∩ Icc 1 (n/4)) S := by
  classical
  obtain ⟨U,hU⟩ := fivefree_uniform hD β hb
  refine ⟨4*(U+1),?_⟩
  intro n hn B hd hg
  let H := n/4
  let C := B ∩ Icc 1 H
  have hp : (quarterD n B).card ≤ C.card + totalBudget n B := by
    have h := prefix_card n B hd
    change _ ≤ C.card + _ at h; omega
  have hpr : ((quarterD n B).card:ℝ) ≤ C.card + (totalBudget n B:ℝ) := by exact_mod_cast hp
  have h4 : (4:ℝ)*H ≤ n := by exact_mod_cast (show 4*H≤n by dsimp [H];omega)
  have ht : (0:ℝ)<H := by exact_mod_cast (show 0<H by dsimp [H];omega)
  by_contra hnone
  have hfree : OP02.SharpK5.FiveFree C := by
    rintro ⟨S,hs,hc,hp⟩;exact hnone ⟨S,hc,hs,hp⟩
  have hh := hU H (by dsimp [H];omega) C inter_subset_right hfree
  nlinarith only [hg,h4,hpr,hh,mul_nonneg hb.le (sub_nonneg.mpr h4),mul_pos hb ht]

end OP02.SharpK7

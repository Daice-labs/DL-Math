import SharedHole
open Finset Filter
open scoped Asymptotics
namespace OP02.SharpK5
set_option maxHeartbeats 3000000

/-- Exactly five distinct members with all off-diagonal physical sums retained. -/
def FiveFree (B : Finset ℕ) : Prop :=
  ¬ ∃ S⊆B, S.card=5 ∧ ∀x∈S,∀y∈S,x≠y→x+y∈B

/-- External fixed-order midpoint input. No axiom is declared. -/
def Dousse5 : Prop :=
  ∀δ:ℝ,0<δ→∃N₀:ℕ,1≤N₀ ∧ ∀N:ℕ,N₀≤N→∀T:Finset ℕ,T⊆Icc 1 N→
    δ*(N:ℝ)≤(T.card:ℝ)→∃S⊆T,S.card=5 ∧ ∀x∈S,∀y∈S,x≠y→∃z∈T,x+y=2*z

/-- The fixed-order five-point external input also supplies the k4 midpoint input. -/
theorem dousse4_of_dousse5 (hD : Dousse5) : OP02.Frontier.Dousse4 := by
  intro δ hδ
  obtain ⟨N₀,hN₀,h⟩ := hD δ hδ
  refine ⟨N₀,hN₀,?_⟩
  intro N hN T hT hcard
  obtain ⟨S,hST,hSc,hmid⟩ := h N hN T hT hcard
  obtain ⟨U,hUS,hUc⟩ := exists_subset_card_eq (show 4≤S.card by omega)
  refine ⟨U,Subset.trans hUS hST,hUc,?_⟩
  intro x hx y hy hxy
  exact hmid x (hUS hx) y (hUS hy) hxy

/-- Actual normalized target of the two-band argument, not supplied as an axiom. -/
def NormalizedGoal : Prop :=
  ∀β:ℝ,0<β→∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→
    FiveFree B→OP02.FewHole.DoublingFree B→
      (B.card:ℝ)≤(85/32:ℝ)*n+β*n+1/2

def K5Goal : Prop :=
  (fun N ↦ (Erdos865.f N 5 : ℝ)) ~[atTop] (fun N ↦ (85/128:ℝ)*N)

theorem deletion (hD : Dousse5) (δ : ℝ) (hδ : 0 < δ) :
      ∃ N0 : ℕ, 1 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N →
        ∀ A : Finset ℕ, A ⊆ Finset.Icc 1 N →
          FiveFree A →
          ∃ B : Finset ℕ, B ⊆ Finset.Icc 1 N ∧
            FiveFree B ∧
            OP02.FewHole.DoublingFree B ∧
            (A.card : ℝ) ≤ (B.card : ℝ) + δ * (N : ℝ) := by
    classical
    obtain ⟨N0, hN0, hD0⟩ := hD δ hδ
    refine ⟨N0, hN0, ?_⟩
    intro N hN A hsub hfour
    let T : Finset ℕ := A.filter (fun x => 2 * x ∈ A)
    have hTA : T ⊆ A := by
      intro x hx
      exact (Finset.mem_filter.mp hx).1
    have hTI : T ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hTA hx)
    have ht : (T.card : ℝ) < δ * (N : ℝ) := by
      by_contra hn
      have hd : δ * (N : ℝ) ≤ (T.card : ℝ) := le_of_not_gt hn
      obtain ⟨S, hST, hSc, hm⟩ := hD0 N hN T hTI hd
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hTA (hST hx)
      · intro x hx y hy hxy
        obtain ⟨z, hz, hzxy⟩ := hm x hx y hy hxy
        rw [hzxy]
        exact (Finset.mem_filter.mp hz).2
    let B : Finset ℕ := A \ T
    have hBA : B ⊆ A := by
      intro x hx
      exact (Finset.mem_sdiff.mp hx).1
    have hBI : B ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hBA hx)
    have hfB : FiveFree B := by
      rintro ⟨S, hSB, hSc, hpair⟩
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hBA (hSB hx)
      · intro x hx y hy hxy
        exact hBA (hpair x hx y hy hxy)
    have hdB : OP02.FewHole.DoublingFree B := by
      intro x hx h2
      obtain ⟨hxA, hxT⟩ := Finset.mem_sdiff.mp hx
      apply hxT
      exact Finset.mem_filter.mpr ⟨hxA, hBA h2⟩
    have hcard : B.card + T.card = A.card :=
      Finset.card_sdiff_add_card_eq_card hTA
    have hcardR : (B.card : ℝ) + (T.card : ℝ) = (A.card : ℝ) := by
      exact_mod_cast hcard
    refine ⟨B, hBI, hfB, hdB, ?_⟩
    linarith only [hcardR, ht]

theorem blocks (N : ℕ) :
    ∃ A : Finset ℕ, A ⊆ Icc 1 N ∧ FiveFree A ∧ A.card = 85 * (N / 128) := by
  classical
  let m := N / 128
  let J0 := Icc (1*m+1) (2*m)
  let J1 := Icc (4*m+1) (8*m)
  let J2 := Icc (16*m+1) (32*m)
  let J3 := Icc (64*m+1) (128*m)
  let A := J0 ∪ J1 ∪ J2 ∪ J3
  have hmem (x : ℕ) : x∈A ↔
    (m+1≤x ∧ x≤2*m) ∨ (4*m+1≤x ∧ x≤8*m) ∨
    (16*m+1≤x ∧ x≤32*m) ∨ (64*m+1≤x ∧ x≤128*m) := by
    simp only [A,J0,J1,J2,J3,mem_union,mem_Icc,one_mul] <;> tauto
  have hm : 128*m≤N := by dsimp [m]; omega
  have hsub : A⊆Icc 1 N := by
    intro x hx
    have hx := (hmem x).mp hx
    rw [mem_Icc]
    rcases hx with hx|hx|hx|hx <;> omega
  have hc0 : J0.card=1*m := by simp [J0,Nat.card_Icc]; omega
  have hc1 : J1.card=4*m := by simp [J1,Nat.card_Icc]; omega
  have hc2 : J2.card=16*m := by simp [J2,Nat.card_Icc]; omega
  have hc3 : J3.card=64*m := by simp [J3,Nat.card_Icc]; omega
  have hd1 : Disjoint (J0) J1 := by
    apply disjoint_left.mpr
    intro x hx hy
    simp only [J0,J1,J2,J3,mem_union,mem_Icc,one_mul] at hx hy
    omega
  have hd2 : Disjoint (J0 ∪ J1) J2 := by
    apply disjoint_left.mpr
    intro x hx hy
    simp only [J0,J1,J2,J3,mem_union,mem_Icc,one_mul] at hx hy
    omega
  have hd3 : Disjoint (J0 ∪ J1 ∪ J2) J3 := by
    apply disjoint_left.mpr
    intro x hx hy
    simp only [J0,J1,J2,J3,mem_union,mem_Icc,one_mul] at hx hy
    omega
  have hcard : A.card=85*m := by
    change (J0∪J1∪J2∪J3).card=85*m
    rw [card_union_of_disjoint hd3,card_union_of_disjoint hd2,card_union_of_disjoint hd1,hc0,hc1,hc2,hc3]
    omega
  have hfree : FiveFree A := by
    rintro ⟨S,hSA,hSc,hpairs⟩
    let col : ℕ→ℕ := fun x=>if x≤2*m then 0 else if x≤8*m then 1 else if x≤32*m then 2 else 3
    have hmaps : ∀x∈S,col x∈Icc 0 3 := by
      intro x hx
      dsimp [col]
      split_ifs <;> norm_num [mem_Icc]
    have hlt : (Icc (0:ℕ) 3).card<S.card := by norm_num [hSc,Nat.card_Icc]
    obtain ⟨x,hx,y,hy,hxy,hcol⟩ := exists_ne_map_eq_of_card_lt_of_maps_to hlt hmaps
    have hxa := (hmem x).mp (hSA hx)
    have hya := (hmem y).mp (hSA hy)
    have hs := (hmem (x+y)).mp (hpairs x hx y hy hxy)
    dsimp [col] at hcol
    split_ifs at hcol <;> omega
  exact ⟨A,hsub,hfree,hcard⟩

/-- Endpoint bridge only: NormalizedGoal remains an explicit unproved input. -/
theorem endpoint_of_normalized (hD : Dousse5) (hnorm : NormalizedGoal) : K5Goal := by
  classical
  let P : ℕ → ℕ → Prop := fun N t =>
    ∀ A : Finset ℕ, A ⊆ Finset.Icc 1 N → t ≤ A.card →
      ∃ S ⊆ A, S.card = 5 ∧
        ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ A
  have f_spec (N : ℕ) : P N (Erdos865.f N 5) := by
    have hne : ({t : ℕ | P N t} : Set ℕ).Nonempty := by
      refine ⟨N + 1, ?_⟩
      intro A hA hc
      have hcc := Finset.card_le_card hA
      have hIc : (Finset.Icc 1 N).card = N := by
        rw [Nat.card_Icc]
        omega
      rw [hIc] at hcc
      omega
    change sInf {t : ℕ | P N t} ∈ {t : ℕ | P N t}
    exact Nat.sInf_mem hne
  have f_le (N t : ℕ) (ht : P N t) : Erdos865.f N 5 ≤ t := by
    change sInf {u : ℕ | P N u} ≤ t
    exact Nat.sInf_le ht
  have f_lower (N : ℕ) : 85 * (N / 128) < Erdos865.f N 5 := by
    obtain ⟨A, hsub, hfour, hcard⟩ := blocks N
    by_contra hn
    have hfA : Erdos865.f N 5 ≤ A.card := by omega
    exact hfour (f_spec N A hsub hfA)
  have f_witness (N : ℕ) :
      ∃ A : Finset ℕ, A ⊆ Finset.Icc 1 N ∧
        FiveFree A ∧ Erdos865.f N 5 ≤ A.card + 1 := by
    have hfpos : 0 < Erdos865.f N 5 := by
      have hf := f_lower N
      omega
    by_contra hno
    have hp : P N (Erdos865.f N 5 - 1) := by
      intro A hA hc
      by_contra hbad
      apply hno
      refine ⟨A, hA, hbad, ?_⟩
      omega
    have hle := f_le N (Erdos865.f N 5 - 1) hp
    omega
  have f_lower_real (N : ℕ) :
      (85 / 128 : ℝ) * (N : ℝ) - 85 ≤ (Erdos865.f N 5 : ℝ) := by
    have hn : N ≤ 128 * (N / 128) + 127 := by omega
    have hf := f_lower N
    have hnr : (N : ℝ) ≤ 128 * ((N / 128 : ℕ) : ℝ) + 127 := by
      exact_mod_cast hn
    have hfr : (85 : ℝ) * ((N / 128 : ℕ) : ℝ) <
        (Erdos865.f N 5 : ℝ) := by
      exact_mod_cast hf
    linarith only [hnr, hfr]
  have f_upper (δ:ℝ) (hδ:0<δ) : ∃N₀:ℕ,∀N:ℕ,N₀≤N→
      (Erdos865.f N 5:ℝ)≤(85/128:ℝ)*N+δ*N+(δ+5) := by
    obtain ⟨D,hDpos,hdel⟩ := deletion hD (δ/2) (by positivity)
    obtain ⟨T,hT⟩ := hnorm δ hδ
    refine ⟨max D (4*T),?_⟩
    intro N hN
    have hDN : D≤N := le_trans (le_max_left _ _) hN
    have hTN : 4*T≤N := le_trans (le_max_right _ _) hN
    obtain ⟨A,hA,hAf,hfA⟩ := f_witness N
    obtain ⟨B,hB,hBf,hBd,hloss⟩ := hdel N hDN A hA hAf
    let n := N/4+1
    have hn : T≤n := by dsimp [n]; omega
    have hNn : N≤4*n := by dsimp [n]; omega
    have hnN : 4*n≤N+4 := by dsimp [n]; omega
    have hB' : B⊆Icc 1 (4*n) := by
      intro x hx
      have hx := mem_Icc.mp (hB hx)
      exact mem_Icc.mpr ⟨hx.1,by omega⟩
    have hb := hT n hn B hB' hBf hBd
    have hnr : (4:ℝ)*n≤N+4 := by exact_mod_cast hnN
    have hfa : (Erdos865.f N 5:ℝ)≤(A.card:ℝ)+1 := by exact_mod_cast hfA
    have hNN : (0:ℝ)≤N := by positivity
    nlinarith [mul_nonneg (le_of_lt hδ) (show (0:ℝ)≤N+4-4*n by linarith)]
  change Asymptotics.IsLittleO Filter.atTop
    (fun N:ℕ=>(Erdos865.f N 5:ℝ)-(85/128:ℝ)*N)
    (fun N:ℕ=>(85/128:ℝ)*N)
  apply Asymptotics.isLittleO_iff.mpr
  intro ε hε
  let δ : ℝ := ε*(85/128:ℝ)/2
  have hδ : 0<δ := by dsimp [δ]; positivity
  obtain ⟨N₀,hN₀⟩ := f_upper δ hδ
  obtain ⟨M,hM⟩ := exists_nat_gt ((δ+90)/δ)
  apply Filter.eventually_atTop.mpr
  refine ⟨max N₀ M,?_⟩
  intro N hN
  have hMN : (M:ℝ)≤N := by exact_mod_cast (le_trans (le_max_right N₀ M) hN)
  have hdiv : (δ+90)/δ<(N:ℝ) := lt_of_lt_of_le hM hMN
  have hsmall : δ+90≤δ*(N:ℝ) := by
    have := (div_lt_iff₀ hδ).mp hdiv
    nlinarith
  have hup := hN₀ N (le_trans (le_max_left _ _) hN)
  have hlo := f_lower_real N
  have hnn : (0:ℝ)≤(85/128:ℝ)*N := by positivity
  change ‖(Erdos865.f N 5:ℝ)-(85/128:ℝ)*N‖≤ε*‖(85/128:ℝ)*N‖
  simp only [Real.norm_eq_abs,abs_of_nonneg hnn]
  apply abs_le.mpr
  dsimp [δ] at hup hsmall
  constructor <;> nlinarith only [hup,hlo,hsmall,hδ]

#print axioms dousse4_of_dousse5
#print axioms deletion
#print axioms blocks
#print axioms endpoint_of_normalized
end OP02.SharpK5

import K7LongOddCharge
import K7LongLattice
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

theorem long_odd_even_mixed_window (hD:Dousse7) : WindowStatement := by
  intro β hb
  obtain ⟨U,hU⟩:=long_odd_shared_loss hD β hb
  obtain ⟨V,hV⟩:=uniform_window_threshold β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  obtain ⟨J,hJ⟩:=inventory_uniform β hb
  obtain ⟨A,hA⟩:=(bridge_rows_of_dispatch hD (i:=14) (Or.inr rfl)) β hb
  refine ⟨max (4*64*16384) (max U (max V (max W (max J A)))),?_⟩
  intro n hn B sub hf hd hg t t' h k l ho ho' opp hp ko lo kl big seed largest ht active
  have loss:=hU n (by omega) B sub hf hd hg t t' h k l ho ho' opp hp ko lo kl big seed largest ht active
  obtain ⟨_,hl⟩:=hV n (by omega)
  obtain ⟨cap,large⟩:=hJ n (by omega) B hd hg
  have sum:=(mem_Icc.mp (mem_inter.mp (seed.2.2 t (by simp) (2*l) (by simp) (by omega))).2).2
  obtain ⟨e,he,he₂,hmax,_⟩:=active
  rcases interpolate_long_window hd hg seed (by omega) hl ho ho' opp ko largest ht (by omega) loss he he₂ hmax with rep|five
  · obtain ⟨T,hT,row⟩:=odd_replacement_in_row14 ho ho' opp ko rep
    exact hA n (by omega) B sub hf hd hg T hT row
  · exact qualified_J0_exclusion hf hd (hW n (by omega) B hf hd hg) cap large five

end OP02.SharpK7.LongOddTask

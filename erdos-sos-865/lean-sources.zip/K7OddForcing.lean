import K7Forcing
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

def oddBases (H m t' : ℕ) := progression (H/2) (H-m) 8 ((12-t'%8)%8)
def oddTests (n t t' h k x:ℕ) (B:Finset ℕ) : Prop :=
  x∈B ∧ x+4*h∈B ∧ x+2*k∈B ∧ (x+t')/4∈quarterD n B ∧ (x+t)/2∉emptyPairs n B
instance (n t t' h k x:ℕ) (B:Finset ℕ):Decidable (oddTests n t t' h k x B):=
  inferInstanceAs (Decidable (x∈B ∧ x+4*h∈B ∧ x+2*k∈B ∧ (x+t')/4∈quarterD n B ∧ (x+t)/2∉emptyPairs n B))

private theorem base_bounds {H m t t' x:ℕ} (hx:x∈oddBases H m t') (hm:3*m≤H)
    (ht:t≤ m) (ht':t'≤ m) (ho:t%2=1) (ho':t'%2=1) (hd:t%4≠t'%4) :
    H/2<x ∧ x+m≤H ∧ x%8=(12-t'%8)%8 ∧ x%4=t%4 ∧ (x+t')%8=4 ∧
    2*((x+t)/2)=x+t ∧ (x+t)/2%2=1 ∧ H/4<(x+t)/2 ∧ (x+t)/2≤H/2 := by
  obtain ⟨hI,hr⟩:=mem_filter.mp hx;have hI':=mem_Ioc.mp hI
  omega

theorem odd_base_alternative {n t t' h k s m x:ℕ} {B:Finset ℕ}
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {t,t',4*h,2*k}))
    (hm:3*m≤n/4) (hm₀:∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤ m)
    (ho:t%2=1) (ho':t'%2=1) (hd:t%4≠t'%4)
    (hx:x∈oddBases (n/4) m t') (hc:oddTests n t t' h k x B) :
    (x+t)/2∈B ∨
      (InternalFive (B∩Icc 1 (n/4)) (insert x {t,t',4*h,2*k}) ∧
        x%4=t%4 ∧ ∀z∈({t,t',4*h,2*k}:Finset ℕ),z<x) := by
  classical
  obtain ⟨h₁,h₂,hr,hx4,hs8,heq,hp,hlo,hhi⟩:=base_bounds hx hm
    (hm₀ t (by simp)) (hm₀ t' (by simp)) ho ho' hd
  by_cases hh:(x+t)/2∈B
  · exact Or.inl hh
  right
  have he : x+t∈B:=by
    rw [←heq];apply (show ∀p:ℕ,0<p→p%2=1→2*p≤n→p∉emptyPairs n B→p∉B→2*p∈B from by
      intro p h1 ho h2 hm ha
      by_contra h;
      exact hm (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨h1,by omega⟩,ho⟩,h2,ha,h⟩))
    all_goals first | assumption | exact hc.2.2.2.2 | omega
  have hs': x+t'∈B:=by
    have hroot:=(mem_filter.mp hc.2.2.2.1).2
    rwa [show 4*((x+t')/4)=x+t' by omega] at hroot
  have sep:∀z∈({t,t',4*h,2*k}:Finset ℕ),z<x:=by intro z hz;have :=hm₀ z hz;omega
  refine ⟨replace_fifth hs (by have :=card_insert_le t ({t',4*h,2*k}:Finset ℕ);
                                 have :=@card_le_three ℕ _ t' (4*h) (2*k);omega)
        (mem_inter.mpr ⟨hc.1,mem_Icc.mpr ⟨by omega,by omega⟩⟩) sep ?_,hx4,sep⟩
  intro z hz;have :=hm₀ z hz
  apply mem_inter.mpr;refine ⟨?_,mem_Icc.mpr ⟨by omega,by omega⟩⟩
  simp only [mem_insert,mem_singleton] at hz
  rcases hz with rfl|rfl|rfl|rfl
  · exact he
  · exact hs'
  · exact hc.2.1
  · exact hc.2.2.1

theorem odd_base_failures {n t t' h k m:ℕ} {B:Finset ℕ} (hB:DoublingFree B)
    (ho:t%2=1) (ho':t'%2=1) (hd:t%4≠t'%4) (hk:k%2=1)
    (hm:3*m≤n/4) (ht:t≤ m) (ht':t'≤ m) (hh:4*h≤ m) (hk':2*k≤ m) :
    ((oddBases (n/4) m t').filter (fun x=>¬oddTests n t t' h k x B)).card ≤
      A_loss n B+2*T_loss n B+G_loss n B := by
  classical
  let X:=oddBases (n/4) m t'
  let O:Finset ℕ:={0,4*h,2*k}
  let T:=absentTop n B
  let G:=passes X O B
  let F:=X.filter (fun x=>¬oddTests n t t' h k x B)
  let A:=emptyOuter (n/4/4) (quarterD n B)
  let J:=gapOriginal n B
  let Root:=A.image (fun r=>4*r-t')
  let Slot:=J.image (fun r=>2*r-t)
  have hhx x (hx:x∈X):=base_bounds hx hm ht ht' ho ho' hd
  have htload:=shift_losses X O B T 4 (t%4) 2
    (fun x hx=>(hhx x hx).2.2.2.1)
    (by
      intro x hx z hz hn
      have hh₀:=hhx x hx
      change z∈({0,4*h,2*k}:Finset ℕ) at hz
      simp only [mem_insert,mem_singleton] at hz
      rcases hz with rfl|rfl|rfl <;> exact mem_filter.mpr
        ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,hn⟩)
    (by
      intro z hz
      by_cases hres:t%4=z%4
      · apply le_trans (card_le_card (t:={0,4*h}) _) card_le_two
        intro u hu;obtain ⟨hu,hmod⟩:=mem_filter.mp hu
        simp only [O,mem_insert,mem_singleton] at hu ⊢
        rcases hu with rfl|rfl|rfl <;> first | tauto | omega
      · apply le_trans (card_le_card (t:={2*k}) _) (by simp)
        intro u hu;obtain ⟨hu,hmod⟩:=mem_filter.mp hu
        simp only [O,mem_insert,mem_singleton] at hu ⊢
        rcases hu with rfl|rfl|rfl <;> first | rfl | omega)
  have hGS:G⊆X:=filter_subset _ _
  have hpart:=card_sdiff_add_card_eq_card hGS
  have hc:(X\G).card≤2*T.card:=by change X.card≤G.card+2*T.card at htload;omega
  have hsub:F⊆(X\G)∪Root∪Slot:=by
    intro x hx
    obtain ⟨hx,hn⟩:=mem_filter.mp hx
    have hhx':=hhx x hx
    by_cases hg:x∈G
    · have hpass:=(mem_filter.mp hg).2
      by_cases hroot:(x+t')/4∈quarterD n B
      · apply mem_union_right;apply mem_image.mpr
        have he:(x+t)/2∈emptyPairs n B := by
          by_contra hq
          exact hn ⟨by simpa using hpass 0 (by simp [O]),hpass _ (by simp [O]),hpass _ (by simp [O]),hroot,hq⟩
        exact ⟨(x+t)/2,mem_filter.mpr ⟨he,by omega,by omega⟩,by omega⟩
      · apply mem_union_left;apply mem_union_right;apply mem_image.mpr
        exact ⟨(x+t')/4,absent_quarter_root (by omega) (by omega) (by omega) hroot,by omega⟩
    · exact mem_union_left _ (mem_union_left _ (mem_sdiff.mpr ⟨hx,hg⟩))
  have hbound:=card_le_card hsub
  have h1:=card_union_le (X\G) Root
  have h2:=card_union_le ((X\G)∪Root) Slot
  have hA:Root.card≤A.card:=card_image_le
  have hJ:Slot.card≤J.card:=card_image_le
  have hT:T.card≤T_loss n B:=absent_top_cost n B hB
  change F.card≤A.card+2*T_loss n B+J.card;omega

end OP02.SharpK7

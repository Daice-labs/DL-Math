import SmallExcessCore
import RetainedS1
import RetainedS3

open Finset
namespace OP02.SmallExcess

theorem lower_card_eq (n : ℕ) (B : Finset ℕ) :
    (OP02.FewHole.lower n B).card = (residueR n B).card + (quarterD n B).card := by
  classical
  let L := OP02.FewHole.lower n B
  let Z := L.filter (fun x => x % 4 = 0)
  let R := residueR n B
  let D := quarterD n B
  have hDcard : D.card = Z.card := by
    refine Finset.card_bij (fun x _ => 4*x) ?_ ?_ ?_
    · intro x hx
      obtain ⟨hxI,hxB⟩ := Finset.mem_filter.mp hx
      obtain ⟨hx1,hxn⟩ := Finset.mem_Icc.mp hxI
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_inter.mpr ⟨hxB,Finset.mem_Icc.mpr ⟨by omega,by omega⟩⟩,by omega⟩
    · intro x hx y hy hxy
      omega
    · intro y hy
      obtain ⟨hyL,hy4⟩ := Finset.mem_filter.mp hy
      obtain ⟨hyB,hyI⟩ := Finset.mem_inter.mp hyL
      obtain ⟨hy1,hyn⟩ := Finset.mem_Icc.mp hyI
      refine ⟨y/4,?_,by omega⟩
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_Icc.mpr ⟨by omega,by omega⟩,?_⟩
      have heq : 4*(y/4)=y := by omega
      rwa [heq]
  have hpartition : L = Z ∪ R := by
    ext x
    simp only [Z,R,residueR,L,Finset.mem_union,Finset.mem_filter]
    tauto
  have hdis : Disjoint Z R := by
    apply Finset.disjoint_left.mpr
    intro x hz hr
    exact (Finset.mem_filter.mp hr).2 (Finset.mem_filter.mp hz).2
  have hc : L.card = Z.card + R.card := by
    rw [hpartition,Finset.card_union_of_disjoint hdis]
  change L.card = R.card + D.card
  omega

/-- The next proof obligation. C must be a single constant independent of n and B. -/
def SmallExcessGoal : Prop :=
  ∃ C : ℕ, ∀ n : ℕ, 1 ≤ n → ∀ B : Finset ℕ,
    B ⊆ Icc 1 (4*n) → OP02.FewHole.FourFree B → OP02.FewHole.DoublingFree B →
    n ≤ 4*(OP02.FewHole.holes n B).card →
    32*(OP02.FewHole.excessHoles n B).card < n →
    8*((residueR n B).card+(quarterD n B).card) ≤
      5*n+8*(OP02.FewHole.excessHoles n B).card+C

theorem tradeoff_iff_count (n C : ℕ) (B : Finset ℕ)
    (hsub : B ⊆ Icc 1 (4*n)) (hdbl : OP02.FewHole.DoublingFree B) :
    (8*((residueR n B).card+(quarterD n B).card) ≤
      5*n+8*(OP02.FewHole.excessHoles n B).card+C) ↔
    8*B.card ≤ 21*n+C := by
  have hc := OP02.FewHole.counting_identity n B hsub hdbl
  have hp := lower_card_eq n B
  omega

/-- No induction or additional analytic hypothesis: combine the two excess branches. -/
theorem large_hole_of_small_excess (h : SmallExcessGoal) : OP02.Frontier.LargeHoleGoal := by
  obtain ⟨C,hC⟩ := h
  refine ⟨max C 57,?_⟩
  intro n hn B hsub hfour hdbl hlarge
  have hcmax : C ≤ max C 57 := le_max_left _ _
  have h57max : 57 ≤ max C 57 := le_max_right _ _
  by_cases he : n ≤ 32*(OP02.FewHole.excessHoles n B).card
  · have hbig := OP02ReviewedS1.result n B hn hsub hfour hdbl hlarge he
    omega
  · have hsmall : 32*(OP02.FewHole.excessHoles n B).card < n := by omega
    have ht := hC n hn B hsub hfour hdbl hlarge hsmall
    have hbound := (tradeoff_iff_count n C B hsub hdbl).mp ht
    omega

/-- This does not prove SmallExcessGoal or Dousse4. Both remain visible hypotheses. -/
theorem k4_of_small_excess_and_dousse
    (hsmall : SmallExcessGoal) (hD : OP02.Frontier.Dousse4) : OP02.K4Goal :=
  OP02ReviewedS3.result hD (large_hole_of_small_excess hsmall)

end OP02.SmallExcess

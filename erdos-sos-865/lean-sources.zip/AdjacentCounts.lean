import PositiveWindow
open Finset
namespace OP02.EdgeBand
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot

def missOdd (n:ℕ) (B:Finset ℕ):=oddPos n\parityMiddle n B 1
def highOdd (n:ℕ) (B:Finset ℕ):=(Ho n B).filter (fun h=>3*n<h)
def lowOdd (n:ℕ) (B:Finset ℕ):=(Ho n B).filter (fun h=>h≤3*n)
def clipOdd (n p:ℕ):=(oddPos n).filter (fun z=>4*n<p+z+2)
def goodAdjacent (n p:ℕ) (Q B:Finset ℕ):=(oddPos n).filter
  (fun z=>z∈B ∧ z+2∈B ∧ z+1∉Q ∧ p+z+2≤4*n ∧ p+z∈B ∧ p+z+2∈B)

theorem missOdd_card (n:ℕ) (B:Finset ℕ):
    (missOdd n B).card+(parityMiddle n B 1).card=n/2 := by
  have hs:parityMiddle n B 1⊆oddPos n := by
    intro z hz
    obtain ⟨hzM,hzo⟩:=mem_filter.mp hz
    have hi:=mem_Icc.mp (mem_inter.mp hzM).2
    exact oddPos_mem.mpr ⟨by omega,hi.2,hzo⟩
  have h:=card_sdiff_add_card_eq_card hs
  rw [oddPos_card] at h
  exact h

theorem odd_hole_partition (n:ℕ) (B:Finset ℕ):
    (highOdd n B).card+(lowOdd n B).card=(Ho n B).card := by
  have hu:highOdd n B∪lowOdd n B=Ho n B := by
    ext x;simp only [highOdd,lowOdd,mem_union,mem_filter]
    constructor
    · rintro (⟨h,_⟩|⟨h,_⟩) <;> exact h
    · intro h
      by_cases hx:3*n<x
      · exact Or.inl ⟨h,hx⟩
      · exact Or.inr ⟨h,by omega⟩
  have hd:Disjoint (highOdd n B) (lowOdd n B) := by
    apply disjoint_left.mpr
    intro x hx hy
    have :=(mem_filter.mp hx).2
    have :=(mem_filter.mp hy).2
    omega
  have h:=card_union_of_disjoint hd
  rw [hu] at h
  omega

theorem clip_count (n p r:ℕ) (hp:p≤2*n+4*r+4) :
    (clipOdd n p).card≤2*r+3 := by
  have hi:Set.InjOn (fun z:ℕ=>(2*n-1-z)/2) (clipOdd n p) := by
    intro x hx y hy he
    have hxI:=oddPos_mem.mp (mem_filter.mp hx).1
    have hyI:=oddPos_mem.mp (mem_filter.mp hy).1
    dsimp only at he;omega
  have hs:(clipOdd n p).image (fun z=>(2*n-1-z)/2)⊆range (2*r+3) := by
    intro x hx;obtain ⟨z,hz,rfl⟩:=mem_image.mp hx
    have hzI:=oddPos_mem.mp (mem_filter.mp hz).1
    have hzC:=(mem_filter.mp hz).2
    apply mem_range.mpr;omega
  have hc:=card_le_card hs
  rw [card_image_of_injOn hi,card_range] at hc
  exact hc

theorem clip_residue_count (n p r j:ℕ) (hp:p≤2*n+4*r+4) :
    ((clipOdd n p).filter (fun z=>z%4=j)).card≤r+2 := by
  let C:=(clipOdd n p).filter (fun z=>z%4=j)
  have hi:Set.InjOn (fun z:ℕ=>(2*n-1-z)/4) C := by
    intro x hx y hy he
    have hxR:=(mem_filter.mp hx).2
    have hyR:=(mem_filter.mp hy).2
    have hxI:=oddPos_mem.mp (mem_filter.mp (mem_filter.mp hx).1).1
    have hyI:=oddPos_mem.mp (mem_filter.mp (mem_filter.mp hy).1).1
    dsimp only at he;omega
  have hs:C.image (fun z=>(2*n-1-z)/4)⊆range (r+2) := by
    intro x hx;obtain ⟨z,hz,rfl⟩:=mem_image.mp hx
    have hzI:=oddPos_mem.mp (mem_filter.mp (mem_filter.mp hz).1).1
    have hzC:=(mem_filter.mp (mem_filter.mp hz).1).2
    apply mem_range.mpr;omega
  have hc:=card_le_card hs
  rw [card_image_of_injOn hi,card_range] at hc
  exact hc

theorem odd_residue_lower (n j:ℕ) (hj:j=1 ∨ j=3) :
    n/4≤((oddPos n).filter (fun z=>z%4=j)).card := by
  let a:=n+1+n%2
  let b:=if a%4=j then 0 else 1
  have hb:b≤1:=by dsimp [b];split_ifs <;> omega
  have hab:(a+2*b)%4=j := by
    dsimp [a,b];split_ifs <;> rcases hj with rfl|rfl <;> omega
  have hi:Function.Injective (fun i:ℕ=>a+2*b+4*i):=by intro x y h;dsimp only at h;omega
  have hs:(range (n/4)).image (fun i=>a+2*b+4*i)⊆(oddPos n).filter (fun z=>z%4=j) := by
    intro z hz;obtain ⟨i,hi,rfl⟩:=mem_image.mp hz
    have hr:=mem_range.mp hi
    apply mem_filter.mpr
    constructor
    · apply oddPos_mem.mpr
      dsimp [a] at *
      rcases hj with rfl|rfl <;> omega
    · omega
  have hc:=card_le_card hs
  rw [card_image_of_injective _ hi,card_range] at hc
  exact hc

/-- A failed usable start has an actual missing endpoint, central parent, high hole, or clipping. -/
theorem adjacent_failure {n p z:ℕ} {Q B:Finset ℕ} (hp:2*n<p) (hpe:p%2=0)
    (hz:z∈oddPos n) (hnot:z∉goodAdjacent n p Q B) :
    (z∈missOdd n B ∨ z+2∈missOdd n B) ∨ z+1∈Q ∨
    (p+z∈highOdd n B ∨ p+z+2∈highOdd n B) ∨ z∈clipOdd n p := by
  have hzI:=oddPos_mem.mp hz
  by_cases hclip:4*n<p+z+2
  · exact Or.inr (Or.inr (Or.inr (mem_filter.mpr ⟨hz,hclip⟩)))
  have hr:p+z+2≤4*n:=by omega
  have hz2:z+2∈oddPos n:=oddPos_mem.mpr ⟨by omega,by omega,by omega⟩
  have hmiss:∀w∈oddPos n,w∉B→w∈missOdd n B := by
    intro w hw hwB
    exact mem_sdiff.mpr ⟨hw,by intro h;exact hwB (mem_inter.mp (mem_filter.mp h).1).1⟩
  by_cases hzB:z∈B
  · by_cases hz2B:z+2∈B
    · by_cases hQ:z+1∈Q
      · exact Or.inr (Or.inl hQ)
      · have hh:∀w,3*n<w→w≤4*n→w%2=1→w∉B→w∈highOdd n B := by
          intro w hw hwu hwo hwB
          apply mem_filter.mpr
          refine ⟨?_,hw⟩
          apply mem_filter.mpr
          refine ⟨?_,hwo⟩
          rcases missing_split (n:=n) (by omega) hwB with hd|he
          · obtain ⟨v,hv,hve⟩:=hd;omega
          · exact he
        by_cases hpz:p+z∈B
        · by_cases hpz2:p+z+2∈B
          · exact False.elim (hnot (mem_filter.mpr ⟨hz,hzB,hz2B,hQ,hr,hpz,hpz2⟩))
          · exact Or.inr (Or.inr (Or.inl (Or.inr (hh _ (by omega) hr (by omega) hpz2))))
        · exact Or.inr (Or.inr (Or.inl (Or.inl (hh _ (by omega) (by omega) (by omega) hpz))))
    · exact Or.inl (Or.inr (hmiss _ hz2 hz2B))
  · exact Or.inl (Or.inl (hmiss _ hz hzB))


#print axioms adjacent_failure
end OP02.EdgeBand

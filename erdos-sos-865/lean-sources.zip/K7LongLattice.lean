import K7LongGeometry
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

/-- At one physical support, every largest actual even sum is the same element. -/
theorem many_retained_at_max {β:ℝ} {n e:ℕ} {B:Finset ℕ} (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (sc:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (he:e∈smallSupport n B) (he₂:e%2=0) (maximum:∀x∈smallSupport n B,x%2=0→x≤e) :
    ∃w∈rigidPresent (n/4/64) (quarterD n B),
      lambdaBudget n B<(retainedEndpoints n B e (4*w)).card := by
  obtain ⟨d,hdS,dpar,hmax,w,hw,hj⟩:=many_retained β n B hd hg sc hl
  have same:d=e:=Nat.le_antisymm (maximum d hdS dpar) (hmax e he he₂)
  exact same ▸ (show ∃w∈rigidPresent (n/4/64) (quarterD n B),
    lambdaBudget n B<(retainedEndpoints n B d (4*w)).card from ⟨w,hw,hj⟩)

/-- The half at H/2 uses the original forcing tests. Strictly larger tested
halves are tested directly in the upper physical membership set. -/
theorem interpolate_long_window {β:ℝ} {n s t t' h k:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {t,t',4*h,2*k}))
    (sc:16384≤n/4/64) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (ho:t%2=1) (ho':t'%2=1) (opp:t%4≠t'%4) (ko:k%2=1)
    (largest:∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤t)
    (ht:17*(n/4/64)<t) (hi:3*t<n/4) (loss:LossBound n B t)
    {e:ℕ} (he:e∈smallSupport n B) (he₂:e%2=0) (hmax:∀x∈smallSupport n B,x%2=0→x≤e) :
    oddReplacement n t t' h k B ∨ qualifiedJ0 n B := by
  classical
  by_cases repl:oddReplacement n t t' h k B
  · exact Or.inl repl
  right
  let H:=n/4
  let N:=H/64
  let R:=(12-t'%8)%8
  let A₀:=A_loss n B
  let T:=T_loss n B
  let K:=A₀+3*T+2
  let Y:=progression (H/2) (H-t-16*K) 8 R
  let I:=Y.image (fun x:ℕ=>((x/8:ℕ):ℤ))
  let p₀:ℤ:=((R+t)/2:ℕ)
  have rlt:R<8:=by dsimp [R];omega
  have rpar:R%2=1 ∧ (R+t)%4=2:=by dsimp [R];omega
  have scale:64≤n/4:=by omega
  have supply:=signed_units hd hg scale hl
  have large:6*lambdaBudget n B+6000<N:=by change _<n/4/64;omega
  have inv:=common_inventory n B
  obtain ⟨w,hw,hj⟩:=many_retained_at_max hd hg scale hl he he₂ hmax
  let A:=retainedEndpoints n B e (4*w)
  let U:=latticeBad H B p₀ e I (A.image (fun a:ℕ=>(a:ℤ)))
  let V:=latticeVeto H B p₀ (4*w) I
  have strict:=long_width (H:=H) (N:=N) (t:=t) (a:=A₀) (T:=T) (G:=G_loss n B)
    (j:=A.card) rfl sc ht hi large inv hj rlt loss
  have ht':=largest t' (by simp)
  have hh:=largest (4*h) (by simp)
  have hk:=largest (2*k) (by simp)
  have lowerFail:=odd_base_failures hd ho ho' opp ko (by omega : 3*t≤n/4) (le_refl t) ht' hh hk
  have ydat {x:ℕ} (hx:x∈Y):H/2<x ∧ x≤H-t-16*K ∧ x%8=R := by
    obtain ⟨hI,hr⟩:=mem_filter.mp hx
    exact ⟨(mem_Ioc.mp hI).1,(mem_Ioc.mp hI).2,hr⟩
  have bas {x:ℕ} (hx:x∈Y) : 2*((x+t)/2)=x+t ∧ (x+t)/2%2=1 ∧
      3*H≤8*((x+t)/2) ∧ 2*((x+t)/2)+16*K≤H ∧
      (((x+t)/2:ℕ):ℤ)=p₀+4*((x/8:ℕ):ℤ) := by
    have h:=ydat hx
    have HT:17*N<t:=ht
    have NS:16384≤N:=sc
    have rem:H=64*N+H%64:=by dsimp [N];omega
    dsimp only [p₀];omega
  have hIc:I.card=Y.card:=by
    apply card_image_of_injOn;intro x hx u hu eq
    have h₁:=ydat hx;have h₂:=ydat hu
    change ((x/8:ℕ):ℤ)=((u/8:ℕ):ℤ) at eq
    omega
  let Dlo:=(oddBases H t t').filter (fun x=>¬oddTests n t t' h k x B)
  let Dhi:=absentTop n B
  have cover:U⊆(Dlo.image (fun v:ℕ=>((v/8:ℕ):ℤ))) ∪
      (Dhi.image (fun p:ℕ=>((p:ℤ)-p₀)/4)) := by
    intro g hgU
    obtain ⟨tested,missing⟩:=mem_filter.mp hgU
    obtain ⟨x,hx,d,hdN,hg'⟩:=represented_index tested
    have xdat:=ydat hx
    have props:=bas hx
    let v:=x+8*d
    let p:=(x+t)/2+4*d
    have eqp:(p:ℤ)=p₀+4*g:=by dsimp [p];omega
    have eqv:((v/8:ℕ):ℤ)=g:=by dsimp [v];omega
    have sym:2*p=v+t:=by dsimp [p,v];omega
    have op:p%2=1:=by dsimp [p];omega
    have hhlo:1≤p:=by dsimp [p];omega
    have hhup:p≤H:=by
      have hDN:d≤N:=hdN
      have h64:64*N≤H:=by dsimp [N];omega
      dsimp [p];omega
    have absent:p∉B:=fun hp => missing
      (mem_image.mpr ⟨p,mem_inter.mpr ⟨hp,mem_Icc.mpr ⟨hhlo,hhup⟩⟩,eqp⟩)
    by_cases seam:2*p≤H
    · apply mem_union_left;apply mem_image.mpr;refine ⟨v,?_,eqv⟩
      have vdom:v∈oddBases H t t':=by
        apply mem_filter.mpr
        exact ⟨mem_Ioc.mpr ⟨by dsimp [v];omega,by omega⟩,by change v%8=R;dsimp [v];omega⟩
      apply mem_filter.mpr;refine ⟨vdom,?_⟩;intro tests
      rcases odd_base_alternative hs (Nat.le_of_lt hi) largest ho ho' opp vdom tests with occ|replace
      · exact absent (by rwa [show (v+t)/2=p by omega] at occ)
      · exact repl ⟨v,vdom,replace⟩
    · apply mem_union_right;apply mem_image.mpr
      exact ⟨p,mem_filter.mpr ⟨mem_Ioc.mpr ⟨by change H/2<p;omega,hhup⟩,op,absent⟩,by omega⟩
  have upperFail:Dhi.card≤T:=absent_top_cost n B hd
  have lowerCount:Dlo.card≤A₀+2*T+G_loss n B:=lowerFail
  have sizeU:U.card≤A₀+3*T+G_loss n B:=by
    have ξ:=(card_le_card cover).trans (card_union_le _ _)
    have f:(Dlo.image (fun v:ℕ=>((v/8:ℕ):ℤ))).card≤Dlo.card:=card_image_le
    have g:(Dhi.image (fun p:ℕ=>((p:ℤ)-p₀)/4)).card≤Dhi.card:=card_image_le
    omega
  have bbounds:=rigid_bounds (mem_filter.mp hw).1
  have sizeV:V.card≤T:=by
    apply le_trans _ upperFail
    apply card_le_card_of_injOn (fun g:ℤ=>(p₀+4*g+16*w).toNat)
    · intro g hgV
      obtain ⟨hgI,absent⟩:=mem_filter.mp hgV
      obtain ⟨x,hx,eq⟩:=mem_image.mp hgI
      have props:=bas hx
      have wb:N/2<w ∧ w≤(3*N+1)/4:=⟨bbounds.1,bbounds.2.1⟩
      have rhs:(p₀+4*g+16*w).toNat=(x+t)/2+16*w:=by omega
      have rem:H=64*N+H%64:=by dsimp [N];omega
      change (p₀+4*g+16*w).toNat∈Dhi
      rw [rhs];apply mem_filter.mpr
      have htop:H/2<(x+t)/2+16*w ∧ (x+t)/2+16*w≤H:=by omega
      refine ⟨mem_Ioc.mpr htop,by omega,?_⟩
      intro present
      apply absent;apply mem_image.mpr
      exact ⟨(x+t)/2+16*w,mem_inter.mpr ⟨present,mem_Icc.mpr ⟨by omega,htop.2⟩⟩,by omega⟩
    · intro i hi' j hj' equal
      obtain ⟨x,hx,ei⟩:=mem_image.mp (mem_filter.mp hi').1
      obtain ⟨z,hz,ej⟩:=mem_image.mp (mem_filter.mp hj').1
      have a:=bas hx;have c:=bas hz
      change (p₀+4*i+16*w).toNat=(p₀+4*j+16*w).toNat at equal
      omega
  apply qualified_j0_on_window hd hg scale hl he he₂ hw hj p₀ I
  · change (V.card:ℤ)+max (U.card:ℤ) (3*(U.card:ℤ)-2*(A.card:ℤ)+2)<(I.card:ℤ)
    change _<((Y.card:ℕ):ℤ) at strict
    rw [hIc];omega
  · intro g hgI
    obtain ⟨x,hx,eq⟩:=mem_image.mp hgI
    have props:=bas hx
    exact ⟨(x+t)/2,by omega,props.2.1,props.2.2.1,by change 2*((x+t)/2)≤H;omega,
      paid_partner_width (H:=H) (p:=(x+t)/2) (a:=A₀) (T:=T) props.2.2.2.1⟩

end OP02.SharpK7.LongOddTask

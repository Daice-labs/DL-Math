import K8UpperSixComplement
import K8UpperSixProfiles
import K8Budget

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8

theorem complement_full_class {H : ℕ} {D F : Finset ℕ}
    (hscale : 4096≤H) (hD : D⊆Icc 1 H) (hd : DoublingFree D)
    (hb : 1536*(chainCapacity H-D.card)<H)
    (h4 : ¬CentralFour H D) (ho : ¬CentralOdd H D) (hF : ShortFive H D F)
    (full : ∀j<4, ∃x∈insert 0 F, x%4=j) : RootSix H D := by
  obtain ⟨w,hw,b,hbO,hwb,wsmall,single,rest⟩ := complement_small_singleton hF full
  let r4 := (6-w%4)%4
  let r := if (r4+b)%8=0 then r4+4 else r4
  have r4lt : r4<4 := Nat.mod_lt _ (by decide)
  have rlt : r<8 := by dsimp only [r]; split_ifs <;> omega
  let L := 648*H/1024-w
  let U := 696*H/1024-w
  let Y := progression L U 8 r
  have data {R} (hR : R∈Y) :
      648*H < 1024*(R+w) ∧ 1024*(R+w)≤696*H ∧
      (R+w)%4=2 ∧ ((R+b)%4=0 → (R+b)%8=4) := by
    obtain ⟨hI,hres⟩ := mem_filter.mp hR
    obtain ⟨lo,hi⟩ := mem_Ioc.mp hI
    dsimp only [L,U] at lo hi
    dsimp only [r,r4] at hres
    split_ifs at hres <;> omega
  apply upper_six_from_trials (Y:=Y) (E:=complementFaults H D) hF
  · intro R hR; have := data hR; omega
  · intro R hR s hs hmiss
    obtain ⟨hl,hu,hp,hbguard⟩ := data hR
    have hsH : s≤H/4 := by
      rcases mem_insert.mp hs with rfl|h
      · omega
      · exact (mem_Icc.mp (mem_inter.mp (hF.1.1 h)).2).2
    apply complement_upper_hole h4 ho (by omega) (by omega) hmiss
    by_cases hodd : (R+s)%2=1
    · exact Or.inl hodd
    by_cases htwo : (R+s)%4=2
    · have he := single s hs (by omega)
      subst s
      exact Or.inr (Or.inr (Or.inr ⟨htwo,by omega,hu⟩))
    have hzero : (R+s)%4=0 := by omega
    by_cases eqb : s=b
    · subst s
      exact Or.inr (Or.inl (hbguard hzero))
    have sm := rest s hs eqb
    exact Or.inr (Or.inr (Or.inl ⟨hzero,by omega,by omega⟩))
  · have hc := complement_fault_budget hD hd
    have hcount := progression_lower L U 8 r (by decide) rlt
    change (U-L)/8 ≤ Y.card at hcount
    dsimp only [L,U] at hcount
    omega

/-- Both complementary-window profile branches, with one original set, one
candidate and all fifteen root edges. The five may be prescribed. -/
theorem complement_of_upper_central_gaps {H : ℕ} {D F : Finset ℕ}
    (hscale : 4096≤H) (hD : D⊆Icc 1 H) (hd : DoublingFree D)
    (hb : 1536*(chainCapacity H-D.card)<H)
    (h4 : ¬CentralFour H D) (ho : ¬CentralOdd H D) (hF : ShortFive H D F) :
    RootSix H D := by
  classical
  by_cases emp : ∃j<4, ∀s∈insert 0 F, s%4≠j
  · obtain ⟨a,ha,he⟩ := emp
    exact complement_empty_class hscale hD hd hb h4 ho hF ha he
  · push_neg at emp
    exact complement_full_class hscale hD hd hb h4 ho hF emp

/-- Uniform signed assumptions yield the complete complement without a
population premise and before any choice of finite set or seed. -/
theorem signed_complement_upper_six {β : ℝ} (hb : 0<β) :
    ∃ M : ℕ, ∀ n : ℕ, M≤n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
     ¬CentralFour (n/4) (quarterD n B) → ¬CentralOdd (n/4) (quarterD n B) →
     ∀F : Finset ℕ, ShortFive (n/4) (quarterD n B) F → RootSix (n/4) (quarterD n B) := by
  obtain ⟨U,hU⟩ := strict_capacity hb
  refine ⟨max U 16384,?_⟩
  intro n hn B hd hg h4 ho F hF
  have hcap := hU n (by omega) B hd hg
  unfold chainDeficit at hcap
  exact complement_of_upper_central_gaps (by omega) (filter_subset _ _) (quarter_doubling_free n B hd)
    (by omega) h4 ho hF

end OP02.SharpK8

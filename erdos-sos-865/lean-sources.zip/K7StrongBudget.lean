import K7RowOne
import K7Dousse
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PositivePivot
namespace OP02.SharpK7

/-- A six-clique of quarter roots has six scaled physical vertices. An odd pivot
in (2n,3n] extends it unless seven translates exhaust the upper odd holes. -/
theorem quarter_six_free (n : ℕ) (B : Finset ℕ)
    (hseven : SevenFree B) (hsmall : 14*(Ho n B).card<n) :
    OP02.SharpK6.SixFree (quarterD n B) := by
  classical
  let E := Ho n B
  let D := quarterD n B
  have he : ¬n≤14*E.card := by dsimp [E]; omega
  have hDfree : OP02.SharpK6.SixFree D := by
    rintro ⟨S0,hS0,hS0c,hS0pair⟩
    let S := S0.image (fun x=>4*x)
    have hSc : S.card=6 := by
      have hinj : Function.Injective (fun x:ℕ=>4*x) := by intro x y h; change 4*x=4*y at h; omega
      rw [card_image_of_injective _ hinj,hS0c]
    have hS : S⊆Icc 1 n := by
      intro x hx
      obtain ⟨r,hr,rfl⟩ := mem_image.mp hx
      have hr := mem_Icc.mp (mem_filter.mp (hS0 hr)).1
      exact mem_Icc.mpr ⟨by omega,by omega⟩
    have hSB : S⊆B := by
      intro x hx
      obtain ⟨r,hr,rfl⟩ := mem_image.mp hx
      exact (mem_filter.mp (hS0 hr)).2
    have hEven : ∀x∈S,x%2=0 := by
      intro x hx
      obtain ⟨r,hr,rfl⟩ := mem_image.mp hx
      omega
    have hpair : ∀x∈S,∀y∈S,x≠y→x+y∈B := by
      intro x hx y hy hxy
      obtain ⟨r,hr,rfl⟩ := mem_image.mp hx
      obtain ⟨s,hs,rfl⟩ := mem_image.mp hy
      have hrs : r≠s := by omega
      have hh := (mem_filter.mp (hS0pair r hr s hs hrs)).2
      simpa only [Nat.mul_add] using hh
    have hzero : (0 : ℕ) ∉ S := by
      intro hz
      have hzI := Finset.mem_Icc.mp (hS hz)
      omega
    let U : Finset ℕ := insert 0 S
    have hUc : U.card = 7 := by simp [U, hzero, hSc]
    let J : Finset ℕ := Finset.Icc 1 ((n + 1) / 2)
    have oddHole (z : ℕ) (hz1 : 2 * n + 1 ≤ z) (hz4 : z ≤ 4 * n)
        (hzodd : z % 2 = 1) (hzB : z ∉ B) : z ∈ E := by
      apply mem_filter.mpr
      refine ⟨?_,hzodd⟩
      change z ∈ (Icc (2*n+1) (4*n) \ B) \ (middle n B).image (fun x=>2*x)
      refine mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨hz1,hz4⟩,hzB⟩,?_⟩
      intro hz
      obtain ⟨q,hq,hqz⟩ := mem_image.mp hz
      omega
    have hcover : ∀ j ∈ J, ∃ u ∈ U, (2 * n + 2 * j - 1) + u ∈ E := by
      intro j hj
      have hjI : j ∈ Finset.Icc 1 ((n + 1) / 2) := hj
      obtain ⟨hj1, hj2⟩ := Finset.mem_Icc.mp hjI
      let p : ℕ := 2 * n + 2 * j - 1
      have hp1 : 2 * n + 1 ≤ p := by dsimp [p]; omega
      have hp3 : p ≤ 3 * n := by dsimp [p]; omega
      have hpodd : p % 2 = 1 := by dsimp [p]; omega
      have hno : ¬ (p ∈ B ∧ ∀ x ∈ S, p + x ∈ B) := by
        rintro ⟨hpB, hsum⟩
        have hpS : p ∉ S := by
          intro hp
          have hpI := Finset.mem_Icc.mp (hS hp)
          omega
        apply hseven
        refine ⟨insert p S, Finset.insert_subset hpB hSB, ?_, ?_⟩
        · simp [hpS, hSc]
        · intro x hx y hy hxy
          rcases Finset.mem_insert.mp hx with hxp | hxS
          · subst x
            rcases Finset.mem_insert.mp hy with hyp | hyS
            · exact (hxy hyp.symm).elim
            · exact hsum y hyS
          · rcases Finset.mem_insert.mp hy with hyp | hyS
            · subst y
              simpa [add_comm] using hsum x hxS
            · exact hpair x hxS y hyS hxy
      by_cases hpB : p ∈ B
      · by_cases hlink : ∀ x ∈ S, p + x ∈ B
        · exact False.elim (hno ⟨hpB, hlink⟩)
        · push Not at hlink
          obtain ⟨x, hx, hpx⟩ := hlink
          have hxb := Finset.mem_Icc.mp (hS hx)
          have hxe := hEven x hx
          refine ⟨x, ?_, ?_⟩
          · change x ∈ insert 0 S
            exact Finset.mem_insert_of_mem hx
          · change p + x ∈ E
            exact oddHole (p + x) (by omega) (by omega) (by omega) hpx
      · refine ⟨0, ?_, ?_⟩
        · simp [U]
        · change p + 0 ∈ E
          simpa only [Nat.add_zero] using oddHole p hp1 (by omega) hpodd hpB
    have hJsub : J ⊆ (U.product E).image
        (fun z : ℕ × ℕ => (z.2 - z.1 - 2 * n + 1) / 2) := by
      intro j hj
      obtain ⟨u, hu, hzu⟩ := hcover j hj
      refine Finset.mem_image.mpr
        ⟨(u, (2 * n + 2 * j - 1) + u),
          Finset.mem_product.mpr ⟨hu, hzu⟩, ?_⟩
      have hj1 := (Finset.mem_Icc.mp hj).1
      change (((2 * n + 2 * j - 1) + u - u - 2 * n + 1) / 2) = j
      omega
    have hJbound : J.card ≤ 7 * E.card := by
      calc
        J.card ≤ ((U.product E).image
            (fun z : ℕ × ℕ => (z.2 - z.1 - 2 * n + 1) / 2)).card :=
          Finset.card_le_card hJsub
        _ ≤ (U.product E).card := Finset.card_image_le
        _ = 7 * E.card := by rw [Finset.product_eq_sprod, Finset.card_product, hUc]
    have hJcard : J.card = (n + 1) / 2 := by
      dsimp [J]
      rw [Nat.card_Icc]
      omega
    rw [hJcard] at hJbound
    have hbad : n ≤ 14 * E.card := by omega
    exact he hbad
  exact hDfree

/-- The sharp signed q allowance follows from the actual original seven-free B
and the inherited order-six endpoint, reached through the explicit Dousse7. -/
theorem strong_budget (hD:Dousse7) (β:ℝ) (hb:0<β) :
    ∃ n₀:ℕ,∀ n:ℕ,n₀≤n→∀ B:Finset ℕ, SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    OP02.SharpK6.SixFree (quarterD n B) ∧
      (totalBudget n B:ℝ) ≤ (n:ℝ)/2048-β*n/2 := by
  obtain ⟨U,hU⟩:=small_inventory β hb
  obtain ⟨V,hV⟩:=sixfree_uniform hD (2*β) (by positivity)
  refine ⟨max U (4*V),?_⟩
  intro n hn B hf hd hg
  obtain ⟨hcap,hpos⟩:=hU n (by omega) B hd hg
  have ho:(Ho n B).card ≤ totalBudget n B:=by
    have h : (Ho n B).card≤(excessHoles n B).card:=card_filter_le _ _
    unfold totalBudget;omega
  have h6:=quarter_six_free n B hf (by omega)
  refine ⟨h6,?_⟩
  have hh:=hV (n/4) (by omega) (quarterD n B) (filter_subset _ _) h6
  have hle:(4:ℝ)*(n/4:ℕ)≤n:=by exact_mod_cast (show 4*(n/4)≤n by omega)
  nlinarith only [hh,hg,hle,mul_nonneg hb.le (sub_nonneg.mpr hle)]

end OP02.SharpK7

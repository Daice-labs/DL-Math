import K9DeepAccounts
import K8Selection

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7 OP02.SharpK8
namespace OP02.SharpK9

def deepStart (h σ : ℕ) := 2*(h/64)+4*σ+12
def deepEnd (h : ℕ) := 3*(h/64)

def DelayedTriangle (h σ : ℕ) (G : Finset ℕ) : Prop :=
  ∃ w₁ w₂ z : ℕ, 0<w₁ ∧ w₁<w₂ ∧ w₂<z ∧ 4*(w₁+w₂)≤h/4 ∧ 4*z≤3*(h/4) ∧
    h/4+32*σ+60<2*z ∧ w₁%2=0 ∧ w₂%2=0 ∧ z%2=0 ∧
    w₁∈G ∧ w₂∈G ∧ z∈G ∧ w₁+w₂∈G ∧ z+w₁∈G ∧ z+w₂∈G

/-- Odd testers for a fixed even reflected pair, paying at most three inverse roles per deep owner. -/
theorem deep_even_pair_tester {h σ a c : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (hd : DoublingFree G) (aev : a%2=0) (cev : c%2=0) (ab : a≤h/64) (cb : c≤h/64)
    (room : 3*(deepFaults h G).card < (deepEnd h+1)/2-(deepStart h σ+1)/2) :
    ∃ z : ℕ, deepStart h σ<z ∧ z≤deepEnd h ∧
      4*z∈G ∧ 4*(z+a)∈G ∧ 4*(z+c)∈G := by
  classical
  let P := Ioc ((deepStart h σ+1)/2) ((deepEnd h+1)/2)
  let roles : Finset ℕ := {0,a,c}
  let label (r j : ℕ) := 16*(2*j-1+r)
  have index {j : ℕ} (hj : j∈P) : 0<j ∧ deepStart h σ<2*j-1 ∧ 2*j-1≤deepEnd h := by
    obtain ⟨lo,up⟩ := mem_Ioc.mp hj
    omega
  have bound := rejected_card P roles (deepFaults h G) label (by
    intro r hr j hj k hk eq
    have := (index hj).1
    have := (index hk).1
    dsimp only [label] at eq
    omega)
  have lim : roles.card≤3 := card_le_three
  have pc : P.card=(deepEnd h+1)/2-(deepStart h σ+1)/2 := Nat.card_Ioc _ _
  have less := lt_of_le_of_lt (bound.trans (Nat.mul_le_mul_right _ lim)) (pc.symm ▸ room)
  obtain ⟨j,hj,ok⟩ := exists_mem_notMem_of_card_lt_card less
  obtain ⟨jp,low,high⟩ := index hj
  have pass : ∀ r∈roles, 4*(2*j-1+r)∈G := by
    intro r hr
    have choices : r=0 ∨ r=a ∨ r=c := by simpa only [roles,mem_insert,mem_singleton] using hr
    have odd : (2*j-1+r)%2=1 := by omega
    by_contra absent
    apply ok (mem_rejected.mpr ⟨r,hr,hj,?_⟩)
    dsimp only [label]
    dsimp only [deepStart,deepEnd] at low high
    exact deep_canonical_fault sub hd (by omega) (by omega) (canonical_odd _ odd) absent
  exact ⟨2*j-1,low,high,by simpa using pass 0 (by simp [roles]),
    pass a (by simp [roles]),pass c (by simp [roles])⟩

/-- The available positive even valuations are exactly four times a canonical index.
On that interval their supply is the difference of two exact canonical capacities. -/
theorem deep_odd_pair_tester {h σ : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (hd : DoublingFree G)
    (room : (deepFaults h G).card < chainCapacity (deepEnd h/4)-chainCapacity (deepStart h σ/4)) :
    ∃ z : ℕ, deepStart h σ<z ∧ z≤deepEnd h ∧ z%2=0 ∧ 4*z∈G := by
  classical
  let upper := canonicalSlots (deepEnd h/4)
  let lower := canonicalSlots (deepStart h σ/4)
  let P := upper \ lower
  have eq := card_sdiff_add_card_inter upper lower
  have ic := card_le_card (inter_subset_right (s₁:=upper) (s₂:=lower))
  change (deepFaults h G).card < upper.card-lower.card at room
  have enough : (deepFaults h G).card<P.card := by dsimp only [P]; omega
  have desc {j} (hj : j∈P) :
      deepStart h σ<4*j ∧ 4*j≤deepEnd h ∧ canonical (4*j)=true := by
    obtain ⟨hi,miss⟩ := mem_sdiff.mp hj
    obtain ⟨hjI,can⟩ := mem_filter.mp hi
    obtain ⟨pos,up⟩ := mem_Icc.mp hjI
    have notlow : ¬ j≤deepStart h σ/4 := fun hj => miss (mem_filter.mpr ⟨mem_Icc.mpr ⟨pos,hj⟩,can⟩)
    exact ⟨by omega,by omega,(canonical_four j).trans can⟩
  by_contra! fail
  have into : ∀ j∈P, 16*(4*j)∈deepFaults h G := by
    intro j hj
    obtain ⟨lo,up,can⟩ := desc hj
    have missing := fail (4*j) lo up (by omega)
    dsimp only [deepStart,deepEnd] at lo up
    exact deep_canonical_fault sub hd (by omega) (by omega) can missing
  have bad := card_le_card_of_injOn (fun j:ℕ => 16*(4*j)) into (by
    intro j hj k hk eq; dsimp at eq; omega)
  omega

/-- A missed odd translate recovers the unique unordered reflection pair on which it occurred. -/
theorem deep_pair_after_tester {h σ e z : ℕ} {G S : Finset ℕ}
    (small : S⊆Icc 1 (h/64)) (ee : e%2=0)
    (oddPairs : ∀ a∈reflectionPairs S e, a%2=1)
    (pop : (unmatchedTop (h/16) (quarterD (h/4) G)).card < (reflectionPairs S e).card)
    (lo : deepStart h σ<z) (up : z≤deepEnd h) (even : z%2=0) :
    ∃ a∈reflectionPairs S e, 4*(z+a)∈G ∧ 4*(z+(e-a))∈G := by
  classical
  let Y := quarterD (h/4) G
  let M := unmatchedTop (h/16) Y
  let P := reflectionPairs S e
  let recover (u : ℕ) := min (u-z) (e-(u-z))
  dsimp only [deepStart,deepEnd] at lo up
  have missing {x} (xx : x≤h/64) (xo : x%2=1) (absent : 4*(z+x)∉G) :
      z+x∈M := by
    apply mem_filter.mpr
    refine ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,fun hh => absent (mem_filter.mp hh).2,?_⟩
    intro v hv eq; omega
  by_contra! fail
  have cover : P⊆M.image recover := by
    intro a ha
    obtain ⟨has,apos,ac,hcs⟩ := mem_filter.mp ha
    have au := (mem_Icc.mp (small has)).2
    have cu := (mem_Icc.mp (small hcs)).2
    have odd := oddPairs a ha
    by_cases first : 4*(z+a)∈G
    · have miss := fail a ha first
      exact mem_image.mpr ⟨z+(e-a),missing cu (by omega) miss,by dsimp [recover]; omega⟩
    · exact mem_image.mpr ⟨z+a,missing au odd first,by dsimp [recover]; omega⟩
  have counted : P.card≤M.card := (card_le_card cover).trans card_image_le
  exact (not_lt_of_ge counted) pop

end OP02.SharpK9

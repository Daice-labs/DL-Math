import K6ActualTriangle
import K6BadTriangle
open Finset
namespace OP02.SharpK6
open OP02.FewHole OP02.SmallExcess OP02.SharpK5

theorem early_triangle_set (n U:ℕ) (B:Finset ℕ)
    (h:EarlyTriangle (actualRootPrefix n B) U) :
    ∃T:Finset ℕ,T⊆quarterD n B ∧ T.card=3 ∧
      (∀t∈T,t ≤ min U (n/16)) ∧
      (∀x∈T,∀y∈T,x≠y → x+y∈quarterD n B) := by
  obtain ⟨x,hx,y,hy,z,hz,hxy,hxz,hyz,hxU,hyU,hzU,hxyA,hxzA,hyzA⟩:=h
  refine ⟨{x,y,z},?_,by simp [hxy,hxz,hyz],?_,?_⟩
  · intro t ht
    simp only [mem_insert,mem_singleton] at ht
    rcases ht with rfl|rfl|rfl <;> exact (mem_filter.mp (by assumption)).1
  · intro t ht
    simp only [mem_insert,mem_singleton] at ht
    rcases ht with rfl|rfl|rfl
    · exact le_min hxU (mem_filter.mp hx).2
    · exact le_min hyU (mem_filter.mp hy).2
    · exact le_min hzU (mem_filter.mp hz).2
  · intro a ha b hb hab
    simp only [mem_insert,mem_singleton] at ha hb
    have hxyD:=(mem_filter.mp hxyA).1
    have hxzD:=(mem_filter.mp hxzA).1
    have hyzD:=(mem_filter.mp hyzA).1
    rcases ha with rfl|rfl|rfl <;> rcases hb with rfl|rfl|rfl
    all_goals first | exact False.elim (hab rfl) | assumption | simpa only [Nat.add_comm] using hxyD | simpa only [Nat.add_comm] using hxzD | simpa only [Nat.add_comm] using hyzD
#print axioms early_triangle_set
end OP02.SharpK6

import K6CanonicalProfiles
open Finset
namespace OP02.SharpK6
open OP02.FewHole OP02.SharpK5 OP02.PositivePivot
set_option maxHeartbeats 3000000

theorem three_residue_split (A:Finset ℕ) (hc:A.card=3)
    (hpar:∀x∈A,∀y∈A,x%2=y%2)
    (hdiff:∃x∈A,∃y∈A,x%4≠y%4) :
    ∃w a b:ℕ,A={w,a,b} ∧ w≠a ∧ w≠b ∧ a≠b ∧
      (a+2)%4=w%4 ∧ (b+2)%4=w%4 := by
  obtain ⟨x,y,z,hxy,hxz,hyz,rfl⟩:=card_eq_three.mp hc
  have hp1:=hpar x (by simp) y (by simp)
  have hp2:=hpar x (by simp) z (by simp)
  have hn:¬(x%4=y%4 ∧ x%4=z%4) := by
    rintro ⟨h1,h2⟩
    obtain ⟨u,hu,v,hv,huv⟩:=hdiff
    simp only [mem_insert,mem_singleton] at hu hv
    rcases hu with rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl <;> omega
  by_cases h1:x%4=y%4
  · refine ⟨z,x,y,?_,by omega,by omega,hxy,by omega,by omega⟩
    ext a; simp only [mem_insert,mem_singleton]; tauto
  by_cases h2:x%4=z%4
  · refine ⟨y,x,z,?_,by omega,hyz,hxz,by omega,by omega⟩
    ext a; simp only [mem_insert,mem_singleton]; tauto
  · exact ⟨x,y,z,rfl,hxy,hxz,hyz,by omega,by omega⟩

theorem split_residue_load (A:Finset ℕ) (w a b:ℕ)
    (hA:A={w,a,b}) (h1:(a+2)%4=w%4) (h2:(b+2)%4=w%4):
    ∀j:ℕ,(A.filter (fun x=>x%4=j)).card≤2 := by
  classical
  intro j
  by_cases hj:w%4=j
  · have hs:A.filter (fun x=>x%4=j)⊆{w} := by
      intro x hx
      obtain ⟨hxA,hxj⟩:=mem_filter.mp hx
      rw [hA] at hxA
      simp only [mem_insert,mem_singleton] at hxA
      rcases hxA with rfl|rfl|rfl
      · simp
      · omega
      · omega
    have:=card_le_card hs
    simp only [card_singleton] at this
    omega
  · apply le_trans (card_le_card (show A.filter (fun x=>x%4=j)⊆{a,b} from ?_)) card_le_two
    intro x hx
    obtain ⟨hxA,hxj⟩:=mem_filter.mp hx
    rw [hA] at hxA
    simp only [mem_insert,mem_singleton] at hxA ⊢
    rcases hxA with rfl|rfl|rfl <;> tauto

theorem three_profile_shape (n:ℕ) (S:Finset ℕ)
    (hS:S⊆Icc 1 n) (hc:S.card=5)
    (hp:∀x∈S,∀y∈S,x≠y → x+y≤n)
    (ho:(S.filter (fun x=>x%2=1)).card=3)
    (hod:∃x∈S,∃y∈S,x%2=1 ∧ y%2=1 ∧ x%4≠y%4)
    (hev:∃v∈S,v%4=2) :
    ∃w∈insert 0 S,∃a∈insert 0 S,∃b∈insert 0 S,
      (2+a)%4=w%4 ∧ (2+b)%4=w%4 ∧ 4*w≤3*n ∧ 2*max a b≤n ∧
      (∀t∈insert 0 S\{w,a,b},t%2≠w%2) ∧
      (∀j:ℕ,((insert 0 S\{w,a,b}).filter (fun x=>x%4=j)).card≤2) := by
  classical
  let U:=insert 0 S
  let E:=U.filter (fun x=>x%2=0)
  let O:=U.filter (fun x=>x%2=1)
  have hz:0∉S := by intro h; have:=(mem_Icc.mp (hS h)).1; omega
  have hUc:U.card=6 := by simp [U,hz,hc]
  have hOc:O.card=3 := by
    have he:O=S.filter (fun x=>x%2=1) := by
      ext x
      simp only [O,U,mem_filter,mem_insert]
      constructor
      · rintro ⟨h0|hx,hodd⟩
        · omega
        · exact ⟨hx,hodd⟩
      · rintro ⟨hx,hodd⟩; exact ⟨Or.inr hx,hodd⟩
    rw [he]; exact ho
  have hpart:U.card=E.card+O.card := by
    apply partition_card
    · intro x; simp only [E,O,mem_filter]; constructor
      · intro hx; by_cases h:x%2=0
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · tauto
    · intro x hx hy; have:=(mem_filter.mp hx).2; have:=(mem_filter.mp hy).2; omega
  have hEc:E.card=3 := by omega
  have hEpar:∀x∈E,∀y∈E,x%2=y%2 := by intro x hx y hy; have:=(mem_filter.mp hx).2; have:=(mem_filter.mp hy).2; omega
  have hOpar:∀x∈O,∀y∈O,x%2=y%2 := by intro x hx y hy; have:=(mem_filter.mp hx).2; have:=(mem_filter.mp hy).2; omega
  have hEdiff:∃x∈E,∃y∈E,x%4≠y%4 := by
    obtain ⟨v,hv,hv4⟩:=hev
    exact ⟨0,by simp [E,U],v,mem_filter.mpr ⟨mem_insert_of_mem hv,by omega⟩,by omega⟩
  have hOdiff:∃x∈O,∃y∈O,x%4≠y%4 := by
    obtain ⟨x,hx,y,hy,hxo,hyo,hxy⟩:=hod
    exact ⟨x,mem_filter.mpr ⟨mem_insert_of_mem hx,hxo⟩,y,mem_filter.mpr ⟨mem_insert_of_mem hy,hyo⟩,hxy⟩
  obtain ⟨w,a,b,hE,hwa,hwb,hab,ha4,hb4⟩:=three_residue_split E hEc hEpar hEdiff
  obtain ⟨z,c,d,hO,hzc,hzd,hcd,hc4,hd4⟩:=three_residue_split O hOc hOpar hOdiff
  have hE_mem: w∈E ∧ a∈E ∧ b∈E := by simp [hE]
  have hO_mem: z∈O ∧ c∈O ∧ d∈O := by simp [hO]
  have hcross:∀x∈E,∀y∈O,x+y≤n := by
    intro x hx y hy
    obtain ⟨hxU,hxe⟩:=mem_filter.mp hx
    obtain ⟨hyU,hyo⟩:=mem_filter.mp hy
    have hyS:y∈S := (mem_insert.mp hyU).resolve_left (by omega)
    rcases mem_insert.mp hxU with rfl|hxS
    · have:=(mem_Icc.mp (hS hyS)).2; omega
    · exact hp x hxS y hyS (by omega)
  have hcomplE:U\{w,a,b}=O := by
    rw [←hE]
    ext x
    simp only [E,O,mem_sdiff,mem_filter]
    by_cases hx:x∈U <;> simp only [hx,true_and,false_and,not_false_eq_true,and_true]
    omega
  have hcomplO:U\{z,c,d}=E := by
    rw [←hO]
    ext x
    simp only [E,O,mem_sdiff,mem_filter]
    by_cases hx:x∈U <;> simp only [hx,true_and,false_and,not_false_eq_true,and_true]
    omega
  by_cases he:4*w≤3*n ∧ 2*max a b≤n
  · refine ⟨w,(mem_filter.mp hE_mem.1).1,a,(mem_filter.mp hE_mem.2.1).1,b,(mem_filter.mp hE_mem.2.2).1,by omega,by omega,he.1,he.2,?_,?_⟩
    · intro t ht
      change t∈U\{w,a,b} at ht
      rw [hcomplE] at ht
      have:=(mem_filter.mp ht).2
      have:=(mem_filter.mp hE_mem.1).2
      omega
    · change ∀j:ℕ,((U\{w,a,b}).filter _).card≤2
      rw [hcomplE]
      exact split_residue_load O z c d hO hc4 hd4
  · have hgeo:4*z≤3*n ∧ 2*max c d≤n := by
      have hwz:=hcross w hE_mem.1 z hO_mem.1
      have haw:=hcross a hE_mem.2.1 z hO_mem.1
      have hbw:=hcross b hE_mem.2.2 z hO_mem.1
      have hwc:=hcross w hE_mem.1 c hO_mem.2.1
      have hac:=hcross a hE_mem.2.1 c hO_mem.2.1
      have hbc:=hcross b hE_mem.2.2 c hO_mem.2.1
      have hwd:=hcross w hE_mem.1 d hO_mem.2.2
      have had:=hcross a hE_mem.2.1 d hO_mem.2.2
      have hbd:=hcross b hE_mem.2.2 d hO_mem.2.2
      omega
    refine ⟨z,(mem_filter.mp hO_mem.1).1,c,(mem_filter.mp hO_mem.2.1).1,d,(mem_filter.mp hO_mem.2.2).1,by omega,by omega,hgeo.1,hgeo.2,?_,?_⟩
    · intro t ht
      change t∈U\{z,c,d} at ht
      rw [hcomplO] at ht
      have:=(mem_filter.mp ht).2
      have:=(mem_filter.mp hO_mem.1).2
      omega
    · change ∀j:ℕ,((U\{z,c,d}).filter _).card≤2
      rw [hcomplO]
      exact split_residue_load E w a b hE ha4 hb4
#print axioms three_residue_split
#print axioms split_residue_load
#print axioms three_profile_shape
end OP02.SharpK6

import K5Progressions
open Finset
namespace OP02.SharpK5
set_option maxHeartbeats 8000000
set_option maxRecDepth 10000

/-- Exact finite residue lemma. Memberships are indexed, so repeated residues
are counted with their full multiplicity. -/
theorem missing_residue_pivot : ∀a b c d:Fin 4,
    (∃j:Fin 4,j.val≠0 ∧ a≠j ∧ b≠j ∧ c≠j ∧ d≠j) →
    ∃p:Fin 4,
      p.val%4≠2 ∧ (p.val+a.val)%4≠2 ∧ (p.val+b.val)%4≠2 ∧
      (p.val+c.val)%4≠2 ∧ (p.val+d.val)%4≠2 ∧
      ((if p.val%2=0 then 1 else 0)+(if (p.val+a.val)%2=0 then 1 else 0)+
       (if (p.val+b.val)%2=0 then 1 else 0)+(if (p.val+c.val)%2=0 then 1 else 0)+
       (if (p.val+d.val)%2=0 then 1 else 0):ℕ)≤3 := by decide

/-- The residue selection applies to an arbitrary set of at most three offsets,
including empty and repeated-residue images. -/
theorem three_residue_set_selection : ∀T:Finset (Fin 8),T.card≤3→∃r:Fin 8,
    ∀a∈T,(r.val+a.val)%8∈({1,3,4,5,7}:Finset ℕ) := by decide

#print axioms missing_residue_pivot
#print axioms three_residue_set_selection
end OP02.SharpK5

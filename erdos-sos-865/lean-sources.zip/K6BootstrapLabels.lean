import K6GoodTriangle
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 3000000

def bootstrapLabel (u v:ℕ) (Q:Finset ℕ) (x z:ℕ) : Prop :=
 z=2*u+8*x ∨ z=2*v+8*x ∨ z=u+v+8*x ∨
 (∃t∈Q,z=u+8*x+4*t) ∨ (∃t∈Q,z=v+8*x+4*t)

/-- Both pivot tests use a single physical label. The duplicated common-even
map is represented once; the odd labels retain coordinate aliases. -/
theorem bootstrap_label_unique (u v x y z:ℕ) (Q:Finset ℕ)
    (hu:u%2=1) (hv:v%2=1) (hs:(u+v)%8=4) (hp:x%2=y%2)
    (hq:Set.InjOn (fun t:ℕ=>t%4) Q)
    (hx:bootstrapLabel u v Q x z) (hy:bootstrapLabel u v Q y z) : x=y := by
  rcases hx with hx|hx|hx|⟨a,ha,hx⟩|⟨a,ha,hx⟩ <;>
    rcases hy with hy|hy|hy|⟨b,hb,hy⟩|⟨b,hb,hy⟩ <;> try omega
  all_goals
    have hab:a=b:=hq ha hb (by dsimp; omega)
    subst b
    omega

def bootstrapResources (n:ℕ) (B:Finset ℕ) := fourResources n B ∪ H2 n B ∪ Ho n B

theorem bootstrap_resource_budget (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    (bootstrapResources n B).card≤totalBudget n B := by
  have h1:=card_union_le (fourResources n B) (H2 n B)
  have h2:=card_union_le (fourResources n B ∪ H2 n B) (Ho n B)
  have h3:=four_resource_card n B
  have h4:=middle_two_le_singleton n B hd
  have h5:=deficit_split n B hd
  have h6:=excess_partition n B
  unfold bootstrapResources totalBudget
  omega

/-- The target double is excess precisely because the selected midpoint is absent. -/
theorem bootstrap_missing_target (n a x:ℕ) (B:Finset ℕ)
    (ha:a%2=1) (hmid:a+4*x∉B)
    (hl:2*n<2*a+8*x) (hh:2*a+8*x≤4*n) (hbad:2*a+8*x∉B) :
    2*a+8*x∈H2 n B := by
  apply mem_filter.mpr
  refine ⟨mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,hh⟩,hbad⟩,?_⟩,by omega⟩
  intro him
  obtain ⟨m,hm,he⟩:=mem_image.mp him
  have heq:m=a+4*x := by change 2*m=2*a+8*x at he; omega
  exact hmid (heq ▸ (mem_inter.mp hm).1)

theorem bootstrap_missing_common (n z:ℕ) (B:Finset ℕ)
    (hz:z%8=4) (hl:2*n<z) (hh:z≤4*n) (hbad:z∉B) :
    z∈fourResources n B := by
  classical
  have hhole:z∈holes n B:=mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,hh⟩,hbad⟩
  by_cases he:z∈excessHoles n B
  · exact mem_union_right _ (mem_filter.mpr ⟨he,by omega⟩)
  have him:z∈(middle n B).image (fun x=>2*x) := by
    by_contra hi
    exact he (mem_sdiff.mpr ⟨hhole,hi⟩)
  obtain ⟨m,hm,rfl⟩:=mem_image.mp him
  exact mem_union_left _ (mem_image.mpr ⟨m,mem_filter.mpr ⟨hm,by omega⟩,rfl⟩)

/-- No bounded multiplicity premise: unique preimages are proved above from
actual residues and root labels, then summed across the single resource union. -/
theorem bootstrap_joint_charge (n u v σ:ℕ) (B Q Y:Finset ℕ)
    (hd:DoublingFree B) (hu:u%2=1) (hv:v%2=1) (hs:(u+v)%8=4)
    (hσ:∀x∈Y,x%2=σ) (hq:Set.InjOn (fun t:ℕ=>t%4) Q)
    (hcover:∀x∈Y,∃z∈bootstrapResources n B,bootstrapLabel u v Q x z) :
    Y.card≤totalBudget n B := by
  classical
  choose f hf hlabel using hcover
  have hc:Y.card≤(bootstrapResources n B).card := by
    apply card_le_card_of_injOn (fun x=>if hx:x∈Y then f x hx else 0)
    · intro x hx
      change x∈Y at hx
      change (if h : x∈Y then f x h else 0)∈bootstrapResources n B
      simpa only [dif_pos hx] using hf x hx
    · intro x hx y hy hxy
      change x∈Y at hx
      change y∈Y at hy
      dsimp only at hxy
      simp only [dif_pos hx,dif_pos hy] at hxy
      apply bootstrap_label_unique u v x y (f x hx) Q hu hv hs (by rw [hσ x hx,hσ y hy]) hq (hlabel x hx)
      rw [hxy]
      exact hlabel y hy
  exact le_trans hc (bootstrap_resource_budget n B hd)

#print axioms bootstrap_label_unique
#print axioms bootstrap_resource_budget
#print axioms bootstrap_missing_target
#print axioms bootstrap_missing_common
#print axioms bootstrap_joint_charge

theorem bootstrap_missing_odd (n z:ℕ) (B:Finset ℕ)
    (hz:z%2=1) (hl:2*n<z) (hh:z≤4*n) (hbad:z∉B) : z∈Ho n B := by
  apply mem_filter.mpr
  refine ⟨mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,hh⟩,hbad⟩,?_⟩,hz⟩
  intro hi
  obtain ⟨m,hm,he⟩:=mem_image.mp hi
  change 2*m=z at he
  omega

theorem bootstrap_label_swap (u v x z:ℕ) (Q:Finset ℕ)
    (h:bootstrapLabel v u Q x z) : bootstrapLabel u v Q x z := by
  rcases h with h|h|h|h|h
  · exact Or.inr (Or.inl h)
  · exact Or.inl h
  · exact Or.inr (Or.inr (Or.inl (by omega)))
  · exact Or.inr (Or.inr (Or.inr (Or.inr h)))
  · exact Or.inr (Or.inr (Or.inr (Or.inl h)))

/-- One failed actual qualification produces an actual resource. No missing
midpoint is mistaken for an excess hole without checking its half. -/
theorem bootstrap_pivot_cover (n u v x:ℕ) (B T:Finset ℕ)
    (hf:SixFree B) (hu:u∈lower n B) (hv:v∈lower n B)
    (huv:u≠v) (huo:u%2=1) (hvo:v%2=1) (hsum:u+v∈B)
    (hsum8:(u+v)%8=4) (hT:T⊆quarterD n B) (hTc:T.card=3)
    (hpair:∀r∈T,∀s∈T,r≠s → r+s∈quarterD n B)
    (hqual:∀r∈T,u+4*r∈B ∧ v+4*r∈B)
    (hmid:u+4*x∉B) (hl:2*n<u+8*x) (hh:u+8*x+n≤4*n) :
    ∃z∈bootstrapResources n B,bootstrapLabel u v (insert 0 T) x z := by
  classical
  let S:=insert u (insert v (T.image (fun r=>4*r)))
  have hc:=qualified_triangle_explicit_clique n u v B T
    (mem_inter.mp hu).1 (mem_inter.mp hv).1 huv huo hvo hsum hT hTc hpair hqual
  change S⊆B ∧ S.card=5 ∧ _ at hc
  have hbnd:∀s∈S,s≤n := by
    intro s hs
    rcases mem_insert.mp hs with rfl|hs
    · exact (mem_Icc.mp (mem_inter.mp hu).2).2
    · rcases mem_insert.mp hs with rfl|hs
      · exact (mem_Icc.mp (mem_inter.mp hv).2).2
      · obtain ⟨r,hr,rfl⟩:=mem_image.mp hs
        have:=(mem_Icc.mp (mem_filter.mp (hT hr)).1).2
        omega
  obtain ⟨s,hs,hbad⟩:=five_clique_missing_label B S hf hc.1 hc.2.1 hc.2.2 (u+8*x)
    (by intro hi; have:=hbnd _ hi; omega)
  have hsb:s≤n := by rcases mem_insert.mp hs with rfl|hs; omega; exact hbnd s hs
  have hzL:2*n<u+8*x+s := by omega
  have hzH:u+8*x+s≤4*n := by omega
  refine ⟨u+8*x+s,?_,?_⟩
  · rcases mem_insert.mp hs with rfl|hs
    · exact mem_union_right _ (bootstrap_missing_odd n _ B (by omega) hzL hzH hbad)
    · rcases mem_insert.mp hs with rfl|hs
      · apply mem_union_left
        apply mem_union_right
        have heq:s+8*x+s=2*s+8*x := by omega
        rw [heq] at hbad hzL hzH ⊢
        exact bootstrap_missing_target n s x B huo hmid hzL hzH hbad
      · rcases mem_insert.mp hs with rfl|hs
        · apply mem_union_left
          apply mem_union_left
          exact bootstrap_missing_common n _ B (by omega) hzL hzH hbad
        · obtain ⟨r,hr,rfl⟩:=mem_image.mp hs
          exact mem_union_right _ (bootstrap_missing_odd n _ B (by omega) hzL hzH hbad)
  · rcases mem_insert.mp hs with rfl|hs
    · exact Or.inr (Or.inr (Or.inr (Or.inl ⟨0,by simp,by omega⟩)))
    · rcases mem_insert.mp hs with rfl|hs
      · exact Or.inl (by omega)
      · rcases mem_insert.mp hs with rfl|hs
        · exact Or.inr (Or.inr (Or.inl (by omega)))
        · obtain ⟨r,hr,rfl⟩:=mem_image.mp hs
          exact Or.inr (Or.inr (Or.inr (Or.inl ⟨r,mem_insert_of_mem hr,rfl⟩)))

/-- The entire failed-qualification population costs at most q, not q for
each pivot. Root-membership failures are deliberately kept separate. -/
theorem actual_bootstrap_qualification_charge (n u v σ:ℕ) (B T Y:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hu:u∈lower n B) (hv:v∈lower n B)
    (huv:u≠v) (huo:u%2=1) (hvo:v%2=1) (hsum:u+v∈B) (hsum8:(u+v)%8=4)
    (hT:T⊆quarterD n B) (hTc:T.card=3)
    (hpair:∀r∈T,∀s∈T,r≠s → r+s∈quarterD n B)
    (hqual:∀r∈T,u+4*r∈B ∧ v+4*r∈B)
    (hq:Set.InjOn (fun t:ℕ=>t%4) (↑(insert 0 T : Finset ℕ)))
    (hσ:∀x∈Y,x%2=σ)
    (hrange:∀x∈Y,2*n<u+8*x ∧ 2*n<v+8*x ∧ u+8*x+n≤4*n ∧ v+8*x+n≤4*n)
    (hfail:∀x∈Y,u+4*x∉B ∨ v+4*x∉B) : Y.card≤totalBudget n B := by
  apply bootstrap_joint_charge n u v σ B (insert 0 T) Y hd huo hvo hsum8 hσ hq
  intro x hx
  have hr:=hrange x hx
  rcases hfail x hx with hxu|hxv
  · exact bootstrap_pivot_cover n u v x B T hf hu hv huv huo hvo hsum hsum8 hT hTc hpair hqual hxu hr.1 hr.2.2.1
  · obtain ⟨z,hz,hlabel⟩:=bootstrap_pivot_cover n v u x B T hf hv hu huv.symm hvo huo
      (by simpa only [Nat.add_comm] using hsum) (by simpa only [Nat.add_comm] using hsum8)
      hT hTc hpair (fun r hr=>⟨(hqual r hr).2,(hqual r hr).1⟩) hxv hr.2.1 hr.2.2.2
    exact ⟨z,hz,bootstrap_label_swap u v x z _ hlabel⟩

#print axioms bootstrap_pivot_cover
#print axioms actual_bootstrap_qualification_charge

end OP02.SharpK6

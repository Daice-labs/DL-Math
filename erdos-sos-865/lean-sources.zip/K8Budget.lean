import K8GeometrySpec

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK8

/-- Actual complete-chain deficit and the original empty-slot, singleton and upper-hole account. -/
theorem signed_capacity {β : ℝ} (hb : 0 < β) :
    ∃ M : ℕ, ∀ n : ℕ, M ≤ n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
      ((chainDeficit n B + totalBudget n B : ℕ) : ℝ) + β*n/2 ≤ ((n/4 : ℕ) : ℝ)/1536 := by
  obtain ⟨U,hU⟩ := capacity_uniform_error (2*β) (by positivity)
  refine ⟨max 1 (4*U),?_⟩
  intro n hn B hd hg
  have hcap := hU (n/4) (by omega)
  have hh : 4*((n/4 : ℕ):ℝ) ≤ n := by exact_mod_cast (show 4*(n/4)≤n by omega)
  have hc := chain_capacity_with_top_loss (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  have he : chainDeficit n B + (quarterD n B).card = chainCapacity (n/4) := by unfold chainDeficit; omega
  have her : (chainDeficit n B : ℝ) + (quarterD n B).card = chainCapacity (n/4) := by exact_mod_cast he
  unfold SignedGap at hg
  push_cast
  nlinarith only [hg,her,hcap,hh,mul_nonneg hb.le (sub_nonneg.mpr hh)]

theorem strict_capacity {β : ℝ} (hb : 0 < β) :
    ∃ M : ℕ, ∀ n : ℕ, M ≤ n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
      1536 * (chainDeficit n B + totalBudget n B) < n/4 := by
  obtain ⟨U,hU⟩ := signed_capacity hb
  refine ⟨max 1 U,?_⟩
  intro n hn B hd hg
  have h := hU n (by omega) B hd hg
  have pos : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have h' : (1536:ℝ) * ((chainDeficit n B + totalBudget n B : ℕ):ℝ) < (n/4:ℕ) := by
    nlinarith only [h,mul_pos hb pos]
  exact_mod_cast h'

/-- Dilation transports the entire fifteen-edge clique, including every integer endpoint. -/
theorem dilate_root_six (n : ℕ) (B : Finset ℕ) (hs : RootSix (n/4) (quarterD n B)) :
    NarrowSix n B := by
  obtain ⟨F,R,hF,hr,hI,rlo,rhi,small⟩ := hs
  have inj : Function.Injective (fun x : ℕ => 4*x) := by intro x y e; change 4*x=4*y at e; omega
  let V := F.image (fun x=>4*x)
  have hz : 4*R ∉ V := by
    intro h; obtain ⟨x,hx,he⟩ := mem_image.mp h
    exact hr (inj he ▸ hx)
  have expand : insert (4*R) V = (insert R F).image (fun x=>4*x) := by simp [V]
  refine ⟨V,4*R,(card_image_of_injective _ inj).trans hF,hz,?_,?_,by omega,by omega,?_⟩
  · rw [expand]
    refine ⟨?_,(card_image_of_injective _ inj).trans hI.2.1,?_⟩
    · intro x hx; obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
      exact (mem_filter.mp (hI.1 ha)).2
    · intro x hx y hy hxy
      obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
      obtain ⟨b,hb,rfl⟩ := mem_image.mp hy
      have h := (mem_filter.mp (hI.2.2 a ha b hb (fun h => hxy (congrArg _ h)))).2
      simpa only [Nat.mul_add] using h
  · intro x hx; rw [expand] at hx
    obtain ⟨a,_,rfl⟩ := mem_image.mp hx
    omega
  · intro x hx; obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
    have := small a ha; omega

end OP02.SharpK8

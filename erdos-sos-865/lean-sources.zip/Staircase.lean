import Mathlib
open Finset
namespace OP02.SharpK4
set_option maxRecDepth 4000
set_option maxHeartbeats 2000000

/-- Physical label geometry on the selected row/column, not on arbitrary boxes. -/
theorem staircase_location (x y : ℕ → ℕ) (hx : StrictMono x) (hy : StrictMono y)
    (p q i j di dj : ℕ) (hip : p ≤ i) (hjq : j ≤ q)
    (hshape : i = p ∨ j = q) (hdi : di ≤ 1) (hdj : dj ≤ 1) :
    (x (i+di)+y (j+dj) < x (p+1)+y q → i=p) ∧
    (x (p+1)+y q < x (i+di)+y (j+dj) → j=q) ∧
    (x (i+di)+y (j+dj) = x (p+1)+y q → i≤p+1 ∧ q≤j+1) := by
  constructor
  · intro h
    by_contra hi
    have hj : j=q := hshape.resolve_left hi
    have hxx := hx.monotone (show p+1 ≤ i+di by omega)
    have hyy := hy.monotone (show q ≤ j+dj by omega)
    omega
  constructor
  · intro h
    by_contra hj
    have hi : i=p := hshape.resolve_right hj
    have hxx := hx.monotone (show i+di ≤ p+1 by omega)
    have hyy := hy.monotone (show j+dj ≤ q by omega)
    omega
  · intro he
    constructor
    · by_contra hi
      have hj : j=q := hshape.resolve_left (by omega)
      have hxx := hx (show p+1 < i+di by omega)
      have hyy := hy.monotone (show q ≤ j+dj by omega)
      omega
    · by_contra hj
      have hi : i=p := hshape.resolve_right (by omega)
      have hxx := hx.monotone (show i+di ≤ p+1 by omega)
      have hyy := hy (show j+dj < q by omega)
      omega

/-- The exact ordered staircase bound. Each box must contain an actual label in K.
No multiplicity or global capacity bound is assumed. -/
theorem staircase_bound (x y : ℕ → ℕ) (hx : StrictMono x) (hy : StrictMono y)
    (Gx Gy K : Finset ℕ) (p q : ℕ)
    (hp : p ∈ Gx) (hq : q ∈ Gy)
    (hmin : ∀ i ∈ Gx, p ≤ i) (hmax : ∀ j ∈ Gy, j ≤ q)
    (hcover : ∀ i ∈ Gx, ∀ j ∈ Gy,
      ∃ di : Fin 2, ∃ dj : Fin 2, x (i+di.val)+y (j+dj.val) ∈ K) :
    Gx.card + Gy.card ≤ 4*K.card+1 := by
  classical
  let S : Finset (ℕ×ℕ) := ({p} ×ˢ Gy) ∪ (Gx ×ˢ {q})
  have hmem (b : {b // b ∈ S}) :
      p ≤ b.val.1 ∧ b.val.2 ≤ q ∧ (b.val.1=p ∨ b.val.2=q) ∧
      b.val.1∈Gx ∧ b.val.2∈Gy := by
    have hb := b.property
    simp only [S, mem_union, mem_product, mem_singleton] at hb
    rcases hb with ⟨hi,hj⟩ | ⟨hi,hj⟩
    · exact ⟨by omega,hmax _ hj,Or.inl hi,by simpa [hi] using hp,hj⟩
    · exact ⟨hmin _ hi,by omega,Or.inr hj,hi,by simpa [hj] using hq⟩
  have hc (b : {b // b ∈ S}) : ∃ c : Fin 2 × Fin 2,
      x (b.val.1+c.1.val)+y (b.val.2+c.2.val) ∈ K := by
    obtain ⟨di,dj,hh⟩ := hcover _ (hmem b).2.2.2.1 _ (hmem b).2.2.2.2
    exact ⟨(di,dj),hh⟩
  let corner (b : {b // b ∈ S}) : Fin 2 × Fin 2 := (hc b).choose
  let label (b : {b // b ∈ S}) : ℕ :=
    x (b.val.1+(corner b).1.val)+y (b.val.2+(corner b).2.val)
  have hl (b : {b // b ∈ S}) : label b ∈ K := (hc b).choose_spec
  have hloc (b : {b // b ∈ S}) :=
    staircase_location x y hx hy p q b.val.1 b.val.2
      (corner b).1.val (corner b).2.val (hmem b).1 (hmem b).2.1
      (hmem b).2.2.1 (by omega) (by omega)
  let tag (b : {b // b ∈ S}) : Fin 2 × Fin 2 :=
    if he : label b = x (p+1)+y q then
      (⟨b.val.1-p,by have := (hloc b).2.2 he;omega⟩,
       ⟨q-b.val.2,by have := (hloc b).2.2 he;omega⟩)
    else corner b
  let f (b : {b // b ∈ S}) : {h // h ∈ K} × (Fin 2 × Fin 2) :=
    (⟨label b,hl b⟩,tag b)
  have hinj : Function.Injective f := by
    intro b c he
    have hel : label b = label c := congrArg (fun z => z.1.val) he
    have het : tag b = tag c := congrArg Prod.snd he
    have hbx := (hmem b).1
    have hby := (hmem b).2.1
    have hcx := (hmem c).1
    have hcy := (hmem c).2.1
    apply Subtype.ext
    apply Prod.ext
    · by_cases hmid : label b = x (p+1)+y q
      · have hmidc : label c = x (p+1)+y q := by omega
        have hh := congrArg (fun z : Fin 2 × Fin 2 => z.1.val) het
        simp only [tag, dif_pos hmid, dif_pos hmidc] at hh
        omega
      · have hmidc : label c ≠ x (p+1)+y q := by omega
        simp only [tag, dif_neg hmid, dif_neg hmidc] at het
        have hdi := congrArg (fun z : Fin 2 × Fin 2 => z.1.val) het
        have hdj := congrArg (fun z : Fin 2 × Fin 2 => z.2.val) het
        by_cases hlt : label b < x (p+1)+y q
        · have hb := (hloc b).1 hlt
          have hc' := (hloc c).1 (show label c < x (p+1)+y q by omega)
          omega
        · have hb := (hloc b).2.1 (show x (p+1)+y q < label b by omega)
          have hc' := (hloc c).2.1 (show x (p+1)+y q < label c by omega)
          dsimp [label] at hel
          have hv : x (b.val.1+(corner b).1.val) = x (c.val.1+(corner c).1.val) := by rw [hb,hc',hdj] at hel;omega
          have hi := hx.injective hv
          omega
    · by_cases hmid : label b = x (p+1)+y q
      · have hmidc : label c = x (p+1)+y q := by omega
        have hh := congrArg (fun z : Fin 2 × Fin 2 => z.2.val) het
        simp only [tag, dif_pos hmid, dif_pos hmidc] at hh
        omega
      · have hmidc : label c ≠ x (p+1)+y q := by omega
        simp only [tag, dif_neg hmid, dif_neg hmidc] at het
        have hdi := congrArg (fun z : Fin 2 × Fin 2 => z.1.val) het
        have hdj := congrArg (fun z : Fin 2 × Fin 2 => z.2.val) het
        by_cases hlt : label b < x (p+1)+y q
        · have hb := (hloc b).1 hlt
          have hc' := (hloc c).1 (show label c < x (p+1)+y q by omega)
          dsimp [label] at hel
          have hv : y (b.val.2+(corner b).2.val) = y (c.val.2+(corner c).2.val) := by rw [hb,hc',hdi] at hel;omega
          have hj := hy.injective hv
          omega
        · have hb := (hloc b).2.1 (show x (p+1)+y q < label b by omega)
          have hc' := (hloc c).2.1 (show x (p+1)+y q < label c by omega)
          omega
  have hcard := Fintype.card_le_of_injective f hinj
  have hbound : S.card ≤ 4*K.card := by
    simpa only [Fintype.card_prod, Fintype.card_coe, Fintype.card_fin, Nat.reduceMul, Nat.mul_comm] using hcard
  have hi : ({p} ×ˢ Gy) ∩ (Gx ×ˢ {q}) = {(p,q)} := by
    ext b
    simp only [mem_inter,mem_product,mem_singleton]
    constructor
    · rintro ⟨⟨h1,h2⟩,⟨h3,h4⟩⟩;exact Prod.ext h1 h4
    · intro hb;subst b;exact ⟨⟨rfl,hq⟩,⟨hp,rfl⟩⟩
  have hu := card_union_add_card_inter ({p} ×ˢ Gy) (Gx ×ˢ {q})
  rw [hi,card_singleton] at hu
  simp only [card_product,card_singleton,one_mul,mul_one] at hu
  change S.card+1=Gy.card+Gx.card at hu
  omega

#print axioms staircase_location
#print axioms staircase_bound
end OP02.SharpK4

import K7RaisedQuartet
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

def sourceFloor (H z p:ℕ) := max (2*H+8) (H+8*z+8-p)

private theorem wide_linear {H j K s p b z:ℕ}
    (pad:384*K+10000*j+300000≤H) (bb:320*b≤15*H+320)
    (pp:2*p≤H) (ss:s≤H) (lo:43*H≤320*z)
    (up:320*z≤43*H+8320*K+5120*j+81920) :
    let A:=18*K+4*j+16
    2*H+8+4*A+s≤4*H ∧ H+8*z+8+4*A+s≤4*H ∧
    8+4*A+p+8*b≤8*z ∧ H+8+4*A+8*b≤2*H:=by
  dsimp only;exact ⟨by omega,by omega,by omega,by omega⟩

theorem raised_source_width {H j K s p b z:ℕ}
    (pad:384*K+10000*j+300000≤H) (bb:b≤3*(H/64)+1) (pp:2*p≤H) (ss:s≤H)
    (lo:43*H/320<z) (up:z≤43*H/320+26*K+16*j+256):
    let A:=18*K+4*j+16
    sourceFloor H z p+4*A+s≤4*H ∧ sourceFloor H z p+4*A+p+8*b≤2*H+8*z:=by
  obtain ⟨t₁,t₂,t₃,t₄⟩:=wide_linear (b:=b) (z:=z) pad (by omega) pp ss (by omega) (by omega)
  unfold sourceFloor
  rcases le_total (2*H+8) (H+8*z+8-p) with h|h
  · rw [max_eq_right h]; exact ⟨by omega,by omega⟩
  · rw [max_eq_left h];exact ⟨t₁,by omega⟩

private theorem repeat4 {x x':ℕ} (h:x≤x') (eq:x%4=x'%4):4*((x'-x)/4)+x=x':=by omega
private theorem root_parity {p x w r:ℕ} (eq:w+x=4*r) (pp:p%2=x%2) (ne:p%4≠x%4):
    (w+p)%4=2 ∧ w%2=p%2:=by omega
private theorem half_odd {w p z:ℕ} (r:(w+p)%4=2) (fit:4*z≤(w+p)/2) :
    ((w+p)/2-4*z)%2=1:=by omega
private theorem undo_sub {a b c:ℕ} (h:a-b≤c):a≤c+b:=by omega
private theorem fit_half_low {H z p lo w:ℕ} (hl:H+8*z+8≤lo+p) (wl:lo<w) : 4*z≤(w+p)/2:=by omega

private theorem pair_linear_facts {H s p x x' b z lo A r w ζ y d:ℕ}
    (xx:x≤x') (xs:x'≤ s) (sh:s≤H) (ph:p≤ s)
    (hb:2*H+8≤lo) (yl:H+8*z+8≤lo+p) (tt:lo+4*A+s≤4*H) (bb:lo+4*A+p+8*b≤2*H+8*z)
    (wl:lo<w) (wh:w≤lo+4*A) (we:w+x=4*r) (er:4*d+x=x') (he:2*ζ=w+p) (ye:y+4*z=ζ)
    : H/2<y ∧ y+4*b≤H ∧ w+x'=4*(r+d) ∧ H/2<r ∧ r+d≤H ∧ 2*ζ≤4*H:=by
  exact ⟨by omega,by omega,by omega,by omega,by omega,by omega⟩

theorem pair_source_facts {H s p x x' b z lo A r:ℕ}
    (xlo:x≤x') (xh:x'≤ s) (sh:s≤H) (ph:p≤ s)
    (pp:p%2=x%2) (op:p%4≠x%4) (xp:x%4=x'%4)
    (hb:2*H+8≤lo) (yl:H+8*z+8-p≤lo)
    (tt:lo+4*A+s≤4*H) (bb:lo+4*A+p+8*b≤2*H+8*z)
    (rl:(lo+x)/4<r) (rh:r≤(lo+x)/4+A) :
    let w:=4*r-x
    let ζ:=(w+p)/2
    let y:=ζ-4*z
    lo<w ∧ w≤lo+4*A ∧ H/2<y ∧ y+4*b≤H ∧ y%2=1 ∧
    w%2=p%2 ∧ 2*(y+4*z)=w+p ∧ w+x=4*r ∧ w+x'=4*(r+(x'-x)/4) ∧
    H/2<r ∧ r+(x'-x)/4≤H ∧ 2*ζ≤4*H :=by
  let w:=4*r-x
  have we:w+x=4*r:=Nat.sub_add_cancel (by omega)
  have wl:lo<w:=by omega
  have wh:w≤lo+4*A:=by omega
  have d₁:=repeat4 xlo xp
  obtain ⟨residue,wo⟩:=root_parity we pp op
  have even:2*((w+p)/2)=w+p:=by omega
  have lower:H+8*z+8≤lo+p:=undo_sub yl
  have yl':4*z≤(w+p)/2:=fit_half_low lower wl
  have yrel:=Nat.sub_add_cancel yl'
  obtain ⟨ylo,yhi,re,rt,ru,zt⟩:=pair_linear_facts xlo xh sh ph hb lower tt bb wl wh we d₁ even yrel
  exact ⟨wl,wh,ylo,yhi,half_odd residue yl',wo,by rw [yrel,even],we,re,rt,ru,zt⟩

end OP02.SharpK7.LongOddTask

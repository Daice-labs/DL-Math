import PivotStructure
open Finset
namespace OP02.PivotAudit
open OP02.FewHole OP02.SmallExcess

/-- Exact remaining asymptotic charging obligation. K is uniform in n and B.
The mixed-triangle and small-joint-deficit restrictions are proved consequences
of a violation of the fixed-57 bound, not new assumptions on SmallExcessGoal. -/
def MixedResidueChargeGoal : Prop :=
  ∃ K : ℕ, ∀ n : ℕ, 20 ≤ n → ∀ B : Finset ℕ,
    B ⊆ Icc 1 (4*n) → FourFree B → DoublingFree B →
    n ≤ 4*(holes n B).card →
    32*(deficit n B+(excessHoles n B).card)<n →
    Erdos865.HasTriple (lower n B) →
    (∀ S, LowerTriangle n B S → MixedResidueProfile S) →
    8*(quarterD n B).card ≤ n+8*(deficit n B+(excessHoles n B).card)+K

theorem violation_has_internal_triangle (n : ℕ) (B : Finset ℕ)
    (hbad : 5*n+8*(excessHoles n B).card+57 <
      8*((residueR n B).card+(quarterD n B).card)) :
    Erdos865.HasTriple (lower n B) := by
  have hcard := lower_card_eq n B
  exact Erdos865.erdos865_contains_triple n (lower n B) (inter_subset_right) (by omega)

/-- A proof of the remaining charge would finish SmallExcessGoal with a fixed error. -/
theorem small_excess_of_mixed_charge (h : MixedResidueChargeGoal) : SmallExcessGoal := by
  obtain ⟨K,hK⟩ := h
  refine ⟨max 57 (K+4),?_⟩
  intro n hn B hsub hfour hdbl hlarge hsmall
  have h57 : 57 ≤ max 57 (K+4) := le_max_left _ _
  have hK4 : K+4 ≤ max 57 (K+4) := le_max_right _ _
  by_cases hbad : 5*n+8*(excessHoles n B).card+57 <
      8*((residueR n B).card+(quarterD n B).card)
  · have hd := violation_small_deficit n B hfour hdbl hsmall hbad
    have ht := violation_has_internal_triangle n B hbad
    have hm := violation_triangles_mixed n B hfour hdbl hsmall hbad
    have hc := hK n hd.2.2 B hsub hfour hdbl hlarge hd.1 ht hm
    have hr := residue_card_le n B hdbl
    unfold deficit at hc
    omega
  · omega

/-- Conversely the original goal implies the restricted charging obligation.
Thus this is an equivalent remaining problem, not an unjustified stronger conjecture. -/
theorem mixed_charge_of_small_excess (h : SmallExcessGoal) : MixedResidueChargeGoal := by
  obtain ⟨C,hC⟩ := h
  refine ⟨C,?_⟩
  intro n hn B hsub hfour hdbl hlarge hjoint htri hmixed
  have he : 32*(excessHoles n B).card<n := by omega
  have hc := hC n (by omega) B hsub hfour hdbl hlarge he
  have hr := residue_card_le n B hdbl
  unfold deficit
  omega

theorem mixed_charge_iff_small_excess : MixedResidueChargeGoal ↔ SmallExcessGoal :=
  ⟨small_excess_of_mixed_charge,mixed_charge_of_small_excess⟩

/-- The missing charge and published-configuration hypothesis remain explicit. -/
theorem k4_of_mixed_charge_and_dousse
    (hcharge : MixedResidueChargeGoal) (hD : OP02.Frontier.Dousse4) : OP02.K4Goal :=
  k4_of_small_excess_and_dousse (small_excess_of_mixed_charge hcharge) hD

/-- This example refutes only the all-translates residue-cover ansatz. -/
theorem residue_profile_0167_obstruction :
    ∀ α : ℕ, ¬ (∀ u ∈ ({0,1,6,7} : Finset ℕ), (α+u)%2=1 ∨ (α+u)%8=4) := by
  intro α h
  have h0 := h 0 (by simp)
  have h1 := h 1 (by simp)
  have h6 := h 6 (by simp)
  have h7 := h 7 (by simp)
  omega
end OP02.PivotAudit

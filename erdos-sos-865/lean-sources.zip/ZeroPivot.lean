import ZeroAP
import ZeroCapacity
open Finset
namespace OP02.ZeroExcess
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

def firstEven (n:ℕ) : ℕ := 2*(n/2+1)

theorem firstEven_spec (n:ℕ) : n< firstEven n ∧ firstEven n≤ n+2 ∧ (firstEven n)%2=0 := by
  dsimp [firstEven]
  omega

theorem pivot_from_even {n x y:ℕ} {B:Finset ℕ} (hd:DoublingFree B)
    (he:(excessHoles n B).card=0) (hx:x%4=0)
    (hy:y%2=0) (hyn:n< y) (hyu:2*y+x≤4*n)
    (hyM:y∉parityMiddle n B 0) (hys:y+x/2∉parityMiddle n B 0) :
    2*y∈B ∧ 2*y+x∈B := by
  have hy':y∉middle n B := fun hh=>hyM (mem_filter.mpr ⟨hh,hy⟩)
  have hys':y+x/2∉middle n B := by
    intro hh
    exact hys (mem_filter.mpr ⟨hh,by omega⟩)
  have hp:=upper_even_present n B hd he (v:=y) (mem_Icc.mpr ⟨by omega,by omega⟩) hy'
  have hpx:=upper_even_present n B hd he (v:=y+x/2) (mem_Icc.mpr ⟨by omega,by omega⟩) hys'
  exact ⟨hp,by convert hpx using 1 <;> omega⟩

theorem AP_no_close_pair {E:Finset ℕ} {C s k y z:ℕ}
    (hshape:E=(range k).image (fun i=>C+2*s*i)) (hs:3 ≤ s)
    (hyz:y< z) (hclose:z≤ y+4) : ¬(y∈E ∧ z∈E) := by
  rintro ⟨hy,hz⟩
  rw [hshape] at hy hz
  obtain ⟨i,hi,hie⟩:=mem_image.mp hy
  obtain ⟨j,hj,hje⟩:=mem_image.mp hz
  have hij:i< j := by
    by_contra hh
    have hji:j≤ i:=by omega
    have hm:=Nat.mul_le_mul_left (2*s) hji
    omega
  have hm:=Nat.mul_le_mul_left (2*s) (show i+1≤ j by omega)
  nlinarith

theorem three_choices {E:Finset ℕ} {C s k y h:ℕ}
    (hshape:E=(range k).image (fun i=>C+2*s*i)) (hs:3 ≤ s) :
    ∃z, (z=y ∨ z=y+2 ∨ z=y+4) ∧ z∉E ∧ z+h∉E := by
  have h01:=AP_no_close_pair hshape hs (y:=y) (z:=y+2) (by omega) (by omega)
  have h02:=AP_no_close_pair hshape hs (y:=y) (z:=y+4) (by omega) (by omega)
  have h12:=AP_no_close_pair hshape hs (y:=y+2) (z:=y+4) (by omega) (by omega)
  have h01':=AP_no_close_pair hshape hs (y:=y+h) (z:=y+2+h) (by omega) (by omega)
  have h02':=AP_no_close_pair hshape hs (y:=y+h) (z:=y+4+h) (by omega) (by omega)
  have h12':=AP_no_close_pair hshape hs (y:=y+2+h) (z:=y+4+h) (by omega) (by omega)
  have hor:(y∉E ∧ y+h∉E) ∨ (y+2∉E ∧ y+2+h∉E) ∨ (y+4∉E ∧ y+4+h∉E) := by tauto
  rcases hor with hh|hh|hh
  · exact ⟨y,Or.inl rfl,hh⟩
  · exact ⟨y+2,Or.inr (Or.inl rfl),hh⟩
  · exact ⟨y+4,Or.inr (Or.inr rfl),hh⟩

theorem AP_above {E:Finset ℕ} {C k z:ℕ}
    (hshape:E=(range k).image (fun i=>C+2*i)) (hz:C+2*k≤ z) : z∉E := by
  intro hh
  rw [hshape] at hh
  obtain ⟨i,hi,hie⟩:=mem_image.mp hh
  have hi':=mem_range.mp hi
  omega

/-- Exhaustive pivot selection, including the one globally counted exceptional set. -/
theorem global_capacity {n A m:ℕ} {B:Finset ℕ}
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hec:MidClosed (parityIndices n B 0))
    (hAo:A%2=1) (hAn:n< A) (hAl:A+2*(m-1)≤2*n)
    (hblock:parityMiddle n B 1=(range m).image (fun i=>A+2*i))
    (hm:3*(parityMiddle n B 0).card+32< m)
    (hn:4*(parityMiddle n B 0).card+12≤ n) :
    (quarterD n B).card≤(parityMiddle n B 0).card ∨
    4*(quarterD n B).card+4*m≤ n+8*(parityMiddle n B 0).card+24 := by
  let E:=parityMiddle n B 0
  let k:=E.card
  let y:=firstEven n
  have hy:=firstEven_spec n
  change n< y ∧ y≤ n+2 ∧ y%2=0 at hy
  have hdroot:∀d∈quarterD n B, 1≤ d ∧ 4*d≤ n := by
    intro d hdD
    have hi:=mem_Icc.mp (mem_filter.mp hdD).1
    omega
  by_cases hk:k=0
  · have hE:E=∅:=card_eq_zero.mp hk
    have hp:∀d∈quarterD n B, ∃p, p∈B ∧ p+4*d∈B ∧ 2*n< p ∧ p%4=0 ∧ p≤2*n+4 := by
      intro d hdD
      have hdi:=hdroot d hdD
      have hb:=pivot_from_even hd he (x:=4*d) (y:=y) (by omega) hy.2.2 hy.1 (by omega)
        (by change y∉E;rw [hE];simp) (by change y+(4*d)/2∉E;rw [hE];simp)
      exact ⟨2*y,hb.1,hb.2,by omega,by omega,by omega⟩
    have hc:=capacity_card hf hd he hAo hAn hAl hblock (C:=4)
      (by omega) (by omega) (Subset.refl _) hp
    rcases hc with hc|hc
    · left;omega
    · right;omega
  have hkpos:0< E.card:=by omega
  obtain ⟨C,s,hs,hso,hCn,hCp,hspan,hshape⟩:=parity_progression n B (by omega : 0<2) hec hkpos
  change E=(range k).image (fun i=>C+2*s*i) at hshape
  by_cases hs1:s=1
  · subst s
    norm_num at hshape hspan
    by_cases hyE:y∈E
    · have hCy:C=y := by
        rw [hshape] at hyE
        obtain ⟨i,hi,hie⟩:=mem_image.mp hyE
        omega
      subst C
      let Y:=y+2*k
      have hp:∀d∈quarterD n B, ∃p, p∈B ∧ p+4*d∈B ∧ 2*n< p ∧ p%4=0 ∧ p≤2*n+(4*k+4) := by
        intro d hdD
        have hdi:=hdroot d hdD
        have hY:Y∉E:=AP_above hshape (by dsimp [Y];omega)
        have hYs:Y+(4*d)/2∉E:=AP_above hshape (by dsimp [Y];omega)
        have hb:=pivot_from_even hd he (x:=4*d) (y:=Y) (by omega)
          (by dsimp [Y];omega) (by dsimp [Y];omega) (by dsimp [Y,k,E] at *;omega) hY hYs
        refine ⟨2*Y,hb.1,hb.2,?_,?_,?_⟩ <;> dsimp [Y] <;> omega
      have hc:=capacity_card hf hd he hAo hAn hAl hblock (C:=4*k+4)
        (by dsimp [k,E] at *;omega) (by omega) (Subset.refl _) hp
      rcases hc with hc|hc
      · left;omega
      · right;dsimp [k,E] at *;omega
    · let Bad:=(quarterD n B).filter (fun d=>y+2*d∈E)
      let Good:=(quarterD n B)\Bad
      have hb:Bad.card≤ k := by
        have hsub:Bad.image (fun d=>y+2*d)⊆E := by
          intro z hz
          obtain ⟨d,hd,rfl⟩:=mem_image.mp hz
          exact (mem_filter.mp hd).2
        have hi:Function.Injective (fun d:ℕ=>y+2*d):=by intro d t hh; dsimp at hh; omega
        have hc:=card_le_card hsub
        rw [card_image_of_injective _ hi] at hc
        exact hc
      have hGood:Good⊆quarterD n B:=sdiff_subset
      have hp:∀d∈Good, ∃p, p∈B ∧ p+4*d∈B ∧ 2*n< p ∧ p%4=0 ∧ p≤2*n+4 := by
        intro d hdG
        have hdi:=hdroot d (hGood hdG)
        have hys:y+(4*d)/2∉E := by
          intro hh
          have heq:(4*d)/2=2*d:=by omega
          have hh':y+2*d∈E:=by simpa [heq] using hh
          exact (mem_sdiff.mp hdG).2 (mem_filter.mpr ⟨hGood hdG,hh'⟩)
        have hp:=pivot_from_even hd he (x:=4*d) (y:=y) (by omega) hy.2.2 hy.1 (by omega) hyE hys
        exact ⟨2*y,hp.1,hp.2,by omega,by omega,by omega⟩
      have hsum:Good.card+Bad.card=(quarterD n B).card :=
        card_sdiff_add_card_eq_card (filter_subset _ _)
      have hc:=capacity_card hf hd he hAo hAn hAl hblock (C:=4)
        (by omega) (by omega) hGood hp
      rcases hc with hc|hc
      · left;dsimp [k,E] at *;omega
      · right;dsimp [k,E] at *;omega
  · have hs3:3 ≤ s:=by omega
    have hp:∀d∈quarterD n B, ∃p, p∈B ∧ p+4*d∈B ∧ 2*n< p ∧ p%4=0 ∧ p≤2*n+12 := by
      intro d hdD
      have hdi:=hdroot d hdD
      obtain ⟨z,hz,hzE,hzs⟩:=three_choices (h:=2*d) (y:=y) hshape hs3
      have hzl:n< z:=by rcases hz with hz|hz|hz <;> omega
      have hzu:z≤ n+6:=by rcases hz with hz|hz|hz <;> omega
      have hzp:z%2=0:=by rcases hz with hz|hz|hz <;> omega
      have hzs' : z+(4*d)/2∉parityMiddle n B 0 := by
        change z+(4*d)/2∉E
        simpa only [show (4*d)/2=2*d by omega] using hzs
      have hb:=pivot_from_even hd he (x:=4*d) (y:=z) (by omega) hzp hzl (by omega)
        hzE hzs' 
      exact ⟨2*z,hb.1,hb.2,by omega,by omega,by omega⟩
    have hc:=capacity_card hf hd he hAo hAn hAl hblock (C:=12)
      (by omega) (by omega) (Subset.refl _) hp
    rcases hc with hc|hc
    · left;omega
    · right;omega

#print axioms global_capacity
end OP02.ZeroExcess

import FrontierSpec
open Finset
namespace OP02.SmallExcess
def residueR (n : ℕ) (B : Finset ℕ) :=
  (OP02.FewHole.lower n B).filter (fun x => x % 4 ≠ 0)
def quarterD (n : ℕ) (B : Finset ℕ) :=
  (Icc 1 (n / 4)).filter (fun x => 4 * x ∈ B)

/-- The retained odd-pivot proof needs only 8e<n, not the large-excess hypothesis. -/
theorem quarter_triple_free (n : ℕ) (B : Finset ℕ)
    (hfour : OP02.FewHole.FourFree B)
    (hsmall : 8 * (OP02.FewHole.excessHoles n B).card < n) :
    Erdos865.IsTripleFree (quarterD n B) := by
  classical
  let E := OP02.FewHole.excessHoles n B
  let D := quarterD n B
  have he : ¬ n ≤ 8 * E.card := by dsimp [E]; omega
  have hDtri : Erdos865.IsTripleFree D := by
    intro htri
    obtain ⟨a, ha, b, hb, c, hc, hab, hac, hbc, habs, hacs, hbcs⟩ := htri
    have haI := Finset.mem_Icc.mp (Finset.mem_filter.mp ha).1
    have hbI := Finset.mem_Icc.mp (Finset.mem_filter.mp hb).1
    have hcI := Finset.mem_Icc.mp (Finset.mem_filter.mp hc).1
    have haB : 4 * a ∈ B := (Finset.mem_filter.mp ha).2
    have hbB : 4 * b ∈ B := (Finset.mem_filter.mp hb).2
    have hcB : 4 * c ∈ B := (Finset.mem_filter.mp hc).2
    have habB : 4 * a + 4 * b ∈ B := by
      simpa only [Nat.mul_add] using (Finset.mem_filter.mp habs).2
    have hacB : 4 * a + 4 * c ∈ B := by
      simpa only [Nat.mul_add] using (Finset.mem_filter.mp hacs).2
    have hbcB : 4 * b + 4 * c ∈ B := by
      simpa only [Nat.mul_add] using (Finset.mem_filter.mp hbcs).2
    have hab4 : 4 * a ≠ 4 * b := by omega
    have hac4 : 4 * a ≠ 4 * c := by omega
    have hbc4 : 4 * b ≠ 4 * c := by omega
    let S : Finset ℕ := {4 * a, 4 * b, 4 * c}
    have hSc : S.card = 3 := by simp [S, hab4, hac4, hbc4]
    have hS : S ⊆ Finset.Icc 1 n := by
      intro x hx
      simp only [S, Finset.mem_insert, Finset.mem_singleton] at hx
      rcases hx with rfl | rfl | rfl
      · exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
      · exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
      · exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
    have hSB : S ⊆ B := by
      intro x hx
      simp only [S, Finset.mem_insert, Finset.mem_singleton] at hx
      rcases hx with rfl | rfl | rfl
      · exact haB
      · exact hbB
      · exact hcB
    have hSeven : ∀ x ∈ S, x % 2 = 0 := by
      intro x hx
      simp only [S, Finset.mem_insert, Finset.mem_singleton] at hx
      rcases hx with rfl | rfl | rfl <;> omega
    have hpair : ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ B := by
      intro x hx y hy hxy
      simp only [S, Finset.mem_insert, Finset.mem_singleton] at hx hy
      rcases hx with rfl | rfl | rfl <;>
        rcases hy with rfl | rfl | rfl <;> simp_all [add_comm]
    have hzero : (0 : ℕ) ∉ S := by
      intro hz
      have hzI := Finset.mem_Icc.mp (hS hz)
      omega
    let U : Finset ℕ := insert 0 S
    have hUc : U.card = 4 := by simp [U, hzero, hSc]
    let J : Finset ℕ := Finset.Icc 1 ((n + 1) / 2)
    have oddHole (z : ℕ) (hz1 : 2 * n + 1 ≤ z) (hz4 : z ≤ 4 * n)
        (hzodd : z % 2 = 1) (hzB : z ∉ B) : z ∈ E := by
      change z ∈ (Finset.Icc (2 * n + 1) (4 * n) \ B) \
        (OP02.FewHole.middle n B).image (fun x => 2 * x)
      refine Finset.mem_sdiff.mpr ⟨Finset.mem_sdiff.mpr
        ⟨Finset.mem_Icc.mpr ⟨hz1, hz4⟩, hzB⟩, ?_⟩
      intro hz
      obtain ⟨q, hq, hqz⟩ := Finset.mem_image.mp hz
      omega
    have hcover : ∀ j ∈ J, ∃ u ∈ U, (2 * n + 2 * j - 1) + u ∈ E := by
      intro j hj
      have hjI : j ∈ Finset.Icc 1 ((n + 1) / 2) := hj
      obtain ⟨hj1, hj2⟩ := Finset.mem_Icc.mp hjI
      let p : ℕ := 2 * n + 2 * j - 1
      have hp1 : 2 * n + 1 ≤ p := by dsimp [p]; omega
      have hp3 : p ≤ 3 * n := by dsimp [p]; omega
      have hpodd : p % 2 = 1 := by dsimp [p]; omega
      have hno : ¬ (p ∈ B ∧ ∀ x ∈ S, p + x ∈ B) := by
        rintro ⟨hpB, hsum⟩
        have hpS : p ∉ S := by
          intro hp
          have hpI := Finset.mem_Icc.mp (hS hp)
          omega
        apply hfour
        refine ⟨insert p S, Finset.insert_subset hpB hSB, ?_, ?_⟩
        · simp [hpS, hSc]
        · intro x hx y hy hxy
          rcases Finset.mem_insert.mp hx with hxp | hxS
          · subst x
            rcases Finset.mem_insert.mp hy with hyp | hyS
            · exact (hxy hyp.symm).elim
            · exact hsum y hyS
          · rcases Finset.mem_insert.mp hy with hyp | hyS
            · subst y
              simpa [add_comm] using hsum x hxS
            · exact hpair x hxS y hyS hxy
      by_cases hpB : p ∈ B
      · by_cases hlink : ∀ x ∈ S, p + x ∈ B
        · exact False.elim (hno ⟨hpB, hlink⟩)
        · push_neg at hlink
          obtain ⟨x, hx, hpx⟩ := hlink
          have hxb := Finset.mem_Icc.mp (hS hx)
          have hxe := hSeven x hx
          refine ⟨x, ?_, ?_⟩
          · change x ∈ insert 0 S
            exact Finset.mem_insert_of_mem hx
          · change p + x ∈ E
            exact oddHole (p + x) (by omega) (by omega) (by omega) hpx
      · refine ⟨0, ?_, ?_⟩
        · simp [U]
        · change p + 0 ∈ E
          simpa only [Nat.add_zero] using oddHole p hp1 (by omega) hpodd hpB
    have hJsub : J ⊆ (U.product E).image
        (fun z : ℕ × ℕ => (z.2 - z.1 - 2 * n + 1) / 2) := by
      intro j hj
      obtain ⟨u, hu, hzu⟩ := hcover j hj
      refine Finset.mem_image.mpr
        ⟨(u, (2 * n + 2 * j - 1) + u),
          Finset.mem_product.mpr ⟨hu, hzu⟩, ?_⟩
      have hj1 := (Finset.mem_Icc.mp hj).1
      change (((2 * n + 2 * j - 1) + u - u - 2 * n + 1) / 2) = j
      omega
    have hJbound : J.card ≤ 4 * E.card := by
      calc
        J.card ≤ ((U.product E).image
            (fun z : ℕ × ℕ => (z.2 - z.1 - 2 * n + 1) / 2)).card :=
          Finset.card_le_card hJsub
        _ ≤ (U.product E).card := Finset.card_image_le
        _ = 4 * E.card := by rw [Finset.product_eq_sprod, Finset.card_product, hUc]
    have hJcard : J.card = (n + 1) / 2 := by
      dsimp [J]
      rw [Nat.card_Icc]
      omega
    rw [hJcard] at hJbound
    have hbad : n ≤ 8 * E.card := by omega
    exact he hbad
  exact hDtri

/-- A pivot divisible by four which is a free hole forces a missing lower point. -/
theorem free_four_pivot_excludes_quarter (n v : ℕ) (B : Finset ℕ)
    (hdbl : OP02.FewHole.DoublingFree B)
    (hhole : 4 * v ∈ OP02.FewHole.holes n B)
    (hexcess : 4 * v ∉ OP02.FewHole.excessHoles n B) : v ∉ B := by
  classical
  have him : 4 * v ∈ (OP02.FewHole.middle n B).image (fun x => 2*x) := by
    by_contra h
    exact hexcess (Finset.mem_sdiff.mpr ⟨hhole,h⟩)
  obtain ⟨q,hq,hqv⟩ := Finset.mem_image.mp him
  have hqb : q ∈ B := (Finset.mem_inter.mp hq).1
  have hqeq : q = 2*v := by omega
  rw [hqeq] at hqb
  exact fun hv => hdbl v hv hqb
end OP02.SmallExcess

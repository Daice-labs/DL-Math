import K7CompleteO2
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask
set_option maxHeartbeats 1400000

private theorem four_max {a c b z v:ℕ} (ac:a<c) (cb:c<b) (bz:b<z) (hv:v∈({a,c,b,z}:Finset ℕ)):v≤z:=by
  simp only [mem_insert,mem_singleton] at hv;omega
private theorem parity_other {v:ℕ} (h:v%2≠1):v%2=0:=by omega
private theorem upper_ge {v w n:ℕ} (h:v≤n/4) (g:n/2<w):v≤w+1:=by omega
private theorem occupied_half {n y z:ℕ} {B:Finset ℕ} (yo:y%2=1)
    (hi:2*(y+4*z)≤n) (slot:y+4*z∉emptyPairs n B) (bad:2*(y+4*z)∉B) : y+4*z∈B:=by
  by_contra no;apply slot
  exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,hi,no,bad⟩
private theorem upper_ne {n w s:ℕ} (wl:n/2<w) (hs:s≤n/4) : ¬w+1≤ s:=by omega
/-- A single even member of residue two forces the common half, regardless
of the residues of the other four vertices. The auxiliary w is one below
the physical even vertex and every translated test is in the same B. -/
theorem four_odd_rows (hD:Dousse7) {i:ℕ} (hi:i=18 ∨ i=19 ∨ i=20 ∨ i=21) : RowExclusion i:=by
  classical
  intro β hb
  obtain ⟨U,hU⟩:=inventory_uniform β hb
  obtain ⟨V,hV⟩:=uniform_window_threshold β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  obtain ⟨G,hG⟩:=padded_inventory hb
  refine ⟨max (4*2^23) (max U (max V (max W G))),?_⟩
  intro n hn B sub hf hd hg S hs row
  have state:(oddOffsets S).card=4 ∧ ¬evenZero S:=by
    unfold rowNumber at row;dsimp only at row
    split_ifs at row <;> first | omega | exact ⟨by omega,by assumption⟩
  have part:=parity_partition S
  have evOne:(evenOffsets S).card=1:=by have :=hs.1;omega
  obtain ⟨x,xe⟩:=card_eq_one.mp evOne
  have xE:x∈evenOffsets S:=by simp [xe]
  obtain ⟨sx,xeven⟩:=mem_filter.mp xE
  have allEven (v:ℕ) (hv:v∈S) (ev:v%2=0):v=x:=
    mem_singleton.mp (xe ▸ (mem_filter.mpr ⟨hv,ev⟩ : v∈evenOffsets S))
  have xr:x%4=2:=by
    by_contra no;apply state.2;intro v hv ev;rw [allEven _ hv ev];omega
  let s:=S.max' ⟨x,sx⟩
  have sm:s∈S:=max'_mem _ _
  have bounds (v:ℕ) (hv:v∈S) : v≤ s ∧ v≤n/4:=⟨le_max' _ _ hv,(mem_Icc.mp (mem_inter.mp (hs.2.1 hv)).2).2⟩
  have sHi:s+1≤n/4:=by
    obtain ⟨v,vs,vn⟩ : ∃v∈S,v≠ s:=by
      by_contra! no
      have sb:S⊆{s}:=fun v hv=>mem_singleton.mpr (no v hv)
      have sz:=card_le_card sb;rw [card_singleton] at sz;have :=hs.1;omega
    have cap:=(mem_Icc.mp (mem_inter.mp (hs.2.2 v vs s sm vn)).2).2
    have pos:=(mem_Icc.mp (mem_inter.mp (hs.2.1 vs)).2).1;omega
  let E:=(oddOffsets S).image (fun v=>v+1)
  have four:E.card≤4:=(card_image_le).trans state.1.le
  have ev (v:ℕ) (hv:v∈E):v%2=0 ∧ v≤ s+1:=by
    obtain ⟨j,jh,rfl⟩:=mem_image.mp hv;obtain ⟨js,jr⟩:=mem_filter.mp jh;have :=(bounds j js).1;omega
  obtain ⟨cap,large⟩:=hU n (by omega) B hd hg
  obtain ⟨_,hl⟩:=hV n (by omega)
  have gap:=hW n (by omega) B hf hd hg
  have pad:=hG n (by omega) B hd hg
  let H:=n/4
  let L:=(quarterMissing H (quarterD n B)).card
  let O:=(oddTopMissing H (quarterD n B)).card
  let q:=totalBudget n B
  have own:=actual_quarter_top_joint n B hd
  have joint:384*(L+O+q)+10000*logLevels H+300000≤H:=by dsimp only [L,O,q,H];omega
  obtain ⟨a,c,b,z,ap,ac,cb,bz,bd,zlo,zu,rzH,ra,rc,rb,rz,rac,rba,rbc,rza,rzc,rzb⟩:=compact_actual_quartet hd hg hl pad
  have geom:=fitted_quartet_geometry (p:=1) (n:=n) rfl joint bd sHi (by omega) (by omega) zlo zu rzH
  obtain ⟨y,w,ystart,yl,yu,yo,wl,wu,wo,we,wxb,slot,slotHi,direct,high⟩:=
    pair_half_selection_fitted (p:=1) (x:=x+1) hd (by omega) rfl (by omega) (by omega) (by omega)
      (by have :=(bounds x sx).1;omega) sHi ac cb bz (by omega) four ev geom.1
  have exactFit:=geom.2 y w ystart we
  have τ:favTau n B≤4*q+8:=by
    have h:=missingTopOdd_le_deficit n B hd;dsimp only [favTau,q];unfold totalBudget;omega
  let T:Finset ℕ:={a,c,b,z}
  have nt:T.card=4:=by simp [T,show a≠c by omega,show a≠b by omega,show a≠z by omega,
    show c≠b by omega,show c≠z by omega,show b≠z by omega]
  have inT:internalOn (quarterD n B) T:=by
    constructor
    · intro v hv;simp only [T,mem_insert,mem_singleton] at hv
      rcases hv with rfl|rfl|rfl|rfl <;> assumption
    · intro v hv j hj ne;simp only [T,mem_insert,mem_singleton] at hv hj
      rcases hv with rfl|rfl|rfl|rfl <;> rcases hj with rfl|rfl|rfl|rfl <;>
        first | exact (ne rfl).elim | assumption | rw [Nat.add_comm];assumption
  have Tmax (v:ℕ) (hv:v∈T):v≤z:=four_max ac cb bz hv
  let W:=w+1
  have Weq:W=2*(y+4*z):=we
  have wS:W∉S:=fun hi=>upper_ne wl (bounds W hi).2 (le_refl _)
  have old:internalOn B S:=⟨fun _ h=>(mem_inter.mp (hs.2.1 h)).1,
    fun u hu v hv ne=>(mem_inter.mp (hs.2.2 u hu v hv ne)).1⟩
  have bad:2*(y+4*z)∉B:=by
    intro double
    have wB:W∈B:=Weq.symm ▸ double
    have six:=append_clique old wB (show ∀v∈S,W+v∈B from by
      intro v hv
      by_cases v₁:v=x
      · subst v;simpa [W,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using wxb
      have odd:v∈oddOffsets S:=mem_filter.mpr ⟨hv,by by_contra no;exact v₁ (allEven _ hv (parity_other no))⟩
      have :=high (v+1) (mem_image.mpr ⟨v,odd,rfl⟩)
      simpa [W,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using this)
    have sz:(insert W S).card=6:=by simp [card_insert_of_notMem wS,hs.1]
    apply flexible_favorable_six (f:=0) (W:=W) hf hd gap large (cutoff_q cap) nt inT Tmax
      (cutoff_z rzH) six sz _ (Nat.zero_le _) _ (cutoff_tau_succ τ exactFit)
    · intro v hv;rcases mem_insert.mp hv with rfl|small
      · exact le_refl _
      · exact upper_ge (bounds v small).2 wl
    · intro v hv ve ne
      rcases mem_insert.mp hv with eq|others
      · exact (ne eq).elim
      · rcases mem_insert.mp others with eq|small
        · subst v;exact even_forced_residue yo Weq
        · rw [allEven v small ve,xr];decide
  have yes:=occupied_half yo slotHi slot bad
  apply selected_common_half_impossible hf hd gap large cap ac cb bz (cutoff_z rzH) yu yo
    ra rc rb rz rac rba rbc rza rzc rzb (by simpa using direct 0 (by simp))
  intro v hv;simp only [mem_insert,mem_singleton] at hv
  rcases hv with rfl|rfl|rfl|rfl <;> first | exact yes | exact direct _ (by simp)

end OP02.SharpK7.LongOddTask

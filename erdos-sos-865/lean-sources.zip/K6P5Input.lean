import K6Endpoint
open Finset Filter
open scoped Asymptotics
namespace OP02.SharpK6
/-- The k4 input to k5 is uniform over every actual OP02.SharpK5.FiveFree set. -/
theorem fivefree_uniform (hD : OP02.SharpK5.Dousse5) (ε:ℝ) (hε:0<ε) :
    ∃N₀:ℕ,∀N:ℕ,N₀≤N→∀A:Finset ℕ,A⊆Icc 1 N→OP02.SharpK5.FiveFree A→
      (A.card:ℝ)≤(85/128:ℝ)*N+ε*N := by
  have hg := OP02.SharpK5.complete_k5_endpoint hD
  change Asymptotics.IsLittleO atTop
    (fun N:ℕ=>(Erdos865.f N 5:ℝ)-(85/128:ℝ)*N)
    (fun N:ℕ=>(85/128:ℝ)*N) at hg
  have he := Asymptotics.isLittleO_iff.mp hg (show 0<ε/(85/128) from by positivity)
  obtain ⟨N₀,hN₀⟩ := eventually_atTop.mp he
  refine ⟨N₀,?_⟩
  intro N hN A hs hf
  have hc : A.card<Erdos865.f N 5 := by
    by_contra hh
    exact hf (OP02.SharpK4.threshold_spec N 5 A hs (by omega))
  have hcr : (A.card:ℝ)<(Erdos865.f N 5:ℝ) := by exact_mod_cast hc
  have hh := hN₀ N hN
  have hnn : (0:ℝ)≤(85/128:ℝ)*N := by positivity
  change ‖(Erdos865.f N 5:ℝ)-(85/128:ℝ)*N‖≤(ε/(85/128))*‖(85/128:ℝ)*N‖ at hh
  simp only [Real.norm_eq_abs,abs_of_nonneg hnn] at hh
  have := (abs_le.mp hh).2
  nlinarith


#print axioms fivefree_uniform
end OP02.SharpK6

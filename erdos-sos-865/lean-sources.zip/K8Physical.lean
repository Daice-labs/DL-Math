import K8Budget
import K8Selection

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK8

/-- The two physical images needed for a missing canonical control after removing excess holes. -/
def controlLoss (n : ℕ) (B : Finset ℕ) : Finset ℕ :=
  (((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x)) ∪
  ((topMissing (n/4) (quarterD n B)).image (fun x=>16*x))

theorem control_loss_card (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    (controlLoss n B).card ≤ (missingTopOdd n B).card + chainDeficit n B := by
  have cm := middle_two_le_singleton n B hd
  have top := chain_capacity_with_top_loss (n/4) (quarterD n B)
    (filter_subset _ _) (quarter_doubling_free n B hd)
  unfold controlLoss chainDeficit
  apply (card_union_le _ _).trans
  exact Nat.add_le_add (le_trans card_image_le cm) (le_trans card_image_le (by omega))

theorem missing_control {n x : ℕ} {B : Finset ℕ} (hd : DoublingFree B)
    (bounds : 2*n<x ∧ x≤4*n) (res : x%8=4 ∨ x%32=16)
    (notE : x ∉ excessHoles n B) (miss : x ∉ B) : x ∈ controlLoss n B := by
  have hc : canonical x=true := by
    rcases res with r|r
    · exact canonical_four_residue _ r
    · have eq : 4*(x/4)=x := by omega
      rw [←eq,canonical_four]
      exact canonical_four_residue _ (by omega)
  have mem : x∈canonicalHoles n B := mem_filter.mpr ⟨mem_sdiff.mpr
    ⟨mem_Icc.mpr ⟨by omega,bounds.2⟩,miss⟩,hc⟩
  have hh := canonical_hole_cover n B hd mem
  rcases mem_union.mp hh with h|h
  · exact mem_union_left _ ((mem_union.mp h).resolve_left notE)
  · exact mem_union_right _ h

theorem half_of_missing {n x : ℕ} {B : Finset ℕ} (bounds : 2*n<x ∧ x≤4*n)
    (notE : x∉excessHoles n B) (miss : x∉B) : x%2=0 ∧ x/2∈B := by
  have hole : x∈holes n B := mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,bounds.2⟩,miss⟩
  have h : x∈(middle n B).image (fun a=>2*a) := by
    by_contra h;exact notE (mem_sdiff.mpr ⟨hole,h⟩)
  obtain ⟨a,ha,rfl⟩ := mem_image.mp h
  exact ⟨by omega,by simpa using (mem_inter.mp ha).1⟩

theorem physical_of_windows {n z : ℕ} {B S V T C P : Finset ℕ}
    (sub : B ⊆ Icc 1 (4*n)) (hd : DoublingFree B)
    (hn : 8≤n) (hcap : 1536*(chainDeficit n B+totalBudget n B)<n/4)
    (seed : Internal 7 (B ∩ Icc 1 n) S)
    (hV : V.card=5) (six : Internal 6 B (insert z V)) (even : ∀x∈insert z V, x%2=0)
    (small : ∀x∈insert z V, x≤n)
    (pb : ∀ p∈P, 2*n<p ∧ p≤3*n)
    (opp : ∀ p∈P, ∀a∈insert 0 S, a∉T → a∉C → (p+a)%2=1)
    (controls : ∀p∈P,∀c∈C,(p+c)%8=4 ∨ (p+c)%32=16)
    (target : ∀p∈P,∀t∈T, (p+t)%4=2 ∧ n<2*((p+t)/2-z) ∧
      ∀x∈insert 0 V, (p+t)/2-z+x≤n)
    (supply : max 8 (6*T.card+C.card) * totalBudget n B +
        C.card * chainDeficit n B < P.card) : ∃ Z, Internal 8 B Z := by
  classical
  let U := insert 0 S
  let W := insert 0 V
  let E := excessHoles n B
  let O := missingTopOdd n B
  let side := controlLoss n B
  let up := rejected P U E (fun a p=>p+a)
  let mid := rejected P C side (fun a p=>p+a)
  let highs (t:ℕ) := rejected P W O (fun y p=>(p+t)/2-z+y)
  let allHigh := T.biUnion highs
  have uv (a:ℕ) (ha:a∈U) : a≤n := by
    rcases mem_insert.mp ha with h|h
    · omega
    · exact (mem_Icc.mp (mem_inter.mp (seed.1 h)).2).2
  have n0 : 0 ∉ S := by
    intro h;have := (mem_Icc.mp (mem_inter.mp (seed.1 h)).2).1;omega
  have z0 : 0 ∉ V := by
    intro h;have := (mem_Icc.mp (sub (six.1 (mem_insert_of_mem h)))).1;omega
  have nU : U.card=8 := by simp [U,n0,seed.2.1]
  have nW : W.card=6 := by simp [W,z0,hV]
  have uc := rejected_card P U E (fun a p=>p+a) (fun a _ x _ y _ he=>by dsimp at he;omega)
  have mc := rejected_card P C side (fun a p=>p+a) (fun a _ x _ y _ he=>by dsimp at he;omega)
  change up.card ≤ U.card * E.card at uc
  change mid.card ≤ C.card * side.card at mc
  rw [nU] at uc
  have each (t:ℕ) (ht:t∈T) : (highs t).card ≤ 6*O.card := by
    rw [←nW]
    apply rejected_card
    intro a ha x hx y hy he
    have hx' := target x hx t ht
    have hy' := target y hy t ht
    change (x+t)/2-z+a=(y+t)/2-z+a at he
    omega
  have ac : allHigh.card ≤ T.card*(6*O.card) := by
    calc
      allHigh.card ≤ ∑ t∈T, (highs t).card := card_biUnion_le
      _ ≤ ∑ _t∈T, 6*O.card := sum_le_sum each
      _ = T.card*(6*O.card) := by simp
  let bad := up ∪ mid ∪ allHigh
  have bound : bad.card ≤ up.card + mid.card + allHigh.card :=
    (card_union_le _ _).trans (Nat.add_le_add_right (card_union_le _ _) _)
  have sidele : side.card ≤ O.card + chainDeficit n B := control_loss_card n B hd
  have ex := deficit_split n B hd
  have EO : E.card + O.card ≤ totalBudget n B := by
    dsimp [E,O,totalBudget]; omega
  let m := max 8 (6*T.card+C.card)
  have leE : 8*E.card ≤ m*E.card := Nat.mul_le_mul_right _ (le_max_left _ _)
  have leO : (6*T.card+C.card)*O.card ≤ m*O.card := Nat.mul_le_mul_right _ (le_max_right _ _)
  have cm' := Nat.mul_le_mul_left C.card sidele
  have ctotal := Nat.mul_le_mul_left m EO
  have cheap : bad.card ≤ m*totalBudget n B + C.card*chainDeficit n B := by
    rw [Nat.mul_add] at cm' ctotal
    rw [Nat.add_mul] at leO
    have assoc : T.card*(6*O.card) = 6*T.card*O.card := by ring
    omega
  have less := lt_of_le_of_lt cheap supply
  obtain ⟨p,hp,keep⟩ := exists_mem_notMem_of_card_lt_card less
  have k1 : p∉up := fun h=>keep (mem_union_left _ (mem_union_left _ h))
  have k2 : p∉mid := fun h=>keep (mem_union_left _ (mem_union_right _ h))
  have k3 : p∉allHigh := fun h=>keep (mem_union_right _ h)
  have ep (a:ℕ) (ha:a∈U) : p+a∉E := fun h=>k1 (mem_rejected.mpr ⟨a,ha,hp,h⟩)
  have rng (a:ℕ) (ha:a∈U) : 2*n<p+a ∧ p+a≤4*n := by have := uv a ha;have := pb p hp; omega
  by_cases full : ∀a∈U, p+a∈B
  · have pp : p∈B := by simpa using full 0 (mem_insert_self _ _)
    have fresh : p∉S := by intro h;have := uv p (mem_insert_of_mem h);have := pb p hp;omega
    exact ⟨_,internal_insert (internal_mono seed inter_subset_left) pp fresh (fun x hx=>full x (mem_insert_of_mem hx))⟩
  · push_neg at full
    obtain ⟨t,tu,abs⟩ := full
    obtain ⟨isEven,half⟩ := half_of_missing (rng t tu) (ep t tu) abs
    have ht : t∈T := by
      by_contra nt
      by_cases cc : t∈C
      · exact k2 (mem_rejected.mpr ⟨t,cc,hp,missing_control hd (rng t tu) (controls p hp t cc) (ep t tu) abs⟩)
      · have := opp p hp t tu nt cc;omega
    let v := (p+t)/2-z
    have bounds := target p hp t ht
    have odd : v%2=1 := by have := even z (mem_insert_self _ _);dsimp [v]; omega
    have high (a:ℕ) (ha:a∈W) : v+a∈B := by
      by_contra h
      have aev : a%2=0 := by
        rcases mem_insert.mp ha with h|h
        · omega
        · exact even a (mem_insert_of_mem h)
      have low : n<2*(v+a) := by dsimp [v]; omega
      have upper := bounds.2.2 a ha
      have hole : v+a ∈ O := mem_filter.mpr ⟨mem_filter.mpr
        ⟨mem_Icc.mpr ⟨by omega,upper⟩,by omega⟩,low,h⟩
      exact k3 (mem_biUnion.mpr ⟨t,ht,mem_rejected.mpr ⟨a,ha,hp,hole⟩⟩)
    have vv : v∈B := by simpa using high 0 (mem_insert_self _ _)
    have edges : ∀a∈insert z V, v+a∈B := by
      intro a ha
      rcases mem_insert.mp ha with az|av
      · have eq : v+a=(p+t)/2 := by dsimp [v]; omega
        exact eq.symm ▸ half
      · exact high a (mem_insert_of_mem av)
    have vn : v≤n := by simpa [v] using bounds.2.2 0 (mem_insert_self _ _)
    exact finish_six_odd hd hn hcap six even (fun x hx=>⟨(mem_Icc.mp (sub (six.1 hx))).1,small x hx⟩) vv odd vn edges

end OP02.SharpK8

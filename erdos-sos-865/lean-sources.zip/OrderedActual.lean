import Staircase
open Finset
namespace OP02.SharpK4
noncomputable section
set_option maxHeartbeats 2000000
noncomputable def enumActual (S : Finset ℕ) (i : ℕ) : ℕ :=
  if h : i < S.card then S.orderEmbOfFin rfl ⟨i,h⟩ else S.sup id + 1 + i

theorem enumActual_mem (S : Finset ℕ) {i : ℕ} (hi : i < S.card) :
    enumActual S i ∈ S := by
  simp only [enumActual,dif_pos hi]
  exact S.orderEmbOfFin_mem rfl _

theorem enumActual_strict (S : Finset ℕ) : StrictMono (enumActual S) := by
  intro i j hij
  by_cases hi : i < S.card
  · by_cases hj : j < S.card
    · simp only [enumActual,dif_pos hi,dif_pos hj]
      exact (S.orderEmbOfFin rfl).strictMono hij
    · have hb : enumActual S i ≤ S.sup id := le_sup (f:=id) (enumActual_mem S hi)
      simp only [enumActual,dif_pos hi] at hb
      simp only [enumActual,dif_pos hi,dif_neg hj]
      omega
  · have hj : ¬ j < S.card := by omega
    simp only [enumActual,dif_neg hi,dif_neg hj]
    omega

theorem enumActual_surj (S : Finset ℕ) {z : ℕ} (hz : z ∈ S) :
    ∃ i, i < S.card ∧ enumActual S i = z := by
  have hh : z ∈ Set.range (S.orderEmbOfFin (k:=S.card) rfl) := by
    simpa only [S.range_orderEmbOfFin rfl, mem_coe] using hz
  obtain ⟨i,hi⟩ := hh
  refine ⟨i.val,i.isLt,?_⟩
  simpa only [enumActual,dif_pos i.isLt] using hi

theorem no_actual_between (S : Finset ℕ) {i z : ℕ} (hz : z ∈ S)
    (hlo : enumActual S i < z) (hhi : z < enumActual S (i+1)) : False := by
  obtain ⟨j,hj,rfl⟩ := enumActual_surj S hz
  have h1 : i < j := (enumActual_strict S).lt_iff_lt.mp hlo
  have h2 : j < i+1 := (enumActual_strict S).lt_iff_lt.mp hhi
  omega

def goodIndices (S B : Finset ℕ) : Finset ℕ :=
  (range (S.card-1)).filter (fun i => enumActual S i + enumActual S (i+1) ∈ B)
def badIndices (S B : Finset ℕ) : Finset ℕ :=
  (range (S.card-1)).filter (fun i => enumActual S i + enumActual S (i+1) ∉ B)

theorem indices_partition (S B : Finset ℕ) :
    S.card ≤ (goodIndices S B).card + (badIndices S B).card + 1 := by
  classical
  have hu : goodIndices S B ∪ badIndices S B = range (S.card-1) := by
    ext i
    simp only [goodIndices,badIndices,mem_union,mem_filter]
    tauto
  have hd : Disjoint (goodIndices S B) (badIndices S B) := by
    apply disjoint_left.mpr
    intro i hi hj
    exact (mem_filter.mp hj).2 (mem_filter.mp hi).2
  have h := card_union_of_disjoint hd
  rw [hu,card_range] at h
  omega

theorem adjacent_sum_strict (S : Finset ℕ) :
    StrictMono (fun i => enumActual S i + enumActual S (i+1)) := by
  intro i j hij
  have h1 := enumActual_strict S hij
  have h2 := enumActual_strict S (show i+1<j+1 by omega)
  dsimp only
  omega

theorem bad_indices_bound (S B K : Finset ℕ)
    (hmap : ∀ i ∈ badIndices S B, enumActual S i + enumActual S (i+1) ∈ K) :
    (badIndices S B).card ≤ K.card := by
  classical
  exact card_le_card_of_injOn (fun i => enumActual S i + enumActual S (i+1))
    hmap (adjacent_sum_strict S).injective.injOn

#print axioms enumActual_strict
#print axioms no_actual_between
#print axioms indices_partition
#print axioms bad_indices_bound
end
end OP02.SharpK4

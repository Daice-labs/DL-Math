import K7CanonicalStar
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7
set_option maxHeartbeats 700000

def starLo (H k b η:ℕ):=max (H/8) (b+(k+η+8)/4)
def starHi (H s k b η:ℕ):=min (H/4-b) ((3*H+2*k-s-2*(η+8))/8)
def halfLo (H k z:ℕ):=max (H/2) (H+k-4*z)
def halfHi (H s k b z:ℕ):=min (H-4*b) ((4*H+2*k-s)/2-4*z)

/-- Coefficient form of the candidate count, with the incomplete
modulus-128 block paid once. Each of the four pairs of cut endpoints
is checked. Rounding is handled in natural numbers. -/
private theorem bridge_width {H s k b κ q O L η:ℕ} (hn:2^23≤H)
    (hs:s≤H) (hk:4*k≤H) (hb:b≤3*(H/64)+1) (hc:384*(κ+q)≤H)
    (hown:L+O≤κ)
    (hη:η≤40*κ+32*q+64 ∨ η≤100*O+16*(κ-O)+64*q+512) :
    3*L<((starHi H s k b η-starLo H k b η)/128)*16 ∧
    2*L<((starHi H s k b η-starLo H k b η)/128)*10 := by
  have e:κ-O+O=κ:=Nat.sub_add_cancel (by omega)
  have budget₁:8192*L+50000≤25*H:=by omega
  have budget₂:4096*L+40*η+23000≤15*H:=by rcases hη with g|g <;> omega
  have budget₃:8192*L+160*η+46000≤65*H:=by rcases hη with g|g <;> omega
  have hη':η+8<H/3:=by rcases hη with g|g <;> omega
  clear e hη hc hown
  let w:ℕ:=(128*L+644)/5
  have wlo:128*L+640≤5*w:=by dsimp [w];omega
  have wup:5*w≤128*L+644:=by dsimp [w];omega
  have hb':64*b≤3*H+64:=by omega
  have diff:H/4-b+b=H/4:=Nat.sub_add_cancel (by omega)
  have num:3*H+2*k-s-2*(η+8)+s+2*(η+8)=3*H+2*k:=by omega
  let a₁:=H/8
  let a₂:=b+(k+η+8)/4
  let b₁:=H/4-b
  let b₂:=(3*H+2*k-s-2*(η+8))/8
  have A₁:8*a₁≤H:=by dsimp [a₁];omega
  have A₂:4*a₂≤4*b+k+η+8:=by dsimp [a₂];omega
  have B₁:H≤4*b₁+4*b+3:=by dsimp [b₁];omega
  have B₂:3*H+2*k≤8*b₂+s+2*(η+8)+7:=by dsimp [b₂];omega
  have aa:a₁+w≤b₁:=by linarith only [A₁,B₁,hb',wup,budget₁]
  have ab:a₂+w≤b₁:=by linarith only [A₂,B₁,hb',wup,budget₂,hk]
  have ba:a₁+w≤b₂:=by linarith only [A₁,B₂,wup,budget₂,hs,Nat.zero_le k]
  have bb:a₂+w≤b₂:=by linarith only [A₂,B₂,hb',wup,budget₃,hs]
  have bound:max a₁ a₂+w≤ min b₁ b₂:=by
    rcases le_total a₁ a₂ with hl|hl
    · rw [max_eq_right hl];exact le_min ab bb
    · rw [max_eq_left hl];exact le_min aa ba
  change starLo H k b η+w≤ starHi H s k b η at bound
  have width:w≤ starHi H s k b η-starLo H k b η:=by omega
  clear budget₁ budget₂ budget₃ wup bound
  omega

private theorem selected_geometry {H s k b z η:ℕ} (hn:2^23≤H) (hs:s≤H) (hk:4*k≤H)
    (hb:b≤3*(H/64)+1) (hη:32*(η+8)≤9*H)
    (hz:starLo H k b η<z) (hu:z≤ starHi H s k b η) :
    H/8<z ∧ z+b≤H/4 ∧ η≤halfHi H s k b z-halfLo H k z := by
  have hlow:=max_lt_iff.mp hz;have hupper:=le_min_iff.mp hu
  have hbh:b≤H/4:=by omega
  have diff:H/4-b+b=H/4:=Nat.sub_add_cancel hbh
  have z₁:H/8<z:=hlow.1
  have z₂:b+(k+η+8)/4<z:=hlow.2
  have z₃:z≤H/4-b:=hupper.1
  have z₄:z≤(3*H+2*k-s-2*(η+8))/8:=hupper.2
  clear hz hu hlow hupper
  have num:3*H+2*k-s-2*(η+8)+s+2*(η+8)=3*H+2*k:=by omega
  have num':4*H+2*k-s+s=4*H+2*k:=by omega
  have za:z+b≤H/4:=by omega
  have zbound:4*z≤H:=by omega
  have s₁:H/2+η≤H-4*b:=by omega
  have s₂:H+k-4*z+η≤H-4*b:=by omega
  have s₃:H/2+η≤(4*H+2*k-s)/2-4*z:=by omega
  have s₄:H+k-4*z+η≤(4*H+2*k-s)/2-4*z:=by omega
  have both:halfLo H k z+η≤ halfHi H s k b z:=by
    unfold halfLo halfHi
    rcases le_total (H/2) (H+k-4*z) with h|h
    · rw [max_eq_right h];exact le_min s₂ s₄
    · rw [max_eq_left h];exact le_min s₁ s₃
  exact ⟨z₁,za,by omega⟩

/-- A single actual triangle is chosen from the physical reflection supply.
In the odd-pair case the tester is itself four times the admitted rigid
owner. The even-pair branch uses its own actual odd tester. -/
theorem physical_triangle_choice {β:ℝ} {n:ℕ} {B:Finset ℕ} (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n) :
    ∃a c b:ℕ,0<a ∧ a<c ∧ c<b ∧ b≤3*(n/4/64)+1 ∧
    ((a%2=0 ∧ c%2=0 ∧ b%2=1) ∨ (a%2=1 ∧ c%2=1 ∧ b%4=0)) ∧
    a∈quarterD n B ∧ c∈quarterD n B ∧ b∈quarterD n B ∧
    a+c∈quarterD n B ∧ b+a∈quarterD n B ∧ b+c∈quarterD n B := by
  obtain ⟨e,he,hee,hmax,w,hw,hj⟩:=many_retained β n B hd hg hscale hl
  obtain ⟨a,ha⟩:=card_pos.mp (show 0<(retainedEndpoints n B e (4*w)).card by omega)
  obtain ⟨hp,hqual⟩:=mem_filter.mp ha
  obtain ⟨haS,ha₀,hac,hcS⟩:=mem_filter.mp hp
  have hN: e≤n/4/64:=(mem_Icc.mp (mem_inter.mp he).2).2
  have heq:a+(e-a)=e:=by omega
  by_cases ho:a%2=0
  · have hc:=ee_margin β n a (e-a) B hd hg (by omega) ha₀ (by omega) (by omega) ⟨ho,by omega⟩
    have hl₀:(0:ℝ)≤logLevels (n/4):=by positivity
    have hΛ:(0:ℝ)≤lambdaBudget n B:=by positivity
    have hpos:0<(evenPairTesters n a (e-a) B).card:=by
      exact_mod_cast (show (0:ℝ)<(evenPairTesters n a (e-a) B).card by linarith only [hc,hl,hl₀,hΛ])
    obtain ⟨b,hb⟩:=card_pos.mp hpos;obtain ⟨hwin,ht⟩:=mem_filter.mp hb
    have hh:=oddTestWindow_mem hwin
    exact ⟨a,e-a,b,ha₀,hac,by omega,hh.2.1,Or.inl ⟨ho,by omega,hh.2.2⟩,
      (mem_inter.mp haS).1,(mem_inter.mp hcS).1,by simpa using ht 0 (by simp),
      heq.symm ▸ (mem_inter.mp he).1,ht a (by simp),ht (e-a) (by simp)⟩
  · have hlab:=hqual.resolve_left ho;have hh:=rigid_bounds (mem_filter.mp hw).1
    exact ⟨a,e-a,4*w,ha₀,hac,by omega,by omega,Or.inr ⟨by omega,by omega,by omega⟩,
      (mem_inter.mp haS).1,(mem_inter.mp hcS).1,(mem_filter.mp hw).2,heq.symm ▸ (mem_inter.mp he).1,hlab.1,hlab.2⟩

/-- Joint first selection for the common-02 and row-5 bridge.
All ten root memberships of the internal quartet refer to this one D;
the next half interval has the promised width before the odd vertex
is selected. The two alternative cutoffs may read the same original budget. -/
theorem actual_bridge_quartet {β:ℝ} {n s k η:ℕ} {B:Finset ℕ} (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hn:2^23≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (hs:s≤n/4) (hk:4*k≤n/4) (hcap:384*(chainDeficit n B+totalBudget n B)≤n/4)
    (hη:η≤40*chainDeficit n B+32*totalBudget n B+64 ∨
      η≤100*(oddTopMissing (n/4) (quarterD n B)).card+
        16*(chainDeficit n B-(oddTopMissing (n/4) (quarterD n B)).card)+64*totalBudget n B+512) :
    ∃a c b z:ℕ,0<a ∧ a<c ∧ c<b ∧ b<z ∧ n/4/8<z ∧ z+b≤n/4/4 ∧
      η≤halfHi (n/4) s k b z-halfLo (n/4) k z ∧
      a∈quarterD n B ∧ c∈quarterD n B ∧ b∈quarterD n B ∧ z∈quarterD n B ∧
      a+c∈quarterD n B ∧ b+a∈quarterD n B ∧ b+c∈quarterD n B ∧
      z+a∈quarterD n B ∧ z+c∈quarterD n B ∧ z+b∈quarterD n B:=by
  obtain ⟨a,c,b,ha,ac,cb,bd,pat,aD,cD,bD,acD,baD,bcD⟩:=physical_triangle_choice hd hg (by omega) hl
  have owners:=actual_quarter_top_joint n B hd
  have widths:=bridge_width hn hs hk bd hcap owners hη
  have bound:=qualified_lower_star hd (l:=starLo (n/4) k b η) ac cb (le_max_left _ _) (u:=starHi (n/4) s k b η) (by
    have h:starHi (n/4) s k b η≤n/4/4-b:=min_le_left _ _
    omega) pat (by
    by_cases ae:a%2=0
    · simpa only [if_pos ae] using widths.1
    · simpa only [if_neg ae] using widths.2)
  obtain ⟨z,l,u,root⟩:=bound
  have e:chainDeficit n B-(oddTopMissing (n/4) (quarterD n B)).card+
      (oddTopMissing (n/4) (quarterD n B)).card=chainDeficit n B:=Nat.sub_add_cancel (by omega)
  have eh:32*(η+8)≤9*(n/4):=by rcases hη with h|h <;> omega
  obtain ⟨lo,up,wid⟩:=selected_geometry hn hs hk bd eh l u
  exact ⟨a,c,b,z,ha,ac,cb,by omega,lo,up,wid,aD,cD,bD,by simpa using root 0 (by simp),
    acD,baD,bcD,root a (by simp),root c (by simp),root b (by simp)⟩

end OP02.SharpK7

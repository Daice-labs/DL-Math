import SmallExcessBridge
open Finset
namespace OP02.PivotAudit
open OP02.FewHole OP02.SmallExcess

def oddSlots (n : ℕ) : Finset ℕ := (Icc 1 n).filter (fun x => x % 2 = 1)
def compress (x : ℕ) : ℕ := if x % 2 = 1 then x else x / 2
def deficit (n : ℕ) (B : Finset ℕ) : ℕ := (n+1)/2 - (residueR n B).card
def missingTopOdd (n : ℕ) (B : Finset ℕ) : Finset ℕ :=
  (oddSlots n).filter (fun v => n < 2*v ∧ v ∉ B)

theorem oddSlots_card (n : ℕ) : (oddSlots n).card = (n+1)/2 := by
  have h : (oddSlots n).card = (Icc 1 ((n+1)/2)).card := by
    apply Finset.card_bij (fun x _ => (x+1)/2)
    · intro x hx
      obtain ⟨hxI,hodd⟩ := mem_filter.mp hx
      obtain ⟨h1,hn⟩ := mem_Icc.mp hxI
      exact mem_Icc.mpr ⟨by omega,by omega⟩
    · intro x hx y hy heq
      have hxo := (mem_filter.mp hx).2
      have hyo := (mem_filter.mp hy).2
      omega
    · intro y hy
      obtain ⟨h1,hn⟩ := mem_Icc.mp hy
      refine ⟨2*y-1,mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega⟩
  rw [h,Nat.card_Icc]
  omega

theorem compression_mem (n : ℕ) (B : Finset ℕ) {x : ℕ} (hx : x ∈ residueR n B) :
    compress x ∈ oddSlots n := by
  obtain ⟨hxL,hx4⟩ := mem_filter.mp hx
  obtain ⟨hxB,hxI⟩ := mem_inter.mp hxL
  obtain ⟨h1,hn⟩ := mem_Icc.mp hxI
  unfold compress
  split_ifs with ho
  · exact mem_filter.mpr ⟨mem_Icc.mpr ⟨h1,hn⟩,ho⟩
  · exact mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩

theorem compression_injective (n : ℕ) (B : Finset ℕ) (hdbl : DoublingFree B) :
    Set.InjOn compress (residueR n B) := by
  intro x hx y hy heq
  have hxB := (mem_inter.mp (mem_filter.mp hx).1).1
  have hyB := (mem_inter.mp (mem_filter.mp hy).1).1
  have hx4 := (mem_filter.mp hx).2
  have hy4 := (mem_filter.mp hy).2
  unfold compress at heq
  split_ifs at heq with hxo hyo hyo
  · exact heq
  · have h : 2*x=y := by omega
    exact False.elim (hdbl x hxB (h.symm ▸ hyB))
  · have h : 2*y=x := by omega
    exact False.elim (hdbl y hyB (h.symm ▸ hxB))
  · omega

theorem residue_card_le (n : ℕ) (B : Finset ℕ) (hdbl : DoublingFree B) :
    (residueR n B).card ≤ (n+1)/2 := by
  have hs : (residueR n B).image compress ⊆ oddSlots n := by
    intro y hy
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hy
    exact compression_mem n B hx
  have h := card_le_card hs
  rw [card_image_of_injOn (compression_injective n B hdbl),oddSlots_card] at h
  exact h

theorem missingTopOdd_le_deficit (n : ℕ) (B : Finset ℕ) (hdbl : DoublingFree B) :
    (missingTopOdd n B).card ≤ deficit n B := by
  let im := (residueR n B).image compress
  have him : im ⊆ oddSlots n := by
    intro y hy
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hy
    exact compression_mem n B hx
  have hs : missingTopOdd n B ⊆ oddSlots n \ im := by
    intro v hv
    obtain ⟨hvo,hnv,hvB⟩ := mem_filter.mp hv
    refine mem_sdiff.mpr ⟨hvo,?_⟩
    intro hvim
    obtain ⟨x,hx,hxv⟩ := mem_image.mp hvim
    have hxB := (mem_inter.mp (mem_filter.mp hx).1).1
    have hxn := (mem_Icc.mp (mem_inter.mp (mem_filter.mp hx).1).2).2
    unfold compress at hxv
    split_ifs at hxv with hxo
    · exact hvB (hxv ▸ hxB)
    · omega
  have h := card_le_card hs
  rw [card_sdiff_of_subset him,oddSlots_card] at h
  have hic : im.card = (residueR n B).card := card_image_of_injOn (compression_injective n B hdbl)
  rw [hic] at h
  exact h

/-- A violation of the fixed-57 tradeoff forces a small joint deficit. -/
theorem violation_small_deficit (n : ℕ) (B : Finset ℕ)
    (hfour : FourFree B) (hdbl : DoublingFree B)
    (hsmall : 32*(excessHoles n B).card < n)
    (hbad : 5*n+8*(excessHoles n B).card+57 <
      8*((residueR n B).card+(quarterD n B).card)) :
    32*(deficit n B+(excessHoles n B).card)<n ∧
      3*(deficit n B+(excessHoles n B).card)<n/8 ∧ 20≤n := by
  have htri := quarter_triple_free n B hfour (by omega)
  have hDsub : quarterD n B ⊆ Icc 1 (n/4) := filter_subset _ _
  have hD := Erdos865.erdos865_upper_bound (n/4) (quarterD n B) hDsub htri
  have hR := residue_card_le n B hdbl
  have hp := lower_card_eq n B
  have hl : (lower n B).card ≤ n := by
    have h := card_le_card (inter_subset_right (s₁ := B) (s₂ := Icc 1 n))
    rw [Nat.card_Icc] at h
    simpa [lower] using h
  unfold deficit
  constructor
  · omega
  constructor
  · omega
  · omega
end OP02.PivotAudit

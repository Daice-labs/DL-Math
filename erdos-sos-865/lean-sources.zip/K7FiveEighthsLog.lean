import K7FiveEighths
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

/-- Count the correction in the exact alternative before changing from
integer log levels to the real binary logarithm. -/
theorem correction_levels (N : ℕ) :
    max (chainCapacity (N/4)-(N/2+3)/3) (chainCapacity (N/4)-(rigidOwners N).card)
      ≤ logLevels N+1 := by
  have hcap:=capacity_log_bound (N/4) N (by omega)
  have hr:=rigid_raw N N (by omega)
  omega

theorem restricted_five_eighths_log {t : ℕ} {Y : Finset ℕ} (ht:0<t) (hs:Y⊆Icc 1 t)
    (hd:DoublingFree Y) (hp:RestrictedClear t Y) :
    (Y.card:ℝ)≤(5/8:ℝ)*t+(3/4:ℝ)*(Real.log (t:ℝ)/Real.log 2)+13/8 := by
  let N:=t/4;let J:=Nat.log 4 N
  let E:=max (chainCapacity (N/4)-(N/2+3)/3) (chainCapacity (N/4)-(rigidOwners N).card)
  have hf:=restricted_five_eighths_exact t Y hs hd hp
  have hb : 8*Y.card≤5*t+13+8*E := by dsimp only [N,E];omega
  have hbr:(8:ℝ)*Y.card≤5*t+13+8*E:=by exact_mod_cast hb
  have hlogtwo:0<Real.log 2 := Real.log_pos (by norm_num)
  have hlogt : 0≤Real.log (t:ℝ):=Real.log_nonneg (by exact_mod_cast (show 1≤t by omega))
  by_cases hn:N<4
  · have hk:chainCapacity (N/4)=0:=by simp [show N/4=0 by omega,chainCapacity,canonicalSlots]
    have hz:E=0:=by simp [E,hk]
    rw [hz,Nat.cast_zero,mul_zero,add_zero] at hbr
    have hratio:=div_nonneg hlogt hlogtwo.le
    linarith
  · have hlev:1≤J := Nat.le_log_of_pow_le (by decide) (by norm_num;omega)
    have hpow:=Nat.pow_log_le_self 4 (show N≠0 by omega)
    have hpt:(4:ℕ)^(J+1)≤t:=by rw [pow_succ];dsimp [J,N] at *;omega
    have hreal:(4:ℝ)^(J+1)≤(t:ℝ):=by exact_mod_cast hpt
    have hlog:=Real.log_le_log (show 0<(4:ℝ)^(J+1) by positivity) hreal
    rw [Real.log_pow,show (4:ℝ)=2*2 by norm_num,Real.log_mul (by norm_num) (by norm_num)] at hlog
    have hjr:(1:ℝ)≤J:=by exact_mod_cast hlev
    have he:=correction_levels N
    have her:(E:ℝ)≤J+2:=by exact_mod_cast he
    have hratio:2*((J:ℝ)+1)≤Real.log (t:ℝ)/Real.log 2 := by
      apply (le_div_iff₀ hlogtwo).mpr
      push_cast at hlog
      nlinarith only [hlog]
    linarith only [hbr,her,hjr,hratio]

theorem five_eighths_log {t : ℕ} {Y : Finset ℕ} (ht:0<t) (hs:Y⊆Icc 1 t)
    (hd:DoublingFree Y) (hp:Profile123 Y) :
    (Y.card:ℝ)≤(5/8:ℝ)*t+(3/4:ℝ)*(Real.log (t:ℝ)/Real.log 2)+13/8 :=
  restricted_five_eighths_log ht hs hd (restricted_of_profile hp)

end OP02.SharpK7

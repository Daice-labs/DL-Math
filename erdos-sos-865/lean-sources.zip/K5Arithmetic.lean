import K5Endpoint
namespace OP02.SharpK5

/-- Recorded clarification: every middle-gap vertex is in the domain of the
7n/4 neighborhood lemma; the rounding term is global. -/
theorem gap_domain (n y : ℕ) (hn : 1024≤n) (hy : y≤2*(n-4*(n/16))) :
    4*y<7*n := by omega

/-- The stronger V bound, not merely V<n/2, validates replacement endpoints. -/
theorem replacement_interval (n V : ℕ) (hn : 1024≤n) (hV : 8*V≤3*n+128) :
    n/2<n-V-1 := by omega

/-- Same-set inventory arithmetic. No geometric supply is assumed or concluded. -/
theorem replacement_budget (δ hi t h e0 e2 e4 e6 : ℕ)
    (ht : t≤hi) (hh : hi≤δ) :
    3*(t+e4+max e2 e6+2*h)+4*hi≤7*(δ+h+e0+e2+e4+e6) := by
  omega

theorem high_vertex_budget (δ hi t h e0 e2 e4 e6 : ℕ)
    (ht : t≤hi) (hh : hi≤δ) :
    24*(t+e4+max e2 e6+2*h)+8*hi+16≤48*(δ+h+e0+e2+e4+e6)+16 := by
  omega

/-- Final real arithmetic after all physical candidate-count inequalities have
been supplied. This theorem does not replace those geometric proofs. -/
theorem replacement_positive (n q κ V hi kstar β ℓ count : ℝ)
    (hn : 1024≤n) (hq : q≤n/128)
    (hk : κ≤n/96-q-β*n+ℓ)
    (hv : V/8=3*kstar+hi+2)
    (hb : 3*kstar+4*hi≤7*q)
    (hcount : n/16-V/8-κ-3*hi-9/8≤count)
    (hmargin : ℓ+4≤β*n) : 0<count := by
  linarith

#print axioms gap_domain
#print axioms replacement_interval
#print axioms replacement_budget
#print axioms high_vertex_budget
#print axioms replacement_positive
end OP02.SharpK5

import K7CompactQuartet
import K7FittedFavorable
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7.LongOddTask

theorem raised_actual_quartet {β:ℝ} {n:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B) (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (pad:384*(chainDeficit n B+totalBudget n B)+10000*logLevels (n/4)+300000≤n/4):
    ∃a c b z:ℕ, 0<a ∧ a<c ∧ c<b ∧ b<z ∧ b≤3*(n/4/64)+1 ∧ 43*(n/4)/320<z ∧
      z≤43*(n/4)/320+26*(quarterMissing (n/4) (quarterD n B)).card+16*logLevels (n/4)+256 ∧
      z+b≤n/4/4 ∧
      a∈quarterD n B ∧ c∈quarterD n B ∧ b∈quarterD n B ∧ z∈quarterD n B ∧
      a+c∈quarterD n B ∧ b+a∈quarterD n B ∧ b+c∈quarterD n B ∧
      z+a∈quarterD n B ∧ z+c∈quarterD n B ∧ z+b∈quarterD n B := by
  obtain ⟨a,c,b,ap,ac,cb,bs,pat,ra,rc,rb,rac,rba,rbc⟩:=physical_triangle_choice hd hg (by omega) hl
  let H:=n/4
  let L:=(quarterMissing H (quarterD n B)).card
  let j:=logLevels H
  let lo:=43*H/320
  let hi:=lo+26*L+16*j+256
  have og:=actual_quarter_top_joint n B hd
  have lcap:384*L+10000*j+300000≤H:=by dsimp only [L,j,H];omega
  have good:hi+b≤H/4:=by change b≤3*(H/64)+1 at bs;dsimp only [hi,lo];omega
  have lower:H/8≤lo:=by dsimp only [lo];omega
  have width:(if a%2=0 then 3 else 2)*L<((hi-lo)/128)*(if a%2=0 then 16 else 10):=by
    dsimp only [hi];split_ifs <;> omega
  obtain ⟨z,lb,ub,roots⟩:=qualified_lower_star hd ac cb lower good pat width
  refine ⟨a,c,b,z,ap,ac,cb,by dsimp only [lo,H] at lb;omega,bs,lb,ub,by omega,ra,rc,rb,by simpa using roots 0 (by simp),
    rac,rba,rbc,roots a (by simp),roots c (by simp),roots b (by simp)⟩

end OP02.SharpK7.LongOddTask

import K5ForcedBands
import K5Progressions
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess
set_option maxHeartbeats 4000000

/-- The actual common root neighborhood of an odd lower edge has no
internal root edge. All failed pivots are charged to one canonical-hole union. -/
theorem root_neighborhood_independent (n u v a b:ℕ) (B:Finset ℕ)
    (hf:FiveFree B) (hu:u∈lower n B) (hv:v∈lower n B)
    (huo:u%2=1) (hvo:v%2=1) (huv:u≠v) (hs:u+v∈B)
    (ha:a∈quarterD n B) (hb:b∈quarterD n B) (hab:a≠b)
    (hua:u+4*a∈B) (hub:u+4*b∈B) (hva:v+4*a∈B) (hvb:v+4*b∈B)
    (hbudget:3*(canonicalHoles n B).card<n/32) : a+b∉quarterD n B := by
  classical
  intro habD
  have huB := (mem_inter.mp hu).1
  have hvB := (mem_inter.mp hv).1
  have huI := mem_Icc.mp (mem_inter.mp hu).2
  have hvI := mem_Icc.mp (mem_inter.mp hv).2
  have haB := (mem_filter.mp ha).2
  have hbB := (mem_filter.mp hb).2
  have haI := mem_Icc.mp (mem_filter.mp ha).1
  have hbI := mem_Icc.mp (mem_filter.mp hb).1
  have habB : 4*a+4*b∈B := by
    simpa only [Nat.mul_add] using (mem_filter.mp habD).2
  let S:Finset ℕ := {u,v,4*a,4*b}
  have hSc:S.card=4 := by
    have h1:u≠4*a := by omega
    have h2:u≠4*b := by omega
    have h3:v≠4*a := by omega
    have h4:v≠4*b := by omega
    have h5:4*a≠4*b := by omega
    simp [S,huv,h1,h2,h3,h4,h5]
  have hSB:S⊆B := by intro x hx; simp only [S,mem_insert,mem_singleton] at hx; rcases hx with rfl|rfl|rfl|rfl <;> assumption
  have hpair:∀x∈S,∀y∈S,x≠y→x+y∈B := by
    intro x hx y hy hxy
    simp only [S,mem_insert,mem_singleton] at hx hy
    rcases hx with rfl|rfl|rfl|rfl <;> rcases hy with rfl|rfl|rfl|rfl <;>
      simp_all only [ne_eq,not_true_eq_false, Nat.add_comm]
  obtain ⟨r,hr0,hra,hrb⟩ := three_residue_selection ⟨0,by omega⟩ ⟨a%8,by omega⟩ ⟨b%8,by omega⟩
  let Y := progression (2*n) (3*n) 32 (4*r.val)
  have hY (p:ℕ) (hp:p∈Y) : 2*n<p ∧ p≤3*n ∧ p%32=4*r.val := by
    obtain ⟨hpI,hpr⟩ := mem_filter.mp hp
    exact ⟨(mem_Ioc.mp hpI).1,(mem_Ioc.mp hpI).2,hpr⟩
  have hcan (p:ℕ) (hp:p∈Y) : canonical p=true ∧ canonical (p+4*a)=true ∧ canonical (p+4*b)=true := by
    have hpR := (hY p hp).2.2
    have hrr := r.isLt
    have h0:(p/4)%8∈({1,3,4,5,7}:Finset ℕ) := by
      have he:(p/4)%8=(r.val+0)%8 := by omega
      rw [he]; exact hr0
    have h1:((p+4*a)/4)%8∈({1,3,4,5,7}:Finset ℕ) := by
      have he:((p+4*a)/4)%8=(r.val+a%8)%8 := by omega
      rw [he]; exact hra
    have h2:((p+4*b)/4)%8∈({1,3,4,5,7}:Finset ℕ) := by
      have he:((p+4*b)/4)%8=(r.val+b%8)%8 := by omega
      rw [he]; exact hrb
    exact ⟨canonical_selected p 0 (by omega) h0,
      canonical_selected (p+4*a) 0 (by omega) h1,
      canonical_selected (p+4*b) 0 (by omega) h2⟩
  have hload:∀j:ℕ,((insert 0 S).filter (fun x=>x%4=j)).card≤3 := by
    intro j
    by_cases hj:j%2=0
    · have hsub:((insert 0 S).filter (fun x=>x%4=j))⊆{0,4*a,4*b} := by
        intro x hx
        obtain ⟨hx,hxr⟩ := mem_filter.mp hx
        simp only [S,mem_insert,mem_singleton] at hx ⊢
        rcases hx with rfl|rfl|rfl|rfl|rfl <;> omega
      have hc := card_le_card hsub
      have hc3:({0,4*a,4*b}:Finset ℕ).card≤3 := card_le_three
      omega
    · have hsub:((insert 0 S).filter (fun x=>x%4=j))⊆{u,v} := by
        intro x hx
        obtain ⟨hx,hxr⟩ := mem_filter.mp hx
        simp only [S,mem_insert,mem_singleton] at hx ⊢
        rcases hx with rfl|rfl|rfl|rfl|rfl <;> omega
      have hc := card_le_card hsub
      have hc2:({u,v}:Finset ℕ).card≤2 := card_le_two
      omega
  have hcover:∀p∈Y,∃s∈insert 0 S,∃h∈canonicalHoles n B,1*p+s=h+0 := by
    intro p hp
    have hpI := hY p hp
    have hc := hcan p hp
    have hpS:p∉S := by
      intro hh
      simp only [S,mem_insert,mem_singleton] at hh
      rcases hh with rfl|rfl|rfl|rfl <;> omega
    obtain ⟨s,hsS,hbad⟩ := four_clique_missing_label B S hf hSB hSc hpair p hpS
    refine ⟨s,hsS,p+s,?_,by omega⟩
    apply mem_filter.mpr
    constructor
    · apply mem_sdiff.mpr
      refine ⟨mem_Icc.mpr ⟨by omega,?_⟩,hbad⟩
      simp only [S,mem_insert,mem_singleton] at hsS
      rcases hsS with rfl|rfl|rfl|rfl|rfl <;> omega
    · simp only [S,mem_insert,mem_singleton] at hsS
      rcases hsS with rfl|rfl|rfl|rfl|rfl
      · simpa using hc.1
      · exact canonical_odd _ (by omega)
      · exact canonical_odd _ (by omega)
      · exact hc.2.1
      · exact hc.2.2
  have hbnd := affine_cover_bound Y (insert 0 S) (canonicalHoles n B) 0 0 1 3 (by omega)
    (fun p hp=>by have hh := hY p hp; omega) hload hcover
  have hl := progression_lower (2*n) (3*n) 32 (4*r.val) (by omega) (by have := r.isLt; omega)
  change (3*n-2*n)/32≤Y.card at hl
  omega

#print axioms root_neighborhood_independent
end OP02.SharpK5

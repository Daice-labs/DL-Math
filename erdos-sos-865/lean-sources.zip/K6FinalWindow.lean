import K6FinalBand
import K6WindowArithmetic
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 4000000

theorem four_membership_loss (Y F B T:Finset ℕ) (σ:ℕ) (hc:T.card=3)
    (hy:∀y ∈ Y,y%4=σ) (hF:∀y ∈ Y,∀t ∈ insert 0 T,y+4*t ∈ F) :
    Y.card ≤ (Y.filter (fun y=>∀t ∈ insert 0 T,y+4*t ∈ B)).card+4*(F\B).card := by
  classical
  let G:=Y.filter (fun y=>∀t ∈ insert 0 T,y+4*t ∈ B)
  let A:=Y\G
  let Q:=(insert 0 T).image (fun t=>4*t)
  have hQc:Q.card ≤ 4:=by
    have h1:=card_image_le (s:=insert 0 T) (f:=fun t:ℕ=>4*t)
    have h2:=card_insert_le 0 T
    dsimp only [Q]; omega
  have hA:A.card ≤ 4*(F\B).card := by
    apply affine_cover_bound A Q (F\B) 0 σ 1 4 (by omega)
    · intro y hyA; exact hy y (mem_sdiff.mp hyA).1
    · intro j; exact le_trans (card_filter_le _ _) hQc
    · intro y hyA
      obtain ⟨hyY,hyG⟩:=mem_sdiff.mp hyA
      have hh:∃t ∈ insert 0 T,y+4*t ∉ B := by
        by_contra h
        push_neg at h
        exact hyG (mem_filter.mpr ⟨hyY,h⟩)
      obtain ⟨t,ht,hbad⟩:=hh
      exact ⟨4*t,mem_image.mpr ⟨t,ht,rfl⟩,y+4*t,mem_sdiff.mpr ⟨hF y hyY t ht,hbad⟩,by omega⟩
  have hpart:=card_sdiff_add_card_eq_card (show G ⊆ Y from filter_subset _ _)
  change A.card+G.card=Y.card at hpart
  change Y.card ≤ G.card+4*(F\B).card
  omega

/-- The common interval and all four shifts are built explicitly; no covering
assignment, partner supply or interval-length inequality is assumed. -/
theorem final_window_upper (n w a b s:ℕ) (B S T:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hg:MiddleGap6 n B)
    (hn:65536 ≤ n) (hq:384*totalBudget n B ≤ n)
    (hS:S ⊆ lower n B) (hSc:S.card=5) (hSp:∀x ∈ S,∀y ∈ S,x ≠ y  →  x+y ∈ B)
    (hw:w ∈ insert 0 S) (ha:a ∈ insert 0 S) (hb:b ∈ insert 0 S)
    (ha4:(2+a)%4=w%4) (hb4:(2+b)%4=w%4)
    (hother:∀t ∈ insert 0 S\{w,a,b},t%2 ≠ w%2)
    (hload:∀r:ℕ,((insert 0 S\{w,a,b}).filter (fun t=>t%4=r)).card ≤ 2)
    (hwB:4*w ≤ 3*n) (hmB:2*max a b ≤ n) (hsB:s ≤ n/16)
    (hT:T ⊆ quarterD n B) (hTc:T.card=3) (hTs:∀t ∈ T,t ≤ s)
    (hTp:∀x ∈ T,∀y ∈ T,x ≠ y  →  x+y ∈ quarterD n B) :
    finalWindowU n (missingTopOdd n B).card w (max a b) s-
      finalWindowL n (missingTopOdd n B).card w ≤ 36*totalBudget n B+4 := by
  classical
  let δ:=(missingTopOdd n B).card
  let L:=finalWindowL n δ w
  let U:=finalWindowU n δ w (max a b) s
  let Y:=fun σ=>progression L U 4 σ
  let G:=fun σ=>(Y σ).filter (fun y=>∀t ∈ insert 0 T,y+4*t ∈ B)
  have hδq:δ ≤ totalBudget n B:=by have:=deficit_split n B hd; dsimp [δ]; unfold totalBudget; omega
  have hY (σ y:ℕ) (hy:y ∈ Y σ):L < y ∧ y ≤ U ∧ y%4=σ := by
    obtain ⟨hyI,hyr⟩:=mem_filter.mp hy
    exact ⟨(mem_Ioc.mp hyI).1,(mem_Ioc.mp hyI).2,hyr⟩
  have hTs0:∀t ∈ insert 0 T,t ≤ s := by
    intro t ht
    rcases mem_insert.mp ht with rfl|ht
    · omega
    · exact hTs t ht
  have hpoint (σ y:ℕ) (hy:y ∈ Y σ) (t:ℕ) (ht:t ∈ insert 0 T) :=
    final_window_point n δ w (max a b) s (totalBudget n B) y t hn hq hδq hwB hmB hsB (hTs0 t ht) (hY σ y hy).1 (hY σ y hy).2.1
  have hshift (σ:ℕ) (hσ:σ=1 ∨ σ=3):∀y ∈ Y σ,∀t ∈ insert 0 T,y+4*t ∈ finalBand n B S w a b σ := by
    intro y hy t ht
    have hp:=hpoint σ y hy t ht
    have hyr:=(hY σ y hy).2.2
    apply mem_filter.mpr
    constructor
    · simp only [forcedBand,mem_filter,mem_Icc]
      refine ⟨⟨by omega,by omega⟩,by omega,?_,by omega⟩
      intro z hz
      have hzn:z ≤ n := by
        rcases mem_insert.mp hz with rfl|hz
        · omega
        · exact (mem_Icc.mp (mem_inter.mp (hS hz)).2).2
      omega
    · intro z hz
      have hzm:z ≤ max a b := by simp only [mem_insert,mem_singleton] at hz; rcases hz with rfl|rfl; exact le_max_left _ _; exact le_max_right _ _
      change 2*n+2*(4*δ+4) < 2*(y+4*t)-w+z ∧ _
      constructor  <;> omega
  have hcost (σ:ℕ) (hσ:σ=1 ∨ σ=3):(Y σ).card ≤ (G σ).card+4*jointBandCost n B := by
    have h1:=four_membership_loss (Y σ) (finalBand n B S w a b σ) B T σ hTc
      (fun y hy=>(hY σ y hy).2.2) (hshift σ hσ)
    have h2:=final_band_bound n w a b σ B S hf hg hS hSc hSp hw ha hb hσ (by omega) (by omega) hother hload
    change (Y σ).card ≤ (G σ).card+4*(finalBand n B S w a b σ\B).card at h1
    omega
  have hlen:U-L ≤ 16*jointBandCost n B+4*(fourResources n B).card+4 := by
    by_contra hlen
    have hbig (σ:ℕ) (hσ:σ=1 ∨ σ=3):(fourResources n B).card < (G σ).card := by
      have hl:=progression_lower L U 4 σ (by simp) (by omega)
      have hc:=hcost σ hσ
      change (U-L)/4 ≤ (Y σ).card at hl
      omega
    obtain ⟨z,hz⟩: (G 3).Nonempty := card_pos.mp (by have:=hbig 3 (Or.inr rfl); omega)
    obtain ⟨hzY,hzB⟩:=mem_filter.mp hz
    have hzpoint:=hpoint 3 z hzY 0 (by simp)
    have hzres:=(hY 3 z hzY).2.2
    have hc:(G 1).card ≤ (fourResources n B).card := by
      apply card_le_card_of_injOn (fun y=>y+z)
      · intro y hy
        obtain ⟨hyY,hyB⟩:=mem_filter.mp hy
        have hypoint:=hpoint 1 y hyY 0 (by simp)
        have hyres:=(hY 1 y hyY).2.2
        have hy0:y ∈ B:=by simpa using hyB 0 (by simp)
        have hz0:z ∈ B:=by simpa using hzB 0 (by simp)
        have hbad:y+z ∉ B := by
          intro hsum
          exact gap_triangle_neighborhood n y z B T hf hd hg hn hq hy0 hz0 (by omega) (by omega) (by omega)
            hypoint.2.2.2.1 hzpoint.2.2.2.1 hsum hT hTc (fun t ht=>le_trans (hTs t ht) hsB) hTp
            (fun t ht=>⟨hyB t (mem_insert_of_mem ht),hzB t (mem_insert_of_mem ht)⟩)
        change y+z ∈ fourResources n B
        apply missing_in_doubled_gap6 n (y+z) B hg (by omega) hbad
        · change 2*n+2*(4*δ+4) < y+z
          omega
        · change y+z < 4*(n-4*(n/16))-2*(4*δ+4)
          omega
      · intro x hx y hy he
        change x+z=y+z at he
        omega
    have :=hbig 1 (Or.inl rfl)
    omega
  have hb:=joint_band_budget n B hd
  change U-L ≤ 36*totalBudget n B+4
  omega

#print axioms four_membership_loss
#print axioms final_window_upper
end OP02.SharpK6

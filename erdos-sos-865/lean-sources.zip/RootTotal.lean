import RootPrefix
open Finset
namespace OP02.EdgeBand
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot

def fullRoots (n:ℕ) (B:Finset ℕ) := (Icc 1 (n/2)).filter (fun x=>4*x∈B)
def middleZero (n:ℕ) (B:Finset ℕ) := (middle n B).filter (fun x=>x%4=0)

theorem full_roots_partition (n:ℕ) (B:Finset ℕ) :
    (fullRoots n B).card=(quarterD n B).card+(middleZero n B).card := by
  let L := (fullRoots n B).filter (fun x=>4*x≤n)
  let U := (fullRoots n B).filter (fun x=>n<4*x)
  have hL:L=quarterD n B := by
    ext x
    simp only [L,fullRoots,quarterD,mem_filter,mem_Icc]
    constructor
    · rintro ⟨⟨⟨h1,h2⟩,hB⟩,hn⟩
      exact ⟨⟨h1,by omega⟩,hB⟩
    · rintro ⟨⟨h1,h2⟩,hB⟩
      exact ⟨⟨⟨h1,by omega⟩,hB⟩,by omega⟩
  have hu:U.image (fun x=>4*x)=middleZero n B := by
    ext z
    constructor
    · intro hz
      obtain ⟨x,hx,rfl⟩:=mem_image.mp hz
      obtain ⟨hxR,hxN⟩:=mem_filter.mp hx
      obtain ⟨hxI,hxB⟩:=mem_filter.mp hxR
      have hx:=mem_Icc.mp hxI
      exact mem_filter.mpr ⟨mem_inter.mpr ⟨hxB,mem_Icc.mpr ⟨by omega,by omega⟩⟩,by omega⟩
    · intro hz
      obtain ⟨hzM,hz4⟩:=mem_filter.mp hz
      obtain ⟨hzB,hzI⟩:=mem_inter.mp hzM
      have hr:=mem_Icc.mp hzI
      refine mem_image.mpr ⟨z/4,mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,?_⟩,by omega⟩,by omega⟩
      have he:4*(z/4)=z:=by omega
      rw [he];exact hzB
  have hc:U.card=(middleZero n B).card := by
    rw [←hu,card_image_of_injective]
    intro x y h;dsimp only at h;omega
  have hpart:L∪U=fullRoots n B := by
    ext x
    simp only [L,U,mem_union,mem_filter]
    constructor
    · rintro (⟨h,_⟩|⟨h,_⟩) <;> exact h
    · intro h
      by_cases hx:4*x≤n
      · exact Or.inl ⟨h,hx⟩
      · exact Or.inr ⟨h,by omega⟩
  have hd:Disjoint L U := by
    apply disjoint_left.mpr
    intro x hx hy
    have :=(mem_filter.mp hx).2
    have :=(mem_filter.mp hy).2
    omega
  have hh:=card_union_of_disjoint hd
  rw [hpart,hL,hc] at hh
  omega

theorem root_total_bound (n:ℕ) (B:Finset ℕ) (hf:FourFree B)
    (hn:2*(Ho n B).card+1≤n/2) :
    8*((quarterD n B).card+(middleZero n B).card)≤5*(n/2)+6*(Ho n B).card+56 := by
  let s:=n/2-2*(Ho n B).card-1
  have hs:s+2*(Ho n B).card+1=n/2 := by dsimp [s];omega
  have ht:=root_prefix_triple_free n B hf hn
  have hi:rootPrefix n B⊆Icc 1 s:=filter_subset _ _
  have hk:=Erdos865.erdos865_upper_bound s (rootPrefix n B) hi ht
  have hsub:rootPrefix n B⊆fullRoots n B := by
    intro x hx
    obtain ⟨hxI,hxB⟩:=mem_filter.mp hx
    have hr:=mem_Icc.mp hxI
    exact mem_filter.mpr ⟨mem_Icc.mpr ⟨hr.1,by omega⟩,hxB⟩
  have htail:fullRoots n B\rootPrefix n B⊆Icc (s+1) (n/2) := by
    intro x hx
    obtain ⟨hxF,hxP⟩:=mem_sdiff.mp hx
    obtain ⟨hxI,hxB⟩:=mem_filter.mp hxF
    have hr:=mem_Icc.mp hxI
    have hxs:s<x := by
      by_contra hh
      exact hxP (mem_filter.mpr ⟨mem_Icc.mpr ⟨hr.1,by omega⟩,hxB⟩)
    exact mem_Icc.mpr ⟨by omega,hr.2⟩
  have hc:=card_le_card htail
  rw [Nat.card_Icc] at hc
  have hp:=card_sdiff_add_card_eq_card hsub
  have hpart:=full_roots_partition n B
  omega

#print axioms full_roots_partition
#print axioms root_total_bound
end OP02.EdgeBand

import K9OuterTrials
import K9OuterSeed

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK8
namespace OP02.SharpK9

/-- A complete small even five either extends the original six through a
direct common root, or gives a new six whose upper root is fully canonical. -/
theorem outer_reflect_given {H : ℕ} {D : Finset ℕ} (sub : D⊆Icc 1 H)
    (df : DoublingFree D) (scale : 4096≤H) (budget : 6144*(chainCapacity H-D.card+1)<H)
    (seed : RootSix (H/4) (D∩Icc 1 (H/4))) (evenFive : SmallEvenFive (H/4) D) :
    RootSeven H D := by
  classical
  let J := H/4
  obtain ⟨X,b,hX,freshB,hSix,bLo,bHi,early⟩ := seed
  obtain ⟨Y,z,hY,freshZ,hFive,ev,zLo,zHi,smallY⟩ := evenFive
  change J<2*b at bLo
  change 4*b≤3*J at bHi
  change ∀x∈X,128*x+5*J≤128*(J/4) at early
  change J<2*z at zLo
  change 4*z≤3*J at zHi
  change ∀x∈Y,4*x≤J at smallY
  let F := insert b X
  let U := insert 0 F
  let W := insert 0 Y
  have six : Internal 6 D F := internal_mono hSix inter_subset_left
  have nonzero : 0∉F := by
    intro hz
    have := (mem_Icc.mp (sub (six.1 hz))).1
    omega
  have cardU : U.card=7 := by simp [U,nonzero,six.2.1]
  have cardW : W.card≤5 := (card_insert_le _ _).trans (by rw [hY])
  have scaleJ : 1024≤J := by dsimp [J]; omega
  have rel : 4*J≤H ∧ H≤4*J+3 := by dsimp [J]; omega
  have ub (u : ℕ) (hu : u∈U) : 4*u≤3*J := by
    rcases mem_insert.mp hu with h|h
    · omega
    · rcases mem_insert.mp h with h|h
      · omega
      · have := early u h; omega
  have shortF (x : ℕ) (hx : x∈F) : 64*x+H≤64*(H/4) := by
    have := ub x (mem_insert_of_mem hx)
    change 64*x+H≤64*J
    omega
  obtain ⟨a,ha,bOther,roles⟩ := outer_cells b cardU
  let T := residueCell U 4 a
  let C := residueCell U 4 ((a+2)%4)
  change T.card+C.card≤3 at roles
  have controlSmall : C.card≤3 := by omega
  obtain ⟨d,r,period,hr,fast,phase⟩ := outer_phase (O:=U) ha controlSmall
  let l := J+2*z+4
  let P := progression l (l+J/4) d r
  have band (p : ℕ) (hp : p∈P) : J+2*z+4<p ∧ p≤J+2*z+4+J/4 ∧ p%d=r :=
    ⟨(mem_Ioc.mp (mem_filter.mp hp).1).1,(mem_Ioc.mp (mem_filter.mp hp).1).2,(mem_filter.mp hp).2⟩
  have smallT (t : ℕ) (ht : t∈T) : 128*t≤27*J := by
    obtain ⟨hu,cell⟩ := mem_filter.mp ht
    rcases mem_insert.mp hu with h|h
    · omega
    · rcases mem_insert.mp h with h|h
      · exfalso; apply bOther; omega
      · have := early t h; omega
  have wz (w : ℕ) (hw : w∈W) : 4*w≤J ∧ w%2=0 := by
    rcases mem_insert.mp hw with h|h
    · omega
    · exact ⟨smallY w h,ev w (mem_insert_of_mem h)⟩
  have zEven := ev z (mem_insert_self _ _)
  have geom (p : ℕ) (hp : p∈P) (t : ℕ) (ht : t∈T) :
      (p+t)%4=2 ∧ z≤(p+t)/2 ∧ J<2*((p+t)/2-z) ∧
      64*((p+t)/2-z)+H≤64*J ∧
      (∀w∈W,(p+t)/2-z+w≤J) := by
    obtain ⟨lo,hi,pr⟩ := band p hp
    obtain ⟨tu,tc⟩ := mem_filter.mp ht
    have res := (phase p pr).1 t tu tc
    have ts := smallT t ht
    refine ⟨res,by omega,by omega,by omega,?_⟩
    intro w hw
    have wb := (wz w hw).1
    omega
  have width := progression_lower l (l+J/4) d r (Or.inr period) hr
  change (l+J/4-l)/d≤P.card at width
  rw [Nat.add_sub_cancel_left] at width
  let κ := chainCapacity H-D.card
  change 6144*(κ+1)<H at budget
  have room : (7+5*T.card)*κ<P.card := by
    rcases period with h8|h32
    · subst d
      have price := Nat.mul_le_mul_right κ (show 7+5*T.card≤22 by omega)
      omega
    · subst d
      have few : ¬C.card≤1 := fun hc=>(by have e:=fast hc; omega)
      have price := Nat.mul_le_mul_right κ (show 7+5*T.card≤12 by omega)
      omega
  obtain ⟨p,hp,upper,low⟩ := outer_accepted (H:=H) (z:=z) (D:=D) (U:=U) (T:=T) (W:=W)
    (P:=P) sub df cardU cardW (by
      intro p hp u hu
      have := band p hp
      have := ub u hu
      constructor <;> omega) (by
      intro p hp u hu nt
      apply (phase p (band p hp).2.2).2 u hu
      exact fun e=>nt (mem_filter.mpr ⟨hu,e⟩)) (by
      intro p hp t ht
      obtain ⟨res,zm,lo,_,wb⟩ := geom p hp t ht
      refine ⟨res,zm,?_⟩
      intro w hw
      have even := (wz w hw).2
      exact ⟨show J<2*((p+t)/2-z+w) by omega,wb w hw,canonical_odd _ (by omega)⟩) room
  have pivotBounds := band p hp
  by_cases pass : ∀u∈U,p+u∈D
  · exact outer_seven_of_pass six shortF (by omega) (by omega) pass
  · push Not at pass
    obtain ⟨t,tu,miss⟩ := pass
    obtain ⟨ht,half⟩ := upper t tu miss
    let v := (p+t)/2-z
    obtain ⟨res,zm,lo,shortV,_⟩ := geom p hp t ht
    have odd : v%2=1 := by dsimp only [v]; omega
    have actual : v∈D := by simpa only [Nat.add_zero,v] using low t ht 0 (mem_insert_self _ _)
    have newV : v∉insert z Y := fun hit=>by have := ev v hit; omega
    have edges (w : ℕ) (hw : w∈insert z Y) : v+w∈D := by
      rcases mem_insert.mp hw with h|h
      · have eq : v+w=(p+t)/2 := by dsimp only [v]; omega
        exact eq.symm ▸ half
      · exact low t ht w (mem_insert_of_mem h)
    have sixNew : Internal 6 D (insert v (insert z Y)) := internal_insert hFive actual newV edges
    apply outer_finish_reflected sub df budget sixNew odd ev
    intro w hw
    change 64*w+H≤64*J
    rcases mem_insert.mp hw with h|h
    · exact h ▸ shortV
    · rcases mem_insert.mp h with h|h
      · omega
      · have := smallY w h; omega

/-- Uniform second reflection in the actual quarter set, using the certified
Roth midpoint source for the order-eight supply. -/
theorem outer_second_reflection {β : ℝ} (hb : 0<β) :
    ∃M : ℕ,∀n : ℕ,M≤n→∀B : Finset ℕ,B⊆Icc 1 (4*n)→DoublingFree B→SignedGap β n B→
      SmallEvenFive ((n/4)/4) (quarterD n B)→RootSeven (n/4) (quarterD n B) := by
  obtain ⟨U,hU⟩ := outer_seed_six hb
  obtain ⟨V,hV⟩ := outer_strict_budget hb
  refine ⟨max 16384 (max U V),?_⟩
  intro n hn B _ hd gap five
  exact outer_reflect_given (filter_subset _ _) (quarter_doubling_free n B hd) (by omega)
    (hV n (by omega) B hd gap) (hU n (by omega) B hd gap) five

end OP02.SharpK9

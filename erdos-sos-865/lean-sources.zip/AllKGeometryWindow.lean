import AllKSpec
import AllKGeometryRoles

open Finset OP02.SharpK8
namespace OP02.AllOrders

def widthDen (k : ℕ) : ℕ := if k=8 then 4 else if k=9 then 8 else if k=10 then 32 else 64

def target256 (k : ℕ) : ℕ := if k<12 then alpha256 (k-1) else gamma256 (k-1)

private theorem order_rows (k : ℕ) (h : 8≤k) :
    k=8 ∨ k=9 ∨ k=10 ∨ k=11 ∨ k=12 ∨ k=13 ∨ 14≤k := by omega

private theorem station {k : ℕ} (h : 12≤k) : alpha256 k=52 ∧ gamma256 k=144 ∧ widthDen k=64 := by
  unfold alpha256 gamma256 widthDen
  split_ifs <;> omega

private theorem stationary_row {k : ℕ} (h : 14≤k) :
    alpha256 k=52 ∧ gamma256 k=144 ∧ gamma256 (k-1)=144 ∧
    gamma256 (k-2)=144 ∧ alpha256 (k-2)=52 ∧ target256 k=144 ∧ widthDen k=64 := by
  have a := station (show 12≤k by omega)
  have b := station (show 12≤k-1 by omega)
  have c := station (show 12≤k-2 by omega)
  exact ⟨a.1,a.2.1,b.2.1,c.2.1,c.1,by simpa [target256,show ¬k<12 by omega] using b.2.1,a.2.2⟩

theorem physical_window_geometry {k T J z R u w : ℕ} (hk : 8≤k) (j : J=T/4)
    (zlo : J<2*z) (zhi : 256*z≤gamma256 (k-2)*J)
    (lo : J+2*z+4<R) (hi : R≤J+2*z+J/widthDen k)
    (parity : (R+u)%2=0) (ut : 256*u≤target256 k*J) (ws : 256*w≤alpha256 (k-2)*J) :
    T<2*R ∧ 256*R≤gamma256 k*T ∧ z≤(R+u)/2 ∧
    J/2+2<(R+u)/2-z+w ∧ (R+u)/2-z+w≤J ∧ 256*((R+u)/2-z)≤alpha256 k*T := by
  subst J
  rcases order_rows k hk with rfl|rfl|rfl|rfl|rfl|rfl|big <;>
    first | (obtain ⟨a,b,c,d,e,f,g⟩ := stationary_row big; simp only [a,b,c,d,e,f,g] at *; omega)
          | (norm_num [widthDen,target256,alpha256,gamma256] at * <;> omega)

theorem pivot_bounds {k T z R : ℕ} (hk : 8≤k)
    (zlo : T/4<2*z) (zhi : 256*z≤gamma256 (k-2)*(T/4))
    (lo : T/4+2*z+4<R) (hi : R≤T/4+2*z+(T/4)/widthDen k) :
    T<2*R ∧ 256*R≤gamma256 k*T := by
  rcases order_rows k hk with rfl|rfl|rfl|rfl|rfl|rfl|big <;>
    first | (obtain ⟨a,b,c,d,e,f,g⟩ := stationary_row big; simp only [a,b,c,d,e,f,g] at *; omega)
          | (norm_num [widthDen,gamma256] at * <;> omega)

/-- Every seed vertex at the quarter prefix fits the next small-vertex bound,
and adding it to the direct upper candidate remains in the whole interval. -/
theorem inherited_bounds {k T J x R : ℕ} (hk : 8≤k) (j : J=T/4)
    (xs : 256*x≤gamma256 (k-1)*J ∨ 256*x≤gamma256 (k-2)*J)
    (rhi : 256*R≤gamma256 k*T) :
    256*x≤alpha256 k*T ∧ R+x≤T := by
  subst J
  rcases order_rows k hk with rfl|rfl|rfl|rfl|rfl|rfl|big <;>
    first | (obtain ⟨a,b,c,d,e,f,g⟩ := stationary_row big; simp only [a,b,c,d,e,f,g] at *; omega)
          | (norm_num [alpha256,gamma256] at * <;> omega)

theorem alpha_le_gamma (k : ℕ) : alpha256 k≤gamma256 k := by
  unfold alpha256 gamma256
  split_ifs <;> omega

theorem vertex_height {k T x z : ℕ} {F A : Finset ℕ} (s : ShapeAt k T A F z)
    (h : x∈F) : 256*x≤gamma256 k*T := by
  by_cases e : x=z
  · simpa [e] using s.height
  · exact (s.small _ h e).trans (Nat.mul_le_mul_right T (alpha_le_gamma _))

end OP02.AllOrders

import K9PhysicalRoles

open Finset OP02.SharpK5
namespace OP02.SharpK9
open OP02.SharpK8 (residueCell control_progression)

/-- Profile roles and a common set of actual upper pivots, before any target fails. -/
structure ProfileWindow (n z κ q : ℕ) (V U T C P : Finset ℕ) : Prop where
  target_sub : T ⊆ U
  control_sub : C ⊆ U
  disjoint : Disjoint T C
  role_count : T.card + C.card ≤ 5
  controls_le : C.card ≤ 3
  supply : max 9 (7*T.card + C.card)*q + C.card*κ < P.card
  pivot : ∀ p ∈ P, 2*n < p ∧ p ≤ 3*n
  odd : ∀ p ∈ P, ∀ u ∈ U, u ∉ T → u ∉ C → (p+u)%2 = 1
  target : ∀ p ∈ P, ∀ u ∈ T, (p+u)%4 = 2 ∧
    ∀ x ∈ insert 0 V, n < 2*((p+u)/2-z+x) ∧ (p+u)/2-z+x ≤ n ∧ ((p+u)/2-z+x)%2 = 1
  control : ∀ p ∈ P, ∀ c ∈ C, (p+c)%8 = 4 ∨ (p+c)%32 = 16


private theorem period_room {H a : ℕ} (large : 256≤H) (cap : 6144*a<H) :
    35*a+1 ≤ H/8/8 ∧ 23*a+1 ≤ H/8/32 := by
  constructor
  · apply (Nat.le_div_iff_mul_le (by decide : 0<8)).2
    apply (Nat.le_div_iff_mul_le (by decide : 0<8)).2
    by_cases ha : a=0 <;> omega
  · apply (Nat.le_div_iff_mul_le (by decide : 0<32)).2
    apply (Nat.le_div_iff_mul_le (by decide : 0<8)).2
    by_cases ha : a=0 <;> omega

private theorem window_supply {n κ q t c d k : ℕ} (hn : 1000000≤n)
    (cap : 6144*(κ+q)<n/4) (roles : t+c≤5) (ctrl : c≤3)
    (period : d=8 ∨ d=32) (short : c≤1 → d=8)
    (count : ((n/4)/8)/d≤k) :
    max 9 (7*t+c)*q+c*κ<k := by
  obtain ⟨room8,room32⟩ := period_room (show 256≤n/4 by omega) cap
  rcases period with rfl|rfl
  · have mult : max 9 (7*t+c) ≤ 35 := by omega
    have cost := Nat.add_le_add (Nat.mul_le_mul_right q mult)
      (Nat.mul_le_mul_right κ (show c≤35 by omega))
    rw [Nat.mul_add] at room8
    omega
  · have many : 2≤c := by by_contra! hs; have := short (by omega); omega
    have mult : max 9 (7*t+c) ≤ 23 := by omega
    have cost := Nat.add_le_add (Nat.mul_le_mul_right q mult)
      (Nat.mul_le_mul_right κ (show c≤23 by omega))
    rw [Nat.mul_add] at room32
    omega

private theorem high_label_bounds {n z p u x : ℕ}
    (lower : n+2*z<p) (upper : p≤n+2*z+n/4/8)
    (target : 2*u≤n) (short : 16*x+n/4≤4*n)
    (evenZ : z%2=0) (evenX : x%2=0) (res : (p+u)%4=2) :
    n < 2*((p+u)/2-z+x) ∧ (p+u)/2-z+x ≤ n ∧ ((p+u)/2-z+x)%2=1 := by
  have sub : z≤(p+u)/2 := by omega
  have addback := Nat.sub_add_cancel sub
  have twice : 2*((p+u)/2)≤p+u := by omega
  have width : 8*(n/4/8)≤n/4 := by omega
  refine ⟨by omega,?_,by omega⟩
  omega

/-- A constructed progression and actual target/control classes for every internal-eight profile.
The common half-open subinterval has length floor(floor(n/4) / 8). -/
theorem profile_window {n z κ q : ℕ} {V U : Finset ℕ}
    (hn : 1000000≤n) (hc : U.card=9)
    (unique : ∀ x∈U, ∀ y∈U, n<2*x → n<2*y → x=y)
    (zlo : n<2*z) (zhi : 4*z≤3*n) (zeven : z%2=0)
    (veven : ∀ x∈V, x%2=0) (vsmall : ∀ x∈V, 16*x+n/4≤4*n)
    (cap : 6144*(κ+q)<n/4) : ∃ T C P, ProfileWindow n z κ q V U T C P := by
  classical
  obtain ⟨a,ha,roles,ctrl,small⟩ := choose_profile_roles hc unique
  let T := residueCell U 4 a
  let C := residueCell U 4 ((a+2)%4)
  change T.card+C.card≤5 at roles
  change C.card≤3 at ctrl
  let b := (6-a)%4
  have cb : ∀ c∈C,(b+c)%4=0 := by
    intro c hcC
    have h := (mem_filter.mp hcC).2
    change c%4=(a+2)%4 at h
    dsimp [b]
    omega
  obtain ⟨d,r,period,hr,short,safe⟩ := control_progression C b (Nat.mod_lt _ (by decide)) ctrl cb
  let L := n+2*z
  let W := (n/4)/8
  let P := progression L (L+W) d r
  have count : W/d≤P.card := by
    have legal : d=4 ∨ d=8 ∨ d=32 := Or.inr period
    simpa only [P,Nat.add_sub_cancel_left] using progression_lower L (L+W) d r legal hr
  have ints : ∀ p∈P, n+2*z<p ∧ p≤n+2*z+(n/4)/8 := fun _ hp =>
    mem_Ioc.mp (mem_filter.mp hp).1
  have universal : ∀ p∈P, p%4=b ∧ ∀ c∈C, (p+c)%8=4 ∨ (p+c)%32=16 :=
    fun p hp => safe p (mem_filter.mp hp).2
  refine ⟨T,C,P,⟨filter_subset _ _,filter_subset _ _,?_,roles,ctrl,
    window_supply hn cap roles ctrl period short count,?_,?_,?_,?_⟩⟩
  · apply disjoint_left.mpr
    intro u ht hC
    have h1 := (mem_filter.mp ht).2
    have h2 := (mem_filter.mp hC).2
    change u%4=a at h1
    change u%4=(a+2)%4 at h2
    omega
  · intro p hp
    obtain ⟨hpL,hpU⟩ := ints p hp
    exact ⟨by omega,by omega⟩
  · intro p hp u hu ht hC
    have hpr := (universal p hp).1
    change p%4=(6-a)%4 at hpr
    have n₁ : u%4≠a := fun h => ht (mem_filter.mpr ⟨hu,h⟩)
    have n₂ : u%4≠(a+2)%4 := fun h => hC (mem_filter.mpr ⟨hu,h⟩)
    omega
  · intro p hp u hu
    have hpr := (universal p hp).1
    change p%4=(6-a)%4 at hpr
    have htu := (mem_filter.mp hu).2
    change u%4=a at htu
    have residue : (p+u)%4=2 := by omega
    refine ⟨residue,?_⟩
    intro x hx
    have hsmall := small u hu
    obtain ⟨hpL,hpU⟩ := ints p hp
    have xe : x%2=0 ∧ 16*x+n/4≤4*n := by
      rcases mem_insert.mp hx with he | h
      · subst x; exact ⟨rfl,by omega⟩
      · exact ⟨veven x h,vsmall x h⟩
    obtain ⟨xe,xs⟩ := xe
    exact high_label_bounds hpL hpU hsmall xs zeven xe residue
  · intro p hp
    exact (universal p hp).2

end OP02.SharpK9

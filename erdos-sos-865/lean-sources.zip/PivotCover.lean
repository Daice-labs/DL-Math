import PivotSlots
open Finset
open scoped BigOperators
namespace OP02.PivotAudit
open OP02.FewHole OP02.SmallExcess

def LowerTriangle (n : ℕ) (B S : Finset ℕ) : Prop :=
  S.card=3 ∧ S ⊆ lower n B ∧ ∀ x  ∈  S, ∀ y  ∈  S, x ≠ y → x+y ∈ B

def pivots (n m α : ℕ) : Finset ℕ :=
  (Icc (2*n+1) (4*n-m)).filter (fun p => p%8=α)
def residueCount (E : Finset ℕ) (j : ℕ) : ℕ := (E.filter (fun z => z%8=j)).card

theorem pivot_missing (n m : ℕ) (B S : Finset ℕ)
    (hfour : FourFree B) (htri : LowerTriangle n B S)
    (hm : ∀ x ∈ S, x ≤ m) (p : ℕ) (hp : p ∈ Icc (2*n+1) (4*n-m)) :
    ∃ u ∈ insert 0 S, p+u ∈ holes n B := by
  obtain ⟨hSc,hSL,hpair⟩ := htri
  obtain ⟨hp1,hp4⟩ := mem_Icc.mp hp
  have hSB : S ⊆ B := fun x hx => (mem_inter.mp (hSL hx)).1
  have hpS : p ∉ S := by
    intro hx
    have hi := mem_Icc.mp (mem_inter.mp (hSL hx)).2
    omega
  have hmiss : ∃ u ∈ insert 0 S, p+u ∉ B := by
    by_contra h
    push_neg at h
    apply hfour
    refine ⟨insert p S,insert_subset ?_ hSB,by simp [hpS,hSc],?_⟩
    · simpa using h 0 (mem_insert_self ..)
    · intro x hx y hy hxy
      rcases mem_insert.mp hx with hxp | hxS
      · subst x
        rcases mem_insert.mp hy with hyp | hyS
        · exact (hxy hyp.symm).elim
        · exact h y (mem_insert_of_mem hyS)
      · rcases mem_insert.mp hy with hyp | hyS
        · subst y
          simpa [add_comm] using h x (mem_insert_of_mem hxS)
        · exact hpair x hxS y hyS hxy
  obtain ⟨u,hu,hnot⟩ := hmiss
  refine ⟨u,hu,mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,hnot⟩⟩
  rcases mem_insert.mp hu with rfl|hu
  · omega
  · have hmu := hm u hu
    omega

theorem pivot_card_lower (n m α : ℕ) (hm : m ≤ n) (ha : α<8) :
    n/8  ≤  (pivots n m α).card := by
  let f := fun j : ℕ => 2*n+1+((α+8-(2*n+1)%8)%8)+8*(j-1)
  have hs : (Icc 1 (n/8)).image f ⊆ pivots n m α := by
    intro p hp
    obtain ⟨j,hj,rfl⟩ := mem_image.mp hp
    obtain ⟨hj1,hjn⟩ := mem_Icc.mp hj
    apply mem_filter.mpr
    dsimp [f]
    constructor
    · exact mem_Icc.mpr ⟨by omega,by omega⟩
    · omega
  have hinj : Set.InjOn f (Icc 1 (n/8)) := by
    intro x hx y hy hxy
    have hx1 := (mem_Icc.mp hx).1
    have hy1 := (mem_Icc.mp hy).1
    dsimp [f] at hxy
    omega
  have hc := card_le_card hs
  rw [card_image_of_injOn hinj,Nat.card_Icc] at hc
  omega

theorem hole_accounting (n : ℕ) (B : Finset ℕ) (hdbl : DoublingFree B)
    (z : ℕ) (hz : z ∈ holes n B) (hgood : z%2=1 ∨ z%8=4) :
    z ∈ excessHoles n B ∨ (z%8=4 ∧ z/4 ∈ missingTopOdd n B ∧ 4*(z/4)=z) := by
  by_cases he : z ∈ excessHoles n B
  · exact Or.inl he
  · right
    have hz4 : z%8=4 := by
      rcases hgood with ho|h4
      · have him : z ∈ (middle n B).image (fun q=>2*q) := by
          by_contra h
          exact he (mem_sdiff.mpr ⟨hz,h⟩)
        obtain ⟨q,hq,hqz⟩ := mem_image.mp him
        omega
      · exact h4
    have hzI := mem_Icc.mp (mem_sdiff.mp hz).1
    have heq : 4*(z/4)=z := by omega
    have hvnot : z/4 ∉ B := free_four_pivot_excludes_quarter n (z/4) B hdbl
      (by simpa only [heq] using hz) (by simpa only [heq] using he)
    refine ⟨hz4,mem_filter.mpr ⟨?_,by omega,hvnot⟩,heq⟩
    exact mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩

/-- The exact weighted four-part cover. No disjointness assumption is used. -/
theorem weighted_pivot_cover (n m α : ℕ) (B S : Finset ℕ)
    (hfour : FourFree B) (hdbl : DoublingFree B)
    (htri : LowerTriangle n B S) (hm : ∀ x ∈ S, x ≤ m)
    (hgood : ∀ u ∈ insert 0 S, (α+u)%2=1 ∨ (α+u)%8=4) :
    (pivots n m α).card  ≤ 
      ((insert 0 S).filter (fun u => (α+u)%8=4)).card * deficit n B +
      ∑ u ∈ insert 0 S, residueCount (excessHoles n B) ((α+u)%8) := by
  classical
  let P := pivots n m α
  let U := insert 0 S
  let E := excessHoles n B
  let T := missingTopOdd n B
  let F := fun u => P.filter (fun p => p+u ∈ holes n B)
  have hcover : P ⊆ U.biUnion F := by
    intro p hp
    have hpI := (mem_filter.mp hp).1
    obtain ⟨u,hu,hz⟩ := pivot_missing n m B S hfour htri hm p hpI
    exact mem_biUnion.mpr ⟨u,hu,mem_filter.mpr ⟨hp,hz⟩⟩
  have hF (u : ℕ) (hu : u ∈ U) :
      (F u).card  ≤  residueCount E ((α+u)%8) +
        (if (α+u)%8=4 then T.card else 0) := by
    let A := E.filter (fun z => z%8=(α+u)%8)
    let Q := if (α+u)%8=4 then T.image (fun v=>4*v) else ∅
    have hs : (F u).image (fun p=>p+u) ⊆ A ∪ Q := by
      intro z hz
      obtain ⟨p,hp,rfl⟩ := mem_image.mp hz
      obtain ⟨hpP,hph⟩ := mem_filter.mp hp
      have hpa := (mem_filter.mp hpP).2
      have hres : (p+u)%8=(α+u)%8 := by omega
      have hg : (p+u)%2=1 ∨ (p+u)%8=4 := by
        have h := hgood u hu
        omega
      rcases hole_accounting n B hdbl (p+u) hph hg with he|⟨h4,ht,heq⟩
      · exact mem_union_left _ (mem_filter.mpr ⟨he,hres⟩)
      · apply mem_union_right
        have ha4 : (α+u)%8=4 := by omega
        simp only [Q,if_pos ha4]
        exact mem_image.mpr ⟨(p+u)/4,ht,heq⟩
    have hi : Set.InjOn (fun p : ℕ=>p+u) (F u) := by
      intro x hx y hy heq
      change x+u=y+u at heq
      omega
    have h1 := card_le_card hs
    rw [card_image_of_injOn hi] at h1
    have h2 := card_union_le A Q
    have h3 : Q.card  ≤  if (α+u)%8=4 then T.card else 0 := by
      dsimp [Q]
      split_ifs with h4
      · exact card_image_le
      · simp
    change (F u).card  ≤  A.card + _
    omega
  have hs := Finset.sum_le_sum (fun u hu => hF u hu)
  have hsum : (∑ u ∈ U, if (α+u)%8=4 then T.card else 0) =
      (U.filter (fun u=>(α+u)%8=4)).card * T.card := by
    rw [← Finset.sum_filter]
    simp
  rw [Finset.sum_add_distrib,hsum] at hs
  have h0 := (card_le_card hcover).trans card_biUnion_le
  have ht : T.card  ≤  deficit n B := missingTopOdd_le_deficit n B hdbl
  have hmul := Nat.mul_le_mul_left ((U.filter (fun u=>(α+u)%8=4)).card) ht
  change P.card ≤ (U.filter (fun u=>(α+u)%8=4)).card * deficit n B +
    ∑ u ∈ U, residueCount E ((α+u)%8)
  calc
    P.card ≤ ∑ u ∈ U, (F u).card := h0
    _ ≤ (∑ u ∈ U, residueCount E ((α+u)%8)) +
        (U.filter (fun u=>(α+u)%8=4)).card * T.card := hs
    _ ≤ (∑ u ∈ U, residueCount E ((α+u)%8)) +
        (U.filter (fun u=>(α+u)%8=4)).card * deficit n B := Nat.add_le_add_left hmul _
    _ = _ := Nat.add_comm _ _
end OP02.PivotAudit

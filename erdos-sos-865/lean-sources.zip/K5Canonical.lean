import K5SmallRoots
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 3000000

/-- Even 2-adic valuation, defined without treating zero as a chain node. -/
def canonical (x : ℕ) : Bool :=
  if h0 : x=0 then false else if x%2=1 then true else !(canonical (x/2))
termination_by x
decreasing_by omega

theorem canonical_zero : canonical 0=false := by rw [canonical]; simp

theorem canonical_odd (x:ℕ) (hx:x%2=1) : canonical x=true := by
  rw [canonical]
  simp [show x≠0 by omega,hx]

theorem canonical_double (x:ℕ) (hx:0<x) : canonical (2*x)=!(canonical x) := by
  rw [canonical]
  simp [show 2*x≠0 by omega]

theorem canonical_four (x:ℕ) : canonical (4*x)=canonical x := by
  by_cases hx:x=0
  · subst x; simp
  · have hh : 4*x=2*(2*x) := by omega
    rw [hh,canonical_double (2*x) (by omega),canonical_double x (by omega)]
    simp

theorem canonical_false_parent (x:ℕ) (hx:0<x) (hc:canonical x=false) :
    2*(x/2)=x ∧ canonical (x/2)=true := by
  have he : x%2=0 := by
    by_contra hh
    have ho : x%2=1 := by omega
    rw [canonical_odd x ho] at hc
    contradiction
  have hp : 0<x/2 := by omega
  have hxe : 2*(x/2)=x := by omega
  have hh := canonical_double (x/2) hp
  rw [hxe,hc] at hh
  refine ⟨hxe,?_⟩
  cases h : canonical (x/2)
  · have hbad : (false:Bool)=true := by simpa only [h,Bool.not_false] using hh
    cases hbad
  · rfl

def canonicalSlots (H:ℕ) := (Icc 1 H).filter (fun x=>canonical x=true)
def chainCapacity (H:ℕ) := (canonicalSlots H).card
def topMissing (H:ℕ) (D:Finset ℕ) :=
  (canonicalSlots H).filter (fun r=>H<2*r ∧ r∉D)
def chainCompress (x:ℕ) := if canonical x then x else x/2

theorem chain_compression_mem (H:ℕ) (D:Finset ℕ) (hs:D⊆Icc 1 H)
    {x:ℕ} (hx:x∈D) : chainCompress x∈canonicalSlots H := by
  obtain ⟨hx1,hxH⟩ := mem_Icc.mp (hs hx)
  unfold chainCompress
  split_ifs with hc
  · exact mem_filter.mpr ⟨hs hx,hc⟩
  · have hf : canonical x=false := by cases h : canonical x <;> simp_all
    obtain ⟨he,hp⟩ := canonical_false_parent x hx1 hf
    exact mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hp⟩

theorem chain_compression_injective (H:ℕ) (D:Finset ℕ) (hs:D⊆Icc 1 H)
    (hd:DoublingFree D) : Set.InjOn chainCompress D := by
  intro x hx y hy hxy
  have hx1 := (mem_Icc.mp (hs hx)).1
  have hy1 := (mem_Icc.mp (hs hy)).1
  unfold chainCompress at hxy
  split_ifs at hxy with hcx hcy hcy
  · exact hxy
  · have hfy : canonical y=false := by cases h : canonical y <;> simp_all
    have hey := (canonical_false_parent y hy1 hfy).1
    have he : 2*x=y := by omega
    exact False.elim (hd x hx (he.symm ▸ hy))
  · have hfx : canonical x=false := by cases h : canonical x <;> simp_all
    have hex := (canonical_false_parent x hx1 hfx).1
    have he : 2*y=x := by omega
    exact False.elim (hd y hy (he.symm ▸ hx))
  · have hfx : canonical x=false := by cases h : canonical x <;> simp_all
    have hfy : canonical y=false := by cases h : canonical y <;> simp_all
    have hex := (canonical_false_parent x hx1 hfx).1
    have hey := (canonical_false_parent y hy1 hfy).1
    omega

/-- One global capacity deficit pays all absent even-valuation chain tops. -/
theorem chain_capacity_with_top_loss (H:ℕ) (D:Finset ℕ) (hs:D⊆Icc 1 H)
    (hd:DoublingFree D) : D.card+(topMissing H D).card≤chainCapacity H := by
  classical
  let I := D.image chainCompress
  have hi : I⊆canonicalSlots H := by
    intro y hy
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hy
    exact chain_compression_mem H D hs hx
  have hdis : Disjoint I (topMissing H D) := by
    apply disjoint_left.mpr
    intro y hy ht
    obtain ⟨x,hx,hxy⟩ := mem_image.mp hy
    obtain ⟨hyS,hyH,hyn⟩ := mem_filter.mp ht
    have hxH := (mem_Icc.mp (hs hx)).2
    unfold chainCompress at hxy
    split_ifs at hxy
    · exact hyn (hxy ▸ hx)
    · omega
  have ht : topMissing H D⊆canonicalSlots H := filter_subset _ _
  have hc := card_le_card (union_subset hi ht)
  rw [card_union_of_disjoint hdis] at hc
  have hic : I.card=D.card := card_image_of_injOn (chain_compression_injective H D hs hd)
  change I.card+(topMissing H D).card≤chainCapacity H at hc
  omega

/-- The canonical inventory partitions into all odd positions and quadrupled nodes. -/
theorem canonical_capacity_recurrence (H:ℕ) :
    chainCapacity H=(H+1)/2+chainCapacity (H/4) := by
  classical
  let O := oddSlots H
  let F := (canonicalSlots (H/4)).image (fun x=>4*x)
  have hp : canonicalSlots H=O∪F := by
    ext x
    constructor
    · intro hx
      obtain ⟨hxI,hcx⟩ := mem_filter.mp hx
      obtain ⟨hx1,hxH⟩ := mem_Icc.mp hxI
      by_cases ho:x%2=1
      · exact mem_union_left _ (mem_filter.mpr ⟨hxI,ho⟩)
      · have he : x%2=0 := by omega
        have hxp : 0<x/2 := by omega
        have hxe : 2*(x/2)=x := by omega
        have hh := canonical_double (x/2) hxp
        rw [hxe,hcx] at hh
        have hf : canonical (x/2)=false := by
          cases h : canonical (x/2)
          · rfl
          · have hbad : (true:Bool)=false := by simpa only [h,Bool.not_true] using hh
            cases hbad
        have he2 := (canonical_false_parent (x/2) hxp hf).1
        have hx4 : 4*(x/4)=x := by omega
        have hc4 : canonical (x/4)=true := by rw [←canonical_four (x/4),hx4]; exact hcx
        apply mem_union_right
        apply mem_image.mpr
        exact ⟨x/4,mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hc4⟩,hx4⟩
    · intro hx
      rcases mem_union.mp hx with hx|hx
      · obtain ⟨hxI,hxo⟩ := mem_filter.mp hx
        exact mem_filter.mpr ⟨hxI,canonical_odd x hxo⟩
      · obtain ⟨y,hy,rfl⟩ := mem_image.mp hx
        obtain ⟨hyI,hcy⟩ := mem_filter.mp hy
        obtain ⟨hy1,hyH⟩ := mem_Icc.mp hyI
        exact mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by simpa [canonical_four] using hcy⟩
  have hd : Disjoint O F := by
    apply disjoint_left.mpr
    intro x hx hy
    have ho := (mem_filter.mp hx).2
    obtain ⟨y,hy,rfl⟩ := mem_image.mp hy
    omega
  have hf : F.card=chainCapacity (H/4) := by
    apply card_image_of_injOn
    intro x hx y hy hxy
    change 4*x=4*y at hxy
    omega
  unfold chainCapacity
  rw [hp,card_union_of_disjoint hd,hf,oddSlots_card]
  rfl

#print axioms chain_capacity_with_top_loss
#print axioms canonical_capacity_recurrence
end OP02.SharpK5

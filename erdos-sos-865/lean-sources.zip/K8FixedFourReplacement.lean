import K8FixedFour
import K8Shell
import K5Profile
import K7Loss

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK7
namespace OP02.SharpK8

private def fixedHi (H : ℕ) := (128*(H/4)-5*H)/128

private theorem fixed_replacement_class {H m r L : ℕ} {D X : Finset ℕ}
    (hH : 65536 ≤ H) (small : ∀ s∈insert 0 X, 128*s < 5*H)
    (hm : m=4 ∨ m=32) (hr : r < m)
    (hc : ∀y : ℕ, y%m=r → ∀s∈insert 0 X,canonical (y+s)=true)
    (hload : ∀ z : ℕ, ((insert 0 X).filter (fun s => (r%4+s)%4=z%4)).card ≤ L)
    (budget : L*(topMissing (H/4) D).card < (fixedHi H-(H/4)/2)/m) :
    FixedReplacement H D X := by
  let J := H/4
  let Y := progression (J/2) (fixedHi H) m r
  let O := insert 0 X
  let E := topMissing J D
  have bounds {y : ℕ} (hy : y∈Y) : J < 2*y ∧ 128*y+5*H≤128*J ∧ y%m=r := by
    obtain ⟨hi,cong⟩ := mem_filter.mp hy
    obtain ⟨low,upper⟩ := mem_Ioc.mp hi
    change y≤(128*J-5*H)/128 at upper
    dsimp only [J] at *
    exact ⟨by omega,by omega,cong⟩
  have counts := shift_losses Y O D E 4 (r%4) L
    (by intro y hy; have c := (bounds hy).2.2; rcases hm with he|he <;> subst m <;> omega)
    (by
      intro y hy s hs habs
      obtain ⟨lo,hi,c⟩ := bounds hy
      have sh := small s hs
      have hupper : y+s≤J := by omega
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hupper⟩,hc y c s hs⟩,by omega,habs⟩)
    (fun z _ => hload z)
  have sz := progression_lower (J/2) (fixedHi H) m r (hm.elim Or.inl (fun e=>Or.inr (Or.inr e))) hr
  change (fixedHi H-J/2)/m≤Y.card at sz
  change L*E.card<(fixedHi H-J/2)/m at budget
  obtain ⟨y,hy⟩ := card_pos.mp (show 0<(passes Y O D).card by omega)
  obtain ⟨hyY,hall⟩ := mem_filter.mp hy
  obtain ⟨lo,hi,_⟩ := bounds hyY
  refine ⟨y,lo,hi,?_⟩
  intro s hs
  have sh := small s hs
  exact mem_inter.mpr ⟨hall s hs,mem_Icc.mpr ⟨by omega,by omega⟩⟩

/-- Every missing-residue quartet has a genuine replacement. For two occupied parities,
the modulo-four load is at most four; the 88Q window already covers that coefficient. -/
theorem fixed_replacement_missing_residue {H : ℕ} {D X : Finset ℕ}
    (hH : 65536 ≤ H) (sub : D ⊆ Icc 1 H) (hd : DoublingFree D)
    (budget : 1536*(chainCapacity H-D.card) < H)
    (hX : Internal 4 (D ∩ Icc 1 (H/4)) X) (small : ∀ x∈X,128*x<5*H)
    (missing : ∃j<4, ∀x∈insert 0 X,x%4≠j) :
    FixedReplacement H D X := by
  classical
  let O := insert 0 X
  have xn : 0∉X := by
    intro hx
    have := (mem_Icc.mp (mem_inter.mp (hX.1 hx)).2).1
    omega
  have cardO : O.card=5 := by dsimp [O]; rw [card_insert_of_notMem xn,hX.2.1]
  have smallO (s : ℕ) (hs : s∈O) : 128*s<5*H := by
    rcases mem_insert.mp hs with h|h
    · omega
    · exact small s h
  have mis := band_canonical_holes_le H 1 D sub hd
  simp only [pow_one] at mis
  by_cases even : ∀s∈O,s%2=0
  · apply fixed_replacement_class (m:=4) (r:=1) (L:=5) hH smallO (by decide) (by decide)
    · intro y hy s hs
      have e := even s hs
      exact canonical_odd _ (by omega)
    · intro z
      exact le_trans (card_filter_le _ _) (le_of_eq cardO)
    · unfold fixedHi
      omega
  · push Not at even
    obtain ⟨a,ha,hao⟩ := even
    obtain ⟨b,hb,havoid,hev⟩ := profile_pivot X hX.2.1 xn missing
    obtain ⟨r,hr,_,hcanon⟩ := canonical_profile_class O b hb havoid hev
    apply fixed_replacement_class (m:=32) (r:=r) (L:=4) hH smallO (by decide) hr hcanon
    · intro z
      let C := O.filter (fun s => (r%4+s)%4=z%4)
      change C.card≤4
      by_contra! gt
      have ceq : C=O := eq_of_subset_of_card_le (filter_subset _ _) (by omega)
      have hzero : 0∈C := ceq ▸ mem_insert_self 0 X
      have hone : a∈C := ceq ▸ ha
      have hz := (mem_filter.mp hzero).2
      have ho := (mem_filter.mp hone).2
      omega
    · unfold fixedHi
      omega

end OP02.SharpK8

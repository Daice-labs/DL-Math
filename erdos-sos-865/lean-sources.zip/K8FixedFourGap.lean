import K8FixedFourGapSpec

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK7
namespace OP02.SharpK8

private def badGapPivots (H : ℕ) (D : Finset ℕ) (a b : ℕ) :=
  (missingGap H D a b).image (fun g => 2*g-a)

/-- Joint bound for the two actual gap progressions after fixed replacement fails.
An odd, valuation-two or unmatched failure shares one augmentable/canonical account.
The three-versus-two parity split bounds all inverse roles over both progressions. -/
theorem fixed_gap_failures {H a b : ℕ} {D X : Finset ℕ}
    (hs : D⊆Icc 1 H) (hd : DoublingFree D) (hH : 65536≤H)
    (small : ∀s∈insert 0 X,128*s<5*H) (hp : GapPair (insert 0 X) a b)
    (fail : ¬FixedReplacement H D X) :
    (missingGap H D a b).card+(missingGap H D b a).card ≤
      3*(chainCapacity H-D.card) := by
  classical
  let J := H/4
  let A := D ∩ Icc 1 J
  let O := insert 0 X
  let E := complementFaults J A
  let P := badGapPivots H D a b ∪ badGapPivots H D b a
  have data {i j p : ℕ} (order : GapPair O i j) (hy : p∈badGapPivots H D i j) :
      J/2<p ∧ 128*p+5*H≤128*J ∧ (p+j)%8=4 ∧ p%2=i%2 ∧
      ∃g : ℕ, g∉D ∧ p+i=2*g := by
    obtain ⟨g,hg,rfl⟩ := mem_image.mp hy
    obtain ⟨hg',abs⟩ := mem_filter.mp hg
    obtain ⟨lo,up,co,pa,eq⟩ := gap_pivot_data hH order.same order.different hg'
    exact ⟨lo,up,co,pa,g,abs,eq⟩
  have cardPivots {i j : ℕ} (order : GapPair O i j) :
      (badGapPivots H D i j).card = (missingGap H D i j).card := by
    apply card_image_of_injOn
    intro u hu v hv he
    dsimp only at he
    have du := (gap_pivot_data hH order.same order.different (mem_filter.mp hu).1).2.2.2.2
    have dv := (gap_pivot_data hH order.same order.different (mem_filter.mp hv).1).2.2.2.2
    omega
  have disj : Disjoint (badGapPivots H D a b) (badGapPivots H D b a) := by
    apply disjoint_left.mpr
    intro p h1 h2
    have c1 := (data hp h1).2.2.1
    have c2 := (data hp.flip h2).2.2.1
    have diff := hp.different
    omega
  have rangeP {p : ℕ} (h : p∈P) : J/2<p ∧ 128*p+5*H≤128*J ∧ p%2=a%2 := by
    rcases mem_union.mp h with h|h
    · obtain ⟨l,u,_,c,_⟩ := data hp h
      exact ⟨l,u,c⟩
    · obtain ⟨l,u,_,c,_⟩ := data hp.flip h
      exact ⟨l,u,c.trans hp.same.symm⟩
  have cover {i j p : ℕ} (order : GapPair O i j) (hy : p∈badGapPivots H D i j)
      (s : ℕ) (hst : s∈O) (abs : p+s∉A) : p+s∈E := by
    obtain ⟨lo,up,c,pa,g,missing,eq⟩ := data order hy
    have shr := small s hst
    have window : J<2*(p+s) ∧ p+s≤J := ⟨by omega,by omega⟩
    by_cases un : p+s∈unmatchedTop J A
    · exact mem_union_left _ un
    have canon (cc : canonical (p+s)=true) : p+s∈E := by
      apply mem_union_right
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,window.2⟩,cc⟩,
        window.1, fun h => (mem_union.mp h).elim abs un⟩
    by_cases si : s=i
    · subst s
      apply mem_union_left
      apply mem_filter.mpr
      refine ⟨mem_Ioc.mpr ⟨by omega,window.2⟩,abs,?_⟩
      intro x hx hdouble
      have xeq : x=g := by omega
      exact missing (xeq ▸ (mem_inter.mp hx).1)
    by_cases sj : s=j
    · subst s
      exact canon (canonical_four_residue _ c)
    have other : s%2≠i%2 := by
      intro h
      exact (order.only s hst h).elim si sj
    exact canon (canonical_odd _ (by omega))
  have nopass : passes P O A=∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro p hp
    obtain ⟨py,all⟩ := mem_filter.mp hp
    obtain ⟨lo,up,_⟩ := rangeP py
    exact fail ⟨p,by omega,up,all⟩
  have losses := shift_losses P O A E 2 (a%2) 3
    (fun _ h => (rangeP h).2.2)
    (by intro p h s hs m; rcases mem_union.mp h with h|h
        · exact cover hp h s hs m
        · exact cover hp.flip h s hs m)
    (fun z _ => hp.load (a%2) z)
  rw [nopass,card_empty,zero_add] at losses
  have ec := complement_fault_budget (show A⊆Icc 1 J from inter_subset_right)
    (show DoublingFree A by intro x h1 h2;exact hd x (mem_inter.mp h1).1 (mem_inter.mp h2).1)
  have kd := prefix_defect_le H 1 D hs hd
  simp only [pow_one] at kd
  change chainCapacity J-A.card≤_ at kd
  change E.card≤_ at ec
  change (badGapPivots H D a b ∪ badGapPivots H D b a).card≤_ at losses
  rw [card_union_of_disjoint disj,cardPivots hp,cardPivots hp.flip] at losses
  omega

end OP02.SharpK8

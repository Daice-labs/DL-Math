import K8UpperSixTools

open Finset OP02.FewHole OP02.SharpK7
namespace OP02.SharpK8

/-- The three restricted Proposition S patterns, keeping the parity split needed
for the two central upper-sixth constructions. -/
def UpperTriangleShape (a c b : ℕ) : Prop :=
  (a%2=0 ∧ c%2=0 ∧ b%2=1) ∨
  (a%2=1 ∧ c%2=1 ∧
      ((a%4=c%4 ∧ b%2=0) ∨ (a%4≠c%4 ∧ b%4=0)))

theorem upper_triangle_shapes {m : ℕ} {Z : Finset ℕ} (hm : 0 < m)
    (hs : Z ⊆ Icc 1 m) (hd : DoublingFree Z)
    (hp : (5/8:ℝ)*m+(3/4:ℝ)*(Real.log (m:ℝ)/Real.log 2)+13/8 < Z.card) :
    ∃ a c b : ℕ, 0<a ∧ a<c ∧ c<b ∧ b≤3*(m/4)+1 ∧
      a∈Z ∧ c∈Z ∧ b∈Z ∧ a+c∈Z ∧ b+a∈Z ∧ b+c∈Z ∧ UpperTriangleShape a c b := by
  classical
  have hfail : ¬RestrictedClear m Z :=
    fun hc => (not_lt_of_ge (restricted_five_eighths_log hm hs hd hc)) hp
  unfold RestrictedClear at hfail
  push_neg at hfail
  obtain ⟨_,a,ha,c,hc,b,hb,apos,ac,cb,_,hac,_,_,bhi,hpat,hba,hbc⟩ := hfail
  refine ⟨a,c,b,apos,ac,cb,bhi,ha,hc,hb,hac,hba,hbc,?_⟩
  rcases hpat with h|⟨h1,h2,_,h3⟩
  · exact Or.inl h
  · exact Or.inr ⟨h1,h2,h3⟩

end OP02.SharpK8

import K5Canonical
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 3000000

def canonicalHoles (n:ℕ) (B:Finset ℕ) := (holes n B).filter (fun x=>canonical x=true)
def chainDeficit (n:ℕ) (B:Finset ℕ) := chainCapacity (n/4)-(quarterD n B).card

theorem odd_tops_cost_once (H:ℕ) (D:Finset ℕ) (hs:D⊆Icc 1 H) (hd:DoublingFree D) :
    (missingTopOdd H D).card≤chainCapacity H-D.card := by
  have hb := chain_capacity_with_top_loss H D hs hd
  have hsub : missingTopOdd H D⊆topMissing H D := by
    intro x hx
    obtain ⟨hxO,hxH,hxD⟩ := mem_filter.mp hx
    obtain ⟨hxI,hxo⟩ := mem_filter.mp hxO
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨hxI,canonical_odd x hxo⟩,hxH,hxD⟩
  have hc := card_le_card hsub
  omega

/-- Every non-excess canonical hole has one actual doubled-middle antecedent.
After M2 is removed, its image is an absent canonical top of the actual root set. -/
theorem canonical_hole_cover (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    canonicalHoles n B⊆excessHoles n B ∪
      (((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x)) ∪
      ((topMissing (n/4) (quarterD n B)).image (fun r=>16*r)) := by
  classical
  intro z hz
  obtain ⟨hzH,hcz⟩ := mem_filter.mp hz
  by_cases hzE:z∈excessHoles n B
  · exact mem_union_left _ (mem_union_left _ hzE)
  have him : z∈(middle n B).image (fun x=>2*x) := by
    by_contra hh
    exact hzE (mem_sdiff.mpr ⟨hzH,hh⟩)
  obtain ⟨x,hxM,rfl⟩ := mem_image.mp him
  obtain ⟨hxB,hxI⟩ := mem_inter.mp hxM
  obtain ⟨hxn,hx2n⟩ := mem_Icc.mp hxI
  by_cases hx2:x%4=2
  · exact mem_union_left _ (mem_union_right _ (mem_image.mpr ⟨x,mem_filter.mpr ⟨hxM,hx2⟩,rfl⟩))
  have hcx : canonical x=false := by
    have hh := canonical_double x (by omega)
    rw [hcz] at hh
    cases hc : canonical x
    · rfl
    · have hbad : (true:Bool)=false := by simpa only [hc,Bool.not_true] using hh
      cases hbad
  have he := (canonical_false_parent x (by omega) hcx).1
  have hx4 : 4*(x/4)=x := by omega
  have hc4 : canonical (x/4)=false := by rw [←canonical_four (x/4),hx4]; exact hcx
  have he4 := (canonical_false_parent (x/4) (by omega) hc4).1
  have hx8 : 8*(x/8)=x := by omega
  let r := x/8
  have hr : 0<r := by dsimp [r]; omega
  have hcr : canonical r=true := by
    have h8 : 4*(2*r)=x := by dsimp [r]; omega
    have hh := canonical_double r hr
    have hcx' : canonical (2*r)=false := by rw [←canonical_four (2*r),h8]; exact hcx
    rw [hcx'] at hh
    cases hc : canonical r
    · have hbad : (false:Bool)=true := by simpa only [hc,Bool.not_false] using hh
      cases hbad
    · rfl
  have hrI : r∈Icc 1 (n/4) := mem_Icc.mpr ⟨by omega,by dsimp [r]; omega⟩
  have hrH : n/4<2*r := by dsimp [r]; omega
  have hrD : r∉quarterD n B := by
    intro hh
    have h4B := (mem_filter.mp hh).2
    apply hd (4*r) h4B
    have hhx : 2*(4*r)=x := by dsimp [r]; omega
    rw [hhx]
    exact hxB
  apply mem_union_right
  apply mem_image.mpr
  refine ⟨r,mem_filter.mpr ⟨mem_filter.mpr ⟨hrI,hcr⟩,hrH,hrD⟩,?_⟩
  dsimp [r]
  omega

/-- Actual canonical-hole budget, with each chain-top deficit used once. -/
theorem canonical_hole_budget (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    (canonicalHoles n B).card≤chainDeficit n B+
      ((middle n B).filter (fun x=>x%4=2)).card+(excessHoles n B).card := by
  have hc := card_le_card (canonical_hole_cover n B hd)
  have h1 := card_union_le (excessHoles n B)
    (((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x))
  have h2 := card_union_le
    (excessHoles n B ∪ (((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x)))
    ((topMissing (n/4) (quarterD n B)).image (fun r=>16*r))
  have h3 := card_image_le (s:=(middle n B).filter (fun x=>x%4=2)) (f:=fun x=>2*x)
  have h4 := card_image_le (s:=topMissing (n/4) (quarterD n B)) (f:=fun r=>16*r)
  have hb := chain_capacity_with_top_loss (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  unfold chainDeficit
  omega

theorem canonical_hole_total_budget (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    (canonicalHoles n B).card≤chainDeficit n B+deficit n B+(excessHoles n B).card := by
  have h1 := canonical_hole_budget n B hd
  have h2 := middle_two_le_singleton n B hd
  have h3 := deficit_split n B hd
  omega

#print axioms odd_tops_cost_once
#print axioms canonical_hole_cover
#print axioms canonical_hole_budget
#print axioms canonical_hole_total_budget
end OP02.SharpK5

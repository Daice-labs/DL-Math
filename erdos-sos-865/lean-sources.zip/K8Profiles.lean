import K8ProfilesRoles
import K8ProfilesProgression

open Finset OP02.SharpK5
namespace OP02.SharpK8

private theorem window_supply {n κ q t c d k : ℕ} (hn : 1000000≤n)
    (cap : 1536*(κ+q)<n/4) (roles : t+c≤4) (ctrl : c≤3)
    (period : d=8 ∨ d=32) (short : c≤1 → d=8)
    (count : (5*(n/4)/16)/d≤k) :
    max 8 (6*t+c)*q+c*κ<k := by
  rcases period with rfl|rfl
  · have h : max 8 (6*t+c) ≤ 24 := by omega
    have a := Nat.mul_le_mul_right q h
    have b := Nat.mul_le_mul_right κ (show c≤24 by omega)
    omega
  · have many : 2≤c := by by_contra! hs; have := short (by omega); omega
    have h : max 8 (6*t+c) ≤ 14 := by omega
    have a := Nat.mul_le_mul_right q h
    have b := Nat.mul_le_mul_right κ (show c≤14 by omega)
    omega

/-- A constructed progression and actual target/control classes for every internal-seven profile.
The common half-open subinterval has length floor(5 floor(n/4) / 16). -/
theorem profile_window {n z κ q : ℕ} {V U : Finset ℕ}
    (hn : 1000000≤n) (hc : U.card=8)
    (unique : ∀ x∈U, ∀ y∈U, n<2*x → n<2*y → x=y)
    (zlo : n<2*z) (zhi : 4*z≤3*n) (zeven : z%2=0)
    (veven : ∀ x∈V, x%2=0) (vsmall : ∀ x∈V, 32*x+5*(n/4)≤8*n)
    (cap : 1536*(κ+q)<n/4) : ∃ T C P, ProfileWindow n z κ q V U T C P := by
  classical
  obtain ⟨a,ha,roles,ctrl,small⟩ := choose_profile_roles hc unique
  let T := residueCell U 4 a
  let C := residueCell U 4 ((a+2)%4)
  change T.card+C.card≤4 at roles
  change C.card≤3 at ctrl
  let b := (6-a)%4
  have cb : ∀ c∈C,(b+c)%4=0 := by
    intro c hcC
    have h := (mem_filter.mp hcC).2
    change c%4=(a+2)%4 at h
    dsimp [b]
    omega
  obtain ⟨d,r,period,hr,short,safe⟩ := control_progression C b (Nat.mod_lt _ (by decide)) ctrl cb
  let L := n+2*z
  let W := 5*(n/4)/16
  let P := progression L (L+W) d r
  have count : W/d≤P.card := by
    have legal : d=4 ∨ d=8 ∨ d=32 := Or.inr period
    simpa only [P,Nat.add_sub_cancel_left] using progression_lower L (L+W) d r legal hr
  have ints : ∀ p∈P, n+2*z<p ∧ p≤n+2*z+5*(n/4)/16 := fun _ hp =>
    mem_Ioc.mp (mem_filter.mp hp).1
  have universal : ∀ p∈P, p%4=b ∧ ∀ c∈C, (p+c)%8=4 ∨ (p+c)%32=16 :=
    fun p hp => safe p (mem_filter.mp hp).2
  refine ⟨T,C,P,⟨filter_subset _ _,filter_subset _ _,?_,roles,ctrl,
    window_supply hn cap roles ctrl period short count,?_,?_,?_,?_⟩⟩
  · apply disjoint_left.mpr
    intro u ht hC
    have h1 := (mem_filter.mp ht).2
    have h2 := (mem_filter.mp hC).2
    change u%4=a at h1
    change u%4=(a+2)%4 at h2
    omega
  · intro p hp
    obtain ⟨hpL,hpU⟩ := ints p hp
    exact ⟨by omega,by omega⟩
  · intro p hp u hu ht hC
    have hpr := (universal p hp).1
    change p%4=(6-a)%4 at hpr
    have n₁ : u%4≠a := fun h => ht (mem_filter.mpr ⟨hu,h⟩)
    have n₂ : u%4≠(a+2)%4 := fun h => hC (mem_filter.mpr ⟨hu,h⟩)
    omega
  · intro p hp u hu
    have hpr := (universal p hp).1
    change p%4=(6-a)%4 at hpr
    have htu := (mem_filter.mp hu).2
    change u%4=a at htu
    have residue : (p+u)%4=2 := by omega
    refine ⟨residue,?_⟩
    intro x hx
    have hsmall := small u hu
    obtain ⟨hpL,hpU⟩ := ints p hp
    have xe : x%2=0 ∧ 32*x+5*(n/4)≤8*n := by
      rcases mem_insert.mp hx with he | h
      · subst x; exact ⟨rfl,by omega⟩
      · exact ⟨veven x h,vsmall x h⟩
    obtain ⟨xe,xs⟩ := xe
    have sub : z≤(p+u)/2 := by omega
    exact ⟨by omega,by omega,by omega⟩
  · intro p hp
    exact (universal p hp).2

end OP02.SharpK8

import SharpOddSubset
import ActualStaircase
import OddEdgeless
open Finset
namespace OP02.SharpK4
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot OP02.BothEdges OP02.EdgeBand
set_option maxHeartbeats 2000000

theorem missing_pair_bound (n : ℕ) (B S T A H : Finset ℕ)
    (hS : S⊆middle n B) (hT : T⊆middle n B) (hs : S.Nonempty) (ht : T.Nonempty)
    (hn : ∀x∈S,∀y∈T,x+y∉B)
    (ha : ∀x∈S,∀y∈T,∀v∈middle n B,2*v=x+y→v∈A)
    (hh : ∀x∈S,∀y∈T,x+y∈excessHoles n B→x+y∈H) :
    S.card+T.card≤A.card+H.card+1 := by
  let F := A.image (fun v=>2*v) ∪ H
  have hf : ∀x∈S,∀y∈T,x+y∈F := by
    intro x hx y hy
    have hxi := mem_Icc.mp (mem_inter.mp (hS hx)).2
    have hyi := mem_Icc.mp (mem_inter.mp (hT hy)).2
    rcases missing_split (n:=n) (by omega) (hn x hx y hy) with hm|he
    · obtain ⟨v,hv,hve⟩ := hm
      exact mem_union_left _ (mem_image.mpr ⟨v,ha x hx y hy v hv hve,hve⟩)
    · exact mem_union_right _ (hh x hx y hy he)
  have hb := sum_union_lower S T F hs ht hf
  have hc := card_union_le (A.image (fun v=>2*v)) H
  have hi := card_image_le (s:=A) (f:=fun v=>2*v)
  dsimp only [F] at hb
  omega

theorem zero_subset_sum_bound (n : ℕ) (B P : Finset ℕ) (hd : DoublingFree B)
    (hP : P⊆middleZero n B) (hn : NoEdge B P) :
    2*P.card≤(middleZero n B).card+((middle n B).filter (fun x=>x%4=2)).card+(H0 n B).card+1 := by
  classical
  by_cases he : P=∅
  · simp [he]
  have hne : P.Nonempty := nonempty_iff_ne_empty.mpr he
  have hpm : P⊆middle n B := fun x hx=>(mem_filter.mp (hP hx)).1
  have hh := pair_bound n B P P P (parityMiddle n B 0) (H0 n B) hd hpm hn Subset.rfl Subset.rfl hne hne
    (by
      intro x hx y hy v hv hve
      have hx4 := (mem_filter.mp (hP hx)).2
      have hy4 := (mem_filter.mp (hP hy)).2
      exact mem_filter.mpr ⟨hv,by omega⟩)
    (by
      intro x hx y hy hh
      have hx4 := (mem_filter.mp (hP hx)).2
      have hy4 := (mem_filter.mp (hP hy)).2
      exact mem_filter.mpr ⟨hh,by omega⟩)
  have hp := even_middle_partition n B
  omega

theorem inactive_odd_bound (n r : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hr : r=1 ∨ r=3) (hne : (res4 (parityMiddle n B 1) r).Nonempty)
    (hisolated : ∀ x∈(parityMiddle n B 1)\res4 (parityMiddle n B 1) r,
      ∀y∈parityMiddle n B 1,x≠y→x+y∉B) :
    ((parityMiddle n B 1)\res4 (parityMiddle n B 1) r).card ≤
      2*((middle n B).filter (fun x=>x%4=2)).card+2*(H0 n B).card+(H2 n B).card+1 := by
  classical
  let O := parityMiddle n B 1
  let Y := res4 O r
  let I := O\Y
  let T2 := (middle n B).filter (fun x=>x%4=2)
  obtain ⟨z,hz⟩ := hne
  obtain ⟨hzO,hzr⟩ := mem_filter.mp hz
  have hzM := (mem_filter.mp hzO).1
  have hzp := (mem_filter.mp hzO).2
  let A := I.filter (fun x=>(z+x)%8=4)
  let C := I.filter (fun x=>(z+x)%8=0)
  have hip (x : ℕ) (hx : x∈I) : x∈O ∧ x%4≠r := by
    obtain ⟨hxO,hxY⟩ := mem_sdiff.mp hx
    exact ⟨hxO,by intro hh;exact hxY (mem_filter.mpr ⟨hxO,hh⟩)⟩
  have hpart : I.card=A.card+C.card := by
    apply partition_card
    · intro x
      simp only [A,C,mem_filter]
      constructor
      · intro hx
        have hp := (mem_filter.mp (hip x hx).1).2
        have hr' := (hip x hx).2
        by_cases hh : (z+x)%8=4
        · exact Or.inl ⟨hx,hh⟩
        · exact Or.inr ⟨hx,by rcases hr with hr|hr <;> omega⟩
      · rintro (⟨hx,_⟩|⟨hx,_⟩) <;> exact hx
    · intro x hx hy
      have h1 := (mem_filter.mp hx).2
      have h2 := (mem_filter.mp hy).2
      omega
  have ha : A.card≤T2.card+(H0 n B).card := by
    by_cases he : A=∅
    · simp [he]
    have hm : A⊆middle n B := fun x hx=>(mem_filter.mp (hip x (mem_filter.mp hx).1).1).1
    have h := missing_pair_bound n B {z} A T2 (H0 n B)
      (by intro x hx;simpa only [mem_singleton.mp hx] using hzM) hm
      (by simp) (nonempty_iff_ne_empty.mpr he)
      (by
        intro x hx y hy
        have hxe : x=z := mem_singleton.mp hx
        subst x
        have hyI := (mem_filter.mp hy).1
        have hyr := (hip y hyI).2
        have h := hisolated y hyI z hzO (by intro he;subst y;exact hyr hzr)
        simpa [Nat.add_comm] using h)
      (by
        intro x hx y hy v hv heq
        have hxe : x=z := mem_singleton.mp hx
        have hp := (mem_filter.mp hy).2
        exact mem_filter.mpr ⟨hv,by omega⟩)
      (by
        intro x hx y hy hh
        have hxe : x=z := mem_singleton.mp hx
        have hp := (mem_filter.mp hy).2
        exact mem_filter.mpr ⟨hh,by omega⟩)
    simp only [card_singleton] at h
    omega
  have hc : 2*C.card≤I.card+(H2 n B).card+1 := by
    by_cases he : C=∅
    · simp [he]
    have hm : C⊆middle n B := fun x hx=>(mem_filter.mp (hip x (mem_filter.mp hx).1).1).1
    have h := missing_pair_bound n B C C I (H2 n B) hm hm
      (nonempty_iff_ne_empty.mpr he) (nonempty_iff_ne_empty.mpr he)
      (by
        intro x hx y hy
        by_cases hxy : x=y
        · subst y
          simpa [two_mul] using hd x (mem_inter.mp (hm hx)).1
        · exact hisolated x (mem_filter.mp hx).1 y (hip y (mem_filter.mp hy).1).1 hxy)
      (by
        intro x hx y hy v hv heq
        have hxx := (mem_filter.mp hx).2
        have hyy := (mem_filter.mp hy).2
        apply mem_sdiff.mpr
        refine ⟨mem_filter.mpr ⟨hv,by rcases hr with hr|hr <;> omega⟩,?_⟩
        intro hvY
        have hvr := (mem_filter.mp hvY).2
        rcases hr with hr|hr <;> omega)
      (by
        intro x hx y hy hh
        have hxx := (mem_filter.mp hx).2
        have hyy := (mem_filter.mp hy).2
        exact mem_filter.mpr ⟨hh,by rcases hr with hr|hr <;> omega⟩)
    omega
  change I.card≤2*T2.card+2*(H0 n B).card+(H2 n B).card+1
  omega

#print axioms missing_pair_bound
#print axioms zero_subset_sum_bound
#print axioms inactive_odd_bound
end OP02.SharpK4

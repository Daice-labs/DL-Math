import K5FullProfile
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.PositivePivot
set_option maxHeartbeats 1000000

theorem four_profile_load (U:Finset ℕ) (hU:U.card=5)
    (hf:∀j<4,∃s∈U,s%4=j) : ∀j:ℕ,(U.filter (fun s=>s%4=j)).card≤2 := by
  classical
  have hpos (j:ℕ) (hj:j<4) : 1≤(U.filter (fun s=>s%4=j)).card := by
    obtain ⟨s,hs,hr⟩:=hf j hj
    exact card_pos.mpr ⟨s,mem_filter.mpr ⟨hs,hr⟩⟩
  have hh:=card_eq_sum_card_fiberwise (s:=U) (t:=range 4) (f:=fun s:ℕ=>s%4)
    (fun s hs=>mem_range.mpr (by change s%4<4; omega))
  simp only [sum_range_succ,sum_range_zero,zero_add] at hh
  have h0:=hpos 0 (by omega)
  have h1:=hpos 1 (by omega)
  have h2:=hpos 2 (by omega)
  have h3:=hpos 3 (by omega)
  intro j
  by_cases hj:j<4
  · interval_cases j <;> omega
  · have he:U.filter (fun s=>s%4=j)=∅ := by
      apply eq_empty_iff_forall_notMem.mpr
      intro s hs; have :=(mem_filter.mp hs).2; omega
    simp [he]

/-- Full profile and internal sums select the two unique same-parity offsets.
The choice is derived, and includes the offset-zero alternative. -/
theorem clique_shape (n:ℕ) (S:Finset ℕ) (hS:S⊆Icc 1 n) (hc:S.card=4)
    (hp:∀x∈S,∀y∈S,x≠y→x+y≤n)
    (hf:∀j<4,∃s∈insert 0 S,s%4=j) :
    ∃u∈insert 0 S,∃v∈insert 0 S,u<v ∧ 2*u<n ∧ (u+2)%4=v%4 ∧
      (∀s∈insert 0 S\{u,v},s%2≠u%2) ∧
      (∀j:ℕ,((insert 0 S\{u,v}).filter (fun s=>s%4=j)).card≤2) := by
  classical
  let U:=insert 0 S
  let E:=U.filter (fun x=>x%2=0)
  let O:=U.filter (fun x=>x%2=1)
  have hzero:0∉S := by intro hh; have :=(mem_Icc.mp (hS hh)).1; omega
  have hUc:U.card=5 := by simp [U,hzero,hc]
  have hpart:E.card+O.card=5 := by
    have hh:U.card=E.card+O.card := by
      apply partition_card
      · intro x
        simp only [E,O,mem_filter]
        constructor
        · intro hx; by_cases hh:x%2=0
          · exact Or.inl ⟨hx,hh⟩
          · exact Or.inr ⟨hx,by omega⟩
        · tauto
      · intro x hx hy; have :=(mem_filter.mp hx).2; have :=(mem_filter.mp hy).2; omega
    omega
  obtain ⟨x0,hx0,hr0⟩:=hf 0 (by omega)
  obtain ⟨x1,hx1,hr1⟩:=hf 1 (by omega)
  obtain ⟨x2,hx2,hr2⟩:=hf 2 (by omega)
  obtain ⟨x3,hx3,hr3⟩:=hf 3 (by omega)
  have hE2:2≤E.card := by
    have hs:({x0,x2}:Finset ℕ)⊆E := by
      intro x hx; simp only [mem_insert,mem_singleton] at hx
      rcases hx with rfl|rfl <;> exact mem_filter.mpr ⟨by assumption,by omega⟩
    have hh:=card_le_card hs
    have hne:x0≠x2 := by omega
    simpa [hne] using hh
  have hO2:2≤O.card := by
    have hs:({x1,x3}:Finset ℕ)⊆O := by
      intro x hx; simp only [mem_insert,mem_singleton] at hx
      rcases hx with rfl|rfl <;> exact mem_filter.mpr ⟨by assumption,by omega⟩
    have hh:=card_le_card hs
    have hne:x1≠x3 := by omega
    simpa [hne] using hh
  have hload (u v:ℕ) : ∀j:ℕ,((U\{u,v}).filter (fun s=>s%4=j)).card≤2 := by
    intro j
    apply le_trans (card_le_card ?_) (four_profile_load U hUc hf j)
    intro s hs
    exact mem_filter.mpr ⟨(mem_sdiff.mp (mem_filter.mp hs).1).1,(mem_filter.mp hs).2⟩
  by_cases he:E.card=2
  · have h0E:0∈E := mem_filter.mpr ⟨by simp [U],by omega⟩
    have hx2E:x2∈E := mem_filter.mpr ⟨hx2,by omega⟩
    have heq:E={0,x2} := by
      apply eq_of_subset_of_card_le
      · intro x hx
        by_contra hn
        have hne0:x≠0 := by intro he; exact hn (by simp [he])
        have hne2:x≠x2 := by intro hh; exact hn (by simp [hh])
        have hs:({0,x2,x}:Finset ℕ)⊆E := by intro a ha; simp only [mem_insert,mem_singleton] at ha; rcases ha with rfl|rfl|rfl <;> assumption
        have hh:=card_le_card hs
        have hz2:0≠x2 := by omega
        have hzc:0≠x := Ne.symm hne0
        have h2x:x2≠x := Ne.symm hne2
        simp only [card_insert_of_notMem,mem_insert,mem_singleton,hz2,hzc,h2x,false_or,not_false_eq_true,card_singleton] at hh
        omega
      · rw [he]; exact card_le_two
    have hx2S:x2∈S := (mem_insert.mp hx2).resolve_left (by omega)
    have hn:n>0 := by have := mem_Icc.mp (hS hx2S); omega
    refine ⟨0,by simp,x2,hx2,by omega,by omega,by omega,?_,hload 0 x2⟩
    intro s hs
    obtain ⟨hsU,hsne⟩:=mem_sdiff.mp hs
    intro hseven
    have hsE:s∈E := mem_filter.mpr ⟨hsU,by omega⟩
    rw [heq] at hsE
    exact hsne hsE
  · have ho:O.card=2 := by omega
    have heq:O={x1,x3} := by
      apply eq_of_subset_of_card_le
      · intro x hx
        by_contra hh
        have hne1:x≠x1 := by intro he; exact hh (by simp [he])
        have hne3:x≠x3 := by intro he; exact hh (by simp [he])
        have hs:({x1,x3,x}:Finset ℕ)⊆O := by
          intro a ha; simp only [mem_insert,mem_singleton] at ha
          rcases ha with rfl|rfl|rfl
          · exact mem_filter.mpr ⟨hx1,by omega⟩
          · exact mem_filter.mpr ⟨hx3,by omega⟩
          · exact hx
        have hh:=card_le_card hs
        have h13:x1≠x3 := by omega
        have h1x:x1≠x := Ne.symm hne1
        have h3x:x3≠x := Ne.symm hne3
        simp [h13,h1x,h3x] at hh
        omega
      · rw [ho]; exact card_le_two
    have hx1S:x1∈S := (mem_insert.mp hx1).resolve_left (by omega)
    have hx3S:x3∈S := (mem_insert.mp hx3).resolve_left (by omega)
    have hsum:=hp x1 hx1S x3 hx3S (by omega)
    have hother:∀s∈U\{x1,x3},s%2=0 := by
      intro s hs
      obtain ⟨hsU,hsne⟩:=mem_sdiff.mp hs
      by_contra hh
      have hsO:s∈O := mem_filter.mpr ⟨hsU,by omega⟩
      rw [heq] at hsO; exact hsne hsO
    by_cases hl:x1<x3
    · refine ⟨x1,hx1,x3,hx3,hl,by omega,by omega,?_,hload x1 x3⟩
      intro s hs; have :=hother s hs; omega
    · refine ⟨x3,hx3,x1,hx1,by omega,by omega,by omega,?_,hload x3 x1⟩
      intro s hs
      have hs':s∈U\{x1,x3} := by simpa only [pair_comm] using hs
      have :=hother s hs'; omega

#print axioms four_profile_load
#print axioms clique_shape
end OP02.SharpK5

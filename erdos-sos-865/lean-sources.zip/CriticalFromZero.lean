import PositiveCritical
import EvenZero
open Finset
namespace OP02.BothEdges
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot OP02.EdgeBand
theorem critical_from_zero_edgeless (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (hen:NoEdge B (middleZero n B))
    (hmargin:32*(deficit n B+(excessHoles n B).card)+64<n) :
    ∃a b c,Critical n B a b c := by
  obtain ⟨hn,hsub,hfour,hdbl,hholes,hbudget,htri,hprofile⟩:=hc
  obtain ⟨x,hx,y,hy,z,hz,hxy,hxz,hyz,hxs,hys,hzs⟩:=htri
  have ht:LowerTriangle n B {x,y,z} := by
    refine ⟨by simp [hxy,hxz,hyz],?_,?_⟩
    · intro u hu
      simp only [mem_insert,mem_singleton] at hu
      rcases hu with rfl|rfl|rfl <;> assumption
    · intro u hu v hv huv
      have hxsB:=(mem_inter.mp hxs).1
      have hysB:=(mem_inter.mp hys).1
      have hzsB:=(mem_inter.mp hzs).1
      simp only [mem_insert,mem_singleton] at hu hv
      rcases hu with rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl <;> simp_all [Nat.add_comm]
  obtain ⟨a,b,c,hset,hao,hbo,hce,hab8,hc8⟩:=hprofile _ ht
  rw [hset] at ht
  have hsep:Set.InjOn (fun u:ℕ=>u%8) ((insert 0 ({a,b,c}:Finset ℕ):Finset ℕ):Set ℕ) := by
    intro u hu v hv he
    change u∈(insert 0 ({a,b,c}:Finset ℕ)) at hu
    change v∈(insert 0 ({a,b,c}:Finset ℕ)) at hv
    dsimp only at he
    simp only [mem_insert,mem_singleton] at hu hv
    rcases hu with rfl|rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl|rfl <;> omega
  have hp:=excess_partition n B
  have hcrit:c%4=2 ∧ a%4≠b%4 := by
    by_contra hh
    have hn':c%4≠2 ∨ a%4=b%4:=by omega
    obtain ⟨α,hα,T,hT,ha⟩:=noncritical_translate hao hbo hce (r:=0) (by omega) hn'
    have hcnt:=positive_pivot_count n B {a,b,c} hfour ht hsep (by omega) hα T hT ha
    have hsmall:=even_zero_bound n B hdbl hen
    omega
  have hab:a≠b:=by intro h;exact hab8 (h ▸ rfl)
  by_cases hlt:a<b
  · exact ⟨a,b,c,ht,hlt,hao,hbo,hcrit.1,hcrit.2⟩
  · have hswap:({b,a,c}:Finset ℕ)={a,b,c}:=by ext u;simp;tauto
    exact ⟨b,a,c,by rw [hswap];exact ht,by omega,hbo,hao,hcrit.1,Ne.symm hcrit.2⟩


#print axioms critical_from_zero_edgeless
end OP02.BothEdges

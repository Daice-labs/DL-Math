import K8Deletion

open Finset Filter
namespace OP02.SharpK8

theorem seven_blocks (N : ℕ) : ∃ A : Finset ℕ,
    A ⊆ Icc 1 N ∧ EightFree A ∧ A.card = 5461*(N/8192) := by
  let m := N/8192
  refine ⟨OP02.SharpK7.geometricBlocks m 7,?_,?_,?_⟩
  · intro x hx
    obtain ⟨h1,h2⟩ := OP02.SharpK7.blocks_range m 7 x hx
    norm_num at h2
    have hm : 8192*m≤N := by dsimp [m];omega
    exact mem_Icc.mpr ⟨h1,by omega⟩
  · rintro ⟨S,hS,hc,hp⟩
    have := OP02.SharpK7.blocks_clique_size m 7 S hS hp;omega
  · rw [OP02.SharpK7.blocks_card]
    simp [sum_range_succ,m] <;> ring

theorem lower_endpoint (N : ℕ) : 5461*(N/8192)+1 ≤ Erdos865.f N 8 := by
  obtain ⟨A,hs,hf,hc⟩ := seven_blocks N
  by_contra hh
  exact hf (OP02.SharpK4.threshold_spec N 8 A hs (by omega))

theorem extremal_witness (N : ℕ) : ∃ A⊆Icc 1 N, EightFree A ∧ Erdos865.f N 8 ≤ A.card+1 := by
  classical
  have hp := lower_endpoint N
  by_contra hn
  have hle : Erdos865.f N 8 ≤ Erdos865.f N 8 - 1 := by
    apply Nat.sInf_le
    intro A hA hc
    by_contra hbad
    exact hn ⟨A,hA,hbad,by omega⟩
  omega

/-- Original-interval count including padding by at most three and the unit for f. -/
theorem upper_endpoint_of_normalized (hD : Dousse8) (hnorm : NormalizedK8Goal)
    (ε : ℝ) (he : 0<ε) : ∃ N₀ : ℕ, ∀ N : ℕ, N₀ ≤ N →
      (Erdos865.f N 8:ℝ) ≤ (5461/8192+ε)*N := by
  obtain ⟨M,hM,hdel⟩ := deletion hD (ε/4) (by positivity)
  obtain ⟨U,hU⟩ := hnorm ε he
  let c : ℝ := 3*(5461/8192:ℝ)+3*ε/4+3/2
  obtain ⟨V,hV⟩ := exists_nat_gt (2*c/ε)
  refine ⟨max M (max (4*U) V),?_⟩
  intro N hN
  obtain ⟨A,hA,hf,hfa⟩ := extremal_witness N
  obtain ⟨B,hB,hBf,hd,hAB⟩ := hdel N (by omega) A hA hf
  let n := (N+3)/4
  have hu : U≤n := by dsimp [n];omega
  have hb' : B⊆Icc 1 (4*n) := by
    intro x hx
    have h := mem_Icc.mp (hB hx)
    exact mem_Icc.mpr ⟨h.1,by dsimp [n];omega⟩
  have hnb := hU n hu B hb' hBf hd
  have hpad : (4:ℝ)*n ≤ (N:ℝ)+3 := by exact_mod_cast (show 4*n≤N+3 by dsimp [n];omega)
  have hc : (Erdos865.f N 8:ℝ) ≤ (A.card:ℝ)+1 := by exact_mod_cast hfa
  have hVN : (V:ℝ) ≤ N := by exact_mod_cast (show V≤N by omega)
  have hcsmall := (div_lt_iff₀ he).mp (lt_of_lt_of_le hV hVN)
  dsimp [c] at hcsmall
  nlinarith only [hAB,hnb,hpad,hc,hcsmall,mul_nonneg he.le (sub_nonneg.mpr hpad)]

/-- The normalized bound remains an explicit premise of this conversion. -/
theorem limit_of_normalized (hD : Dousse8) (hnorm : NormalizedK8Goal) : SharpK8Limit := by
  unfold SharpK8Limit
  apply Metric.tendsto_atTop.mpr
  intro ε he
  obtain ⟨T,hT⟩ := upper_endpoint_of_normalized hD hnorm (ε/2) (by positivity)
  obtain ⟨M,hM⟩ := exists_nat_gt (5461/ε)
  refine ⟨max 1 (max T M),?_⟩
  intro N hN
  have hpos : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  have hmn : (M:ℝ)≤N := by exact_mod_cast (show M≤N by omega)
  have heN := (div_lt_iff₀ he).mp (lt_of_lt_of_le hM hmn)
  have hup := hT N (by omega)
  have hlow : (5461:ℝ)*((N/8192:ℕ):ℝ)+1 ≤ (Erdos865.f N 8:ℝ) := by
    exact_mod_cast lower_endpoint N
  have hrem : (N:ℝ) ≤ 8192*((N/8192:ℕ):ℝ)+8191 := by
    exact_mod_cast (show N≤8192*(N/8192)+8191 by omega)
  rw [Real.dist_eq,abs_lt]
  constructor
  · apply lt_sub_iff_add_lt.mpr
    apply (lt_div_iff₀ hpos).mpr
    nlinarith only [hlow,hrem,heN]
  · apply sub_lt_iff_lt_add.mpr
    apply (div_lt_iff₀ hpos).mpr
    nlinarith only [hup,mul_pos he hpos]

end OP02.SharpK8

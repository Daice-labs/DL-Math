import K6AmbientRootContract
open Finset
namespace OP02.SharpK6
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.SharpK5
set_option maxHeartbeats 2000000

/-- Unproved order-six geometric obligation, named rather than hidden in a context. -/
def MiddleGap6 (n:ℕ) (B:Finset ℕ) : Prop :=
  ∀x∈middle n B,x%4=0→¬(n+(4*(missingTopOdd n B).card+4)<x ∧
    x<2*(n-4*(n/16))-(4*(missingTopOdd n B).card+4))

/-- Explicit extension of a five-clique. Repeated sum labels are not excluded. -/
theorem five_clique_missing_label (B S:Finset ℕ) (hf:SixFree B)
    (hs:S⊆B) (hc:S.card=5) (hpairs:∀x∈S,∀y∈S,x≠y→x+y∈B)
    (p:ℕ) (hp:p∉S) : ∃s∈insert 0 S,p+s∉B := by
  classical
  by_contra hh
  push_neg at hh
  have hpB : p∈B := by simpa using hh 0 (by simp)
  have hsum : ∀x∈S,p+x∈B := fun x hx=>hh x (mem_insert_of_mem hx)
  apply hf
  refine ⟨insert p S,insert_subset hpB hs,by simp [hp,hc],?_⟩
  intro x hx y hy hxy
  rcases mem_insert.mp hx with hxp|hxS
  · subst x
    rcases mem_insert.mp hy with hyp|hyS
    · exact False.elim (hxy hyp.symm)
    · exact hsum y hyS
  · rcases mem_insert.mp hy with hyp|hyS
    · subst y
      simpa [Nat.add_comm] using hsum x hxS
    · exact hpairs x hxS y hyS hxy


/-- Physical inventory implication only. MiddleGap6 still must be derived
from SixFree; this declaration does not claim that derivation. -/
theorem missing_in_doubled_gap6 (n z:ℕ) (B:Finset ℕ)
    (hgap:MiddleGap6 n B) (hz4:z%4=0) (hzB:z∉B)
    (hzL:2*n+2*(4*(missingTopOdd n B).card+4)<z)
    (hzU:z<4*(n-4*(n/16))-2*(4*(missingTopOdd n B).card+4)) :
    z∈fourResources n B := by
  classical
  have hhole:z∈holes n B := mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hzB⟩
  by_cases he:z∈excessHoles n B
  · exact mem_union_right _ (mem_filter.mpr ⟨he,hz4⟩)
  have hi:z∈(middle n B).image (fun x=>2*x) := by
    by_contra hh
    exact he (mem_sdiff.mpr ⟨hhole,hh⟩)
  obtain ⟨x,hx,rfl⟩:=mem_image.mp hi
  have hx4:x%4≠0 := by
    intro hh
    exact hgap x hx hh ⟨by omega,by omega⟩
  exact mem_union_left _ (mem_image.mpr ⟨x,mem_filter.mpr ⟨hx,by omega⟩,rfl⟩)

#print axioms five_clique_missing_label
#print axioms missing_in_doubled_gap6
end OP02.SharpK6

import K8Profiles
import K8Physical
import K8Admission
import K8EndpointConversion

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8

/-- This actual physical lift covers every internal-seven profile under one numerical account. -/
theorem all_profiles_from_narrow_six {n : ℕ} {B S : Finset ℕ} (hn : 1000000≤n)
    (sub : B ⊆ Icc 1 (4*n)) (hd : DoublingFree B)
    (budget : 1536*(chainDeficit n B+totalBudget n B)<n/4)
    (seed : Internal 7 (B∩Icc 1 n) S) (narrow : NarrowSix n B) :
    ∃ W, Internal 8 B W := by
  classical
  obtain ⟨V,z,cardV,_,six,even,zlo,zhi,small⟩ := narrow
  have nozero : 0∉S := by intro h;have := (mem_Icc.mp (mem_inter.mp (seed.1 h)).2).1;omega
  have size : (insert 0 S).card=8 := by rw [card_insert_of_notMem nozero,seed.2.1]
  have unique : ∀x∈insert 0 S,∀y∈insert 0 S,n<2*x → n<2*y → x=y := by
    intro x hx y hy xbig ybig
    by_contra neq
    have xx := (mem_insert.mp hx).resolve_left (show x≠0 by omega)
    have yy := (mem_insert.mp hy).resolve_left (show y≠0 by omega)
    have := (mem_Icc.mp (mem_inter.mp (seed.2.2 x xx y yy neq)).2).2
    omega
  obtain ⟨T,C,P,win⟩ := profile_window hn size unique zlo zhi (even z (mem_insert_self _ _))
    (fun x hx=>even x (mem_insert_of_mem hx)) small budget
  apply physical_of_windows sub hd (by omega) budget seed cardV six even
    (fun x hx=>by rcases mem_insert.mp hx with h|h
                  · omega
                  · have := small x h;omega)
    (fun p hp=>by have := win.pivot p hp;omega) win.odd win.control _ win.supply
  intro p hp t ht
  obtain ⟨r,edges⟩ := win.target p hp t ht
  have zero := edges 0 (mem_insert_self _ _)
  exact ⟨r,by simpa using zero.1,fun x hx=>(edges x hx).2.1⟩

theorem lift_of_root_supply (supply : RootSupply) : AllProfileLift := by
  intro β hb
  obtain ⟨C,hC⟩ := strict_capacity hb
  obtain ⟨U,hU⟩ := supply β hb
  refine ⟨max 1000000 (max C U),?_⟩
  intro n hn B sub hd hg S seed
  exact all_profiles_from_narrow_six (by omega) sub hd (hC n (by omega) B hd hg) seed
    (dilate_root_six n B (hU n (by omega) B sub hd hg))

theorem endpoint_of_root_supply (hD : Dousse8) (supply : RootSupply) : SharpK8Limit :=
  limit_of_normalized hD (normalized_of_lift hD (lift_of_root_supply supply))

end OP02.SharpK8

import K8ProfilesSpec

open Finset OP02.SharpK5
namespace OP02.SharpK8

/-- At most three controlled offsets in one class modulo four acquire one common safe lift. -/
theorem control_progression (C : Finset ℕ) (b : ℕ) (hb : b<4) (hc : C.card≤3)
    (hz : ∀ c∈C, (b+c)%4=0) :
    ∃ d r : ℕ, (d=8 ∨ d=32) ∧ r<d ∧ (C.card≤1 → d=8) ∧
      ∀ p : ℕ, p%d=r → p%4=b ∧ ∀ c∈C, (p+c)%8=4 ∨ (p+c)%32=16 := by
  classical
  by_cases few : C.card≤1
  · rcases C.eq_empty_or_nonempty with h | ⟨c,hcC⟩
    · refine ⟨8,b,Or.inl rfl,by omega,fun _ => rfl,?_⟩
      intro p hp
      exact ⟨by omega,by simp [h]⟩
    · let r := (12-c%8)%8
      have hbase := hz c hcC
      refine ⟨8,r,Or.inl rfl,Nat.mod_lt _ (by decide),fun _ => rfl,?_⟩
      intro p hp
      change p%8=(12-c%8)%8 at hp
      refine ⟨by omega,?_⟩
      intro a ha
      have he := card_le_one.mp few a ha c hcC
      exact Or.inl (by omega)
  let f (c : ℕ) : Fin 8 := ⟨((b+c)/4)%8,Nat.mod_lt _ (by decide)⟩
  have small : (C.image f).card≤3 := (card_image_le).trans hc
  obtain ⟨W,hCW,_,hW⟩ := exists_subsuperset_card_eq (subset_univ (C.image f)) small
    (by decide : 3≤(univ : Finset (Fin 8)).card)
  obtain ⟨a₁,a₂,a₃,_,_,_,hW'⟩ := card_eq_three.mp hW
  obtain ⟨s,sa,sb,sc⟩ := three_residue_selection a₁ a₂ a₃
  have hs := s.isLt
  refine ⟨32,4*s.val+b,Or.inr rfl,by omega,fun h => (few h).elim,?_⟩
  intro p hp
  refine ⟨by omega,?_⟩
  intro c hcC
  have incl := hCW (mem_image_of_mem f hcC)
  rw [hW'] at incl
  simp only [mem_insert,mem_singleton] at incl
  have allowed : (s.val+(f c).val)%8∈({1,3,4,5,7}:Finset ℕ) := by
    rcases incl with h|h|h
    · simpa only [h] using sa
    · simpa only [h] using sb
    · simpa only [h] using sc
  change (s.val + ((b+c)/4)%8)%8∈({1,3,4,5,7}:Finset ℕ) at allowed
  simp only [mem_insert,mem_singleton] at allowed
  have hbase := hz c hcC
  rcases allowed with h|h|h|h|h <;> omega

end OP02.SharpK8

import K6FinalWindow
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 2000000
def bandNeighbors (n σ:ℕ) (B T:Finset ℕ) :=
  (middle n B).filter (fun y=>y%4=σ ∧ (∀t∈T,y+4*t∈B) ∧
    n+4*(missingTopOdd n B).card+4<y ∧
    y<2*(n-4*(n/16))-(4*(missingTopOdd n B).card+4))

/-- Supply from the first K positions; two global endpoint losses, never one
loss per component. Every translated membership stays in the actual first band. -/
theorem first_band_supply (n u σ:ℕ) (B S T:Finset ℕ)
    (hn:1024≤n) (hq:128*totalBudget n B≤n) (hd:DoublingFree B)
    (hu:2*u<n) (hσ:σ=1 ∨ σ=3) (hs:S⊆Icc 1 n)
    (hTc:T.card=3) (hsmall:∀t∈T,t≤n/16) :
    n/16≤(bandNeighbors n σ B T).card+2*(missingTopOdd n B).card+
      4*(forcedBand n S u σ\B).card+3 := by
  classical
  let K:=n/16
  let hi:=(missingTopOdd n B).card
  let τ:=4*hi+4
  let W:=n-4*K
  let f:=4*((n+u/2+4-σ)/4)+σ
  let Y:=(range K).image (fun i=>f+4*i)
  have hf:n+u/2<f ∧ f≤n+u/2+4 ∧ f%4=σ := by dsimp [f]; rcases hσ with rfl|rfl <;> omega
  have hY (y:ℕ) (hy:y∈Y) : ∃i<K,y=f+4*i := by
    obtain ⟨i,hi,he⟩:=mem_image.mp hy
    exact ⟨i,mem_range.mp hi,he.symm⟩
  have hycard:Y.card=K := by
    rw [card_image_of_injective]
    · exact card_range K
    · intro i j he; change f+4*i=f+4*j at he; omega
  have hyres:∀y∈Y,y%4=σ := by intro y hy; obtain ⟨i,hi,rfl⟩:=hY y hy; omega
  have hyrange:∀y∈Y,n<y ∧ y≤2*W ∧ y≤2*n := by
    intro y hy; obtain ⟨i,hi,rfl⟩:=hY y hy
    dsimp only [W,K] at *; omega
  have hF:∀y∈Y,∀t∈insert 0 T,y+4*t∈forcedBand n S u σ := by
    intro y hy t ht
    obtain ⟨i,hi,rfl⟩:=hY y hy
    have htB:t≤n/16 := by
      rcases mem_insert.mp ht with rfl|ht
      · omega
      · exact hsmall t ht
    simp only [forcedBand,mem_filter,mem_Icc]
    dsimp only [K] at hi
    refine ⟨⟨by omega,by omega⟩,by omega,?_,by omega⟩
    intro a ha
    rcases mem_insert.mp ha with rfl|ha
    · omega
    · have haI:=mem_Icc.mp (hs ha); omega
  let G:=Y.filter (fun y=>∀t∈insert 0 T,y+4*t∈B)
  have hloss:=four_membership_loss Y (forcedBand n S u σ) B T σ hTc hyres hF
  change Y.card≤G.card+4*(forcedBand n S u σ\B).card at hloss
  let A:=progression n (n+τ) 4 σ
  let Z:=progression (2*W-τ-1) (2*W) 4 σ
  have hhiq:hi≤totalBudget n B := by
    have hh:=deficit_split n B hd
    dsimp only [hi]; unfold totalBudget; omega
  have hA:A.card≤hi+1 := by
    rw [progression_card n (n+τ) 4 σ (by omega) (by omega)]
    dsimp only [τ]; omega
  have hZ:Z.card≤hi+2 := by
    have hh:=progression_upper (2*W-τ-1) (2*W) 4 σ (by omega) (by omega)
    change Z.card≤(2*W-(2*W-τ-1))/4+1 at hh
    dsimp only [W,K,τ] at hh
    omega
  have hsub:G⊆bandNeighbors n σ B T∪A∪Z := by
    intro y hy
    obtain ⟨hyY,hall⟩:=mem_filter.mp hy
    have hyB:y∈B := by simpa using hall 0 (by simp)
    have hyrng:=hyrange y hyY
    have hyσ:=hyres y hyY
    by_cases hlo:y≤n+τ
    · exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨mem_Ioc.mpr ⟨hyrng.1,hlo⟩,hyσ⟩))
    by_cases hhi:2*W-τ≤y
    · apply mem_union_right
      refine mem_filter.mpr ⟨mem_Ioc.mpr ⟨?_,hyrng.2.1⟩,hyσ⟩
      dsimp only [W,K,τ] at *; omega
    · apply mem_union_left
      apply mem_union_left
      exact mem_filter.mpr ⟨mem_inter.mpr ⟨hyB,mem_Icc.mpr ⟨by omega,hyrng.2.2⟩⟩,
        hyσ,(fun t ht=>hall t (mem_insert_of_mem ht)),by change n+τ<y; omega,by change y<2*W-τ; omega⟩
  have hcard:=le_trans (card_le_card hsub) (card_union_le (bandNeighbors n σ B T∪A) Z)
  have hcard2:=card_union_le (bandNeighbors n σ B T) A
  rw [hycard] at hloss
  change K≤(bandNeighbors n σ B T).card+2*hi+4*(forcedBand n S u σ\B).card+3
  omega

#print axioms first_band_supply
end OP02.SharpK6

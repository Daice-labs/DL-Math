import FewHole

open Finset

/-- Literal expanded statement: no hidden structural or analytic hypothesis. -/
theorem OP02.FewHole.few_holes_explicit :
    ∀ (n : ℕ) (B : Finset ℕ),
      B ⊆ Finset.Icc 1 (4 * n) →
      (¬ ∃ S ⊆ B, S.card = 4 ∧
        ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ B) →
      (∀ x ∈ B, 2 * x ∉ B) →
      4 * ((Finset.Icc (2 * n + 1) (4 * n)) \ B).card < n →
      8 * B.card ≤ 21 * n + 53 :=
  OP02.FewHole.few_holes

-- The assumptions are inhabited: B={3,4}, n=1 has no upper-half holes.
example : ∃ (n : ℕ) (B : Finset ℕ),
    B ⊆ Icc 1 (4 * n) ∧ OP02.FewHole.FourFree B ∧
    OP02.FewHole.DoublingFree B ∧
    4 * (OP02.FewHole.holes n B).card < n := by
  refine ⟨1, {3, 4}, ?_, ?_, ?_, ?_⟩
  · decide
  · intro h
    obtain ⟨S, hS, hc, _⟩ := h
    have := Finset.card_le_card hS
    norm_num at this
    omega
  · norm_num [OP02.FewHole.DoublingFree]
  · decide

#print OP02.FewHole.FourFree
#print OP02.FewHole.DoublingFree
#print OP02.FewHole.holes
#print OP02.FewHole.excessHoles
#check OP02.FewHole.few_holes_explicit
#print OP02.FewHole.few_holes_explicit
#print axioms OP02Candidate.result
#print axioms Erdos865.erdos865_upper_bound
#print axioms OP02.FewHole.lower_triple_free
#print axioms OP02.FewHole.counting_identity
#print axioms OP02.FewHole.few_holes_with_excess
#print axioms OP02.FewHole.few_holes
#print axioms OP02.FewHole.few_holes_explicit

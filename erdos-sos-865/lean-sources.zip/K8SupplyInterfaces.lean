import K8SmallSupport
import K7PhysicalReductions

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8
open OP02.SharpK7 (logLevels)

def bandOddHoles (h : ℕ) (D : Finset ℕ) : Finset ℕ :=
  (Ioc (h/2) h).filter (fun v=> v%2=1 ∧ v∉D)

theorem odds_unmatched (h : ℕ) (D : Finset ℕ) : bandOddHoles h D ⊆ unmatchedTop h D := by
  intro x hx;obtain ⟨hx,odd,miss⟩ := mem_filter.mp hx
  exact mem_filter.mpr ⟨hx,miss,fun y _ he=>by omega⟩

def CentralTriangleSupply (H : ℕ) (D : Finset ℕ) : Prop :=
  ∀ W : Finset ℕ, W.card ≤ (bandOddHoles (H/4) D).card →
    (5/8:ℝ)*(H/64:ℕ)+(3/4:ℝ)*(Real.log ((H/64:ℕ):ℝ)/Real.log 2)+13/8 <
      ((quarterD (H/16) D \ W).card:ℝ)

theorem uniform_central_triangle_supply {β : ℝ} (hb : 0<β) :
    ∃ U : ℕ, ∀ n : ℕ, U≤n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
    CentralTriangleSupply (n/4) (quarterD n B) := by
  obtain ⟨U,hU⟩ := OP02.SharpK7.uniform_window_threshold β hb
  refine ⟨U,?_⟩
  intro n hn B hd hg W hw
  obtain ⟨hu,margin⟩ := hU n hn
  let H := n/4
  have cost := hw.trans (card_le_card (odds_unmatched _ _))
  have his := central_filtered_surplus hd hg cost
  have hm : 0<H/64 := by dsimp [H];omega
  have hpow : H/64 ≤ 4^(logLevels H) :=
    (Nat.div_le_self _ _).trans (Nat.lt_pow_succ_log_self (b:=4) (by decide) H).le
  have hr : ((H/64:ℕ):ℝ) ≤ (4:ℝ)^(logLevels H) := by exact_mod_cast hpow
  have hlog := Real.log_le_log (show 0<((H/64:ℕ):ℝ) by exact_mod_cast hm) hr
  rw [Real.log_pow,show (4:ℝ)=2*2 by norm_num,Real.log_mul (by norm_num) (by norm_num)] at hlog
  have ht : 0<Real.log 2 := Real.log_pos (by norm_num)
  have hratio : Real.log ((H/64:ℕ):ℝ)/Real.log 2 ≤ 2*(logLevels H:ℝ) := by
    apply (div_le_iff₀ ht).mpr; nlinarith only [hlog]
  change 10*(logLevels H:ℝ)+1000≤β*n at margin
  change (5/8:ℝ)*(H/64:ℕ)+β*n-2 ≤ _ at his
  change (5/8:ℝ)*(H/64:ℕ)+3/4*(Real.log ((H/64:ℕ):ℝ)/Real.log 2)+13/8 < _
  linarith only [hratio,margin,his,Nat.cast_nonneg (α:=ℝ) (logLevels H)]

theorem uniform_fixed_pair_supply {β : ℝ} (hb : 0<β) :
    ∃ U : ℕ, ∀ n : ℕ, U≤n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
      let H := n/4
      let D := quarterD n B
      let Z := quarterD (H/64) D
      ∃ e∈Z, e%2=0 ∧ (∀x∈Z,x%2=0→x≤e) ∧
        (unmatchedTop (H/4) D).card+(unmatchedTop (H/16) D).card <
        (OP02.SharpK7.reflectionPairs Z e).card := by
  obtain ⟨U,hU⟩ := OP02.SharpK7.uniform_window_threshold β hb
  refine ⟨U,?_⟩
  intro n hn B hd hg
  have m := (hU n hn).2
  have room : 4 < β*n := by linarith only [m,Nat.cast_nonneg (α:=ℝ) (logLevels (n/4))]
  obtain ⟨e,he,ee,hm,hh⟩ := fixed_actual_pairs hd hg room
  refine ⟨e,he,ee,hm,?_⟩
  exact_mod_cast (show ((unmatchedTop (n/4/4) (quarterD n B)).card:ℝ)+
    (unmatchedTop (n/4/16) (quarterD n B)).card <
    (OP02.SharpK7.reflectionPairs (quarterD (n/4/64) (quarterD n B)) e).card by
    linarith only [hh,room,Nat.cast_nonneg (α:=ℝ) (totalBudget n B),
      Nat.cast_nonneg (α:=ℝ) (unmatchedTop (n/4) (quarterD n B)).card])

end OP02.SharpK8

import K8Admission
import K8EndpointConversion

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8

theorem density_iff_signed {n : ℕ} {B : Finset ℕ} (β : ℝ)
    (sub : B ⊆ Icc 1 (4*n)) (hd : DoublingFree B) :
    (5461/2048+β)*(n:ℝ)+((n%2:ℕ):ℝ)/2 ≤ B.card ↔ SignedGap β n B := by
  have hI := exact_inventory n B sub hd
  have hi : B.card+totalBudget n B=2*n+(n+1)/2+(quarterD n B).card := by unfold totalBudget;omega
  have hr : (B.card:ℝ)+totalBudget n B=2*(n:ℝ)+((n+1)/2:ℕ)+(quarterD n B).card := by exact_mod_cast hi
  have hc : (2:ℝ)*((n+1)/2:ℕ)=(n:ℝ)+((n%2:ℕ):ℝ) := by
    exact_mod_cast (show 2*((n+1)/2)=n+n%2 by omega)
  unfold SignedGap;constructor <;> intro h <;> linarith only [h,hr,hc]

noncomputable def largestEightFreeCard (N : ℕ) : ℕ := by
  classical
  exact ((Icc 1 N).powerset.filter EightFree).sup Finset.card

/-- The original least forcing cardinality is the maximum free cardinality plus one, also at N=0. -/
theorem threshold_eq_max_plus_one (N : ℕ) :
    Erdos865.f N 8 = largestEightFreeCard N+1 := by
  classical
  obtain ⟨A,sub,hf,ha⟩ := extremal_witness N
  have leA : A.card ≤ largestEightFreeCard N :=
    le_sup (f:=Finset.card) (mem_filter.mpr ⟨mem_powerset.mpr sub,hf⟩)
  have less : largestEightFreeCard N ≤ Erdos865.f N 8-1 := by
    unfold largestEightFreeCard
    apply Finset.sup_le
    intro W hw
    obtain ⟨wSub,wFree⟩ := mem_filter.mp hw
    have low : W.card < Erdos865.f N 8 := by
      by_contra! hh
      exact wFree (OP02.SharpK4.threshold_spec N 8 W (mem_powerset.mp wSub) hh)
    omega
  have positive := lower_endpoint N
  omega

end OP02.SharpK8

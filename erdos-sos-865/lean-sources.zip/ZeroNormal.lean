import ZeroCover
open Finset
namespace OP02.ZeroExcess
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

theorem residue_interval_lower (n r:ℕ) (hr:r<4) :
    n/4 ≤ ((Icc (n+1) (2*n)).filter (fun z=>z%4=r)).card := by
  let f:=fun i:ℕ=>n+1+(r+4-(n+1)%4)%4+4*i
  have hs : (range (n/4)).image f ⊆ (Icc (n+1) (2*n)).filter (fun z=>z%4=r) := by
    intro z hz
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hz
    have hi' := mem_range.mp hi
    refine mem_filter.mpr ⟨mem_Icc.mpr ⟨?_,?_⟩,?_⟩ <;> dsimp [f] <;> omega
  have hi:Function.Injective f := by intro i j hh; dsimp [f] at hh; omega
  have hc := card_le_card hs
  rw [card_image_of_injective _ hi,card_range] at hc
  exact hc

theorem residue_population {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0) {r:ℕ} (hr:r<4) :
    n/4 ≤ ((middle n B).filter (fun z=>z%4=r)).card+
      2*(parityMiddle n B (1-r%2)).card := by
  let X:=(Icc (n+1) (2*n)).filter (fun z=>z%4=r)
  let Y:=(middle n B).filter (fun z=>z%4=r)
  have hs:X⊆(X\middle n B)∪Y := by
    intro x hx
    by_cases hm:x∈middle n B
    · exact mem_union_right _ (mem_filter.mpr ⟨hm,(mem_filter.mp hx).2⟩)
    · exact mem_union_left _ (mem_sdiff.mpr ⟨hx,hm⟩)
  have hc: X.card≤(X\middle n B).card+Y.card := (card_le_card hs).trans (card_union_le _ _)
  have hb:=missing_residue_bound ht hf hd he hr
  have hl:=residue_interval_lower n r hr
  change n/4≤X.card at hl
  change (X\middle n B).card≤_ at hb
  change n/4≤Y.card+_
  omega

theorem even_noedge {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hmargin:32*deficit n B+40<n) : NoEdge B (parityMiddle n B 0) := by
  rcases one_middle_side_edgeless n B hf hd he with h|h
  · exact h
  · have ho:=odd_edgeless_small n B hd he h
    have hbudget:=middle_two_mod_four n B hd
    have hpop:=residue_population ht hf hd he (r:=2) (by omega)
    norm_num at hpop
    omega

theorem odd_population_total {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0) :
    2*(n/4) ≤ (parityMiddle n B 1).card+4*(parityMiddle n B 0).card := by
  have h1:=residue_population ht hf hd he (r:=1) (by omega)
  have h3:=residue_population ht hf hd he (r:=3) (by omega)
  norm_num at h1 h3
  have heq : (parityMiddle n B 1)=((middle n B).filter (fun z=>z%4=1)) ∪
      ((middle n B).filter (fun z=>z%4=3)) := by
    ext z
    have hp : z%2=1 ↔ z%4=1 ∨ z%4=3 := by omega
    simp only [parityMiddle,mem_filter,mem_union,hp]
    tauto
  have hdj : Disjoint ((middle n B).filter (fun z=>z%4=1))
      ((middle n B).filter (fun z=>z%4=3)) := by
    apply disjoint_left.mpr
    intro z hz hz'
    have := (mem_filter.mp hz).2
    have := (mem_filter.mp hz').2
    omega
  have hc:=card_union_of_disjoint hdj
  rw [←heq] at hc
  omega

theorem odd_same_residue_noedge {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hlarge:4*(parityMiddle n B 0).card<n/4)
    (hnon:(parityMiddle n B 0).Nonempty)
    {x y:ℕ} (hx:x∈parityMiddle n B 1) (hy:y∈parityMiddle n B 1)
    (hxy:x≠y) (hmod:x%4=y%4) : x+y∉B := by
  intro hs
  classical
  obtain ⟨w,hw⟩ := hnon
  let r:=4-x%4
  have hxp: x%2=1 := (mem_filter.mp hx).2
  have hyp: y%2=1 := (mem_filter.mp hy).2
  have hr:r<4 := by dsimp [r]; omega
  have hrp:r%2=1 := by dsimp [r]; omega
  let T:=(middle n B).filter (fun z=>z%4=r)
  let F:=fun v=>T.filter (fun z=>v+z∉B)
  have hF:∀v∈parityMiddle n B 1, v%4=x%4 → (F v).card≤(parityMiddle n B 0).card := by
    intro v hv hv4
    have hvi:=mem_Icc.mp (mem_inter.mp (mem_filter.mp hv).1).2
    have hsub : (F v).image (fun z=>(v+z)/2) ⊆ parityMiddle n B 0 := by
      intro t ht'
      obtain ⟨z,hz,rfl⟩ := mem_image.mp ht'
      obtain ⟨hzT,hznot⟩ := mem_filter.mp hz
      obtain ⟨hzM,hz4⟩ := mem_filter.mp hzT
      have hzi:=mem_Icc.mp (mem_inter.mp hzM).2
      obtain ⟨u,hu,hue⟩ := (upper_missing_iff n B hd he
        (mem_Icc.mpr ⟨by omega,by omega⟩)).mp hznot
      have hp:u%2=0 := by dsimp [r] at hz4; omega
      have hu':u=(v+z)/2 := by omega
      exact mem_filter.mpr ⟨hu' ▸ hu,by omega⟩
    have hinj:Set.InjOn (fun z:ℕ=>(v+z)/2) (F v) := by
      intro z hz t ht' heq
      have hz4: z%4=r := (mem_filter.mp (mem_filter.mp hz).1).2
      have ht4: t%4=r := (mem_filter.mp (mem_filter.mp ht').1).2
      dsimp at heq
      omega
    have hc:=card_le_card hsub
    rw [card_image_of_injOn hinj] at hc
    exact hc
  have hcover:T⊆F x∪F y := by
    intro z hz
    by_cases hxz:x+z∈B
    · by_cases hyz:y+z∈B
      · have hzM: z∈middle n B := (mem_filter.mp hz).1
        have hz4: z%4=r := (mem_filter.mp hz).2
        have hzp:z%2=1 := by omega
        have hwp:w%2=0 := (mem_filter.mp hw).2
        have hzdx:x≠z := by dsimp [r] at hz4; omega
        have hzdy:y≠z := by dsimp [r] at hz4; omega
        exact (four_forbidden B hf (mem_inter.mp (mem_filter.mp hx).1).1
          (mem_inter.mp (mem_filter.mp hy).1).1 (mem_inter.mp hzM).1
          (mem_inter.mp (mem_filter.mp hw).1).1 hxy hzdx (by omega) hzdy (by omega)
          (by omega) hs hxz (middle_cross n B hd he (mem_filter.mp hx).1 (mem_filter.mp hw).1 (by omega))
          hyz (middle_cross n B hd he (mem_filter.mp hy).1 (mem_filter.mp hw).1 (by omega))
          (middle_cross n B hd he hzM (mem_filter.mp hw).1 (by omega))).elim
      · exact mem_union_right _ (mem_filter.mpr ⟨hz,hyz⟩)
    · exact mem_union_left _ (mem_filter.mpr ⟨hz,hxz⟩)
  have h1:=hF x hx rfl
  have h2:=hF y hy hmod.symm
  have hcard: T.card≤(F x).card+(F y).card := (card_le_card hcover).trans (card_union_le _ _)
  have hpop:=residue_population ht hf hd he hr
  rw [hrp] at hpop
  norm_num at hpop
  change n/4≤T.card+_ at hpop
  omega

theorem odd_indices_closed {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hlarge:4*(parityMiddle n B 0).card<n/4) :
    MidClosed (parityIndices n B 1) := by
  intro i hi j hj z hz
  obtain ⟨x,hx,hxi⟩ := (parity_indices_mem n B (by omega : 1<2)).mp hi
  obtain ⟨y,hy,hyj⟩ := (parity_indices_mem n B (by omega : 1<2)).mp hj
  let v:=(x+y)/2
  have hxp:x%2=1 := (mem_filter.mp hx).2
  have hyp:y%2=1 := (mem_filter.mp hy).2
  have hvi: v∈Icc (n+1) (2*n) := by
    have hxx:=mem_Icc.mp (mem_inter.mp (mem_filter.mp hx).1).2
    have hyy:=mem_Icc.mp (mem_inter.mp (mem_filter.mp hy).1).2
    exact mem_Icc.mpr ⟨by dsimp [v];omega,by dsimp [v];omega⟩
  have hvp:v%2=1 := by dsimp [v];omega
  have hvM:v∈middle n B := by
    by_cases hxy:x=y
    · have hvx:v=x := by dsimp [v];omega
      exact hvx ▸ (mem_filter.mp hx).1
    by_cases hE:(parityMiddle n B 0).Nonempty
    · have hnot:=odd_same_residue_noedge ht hf hd he hlarge hE hx hy hxy (by omega)
      have hxx:=mem_Icc.mp (mem_inter.mp (mem_filter.mp hx).1).2
      have hyy:=mem_Icc.mp (mem_inter.mp (mem_filter.mp hy).1).2
      obtain ⟨w,hw,hwe⟩ := (upper_missing_iff n B hd he
        (mem_Icc.mpr ⟨by omega,by omega⟩)).mp hnot
      have hwv:w=v := by dsimp [v];omega
      exact hwv ▸ hw
    · by_contra hnot
      obtain ⟨w,hw,hstep⟩:=critical_neighbor ht hf hd he hvi hnot
      have hco:=ht.co
      have hao:=ht.ao
      have hbo:=ht.bo
      have hab:=ht.ab
      have hlt:=ht.lt
      have hwp:w%2=0 := by
        rcases hstep with hh|hh <;> rcases hh with hh|hh <;> omega
      exact hE ⟨w,mem_filter.mpr ⟨hw,hwp⟩⟩
  apply (parity_indices_mem n B (by omega : 1<2)).mpr
  exact ⟨v,mem_filter.mpr ⟨hvM,hvp⟩,by dsimp [v];omega⟩

#print axioms even_noedge
#print axioms odd_population_total
#print axioms odd_indices_closed
end OP02.ZeroExcess

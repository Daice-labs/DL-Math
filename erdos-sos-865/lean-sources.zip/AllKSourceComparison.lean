import OP02Spec
import Batteries.Util.ExtendedBinder

open Finset Filter
open scoped Asymptotics
namespace OP02.AllOrders.PublicComparison

/-- Source definition of the least threshold, elaborated verbatim in a fresh namespace. -/
noncomputable def f (N k : ℕ) : ℕ :=
  sInf {m | ∀ A ⊆ Icc 1 N, A.card ≥ m →
    ∃ S ⊆ A, S.card = k ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ A}

set_option linter.unusedVariables false in
/-- The exact public proposition, including its extended binder. -/
def publicConjecture : Prop :=
    ∀ᵉ (k : ℕ) (hk : 2 ≤ k),
    (fun N ↦ (f N k : ℝ)) ~[atTop] (fun N ↦ (1 / 2 : ℝ) * (1 + ∑ r ∈ Icc 1 (k - 2),
      (1 / 4 : ℝ) ^ r) * N)

theorem sameThreshold : f = Erdos865.f := rfl

theorem sameConjecture : publicConjecture = OP02.GeneralGoal := rfl

#print axioms sameThreshold
#print axioms sameConjecture

end OP02.AllOrders.PublicComparison

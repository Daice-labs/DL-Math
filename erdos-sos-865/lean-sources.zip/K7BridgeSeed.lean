import K7AllocatedHalf
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- Both common-02 and single-residue-two T2 have at most two other
even vertices and at most three odd anchors. Unused roles may repeat
an actual anchor. All physical queries are made relative to one B. -/
theorem bridge_seed_exclusion (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤ n→∀B:Finset ℕ,SevenFree B→DoublingFree B →
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→∀s k h j x₁ x₂ x₃ w:ℕ,
    s≤ n/4→ 4*k≤ n/4→2*k≤ s→k%2=1→4*h≤ s→4*j≤ s→
    (∀x∈({x₁,x₂,x₃}:Finset ℕ),x≤ s ∧ x%2=1) →
    (∀v∈S,v=2*k ∨ v=4*h ∨ v=4*j ∨ v∈({x₁,x₂,x₃}:Finset ℕ)) →
    w≤ s→w%2=1→(∀v∈S,v%2=1→v≠w→v%4≠w%4)→False:=by
  obtain ⟨U,hU⟩:=inventory_uniform β hb
  obtain ⟨V,hV⟩:=uniform_window_threshold β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  obtain ⟨G,hG⟩:=uniform_favorable_band hD hb
  refine ⟨max (4*2^23) (max U (max V (max W G))),?_⟩
  intro n hn B hf hd hg S hS s k h j x₁ x₂ x₃ w hs hk hks ko hh hj xmax cover ws wo singleton
  have hlarge:2^23≤ n/4:=by omega
  obtain ⟨cap,nlarge⟩:=hU n (by omega) B hd hg
  obtain ⟨hscale,hl⟩:=hV n (by omega)
  obtain ⟨a,c,b,z,apos,ac,cb,bz,zlo,zu,wid,ha,hc,hb',hz,hac,hba,hbc,hza,hzc,hzb⟩:=
    actual_bridge_quartet hd hg hlarge hl hs hk cap (η:=bridgeEta n B) (Or.inr (le_refl _))
  have z4:4*z≤ n/4:=by omega
  obtain ⟨r,y,yl,yu,yo,rl,ru,eq,slot,slotsize,direct,roots,high⟩:=
    select_physical_half hd hscale hs hks ko hh hj xmax ac cb bz z4 wid
  have old:internalOn B S:=⟨fun _ h=>(mem_inter.mp (hS.2.1 h)).1,
    fun x hx y hy ne=>(mem_inter.mp (hS.2.2 x hx y hy ne)).1⟩
  have sv:∀v∈S,v≤ n/4:=by intro v hv;exact (mem_Icc.mp (mem_inter.mp (hS.2.1 hv)).2).2
  have rnew:4*r∉S:=by intro hm;have :=sv _ hm;omega
  have rB:4*r∈B:=by simpa using (mem_filter.mp (roots 0 (by simp))).2
  have doubleMissing:2*(y+4*z)∉B:=by
    intro he
    have extended:=append_clique old rB (show ∀v∈S,4*r+v∈B from by
      intro v hv;rcases cover v hv with rfl|rfl|rfl|hv
      · rwa [eq,Nat.mul_add,←Nat.mul_assoc] at he
      · simpa [Nat.mul_add] using (mem_filter.mp (roots h (by simp))).2
      · simpa [Nat.mul_add] using (mem_filter.mp (roots j (by simp))).2
      · exact high _ hv)
    apply hG n (by omega) B hf hd hg (insert (4*r) S) extended (by simp [rnew,hS.1]) _ w (by omega)
    · intro v hv ve hne;rcases mem_insert.mp hv with rfl|hv;omega
      rcases mem_insert.mp hv with rfl|hv;omega
      exact ⟨singleton _ hv (by omega) hne,sv _ hv⟩
    · intro v hv;rcases mem_insert.mp hv with rfl|hv;omega;have :=sv _ hv;omega
  have edge:y+4*z∈B:=by
    by_contra bad
    exact slot (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,slotsize,bad,doubleMissing⟩)
  apply selected_common_half_impossible hf hd (hW n (by omega) B hf hd hg) nlarge cap ac cb bz z4 yu yo
    ha hc hb' hz hac hba hbc hza hzc hzb (by simpa using direct 0 (by simp))
  intro v hv;simp only [mem_insert,mem_singleton] at hv
  rcases hv with rfl|rfl|rfl|rfl <;> first | exact edge | exact direct _ (by simp)

end OP02.SharpK7

import Mathlib

open Finset
namespace OP02.SharpK7

/-- Six successive scales will give the constructive lower endpoint. -/
def geometricBlocks (m : ℕ) : ℕ → Finset ℕ
  | 0 => ∅
  | j+1 => geometricBlocks m j ∪ Ioc (4^j*m) (2*(4^j*m))

theorem blocks_range (m j x : ℕ) (hx : x∈geometricBlocks m j) :
    0 < x ∧ 2*x ≤ 4^j*m := by
  induction j with
  | zero => simp [geometricBlocks] at hx
  | succ j ih =>
    have hh : 4^(j+1)*m=4*(4^j*m) := by ring
    rw [hh]
    rcases mem_union.mp hx with ho | hn
    · have := ih ho; omega
    · have := mem_Ioc.mp hn; omega

theorem blocks_card (m j : ℕ) :
    (geometricBlocks m j).card = ∑ i ∈ range j, 4^i*m := by
  induction j with
  | zero => simp [geometricBlocks]
  | succ j ih =>
    have hh : Disjoint (geometricBlocks m j) (Ioc (4^j*m) (2*(4^j*m))) := by
      apply disjoint_left.mpr
      intro x hx hy
      have := blocks_range m j x hx; have := mem_Ioc.mp hy; omega
    rw [geometricBlocks,card_union_of_disjoint hh,ih,sum_range_succ,Nat.card_Ioc]
    omega

/-- Every internal clique uses at most one vertex per block. -/
theorem blocks_clique_size (m j : ℕ) (S : Finset ℕ)
    (hs : S ⊆ geometricBlocks m j)
    (hp : ∀ x∈S, ∀ y∈S, x≠y → x+y∈geometricBlocks m j) : S.card ≤ j := by
  classical
  induction j generalizing S with
  | zero => simpa [geometricBlocks] using card_le_card hs
  | succ j ih =>
    let T := S ∩ geometricBlocks m j
    have old := inter_subset_right (s₁ := S) (s₂ := geometricBlocks m j)
    have hpT : ∀ x∈T, ∀ y∈T, x≠y → x+y∈geometricBlocks m j := by
      intro x hx y hy hxy
      have hx' := mem_inter.mp hx; have hy' := mem_inter.mp hy
      rcases mem_union.mp (hp x hx'.1 y hy'.1 hxy) with h | h
      · exact h
      · have := blocks_range m j x hx'.2
        have := blocks_range m j y hy'.2
        have := mem_Ioc.mp h
        omega
    have hold := ih T old hpT
    have hnew {x : ℕ} (hx : x∈S \ T) : x∈Ioc (4^j*m) (2*(4^j*m)) := by
      obtain ⟨hxS,hxT⟩ := mem_sdiff.mp hx
      exact (mem_union.mp (hs hxS)).resolve_left (fun a => hxT (mem_inter.mpr ⟨hxS,a⟩))
    have hone : (S \ T).card ≤ 1 := by
      apply card_le_one.mpr
      intro x hx y hy
      by_contra hne
      have h1 := mem_Ioc.mp (hnew hx); have h2 := mem_Ioc.mp (hnew hy)
      rcases mem_union.mp (hp x (mem_sdiff.mp hx).1 y (mem_sdiff.mp hy).1 hne) with h | h
      · have := blocks_range m j (x+y) h; omega
      · have := mem_Ioc.mp h; omega
    have hc := card_sdiff_add_card_eq_card (inter_subset_left (s₁:=S) (s₂:=geometricBlocks m j) : T ⊆ S)
    change (S \ T).card + T.card = S.card at hc
    omega

end OP02.SharpK7

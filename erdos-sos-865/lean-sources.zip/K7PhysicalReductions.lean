import K7ShortOddWindow
import K7TwoKWindow
import K7QualifiedCluster
import K7ProfileRoster
import K7ThreeOddZero
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

private theorem square_le_four_pow (j:ℕ) : j*j≤4^j := by
  induction j with
  | zero => decide
  | succ j ih =>
    rw [pow_succ]
    cases j with
    | zero => decide
    | succ j => nlinarith

theorem uniform_window_threshold (β:ℝ) (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→64≤n/4 ∧ 10*(logLevels (n/4):ℝ)+1000≤β*n := by
  obtain ⟨M,hM⟩:=exists_nat_gt (1020/β)
  refine ⟨max 256 (4*4^M),?_⟩
  intro n hn
  let J:=Nat.log 4 (n/4)
  have hMJ:M≤J:=Nat.le_log_of_pow_le (by decide) (by omega)
  have hJ:J*J≤n:=by
    have hp:=Nat.pow_log_le_self 4 (show n/4≠0 by omega)
    change 4^J≤n/4 at hp
    have hs:=square_le_four_pow J;omega
  have hMr:(1020:ℝ)<β*J:=by
    have hMJ':(M:ℝ)≤J:=by exact_mod_cast hMJ
    have hm:=(div_lt_iff₀ hb).mp hM
    nlinarith only [hm,mul_le_mul_of_nonneg_left hMJ' hb.le]
  have hJpos:1≤J:=Nat.le_log_of_pow_le (by decide) (by norm_num;omega)
  have h1:(1:ℝ)≤J:=by exact_mod_cast hJpos
  have h2:(J:ℝ)*J≤n:=by exact_mod_cast hJ
  refine ⟨by omega,?_⟩
  change 10*((J+1:ℕ):ℝ)+1000≤β*n
  push_cast
  nlinarith only [h1,mul_le_mul_of_nonneg_right hMr.le (show 0≤(J:ℝ) by positivity),
    mul_le_mul_of_nonneg_left h2 hb.le]

theorem short_odd_forces_replacement (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀s t t' h k:ℕ,InternalFive (B∩Icc 1 (n/4)) (insert s {t,t',4*h,2*k}) →
    t%2=1→t'%2=1→t%4≠t'%4→k%2=1→(∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤t) →
    t≤17*(n/4/64) → oddReplacement n t t' h k B := by
  obtain ⟨U,hU⟩:=uniform_window_threshold β hb
  obtain ⟨V,hV⟩:=inventory_uniform β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  refine ⟨max U (max V W),?_⟩
  intro n hn B hf hd hg s t t' h k hs ho ho' hop hk hm ht
  obtain ⟨hcap,hlarge⟩:=hV n (by omega) B hd hg
  obtain ⟨hscale,hl⟩:=hU n (by omega)
  exact (short_odd_window_qualified hd hg hs hscale hl ho ho' hop hk hm ht).resolve_right
    (qualified_J0_exclusion hf hd (hW n (by omega) B hf hd hg) hcap hlarge)

theorem two_k_forces_replacement (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀s u v h k:ℕ,InternalFive (B∩Icc 1 (n/4)) (insert s {u,v,4*h,2*k}) →
    u%2=1→v%2=1→u%4≠v%4→k%2=1→h%2=0→3*(2*k)≤n/4 →
    (∀z∈({u,v,4*h,2*k}:Finset ℕ),z≤2*k) →
    32*(2*k)<9*(n/4)+384*logLevels (n/4)+160 → evenReplacement n u v h k B := by
  obtain ⟨U,hU⟩:=uniform_window_threshold β hb
  obtain ⟨V,hV⟩:=inventory_uniform β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  refine ⟨max U (max V W),?_⟩
  intro n hn B hf hd hg s u v h k hs hu hv hop hk hh hm hmax hband
  obtain ⟨hcap,hlarge⟩:=hV n (by omega) B hd hg
  obtain ⟨hscale,hl⟩:=hU n (by omega)
  exact (two_k_window_qualified hd hg hs hscale hl hu hv hop hk hh hm hmax hband).resolve_right
    (qualified_J0_exclusion hf hd (hW n (by omega) B hf hd hg) hcap hlarge)

theorem row13_of_dispatch (hD:Dousse7) : RowExclusion 13 := by
  intro β hb
  obtain ⟨U,hU⟩:=row13_all_three_odd_zero hD hb
  refine ⟨U,?_⟩
  intro n hn B _ hf hd hg S hs hir
  have hrow:(oddOffsets S).card=3 ∧ (twoOffsets S).card=0:=by
    unfold rowNumber at hir;dsimp only at hir
    split_ifs at hir <;> omega
  apply hU n hn B hf hd hg S hs hrow.1
  intro x hx he
  have hn:(twoOffsets S)=∅:=card_eq_zero.mp hrow.2
  by_contra bad;have h2:x∈twoOffsets S:=mem_filter.mpr ⟨hx,by omega⟩;simp [hn] at h2

def pendingRows : Finset ℕ := openRows.erase 13

theorem normalized_of_pending_rows (hD:Dousse7) (rows:∀i∈pendingRows,RowExclusion i) : NormalizedK7Goal := by
  apply normalized_of_open_rows hD
  intro i hi
  by_cases h:i=13
  · exact h ▸ row13_of_dispatch hD
  · exact rows i (mem_erase.mpr ⟨h,hi⟩)

theorem limit_of_pending_rows (hD:Dousse7) (rows:∀i∈pendingRows,RowExclusion i) : SharpK7Limit :=
  limit_of_normalized hD (normalized_of_pending_rows hD rows)

end OP02.SharpK7

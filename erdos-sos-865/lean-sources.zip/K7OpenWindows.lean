import K7CommonRows
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- The two exclusions depend only on the actual seed and signed gap.
In particular the winning reflection pair may have either parity. -/
theorem closed_O2_windows (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤ n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→SevenFree B→DoublingFree B →
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀s t t' h k:ℕ,InternalFive (B∩Icc 1 (n/4)) (insert s {t,t',4*h,2*k}) →
    t%2=1→t'%2=1→t%4≠t'%4→k%2=1 →
    ( ((∀x∈({t,t',4*h,2*k}:Finset ℕ),x≤ t) ∧ t≤17*(n/4/64)) ∨
      ((∀x∈({t,t',4*h,2*k}:Finset ℕ),x≤2*k) ∧ h%2=0 ∧ 3*(2*k)≤ n/4 ∧
       32*(2*k)<9*(n/4)+384*logLevels (n/4)+160)) → False:=by
  obtain ⟨U,hU⟩:=short_odd_forces_replacement hD hb
  obtain ⟨V,hV⟩:=two_k_forces_replacement hD hb
  obtain ⟨W,hW⟩:=(bridge_rows_of_dispatch hD (i:=5) (Or.inl rfl)) β hb
  obtain ⟨A,hA⟩:=(bridge_rows_of_dispatch hD (i:=14) (Or.inr rfl)) β hb
  refine ⟨max U (max V (max W A)),?_⟩
  intro n hn B sub hf hd hg s t t' h k hs ho ho' hop ko guard
  rcases guard with ⟨hm,ht⟩|⟨hm,he,hl,hb'⟩
  · obtain ⟨T,hT,row⟩:=odd_replacement_in_row14 ho ho' hop ko (hU n (by omega) B hf hd hg s t t' h k hs ho ho' hop ko hm ht)
    exact hA n (by omega) B sub hf hd hg T hT row
  · obtain ⟨T,hT,row⟩:=even_replacement_in_row5 ho ho' hop ko (hV n (by omega) B hf hd hg s t t' h k hs ho ho' hop ko he hl hm hb')
    exact hW n (by omega) B sub hf hd hg T hT row

/-- Exact complementary seed condition after the two closed windows.
All thresholds and the original physical inventory stay outside the
choice of seed. -/
def O2WindowGap:Prop:=
  ∀β:ℝ,0<β→∃n₀:ℕ,∀n:ℕ,n₀≤ n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→SevenFree B→DoublingFree B →
  (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
  ∀ u v h k l:ℕ,u%2=1→v%2=1→u%4≠v%4→0<h→k%2=1→l%2=1→k<l→2*(n/4)<3*(2*l) →
  InternalFive (B∩Icc 1 (n/4)) (insert (2*l) {u,v,4*h,2*k}) →
  (∀ x∈({u,v}:Finset ℕ),(∀a∈({u,v,4*h,2*k}:Finset ℕ),a≤ x)→17*(n/4/64)<x) →
  ((∀a∈({u,v,4*h,2*k}:Finset ℕ),a≤2*k)→
    h%2≠0 ∨ 9*(n/4)+384*logLevels (n/4)+160≤32*(2*k)) → False

theorem row9_of_window_gap (hD:Dousse7) (gap:O2WindowGap) : RowExclusion 9:=by
  intro β hb
  obtain ⟨U,hU⟩:=closed_O2_windows hD hb;obtain ⟨V,hV⟩:=gap β hb
  refine ⟨max U V,?_⟩;intro n hn B sub hf hd hg S hs row
  obtain ⟨u,v,h,k,l,uo,vo,op,hpos,ko,lo,kl,big,seed⟩:=row9_implies_seed hs row
  have ue:=Nat.odd_iff.mp uo;have ve:=Nat.odd_iff.mp vo;have ke:=Nat.odd_iff.mp ko;have le:=Nat.odd_iff.mp lo
  have eqS:({u,v,4*h,2*k,2*l}:Finset ℕ)=insert (2*l) {u,v,4*h,2*k}:=by ext x;simp only [mem_insert,mem_singleton];tauto
  rw [eqS] at seed
  have sw:({u,v,4*h,2*k}:Finset ℕ)={v,u,4*h,2*k}:=Finset.insert_comm _ _ _
  have sum:= (mem_Icc.mp (mem_inter.mp (seed.2.2 (2*k) (by simp) (2*l) (by simp) (by omega))).2).2
  have close:=hU n (by omega) B sub hf hd hg
  apply hV n (by omega) B sub hf hd hg u v h k l ue ve op hpos ke le kl big seed
  · intro x hx hm;by_contra bad;push Not at bad
    rcases mem_insert.mp hx with eq|eq
    · subst x;exact close _ _ _ _ _ seed ue ve op ke (Or.inl ⟨hm,bad⟩)
    · have xv:x=v:=mem_singleton.mp eq
      subst x;rw [sw] at hm seed
      exact close _ _ _ _ _ seed ve ue op.symm ke (Or.inl ⟨hm,bad⟩)
  · intro hm;by_contra bad;push Not at bad
    exact close _ _ _ _ _ seed ue ve op ke (Or.inr ⟨hm,bad.1,by omega,bad.2⟩)

theorem gap_of_row9 (hr:RowExclusion 9) : O2WindowGap:=by
  intro β hb
  obtain ⟨U,hU⟩:=hr β hb
  refine ⟨U,?_⟩;intro n hn B sub hf hd hg u v h k l uo vo op hpos ko lo kl big seed _ _
  have eqS:({u,v,4*h,2*k,2*l}:Finset ℕ)=insert (2*l) {u,v,4*h,2*k}:=by ext x;simp only [mem_insert,mem_singleton];tauto
  obtain ⟨S,hS,row⟩:=seed_implies_row9 (n:=n) (B:=B)
    ⟨u,v,h,k,l,Nat.odd_iff.mpr uo,Nat.odd_iff.mpr vo,op,hpos,Nat.odd_iff.mpr ko,Nat.odd_iff.mpr lo,kl,big,eqS ▸ seed⟩
  exact hU n hn B sub hf hd hg S hS row

def exceptionalWindowRows:Finset ℕ:=remainingAfterBridges.erase 9

theorem o2_iff_remaining_windows (hD:Dousse7) : ActualO2Goal ↔ O2WindowGap :=
  ⟨fun h=>gap_of_row9 (o2_goal_iff_row9.mp h),fun h=>o2_goal_iff_row9.mpr (row9_of_window_gap hD h)⟩

theorem limit_from_open_windows (hD:Dousse7) (gap:O2WindowGap)
    (rows:∀i∈exceptionalWindowRows,RowExclusion i) : SharpK7Limit:=by
  apply limit_after_bridges hD
  intro i hi
  by_cases eq:i=9
  · exact eq ▸ row9_of_window_gap hD gap
  · exact rows i (mem_erase.mpr ⟨eq,hi⟩)

end OP02.SharpK7

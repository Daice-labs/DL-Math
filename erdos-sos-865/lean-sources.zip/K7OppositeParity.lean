import K7LongLattice

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7.LongOddTask

/-- A block of consecutive bases has a good index with at most d later
failures of opposite parity. Failures may occur outside the block. -/
theorem opposite_parity_base (F : Finset ℕ) (d start : ℕ)
    (cap : F.card ≤ 2*d) :
    ∃ g ∈ Icc start (start+2*d+1), g ∉ F ∧
      (F.filter (fun j => g<j ∧ j%2 ≠ g%2)).card ≤ d := by
  classical
  let I := Icc start (start+2*d+1)
  let G := I \ F
  have hI : I.card=2*d+2 := by simp [I,Nat.card_Icc];omega
  have neG : G.Nonempty := by
    by_contra hn
    have hsub : I ⊆ F := by
      intro x hx
      by_contra he
      exact hn ⟨x,mem_sdiff.mpr ⟨hx,he⟩⟩
    have := card_le_card hsub
    omega
  by_cases both : ∃ x ∈ G, ∃ y ∈ G, x%2 ≠ y%2
  · obtain ⟨x,hx,y,hy,diff⟩ := both
    let A := F.filter (fun j => j%2≠x%2)
    let B := F \ A
    have hpart := card_sdiff_add_card_eq_card (filter_subset (fun j => j%2≠x%2) F)
    change B.card + A.card = F.card at hpart
    by_cases small : A.card ≤ d
    · refine ⟨x,(mem_sdiff.mp hx).1,(mem_sdiff.mp hx).2,le_trans (card_le_card ?_) small⟩
      intro j hj;exact mem_filter.mpr ⟨(mem_filter.mp hj).1,(mem_filter.mp hj).2.2⟩
    · refine ⟨y,(mem_sdiff.mp hy).1,(mem_sdiff.mp hy).2,le_trans (card_le_card ?_) (show B.card≤d by omega)⟩
      intro j hj;obtain ⟨hj,_,hp⟩ := mem_filter.mp hj
      apply mem_sdiff.mpr;refine ⟨hj,?_⟩
      intro ha;have := (mem_filter.mp ha).2
      change j%2≠x%2 at this
      omega
  · let g := G.max' neG
    have hg : g∈G := max'_mem _ _
    obtain ⟨hgI,hgF⟩ := mem_sdiff.mp hg
    refine ⟨g,hgI,hgF,?_⟩
    let Danger := F.filter (fun j => g<j ∧ j%2≠g%2)
    let safe := F \ Danger
    let blocks := (range (d+1)).erase ((g-start)/2)
    have gBounds := mem_Icc.mp hgI
    have idin : (g-start)/2 ∈ range (d+1) := mem_range.mpr (by omega)
    have hs : blocks.card=d := by simp [blocks,card_erase_of_mem idin]
    have one (i : ℕ) (hi : i∈blocks) :
        ∃ j∈safe, start+2*i ≤ j ∧ j≤ start+2*i+1 := by
      obtain ⟨ine,hr⟩ := mem_erase.mp hi
      have ilt := mem_range.mp hr
      let x:=start+2*i
      have xI : x∈I := mem_Icc.mpr ⟨by dsimp [x];omega,by dsimp [x];omega⟩
      have yI : x+1∈I := mem_Icc.mpr ⟨by dsimp [x];omega,by dsimp [x];omega⟩
      have cut : x+1<g ∨ g<x := by dsimp [x];omega
      have below (j : ℕ) (jI:j∈I) (jc:j<g) (jo:j%2≠g%2) : j∈safe := by
        apply mem_sdiff.mpr
        refine ⟨by by_contra h;exact both ⟨j,mem_sdiff.mpr ⟨jI,h⟩,g,hg,jo⟩,?_⟩
        intro he;have := (mem_filter.mp he).2.1;omega
      have above (j : ℕ) (jI:j∈I) (jc:g<j) (je:j%2=g%2) : j∈safe := by
        apply mem_sdiff.mpr
        refine ⟨by by_contra h;have := le_max' G j (mem_sdiff.mpr ⟨jI,h⟩);change j≤g at this;omega,?_⟩
        intro he;exact (mem_filter.mp he).2.2 je
      rcases cut with left | right
      · by_cases eq : x%2=g%2
        · exact ⟨x+1,below _ yI left (by omega),by omega,le_rfl⟩
        · exact ⟨x,below _ xI (by omega) eq,le_rfl,by omega⟩
      · by_cases eq : x%2=g%2
        · exact ⟨x,above _ xI right eq,le_rfl,by omega⟩
        · exact ⟨x+1,above _ yI (by omega) (by omega),by omega,le_rfl⟩
    let pay (i : ℕ) : ℕ := if hi : i∈blocks then (one i hi).choose else 0
    have spec (i : ℕ) (hi:i∈blocks) : pay i∈safe ∧ start+2*i≤pay i ∧ pay i≤ start+2*i+1 := by
      simpa [pay,hi] using (one i hi).choose_spec
    have covered : blocks.card ≤ safe.card := by
      apply card_le_card_of_injOn pay (fun i hi=>(spec i hi).1)
      intro i hi j hj eq; have a:=(spec i hi).2;have b:=(spec j hj).2;omega
    have part := card_sdiff_add_card_eq_card (filter_subset (fun j=>g<j ∧ j%2≠g%2) F)
    change safe.card+Danger.card=F.card at part
    change Danger.card≤d
    omega

end OP02.SharpK7.LongOddTask

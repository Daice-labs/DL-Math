import PositiveEdges
import ZeroCapacity
open Finset
namespace OP02.PositivePivot
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess

def hull (A l:ℕ):=(range l).image (fun i=>A+2*i)
def gaps (n A l:ℕ) (B:Finset ℕ):=hull A l\parityMiddle n B 1

theorem hull_mem {A l z:ℕ} (hl:0<l) (ha:A%2=1) :
    z∈hull A l ↔ A≤z ∧ z≤A+2*(l-1) ∧ z%2=1 := by
  constructor
  · intro hz
    obtain ⟨i,hi,rfl⟩:=mem_image.mp hz
    have hi':=mem_range.mp hi
    omega
  · rintro ⟨hlo,hup,hodd⟩
    exact mem_image.mpr ⟨(z-A)/2,mem_range.mpr (by omega),by omega⟩

def badWindow (n A l x p:ℕ) (B:Finset ℕ):=
  ((parityMiddle n B 0).image (fun v=>v-1) ∪ (H0 n B).image (fun h=>h/2-1)) ∪
  (((Ho n B).product (range 2)).image (fun hi=>hi.1-(if 3*n<hi.1 then p else x)-2*hi.2)) ∪
  (((gaps n A l B).product (range 2)).image (fun hi=>hi.1-2*hi.2)) ∪
  (((gaps n A l B).product (range 2)).image (fun hi=>hi.1-x-2*hi.2))

theorem badWindow_card (n A l x p:ℕ) (B:Finset ℕ):
    (badWindow n A l x p B).card≤(parityMiddle n B 0).card+(H0 n B).card+
      2*(Ho n B).card+4*(gaps n A l B).card := by
  unfold badWindow
  apply le_trans (card_union_le _ _)
  apply le_trans (Nat.add_le_add_right (card_union_le _ _) _)
  apply le_trans (Nat.add_le_add_right (Nat.add_le_add_right (card_union_le _ _) _) _)
  apply le_trans (Nat.add_le_add_right (Nat.add_le_add_right (Nat.add_le_add_right (card_union_le _ _) _) _) _)
  have he:=card_image_le (s:=parityMiddle n B 0) (f:=fun v=>v-1)
  have hh:=card_image_le (s:=H0 n B) (f:=fun h=>h/2-1)
  have ho:=card_image_le (s:=(Ho n B).product (range 2))
    (f:=fun hi=>hi.1-(if 3*n<hi.1 then p else x)-2*hi.2)
  have hg1:=card_image_le (s:=(gaps n A l B).product (range 2)) (f:=fun hi=>hi.1-2*hi.2)
  have hg2:=card_image_le (s:=(gaps n A l B).product (range 2)) (f:=fun hi=>hi.1-x-2*hi.2)
  simp only [product_eq_sprod,card_product,card_range] at ho hg1 hg2
  simp only [product_eq_sprod]
  omega

theorem odd_upper_present {n z:ℕ} {B:Finset ℕ} (hr:2*n<z ∧ z≤4*n)
    (ho:z%2=1) (hh:z∉Ho n B) : z∈B := by
  by_contra hb
  rcases missing_split hr hb with hi|he
  · obtain ⟨v,hv,hve⟩:=hi
    omega
  · exact hh (mem_filter.mpr ⟨he,ho⟩)

theorem even_upper_present {n v:ℕ} {B:Finset ℕ} (hr:2*n<2*v ∧ 2*v≤4*n)
    (he:v%2=0) (hv:v∉parityMiddle n B 0) (hh:2*v∉H0 n B) : 2*v∈B := by
  by_contra hb
  rcases missing_split hr hb with hi|hex
  · obtain ⟨w,hw,hwe⟩:=hi
    have h:w=v:=by omega
    subst w
    exact hv (mem_filter.mpr ⟨hw,he⟩)
  · exact hh (mem_filter.mpr ⟨hex,by omega⟩)

/-- All interruptions and odd-hole failures lie in one physical union. -/
theorem positive_usable_window {n A l x p z:ℕ} {B:Finset ℕ}
    (hf:FourFree B) (hl:0<l) (hAo:A%2=1) (hAn:n<A) (hAl:A+2*(l-1)≤2*n)
    (hxB:x∈B) (hxn:x≤n) (hx4:x%4=0) (hxp:0<x)
    (hpB:p∈B) (hpxB:p+x∈B) (hpn:2*n<p) (hp4:p%4=0)
    (hzl:A≤z) (hzu:z+2≤A+2*(l-1)) (hzo:z%2=1) (hclip:p+z+2≤4*n)
    (hgood:z∉badWindow n A l x p B) : A+2*(l-1)<x+z+2 ∧ x+z≤2*n := by
  have hE:z+1∉parityMiddle n B 0 := by
    intro h
    apply hgood
    apply mem_union_left;apply mem_union_left;apply mem_union_left;apply mem_union_left
    exact mem_image.mpr ⟨z+1,h,by omega⟩
  have hH:2*(z+1)∉H0 n B := by
    intro h
    apply hgood
    apply mem_union_left;apply mem_union_left;apply mem_union_left;apply mem_union_right
    exact mem_image.mpr ⟨2*(z+1),h,by omega⟩
  have hgap:∀i<2,z+2*i∉gaps n A l B := by
    intro i hi h
    apply hgood
    apply mem_union_left;apply mem_union_right
    exact mem_image.mpr ⟨(z+2*i,i),mem_product.mpr ⟨h,mem_range.mpr hi⟩,by dsimp;omega⟩
  have hxgap:∀i<2,x+z+2*i∉gaps n A l B := by
    intro i hi h
    apply hgood
    apply mem_union_right
    exact mem_image.mpr ⟨(x+z+2*i,i),mem_product.mpr ⟨h,mem_range.mpr hi⟩,by dsimp;omega⟩
  have hhigh:∀i<2,p+z+2*i∉Ho n B := by
    intro i hi h
    apply hgood
    apply mem_union_left;apply mem_union_left;apply mem_union_right
    refine mem_image.mpr ⟨(p+z+2*i,i),mem_product.mpr ⟨h,mem_range.mpr hi⟩,?_⟩
    dsimp
    rw [if_pos (by omega)]
    omega
  have hlow:∀i<2,x+z+2*i∉Ho n B := by
    intro i hi h
    apply hgood
    apply mem_union_left;apply mem_union_left;apply mem_union_right
    refine mem_image.mpr ⟨(x+z+2*i,i),mem_product.mpr ⟨h,mem_range.mpr hi⟩,?_⟩
    dsimp
    rw [if_neg (by omega)]
    omega
  have hzM:∀i<2,z+2*i∈parityMiddle n B 1 := by
    intro i hi
    have hmem:z+2*i∈hull A l:=(hull_mem hl hAo).mpr ⟨by omega,by omega,by omega⟩
    by_contra hnot
    exact hgap i hi (mem_sdiff.mpr ⟨hmem,hnot⟩)
  have hpz:∀i<2,p+(z+2*i)∈B := by
    intro i hi
    apply odd_upper_present (n:=n) (by omega) (by omega)
    simpa only [Nat.add_assoc] using hhigh i hi
  have hzz:z+(z+2)∈B := by
    have h:=even_upper_present (n:=n) (v:=z+1) (by omega) (by omega) hE hH
    convert h using 1 <;> omega
  have hforbid:(x+z+2≤A+2*(l-1) ∨ 2*n<x+z)→False := by
    intro hor
    have hxs:∀i<2,x+(z+2*i)∈B := by
      intro i hi
      rcases hor with hinside|hupper
      · have hh:x+z+2*i∈hull A l:=(hull_mem hl hAo).mpr ⟨by omega,by omega,by omega⟩
        have hmem:x+z+2*i∈parityMiddle n B 1 := by
          by_contra hnot
          exact hxgap i hi (mem_sdiff.mpr ⟨hh,hnot⟩)
        simpa only [Nat.add_assoc] using (mem_inter.mp (mem_filter.mp hmem).1).1
      · apply odd_upper_present (n:=n) (by omega) (by omega)
        simpa only [Nat.add_assoc] using hlow i hi
    have h0:=hzM 0 (by omega)
    have h1:=hzM 1 (by omega)
    norm_num only [Nat.mul_zero,Nat.mul_one,Nat.add_zero] at h0 h1
    exact four_forbidden B hf hxB hpB (mem_inter.mp (mem_filter.mp h0).1).1
      (mem_inter.mp (mem_filter.mp h1).1).1 (by omega) (by omega) (by omega)
      (by omega) (by omega) (by omega) (by simpa [Nat.add_comm] using hpxB)
      (by simpa using hxs 0 (by omega)) (by simpa using hxs 1 (by omega))
      (by simpa using hpz 0 (by omega)) (by simpa using hpz 1 (by omega)) hzz
  constructor
  · by_contra h;exact hforbid (Or.inl (by omega))
  · by_contra h;exact hforbid (Or.inr (by omega))

#print axioms badWindow_card
#print axioms positive_usable_window
end OP02.PositivePivot

import K6Endpoint
open Finset
namespace OP02.SharpK6
open OP02.FewHole OP02.SmallExcess OP02.PositivePivot
set_option maxHeartbeats 3000000

/-- Actual quarter-root OP02.SharpK5.FiveFreeness under the small physical odd-hole budget.
This does not impose OP02.SharpK5.FiveFree on the original FiveFree set. -/
theorem quarter_five_free (n : ℕ) (B : Finset ℕ)
    (hfive : SixFree B) (hsmall : 12*(Ho n B).card<n) :
    OP02.SharpK5.FiveFree (quarterD n B) := by
  classical
  let E := Ho n B
  let D := quarterD n B
  have he : ¬n≤12*E.card := by dsimp [E]; omega
  have hDfree : OP02.SharpK5.FiveFree D := by
    rintro ⟨S0,hS0,hS0c,hS0pair⟩
    let S := S0.image (fun x=>4*x)
    have hSc : S.card=5 := by
      have hinj : Function.Injective (fun x:ℕ=>4*x) := by intro x y h; change 4*x=4*y at h; omega
      rw [card_image_of_injective _ hinj,hS0c]
    have hS : S⊆Icc 1 n := by
      intro x hx
      obtain ⟨r,hr,rfl⟩ := mem_image.mp hx
      have hr := mem_Icc.mp (mem_filter.mp (hS0 hr)).1
      exact mem_Icc.mpr ⟨by omega,by omega⟩
    have hSB : S⊆B := by
      intro x hx
      obtain ⟨r,hr,rfl⟩ := mem_image.mp hx
      exact (mem_filter.mp (hS0 hr)).2
    have hSeven : ∀x∈S,x%2=0 := by
      intro x hx
      obtain ⟨r,hr,rfl⟩ := mem_image.mp hx
      omega
    have hpair : ∀x∈S,∀y∈S,x≠y→x+y∈B := by
      intro x hx y hy hxy
      obtain ⟨r,hr,rfl⟩ := mem_image.mp hx
      obtain ⟨s,hs,rfl⟩ := mem_image.mp hy
      have hrs : r≠s := by omega
      have hh := (mem_filter.mp (hS0pair r hr s hs hrs)).2
      simpa only [Nat.mul_add] using hh
    have hzero : (0 : ℕ) ∉ S := by
      intro hz
      have hzI := Finset.mem_Icc.mp (hS hz)
      omega
    let U : Finset ℕ := insert 0 S
    have hUc : U.card = 6 := by simp [U, hzero, hSc]
    let J : Finset ℕ := Finset.Icc 1 ((n + 1) / 2)
    have oddHole (z : ℕ) (hz1 : 2 * n + 1 ≤ z) (hz4 : z ≤ 4 * n)
        (hzodd : z % 2 = 1) (hzB : z ∉ B) : z ∈ E := by
      apply mem_filter.mpr
      refine ⟨?_,hzodd⟩
      change z ∈ (Icc (2*n+1) (4*n) \ B) \ (middle n B).image (fun x=>2*x)
      refine mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨hz1,hz4⟩,hzB⟩,?_⟩
      intro hz
      obtain ⟨q,hq,hqz⟩ := mem_image.mp hz
      omega
    have hcover : ∀ j ∈ J, ∃ u ∈ U, (2 * n + 2 * j - 1) + u ∈ E := by
      intro j hj
      have hjI : j ∈ Finset.Icc 1 ((n + 1) / 2) := hj
      obtain ⟨hj1, hj2⟩ := Finset.mem_Icc.mp hjI
      let p : ℕ := 2 * n + 2 * j - 1
      have hp1 : 2 * n + 1 ≤ p := by dsimp [p]; omega
      have hp3 : p ≤ 3 * n := by dsimp [p]; omega
      have hpodd : p % 2 = 1 := by dsimp [p]; omega
      have hno : ¬ (p ∈ B ∧ ∀ x ∈ S, p + x ∈ B) := by
        rintro ⟨hpB, hsum⟩
        have hpS : p ∉ S := by
          intro hp
          have hpI := Finset.mem_Icc.mp (hS hp)
          omega
        apply hfive
        refine ⟨insert p S, Finset.insert_subset hpB hSB, ?_, ?_⟩
        · simp [hpS, hSc]
        · intro x hx y hy hxy
          rcases Finset.mem_insert.mp hx with hxp | hxS
          · subst x
            rcases Finset.mem_insert.mp hy with hyp | hyS
            · exact (hxy hyp.symm).elim
            · exact hsum y hyS
          · rcases Finset.mem_insert.mp hy with hyp | hyS
            · subst y
              simpa [add_comm] using hsum x hxS
            · exact hpair x hxS y hyS hxy
      by_cases hpB : p ∈ B
      · by_cases hlink : ∀ x ∈ S, p + x ∈ B
        · exact False.elim (hno ⟨hpB, hlink⟩)
        · push_neg at hlink
          obtain ⟨x, hx, hpx⟩ := hlink
          have hxb := Finset.mem_Icc.mp (hS hx)
          have hxe := hSeven x hx
          refine ⟨x, ?_, ?_⟩
          · change x ∈ insert 0 S
            exact Finset.mem_insert_of_mem hx
          · change p + x ∈ E
            exact oddHole (p + x) (by omega) (by omega) (by omega) hpx
      · refine ⟨0, ?_, ?_⟩
        · simp [U]
        · change p + 0 ∈ E
          simpa only [Nat.add_zero] using oddHole p hp1 (by omega) hpodd hpB
    have hJsub : J ⊆ (U.product E).image
        (fun z : ℕ × ℕ => (z.2 - z.1 - 2 * n + 1) / 2) := by
      intro j hj
      obtain ⟨u, hu, hzu⟩ := hcover j hj
      refine Finset.mem_image.mpr
        ⟨(u, (2 * n + 2 * j - 1) + u),
          Finset.mem_product.mpr ⟨hu, hzu⟩, ?_⟩
      have hj1 := (Finset.mem_Icc.mp hj).1
      change (((2 * n + 2 * j - 1) + u - u - 2 * n + 1) / 2) = j
      omega
    have hJbound : J.card ≤ 6 * E.card := by
      calc
        J.card ≤ ((U.product E).image
            (fun z : ℕ × ℕ => (z.2 - z.1 - 2 * n + 1) / 2)).card :=
          Finset.card_le_card hJsub
        _ ≤ (U.product E).card := Finset.card_image_le
        _ = 6 * E.card := by rw [Finset.product_eq_sprod, Finset.card_product, hUc]
    have hJcard : J.card = (n + 1) / 2 := by
      dsimp [J]
      rw [Nat.card_Icc]
      omega
    rw [hJcard] at hJbound
    have hbad : n ≤ 12 * E.card := by omega
    exact he hbad
  exact hDfree

#print axioms quarter_five_free
end OP02.SharpK6

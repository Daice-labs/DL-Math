import K6HighVertex
import K6Replacement
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 3000000

theorem pair_profile_impossible (n u v:ℕ) (B S Q:Finset ℕ)
    (hn:65536≤n) (hf:SixFree B) (hd:DoublingFree B)
    (hg:MiddleGap6 n B) (hq:512*totalBudget n B≤n)
    (hk:384*(chainDeficit n B+totalBudget n B)≤n)
    (hcanon:6*(canonicalHoles n B).card<n/32)
    (hS:S⊆lower n B) (hSc:S.card=5)
    (hpairs:∀x∈S,∀y∈S,x≠y → x+y∈lower n B)
    (hu:u∈insert 0 S) (hv:v∈S) (huv:u<v) (hul:2*u<n)
    (hres:(u+2)%4=v%4)
    (hpar:∀x∈insert 0 S\{u,v},x%2≠u%2)
    (hload:∀j:ℕ,((insert 0 S\{u,v}).filter (fun x=>x%4=j)).card≤4)
    (hQ:Q⊆quarterD n B) (hQc:Q.card=3)
    (hQp:∀x∈Q,∀y∈Q,x≠y → x+y∈quarterD n B)
    (hsmall:∀t∈Q,t≤n/16) : False := by
  classical
  have hpB:∀x∈S,∀y∈S,x≠y → x+y∈B := fun x hx y hy hxy=>(mem_inter.mp (hpairs x hx y hy hxy)).1
  have hvhigh:=designated_high_vertex n u v B S Q hn hf hd hq hg hS hSc hpB hu (mem_insert_of_mem hv) hul hres hpar hload hQ hQc hQp hsmall
  let V:=highThreshold n B
  let T:=S.erase v
  have hvI:=mem_Icc.mp (mem_inter.mp (hS hv)).2
  have hbud:=band_budget n 1 B hd (Or.inl rfl)
  have hV:8*V≤3*n+128 := by dsimp [V]; omega
  have hVP:V<n-V-1 := by omega
  have hTV:T⊆Icc 1 V := by
    intro x hx
    obtain ⟨hxv,hxS⟩:=mem_erase.mp hx
    have hxI:=mem_Icc.mp (mem_inter.mp (hS hxS)).2
    have hsum:=mem_Icc.mp (mem_inter.mp (hpairs x hxS v hv hxv)).2
    exact mem_Icc.mpr ⟨hxI.1,by change x≤highThreshold n B; omega⟩
  have hTc:T.card=4 := by dsimp only [T]; rw [card_erase_of_mem hv,hSc]
  have huT:u∈insert 0 T := by
    rcases mem_insert.mp hu with hu0|huS
    · exact mem_insert.mpr (Or.inl hu0)
    · exact mem_insert_of_mem (mem_erase.mpr ⟨by omega,huS⟩)
  have hparT:∀x∈insert 0 T\{u},x%2≠u%2 := by
    intro x hx
    obtain ⟨hxU,hxu⟩:=mem_sdiff.mp hx
    have hxu':x≠u := by simpa only [mem_singleton] using hxu
    have hxv:x≠v := by
      rcases mem_insert.mp hxU with hx0|hxT
      · omega
      · exact (mem_erase.mp hxT).1
    have hxS:x∈insert 0 S := by
      rcases mem_insert.mp hxU with hx0|hxT
      · exact mem_insert.mpr (Or.inl hx0)
      · exact mem_insert_of_mem (mem_erase.mp hxT).2
    exact hpar x (mem_sdiff.mpr ⟨hxS,by simp [hxu',hxv]⟩)
  have hsupply:=replacement_supply n V (chainDeficit n B) (totalBudget n B) (missingTopOdd n B).card
    hn hq hk hbud.2.2.2.2
  obtain ⟨p,hpL,hpH,hpResidue,hlabels⟩:=replacement_exists n V u B T (by omega) hd hTV hTc huT hparT hV hsupply
  have hpB:p∈B := by simpa using hlabels 0 (by simp)
  have hpT:p∉T := by intro hh; have :=mem_Icc.mp (hTV hh); omega
  let S':=insert p T
  have hS'c:S'.card=5 := by simp [S',hpT,hTc]
  have hS'lower:S'⊆lower n B := by
    intro x hx
    rcases mem_insert.mp hx with hxp|hxT
    · subst x; exact mem_inter.mpr ⟨hpB,mem_Icc.mpr ⟨by omega,by omega⟩⟩
    · exact hS (mem_erase.mp hxT).2
  have hS'pairs:∀x∈S',∀y∈S',x≠y→x+y∈lower n B := by
    intro x hx y hy hxy
    rcases mem_insert.mp hx with hxp|hxT
    · subst x
      rcases mem_insert.mp hy with hyp|hyT
      · exact False.elim (hxy hyp.symm)
      · have hyI:=mem_Icc.mp (hTV hyT)
        exact mem_inter.mpr ⟨hlabels y (mem_insert_of_mem hyT),mem_Icc.mpr ⟨by omega,by omega⟩⟩
    · rcases mem_insert.mp hy with hyp|hyT
      · subst y
        have hxI:=mem_Icc.mp (hTV hxT)
        have hh:=hlabels x (mem_insert_of_mem hxT)
        rw [Nat.add_comm] at hh
        exact mem_inter.mpr ⟨hh,mem_Icc.mpr ⟨by omega,by omega⟩⟩
      · exact hpairs x (mem_erase.mp hxT).2 y (mem_erase.mp hyT).2 hxy
  have hpUmod:(p+u)%8=4 := by
    -- The selected membership is a quarter-root only through its residue.
    -- Reconstruct it from doubling-free odd singleton slots is not valid;
    -- use the strengthened replacement theorem's explicit residue conclusion.
    exact hpResidue
  have hpar':∀x∈insert 0 S'\{u,p},x%2≠u%2 := by
    intro x hx
    obtain ⟨hxU,hxne⟩:=mem_sdiff.mp hx
    have hxu:x≠u := by simpa using (show x∉({u}:Finset ℕ) from fun h=>hxne (mem_insert.mpr (Or.inl (mem_singleton.mp h))))
    have hxp:x≠p := by intro h; exact hxne (by simp [h])
    have hxT:x∈insert 0 T := by
      rcases mem_insert.mp hxU with h0|hxS
      · exact mem_insert.mpr (Or.inl h0)
      · exact mem_insert_of_mem ((mem_insert.mp hxS).resolve_left hxp)
    exact hparT x (mem_sdiff.mpr ⟨hxT,by simpa⟩)
  have hload':∀j:ℕ,((insert 0 S'\{u,p}).filter (fun x=>x%4=j)).card≤4 := by
    intro j
    have hsub:insert 0 S'\{u,p}⊆insert 0 T\{u} := by
      intro x hx
      obtain ⟨hxU,hxne⟩:=mem_sdiff.mp hx
      simp only [S',mem_insert] at hxU
      rcases hxU with h0|hp|hxT
      · exact mem_sdiff.mpr ⟨mem_insert.mpr (Or.inl h0),by intro h; exact hxne (mem_insert.mpr (Or.inl (mem_singleton.mp h)))⟩
      · exact False.elim (hxne (by simp [hp]))
      · exact mem_sdiff.mpr ⟨mem_insert_of_mem hxT,by intro h; exact hxne (mem_insert.mpr (Or.inl (mem_singleton.mp h)))⟩
    have huTc:(insert 0 T\{u}).card≤4 := by
      rw [card_sdiff_of_subset (by simpa using huT)]
      have:=card_insert_le 0 T
      simp only [card_singleton]
      omega
    exact le_trans (card_filter_le _ _) (le_trans (card_le_card hsub) huTc)
  have hu':u∈insert 0 S' := by
    rcases mem_insert.mp huT with h0|huT
    · exact mem_insert.mpr (Or.inl h0)
    · exact mem_insert_of_mem (mem_insert_of_mem huT)
  by_cases huo:u%2=1
  · have hres':(u+2)%4=p%4 := by omega
    have hpHigh:=designated_high_vertex n u p B S' Q hn hf hd hq hg hS'lower hS'c
      (fun x hx y hy hxy=>(mem_inter.mp (hS'pairs x hx y hy hxy)).1)
      hu' (by simp [S']) hul hres' hpar' hload' hQ hQc hQp hsmall
    change n-p≤V at hpHigh
    omega
  · have hu0:u=0 := by
      by_contra hh
      have h0:=hpar 0 (mem_sdiff.mpr ⟨by simp,by simp only [mem_insert,mem_singleton]; omega⟩)
      omega
    have hp4:p%4=0 := by omega
    have hEven:S'.filter (fun x=>x%2=0)={p} := by
      ext x
      simp only [mem_filter,mem_singleton]
      constructor
      · rintro ⟨hx,hxe⟩
        rcases mem_insert.mp hx with hp|hxT
        · exact hp
        · have hpos:= (mem_Icc.mp (hTV hxT)).1
          have hparx:=hparT x (mem_sdiff.mpr ⟨mem_insert_of_mem hxT,by simp [hu0]; omega⟩)
          omega
      · intro he; subst x; exact ⟨by simp [S'],by omega⟩
    have hOdd:(S'.filter (fun x=>x%2=1)).card=4 := by
      have hpartition: S'.card=(S'.filter (fun x=>x%2=0)).card+(S'.filter (fun x=>x%2=1)).card := by
        apply partition_card
        · intro x; simp only [mem_filter]; constructor
          · intro hx; by_cases he:x%2=0
            · exact Or.inl ⟨hx,he⟩
            · exact Or.inr ⟨hx,by omega⟩
          · tauto
        · intro x hx hy; have:=(mem_filter.mp hx).2; have:=(mem_filter.mp hy).2; omega
      rw [hEven,card_singleton] at hpartition
      omega
    apply easy_profile_excluded n B S' hf hS'lower hS'c
      (fun x hx y hy hxy=>(mem_inter.mp (hS'pairs x hx y hy hxy)).1) hcanon
    apply Or.inr; apply Or.inr; apply Or.inr; apply Or.inr
    refine ⟨Or.inr hOdd,?_⟩
    intro x hx hxe
    have hxE:x∈S'.filter (fun x=>x%2=0):=mem_filter.mpr ⟨hx,hxe⟩
    rw [hEven] at hxE
    simpa only [mem_singleton.mp hxE] using hp4

#print axioms pair_profile_impossible
end OP02.SharpK6

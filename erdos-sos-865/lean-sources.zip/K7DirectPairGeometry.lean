import K7LongOddProof
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

theorem half_residues {x p y z w:ℕ} (px:p<x) (po:p%2=1) (xo:x%2=1) (op:p%4≠x%4)
    (ry:y%4=(6-((x-p)/2)%4)%4) (eq:w+p=2*(y+4*z)) :
    y%2=1 ∧ w%2=1 ∧ (w+x)%8=4 := by
  let δ:=(x-p)/2
  have dx:x=p+2*δ:=by dsimp [δ];omega
  have od:δ%2=1:=by omega
  change y%4=(6-δ%4)%4 at ry
  have sm:w+x=2*y+8*z+2*δ:=by omega
  rw [sm];omega

theorem half_numeric {n H p x s b z y :ℕ}
    (eqH:H=n/4) (px:p<x) (xs:x≤ s) (sH:s≤H) (bz:b<z) (zH:4*z≤H)
    (po:p%2=1) (xo:x%2=1) (op:p%4≠x%4)
    (lower:halfLo H (p/2) z+3<y) (upper:y≤halfHi H s (p/2) b z)
    (ry:y%4=(6-((x-p)/2)%4)%4) :
    let w:=2*(y+4*z)-p
    H/2<y ∧ y+4*b≤H ∧ y%2=1 ∧ 2*H+2<w ∧ w+s≤4*H ∧ w%2=1 ∧
      w+p=2*(y+4*z) ∧ (w+x)%8=4 ∧ H/2<(w+x)/4 ∧ (w+x)/4≤H ∧ 2*(y+4*z)≤n := by
  let w:=2*(y+4*z)-p
  have l1:H/2≤halfLo H (p/2) z:=le_max_left _ _
  have l2:H+p/2-4*z≤halfLo H (p/2) z:=le_max_right _ _
  have u1:halfHi H s (p/2) b z≤H-4*b:=min_le_left _ _
  have u2:halfHi H s (p/2) b z≤(4*H+2*(p/2)-s)/2-4*z:=min_le_right _ _
  have ylo:H/2<y:=by omega
  have yb:y+4*b≤H:=by omega
  have eq:w+p=2*(y+4*z):=by dsimp [w];omega
  have wl:2*H+2<w:=by omega
  have wh:w+s≤4*H:=by omega
  obtain ⟨yo,wo,rr⟩:=half_residues px po xo op ry eq
  exact ⟨ylo,yb,yo,wl,wh,wo,eq,rr,by omega,by omega,by omega⟩

end OP02.SharpK7.LongOddTask

import AdjacentSumset
import PositiveGlobal
open Finset
namespace OP02.EdgeBand
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot

theorem actual_prefix_data (n:ℕ) (B:Finset ℕ)
    (hn:4*((parityMiddle n B 0).card+(H0 n B).card)+4≤n) :
    ∃r p:ℕ,∃G:Finset ℕ,∃b:ℕ,
      G.card+b=(quarterD n B).card ∧
      r+b≤(parityMiddle n B 0).card+(H0 n B).card ∧
      G⊆quarterD n B ∧ 2*n<p ∧ p%4=0 ∧ p≤2*n+4*r+4 ∧
      p∈B ∧ ∀d∈G,p+4*d∈B := by
  let Q:=actualQ n B
  let q0:=(parityMiddle n B 0).card+(H0 n B).card
  have hQ:Q.card≤q0 := by
    have hu:=card_union_le (parityMiddle n B 0) ((H0 n B).image (fun h=>h/2))
    have hi:=card_image_le (s:=H0 n B) (f:=fun h=>h/2)
    dsimp [Q,q0,actualQ]
    omega
  let y:=firstEven n
  have hy:=firstEven_spec n
  change n<y ∧ y≤n+2 ∧ y%2=0 at hy
  have hinj:Set.InjOn (fun i:ℕ=>y+2*i) (range (Q.card+1)) := by
    intro i hi j hj he;dsimp only at he;omega
  obtain ⟨i,hi,hnot⟩:=avoid_card Q (fun i=>y+2*i) hinj
  have hex:∃j:ℕ,y+2*j∉Q:=⟨i,hnot⟩
  let r:=Nat.find hex
  have hrnot:y+2*r∉Q:=Nat.find_spec hex
  have hr: r≤Q.card := by
    have hri:=Nat.find_min' hex hnot
    have hii:=mem_range.mp hi
    dsimp [r]
    omega
  have hpref:∀j<r,y+2*j∈Q := by
    intro j hj
    by_contra hh
    have hh':=Nat.find_min' hex hh
    change r≤j at hh'
    omega
  let Y:=y+2*r
  let Bad:=(quarterD n B).filter (fun d=>Y+2*d∈Q)
  let Good:=quarterD n B\Bad
  have hbadsub:Bad⊆quarterD n B:=filter_subset _ _
  have hgsub:Good⊆quarterD n B:=sdiff_subset
  have hsum:Good.card+Bad.card=(quarterD n B).card:=card_sdiff_add_card_eq_card hbadsub
  have hpay:r+Bad.card≤Q.card := by
    let P:=(range r).image (fun j=>y+2*j)
    let F:=Bad.image (fun d=>Y+2*d)
    have hP:P⊆Q := by
      intro z hz;obtain ⟨j,hj,rfl⟩:=mem_image.mp hz
      exact hpref j (mem_range.mp hj)
    have hF:F⊆Q := by
      intro z hz;obtain ⟨d,hd,rfl⟩:=mem_image.mp hz
      exact (mem_filter.mp hd).2
    have hdis:Disjoint P F := by
      apply disjoint_left.mpr
      intro z hz hz'
      obtain ⟨j,hj,hje⟩:=mem_image.mp hz
      obtain ⟨d,hd,hde⟩:=mem_image.mp hz'
      have hj':=mem_range.mp hj
      have hdI:=mem_Icc.mp (mem_filter.mp (hbadsub hd)).1
      dsimp [Y] at hde
      omega
    have hc:=card_le_card (union_subset hP hF)
    rw [card_union_of_disjoint hdis] at hc
    have hPc:P.card=r := by
      dsimp [P]
      rw [card_image_of_injective]
      · exact card_range _
      · intro j k he;dsimp only at he;omega
    have hFc:F.card=Bad.card := by
      apply card_image_of_injective
      intro j k he;dsimp only at he;omega
    omega
  have hpresent:∀v:ℕ,v∉Q→v%2=0→2*n<2*v→2*v≤4*n→2*v∈B := by
    intro v hv he hlo hup
    apply even_upper_present ⟨hlo,hup⟩ he
    · intro hh;exact hv (mem_union_left _ hh)
    · intro hh
      apply hv
      apply mem_union_right
      exact mem_image.mpr ⟨2*v,hh,by omega⟩
  have hpB:2*Y∈B:=hpresent Y hrnot (by dsimp [Y];omega)
    (by dsimp [Y];omega) (by dsimp [Y,q0] at *;omega)
  refine ⟨r,2*Y,Good,Bad.card,hsum,?_,hgsub,?_,?_,?_,hpB,?_⟩
  · exact hpay.trans hQ
  · dsimp [Y];omega
  · dsimp [Y];omega
  · dsimp [Y];omega
  · intro d hdG
    have hdI:=mem_Icc.mp (mem_filter.mp (hgsub hdG)).1
    have hnot:Y+2*d∉Q := by
      intro hh
      exact (mem_sdiff.mp hdG).2 (mem_filter.mpr ⟨hgsub hdG,hh⟩)
    have h:=hpresent (Y+2*d) hnot (by dsimp [Y];omega)
      (by dsimp [Y];omega) (by dsimp [Y,q0] at *;omega)
    convert h using 1 <;> omega

#print axioms actual_prefix_data
end OP02.EdgeBand

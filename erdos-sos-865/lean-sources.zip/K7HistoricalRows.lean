import K7FavorableBand
import K7ReplacementRows
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7
set_option maxHeartbeats 900000

/-- Choose an actual extension y of the entire five with the residue
opposite to its common odd residue. Its translated labels and y all lie
in the lower interval. -/
theorem homogeneous_lower_extension {n c:ℕ} {B S:Finset ℕ} (hd:DoublingFree B)
    (hcap:384*(chainDeficit n B+totalBudget n B)≤n/4) (hn:65536≤n)
    (hs:InternalFive (B∩Icc 1 (n/4)) S) (ho:(oddOffsets S).card≤3)
    (hc:c<4) (hco:c%2=1) (hclass:∀x∈S,x%2=1→x%4=c) :
    ∃y:ℕ,n/2<y ∧ 4*y≤3*n ∧ y%2=1 ∧ y%4≠c ∧ internalOn B (insert y S) := by
  classical
  let r:=(4-c)%4
  let O:=insert 0 S
  have hres:r<4 ∧ r%2=1 ∧ (r+c)%4=0:=by dsimp [r];omega
  have hp:∀x∈O,(r+x)%4≠2:=by
    intro x hx;rcases mem_insert.mp hx with h|h
    · omega
    · by_cases hox:x%2=1
      · have :=hclass x h hox;omega
      · omega
  have hodd:(O.filter (fun x=>(r+x)%2=0)).card≤3:=by
    apply (card_le_card _).trans ho
    intro x hx;obtain ⟨h,he⟩:=mem_filter.mp hx;rcases mem_insert.mp h with h|h
    · omega
    · exact mem_filter.mpr ⟨h,by omega⟩
  obtain ⟨v,hv,hr,hcan⟩:=canonical_profile_class O r hres.1 hp hodd
  let P:=progression (n/2) (3*n/4) 32 v
  let E:=(Ioc (n/2) n).filter (fun z=>canonical z=true ∧ z∉B)
  have hE:E.card≤chainDeficit n B+totalBudget n B:=canonical_lower_losses n B hd
  have hO:O.card≤6:=by have :=card_insert_le 0 S;have h5:=hs.1;dsimp [O];omega
  have hT:∀x∈O,x≤n/4:=by
    intro x hx;rcases mem_insert.mp hx with rfl|h;omega;exact (mem_Icc.mp (mem_inter.mp (hs.2.1 h)).2).2
  have pd {y:ℕ} (hy:y∈P):n/2<y ∧ y≤3*n/4 ∧ y%32=v:=by
    obtain ⟨h,hr'⟩:=mem_filter.mp hy;exact ⟨(mem_Ioc.mp h).1,(mem_Ioc.mp h).2,hr'⟩
  have hcnt:=shift_losses P O B E 1 0 6 (by intro _ _;omega) (by
    intro y hy x hx hab;have hh:=pd hy;have xu:=hT x hx
    exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,hcan y hh.2.2 x hx,hab⟩)
    (fun _ _=>(card_filter_le _ _).trans hO)
  have plen:=progression_lower (n/2) (3*n/4) 32 v (by decide) hv
  change _≤P.card at plen
  obtain ⟨y,hy⟩:=card_pos.mp (show 0<(passes P O B).card by omega)
  obtain ⟨hP,hpass⟩:=mem_filter.mp hy;have hh:=pd hP
  have old:internalOn B S:=⟨fun _ h=>(mem_inter.mp (hs.2.1 h)).1,
    fun x hx z hz ne=>(mem_inter.mp (hs.2.2 x hx z hz ne)).1⟩
  exact ⟨y,hh.1,by omega,by omega,by omega,
    append_clique old (by simpa using hpass 0 (mem_insert_self _ _)) (fun x hx=>hpass x (mem_insert_of_mem hx))⟩

/-- The favorable-band exclusion also works when the original odd class
has only one member. Thus one actual construction covers HB(b), (c), (d). -/
theorem homogeneous_short_rows (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B →
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→(oddOffsets S).card≤3→sameOdd S→False := by
  obtain ⟨U,hU⟩:=inventory_uniform β hb
  obtain ⟨V,hV⟩:=uniform_favorable_band hD hb
  refine ⟨max U V,?_⟩
  intro n hn B hf hd hg S hs hno hsame
  obtain ⟨c,hc,co,hcS⟩:=hsame
  obtain ⟨hcap,hN⟩:=hU n (by omega) B hd hg
  obtain ⟨y,hyl,hyu,yo,hr,hnew⟩:=homogeneous_lower_extension hd hcap hN hs hno hc co hcS
  have hH {x:ℕ} (hx:x∈S):x≤n/4:=(mem_Icc.mp (mem_inter.mp (hs.2.1 hx)).2).2
  have hnot:y∉S:=by intro hh;have :=hH hh;omega
  have hsn:∀x∈insert y S,x≤n:=by
    intro x hx;rcases mem_insert.mp hx with h|h
    · omega
    · have :=hH h;omega
  apply hV n (by omega) B hf hd hg (insert y S) hnew (by simp [hnot,hs.1]) hsn y hyu
  · intro x hx he hne;rcases mem_insert.mp hx with hx|hx
    · omega
    rcases mem_insert.mp hx with hx|hx
    · omega
    · have :=hcS x hx (by omega);exact ⟨by omega,hH hx⟩

private theorem single_odd_mono {S:Finset ℕ} (h:(oddOffsets S).card=1) : sameOdd S:=by
  obtain ⟨x,hx⟩:=card_eq_one.mp h
  have hx':x∈oddOffsets S:=hx ▸ mem_singleton_self x
  have ho: x%2=1:=(mem_filter.mp hx').2
  refine ⟨x%4,by omega,by omega,?_⟩
  intro y hy hyo;have hmem:y∈oddOffsets S:=mem_filter.mpr ⟨hy,hyo⟩
  rw [hx,mem_singleton] at hmem
  congr 1

theorem short_rows_of_dispatch (hD:Dousse7) {i:ℕ} (hi:i=2 ∨ i=3 ∨ i=11) : RowExclusion i := by
  intro β hb
  obtain ⟨U,hU⟩:=homogeneous_short_rows hD hb
  refine ⟨U,?_⟩;intro n hn B _ hf hd hg S hs hrow
  have he:((oddOffsets S).card=1) ∨ ((oddOffsets S).card≤3 ∧ sameOdd S):=by
    unfold rowNumber at hrow;dsimp only at hrow
    split_ifs at hrow <;> first | omega | right; constructor <;> first | assumption | omega
  rcases he with h|⟨ho,hm⟩
  · exact hU n hn B hf hd hg S hs (by omega) (single_odd_mono h)
  · exact hU n hn B hf hd hg S hs ho hm

def outstandingRows:Finset ℕ:=pendingRows \ {2,3,11}

theorem normalized_of_outstanding_rows (hD:Dousse7) (rows:∀i∈outstandingRows,RowExclusion i) : NormalizedK7Goal := by
  apply normalized_of_pending_rows hD
  intro i hi
  by_cases h:i=2 ∨ i=3 ∨ i=11
  · exact short_rows_of_dispatch hD h
  · exact rows i (mem_sdiff.mpr ⟨hi,by simpa using h⟩)

theorem limit_of_outstanding_rows (hD:Dousse7) (rows:∀i∈outstandingRows,RowExclusion i) : SharpK7Limit :=
  limit_of_normalized hD (normalized_of_outstanding_rows hD rows)

end OP02.SharpK7

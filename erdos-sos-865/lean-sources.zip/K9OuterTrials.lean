import K9OuterPhases
import K8CentralCounting

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK8
namespace OP02.SharpK9

/-- Count the joint search once for the upper seven roles and once for each
of the five reflected lower roles per target. Both hole sets are charged to
the deficit of the original set. -/
theorem outer_accepted {H z : ℕ} {D U T W P : Finset ℕ}
    (sub : D⊆Icc 1 H) (hd : DoublingFree D) (hU : U.card=7) (hW : W.card≤5)
    (bounds : ∀p∈P,∀u∈U,H<2*(p+u) ∧ p+u≤H)
    (safe : ∀p∈P,∀u∈U,u∉T → canonical (p+u)=true)
    (target : ∀p∈P,∀t∈T,(p+t)%4=2 ∧ z≤(p+t)/2 ∧ ∀w∈W,
      H/4<2*((p+t)/2-z+w) ∧ (p+t)/2-z+w≤H/4 ∧ canonical ((p+t)/2-z+w)=true)
    (supply : (7+5*T.card)*(chainCapacity H-D.card)<P.card) :
    ∃p∈P, (∀u∈U,p+u∉D → u∈T ∧ (p+u)/2∈D) ∧
      ∀t∈T,∀w∈W,(p+t)/2-z+w∈D := by
  classical
  let E := complementFaults H D
  let L := topMissing (H/4) D
  let upper := rejected P U E (fun u p=>p+u)
  let row (t : ℕ) := rejected P W L (fun w p=>(p+t)/2-z+w)
  let lower := T.biUnion row
  let κ := chainCapacity H-D.card
  have hE : E.card≤κ := complement_fault_budget sub hd
  have hL : L.card≤κ := by
    have h := band_canonical_holes_le H 1 D sub hd
    simpa only [pow_one] using h
  have uc := rejected_card P U E (fun u p=>p+u) (by
    intro u _ a _ b _ h; change a+u=b+u at h; omega)
  change upper.card≤U.card*E.card at uc
  have upperBound : upper.card≤7*κ := by rw [hU] at uc; omega
  have rowBound (t : ℕ) (ht : t∈T) : (row t).card ≤ 5*κ := by
    apply le_trans (rejected_card P W L _ ?_) (Nat.mul_le_mul hW hL)
    intro w _ a ha b hb eq
    have ax := target a ha t ht
    have bx := target b hb t ht
    change (a+t)/2-z+w=(b+t)/2-z+w at eq
    omega
  have lowerBound : lower.card≤T.card*(5*κ) := by
    calc
      lower.card ≤ ∑t∈T,(row t).card := card_biUnion_le
      _ ≤ ∑_t∈T,5*κ := sum_le_sum rowBound
      _ = _ := by simp
  have lim : (upper∪lower).card ≤ (7+5*T.card)*κ := by
    apply (card_union_le _ _).trans
    have eq : (7+5*T.card)*κ=7*κ+T.card*(5*κ) := by ring
    omega
  obtain ⟨p,hp,keep⟩ := exists_mem_notMem_of_card_lt_card (lim.trans_lt supply)
  have noUpper (u : ℕ) (hu : u∈U) : p+u∉E :=
    fun h=>keep (mem_union_left _ (mem_rejected.mpr ⟨u,hu,hp,h⟩))
  refine ⟨p,hp,?_,?_⟩
  · intro u hu miss
    obtain ⟨lo,hi⟩ := bounds p hp u hu
    have noUnmatched : p+u∉unmatchedTop H D := fun hm=>
      noUpper u hu (mem_union_left _ hm)
    have role : u∈T := by
      by_contra notT
      apply noUpper u hu
      apply mem_union_right
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hi⟩,safe p hp u hu notT⟩,
        lo,fun h=>(mem_union.mp h).elim miss noUnmatched⟩
    refine ⟨role,?_⟩
    by_contra half
    apply noUnmatched
    apply mem_filter.mpr
    refine ⟨mem_Ioc.mpr ⟨by omega,hi⟩,miss,?_⟩
    intro x hx he
    exact half ((show x=(p+u)/2 by omega) ▸ hx)
  · intro t ht w hw
    by_contra miss
    obtain ⟨lo,hi,can⟩ := (target p hp t ht).2.2 w hw
    have hole : (p+t)/2-z+w∈L := mem_filter.mpr
      ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hi⟩,can⟩,lo,miss⟩
    exact keep (mem_union_right _ (mem_biUnion.mpr
      ⟨t,ht,mem_rejected.mpr ⟨w,hw,hp,hole⟩⟩))

theorem outer_seven_of_pass {H R : ℕ} {D F : Finset ℕ}
    (hF : Internal 6 D F) (short : ∀x∈F,64*x+H≤64*(H/4))
    (lo : H<2*R) (hi : 4*R≤3*H) (pass : ∀s∈insert 0 F,R+s∈D) : RootSeven H D := by
  have fresh : R∉F := by intro h; have := short R h; omega
  exact ⟨F,R,hF.2.1,fresh,internal_insert hF (by simpa using pass 0 (mem_insert_self _ _))
    fresh (fun s hs=>pass s (mem_insert_of_mem hs)),lo,hi,short⟩

/-- A six with one odd and five even vertices has a common fully canonical
phase in the final top band. -/
theorem outer_finish_reflected {H v : ℕ} {D F : Finset ℕ}
    (sub : D⊆Icc 1 H) (hd : DoublingFree D)
    (budget : 6144*(chainCapacity H-D.card+1)<H)
    (seed : Internal 6 D (insert v F)) (odd : v%2=1) (ev : ∀w∈F,w%2=0)
    (short : ∀w∈insert v F,64*w+H≤64*(H/4)) : RootSeven H D := by
  classical
  let O := insert 0 (insert v F)
  let r := (12-v%8)%8
  let P := progression (H/2) (3*H/4) 8 r
  let E := topMissing H D
  have lohi (p : ℕ) (hp : p∈P) : H/2<p ∧ p≤3*H/4 ∧ p%8=r :=
    ⟨(mem_Ioc.mp (mem_filter.mp hp).1).1,(mem_Ioc.mp (mem_filter.mp hp).1).2,(mem_filter.mp hp).2⟩
  have cap := chain_capacity_with_top_loss H D sub hd
  have cost : E.card≤chainCapacity H-D.card := by dsimp only [E]; omega
  have size : O.card≤7 := (card_insert_le _ _).trans (by rw [seed.2.1])
  have count := progression_lower (H/2) (3*H/4) 8 r (by decide) (Nat.mod_lt _ (by decide))
  change (3*H/4-H/2)/8≤P.card at count
  have room : O.card*E.card<P.card := by
    have hh := Nat.mul_le_mul size cost; omega
  obtain ⟨p,hp,pass⟩ := plain_selection (P:=P) (F:=O) (D:=D) (E:=E) (by
    intro p hp s hs absent
    obtain ⟨lo,hi,pr⟩ := lohi p hp
    change p%8=(12-v%8)%8 at pr
    have ub : s≤H/4 := by
      rcases mem_insert.mp hs with h|h
      · omega
      · have := short s h; omega
    have can : canonical (p+s)=true := by
      rcases mem_insert.mp hs with h|h
      · exact canonical_odd _ (by omega)
      · rcases mem_insert.mp h with h|h
        · exact canonical_four_residue _ (by omega)
        · have := ev s h; exact canonical_odd _ (by omega)
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,can⟩,
      by omega,absent⟩) room
  have bd := lohi p hp
  exact outer_seven_of_pass seed short (by omega) (by omega) pass

end OP02.SharpK9

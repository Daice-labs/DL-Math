import AllKInduction
import AllKLocal
import AllKGeometrySupply

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK8
namespace OP02.AllOrders

private theorem safe_canonical {x : ℕ} (h : x%2=1 ∨ x%8=4 ∨ x%32=16) : canonical x=true := by
  rcases h with h|h|h
  · exact canonical_odd x h
  · exact canonical_four_residue x h
  · have eq : 4*(x/4)=x := by omega
    have h' : (x/4)%8=4 := by omega
    conv_lhs => rw [←eq,canonical_four]
    exact canonical_four_residue _ h'

/-- Apply the two actual projected cliques to the same original word.  One
surviving upper candidate passes all target tests before the completion is chosen. -/
theorem geometric_step (k : ℕ) (hk : 8≤k) : GeometricStep k := by
  classical
  refine ⟨10000*lossDen k,?_⟩
  intro T large A sub df budget F f W z seed core div4
  let J := T/4
  let U := insert 0 F
  let V := insert 0 (W.erase z)
  have nz (x) (hx : x∈A) : x≠0 := by have := (mem_Icc.mp (sub hx)).1; omega
  have nF : 0∉F := fun h=>nz 0 (seed.clique.1 h) rfl
  have nW : 0∉W := fun h=>nz 0 (core.clique.1 h) rfl
  have nV : 0∉W.erase z := fun h=>nW (mem_of_mem_erase h)
  have cU : U.card=k := by rw [show U=insert 0 F from rfl,card_insert_of_notMem nF,seed.clique.2.1]; omega
  have cV : V.card=k-2 := by
    rw [show V=insert 0 (W.erase z) from rfl,card_insert_of_notMem nV,card_erase_of_mem core.top,core.clique.2.1]; omega
  have su : ∃c, (c=1 ∨ c=3) ∧ (residueCell U 4 c).card≤3 := by
    obtain ⟨c,co,cs⟩ := seed.sparse
    refine ⟨c,co,le_trans (card_le_card ?_) cs⟩
    intro x hx
    obtain ⟨hx,hc⟩ := mem_filter.mp hx
    rcases mem_insert.mp hx with rfl|hf
    · change 0%4=c at hc; omega
    · exact mem_filter.mpr ⟨hf,hc⟩
  obtain ⟨a,d,r,ha,ds,rd,cc,t32,exclude,_,phase⟩ := window_residues (b:=f) cU su
  let B := residueCell U 4 a
  have bsub : B⊆U := filter_subset _ _
  have ct : B.card≤k := cU ▸ card_le_card bsub
  obtain ⟨room,room2⟩ := window_supply hk ct ds t32 large budget
  let X := progression (J+2*z+4) (J+2*z+J/widthDen k) d r
  have count := progression_lower (J+2*z+4) (J+2*z+J/widthDen k) d r (Or.inr ds) rd
  have windowSize : (J+2*z+J/widthDen k)-(J+2*z+4)=J/widthDen k-4 := by omega
  rw [windowSize] at count
  have supply : (U.card+V.card*B.card)*(chainCapacity T-A.card)<X.card := by
    rw [cU,cV]; exact room.trans_le count
  have pos (p : ℕ) (hp : p∈X) : J+2*z+4<p ∧ p≤J+2*z+J/widthDen k ∧ p%d=r :=
    ⟨(mem_Ioc.mp (mem_filter.mp hp).1).1,(mem_Ioc.mp (mem_filter.mp hp).1).2,(mem_filter.mp hp).2⟩
  have pivot (p : ℕ) (hp : p∈X) : T<2*p ∧ 256*p≤gamma256 k*T :=
    pivot_bounds hk core.above core.height (pos p hp).1 (pos p hp).2.1
  have uh (u : ℕ) (hu : u∈U) : 256*u≤gamma256 (k-1)*J := by
    rcases mem_insert.mp hu with rfl|hf
    · simp
    · exact vertex_height seed hf
  have th (t : ℕ) (ht : t∈B) : 256*t≤target256 k*J := by
    by_cases h : k<12
    · rw [target256,if_pos h]
      rcases mem_insert.mp (bsub ht) with rfl|hf
      · simp
      · have tc : t%4=a := (mem_filter.mp ht).2
        exact seed.small t hf (fun e=>exclude h (e ▸ tc))
    · rw [target256,if_neg h]; exact uh t (bsub ht)
  have vs (w : ℕ) (hw : w∈V) : 256*w≤alpha256 (k-2)*J ∧ w%2=0 := by
    rcases mem_insert.mp hw with rfl|he
    · simp
    · obtain ⟨ne,h⟩ := mem_erase.mp he
      have dv := div4 _ h
      exact ⟨core.small _ h ne,by omega⟩
  have ze : z%2=0 := by have := div4 _ core.top; omega
  have tgt (p : ℕ) (hp : p∈X) (t : ℕ) (ht : t∈B) (w : ℕ) (hw : w∈V) :
      (p+t)%4=2 ∧ z≤(p+t)/2 ∧ J/2+2<(p+t)/2-z+w ∧ (p+t)/2-z+w≤J ∧
      ((p+t)/2-z+w)%2=1 ∧ 256*((p+t)/2-z)≤alpha256 k*T := by
    have h := pos p hp
    have pt := (phase p h.2.2).2.1 t ht
    have g := physical_window_geometry (J:=J) hk rfl core.above core.height h.1 h.2.1
      (show (p+t)%2=0 by omega) (th t ht) (vs w hw).1
    have hm := g.2.2.1
    have we := (vs w hw).2
    exact ⟨pt,hm,g.2.2.2.1,g.2.2.2.2.1,by omega,g.2.2.2.2.2⟩
  obtain ⟨p,hp,upper,lower⟩ := shared_loss (U:=U) (targets:=B) (W:=V) (P:=X) (z:=z) sub df (by
    intro p hp u hu
    have h := pivot p hp
    exact ⟨by omega,(inherited_bounds hk rfl (Or.inl (uh u hu)) h.2).2⟩) (by
    intro p hp u hu nt
    exact safe_canonical ((phase p (pos p hp).2.2).2.2 u hu nt)) (by
    intro p hp t ht
    have h := tgt p hp t ht 0 (mem_insert_self _ _)
    refine ⟨h.1,h.2.1,?_⟩
    intro w hw
    have g := tgt p hp t ht w hw
    exact ⟨g.2.2.1,g.2.2.2.1,g.2.2.2.2.1⟩) supply
  have h := pivot p hp
  by_cases direct : ∀u∈U,p+u∈A
  · refine ⟨insert p F,p,direct_shape (by omega) seed.clique seed.sparse ha cc
      (phase p (pos p hp).2.2).1 h.1 h.2 ?_ direct⟩
    intro x hx
    exact (inherited_bounds hk rfl (Or.inl (vertex_height seed hx)) h.2).1
  · push Not at direct
    obtain ⟨u,hu,miss⟩ := direct
    obtain ⟨ht,half⟩ := upper u hu miss
    have g := tgt p hp u ht 0 (mem_insert_self _ _)
    simp only [Nat.add_zero] at g
    apply replacement_shape (k:=k) (by omega) sub df core.clique (fun w hw=>by have := div4 w hw; omega)
      half g.2.1 g.2.2.2.2.1 (lower u ht) _ g.2.2.2.2.2 room2
    intro x hx
    exact (inherited_bounds hk rfl (Or.inr (vertex_height core hx)) h.2).1

end OP02.AllOrders

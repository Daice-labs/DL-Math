import K7PhysicalReductions
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

def quarterMissing (H:ℕ) (D:Finset ℕ) : Finset ℕ:=
  (canonicalSlots H).filter (fun x=>H<8*x ∧ 4*x≤H ∧ x∉D)
def oddTopMissing (H:ℕ) (D:Finset ℕ) : Finset ℕ:=
  (topMissing H D).filter (fun x=>x%2=1)

/-- The proof uses the vacant canonical slot y if its double is absent,
and top slot 4y when its double is occupied. The two cases are physically
disjoint, and the second tag is even. Thus upper odd singleton losses are
additional to the quarter-band loss within the original budget. -/
theorem quarter_top_joint {H:ℕ} {D:Finset ℕ} (hs:D⊆Icc 1 H) (hd:DoublingFree D) :
    D.card+(quarterMissing H D).card+(oddTopMissing H D).card≤chainCapacity H := by
  classical
  let I:=D.image chainCompress
  let A:=quarterMissing H D
  let O:=oddTopMissing H D
  let tag (y:ℕ):=if 2*y∈D then 4*y else y
  let J:=A.image tag
  have ida {a:ℕ} (ha:a∈A):0<a ∧ H<8*a ∧ 4*a≤H ∧ canonical a=true ∧ a∉D:=by
    obtain ⟨hi,hp,hu,hn⟩:=mem_filter.mp ha
    exact ⟨(mem_Icc.mp (mem_filter.mp hi).1).1,hp,hu,(mem_filter.mp hi).2,hn⟩
  have od {a:ℕ} (ha:a∈O):H<2*a ∧ a%2=1 ∧ a∉D ∧ a∈canonicalSlots H:=by
    obtain ⟨ht,ho⟩:=mem_filter.mp ha;obtain ⟨hi,hh,hn⟩:=mem_filter.mp ht
    exact ⟨hh,ho,hn,hi⟩
  have pre {y:ℕ} (hy:y∈I): y∈D ∨ 2*y∈D:=by
    obtain ⟨x,hx,rfl⟩:=mem_image.mp hy
    unfold chainCompress;split_ifs with h
    · exact Or.inl hx
    · have hf:canonical x=false:=by cases h':canonical x <;> simp_all
      apply Or.inr;rw [(canonical_false_parent x (mem_Icc.mp (hs hx)).1 hf).1];exact hx
  have ji:Set.InjOn tag A:=by
    intro x hx y hy h
    have :=ida hx;have :=ida hy
    dsimp [tag] at h;split_ifs at h <;> omega
  have dj:Disjoint I J:=by
    apply disjoint_left.mpr;intro x hx hj
    obtain ⟨y,hy,rfl⟩:=mem_image.mp hj;obtain ⟨ypos,yr,yr',hyc,ha⟩:=ida hy
    have hp:=pre hx
    dsimp [tag] at hp;split_ifs at hp with h
    · rcases hp with h4|h8
      · exact hd (2*y) h (by convert h4 using 1 <;> omega)
      · have :=mem_Icc.mp (hs h8);omega
    · exact hp.elim ha h
  have doi:Disjoint I O:=by
    apply disjoint_left.mpr;intro y hy ho;have hh:=od ho
    rcases pre hy with h|h;exact hh.2.2.1 h
    have :=mem_Icc.mp (hs h);omega
  have djo:Disjoint J O:=by
    apply disjoint_left.mpr;intro y hy ho;obtain ⟨x,hx,rfl⟩:=mem_image.mp hy
    have a:=ida hx;have b:=od ho
    dsimp only [tag] at b;split_ifs at b <;> omega
  have si:I⊆canonicalSlots H:=by intro x hx;obtain ⟨a,ha,rfl⟩:=mem_image.mp hx;exact chain_compression_mem H D hs ha
  have sj:J⊆canonicalSlots H:=by
    intro y hy;obtain ⟨x,hx,rfl⟩:=mem_image.mp hy;have h:=ida hx;dsimp [tag];split_ifs
    · exact mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,h.2.2.1⟩,by rw [canonical_four];exact h.2.2.2.1⟩
    · exact (mem_filter.mp hx).1
  have so:O⊆canonicalSlots H:=fun x hx=>(od hx).2.2.2
  have count:=card_le_card (union_subset (union_subset si sj) so)
  have dij:Disjoint (I∪J) O:=disjoint_union_left.mpr ⟨doi,djo⟩
  rw [card_union_of_disjoint dij,card_union_of_disjoint dj] at count
  have nI:I.card=D.card:=card_image_of_injOn (chain_compression_injective H D hs hd)
  have nJ:J.card=A.card:=card_image_of_injOn ji
  rw [nI,nJ] at count
  change D.card+A.card+O.card≤(canonicalSlots H).card
  exact count

theorem actual_quarter_top_joint (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    (quarterMissing (n/4) (quarterD n B)).card+(oddTopMissing (n/4) (quarterD n B)).card≤
      chainDeficit n B:=by
  have hh:=quarter_top_joint (H:=n/4) (D:=quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  unfold chainDeficit;omega
end OP02.SharpK7

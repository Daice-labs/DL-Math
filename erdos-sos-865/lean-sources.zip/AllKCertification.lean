import AllOrdersEndpoint
import AllKSharpTests
import AllKSourceComparison

open OP02.AllOrders
namespace OP02.AllOrdersCertification

example : PublicComparison.publicConjecture := erdos_sos

#print Erdos865.f
#print OP02.GeneralGoal
#print OP02.AllOrders.Shaped
#print OP02.AllOrders.ShapeAt
#check @OP02.AllOrders.deficient_iff
#print axioms OP02.AllOrders.deficient_iff
#check @OP02.AllOrders.deficient_card
#print axioms OP02.AllOrders.deficient_card
#check @OP02.AllOrders.shared_loss
#print axioms OP02.AllOrders.shared_loss
#check @OP02.AllOrders.eight_period32_comparison
#print axioms OP02.AllOrders.eight_period32_comparison
#check @OP02.AllOrders.twelve_top_window
#print axioms OP02.AllOrders.twelve_top_window
#check @OP02.AllOrders.twelve_top_reflection
#print axioms OP02.AllOrders.twelve_top_reflection
#check @OP02.AllOrders.direct_shape
#print axioms OP02.AllOrders.direct_shape
#check @OP02.AllOrders.replacement_shape
#print axioms OP02.AllOrders.replacement_shape
#check @OP02.AllOrders.shaped_six
#print axioms OP02.AllOrders.shaped_six
#check @OP02.AllOrders.shaped_seven
#print axioms OP02.AllOrders.shaped_seven
#check @OP02.AllOrders.projected_inputs
#print axioms OP02.AllOrders.projected_inputs
#check @OP02.AllOrders.window_residues
#print axioms OP02.AllOrders.window_residues
#check @OP02.AllOrders.physical_window_geometry
#print axioms OP02.AllOrders.physical_window_geometry
#check @OP02.AllOrders.window_supply
#print axioms OP02.AllOrders.window_supply
#check @OP02.AllOrders.geometric_step
#print axioms OP02.AllOrders.geometric_step
#check @OP02.AllOrders.shaped_step
#print axioms OP02.AllOrders.shaped_step
#check @OP02.AllOrders.shaped_all
#print axioms OP02.AllOrders.shaped_all
#check @OP02.AllOrders.midpoints_all
#print axioms OP02.AllOrders.midpoints_all
#check @OP02.AllOrders.band_lower
#print axioms OP02.AllOrders.band_lower
#check @OP02.AllOrders.sharp_limit
#print axioms OP02.AllOrders.sharp_limit
#check @OP02.AllOrders.erdos_sos
#print axioms OP02.AllOrders.erdos_sos
#check @OP02.AllOrders.PublicComparison.sameThreshold
#print axioms OP02.AllOrders.PublicComparison.sameThreshold
#check @OP02.AllOrders.PublicComparison.sameConjecture
#print axioms OP02.AllOrders.PublicComparison.sameConjecture
end OP02.AllOrdersCertification

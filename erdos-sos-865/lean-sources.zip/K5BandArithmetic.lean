import K5Arithmetic
namespace OP02.SharpK5
set_option maxHeartbeats 1000000

/-- Both endpoint clips are retained. The small budget excludes every branch
of min/max except the one that forces the designated vertex near n. -/
theorem second_band_arithmetic (n v hi k q:ℕ) (hn:1024≤n) (hv:v≤n)
    (hq:128*q≤n) (hk:3*k+hi≤6*q)
    (hc:(min (n+v/2+n/4) (2*(n-4*(n/16))-(4*hi+4)-1)-
      max (n+v/2) (n+4*hi+4))/4≤3*k) : n-v≤24*k+8*hi+16 := by
  omega

/-- Scalar endpoint check for the common-neighbor pivots. -/
theorem gap_pivot_arithmetic (n q hi J h r s p:ℕ)
    (hn:1024≤n) (hq:128*q≤n) (hhi:hi≤q) (hJh:J+h≤q)
    (hrs:r+s≤n/16)
    (hp:p≤2*n+2*(4*hi+4)+4*(3*J+2*h+1)) :
    p≤2*n+20*q+16 ∧
    p+4*r<4*(n-4*(n/16))-2*(4*hi+4) ∧
    p+4*s<4*(n-4*(n/16))-2*(4*hi+4) := by omega

theorem gap_pivot_odd_upper (n q p y:ℕ) (hn:1024≤n) (hq:128*q≤n)
    (hp:p≤2*n+20*q+16) (hy:4*y≤7*n) : p+y≤4*n := by omega

#print axioms gap_pivot_arithmetic
#print axioms gap_pivot_odd_upper
#print axioms second_band_arithmetic
end OP02.SharpK5

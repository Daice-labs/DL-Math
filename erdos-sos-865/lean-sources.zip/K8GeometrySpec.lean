import K8Spec

open Finset OP02.FewHole OP02.SmallExcess
namespace OP02.SharpK8

def ShortFive (H : ℕ) (D F : Finset ℕ) : Prop :=
  Internal 5 (D ∩ Icc 1 (H/4)) F ∧ ∀ x ∈ F, 128*x + 5*H ≤ 128*(H/4)

/-- Central constructions may have an early pair label above H/4. -/
def RootSix (H : ℕ) (D : Finset ℕ) : Prop :=
  ∃ (F : Finset ℕ) (R : ℕ), F.card = 5 ∧ R ∉ F ∧ Internal 6 D (insert R F) ∧
    H < 2*R ∧ 4*R ≤ 3*H ∧ ∀ x ∈ F, 128*x + 5*H ≤ 128*(H/4)

def NarrowSix (n : ℕ) (B : Finset ℕ) : Prop :=
  ∃ (V : Finset ℕ) (z : ℕ), V.card = 5 ∧ z ∉ V ∧ Internal 6 B (insert z V) ∧
    (∀ x ∈ insert z V, x % 2 = 0) ∧ n < 2*z ∧ 4*z ≤ 3*n ∧
    ∀ x ∈ V, 32*x + 5*(n/4) ≤ 8*n

def RootSupply : Prop :=
  ∀ β : ℝ, 0 < β → ∃ M : ℕ, ∀ n : ℕ, M ≤ n → ∀ B : Finset ℕ,
    B ⊆ Icc 1 (4*n) → DoublingFree B → SignedGap β n B →
    RootSix (n/4) (quarterD n B)

end OP02.SharpK8

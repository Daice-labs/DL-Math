import K8CentralBranches
import K8UpperSixFull

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8

/-- Under the original signed hypothesis a supplied short five suffices.
Each central branch constructs its own complete six and its upper root.
In their joint complement the supplied five keeps its five upper contacts. -/
theorem signed_upper_from_short {β : ℝ} (hb : 0 < β) :
    ∃ U : ℕ, ∀ n : ℕ, U≤n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
      (∃ F, ShortFive (n/4) (quarterD n B) F) → RootSix (n/4) (quarterD n B) := by
  classical
  obtain ⟨M,hM⟩ := strict_capacity hb
  obtain ⟨T,hT⟩ := uniform_central_triangle_supply hb
  refine ⟨max 4000000000 (max M T),?_⟩
  intro n hn B hd hg hf
  let H := n/4
  let D := quarterD n B
  have large : 1000000000≤H := by dsimp [H]; omega
  have sub : D⊆Icc 1 H := filter_subset _ _
  have free : DoublingFree D := quarter_doubling_free n B hd
  have xcap := hM n (by omega) B hd hg
  have budget : 1536*(chainCapacity H-D.card)<H := by
    unfold chainDeficit at xcap
    dsimp [H,D]
    omega
  have supply : CentralTriangleSupply H D := hT n (by omega) B hd hg
  by_cases c4 : CentralFour H D
  · exact central_four_root_six large sub free budget supply c4
  by_cases co : CentralOdd H D
  · exact central_odd_root_six large sub free budget supply co
  obtain ⟨F,hF⟩ := hf
  exact complement_of_upper_central_gaps (by omega) sub free budget c4 co hF

end OP02.SharpK8

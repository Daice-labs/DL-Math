import K7HalfRoles
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7
set_option maxHeartbeats 2400000

def bridgeEta (n:ℕ) (B:Finset ℕ):ℕ:=
  let O:=(oddTopMissing (n/4) (quarterD n B)).card
  100*O+16*(chainDeficit n B-O)+64*totalBudget n B+512

private theorem root_interval_surplus {lo hi m k O E K q ha sl:ℕ}
    (ke:k≤ lo+m) (own:O+E≤ K) (classes:ha+sl≤ q)
    (hw:100*O+16*(K-O)+64*q+512≤ hi-lo) :
    7*O+E+3*ha+5*sl < (((hi+m-k)/2-(lo+m-k)/2)/32)*5:=by
  have add:K-O+O=K:=Nat.sub_add_cancel (by omega)
  omega

private theorem slot_forces_odd {n v:ℕ} {B:Finset ℕ} (hp:0< v) (odd:v%2=1)
    (hu:2*v≤ n) (hs:v∉emptyPairs n B) (h2:2*v∉B) : v∈B:=by
  by_contra h
  exact hs (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨hp,by omega⟩,odd⟩,hu,h,h2⟩)

/-- Count all tests for one half. Odd top owners reject at most seven
root tests, even top owners at most one. Three high-singleton images
and five paired-slot images are paid from the same original deficit. -/
theorem select_physical_half {n s h j k a c b z x₁ x₂ x₃:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B) (hn:64≤ n/4) (hs:s≤ n/4) (hk:2*k≤ s) (ko:k%2=1)
    (h1:4*h≤ s) (h2:4*j≤ s) (xmax:∀x∈({x₁,x₂,x₃}:Finset ℕ),x≤ s ∧ x%2=1)
    (ac:a< c) (cb:c< b) (bz:b< z) (zs:4*z≤ n/4)
    (hw:bridgeEta n B≤ halfHi (n/4) s k b z-halfLo (n/4) k z) :
    ∃r y:ℕ, n/4/2< y ∧ y≤ n/4 ∧ y%2=1 ∧ n/4<4*r ∧ 4*r+s≤ n ∧
    y+4*z=2*r+k ∧ (y+4*z)∉emptyPairs n B ∧ 2*(y+4*z)≤ n ∧
    (∀t∈({0,a,c,b}:Finset ℕ),y+4*t∈B) ∧
    (∀t∈({0,h,j}:Finset ℕ),r+t∈quarterD n B) ∧
    (∀x∈({x₁,x₂,x₃}:Finset ℕ),4*r+x∈B) :=by
  classical
  let H:=n/4
  let D:=quarterD n B
  let d:=minorShift h j
  let T:=topMissing H D
  let O:=oddTopMissing H D
  let E:=T.filter (fun v=>v%2=0)
  let A:=missingTopOdd n B
  let S:=emptyPairs n B
  let l:=halfLo H k z
  let u:=halfHi H s k b z
  let l':=(l+4*z-k)/2
  let u':=(u+4*z-k)/2
  let P:=(Ioc l' u').filter (fun r=>r%32∈halfResidues d)
  let y (r:ℕ):=2*r+k-4*z
  have l1:H/2≤ l:=le_max_left _ _
  have l2:H+k-4*z≤ l:=le_max_right _ _
  have u1:u≤ H-4*b:=min_le_left _ _
  have u2:u≤(4*H+2*k-s)/2-4*z:=min_le_right _ _
  change s≤ H at hs;change 4*z≤ H at zs
  have z4:4*b≤ H:=by omega
  have sn:s+(4*H+2*k-s)=4*H+2*k:=by omega
  have unn:4*z≤(4*H+2*k-s)/2:=by omega
  have bounds {r} (hr:r∈P): H/2< y r ∧ y r+4*b≤ H ∧ H<2*r ∧ 4*r+s≤4*H ∧
      y r+4*z=2*r+k ∧ y r%2=1 ∧ y r+4*z≤2*H:=by
    have rh:=mem_Ioc.mp (mem_filter.mp hr).1
    dsimp only [l',u'] at rh
    dsimp only [y]
    omega
  have tt:=chain_capacity_with_top_loss H D (filter_subset _ _) (quarter_doubling_free n B hd)
  have ot:O.card+E.card≤ chainDeficit n B:=by
    have ep:E=T.filter (fun v=>¬v%2=1):=by
      ext v
      change (v ∈ T.filter (fun w => w%2=0)) ↔ (v ∈ T.filter (fun w => ¬w%2=1))
      simp only [mem_filter]
      have hh : (v%2=0 ↔ ¬v%2=1) := by omega
      tauto
    rw [ep];have part:=card_filter_add_card_filter_not (s:=T) (p:=fun v=>v%2=1)
    change (T.filter _).card+_≤_;rw [part]
    unfold chainDeficit;change _≤ chainCapacity H-D.card;change D.card+T.card≤_ at tt;omega
  have account:A.card+S.card≤ totalBudget n B:=by
    have h:=deficit_split n B hd;dsimp [A,S];unfold totalBudget;omega
  have kx:k≤ l+4*z:=by omega
  have w0:100*O.card+16*(chainDeficit n B-O.card)+64*totalBudget n B+512≤ u-l:=hw
  have pos:=root_interval_surplus (m:=4*z) kx ot account w0
  have supp:=count_halves l' u' d
  change _≤ P.card at supp
  let L:List LossTest:=[(fun r=>r,O),(fun r=>r+h,O),(fun r=>r+j,O),(fun r=>r+d,E),
    (fun r=>y r,O),(fun r=>y r+4*a,O),(fun r=>y r+4*c,O),(fun r=>y r+4*b,O),
    (fun r=>4*r+x₁,A),(fun r=>4*r+x₂,A),(fun r=>4*r+x₃,A),
    (fun r=>2*r+k,S),(fun r=>y r,S),(fun r=>y r+4*a,S),(fun r=>y r+4*c,S),(fun r=>y r+4*b,S)]
  have hinj:∀ f ∈ L, ∀ r ∈ P, ∀ t ∈ P, f.1 r = f.1 t → r = t := by
    intro f hf r hr t ht he
    have a1: y r+4*z=2*r+k:=(bounds hr).2.2.2.2.1
    have a2: y t+4*z=2*t+k:=(bounds ht).2.2.2.2.1
    simp only [L,List.mem_cons,List.not_mem_nil,or_false] at hf
    rcases hf with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;>
      dsimp only at he <;> omega
  have size:(L.map fun f=>f.2.card).sum< P.card:=by
    simp only [L,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil];change _<((u'-l')/32)*5 at pos;exact lt_of_le_of_lt (by omega) (lt_of_lt_of_le pos supp)
  obtain ⟨r,hr,good⟩:=avoid_physical_tests P L hinj size
  obtain ⟨yl,yu,rl,ru,eq,yo,eu⟩:=bounds hr
  have rd:=(half_residue_data h j).2 r (mem_filter.mp hr).2
  have pass0:r∉O:=good (fun r=>r,O) (by simp [L])
  have pass1:r+h∉O:=good (fun r=>r+h,O) (by simp [L])
  have pass2:r+j∉O:=good (fun r=>r+j,O) (by simp [L])
  have pass3:r+d∉E:=good (fun r=>r+d,E) (by simp [L])
  have pass4:y r∉O:=good (fun r=>y r,O) (by simp [L])
  have pass5:y r+4*a∉O:=good (fun r=>y r+4*a,O) (by simp [L])
  have pass6:y r+4*c∉O:=good (fun r=>y r+4*c,O) (by simp [L])
  have pass7:y r+4*b∉O:=good (fun r=>y r+4*b,O) (by simp [L])
  have pass8:4*r+x₁∉A:=good (fun r=>4*r+x₁,A) (by simp [L])
  have pass9:4*r+x₂∉A:=good (fun r=>4*r+x₂,A) (by simp [L])
  have pass10:4*r+x₃∉A:=good (fun r=>4*r+x₃,A) (by simp [L])
  have pass11:2*r+k∉S:=good (fun r=>2*r+k,S) (by simp [L])
  have pass12:y r∉S:=good (fun r=>y r,S) (by simp [L])
  have pass13:y r+4*a∉S:=good (fun r=>y r+4*a,S) (by simp [L])
  have pass14:y r+4*c∉S:=good (fun r=>y r+4*c,S) (by simp [L])
  have pass15:y r+4*b∉S:=good (fun r=>y r+4*b,S) (by simp [L])
  have oddroot {v:ℕ} (vlow:H<2*v) (vup:v≤ H) (vo:v%2=1) (good':v∉O):v∈D:=by
    by_contra bad
    apply good' (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,vup⟩,canonical_odd _ vo⟩,vlow,bad⟩,vo⟩)
  have oddTest (t:ℕ) (ht:t∈({0,a,c,b}:Finset ℕ)):y r+4*t∈B:=by
    have tb:t≤ b:=by simp only [mem_insert,mem_singleton] at ht;omega
    have vo:(y r+4*t)%2=1:=by omega
    have posO:y r+4*t∉O ∧ y r+4*t∉S:=by
      simp only [mem_insert,mem_singleton] at ht
      rcases ht with e|e|e|e <;> subst t
      · simpa using And.intro pass4 pass12
      · exact ⟨pass5,pass13⟩
      · exact ⟨pass6,pass14⟩
      · exact ⟨pass7,pass15⟩
    have vv:=oddroot (v:=y r+4*t) (by omega) (by omega) vo posO.1
    have dv:2*(y r+4*t)∉B:=fun hm=>hd _ hm (by simpa only [←Nat.mul_assoc] using (mem_filter.mp vv).2)
    apply slot_forces_odd (by omega) vo _ posO.2 dv
    dsimp [H] at yu;omega
  have rt (v:ℕ) (hv:v∈({0,h,j}:Finset ℕ)):r+v∈D:=by
    have vs:4*v≤ s:=by simp only [mem_insert,mem_singleton] at hv;omega
    by_cases odd:(r+v)%2=1
    · apply oddroot (by omega) (by omega) odd
      simp only [mem_insert,mem_singleton] at hv;rcases hv with e|e|e <;> subst v
      · simpa using pass0
      · exact pass1
      · exact pass2
    · have ed:=rd.2 v hv (by omega)
      change v=d at ed
      have pe:r+d∉E:=pass3
      by_contra bad
      apply pe
      rw [←ed]
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,rd.1 v hv⟩,by omega,bad⟩,by omega⟩
  have top (x:ℕ) (hx:x∈({x₁,x₂,x₃}:Finset ℕ)):4*r+x∈B:=by
    have xx:=xmax x hx
    have ok:4*r+x∉A:=by
      simp only [mem_insert,mem_singleton] at hx;rcases hx with e|e|e <;> subst x <;> assumption
    by_contra bad;apply ok
    change s≤ n/4 at hs;change n/4<2*r at rl;change 4*r+s≤4*(n/4) at ru
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega,bad⟩
  have edge:2*r+k∉S:=pass11
  refine ⟨r,y r,yl,by change _≤ H;omega,yo,by change H<_;omega,?_,eq,eq ▸ edge,?_,oddTest,rt,top⟩
  · change 4*r+s≤4*(n/4) at ru;omega
  · change y r+4*z≤2*(n/4) at eu;omega

end OP02.SharpK7

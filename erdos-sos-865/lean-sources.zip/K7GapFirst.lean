import K7StrongBudget
import K6QualifiedPrefix
import K6BootstrapLabels
open Finset OP02.SmallExcess OP02.FewHole OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7

/-- The vertices have a common physical support. An edge label can coincide
with a different edge label. -/
def internalOn (B S:Finset ℕ) : Prop :=
  S⊆B ∧ ∀x∈S,∀y∈S,x≠y→x+y∈B

theorem combine_roots {n:ℕ} {B T V:Finset ℕ}
    (hs:internalOn (quarterD n B) T) (hv:internalOn B V)
    (hsep:∀a∈T,∀v∈V,4*a<v)
    (hc: T.card+V.card=7) (hx:∀a∈T,∀v∈V,v+4*a∈B) : ¬SevenFree B := by
  intro hf;apply hf
  let U:=T.image (fun a:ℕ=>4*a)
  have hd:Disjoint U V:=by
    apply disjoint_left.mpr;intro z hz hz'
    obtain ⟨a,ha,rfl⟩:=mem_image.mp hz
    exact (lt_irrefl _) (hsep a ha _ hz')
  have hsize:U.card=T.card:=card_image_of_injective _ (by intro x y hh;change 4*x=4*y at hh;omega)
  refine ⟨U∪V,?_,by rw [card_union_of_disjoint hd,hsize];exact hc,?_⟩
  · apply union_subset _ hv.1;intro x hx
    obtain ⟨a,ha,rfl⟩:=mem_image.mp hx;exact (mem_filter.mp (hs.1 ha)).2
  · intro x h1 y h2 hne
    rcases mem_union.mp h1 with h1|h1 <;> rcases mem_union.mp h2 with h2|h2
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp h1;obtain ⟨b,hb,rfl⟩:=mem_image.mp h2
      simpa only [Nat.mul_add] using (mem_filter.mp (hs.2 a ha b hb (by omega))).2
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp h1;simpa [Nat.add_comm] using hx a ha y h2
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp h2;exact hx a ha x h1
    · exact hv.2 x h1 y h2 hne

def rootFourBound (β:ℝ) (n:ℕ) : Prop :=
  ∀X:Finset ℕ,X⊆Icc 1 (n/16)→FourFree X→(X.card:ℝ)≤(21/32+β)*(n/16:ℕ)
def rootFiveBound (β:ℝ) (n:ℕ) : Prop :=
  ∀X:Finset ℕ,X⊆Icc 1 (n/4)→FiveFree X→(X.card:ℝ)≤(85/128+β)*(n/4:ℕ)

theorem root_fraction_bound (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    (quarterD n B).card + 2*(n/16) ≤ n/4 + ((quarterD n B).filter (fun x=>x≤n/16)).card :=
  quarter_root_capacity (n/4) (n/16) (quarterD n B) (by omega)
    (filter_subset _ _) (quarter_doubling_free n B hd)

/-- The qualified four roots are selected after all three auxiliary vertices.
The two high translations use opposite odd classes and the upper translation
uses only odd excess. -/
theorem no_upper_triangle {β:ℝ} {n u v p:ℕ} {B:Finset ℕ}
    (hb:0<β) (hf:SevenFree B) (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hbn:(10:ℝ)≤β*n) (h4:rootFourBound β n)
    (hu:u∈B) (hv:v∈B) (huv:u<v) (hou:u%2=1) (hov:v%2=1)
    (hsum:(u+v)%4=0) (he:u+v∈B) (huL:n<2*u) (hvH:v≤n-4*(n/16))
    (hp:2*n<p) (hpH:p+v≤4*n) (hpo:p%2=1) :
    ¬(p∈B ∧ p+u∈B ∧ p+v∈B) := by
  classical
  rintro ⟨hpB,hpu,hpv⟩
  let X:=OP02.SharpK6.qualifiedPrefix n (n/16) u v B
  let Y:=X.filter (fun a=>p+4*a∈B)
  let F:=X\Y
  have hQ:=OP02.SharpK6.qualified_prefix_loss n (n/16) u v B (le_refl _) hou hov
    (by omega) huL (by omega) (by omega) hvH
  have hXs:X⊆Icc 1 (n/16):=OP02.SharpK6.qualified_prefix_subset _ _ _ _ _
  have hF:F.card≤(Ho n B).card:=by
    apply card_le_card_of_injOn (fun a:ℕ=>p+4*a)
    · intro a ha;obtain ⟨hax,hay⟩:=mem_sdiff.mp ha
      have hr:=mem_Icc.mp (hXs hax)
      have hm:p+4*a∉B:=fun h=>hay (mem_filter.mpr ⟨hax,h⟩)
      change p+4*a∈Ho n B
      exact OP02.SharpK6.bootstrap_missing_odd n _ B (by omega) (by omega) (by omega) hm
    · intro x hx y hy heq;change p+4*x=p+4*y at heq;omega
  have hpart:=card_sdiff_add_card_eq_card (filter_subset _ _:Y⊆X)
  change F.card+Y.card=X.card at hpart
  have hsing:=missingTopOdd_le_deficit n B hd
  have hodd:(Ho n B).card≤(excessHoles n B).card:=card_filter_le _ _
  have hcost:(missingTopOdd n B).card+(Ho n B).card≤totalBudget n B:=by unfold totalBudget;omega
  have hprev:=root_fraction_bound n B hd
  have hres:(quarterD n B).card+2*(n/16)≤n/4+Y.card+totalBudget n B:=by
    change _≤X.card+_ at hQ;omega
  have hy4:¬FourFree Y:=by
    intro hy
    have hh:=h4 Y (fun a ha=>hXs (mem_filter.mp ha).1) hy
    have hs':((quarterD n B).card:ℝ)+2*(n/16:ℕ)≤(n/4:ℕ)+(Y.card:ℝ)+totalBudget n B:=by exact_mod_cast hres
    have floor:(512:ℝ)*(n/4:ℕ)≤85*(n:ℝ)+688*(n/16:ℕ)+1024:=by
      exact_mod_cast (show 512*(n/4)≤85*n+688*(n/16)+1024 by omega)
    have hhalf:(2:ℝ)*(n/16:ℕ)≤(n:ℝ):=by exact_mod_cast (show 2*(n/16)≤n by omega)
    nlinarith only [hg,hs',hh,hbn,floor,mul_nonneg hb.le (sub_nonneg.mpr hhalf)]
  obtain ⟨T,hT,hc,hpair⟩:=Classical.not_not.mp hy4
  let V:Finset ℕ:={u,v,p}
  have hy {a:ℕ} (ha:a∈Y):a∈quarterD n B ∧ u+4*a∈B ∧ v+4*a∈B ∧ p+4*a∈B:=by
    obtain ⟨hx,hpa⟩:=mem_filter.mp ha;obtain ⟨hx',h₁,h₂⟩:=mem_filter.mp hx
    exact ⟨(mem_filter.mp hx').1,h₁,h₂,hpa⟩
  have hsep:∀a∈T,∀w∈V,4*a<w:=by
    intro a ha w hw;have hh:=mem_Icc.mp (hXs (mem_filter.mp (hT ha)).1)
    simp only [V,mem_insert,mem_singleton] at hw;rcases hw with rfl|rfl|rfl <;> omega
  have huv':u≠v:=by omega
  have hup:u≠p:=by omega
  have hvp:v≠p:=by omega
  have hcl:internalOn B V:=by
    constructor
    · intro a ha;simp only [V,mem_insert,mem_singleton] at ha;rcases ha with rfl|rfl|rfl <;> assumption
    · intro a ha b hb' hne;simp only [V,mem_insert,mem_singleton] at ha hb'
      rcases ha with rfl|rfl|rfl <;> rcases hb' with rfl|rfl|rfl <;>
        first | exact False.elim (hne rfl) | exact he | exact hpu | exact hpv |
                simpa only [Nat.add_comm] using he | simpa only [Nat.add_comm] using hpu |
                simpa only [Nat.add_comm] using hpv
  apply combine_roots (n:=n) (T:=T) (V:=V) (B:=B) _ hcl hsep _ _ hf
  · exact ⟨fun a ha=>(hy (hT ha)).1,fun a ha b hb' hn=>(hy (hpair a ha b hb' hn)).1⟩
  · simp [V,hc,huv',hup,hvp]
  · intro a ha z hz;have hq:=hy (hT ha)
    simp only [V,mem_insert,mem_singleton] at hz
    rcases hz with rfl|rfl|rfl <;> tauto

end OP02.SharpK7

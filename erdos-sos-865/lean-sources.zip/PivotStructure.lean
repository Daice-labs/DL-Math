import PivotCover
open Finset
open scoped BigOperators
namespace OP02.PivotAudit
open OP02.FewHole OP02.SmallExcess

theorem weighted_residues_bound (U E : Finset ℕ) (α M : ℕ)
    (hM : ∀ j, (U.filter (fun u => (α+u)%8=j)).card ≤ M) :
    (∑ u ∈ U, residueCount E ((α+u)%8)) ≤ M*E.card := by
  have heq : (∑ u ∈ U, residueCount E ((α+u)%8)) =
      ∑ z ∈ E, (U.filter (fun u => (α+u)%8=z%8)).card := by
    simp only [residueCount,card_eq_sum_ones,sum_filter]
    rw [sum_comm]
    apply sum_congr rfl
    intro z hz
    apply sum_congr rfl
    intro u hu
    simp [eq_comm]
  rw [heq]
  calc
    (∑ z ∈ E, (U.filter (fun u => (α+u)%8=z%8)).card) ≤ ∑ _z ∈ E, M :=
      sum_le_sum (fun z hz => hM (z%8))
    _ = M*E.card := by simp [Nat.mul_comm]

theorem multiplicity_le_three (n : ℕ) (B S : Finset ℕ)
    (htri : LowerTriangle n B S) (ha : ∃ a ∈ S, a%2=1) (α j : ℕ) :
    ((insert 0 S).filter (fun u => (α+u)%8=j)).card ≤ 3 := by
  obtain ⟨hSc,hSL,hpair⟩ := htri
  have hz : 0 ∉ S := by
    intro h
    have := (mem_Icc.mp (mem_inter.mp (hSL h)).2).1
    omega
  have hUc : (insert 0 S).card=4 := by simp [hz,hSc]
  obtain ⟨a,ha,hao⟩ := ha
  have hex : ∃ u ∈ insert 0 S, (α+u)%8 ≠ j := by
    by_cases h : α%8=j
    · refine ⟨a,mem_insert_of_mem ha,?_⟩
      omega
    · exact ⟨0,mem_insert_self ..,by simpa using h⟩
  obtain ⟨v,hv,hvj⟩ := hex
  have hs : (insert 0 S).filter (fun u => (α+u)%8=j) ⊆ (insert 0 S).erase v := by
    intro u hu
    obtain ⟨hu,huj⟩ := mem_filter.mp hu
    exact mem_erase.mpr ⟨by intro huv; subst u; contradiction,hu⟩
  have hc := card_le_card hs
  rw [card_erase_of_mem hv,hUc] at hc
  exact hc

/-- Arbitrary even lower triangles, not just the divided-by-four class. -/
theorem no_all_even_triangle (n : ℕ) (B S : Finset ℕ)
    (hfour : FourFree B) (htri : LowerTriangle n B S)
    (hsmall : 8*(excessHoles n B).card<n) :
    ¬ (∀ x ∈ S, x%2=0) := by
  intro heven
  let U := insert 0 S
  let E := excessHoles n B
  let J := Icc 1 ((n+1)/2)
  have hm : ∀ x ∈ S, x ≤ n := fun x hx =>
    (mem_Icc.mp (mem_inter.mp (htri.2.1 hx)).2).2
  have hzero : 0 ∉ S := by
    intro hz
    have := (mem_Icc.mp (mem_inter.mp (htri.2.1 hz)).2).1
    omega
  have hUc : U.card=4 := by simp [U,hzero,htri.1]
  have hcover : ∀ j ∈ J, ∃ u ∈ U, (2*n+2*j-1)+u ∈ E := by
    intro j hj
    obtain ⟨hj1,hjn⟩ := mem_Icc.mp hj
    let p := 2*n+2*j-1
    have hp : p ∈ Icc (2*n+1) (4*n-n) := mem_Icc.mpr ⟨by dsimp [p];omega,by dsimp [p];omega⟩
    obtain ⟨u,hu,hz⟩ := pivot_missing n n B S hfour htri hm p hp
    have hue : u%2=0 := by
      rcases mem_insert.mp hu with rfl|hu
      · omega
      · exact heven u hu
    have hodd : (p+u)%2=1 := by dsimp [p];omega
    have hE : p+u ∈ E := by
      refine mem_sdiff.mpr ⟨hz,?_⟩
      intro him
      obtain ⟨q,hq,hqz⟩ := mem_image.mp him
      omega
    exact ⟨u,hu,hE⟩
  have hsub : J ⊆ (U.product E).image (fun z : ℕ×ℕ => (z.2-z.1-2*n+1)/2) := by
    intro j hj
    obtain ⟨u,hu,hzu⟩ := hcover j hj
    refine mem_image.mpr ⟨(u,(2*n+2*j-1)+u),mem_product.mpr ⟨hu,hzu⟩,?_⟩
    have hj1 := (mem_Icc.mp hj).1
    change (((2*n+2*j-1)+u-u-2*n+1)/2)=j
    omega
  have hbound : J.card ≤ 4*E.card := by
    calc
      J.card ≤ ((U.product E).image (fun z : ℕ×ℕ => (z.2-z.1-2*n+1)/2)).card := card_le_card hsub
      _ ≤ (U.product E).card := card_image_le
      _ = 4*E.card := by rw [product_eq_sprod,card_product,hUc]
  have hJ : J.card=(n+1)/2 := by simp [J,Nat.card_Icc]
  rw [hJ] at hbound
  change 8*E.card<n at hsmall
  omega

/-- A hypothetical fixed-57 violation admits no residue translate controlled by this cover. -/
theorem no_good_translate (n : ℕ) (B S : Finset ℕ)
    (hfour : FourFree B) (hdbl : DoublingFree B)
    (hsmall : 32*(excessHoles n B).card<n)
    (hbad : 5*n+8*(excessHoles n B).card+57 <
      8*((residueR n B).card+(quarterD n B).card))
    (htri : LowerTriangle n B S) (α : ℕ) (ha : α<8) :
    ¬ (∀ u ∈ insert 0 S, (α+u)%2=1 ∨ (α+u)%8=4) := by
  intro hgood
  have hdef := violation_small_deficit n B hfour hdbl hsmall hbad
  have hne := no_all_even_triangle n B S hfour htri (by omega)
  have hodd : ∃ a ∈ S, a%2=1 := by
    by_contra hn
    push_neg at hn
    apply hne
    intro x hx
    have h := hn x hx
    omega
  have hm : ∀ x ∈ S, x ≤ n := fun x hx =>
    (mem_Icc.mp (mem_inter.mp (htri.2.1 hx)).2).2
  have hcover := weighted_pivot_cover n n α B S hfour hdbl htri hm hgood
  have hp := pivot_card_lower n n α (by omega) ha
  have hM := fun j => multiplicity_le_three n B S htri hodd α j
  have hsum := weighted_residues_bound (insert 0 S) (excessHoles n B) α 3 hM
  have ht := Nat.mul_le_mul_right (deficit n B) (hM 4)
  omega

def MixedResidueProfile (S : Finset ℕ) : Prop :=
  ∃ a b c : ℕ, S={a,b,c} ∧ a%2=1 ∧ b%2=1 ∧ c%2=0 ∧ a%8 ≠ b%8 ∧ c%8 ≠ 0

set_option maxHeartbeats 2000000 in
/-- Arithmetic classification, independent of the conjecture or any finite frontier. -/
theorem residue_classification (a b c : ℕ)
    (hodd : a%2=1 ∨ b%2=1 ∨ c%2=1)
    (hno : ∀ α<8, ¬ ((α%2=1 ∨ α%8=4) ∧
      ((α+a)%2=1 ∨ (α+a)%8=4) ∧
      ((α+b)%2=1 ∨ (α+b)%8=4) ∧
      ((α+c)%2=1 ∨ (α+c)%8=4))) :
    MixedResidueProfile {a,b,c} := by
  have h4 : ¬ ((a%2=1 ∨ a%8=0) ∧ (b%2=1 ∨ b%8=0) ∧
      (c%2=1 ∨ c%8=0)) := by
    intro hh
    apply hno 4 (by omega)
    refine ⟨by omega,?_,?_,?_⟩ <;> omega
  have ha : a%2=1 → ¬ ((b%2=0 ∨ b%8=a%8) ∧ (c%2=0 ∨ c%8=a%8)) := by
    intro hao hh
    apply hno ((12-a%8)%8) (by omega)
    refine ⟨?_,?_,?_,?_⟩ <;> omega
  have hb : b%2=1 → ¬ ((a%2=0 ∨ a%8=b%8) ∧ (c%2=0 ∨ c%8=b%8)) := by
    intro hbo hh
    apply hno ((12-b%8)%8) (by omega)
    refine ⟨?_,?_,?_,?_⟩ <;> omega
  have hc : c%2=1 → ¬ ((a%2=0 ∨ a%8=c%8) ∧ (b%2=0 ∨ b%8=c%8)) := by
    intro hco hh
    apply hno ((12-c%8)%8) (by omega)
    refine ⟨?_,?_,?_,?_⟩ <;> omega
  clear hno
  have hp :
      (a%2=1 ∧ b%2=1 ∧ c%2=0 ∧ a%8 ≠ b%8 ∧ c%8 ≠ 0) ∨
      (a%2=1 ∧ c%2=1 ∧ b%2=0 ∧ a%8 ≠ c%8 ∧ b%8 ≠ 0) ∨
      (b%2=1 ∧ c%2=1 ∧ a%2=0 ∧ b%8 ≠ c%8 ∧ a%8 ≠ 0) := by
    by_cases hao : a%2=1 <;>
      by_cases hbo : b%2=1 <;>
      by_cases hco : c%2=1 <;> omega
  rcases hp with hp|hp|hp
  · exact ⟨a,b,c,rfl,hp⟩
  · refine ⟨a,c,b,?_,hp⟩
    ext x
    simp only [mem_insert,mem_singleton]
    tauto
  · refine ⟨b,c,a,?_,hp⟩
    ext x
    simp only [mem_insert,mem_singleton]
    tauto

theorem violation_triangles_mixed (n : ℕ) (B : Finset ℕ)
    (hfour : FourFree B) (hdbl : DoublingFree B)
    (hsmall : 32*(excessHoles n B).card<n)
    (hbad : 5*n+8*(excessHoles n B).card+57 <
      8*((residueR n B).card+(quarterD n B).card)) :
    ∀ S, LowerTriangle n B S → MixedResidueProfile S := by
  intro S ht
  obtain ⟨a,b,c,hab,hac,hbc,hS⟩ := card_eq_three.mp ht.1
  have hne := no_all_even_triangle n B S hfour ht (by omega)
  have hodd : a%2=1 ∨ b%2=1 ∨ c%2=1 := by
    by_contra hn
    apply hne
    intro x hx
    rw [hS] at hx
    simp only [mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl <;> omega
  rw [hS]
  apply residue_classification a b c hodd
  intro α hα hh
  apply no_good_translate n B S hfour hdbl hsmall hbad ht α hα
  intro u hu
  rw [hS] at hu
  simp only [mem_insert,mem_singleton] at hu
  rcases hu with rfl|rfl|rfl|rfl
  · simpa using hh.1
  · exact hh.2.1
  · exact hh.2.2.1
  · exact hh.2.2.2

/-- The surviving profiles cannot be repaired just by changing the pivot residue. -/
theorem mixed_has_no_good_translate (S : Finset ℕ) (hS : MixedResidueProfile S) :
    ∀ α : ℕ, ¬ (∀ u ∈ insert 0 S, (α+u)%2=1 ∨ (α+u)%8=4) := by
  obtain ⟨a,b,c,rfl,ha,hb,hc,hab,hc8⟩ := hS
  intro α h
  have h0 := h 0 (by simp)
  have h1 := h a (by simp)
  have h2 := h b (by simp)
  have h3 := h c (by simp)
  omega
end OP02.PivotAudit

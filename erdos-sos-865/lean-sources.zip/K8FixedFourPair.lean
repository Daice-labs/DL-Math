import K8FixedFourFifth
import K7Reflection

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK7
namespace OP02.SharpK8

/-- A failed valuation-two contact determines the unordered reflected pair
uniquely. The map takes the smaller of its recovered endpoints. -/
theorem compatible_odd_reflected_pair {H e z : ℕ} {D Z : Finset ℕ}
    (hd : DoublingFree D) (hscale : 16777216≤H)
    (hZ : Z⊆Icc 1 (H/256)) (roots : ∀x∈Z, 4*x∈D)
    (he : e∈Z) (ee : e%2=0)
    (oddPairs : ∀a∈reflectionPairs Z e, a%2=1)
    (pop : (unmatchedTop (H/4) D).card+(unmatchedTop (H/4/4) D).card <
      (reflectionPairs Z e).card)
    (zlo : H/4/2 < z) (zup : z≤fifthCap H) (zres : z%16=0) :
    ∃ a b : ℕ, 0<a ∧ a<b ∧ b≤H/256 ∧ a%2=1 ∧ b%2=1 ∧
      4*a∈D ∧ 4*b∈D ∧ 4*a+4*b∈D ∧ z+4*a∈D ∧ z+4*b∈D := by
  classical
  let J := H/4
  let P := reflectionPairs Z e
  let M := (Ioc (J/2) J).filter (fun v => v%8=4 ∧ v∉D)
  have bound := valuation_two_upper_cost J D hd
  change M.card ≤ _ at bound
  have data {a} (ha : a∈P) :
      0<a ∧ a<e-a ∧ e-a≤H/256 ∧ a%2=1 ∧ (e-a)%2=1 ∧
      4*a∈D ∧ 4*(e-a)∈D ∧ 4*a+4*(e-a)∈D := by
    obtain ⟨haZ,apos,ord,hbZ⟩ := mem_filter.mp ha
    have aodd := oddPairs a ha
    have hup := (mem_Icc.mp (hZ hbZ)).2
    exact ⟨apos,ord,hup,aodd,by omega,roots a haZ,roots _ hbZ,
      (show 4*a+4*(e-a)=4*e by omega) ▸ roots e he⟩
  by_contra! bad
  let recover := fun v:ℕ => min ((v-z)/4) (e-(v-z)/4)
  have cov : P⊆M.image recover := by
    intro a ha
    obtain ⟨apos,ord,bup,ao,bo,ra,rb,rs⟩ := data ha
    have f : z+4*a∉D ∨ z+4*(e-a)∉D := by
      by_contra! ok
      exact bad a (e-a) apos ord bup ao bo ra rb rs ok.1 ok.2
    have inside {x : ℕ} (h : x≤H/256) (xodd : x%2=1) (hm : z+4*x∉D) :
        z+4*x∈M := by
      apply mem_filter.mpr
      dsimp [J]
      dsimp [fifthCap,fifthCeil] at zup
      exact ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,hm⟩
    rcases f with ff|ff
    · exact mem_image.mpr ⟨z+4*a,inside (by omega) ao ff,by dsimp [recover]; omega⟩
    · exact mem_image.mpr ⟨z+4*(e-a),inside bup bo ff,by dsimp [recover]; omega⟩
  have zz := (card_le_card cov).trans card_image_le
  change P.card≤M.card at zz
  dsimp only [J,P] at bound zz
  omega

/-- A fixed upper z is chosen first in the odd branch. One genuine reflected
pair then supplies both of its contacts and its own physical pair sum. -/
theorem odd_pair_and_fifth {H e : ℕ} {D Z : Finset ℕ}
    (hs : D⊆Icc 1 H) (hd : DoublingFree D) (hscale : 16777216≤H)
    (hκ : 1536*(chainCapacity H-D.card)<H)
    (hZ : Z⊆Icc 1 (H/256)) (roots : ∀x∈Z, 4*x∈D)
    (he : e∈Z) (ee : e%2=0) (oddPairs : ∀a∈reflectionPairs Z e, a%2=1)
    (pop : (unmatchedTop (H/4) D).card + (unmatchedTop (H/4/4) D).card <
      (reflectionPairs Z e).card) :
    ∃ a b z : ℕ, 0<a ∧ a<b ∧ b≤H/256 ∧ a%2=1 ∧ b%2=1 ∧
      4*a∈D ∧ 4*b∈D ∧ 4*a+4*b∈D ∧ z∈D ∧
      H/4/2<z ∧ z≤fifthCap H ∧ z%16=0 ∧ z+4*a∈D ∧ z+4*b∈D := by
  obtain ⟨z,hz,zlo,zup,zres⟩ := choose_odd_pair_fifth hs hd hscale hκ
  obtain ⟨a,b,apos,ord,bup,ao,bo,ra,rb,rs,za,zb⟩ :=
    compatible_odd_reflected_pair hd hscale hZ roots he ee oddPairs pop zlo zup zres
  exact ⟨a,b,z,apos,ord,bup,ao,bo,ra,rb,rs,hz,zlo,zup,zres,za,zb⟩

end OP02.SharpK8

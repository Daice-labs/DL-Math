import K9Spec
import K8ProfilesRoles
import K8ProfilesProgression
import K8Shell
import K8UpperSixComplement

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK8
namespace OP02.SharpK9

private theorem count_four (O : Finset ℕ) :
    O.card = (residueCell O 4 0).card + (residueCell O 4 1).card +
      (residueCell O 4 2).card + (residueCell O 4 3).card := by
  have h := card_eq_sum_card_fiberwise (s:=O) (t:=range 4) (f:=fun s : ℕ => s%4)
    (fun s _ => mem_range.mpr (by change s%4<4; omega))
  simp only [sum_range_succ,sum_range_zero,zero_add] at h
  exact h

/-- On the smaller parity, put the exceptional large offset in the control cell. -/
theorem outer_cells {O : Finset ℕ} (large : ℕ) (hO : O.card=7) :
    ∃ a<4, a≠large%4 ∧
      (residueCell O 4 a).card + (residueCell O 4 ((a+2)%4)).card ≤ 3 := by
  let k (j : ℕ) := (residueCell O 4 j).card
  have count := count_four O
  change O.card=k 0+k 1+k 2+k 3 at count
  by_cases he : k 0 + k 2 ≤ 3
  · by_cases hn : large%4=0
    · exact ⟨2,by decide,by omega,show k 2+k 0≤3 by omega⟩
    · exact ⟨0,by decide,Ne.symm hn,he⟩
  · by_cases hn : large%4=1
    · exact ⟨3,by decide,by omega,show k 3+k 1≤3 by omega⟩
    · exact ⟨1,by decide,Ne.symm hn,show k 1+k 3≤3 by omega⟩

/-- Five offsets missing a cell admit a phase with either one control or
multiplicity at most three in every cell. -/
theorem inner_cells {O : Finset ℕ} (hO : O.card=5)
    (miss : ∃j<4, ∀u∈O,u%4≠j) :
    ∃ a<4, (∀u∈O,u%4≠a) ∧ (residueCell O 4 ((a+2)%4)).card≤3 ∧
      ((residueCell O 4 ((a+2)%4)).card≤1 ∨
        ∀j<4,(residueCell O 4 j).card≤3) := by
  classical
  let k (j : ℕ) := (residueCell O 4 j).card
  have count := count_four O
  change O.card=k 0+k 1+k 2+k 3 at count
  by_cases evenLoad : ∀ j<4, k j≤3
  · obtain ⟨a,ha,he⟩ := miss
    exact ⟨a,ha,he,evenLoad _ (Nat.mod_lt _ (by decide)),Or.inr evenLoad⟩
  push_neg at evenLoad
  obtain ⟨j,hj,heavy⟩ := evenLoad
  have zero (a : ℕ) (hh : k a=0) : ∀u∈O,u%4≠a := by
    intro u hu he
    have pos : 0<k a := card_pos.mpr ⟨u,mem_filter.mpr ⟨hu,he⟩⟩
    omega
  have limited (a : ℕ) (ha : a<4) (empty : k a=0) (small : k ((a+2)%4)≤1) :
      (∀u∈O,u%4≠a) ∧ (residueCell O 4 ((a+2)%4)).card≤3 ∧
      ((residueCell O 4 ((a+2)%4)).card≤1 ∨ ∀j<4,(residueCell O 4 j).card≤3) :=
    ⟨zero a empty,small.trans (by decide),Or.inl small⟩
  have parity : k 0+k 2 ≤ 1 ∨ k 1+k 3 ≤ 1 := by interval_cases j <;> omega
  rcases parity with h|h
  · by_cases e : k 0=0
    · exact ⟨0,by decide,limited 0 (by decide) e (show k 2≤1 by omega)⟩
    · exact ⟨2,by decide,limited 2 (by decide) (by omega) (show k 0≤1 by omega)⟩
  · by_cases e : k 1=0
    · exact ⟨1,by decide,limited 1 (by decide) e (show k 3≤1 by omega)⟩
    · exact ⟨3,by decide,limited 3 (by decide) (by omega) (show k 1≤1 by omega)⟩

/-- A common phase for every nontarget label. The period is eight when there
is at most one controlled offset. -/
theorem outer_phase {O : Finset ℕ} {a : ℕ} (ha : a<4)
    (hc : (residueCell O 4 ((a+2)%4)).card≤3) :
    ∃ d r : ℕ, (d=8 ∨ d=32) ∧ r<d ∧
      ((residueCell O 4 ((a+2)%4)).card≤1 → d=8) ∧
      ∀p : ℕ,p%d=r →
        (∀u∈O,u%4=a → (p+u)%4=2) ∧
        (∀u∈O,u%4≠a → canonical (p+u)=true) := by
  let b := (6-a)%4
  let C := residueCell O 4 ((a+2)%4)
  obtain ⟨d,r,hd,hr,hfast,hphase⟩ := control_progression C b (Nat.mod_lt _ (by decide)) hc (by
    intro c h
    have e := (mem_filter.mp h).2
    dsimp only [b]
    omega)
  refine ⟨d,r,hd,hr,hfast,?_⟩
  intro p hp
  obtain ⟨base,ctrl⟩ := hphase p hp
  change p%4=(6-a)%4 at base
  refine ⟨fun u _ e=>by omega,?_⟩
  intro u hu hn
  by_cases same : u%4=(a+2)%4
  · obtain h|h := ctrl u (mem_filter.mpr ⟨hu,same⟩)
    · exact canonical_four_residue _ h
    · rw [show p+u=4*((p+u)/4) by omega,canonical_four]
      exact canonical_four_residue _ (by omega)
  · exact canonical_odd _ (by omega)

end OP02.SharpK9

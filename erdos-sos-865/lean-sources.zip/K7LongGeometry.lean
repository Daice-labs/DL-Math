import K7LowerTags
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

/-- Length of the common domain of bases in the original x-coordinate, with step eight. -/
theorem long_width {H N t a T G L j r : ℕ}
    (hN:N=H/64) (sc:16384≤N) (lo:17*N<t) (hi:3*t<H)
    (budget:6*L+6000<N) (inv:a+T+G≤L) (enough:L<j) (hr:r<8)
    (loss:24*(T:ℤ)≤abs ((t:ℤ)-20*(N:ℤ))+48) :
    (T:ℤ)+max ((a+3*T+G:ℕ):ℤ) (3*((a+3*T+G:ℕ):ℤ)-2*(j:ℤ)+2) <
      ((progression (H/2) (H-t-16*(a+3*T+2)) 8 r).card:ℤ) := by
  have raw:=progression_lower (H/2) (H-t-16*(a+3*T+2)) 8 r (by decide) hr
  have rem : 64*N≤H ∧ H≤64*N+63:=by omega
  by_cases ht:t≤20*N
  · rw [abs_of_nonpos (by omega)] at loss
    omega
  · rw [abs_of_nonneg (by omega)] at loss
    omega

theorem paid_partner_width {H p a T : ℕ} (h : 2*p+16*(a+3*T+2)≤H) :
    a+3*T<(progression (H/2) (H-p) 8 ((12-p%8)%8)).card := by
  have raw:=progression_lower (H/2) (H-p) 8 ((12-p%8)%8) (by decide) (by omega)
  omega

/-- A tested lattice index is its original base plus zero or the offset of an actual endpoint. -/
theorem represented_index {n e b : ℕ} {B:Finset ℕ} {Y:Finset ℕ} {g:ℤ}
    (hg:g∈testedIndices (Y.image (fun x:ℕ=>((x/8:ℕ):ℤ)))
      ((retainedEndpoints n B e b).image (fun a:ℕ=>(a:ℤ))) (e:ℤ)) :
    ∃x∈Y,∃d:ℕ,d≤n/4/64 ∧ g=((x/8:ℕ):ℤ)+(d:ℤ) := by
  rcases mem_union.mp hg with hg|hg
  · obtain ⟨x,hx,rfl⟩:=mem_image.mp hg;exact ⟨x,hx,0,by omega,by simp⟩
  · obtain ⟨g',hg',hs⟩:=mem_biUnion.mp hg
    obtain ⟨x,hx,rfl⟩:=mem_image.mp hg'
    rcases mem_union.mp hs with hs|hs
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp hs
      obtain ⟨u,hu,rfl⟩:=mem_image.mp ha
      exact ⟨x,hx,u,(mem_Icc.mp (mem_inter.mp (mem_filter.mp (mem_filter.mp hu).1).1).2).2,rfl⟩
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp hs
      obtain ⟨u,hu,rfl⟩:=mem_image.mp ha
      have h:=mem_filter.mp (mem_filter.mp hu).1
      exact ⟨x,hx,e-u,(mem_Icc.mp (mem_inter.mp h.2.2.2).2).2,by omega⟩

end OP02.SharpK7.LongOddTask

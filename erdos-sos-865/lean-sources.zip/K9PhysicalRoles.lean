import K9Spec
import K8ProfilesProgression
import K8ProfilesRoles

open Finset
namespace OP02.SharpK9
open OP02.SharpK8 (residueCell)

private theorem choose_parity {n : ℕ} {U : Finset ℕ} (hc : U.card=9)
    (unique : ∀ x∈U, ∀ y∈U, n<2*x → n<2*y → x=y) :
    ∃ k<2, (residueCell U 2 k).card≤5 ∧
      (4≤(residueCell U 2 k).card → ∀ x∈residueCell U 2 k, 2*x≤n) := by
  classical
  let A := residueCell U 2 0
  let B := residueCell U 2 1
  have comp : U.filter (fun x => ¬ x%2=0) = B := by
    ext x
    simp only [B,residueCell,mem_filter]
    constructor <;> rintro ⟨hxU,hxr⟩ <;> exact ⟨hxU,by omega⟩
  have sum : A.card+B.card=9 := by
    rw [←comp]
    exact (Finset.card_filter_add_card_filter_not (s:=U) (fun x => x%2=0)).trans hc
  by_cases a : A.card<4
  · exact ⟨0,by decide,by change A.card≤5; omega,fun h => by change 4≤A.card at h; omega⟩
  by_cases b : B.card<4
  · exact ⟨1,by decide,by change B.card≤5; omega,fun h => by change 4≤B.card at h; omega⟩
  by_cases small : ∀ x∈A, 2*x≤n
  · exact ⟨0,by decide,by change A.card≤5; omega,fun _ => small⟩
  push Not at small
  obtain ⟨x,hx,hlarge⟩ := small
  obtain ⟨hxU,hxe⟩ := mem_filter.mp hx
  refine ⟨1,by decide,by change B.card≤5;omega,?_⟩
  intro _ y hy
  obtain ⟨hyU,hyo⟩ := mem_filter.mp hy
  by_contra! hylarge
  have he := unique x hxU y hyU hlarge hylarge
  omega

/-- Choose one residue class of small targets and its opposite controlled class in the original word. -/
theorem choose_profile_roles {n : ℕ} {U : Finset ℕ} (hc : U.card=9)
    (unique : ∀ x∈U, ∀ y∈U, n<2*x → n<2*y → x=y) :
    ∃ a<4, (residueCell U 4 a).card + (residueCell U 4 ((a+2)%4)).card ≤ 5 ∧
      (residueCell U 4 ((a+2)%4)).card ≤ 3 ∧
      ∀ x∈residueCell U 4 a, 2*x≤n := by
  classical
  obtain ⟨k,hk,hcA,tie⟩ := choose_parity hc unique
  let A := residueCell U 2 k
  let X := residueCell U 4 k
  let Y := residueCell U 4 (k+2)
  have parts : X ∪ Y = A := by
    ext x
    simp only [X,Y,A,residueCell,mem_union,mem_filter]
    constructor
    · rintro (⟨hu,h⟩ | ⟨hu,h⟩) <;> exact ⟨hu,by omega⟩
    · rintro ⟨hu,h⟩
      by_cases h0 : x%4=k
      · exact Or.inl ⟨hu,h0⟩
      · exact Or.inr ⟨hu,by omega⟩
  have dj : Disjoint X Y := by
    apply disjoint_left.mpr
    intro x hx hy
    have hx' := (mem_filter.mp hx).2
    have hy' := (mem_filter.mp hy).2
    omega
  have sizes : X.card + Y.card = A.card := by rw [←card_union_of_disjoint dj,parts]
  change A.card≤5 at hcA
  change 4≤A.card → ∀x∈A, 2*x≤n at tie
  have sx : X⊆A := fun _ hx => parts ▸ mem_union_left Y hx
  have sy : Y⊆A := fun _ hy => parts ▸ mem_union_right X hy
  have kx : (k+2)%4=k+2 := by omega
  have ky : (k+2+2)%4=k := by omega
  suffices h : (Y.card≤3 ∧ ∀x∈X,2*x≤n) ∨ (X.card≤3 ∧ ∀x∈Y,2*x≤n) by
    rcases h with ⟨c,sm⟩ | ⟨c,sm⟩
    · exact ⟨k,by omega,by rw [kx]; change X.card+Y.card≤5; omega,by rwa [kx],sm⟩
    · exact ⟨k+2,by omega,by rw [ky]; change Y.card+X.card≤5; omega,by rwa [ky],sm⟩
  by_cases h4 : 4≤A.card
  · have sx' : ∀x∈X,2*x≤n := fun x hx => tie h4 x (sx hx)
    have sy' : ∀x∈Y,2*x≤n := fun x hx => tie h4 x (sy hx)
    by_cases ys : Y.card ≤ X.card
    · exact Or.inl ⟨by omega,sx'⟩
    · exact Or.inr ⟨by omega,sy'⟩
  have x3 : X.card≤3 := by omega
  have y3 : Y.card≤3 := by omega
  by_cases xe : X=∅
  · exact Or.inl ⟨y3,by simp [xe]⟩
  by_cases ye : Y=∅
  · exact Or.inr ⟨x3,by simp [ye]⟩
  by_cases sm : ∀x∈X,2*x≤n
  · exact Or.inl ⟨y3,sm⟩
  push Not at sm
  obtain ⟨x,hx,large⟩ := sm
  right
  refine ⟨x3,?_⟩
  intro y hy
  by_contra! bad
  have he := unique x (mem_filter.mp hx).1 y (mem_filter.mp hy).1 large bad
  exact disjoint_left.mp dj hx (he ▸ hy)

end OP02.SharpK9

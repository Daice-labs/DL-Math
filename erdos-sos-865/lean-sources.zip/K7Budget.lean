import K7Reflection
import K5GapReduction
import K5CapacityError

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

def smallSupport (n : ℕ) (B : Finset ℕ) :=
  prefixRoots ((n/4)/64) (quarterD n B)
def lambdaBudget (n : ℕ) (B : Finset ℕ) :=
  (emptyOuter (n/4/4) (quarterD n B)).card +
  (emptyOuter (n/4) (quarterD n B)).card + (emptyPairs n B).card
def midEmpty (n : ℕ) (B : Finset ℕ) := emptyOuter (n/4/16) (quarterD n B)
def midOddLoss (n : ℕ) (B : Finset ℕ) :=
  (midEmpty n B).filter (fun t => t%2=1)
def surplus (n : ℕ) (B : Finset ℕ) : ℤ :=
  ((smallSupport n B).card : ℤ) - ((n/4/64+1)/2 : ℕ)
def logLevels (H : ℕ) := Nat.log 4 H + 1

/-- A telescope of the *actual* occupied classes, keeping all three remainders. -/
theorem three_shells (H : ℕ) (D : Finset ℕ) (hd : DoublingFree D) :
  (prefixRoots H D).card + (emptyOuter H D).card + (emptyOuter (H/4) D).card +
    (emptyOuter (H/16) D).card + H/4 + H/16 + 2*(H/64)
    = (prefixRoots (H/64) D).card + H := by
  have h1 := shell_count H D hd
  have h2 := shell_count (H/4) D hd
  have h3 := shell_count (H/16) D hd
  rw [show H/4/4 = H/16 by omega] at h2
  rw [show H/16/4 = H/64 by omega] at h3
  omega

theorem capacity_log_bound (t H : ℕ) (ht : t ≤ H) :
    3*chainCapacity t ≤ 2*t + logLevels H := by
  have hp := Nat.lt_pow_succ_log_self (b:=4) (by decide) H
  have hz : t/4^(logLevels H)=0 := Nat.div_eq_of_lt (lt_of_le_of_lt ht hp)
  simpa only [hz,mul_zero,add_zero] using capacity_truncation (logLevels H) t

/-- Original budget and the three-level identity imply a four-unit floor loss,
uniformly. The count on the left includes all middle empty classes. -/
theorem surplus_lower (β : ℝ) (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hpg : (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ) - (totalBudget n B:ℝ)) :
    (lambdaBudget n B : ℝ) + (midEmpty n B).card + β*n - 4 ≤ (surplus n B : ℝ) := by
  let H := n/4
  let D := quarterD n B
  have hpre : prefixRoots H D = D := inter_eq_left.mpr (filter_subset _ _)
  have hs := three_shells H D (quarter_doubling_free n B hd)
  rw [hpre] at hs
  have hsR : (D.card : ℝ) + (emptyOuter H D).card + (emptyOuter (H/4) D).card +
    (emptyOuter (H/16) D).card + (H/4:ℕ) + (H/16:ℕ) + 2*(H/64:ℕ) =
      ((prefixRoots (H/64) D).card:ℝ)+H := by exact_mod_cast hs
  have hf : 512*(H+((H/64+1)/2)) ≤ 340*H+512*(H/4 + H/16 + 2*(H/64)+4) := by omega
  have hfR : (512:ℝ)*(H+((H/64+1)/2:ℕ)) ≤ 340*H+
      512*((H/4:ℕ)+(H/16:ℕ)+(2:ℝ)*(H/64:ℕ)+4) := by exact_mod_cast hf
  have hhn : (4:ℝ)*H ≤ n := by exact_mod_cast (show 4*H≤n by dsimp [H];omega)
  have hdp : (emptyPairs n B).card ≤ totalBudget n B := by
    unfold totalBudget; rw [deficit_split n B hd]; omega
  have hdpR : ((emptyPairs n B).card:ℝ) ≤ totalBudget n B := by exact_mod_cast hdp
  change (85/512+β)*(n:ℝ) ≤ (D.card:ℝ)-_ at hpg
  simp only [lambdaBudget,midEmpty,surplus,smallSupport,Nat.cast_add,Int.cast_sub,Int.cast_natCast]
  change ((emptyOuter (H/4) D).card:ℝ) + (emptyOuter H D).card + (emptyPairs n B).card +
    (emptyOuter (H/16) D).card + β*n-4 ≤ (prefixRoots (H/64) D).card-((H/64+1)/2:ℕ)
  linarith only [hsR,hfR,hpg,hhn,hdpR]

theorem surplus_upper (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    (surplus n B : ℝ) ≤ (n/4/64:ℕ)/6 + (logLevels (n/4):ℝ)/3 := by
  let N := n/4/64
  let S := smallSupport n B
  have hS : S ⊆ Icc 1 N := inter_subset_right
  have hD := quarter_doubling_free n B hd
  have hdS : DoublingFree S := fun x hx h2 =>
    hD x (mem_inter.mp hx).1 (mem_inter.mp h2).1
  have hb := chain_capacity_with_top_loss N S hS hdS
  have hr := canonical_capacity_recurrence N
  have ht := capacity_log_bound (N/4) (n/4) (by dsimp [N];omega)
  have hk : 6*S.card ≤ 6*((N+1)/2)+N+2*(logLevels (n/4)) := by omega
  have hkR : (6:ℝ)*S.card ≤ 6*((N+1)/2:ℕ)+N+2*(logLevels (n/4)) := by exact_mod_cast hk
  simp only [surplus,Int.cast_sub,Int.cast_natCast]
  change (S.card:ℝ)-((N+1)/2:ℕ) ≤ (N:ℝ)/6 + (logLevels (n/4):ℝ)/3
  linarith

theorem signed_supply (β : ℝ) (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hpg : (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale : (16:ℕ) ≤ n/4) (hlarge : 10*(logLevels (n/4):ℝ)+1000 ≤ β*n) :
    (lambdaBudget n B:ℝ) + (midEmpty n B).card +
      (β*n-(3/2:ℝ)*logLevels (n/4)-1) ≤ (surplus n B:ℝ) ∧
    (lambdaBudget n B:ℝ)+(midOddLoss n B).card < (n/4/64:ℕ)/6 - 1000 ∧
    0 < surplus n B := by
  have hl := surplus_lower β n B hd hpg
  have hu := surplus_upper n B hd
  have hlogN : 2≤Nat.log 4 (n/4) := Nat.le_log_of_pow_le (by decide) (by norm_num;exact hscale)
  have hlog : (3:ℝ)≤logLevels (n/4) := by
    exact_mod_cast (show 3≤logLevels (n/4) by unfold logLevels; omega)
  have hodd : ((midOddLoss n B).card:ℝ) ≤ (midEmpty n B).card := by
    exact_mod_cast (card_le_card (filter_subset _ _) : (midOddLoss n B).card ≤ _)
  have hz : (0:ℝ) ≤ lambdaBudget n B := by positivity
  have hz' : (0:ℝ) ≤ (midEmpty n B).card := by positivity
  refine ⟨by linarith,by linarith,?_⟩
  have : (0:ℝ) < (surplus n B : ℝ) := by linarith
  exact_mod_cast this

/-- An actual largest even reflection sum and actual occupied pairs follow
from the original positive gap, without prescribing their parities. -/
theorem actual_reflection_supply (β : ℝ) (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hpg : (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale : 16 ≤ n/4) (hlarge : 10*(logLevels (n/4):ℝ)+1000 ≤ β*n) :
    ∃ e∈smallSupport n B, e%2=0 ∧ (∀ x∈smallSupport n B,x%2=0 → x≤e) ∧
      surplus n B ≤ ((reflectionPairs (smallSupport n B) e).card:ℤ) := by
  have hs := (signed_supply β n B hd hpg hscale hlarge).2.2
  have hdr := quarter_doubling_free n B hd
  have hdS : DoublingFree (smallSupport n B) := fun x hx h2 =>
    hdr x (mem_inter.mp hx).1 (mem_inter.mp h2).1
  obtain ⟨e,he,hee,hm,hc⟩ := find_reflection_sum (n/4/64) (smallSupport n B) inter_subset_right hdS
    (by unfold surplus at hs;omega)
  exact ⟨e,he,hee,hm,by unfold surplus;omega⟩

end OP02.SharpK7

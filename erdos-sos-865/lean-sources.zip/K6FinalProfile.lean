import K6FinalWindow
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 2000000
theorem final_profile_contradiction (β:ℝ) (n w a b s:ℕ) (B S T:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hg:MiddleGap6 n B)
    (hn:65536 ≤ n) (hq:384*totalBudget n B ≤ n)
    (hS:S ⊆ lower n B) (hSc:S.card=5) (hSp:∀x ∈ S,∀y ∈ S,x ≠ y  →  x+y ∈ B)
    (hw:w ∈ insert 0 S) (ha:a ∈ insert 0 S) (hb:b ∈ insert 0 S)
    (ha4:(2+a)%4=w%4) (hb4:(2+b)%4=w%4)
    (hother:∀t ∈ insert 0 S\{w,a,b},t%2 ≠ w%2)
    (hload:∀r:ℕ,((insert 0 S\{w,a,b}).filter (fun t=>t%4=r)).card ≤ 2)
    (hwB:4*w ≤ 3*n) (hmB:2*max a b ≤ n) (hsB:s ≤ n/16)
    (hT:T ⊆ quarterD n B) (hTc:T.card=3) (hTs:∀t ∈ T,t ≤ s)
    (hTp:∀x ∈ T,∀y ∈ T,x ≠ y  →  x+y ∈ quarterD n B)
    (hβ:0<β) (hβu:β≤1/1024) (hmargin:(100:ℝ)≤β*n)
    (hqsharp:(totalBudget n B:ℝ)≤n/512-(β/2)*n)
    (hsearly:(s:ℝ)≤11*(n/16:ℕ)/16-totalBudget n B-β*n+12) : False := by
  have hδq:(missingTopOdd n B).card≤totalBudget n B := by
    have:=deficit_split n B hd
    unfold totalBudget
    omega
  have hl:=final_window_length n (missingTopOdd n B).card w (max a b) s (totalBudget n B) hn hq hδq hwB hmB hsB
  have hu:=final_window_upper n w a b s B S T hf hd hg hn hq hS hSc hSp hw ha hb ha4 hb4 hother hload hwB hmB hsB hT hTc hTs hTp
  have hwn:w≤n := by omega
  have hmn:max a b+8*s≤n := by omega
  have hcast:(min ((n-w:ℕ):ℝ) ((n-max a b-8*s:ℕ):ℝ))≤
      2*((finalWindowU n (missingTopOdd n B).card w (max a b) s-finalWindowL n (missingTopOdd n B).card w:ℕ):ℝ)+4*(4*(missingTopOdd n B).card+4)+16 := by
    exact_mod_cast hl
  have hsub1:((n-w:ℕ):ℝ)=(n:ℝ)-w := by rw [Nat.cast_sub hwn]
  have hsub2:((n-max a b-8*s:ℕ):ℝ)=(n:ℝ)-max a b-8*s := by
    rw [Nat.cast_sub (by omega),Nat.cast_sub (by omega)]
    push_cast
    ring
  rw [hsub1,hsub2] at hcast
  have hmin:min (((n:ℝ)-w)/2) (((n:ℝ)-max a b)/2-4*s) =
      min ((n:ℝ)-w) ((n:ℝ)-max a b-8*s)/2 := by
    have he:((n:ℝ)-max a b)/2-4*s=((n:ℝ)-max a b-8*s)/2 := by ring
    rw [he, min_div_div_right (by norm_num : (0:ℝ)≤2)]
  have hKr:((n/16:ℕ):ℝ)≤(n:ℝ)/16 := by
    have h:16*(n/16)≤n := by omega
    have hR:(16:ℝ)*(n/16:ℕ)≤n := by exact_mod_cast h
    linarith
  have hmr:((max a b:ℕ):ℝ)≤(n:ℝ)/2 := by
    have hR:(2:ℝ)*(max a b:ℕ)≤n := by exact_mod_cast hmB
    linarith
  have hwr:(w:ℝ)≤3*(n:ℝ)/4 := by
    have hR:(4:ℝ)*w≤3*n := by exact_mod_cast hwB
    linarith
  apply band_arithmetic_contradiction n (totalBudget n B) (missingTopOdd n B).card β s ((max a b:ℕ):ℝ) w (n/16:ℕ)
    (finalWindowU n (missingTopOdd n B).card w (max a b) s-finalWindowL n (missingTopOdd n B).card w:ℕ)
    (by exact_mod_cast hn) (by positivity) (by exact_mod_cast hδq) hβ hβu hmargin hqsharp
    hKr hsearly hmr hwr
  · rw [hmin]
    linarith
  · exact_mod_cast hu
#print axioms final_profile_contradiction
end OP02.SharpK6

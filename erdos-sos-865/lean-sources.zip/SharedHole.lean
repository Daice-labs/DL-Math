import SharedCleaning
open Finset
namespace OP02.SharpK4
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot OP02.BothEdges OP02.EdgeBand
set_option maxHeartbeats 3000000

theorem shared_hole_bound (n : ℕ) (B : Finset ℕ) (hf : FourFree B) (hd : DoublingFree B)
    (hx : ¬NoEdge B (middleZero n B)) (hy : ¬NoEdge B (parityMiddle n B 1)) :
    (holes n B).card ≤ 7*(Ho n B).card+
      6*((middle n B).filter (fun x=>x%4=2)).card+6*((H0 n B).card+(H2 n B).card)+5 := by
  classical
  let O := parityMiddle n B 1
  let T := (middle n B).filter (fun x=>x%4=2)
  have hholes := holes_partition n B hd
  have hmiddle := middle_partition n B
  have heven := even_middle_partition n B
  have hexcess := excess_partition n B
  have hodd := zero_edge_odd_population n B hf hd hx
  by_cases hgood : ∃x∈O,∃y∈O,x≠y ∧ x+y∈B ∧
      (res4 (Ho n B) (x%4)).card+(res4 (Ho n B) (y%4)).card≤(Ho n B).card
  · obtain ⟨x,hxO,y,hyO,hxy,hE,hbudget⟩ := hgood
    have hzero := odd_edge_zero_population n x y B hf hd hxO hyO hxy hE
    dsimp only [O,T] at *
    omega
  have hlarge : ∀x∈O,∀y∈O,x≠y→x+y∈B→
      (Ho n B).card < (res4 (Ho n B) (x%4)).card+(res4 (Ho n B) (y%4)).card := by
    intro x hxO y hyO hxy hE
    by_contra hh
    exact hgood ⟨x,hxO,y,hyO,hxy,hE,by omega⟩
  obtain ⟨x,hxO,y,hyO,hxy,hE⟩ : ∃x∈O,∃y∈O,x≠y ∧ x+y∈B := by
    simpa [O,NoEdge,not_forall] using hy
  let r := x%4
  let Y := res4 O r
  let I := O\Y
  have hoddres (z : ℕ) (hz : z∈O) : z%4=1 ∨ z%4=3 := by
    have hp := (mem_filter.mp hz).2
    omega
  have hr : r=1 ∨ r=3 := hoddres x hxO
  have hne : Y.Nonempty := ⟨x,mem_filter.mpr ⟨hxO,rfl⟩⟩
  let A := (res4 (Ho n B) 1).card
  let C := (res4 (Ho n B) 3).card
  have hpart := odd_hole_partition n B
  have hw (z : ℕ) (hz : z∈O) :
      (res4 (Ho n B) (z%4)).card=residueWeight A C (z%4) := by
    rcases hoddres z hz with hh|hh
    · simp [residueWeight,hh,A]
    · simp [residueWeight,hh,C]
  have hisolated : ∀z∈I,∀w∈O,z≠w→z+w∉B := by
    intro z hz w hwO hzw hsum
    obtain ⟨hzO,hznot⟩ := mem_sdiff.mp hz
    have h1 := hlarge x hxO y hyO hxy hE
    have h2 := hlarge z hzO w hwO hzw hsum
    rw [hw x hxO,hw y hyO] at h1
    rw [hw z hzO,hw w hwO] at h2
    have hp : (Ho n B).card=A+C := hpart
    rw [hp] at h1 h2
    have hu := large_pairs_same A C (x%4) (y%4) (z%4) (w%4)
      (hoddres x hxO) (hoddres y hyO) (hoddres z hzO) (hoddres w hwO) h1 h2
    exact hznot (mem_filter.mpr ⟨hzO,hu.2.1⟩)
  have hi := inactive_odd_bound n r B hd hr hne hisolated
  have hiRestore : I.card+Y.card=O.card := card_sdiff_add_card_eq_card (filter_subset _ _)
  have hzGeneral := odd_edge_zero_population n x y B hf hd hxO hyO hxy hE
  have hxx : (res4 (Ho n B) (x%4)).card≤(Ho n B).card := card_le_card (filter_subset _ _)
  have hyy : (res4 (Ho n B) (y%4)).card≤(Ho n B).card := card_le_card (filter_subset _ _)
  have hzero : (middleZero n B).card≤4*(Ho n B).card+T.card+(H0 n B).card+1 := by
    dsimp only [T]
    omega
  by_cases hgx : (goodIndices (middleZero n B) B).Nonempty
  · by_cases hgy : (goodIndices Y B).Nonempty
    · have hs := actual_staircase_count n r B hf hr hgx hgy
      change I.card≤2*T.card+2*(H0 n B).card+(H2 n B).card+1 at hi
      change (middleZero n B).card+Y.card≤4*(Ho n B).card+T.card+(H0 n B).card+I.card+(H2 n B).card+3 at hs
      dsimp only [O,T] at *
      omega
    · have hg : (goodIndices Y B).card=0 := card_eq_zero.mpr (not_nonempty_iff_eq_empty.mp hgy)
      have hb := bad_odd_class_bound n r B hr
      have hp := indices_partition Y B
      change (badIndices Y B).card≤I.card+(H2 n B).card at hb
      change I.card≤2*T.card+2*(H0 n B).card+(H2 n B).card+1 at hi
      dsimp only [O,T] at *
      omega
  · have hg : (goodIndices (middleZero n B) B).card=0 := card_eq_zero.mpr (not_nonempty_iff_eq_empty.mp hgx)
    have hb := bad_zero_bound n B
    have hp := indices_partition (middleZero n B) B
    dsimp only [O,T] at *
    omega

/-- Complete reviewed k4 charge theorem; no new capacity, edge, or selection premise. -/
theorem complete_charge_bound (n : ℕ) (B : Finset ℕ) (hc : ChargeContext n B) :
    8*(quarterD n B).card≤n+8*(deficit n B+(excessHoles n B).card)+72 := by
  classical
  by_cases hx : NoEdge B (middleZero n B)
  · have h := zero_edgeless_bound n B hc hx
    omega
  by_cases hy : NoEdge B (parityMiddle n B 1)
  · exact odd_edgeless_bound n B hc hy
  have hh := shared_hole_bound n B hc.2.2.1 hc.2.2.2.1 hx hy
  have ht := middle_two_mod_four n B hc.2.2.2.1
  have he := excess_partition n B
  have hholes := hc.2.2.2.2.1
  have hnear : n≤32*(deficit n B+(excessHoles n B).card)+64 := by omega
  have hb := near_budget_bound n B hc hnear
  omega

/-- Only the published midpoint theorem remains a formal input to this endpoint. -/
theorem complete_k4_endpoint (hD : OP02.Frontier.Dousse4) : OP02.K4Goal := by
  apply k4_of_mixed_charge_and_dousse ?_ hD
  refine ⟨72,?_⟩
  intro n hn B hsub hf hd hh hs ht hm
  exact complete_charge_bound n B ⟨hn,hsub,hf,hd,hh,hs,ht,hm⟩

#print axioms shared_hole_bound
#print axioms complete_charge_bound
#print axioms complete_k4_endpoint
end OP02.SharpK4

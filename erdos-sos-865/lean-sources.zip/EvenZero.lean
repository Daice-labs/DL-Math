import PositiveEdges
import RootTotal
open Finset
namespace OP02.BothEdges
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot OP02.EdgeBand
theorem even_zero_subset_bound (n:ℕ) (B P:Finset ℕ) (hd:DoublingFree B)
    (hP:P⊆parityMiddle n B 0) (hn:NoEdge B (P.filter (fun x=>x%4=0))) :
    P.card≤2*deficit n B+(H0 n B).card+((parityMiddle n B 0)\P).card+1 := by
  let E:=parityMiddle n B 0
  let P0:=P.filter (fun x=>x%4=0)
  let P2:=P.filter (fun x=>x%4=2)
  have hpart:P0∪P2=P := by
    ext x
    simp only [P0,P2,mem_union,mem_filter]
    constructor
    · rintro (⟨h,_⟩|⟨h,_⟩) <;> exact h
    · intro hx
      have hp: x%2=0 := (mem_filter.mp (hP hx)).2
      by_cases h:x%4=0
      · exact Or.inl ⟨hx,h⟩
      · exact Or.inr ⟨hx,by omega⟩
  have hdis:Disjoint P0 P2 := by
    apply disjoint_left.mpr
    intro x hx hy
    have h0:=(mem_filter.mp hx).2
    have h2:=(mem_filter.mp hy).2
    omega
  have hcards:P0.card+P2.card=P.card := by rw [←card_union_of_disjoint hdis,hpart]
  have hp2:P2.card≤deficit n B := by
    have hs:P2⊆(middle n B).filter (fun x=>x%4=2) := by
      intro x hx
      exact mem_filter.mpr ⟨(mem_filter.mp (hP (mem_filter.mp hx).1)).1,(mem_filter.mp hx).2⟩
    exact le_trans (card_le_card hs) (middle_two_mod_four n B hd)
  have hrestore: (E\P).card+P.card=E.card := card_sdiff_add_card_eq_card hP
  by_cases hzero:P0=∅
  · have hc:P0.card=0:=by rw [hzero,card_empty]
    omega
  have hne:P0.Nonempty:=nonempty_iff_ne_empty.mpr hzero
  let F:=(E.image (fun x=>2*x))∪H0 n B
  have hsum:∀ x ∈ P0, ∀ y ∈ P0, x+y∈F := by
    intro x hx y hy
    obtain ⟨hxP,hx4⟩:=mem_filter.mp hx
    obtain ⟨hyP,hy4⟩:=mem_filter.mp hy
    have hxM:=(mem_filter.mp (hP hxP)).1
    have hyM:=(mem_filter.mp (hP hyP)).1
    have hxi:=mem_Icc.mp (mem_inter.mp hxM).2
    have hyi:=mem_Icc.mp (mem_inter.mp hyM).2
    have hb:x+y∉B := by
      by_cases he:x=y
      · subst y
        have hh:=hd x (mem_inter.mp hxM).1
        simpa [two_mul] using hh
      · exact hn x (mem_filter.mpr ⟨hxP,hx4⟩) y (mem_filter.mpr ⟨hyP,hy4⟩) he
    rcases missing_split (n:=n) (by omega) hb with him|hh
    · obtain ⟨v,hv,hve⟩:=him
      apply mem_union_left
      exact mem_image.mpr ⟨v,mem_filter.mpr ⟨hv,by omega⟩,hve⟩
    · apply mem_union_right
      exact mem_filter.mpr ⟨hh,by omega⟩
  have hc:=sum_union_lower P0 P0 F hne hne hsum
  have hF:F.card≤E.card+(H0 n B).card := by
    have hu:=card_union_le (E.image (fun x=>2*x)) (H0 n B)
    have hi:=card_image_le (s:=E) (f:=fun x=>2*x)
    dsimp [F]
    omega
  dsimp [E] at *
  omega

/-- Full even population bound needs edgelessness only on actual residue-zero middle. -/
theorem even_zero_bound (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B)
    (hn:NoEdge B (middleZero n B)) :
    (parityMiddle n B 0).card≤2*deficit n B+(H0 n B).card+1 := by
  have hset:(parityMiddle n B 0).filter (fun x=>x%4=0)=middleZero n B := by
    ext x
    simp only [parityMiddle,middleZero,mem_filter]
    constructor
    · rintro ⟨⟨hm,hp⟩,hz⟩; exact ⟨hm,hz⟩
    · rintro ⟨hm,hz⟩; exact ⟨⟨hm,by omega⟩,hz⟩
  have hp:NoEdge B ((parityMiddle n B 0).filter (fun x=>x%4=0)) := by
    rw [hset];exact hn
  have h:=even_zero_subset_bound n B (parityMiddle n B 0) hd Subset.rfl hp
  simpa using h
#print axioms even_zero_subset_bound
#print axioms even_zero_bound
end OP02.BothEdges

import K5CanonicalHoles
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 3000000

theorem chain_capacity_le_interval (H:ℕ) : chainCapacity H≤H := by
  have h := card_le_card (filter_subset (fun x=>canonical x=true) (Icc 1 H))
  rw [Nat.card_Icc] at h
  simpa [chainCapacity,canonicalSlots] using h

/-- A fixed truncation depth has one global rounding cost, not one cost per chain. -/
theorem capacity_truncation (j H:ℕ) :
    3*chainCapacity H≤2*H+j+3*(H/4^j) := by
  induction j generalizing H with
  | zero =>
    have h := chain_capacity_le_interval H
    simp only [pow_zero,Nat.div_one,Nat.add_zero]
    omega
  | succ j ih =>
    have hb := ih (H/4)
    have hr := canonical_capacity_recurrence H
    have he : H/4/4^j=H/4^(j+1) := by rw [Nat.div_div_eq_div_mul,pow_succ]; congr 1; omega
    rw [he] at hb
    omega

/-- Uniform asymptotic capacity estimate obtained with a fixed depth, avoiding
any unformalized logarithm estimate. -/
theorem capacity_uniform_error (ε:ℝ) (hε:0<ε) :
    ∃H₀:ℕ,∀H:ℕ,H₀≤H→(chainCapacity H:ℝ)≤(2/3:ℝ)*H+ε*H := by
  obtain ⟨j,hj⟩ := exists_nat_gt (6/ε)
  have hpow : ∀k:ℕ,k≤4^k := by
    intro k
    induction k with
    | zero => simp
    | succ k ih =>
      rw [pow_succ]
      have hp : 0<4^k := by positivity
      omega
  have hpj := hpow j
  have hp : (0:ℝ)<(4^j:ℕ) := by positivity
  have hjp : (j:ℝ)≤(4^j:ℕ) := by exact_mod_cast hpj
  have hβp : (6:ℝ)<ε*(4^j:ℕ) := by
    have h := (div_lt_iff₀ hε).mp hj
    nlinarith
  obtain ⟨H₀,hH₀⟩ := exists_nat_gt ((j:ℝ)/ε)
  refine ⟨H₀,?_⟩
  intro H hH
  have hHreal : (H₀:ℝ)≤H := by exact_mod_cast hH
  have hjH : (j:ℝ)≤ε*H := by
    have hdiv : (j:ℝ)/ε<(H:ℝ) := lt_of_lt_of_le hH₀ hHreal
    have := (div_lt_iff₀ hε).mp hdiv
    linarith
  have hb := capacity_truncation j H
  have hbr : (3:ℝ)*chainCapacity H≤2*H+j+3*(H/4^j:ℕ) := by exact_mod_cast hb
  have hdiv := Nat.div_mul_le_self H (4^j)
  have hdivr : ((H/4^j:ℕ):ℝ)*(4^j:ℕ)≤H := by exact_mod_cast hdiv
  have htail : (3:ℝ)*(H/4^j:ℕ)≤ε*H := by
    have hn : (0:ℝ)≤(H/4^j:ℕ) := by positivity
    nlinarith [mul_nonneg (le_of_lt hε) (show (0:ℝ)≤H-(H/4^j:ℕ)*(4^j:ℕ) by linarith)]
  nlinarith

/-- An arbitrary positive normalized violation makes the complete actual
canonical budget small, uniformly over B. -/
theorem positive_gap_canonical_budget (β:ℝ) (hβ:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,DoublingFree B→
    (5/32:ℝ)*n+β*n≤((quarterD n B).card:ℝ)-((deficit n B+(excessHoles n B).card:ℕ):ℝ)→
    ((chainDeficit n B+deficit n B+(excessHoles n B).card:ℕ):ℝ)≤
      (n:ℝ)/96-(β/2)*n := by
  obtain ⟨H₀,hH₀⟩ := capacity_uniform_error (2*β) (by positivity)
  refine ⟨4*H₀,?_⟩
  intro n hn B hd hgap
  have hH : H₀≤n/4 := by omega
  have hc := hH₀ (n/4) hH
  have hnH : (4:ℝ)*(n/4:ℕ)≤n := by exact_mod_cast (show 4*(n/4)≤n by omega)
  have hcap := chain_capacity_with_top_loss (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  have hk : chainDeficit n B+(quarterD n B).card=chainCapacity (n/4) := by unfold chainDeficit; omega
  have hkr : (chainDeficit n B:ℝ)+(quarterD n B).card=chainCapacity (n/4) := by exact_mod_cast hk
  push_cast at hgap ⊢
  nlinarith [mul_nonneg (le_of_lt hβ) (show (0:ℝ)≤n-4*(n/4:ℕ) by linarith)]

#print axioms capacity_truncation
#print axioms capacity_uniform_error
#print axioms positive_gap_canonical_budget
end OP02.SharpK5

import K7FourOddRows
import K7ThreeOddRows
import K7MoreO2
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7
open LongOddTask
set_option maxHeartbeats 1800000

private theorem historical_four_dispatch {i:ℕ} (hi:i=1 ∨ i=12 ∨ i=17 ∨ i=22):RowExclusion i:=by
  classical
  intro β hb
  obtain ⟨p,hp⟩:=row01_all_even β hb
  obtain ⟨q,hq⟩:=row12_same_odd hb
  obtain ⟨u,hu⟩:=rows17_22 hb
  refine ⟨max p (max q u),?_⟩
  intro n hn B sub hf hd hg S hs row
  have fifth:5≤(oddOffsets S).card→evenZero S:=by
    intro all;have sizes:=parity_partition S;have sz:=hs.1
    have empty:evenOffsets S=∅:=card_eq_zero.mp (by omega)
    intro v hv ev
    have ve:v∈evenOffsets S:=mem_filter.mpr ⟨hv,ev⟩
    simp [empty] at ve
  have cases:(oddOffsets S).card=0 ∨ (4≤(oddOffsets S).card ∧ evenZero S) ∨
      ((oddOffsets S).card=3 ∧ evenZero S ∧ sameOdd S):=by
    unfold rowNumber at row;dsimp only at row
    split_ifs at row <;> first | omega | exact Or.inr (Or.inl ⟨by omega,by assumption⟩) |
      exact Or.inr (Or.inr ⟨by omega,by assumption,by assumption⟩) | exact Or.inr (Or.inl ⟨by omega,fifth (by omega)⟩)
  rcases cases with zero|⟨four,ev⟩|⟨three,ev,mono⟩
  · apply hp n (by omega) B hf hd hg S hs
    intro x hx;by_contra ex
    have xo:x∈oddOffsets S:=mem_filter.mpr ⟨hx,by omega⟩
    have :=card_pos.mpr ⟨x,xo⟩;omega
  · exact hu n (by omega) B hf hd hg S hs four ev
  · exact hq n (by omega) B hf hd hg S hs three ev mono

/-- Every actual profile has a genuine exclusion proof under the seven-point
midpoint premise. This dispatcher also covers all placements of row 9. -/
theorem all22Rows_of_dousse7 (hD:Dousse7) (i:ℕ) (hi:i∈Icc 1 22):RowExclusion i:=by
  obtain ⟨lo,up⟩:=mem_Icc.mp hi
  interval_cases i <;> first
    | exact historical_four_dispatch (by decide)
    | exact short_rows_of_dispatch hD (by decide)
    | exact direct_T2_rows hD (by decide)
    | exact bridge_rows_of_dispatch hD (by decide)
    | exact balanced_two_rows hD (by decide)
    | exact row13_of_dispatch hD
    | exact remaining_three_odd_rows hD (by decide)
    | exact four_odd_rows hD (by decide)

/-- One threshold chosen before n, the set, the row and the seed. -/
theorem uniform22_of_dousse7 (hD:Dousse7) {β:ℝ} (hb:0<β):
    ∃U:ℕ,∀n:ℕ,U≤n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ)→
    ∀i∈Icc 1 22,∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→ rowNumber n B S=i→False:=by
  classical
  let m (i:ℕ):ℕ:=if hi:i∈Icc 1 22 then (all22Rows_of_dousse7 hD i hi β hb).choose else 0
  refine ⟨(Icc 1 22).sup m,?_⟩
  intro n hn B sub hf hd hg i ii S hs row
  have bound:m i≤n:=(le_sup (f:=m) ii).trans hn
  simp only [m,dif_pos ii] at bound
  exact (all22Rows_of_dousse7 hD i ii β hb).choose_spec n bound B sub hf hd hg S hs row

theorem actualO2_of_dousse7 (hD:Dousse7) : ActualO2Goal :=
  (o2_iff_remaining_windows hD).mpr (complete_remaining_O2_windows hD)

theorem normalizedK7_of_dousse7 (hD:Dousse7) : NormalizedK7Goal :=
  normalized_of_open_rows hD (fun i hi=>all22Rows_of_dousse7 hD i (mem_sdiff.mp hi).1)

/-- Conditional sharp Erdős–Sós endpoint for the existing extremal function. -/
theorem sharpK7_of_dousse7 : Dousse7 → SharpK7Limit :=
  fun hD=>limit_of_normalized hD (normalizedK7_of_dousse7 hD)

end OP02.SharpK7

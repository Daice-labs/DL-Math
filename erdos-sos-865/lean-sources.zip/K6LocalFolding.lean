import KnownK3
open Finset Erdos865
namespace OP02.SharpK6
set_option maxHeartbeats 2000000

/-- Local contract: labels are in the actual ambient A, not a cropped prefix. -/
def NoTriangleAt (A : Finset ℕ) (h : ℕ) : Prop :=
  ∀ x ∈ A, ∀ y ∈ A, x ≠ y → x ≠ h → y ≠ h →
    x + y ∈ A → x + h ∈ A → y + h ∈ A → False

theorem local_foldedOK {A : Finset ℕ} {N h : ℕ}
    (ha : NoTriangleAt A h) (hh : h ∈ A) : FoldedOK h (Bset A N h) := by
  constructor
  · intro x hx
    simpa only [Bset, Xset, Yset, mem_inter, mem_filter, mem_Ico] using
      (show 1 ≤ x ∧ x < h from (mem_Ico.mp (mem_filter.mp (mem_inter.mp hx).1).1))
  · intro x hx y hy hxy
    have hx' := mem_inter.mp hx
    have hy' := mem_inter.mp hy
    have hxi := mem_Ico.mp (mem_filter.mp hx'.1).1
    have hyi := mem_Ico.mp (mem_filter.mp hy'.1).1
    have hxA := (mem_filter.mp hx'.1).2
    have hyA := (mem_filter.mp hy'.1).2
    have hxh : x+h∈A := by simpa [Nat.add_comm] using (mem_filter.mp hx'.2).2.2
    have hyh : y+h∈A := by simpa [Nat.add_comm] using (mem_filter.mp hy'.2).2.2
    have reject (hs : x+y∈A) : False := ha x hxA y hyA hxy (by omega) (by omega) hs hxh hyh
    constructor
    · intro hs; exact reject (hs ▸ hh)
    · intro hs
      by_cases hlo : x+y<h
      · have hr : (x+y)%h=x+y := Nat.mod_eq_of_lt hlo
        rw [hr] at hs
        exact reject (mem_filter.mp (mem_inter.mp hs).1).2
      · have hr : (x+y)%h=x+y-h := by
          rw [Nat.mod_eq_sub_mod (by omega), Nat.mod_eq_of_lt (by omega)]
        rw [hr] at hs
        have hhA := (mem_filter.mp (mem_inter.mp hs).2).2.2
        have heq : h+(x+y-h)=x+y := by omega
        rw [heq] at hhA
        exact reject hhA

theorem local_collisions_subset {A : Finset ℕ} {N h : ℕ}
    (ha : NoTriangleAt A h) : collisions h (Bset A N h) ⊆ Eset A N h := by
  intro r hr
  obtain ⟨hl,hu⟩ := mem_inter.mp hr
  obtain ⟨⟨x,y⟩,hxy,heq⟩ := mem_image.mp hl
  obtain ⟨hmem,hne,hs⟩ := mem_filter.mp hxy
  obtain ⟨hx,hy⟩ := mem_product.mp hmem
  have hxi := mem_Ico.mp (mem_filter.mp (mem_inter.mp hx).1).1
  have hyi := mem_Ico.mp (mem_filter.mp (mem_inter.mp hy).1).1
  have hxA := (mem_filter.mp (mem_inter.mp hx).1).2
  have hyA := (mem_filter.mp (mem_inter.mp hy).1).2
  have hxh : x+h∈A := by simpa [Nat.add_comm] using (mem_filter.mp (mem_inter.mp hx).2).2.2
  have hyh : y+h∈A := by simpa [Nat.add_comm] using (mem_filter.mp (mem_inter.mp hy).2).2.2
  apply mem_sdiff.mpr
  refine ⟨mem_Ico.mpr ⟨by omega,by omega⟩,?_⟩
  intro hun
  rcases mem_union.mp hun with hX|hY
  · have hrA := (mem_filter.mp hX).2
    have hsA : x+y∈A := by simpa only [heq] using hrA
    exact ha x hxA y hyA hne (by omega) (by omega) hsA hxh hyh
  · obtain ⟨⟨u,v⟩,huv,hre⟩ := mem_image.mp hu
    obtain ⟨hm,hne',hgt⟩ := mem_filter.mp huv
    obtain ⟨hu',hv'⟩ := mem_product.mp hm
    have hui := mem_Ico.mp (mem_filter.mp (mem_inter.mp hu').1).1
    have hvi := mem_Ico.mp (mem_filter.mp (mem_inter.mp hv').1).1
    have huA := (mem_filter.mp (mem_inter.mp hu').1).2
    have hvA := (mem_filter.mp (mem_inter.mp hv').1).2
    have huh : u+h∈A := by simpa [Nat.add_comm] using (mem_filter.mp (mem_inter.mp hu').2).2.2
    have hvh : v+h∈A := by simpa [Nat.add_comm] using (mem_filter.mp (mem_inter.mp hv').2).2.2
    have hrA := (mem_filter.mp hY).2.2
    have he : h+r=u+v := by omega
    rw [he] at hrA
    exact ha u huA v hvA hne' (by omega) (by omega) hrA huh hvh

/-- Accepted paper (24), derived from a local exclusion, not global triangle-freeness. -/
theorem local_folding {A : Finset ℕ} {N h : ℕ}
    (ha : NoTriangleAt A h) (hh : h∈A) (hh2 : 2≤h) :
    4*((Xset A h).card+(Yset A N h).card)+
      4*(Eset A N h \ collisions h (Bset A N h)).card ≤ 5*h+4 := by
  have hf := folded_additive hh2 (local_foldedOK ha hh (N:=N))
  have hc := card_sdiff_add_card_eq_card (local_collisions_subset ha (N:=N))
  have hi := card_XY_E A N h
  omega

#print axioms local_foldedOK
#print axioms local_collisions_subset
#print axioms local_folding
end OP02.SharpK6

import PositiveOdd
open Finset
namespace OP02.PositivePivot
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess

theorem middle_partition (n:ℕ) (B:Finset ℕ) :
    (middle n B).card=(parityMiddle n B 0).card+(parityMiddle n B 1).card := by
  apply partition_card
  · intro x
    simp only [parityMiddle,mem_filter]
    constructor
    · intro hx
      by_cases h:x%2=0
      · exact Or.inl ⟨hx,h⟩
      · exact Or.inr ⟨hx,by omega⟩
    · rintro (⟨h,_⟩|⟨h,_⟩) <;> exact h
  · intro x hx hy
    have h0:=(mem_filter.mp hx).2
    have h1:=(mem_filter.mp hy).2
    omega

theorem excess_partition (n:ℕ) (B:Finset ℕ) :
    (excessHoles n B).card=(H0 n B).card+(H2 n B).card+(Ho n B).card := by
  let E:=(excessHoles n B).filter (fun x=>x%2=0)
  have hp:(excessHoles n B).card=E.card+(Ho n B).card := by
    apply partition_card
    · intro x
      simp only [E,Ho,mem_filter]
      constructor
      · intro hx
        by_cases h:x%2=0
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨h,_⟩|⟨h,_⟩) <;> exact h
    · intro x hx hy
      have h0:=(mem_filter.mp hx).2
      have h1:=(mem_filter.mp hy).2
      omega
  have he:E.card=(H0 n B).card+(H2 n B).card := by
    apply partition_card
    · intro x
      simp only [E,H0,H2,mem_filter]
      constructor
      · rintro ⟨hx,hr⟩
        by_cases h:x%4=0
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨h,hr⟩|⟨h,hr⟩) <;> exact ⟨h,by omega⟩
    · intro x hx hy
      have h0:=(mem_filter.mp hx).2
      have h1:=(mem_filter.mp hy).2
      omega
  omega

theorem holes_partition (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    (holes n B).card=(middle n B).card+(excessHoles n B).card := by
  have hs:(middle n B).image (fun x=>2*x)⊆holes n B := by
    intro x hx
    obtain ⟨y,hy,rfl⟩:=mem_image.mp hx
    have hr:=mem_Icc.mp (mem_inter.mp hy).2
    exact mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hd y (mem_inter.mp hy).1⟩
  have hc:=card_sdiff_add_card_eq_card hs
  have hi:Function.Injective (fun x:ℕ=>2*x):=by intro x y h;dsimp only at h;omega
  rw [card_image_of_injective _ hi] at hc
  change (excessHoles n B).card+(middle n B).card=(holes n B).card at hc
  omega

theorem cross_missing_count {n r v:ℕ} {B:Finset ℕ} (hr:r<2)
    (hv:v∈middle n B) (hvr:v%2≠r) :
    ((parityMiddle n B r).filter (fun z=>v+z∉B)).card≤(Ho n B).card := by
  let S:=(parityMiddle n B r).filter (fun z=>v+z∉B)
  have hi:Set.InjOn (fun z=>v+z) S:=by intro x hx y hy h;dsimp only at h;omega
  have hs:S.image (fun z=>v+z)⊆Ho n B := by
    intro x hx
    obtain ⟨z,hz,rfl⟩:=mem_image.mp hx
    obtain ⟨hzP,hznot⟩:=mem_filter.mp hz
    obtain ⟨hzM,hzr⟩:=mem_filter.mp hzP
    have hvi:=mem_Icc.mp (mem_inter.mp hv).2
    have hzi:=mem_Icc.mp (mem_inter.mp hzM).2
    have hp:(v+z)%2=1:=by omega
    refine mem_filter.mpr ⟨?_,hp⟩
    rcases missing_split (n:=n) (by omega) hznot with hh|hh
    · obtain ⟨w,hw,he⟩:=hh
      omega
    · exact hh
  have hc:=card_le_card hs
  rw [card_image_of_injOn hi] at hc
  exact hc

/-- An actual edge leaves an edgeless subset of the opposite parity, omitting at most2Ho. -/
theorem edge_clean_subset {n r x y:ℕ} {B:Finset ℕ} (hr:r<2)
    (hf:FourFree B) (hx:x∈middle n B) (hy:y∈middle n B)
    (hxr:x%2≠r) (hyr:y%2≠r) (hxy:x≠y) (hedge:x+y∈B) :
    ∃P:Finset ℕ,P⊆parityMiddle n B r ∧ NoEdge B P ∧
      ((parityMiddle n B r)\P).card≤2*(Ho n B).card := by
  let Q:=parityMiddle n B r
  let P:=Q.filter (fun z=>x+z∈B ∧ y+z∈B)
  have hP:P⊆Q:=filter_subset _ _
  refine ⟨P,hP,?_,?_⟩
  · intro z hz w hw hzw hsum
    obtain ⟨hzQ,hxz,hyz⟩:=mem_filter.mp hz
    obtain ⟨hwQ,hxw,hyw⟩:=mem_filter.mp hw
    have hzM:=(mem_filter.mp hzQ).1
    have hwM:=(mem_filter.mp hwQ).1
    have hzp:=(mem_filter.mp hzQ).2
    have hwp:=(mem_filter.mp hwQ).2
    exact four_forbidden B hf (mem_inter.mp hx).1 (mem_inter.mp hy).1
      (mem_inter.mp hzM).1 (mem_inter.mp hwM).1 hxy (by omega) (by omega)
      (by omega) (by omega) hzw hedge hxz hxw hyz hyw hsum
  · have hs:Q\P⊆Q.filter (fun z=>x+z∉B)∪Q.filter (fun z=>y+z∉B) := by
      intro z hz
      obtain ⟨hzQ,hzP⟩:=mem_sdiff.mp hz
      by_cases h:x+z∈B
      · exact mem_union_right _ (mem_filter.mpr ⟨hzQ,by intro h';exact hzP (mem_filter.mpr ⟨hzQ,h,h'⟩)⟩)
      · exact mem_union_left _ (mem_filter.mpr ⟨hzQ,h⟩)
    have hc:=(card_le_card hs).trans (card_union_le _ _)
    have h1:=cross_missing_count hr hx hxr
    have h2:=cross_missing_count hr hy hyr
    change (Q.filter (fun z=>x+z∉B)).card≤_ at h1
    change (Q.filter (fun z=>y+z∉B)).card≤_ at h2
    change (Q\P).card≤2*(Ho n B).card
    omega

theorem one_side_edgeless (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (hn:44*(deficit n B+(excessHoles n B).card)+12<n) :
    NoEdge B (parityMiddle n B 0) ∨ NoEdge B (parityMiddle n B 1) := by
  by_contra hh
  have he:¬NoEdge B (parityMiddle n B 0):=fun h=>hh (Or.inl h)
  have ho:¬NoEdge B (parityMiddle n B 1):=fun h=>hh (Or.inr h)
  obtain ⟨x,hx,y,hy,hxy,hxs⟩ : ∃x∈parityMiddle n B 0,∃y∈parityMiddle n B 0,x≠y ∧ x+y∈B := by
    simpa [NoEdge,not_forall] using he
  obtain ⟨z,hz,w,hw,hzw,hzs⟩ : ∃z∈parityMiddle n B 1,∃w∈parityMiddle n B 1,z≠w ∧ z+w∈B := by
    simpa [NoEdge,not_forall] using ho
  obtain ⟨PE,hPE,hNE,hDE⟩:=edge_clean_subset (r:=0) (by omega) hc.2.2.1
    (mem_filter.mp hz).1 (mem_filter.mp hw).1 (by have :=(mem_filter.mp hz).2;omega)
    (by have :=(mem_filter.mp hw).2;omega) hzw hzs
  obtain ⟨PO,hPO,hNO,hDO⟩:=edge_clean_subset (r:=1) (by omega) hc.2.2.1
    (mem_filter.mp hx).1 (mem_filter.mp hy).1 (by have :=(mem_filter.mp hx).2;omega)
    (by have :=(mem_filter.mp hy).2;omega) hxy hxs
  have hE:=actual_even_subset n B PE hc.2.2.2.1 hPE hNE
  have hO:=actual_odd_subset n B PO hc.2.2.2.1 hPO hNO
  have hRE:=card_sdiff_add_card_eq_card hPE
  have hRO:=card_sdiff_add_card_eq_card hPO
  have hholes:=hc.2.2.2.2.1
  have hhp:=holes_partition n B hc.2.2.2.1
  have hmp:=middle_partition n B
  have hep:=excess_partition n B
  omega

#print axioms holes_partition
#print axioms excess_partition
#print axioms edge_clean_subset
#print axioms one_side_edgeless
end OP02.PositivePivot

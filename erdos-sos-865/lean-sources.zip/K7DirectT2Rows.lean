import K7DirectPairHalf
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask
set_option maxHeartbeats 1400000

/-- A single conditional exclusion for the two-odd rows whose even offsets
(including zero) are homogeneous or have a singleton residue class.
The high odd vertex connects to the two actual small anchors. -/
theorem unbalanced_two_odds (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ)→
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→
    ∀p x:ℕ,p<x→p%2=1→x%2=1→p%4≠x%4→ oddOffsets S={p,x}→
    (evenZero S ∨ ∃f, f≤n/4 ∧ f%2=0 ∧
      ∀v∈insert 0 S,v%2=0→v≠f→v%4≠f%4)→False:=by
  classical
  obtain ⟨U,hU⟩:=inventory_uniform β hb
  obtain ⟨V,hV⟩:=uniform_window_threshold β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  obtain ⟨G,hG⟩:=uniform_favorable_band hD hb
  refine ⟨max (4*2^23) (max U (max V (max W G))),?_⟩
  intro n hn B hf hd hg S hs p x px po xo opp oddset profile
  have sp:p∈S:=(mem_filter.mp (show p∈oddOffsets S by simp [oddset])).1
  have sx:x∈S:=(mem_filter.mp (show x∈oddOffsets S by simp [oddset])).1
  let s:=S.max' ⟨x,sx⟩
  have sm:s∈S:=max'_mem _ _
  have bounds (v:ℕ) (hv:v∈S) : v≤ s ∧ v≤n/4 := ⟨le_max' _ _ hv,(mem_Icc.mp (mem_inter.mp (hs.2.1 hv)).2).2⟩
  have sHi:= (bounds s sm).2
  have xs:=(bounds x sx).1
  have pairCap:=(mem_Icc.mp (mem_inter.mp (hs.2.2 p sp s sm (by omega))).2).2
  let E:=insert 0 (S \ {p,x})
  have sub:({p,x}:Finset ℕ)⊆S:=by intro v hv;simp only [mem_insert,mem_singleton] at hv;rcases hv with rfl|rfl <;> assumption
  have two:({p,x}:Finset ℕ).card=2:=card_pair (by omega)
  have diff:=card_sdiff_add_card_eq_card sub
  have four:E.card≤4:=by have h:=card_insert_le 0 (S\{p,x});have :=hs.1;change (insert 0 (S \ {p,x})).card≤4;omega
  have ev (v:ℕ) (hv:v∈E) : v%2=0 ∧ v≤ s:=by
    rcases mem_insert.mp hv with rfl|hs'
    · omega
    obtain ⟨vs,out⟩:=mem_sdiff.mp hs'
    have ve:v%2=0:=by
      by_contra no
      have hov:v∈oddOffsets S:=mem_filter.mpr ⟨vs,by omega⟩
      exact out (oddset ▸ hov)
    exact ⟨ve,(bounds v vs).1⟩
  obtain ⟨cap,large⟩:=hU n (by omega) B hd hg
  obtain ⟨_,hl⟩:=hV n (by omega)
  have gap:=hW n (by omega) B hf hd hg
  obtain ⟨a,c,b,z,ap,ac,cb,bz,zlo,zu,width,ra,rc,rb,rz,rac,rba,rbc,rza,rzc,rzb⟩:=
    actual_bridge_quartet hd hg (by omega) hl sHi (show 4*(p/2)≤n/4 by omega) cap
      (η:=40*chainDeficit n B+32*totalBudget n B+64) (Or.inl (le_refl _))
  obtain ⟨y,w,yl,yu,yo,wl,wu,wo,we,wxb,slot,slotHi,direct,high⟩:=
    pair_half_selection hd (by omega) po xo opp px xs sHi ac cb bz (by omega) four ev width
  have wB:w∈B:=by simpa using high 0 (mem_insert_self _ _)
  have wS:w∉S:=fun hi=>by have :=(bounds w hi).2;omega
  have old:internalOn B S:=⟨fun _ h=>(mem_inter.mp (hs.2.1 h)).1,
    fun u hu v hv ne=>(mem_inter.mp (hs.2.2 u hu v hv ne)).1⟩
  have bad:2*(y+4*z)∉B:=by
    intro double
    have six:=append_clique old wB (show ∀v∈S,w+v∈B from by
      intro v hv
      by_cases v₁:v=p
      · subst v;rwa [we]
      by_cases v₂:v=x
      · subst v;exact wxb
      exact high v (mem_insert_of_mem (mem_sdiff.mpr ⟨hv,by simp [v₁,v₂]⟩)))
    have sz:(insert w S).card=6:=by simp [card_insert_of_notMem wS,hs.1]
    have limit (v:ℕ) (hv:v∈insert w S):v≤n:=by
      rcases mem_insert.mp hv with rfl|h
      · omega
      · have :=(bounds v h).2;omega
    rcases profile with allzero|⟨f,fH,fe,pivot⟩
    · apply pv_six hf hd gap large (by omega) six sz limit
      intro v hv ve;rcases mem_insert.mp hv with rfl|h
      · omega
      · have :=(bounds v h).2;exact ⟨allzero _ h ve,by omega⟩
    · apply hG n (by omega) B hf hd hg _ six sz limit f (by omega)
      intro v hv oe ne
      have vE:v%2=0:=by omega
      have oldmem:v∈insert 0 S:=by
        rcases mem_insert.mp hv with rfl|vx
        · exact mem_insert_self _ _
        · rcases mem_insert.mp vx with rfl|h
          · omega
          · exact mem_insert_of_mem h
      refine ⟨pivot _ oldmem vE ne,?_⟩
      rcases mem_insert.mp oldmem with rfl|h
      · omega
      · exact (bounds v h).2
  have yes:y+4*z∈B:=by
    by_contra absent
    exact slot (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,slotHi,absent,bad⟩)
  apply selected_common_half_impossible hf hd gap large cap ac cb bz (by omega) yu yo
    ra rc rb rz rac rba rbc rza rzc rzb (by simpa using direct 0 (by simp))
  intro v hv;simp only [mem_insert,mem_singleton] at hv
  rcases hv with rfl|rfl|rfl|rfl <;> first | exact yes | exact direct _ (by simp)

theorem direct_T2_rows (hD:Dousse7) {i:ℕ} (hi:i=4 ∨ i=6 ∨ i=7 ∨ i=10) : RowExclusion i := by
  classical
  intro β hb
  obtain ⟨U,hU⟩:=unbalanced_two_odds hD hb
  refine ⟨U,?_⟩;intro n hn B sub hf hd hg S hs row
  have state:(oddOffsets S).card=2 ∧ ¬sameOdd S ∧
      ((twoOffsets S).card=0 ∨ (twoOffsets S).card=1 ∨ 2<(twoOffsets S).card):=by
    unfold rowNumber at row;dsimp only at row
    split_ifs at row <;> first | omega | exact ⟨by omega,by assumption,by omega⟩
  obtain ⟨x,y,ne,oddset⟩:=card_eq_two.mp state.1
  have xy:∀v∈({x,y}:Finset ℕ),v∈S ∧ v%2=1:=by
    intro v hv;exact mem_filter.mp (oddset.symm ▸ hv : v∈oddOffsets S)
  have xx:=xy x (by simp);have yy:=xy y (by simp)
  have op:x%4≠y%4:=by
    intro eq;apply state.2.1;refine ⟨x%4,by omega,by omega,?_⟩
    intro v hv vo;have hh: v∈oddOffsets S:=mem_filter.mpr ⟨hv,vo⟩
    simp only [oddset,mem_insert,mem_singleton] at hh;omega
  have profile:evenZero S ∨ ∃f,f≤n/4 ∧ f%2=0 ∧ ∀v∈insert 0 S,v%2=0→v≠f→v%4≠f%4:=by
    rcases state.2.2 with zero|one|three
    · left;intro v hv ve;by_contra nv
      have mem:v∈twoOffsets S:=mem_filter.mpr ⟨hv,by omega⟩
      have :=card_pos.mpr ⟨v,mem⟩;omega
    · right;obtain ⟨f,eq⟩:=card_eq_one.mp one
      have fT:f∈twoOffsets S:=by simp [eq]
      obtain ⟨fs,fr⟩:=mem_filter.mp fT
      refine ⟨f,(mem_Icc.mp (mem_inter.mp (hs.2.1 fs)).2).2,by omega,?_⟩
      intro v hv ve ne;rcases mem_insert.mp hv with rfl|vs
      · omega
      · intro same
        have vv:v∈twoOffsets S:=mem_filter.mpr ⟨vs,by omega⟩
        exact ne (mem_singleton.mp (eq ▸ vv))
    · right;refine ⟨0,Nat.zero_le _,rfl,?_⟩
      have subset:twoOffsets S⊆S\oddOffsets S:=by
        intro v hv;obtain ⟨vs,vr⟩:=mem_filter.mp hv
        exact mem_sdiff.mpr ⟨vs,by intro oo;have :=(mem_filter.mp oo).2;omega⟩
      have part:=card_sdiff_add_card_eq_card (filter_subset _ _ : oddOffsets S⊆S)
      change (S\oddOffsets S).card+(oddOffsets S).card=S.card at part
      have two: (oddOffsets S).card=2:=state.1
      have equ:twoOffsets S=S\oddOffsets S:=eq_of_subset_of_card_le subset (by have :=hs.1;omega)
      intro v hv ve vn;rcases mem_insert.mp hv with eq|vs
      · exact (vn eq).elim
      · have vT:v∈twoOffsets S:=by rw [equ];exact mem_sdiff.mpr ⟨vs,by intro ho;have :=(mem_filter.mp ho).2;omega⟩
        have :=(mem_filter.mp vT).2;omega
  rcases lt_or_gt_of_ne ne with lt|gt
  · exact hU n hn B hf hd hg S hs x y lt xx.2 yy.2 op oddset profile
  · exact hU n hn B hf hd hg S hs y x gt yy.2 xx.2 op.symm (by rwa [Finset.pair_comm]) profile
end OP02.SharpK7.LongOddTask

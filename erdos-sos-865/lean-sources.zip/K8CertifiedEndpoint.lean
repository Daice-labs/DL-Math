import K8FixedFourShort
import K8UpperComplete
import K8Assembly
import K8Exact

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8

/-- Under the actual signed gap, one choice of size threshold supplies all fifteen
root sums independently of a subsequent internal seven. -/
theorem root_supply_of_dousse5 (h5 : Dousse5) : RootSupply := by
  intro β hb
  obtain ⟨U,hU⟩ := signed_short_five h5 hb
  obtain ⟨V,hV⟩ := signed_upper_from_short hb
  refine ⟨max U V,?_⟩
  intro n hn B _sub hd gap
  exact hV n (by omega) B hd gap (hU n (by omega) B hd gap)

/-- Every actual internal seven, with zero admitted as an offset, forces an eight
in the same normalized physical set. The root supply requires only order five. -/
theorem all_profile_seven_to_eight (h5 : Dousse5) : AllProfileLift :=
  lift_of_root_supply (root_supply_of_dousse5 h5)

theorem normalizedK8_of_dousse8 (h8 : Dousse8) : NormalizedK8Goal :=
  normalized_of_lift h8 (all_profile_seven_to_eight (dousse5_of_dousse8 h8))

/-- Sharp order-eight limit for the original Erdős threshold under the explicit
eight-point midpoint theorem. -/
theorem sharpK8_of_dousse8 : Dousse8 → SharpK8Limit :=
  fun h8 => limit_of_normalized h8 (normalizedK8_of_dousse8 h8)

end OP02.SharpK8

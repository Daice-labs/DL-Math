import K8UpperTriangleShapes
import K8SupplyInterfaces

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7
namespace OP02.SharpK8

theorem central_band_odd_cost {H : ℕ} {D : Finset ℕ} (hD : D⊆Icc 1 H) (hd : DoublingFree D) :
    (bandOddHoles (H/4) D).card≤chainCapacity H-D.card := by
  have sub : bandOddHoles (H/4) D⊆topMissing (H/4) D := by
    intro x hx
    obtain ⟨hi,hodd,ha⟩ := mem_filter.mp hx
    obtain ⟨hl,hu⟩ := mem_Ioc.mp hi
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hu⟩,canonical_odd _ hodd⟩,by omega,ha⟩
  exact (card_le_card sub).trans (band_canonical_holes_le H 1 D hD hd)

theorem central_four_pair {H g : ℕ} {D : Finset ℕ}
    (hscale : 1000000000≤H) (hD : D⊆Icc 1 H) (hd : DoublingFree D)
    (hκ : 1536*(chainCapacity H-D.card)<H)
    (g4 : g%4=0) (gl : 260*H≤1024*g) (gu : 1024*g≤412*H) :
    ∃ x y : ℕ, x∈D ∧ y∈D ∧ x%4=1 ∧ y%4=3 ∧ x+y=g ∧
      H/4/2<x ∧ x≤H/4-4*(3*(H/256)+1) ∧
      H/4/2<y ∧ y≤H/4-4*(3*(H/256)+1) := by
  classical
  let J := H/4
  let C := J-4*(3*(H/256)+1)
  let L := max (J/2) (g-C)
  let U := min C (g-J/2-1)
  let P := progression L U 4 1
  let O := bandOddHoles J D
  have data {x : ℕ} (hx : x∈P) : x%4=1 ∧ (g-x)%4=3 ∧ x+(g-x)=g ∧
      J/2<x ∧ x≤C ∧ J/2<g-x ∧ g-x≤C := by
    obtain ⟨hi,hres⟩ := mem_filter.mp hx
    obtain ⟨lo,up⟩ := mem_Ioc.mp hi
    dsimp only [U,L] at lo up
    omega
  have miss {v} (lo : J/2<v) (up : v≤C) (odd : v%2=1) (habs : v∉D) : v∈O := by
    dsimp only [C] at up
    exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨lo,by omega⟩,odd,habs⟩
  have cost := central_band_odd_cost hD hd
  change O.card ≤ _ at cost
  have ntrial := progression_lower L U 4 1 (by decide) (by decide)
  change (U-L)/4≤P.card at ntrial
  dsimp [U,L,C,J] at ntrial
  by_contra! bad
  let inv := fun y : ℕ => if y%4=1 then y else g-y
  have cov : P⊆O.image inv := by
    intro x hx
    obtain ⟨xr,yr,hxy,xlo,xup,ylo,yup⟩ := data hx
    by_cases xD : x∈D
    · have yD : g-x∉D := by intro h;exact (not_lt_of_ge yup) (bad x (g-x) xD h xr yr hxy xlo xup ylo)
      exact mem_image.mpr ⟨g-x,miss ylo yup (by omega) yD,by dsimp [inv]; split_ifs <;> omega⟩
    · exact mem_image.mpr ⟨x,miss xlo xup (by omega) xD,by simp [inv,xr]⟩
  have cnt : P.card ≤ O.card := (card_le_card cov).trans card_image_le
  omega

/-- All large indices are retained unconditionally. A failed index has a unique
inverse in its odd residue class across both translated lists. -/
theorem central_four_pair_and_triangle {H g : ℕ} {D : Finset ℕ}
    (hscale : 1000000000≤H) (hD : D⊆Icc 1 H) (hd : DoublingFree D)
    (hκ : 1536*(chainCapacity H-D.card)<H) (supply : CentralTriangleSupply H D)
    (hg : g∈D) (g4 : g%4=0) (gl : 260*H≤1024*g) (gu : 1024*g≤412*H) :
    ∃ x y a c b : ℕ, x%4=1 ∧ y%4=3 ∧ x+y=g ∧ x+y∈D ∧
      H/4/2<x ∧ x≤H/4-4*(3*(H/256)+1) ∧ H/4/2<y ∧ y≤H/4-4*(3*(H/256)+1) ∧
      0<a ∧ a<c ∧ c<b ∧ b≤3*(H/256)+1 ∧
      a∈quarterD (H/16) D ∧ c∈quarterD (H/16) D ∧ b∈quarterD (H/16) D ∧
      a+c∈quarterD (H/16) D ∧ b+a∈quarterD (H/16) D ∧ b+c∈quarterD (H/16) D ∧
      UpperTriangleShape a c b ∧
      ∀ f∈({0,a,c,b}:Finset ℕ), x+4*f∈D ∧ y+4*f∈D := by
  classical
  obtain ⟨x,y,xD,yD,xr,yr,eq,xlo,xup,ylo,yup⟩ := central_four_pair hscale hD hd hκ g4 gl gu
  let t := 3*(H/256)+1
  let Z := quarterD (H/16) D
  let W := (Icc 1 t).filter (fun i => x+4*i∉D ∨ y+4*i∉D)
  let O := bandOddHoles (H/4) D
  let inv := fun v : ℕ => if v%4=1 then (v-x)/4 else (v-y)/4
  have cover : W⊆O.image inv := by
    intro i hi
    obtain ⟨hI,test⟩ := mem_filter.mp hi
    obtain ⟨il,iu⟩ := mem_Icc.mp hI
    dsimp only [t] at iu
    rcases test with h|h
    · apply mem_image.mpr
      exact ⟨x+4*i,mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,h⟩,
        by dsimp [inv];split_ifs <;> omega⟩
    · apply mem_image.mpr
      exact ⟨y+4*i,mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,h⟩,
        by dsimp [inv];split_ifs <;> omega⟩
  have cost : W.card ≤ O.card := (card_le_card cover).trans card_image_le
  have enough := supply W cost
  have sub : Z\W ⊆ Icc 1 (H/64) := by
    intro v hv
    obtain ⟨hv,_⟩ := mem_sdiff.mp hv
    obtain ⟨l,u⟩ := mem_Icc.mp (mem_filter.mp hv).1
    exact mem_Icc.mpr ⟨l,by omega⟩
  have free : DoublingFree (Z\W) := by
    intro i hi hh
    exact quarter_doubling_free (H/16) D hd i (mem_sdiff.mp hi).1 (mem_sdiff.mp hh).1
  obtain ⟨a,c,b,ap,ac,cb,bu,ha,hc,hb,hac,hba,hbc,pat⟩ :=
    upper_triangle_shapes (by omega) sub free enough
  have good {i} (hi : i∈Z\W) (il : 0 < i) (iu : i≤t) :
      x+4*i∈D ∧ y+4*i∈D := by
    by_contra! hn
    exact (mem_sdiff.mp hi).2 (mem_filter.mpr ⟨mem_Icc.mpr ⟨il,iu⟩,by tauto⟩)
  have bv : b≤t := by dsimp [t];omega
  refine ⟨x,y,a,c,b,xr,yr,eq,eq ▸ hg,xlo,xup,ylo,yup,ap,ac,cb,bv,
    (mem_sdiff.mp ha).1,(mem_sdiff.mp hc).1,(mem_sdiff.mp hb).1,
    (mem_sdiff.mp hac).1,(mem_sdiff.mp hba).1,(mem_sdiff.mp hbc).1,pat,?_⟩
  intro f hf
  simp only [mem_insert,mem_singleton] at hf
  rcases hf with rfl|rfl|rfl|rfl
  · simpa using And.intro xD yD
  · exact good ha ap (by omega)
  · exact good hc (by omega) (by omega)
  · exact good hb (by omega) bv

end OP02.SharpK8

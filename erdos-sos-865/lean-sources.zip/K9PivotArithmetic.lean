import K9Spec

namespace OP02.SharpK9

theorem pivot_width {h w₁ w₂ z u σ : ℕ}
    (large : 100000≤h) (loss : 6*σ<h/64) (ws : 4*(w₁+w₂)≤h/4)
    (zs : 4*z≤3*(h/4)) (delay : h/4+32*σ+60<2*z) (ub : 2*u≤h/4) :
    max (2*(h/4)+2) (h/4+4+2*z-u)+32*σ+8 ≤ min (3*(h/4)) (2*(h/4)+2*z-2*w₂-u) := by
  let l := h/4
  have low : 32*σ+80≤l/2 := by dsimp only [l]; omega
  have w : 4*w₂≤l := by dsimp only [l];omega
  change max (2*l+2) (l+4+2*z-u)+32*σ+8 ≤ min (3*l) (2*l+2*z-2*w₂-u)
  change 2*u≤l at ub
  change l+32*σ+60<2*z at delay
  change 4*z≤3*l at zs
  simp only [Nat.max_def, Nat.min_def]
  split_ifs <;> omega

theorem pivot_shift8 {p c r : ℕ} (pr : p%8=r) (good : (r+c)%8=4) : (p+c)%8=4 := by
  calc
    (p+c)%8 = (p%8+c)%8 := by omega
    _ = 4 := by rw [pr]; exact good

theorem pivot_target_phase {p c u : ℕ} (pm : (p+c)%8=4) (same : u%2=c%2)
    (other : u%4≠c%4) : (p+u)%4=2 := by omega

theorem pivot_non_target {p c u s : ℕ} (pm : (p+c)%8=4) (pu : (p+u)%4=2)
    (sc : s%4≠c%4) (su : s%4≠u%4) : (p+s)%2=1 := by omega

theorem pivot_mid_bounds {h p u w z : ℕ}
    (a : 2*(h/4)+2<p) (b : h/4+4+2*z-u<p)
    (c : p≤3*(h/4)) (d : p≤2*(h/4)+2*z-2*w-u)
    (phase : (p+u)%4=2) (even : z%2=0) :
    h<2*p ∧ 4*p≤3*h ∧ ((p+u)/2-z)+z=(p+u)/2 ∧
    h/4/2+2<(p+u)/2-z ∧ ((p+u)/2-z)+w≤h/4 ∧ ((p+u)/2-z)%2=1 := by
  have dpos : p>0 := by omega
  exact ⟨by omega,by omega,by omega,by omega,by omega,by omega⟩

theorem pivot_room {L V σ nX : ℕ} (span : L + 32*σ + 8 ≤ V) (raw : (V - L) / 8 ≤ nX) :
    4 * σ < nX := by omega

theorem pivot_mod4 {p r : ℕ} (phase : p%8=r) : p%4=r%4 := by omega

theorem pivot_control_residue {p c s : ℕ} (pc : (p+c)%8=4) (ps : (p+s)%8=4) :
    s%4=c%4 := by omega

theorem pivot_reflect_inj {p q u z a b : ℕ} (x : a+z=(p+u)/2) (y : b+z=(q+u)/2)
    (px : (p+u)%4=2) (qx : (q+u)%4=2) (eq : a=b) : p=q := by omega

theorem pivot_lower_phase {v w : ℕ} (odd : v%2=1) (even : w%2=0) :
    (4*(v+w))%8=4 := by omega

theorem pivot_test_band {p s h : ℕ} (lo : h<2*p) (hi : 4*p≤3*h) (small : s≤h/4) :
    h/2<p+s ∧ p+s≤h := by omega

theorem pivot_low_offset {h v w w₂ : ℕ} (lo : h/4/2+2<v) (hi : v+w₂≤h/4)
    (wb : w≤w₂) (odd : v%2=1) (even : w%2=0) :
    h/4/2+2<v+w ∧ v+w≤h/4 ∧ (v+w)%2=1 := by omega

end OP02.SharpK9

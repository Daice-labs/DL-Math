import K6MiddleGapComplete
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 4000000

/-- Arbitrary root triangles, including the formerly bad residue pattern,
are excluded in actual odd common neighborhoods once the middle gap is derived. -/
theorem gap_triangle_neighborhood (n u v:ℕ) (B T:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hg:MiddleGap6 n B)
    (hn:65536≤n) (hq:384*totalBudget n B≤n)
    (hu:u∈B) (hv:v∈B) (huv:u≠v) (huo:u%2=1) (hvo:v%2=1)
    (huH:4*u≤7*n) (hvH:4*v≤7*n) (hsum:u+v∈B)
    (hT:T⊆quarterD n B) (hTc:T.card=3)
    (hTK:∀t∈T,t≤n/16)
    (hpair:∀x∈T,∀y∈T,x≠y → x+y∈quarterD n B)
    (hqual:∀x∈T,u+4*x∈B ∧ v+4*x∈B) : False := by
  classical
  let S:=insert u (insert v (T.image (fun t=>4*t)))
  let Q:=insert 0 T
  have hcl:=qualified_triangle_explicit_clique n u v B T hu hv huv huo hvo hsum hT hTc hpair hqual
  change S⊆B ∧ S.card=5 ∧ _ at hcl
  let δ:=(missingTopOdd n B).card
  let q:=totalBudget n B
  let τ:=4*δ+4
  let L:=2*n+2*τ
  let U:=L+4*(4*q+1)
  let Y:=progression L U 4 0
  let H:=fourResources n B ∪ Ho n B
  have hδ:=deficit_split n B hd
  have hδq:δ≤q:=by dsimp [δ,q]; unfold totalBudget; omega
  have hH:H.card≤q:=by
    have:=card_union_le (fourResources n B) (Ho n B)
    have:=four_resource_budget n B hd
    dsimp [H,q]; omega
  have hQc:Q.card≤4:=by dsimp only [Q]; have:=card_insert_le 0 T; omega
  have hmem (s:ℕ) (hs:s∈insert 0 S):s=u ∨ s=v ∨ ∃t∈Q,s=4*t := by
    rcases mem_insert.mp hs with rfl|hs
    · exact Or.inr (Or.inr ⟨0,by simp [Q],by omega⟩)
    · rcases mem_insert.mp hs with rfl|hs
      · exact Or.inl rfl
      · rcases mem_insert.mp hs with rfl|hs
        · exact Or.inr (Or.inl rfl)
        · obtain ⟨t,ht,rfl⟩:=mem_image.mp hs
          exact Or.inr (Or.inr ⟨t,mem_insert_of_mem ht,rfl⟩)
  have hQK:∀t∈Q,t≤n/16:=by
    intro t ht
    rcases mem_insert.mp ht with rfl|ht
    · omega
    · exact hTK t ht
  have hY (p:ℕ) (hp:p∈Y):2*n+2*τ<p ∧ p≤2*n+24*q+12 ∧ p%4=0 := by
    obtain ⟨hpI,hpr⟩:=mem_filter.mp hp
    have hh:=mem_Ioc.mp hpI
    dsimp only [L,U,τ] at hh ⊢
    omega
  have hload:∀j:ℕ,((insert 0 S).filter (fun s=>s%4=j)).card≤4 := by
    intro j
    by_cases hj:j%2=0
    · have hsub:((insert 0 S).filter (fun s=>s%4=j))⊆Q.image (fun t=>4*t) := by
        intro s hs
        obtain ⟨hs,hjr⟩:=mem_filter.mp hs
        rcases hmem s hs with rfl|rfl|⟨t,ht,rfl⟩
        · omega
        · omega
        · exact mem_image.mpr ⟨t,ht,rfl⟩
      exact le_trans (card_le_card hsub) (le_trans card_image_le hQc)
    · have hsub:((insert 0 S).filter (fun s=>s%4=j))⊆{u,v} := by
        intro s hs
        obtain ⟨hs,hjr⟩:=mem_filter.mp hs
        rcases hmem s hs with rfl|rfl|⟨t,ht,rfl⟩
        · simp
        · simp
        · omega
      exact le_trans (card_le_card hsub) (le_trans card_le_two (by omega))
  have hc:Y.card≤4*H.card := by
    apply affine_cover_bound Y (insert 0 S) H 0 0 1 4 (by omega)
    · intro p hp; exact (hY p hp).2.2
    · exact hload
    · intro p hp
      have hpI:=hY p hp
      have hpS:p∉S := by
        intro hs
        rcases hmem p (mem_insert_of_mem hs) with hpu|hpv|⟨t,ht,hpt⟩
        · dsimp [τ] at hpI; omega
        · dsimp [τ] at hpI; omega
        · have:=hQK t ht; dsimp [τ] at hpI; omega
      obtain ⟨s,hs,hbad⟩:=five_clique_missing_label B S hf hcl.1 hcl.2.1 hcl.2.2 p hpS
      refine ⟨s,hs,p+s,?_,by omega⟩
      rcases hmem s hs with rfl|rfl|⟨t,ht,rfl⟩
      · apply mem_union_right
        apply bootstrap_missing_odd n _ B (by omega) (by dsimp [τ] at hpI; omega) _ hbad
        dsimp only [q] at hpI
        omega
      · apply mem_union_right
        apply bootstrap_missing_odd n _ B (by omega) (by dsimp [τ] at hpI; omega) _ hbad
        dsimp only [q] at hpI
        omega
      · have htK:=hQK t ht
        apply mem_union_left
        apply missing_in_doubled_gap6 n (p+4*t) B hg (by omega) hbad
        · dsimp only [τ,δ] at hpI
          omega
        · dsimp only [q,τ,δ] at hpI hδq
          omega
  have hl:=progression_lower L U 4 0 (by simp) (by omega)
  change (U-L)/4≤Y.card at hl
  dsimp only [U] at hl
  omega

#print axioms gap_triangle_neighborhood
end OP02.SharpK6

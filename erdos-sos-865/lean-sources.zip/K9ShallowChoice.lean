import K9ShallowCover
import K9DeepTests
import K9PivotArithmetic

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7 OP02.SharpK8
namespace OP02.SharpK9

private theorem candidate_residue (c : ℕ) : (12-c%8)%8<8 ∧ ((12-c%8)%8+c)%8=4 := by omega

/-- The same upper pivot tests the singleton target and all four companion
offsets. When the target is absent, its occupied half joins three previously
fixed roots. The shared selection charges a shallow terminal at most four times. -/
theorem full_class_choice {h w₁ w₂ z : ℕ} {G T : Finset ℕ}
    (large : 100000≤h) (sub : G⊆Icc 1 h) (hd : DoublingFree G)
    (smallLoss : 6*(shallowFaults h G).card<h/64)
    (seed : Internal 4 (G∩Icc 1 (h/4)) T)
    (full : ∀j<4, ∃x∈insert 0 T, x%4=j)
    (wpos : 0<w₁) (ww : w₁<w₂) (wz : w₂<z)
    (ws : 4*(w₁+w₂)≤h/4) (zs : 4*z≤3*(h/4))
    (delay : h/4+32*(shallowFaults h G).card+60<2*z)
    (we₁ : w₁%2=0) (we₂ : w₂%2=0) (ze : z%2=0) :
    (∃ p, h<2*p ∧ 4*p≤3*h ∧ ∀s∈insert 0 T,p+s∈G) ∨
    (∃ v, v≤h/4 ∧ v%2=1 ∧ v∈G ∧ v+w₁∈G ∧ v+w₂∈G ∧ v+z∈G) := by
  classical
  let l:=h/4
  let A:=shallowFaults h G
  obtain ⟨u,hu,c,hc,ub,ucp,uc,su,sc,loads⟩:=quartet_roles seed full
  let r := (12-c%8)%8
  let L := max (2*l+2) (l+4+2*z-u)
  let V := min (3*l) (2*l+2*z-2*w₂-u)
  let X := progression L V 8 r
  let W : Finset ℕ := {0,w₁,w₂}
  let v := fun p : ℕ => (p+u)/2-z
  have cr : r<8 ∧ (r+c)%8=4 := candidate_residue c
  have length : L+32*A.card+8≤V := pivot_width large smallLoss ws zs delay ub
  have supply : 4*A.card<X.card := by
    have lower:=progression_lower L V 8 r (by decide) cr.1
    change (V-L)/8 ≤ X.card at lower
    exact pivot_room length lower
  have loc (p : ℕ) (hp : p∈X) : L<p ∧ p≤V ∧ p%8=r :=
    ⟨(mem_Ioc.mp (mem_filter.mp hp).1).1,(mem_Ioc.mp (mem_filter.mp hp).1).2,(mem_filter.mp hp).2⟩
  have mid (p : ℕ) (hp : p∈X) : h<2*p ∧ 4*p≤3*h ∧
      (p+u)%4=2 ∧ v p + z=(p+u)/2 ∧ h/4/2+2<v p ∧ v p + w₂≤h/4 ∧ v p%2=1 := by
    obtain ⟨pl,ph,pr⟩:=loc p hp
    have l₁:=lt_of_le_of_lt (le_max_left _ _) pl
    have l₂:=lt_of_le_of_lt (le_max_right _ _) pl
    have h₁:=le_trans ph (min_le_left _ _)
    have h₂:=le_trans ph (min_le_right _ _)
    change 2*(h/4)+2<p at l₁
    change h/4+4+2*z-u<p at l₂
    change p≤3*(h/4) at h₁
    change p≤2*(h/4)+2*z-2*w₂-u at h₂
    have pm : (p+c)%8=4 := pivot_shift8 pr cr.2
    have tgt : (p+u)%4=2 := pivot_target_phase pm ucp uc
    obtain ⟨phlo,phhi,pv,dlo,dhi,vo⟩:=pivot_mid_bounds l₁ l₂ h₁ h₂ tgt ze
    exact ⟨phlo,phhi,tgt,pv,dlo,dhi,vo⟩
  have Wprop (w : ℕ) (hw : w∈W) : w≤w₂ ∧ w%2=0 := by
    simp only [W,mem_insert,mem_singleton] at hw
    rcases hw with rfl|rfl|rfl
    · exact ⟨Nat.zero_le _,rfl⟩
    · exact ⟨Nat.le_of_lt ww,we₁⟩
    · exact ⟨le_rfl,we₂⟩
  have wc : W.card≤3 := by
    have a := card_insert_le 0 ({w₁,w₂}:Finset ℕ)
    have b := card_insert_le w₁ ({w₂}:Finset ℕ)
    simp only [card_singleton] at b
    change (insert 0 ({w₁,w₂}:Finset ℕ)).card≤3
    exact a.trans (Nat.succ_le_succ b)
  have ctrl (p : ℕ) (hp : p∈X) (s : ℕ) (hs : s∈insert 0 T) (pc : (p+s)%8=4) : s=c := by
    have pp := (loc p hp).2.2
    exact sc s hs (pivot_control_residue (pivot_shift8 pp cr.2) pc)
  obtain ⟨p,hp,upper,lower⟩ := shared_shallow_selection (U:=insert 0 T) (W:=W) (A:=A)
    (c:=c) (r:=r%4) (v:=v) (fun p hp => pivot_mod4 (loc p hp).2.2)
    loads ctrl wc (by
      intro p hp w hw
      have ⟨_,even⟩:=Wprop w hw
      have odd:=(mid p hp).2.2.2.2.2.2
      exact pivot_lower_phase odd even) (by
      intro p hp q hq eq
      have ap := mid p hp
      have aq := mid q hq
      change v p=v q at eq
      exact pivot_reflect_inj ap.2.2.2.1 aq.2.2.2.1 ap.2.2.1 aq.2.2.1 eq) supply
  have ⟨lo,hi,tgt,vsym,vlo,vhi,odd⟩ := mid p hp
  have lim (s : ℕ) (hs : s∈insert 0 T) : s≤h/4 := by
    rcases mem_insert.mp hs with rfl|ht
    · exact Nat.zero_le _
    · exact (mem_Icc.mp (mem_inter.mp (seed.1 ht)).2).2
  have band (s : ℕ) (hs : s∈insert 0 T) : h/2<p+s ∧ p+s≤h := by
    exact pivot_test_band lo hi (lim s hs)
  have safe (s : ℕ) (hs : s∈insert 0 T) (neq : s≠u) : p+s∈G := by
    by_contra absent
    have ps := (loc p hp).2.2
    have shape : (p+s)%2=1 ∨ (p+s)%8=4 := by
      by_cases sr : s%4=c%4
      · have eq:=sc s hs sr
        exact Or.inr (eq ▸ pivot_shift8 ps cr.2)
      · have ur : s%4≠u%4 := fun h => neq (su s hs h)
        exact Or.inl (pivot_non_target (pivot_shift8 ps cr.2) tgt sr ur)
    exact upper s hs (shallow_top_fault sub (band s hs).1 (band s hs).2 shape absent)
  by_cases target : p+u∈G
  · left
    exact ⟨p,lo,hi,fun s hs => by by_cases eq : s=u; exact eq ▸ target;exact safe s hs eq⟩
  · right
    have half : (p+u)/2∈G := by
      by_contra fail
      exact upper u hu (shallow_half_fault sub (band u hu).1 (band u hu).2 tgt target fail)
    have pass (w : ℕ) (hw : w∈W) : v p+w∈G := by
      have ⟨wb,we⟩:=Wprop w hw
      by_contra absent
      obtain ⟨low,high,phase⟩:= pivot_low_offset vlo vhi wb odd we
      exact lower w hw (shallow_lower_fault sub hd low high phase absent)
    exact ⟨v p,(Nat.le_add_right _ _).trans vhi,odd,by simpa using (pass 0 (by simp [W])),
      pass w₁ (by simp [W]),pass w₂ (by simp [W]),vsym ▸ half⟩

end OP02.SharpK9

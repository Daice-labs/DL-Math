import K8UpperSixTools
import K8FixedFourPrefix

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7 OP02.PivotAudit
namespace OP02.SharpK8

def CentralFour (H : ℕ) (D : Finset ℕ) : Prop :=
  ∃ g∈D, g%4=0 ∧ 260*H≤1024*g ∧ 1024*g≤412*H

def CentralOdd (H : ℕ) (D : Finset ℕ) : Prop :=
  ∃ g∈D, g%2=1 ∧ 324*H≤1024*g ∧ 1024*g≤348*H

def complementFaults (H : ℕ) (D : Finset ℕ) :=
  unmatchedTop H D ∪ topMissing H (D ∪ unmatchedTop H D)

theorem complement_fault_budget {H : ℕ} {D : Finset ℕ}
    (hD : D⊆Icc 1 H) (hd : DoublingFree D) :
    (complementFaults H D).card ≤ chainCapacity H-D.card := by
  apply augmented_top_budget H D _ hD hd
  intro v hv
  obtain ⟨hI,ha,hprev⟩ := mem_filter.mp hv
  obtain ⟨hl,hu⟩ := mem_Ioc.mp hI
  exact ⟨by omega,hu,ha,hprev⟩

/-- Common physical cover for both complementary windows. The first two roles
are canonical. The other two have no possible occupied middle half. -/
theorem complement_upper_hole {H v : ℕ} {D : Finset ℕ}
    (h4 : ¬CentralFour H D) (hodd : ¬CentralOdd H D)
    (hlo : H < 2*v) (hhi : v≤H) (absent : v∉D)
    (eligible : v%2=1 ∨ v%8=4 ∨
      (v%4=0 ∧ 520*H≤1024*v ∧ 1024*v≤824*H) ∨
      (v%4=2 ∧ 648*H≤1024*v ∧ 1024*v≤696*H)) :
    v∈complementFaults H D := by
  classical
  change v∈unmatchedTop H D ∪ topMissing H (D∪unmatchedTop H D)
  by_cases hu : v∈unmatchedTop H D
  · exact mem_union_left _ hu
  have canonicalHole (hc : canonical v=true) : v∈topMissing H (D∪unmatchedTop H D) := by
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hhi⟩,hc⟩,hlo,
      fun hm => (mem_union.mp hm).elim absent hu⟩
  have noHalf (hh : ∀x∈D, 2*x≠v) : False :=
    hu (mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,hhi⟩,absent,hh⟩)
  apply mem_union_right
  rcases eligible with ho|hc|⟨hdiv,hl,hh⟩|⟨hdiv,hl,hh⟩
  · exact canonicalHole (canonical_odd v ho)
  · exact canonicalHole (canonical_four_residue v hc)
  · by_cases hv : v%8=4
    · exact canonicalHole (canonical_four_residue v hv)
    · exfalso
      apply noHalf
      intro x hx he
      exact h4 ⟨x,hx,by omega,by omega,by omega⟩
  · exfalso
    apply noHalf
    intro x hx he
    exact hodd ⟨x,hx,by omega,by omega,by omega⟩

/-- Every member of each successful trial uses its actual label in D. -/
theorem upper_six_from_trials {H : ℕ} {D F E Y : Finset ℕ} (hF : ShortFive H D F)
    (rangeR : ∀R∈Y, H < 2*R ∧ 4*R≤3*H)
    (cover : ∀R∈Y, ∀s∈insert 0 F, R+s∉D → R+s∈E)
    (enough : 6*E.card < Y.card) : RootSix H D := by
  classical
  have cnt := shift_losses Y (insert 0 F) D E 1 0 6 (by intro x hx; omega) cover (by
    intro z hz
    have hO := card_insert_le 0 F
    have hsize := hF.1.2.1
    exact (card_filter_le _ _).trans (by omega))
  obtain ⟨R,hR⟩ := card_pos.mp (show 0 < (OP02.SharpK7.passes Y (insert 0 F) D).card by omega)
  obtain ⟨hY,hpass⟩ := mem_filter.mp hR
  exact common_short_six hF (rangeR R hY).1 (rangeR R hY).2 hpass

/-- One fixed residue avoids two modulo four for every offset, including zero. -/
theorem complement_empty_class {H a : ℕ} {D F : Finset ℕ}
    (hscale : 4096≤H) (hD : D⊆Icc 1 H) (hd : DoublingFree D)
    (hb : 1536*(chainCapacity H-D.card)<H)
    (h4 : ¬CentralFour H D) (ho : ¬CentralOdd H D) (hF : ShortFive H D F)
    (ha : a<4) (empty : ∀s∈insert 0 F, s%4≠a) : RootSix H D := by
  let r := (6-a)%4
  let Y := progression (522*H/1024) (564*H/1024) 4 r
  have hr : r<4 := Nat.mod_lt _ (by decide)
  have hh {R} (hR : R∈Y) :
      522*H < 1024*R ∧ 1024*R ≤ 564*H ∧ R%4=r := by
    obtain ⟨hI,hres⟩ := mem_filter.mp hR
    obtain ⟨hl,hu⟩ := mem_Ioc.mp hI
    exact ⟨by omega,by omega,hres⟩
  apply upper_six_from_trials (Y:=Y) (E:=complementFaults H D) hF
  · intro R hR; have := hh hR; omega
  · intro R hR s hs hmiss
    have hsize : s≤H/4 := by
      rcases mem_insert.mp hs with rfl|hh
      · omega
      · exact (mem_Icc.mp (mem_inter.mp (hF.1.1 hh)).2).2
    have ⟨hl,hu,hres⟩ := hh hR
    have hsmod := empty s hs
    dsimp [r] at hres
    apply complement_upper_hole h4 ho (by omega) (by omega) hmiss
    by_cases hso : (R+s)%2=1
    · exact Or.inl hso
    · right; right; left
      exact ⟨by omega,by omega,by omega⟩
  · have hc := complement_fault_budget hD hd
    have hcount := progression_lower (522*H/1024) (564*H/1024) 4 r (by decide) hr
    change _ ≤ Y.card at hcount
    omega

end OP02.SharpK8

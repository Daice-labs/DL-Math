import K8CentralFrame
import K8CentralWindows
import K8CentralFourPair

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8

theorem central_four_root_six {H : ℕ} {D : Finset ℕ} (large : 10^9≤H)
    (sub : D ⊆ Icc 1 H) (hd : DoublingFree D) (budget : 1536*(chainCapacity H-D.card)<H)
    (supply : CentralTriangleSupply H D) (central : CentralFour H D) : RootSix H D := by
  classical
  obtain ⟨g,hg,g4,gl,gu⟩ := central
  obtain ⟨x,y,a,c,b,xr,yr,_,sum,xl,xu,yl,yu,_,ac,cb,bu,ha,hc,hb,hac,hba,hbc,shape,cross⟩ :=
    central_four_pair_and_triangle large sub hd budget supply hg g4 gl gu
  obtain ⟨hF,hsmall⟩ := central_five large ac cb bu ha hc hb hac hba hbc xl xu yl yu (by omega) sum cross
  obtain ⟨pat⟩ := triangle_pattern ac shape
  let P := residueCandidates (H/2) (3*H/4) pat.modulus pat.codes
  have bound := chain_capacity_with_top_loss H D sub hd
  have cost : 1536*(topMissing H D).card<H := by omega
  have room : 6*(topMissing H D).card<P.card :=
    (central_pattern_supplies (l:=H/2) (u:=3*H/4) pat large cost).2 (by omega)
  apply early_upper_common hF hsmall _ room
  intro R hR
  obtain ⟨hi,codes⟩ := mem_filter.mp hR
  obtain ⟨rlo,rhi⟩ := mem_Ioc.mp hi
  obtain ⟨r4,_,safe⟩ := pat.safe R codes
  refine ⟨by omega,by omega,?_⟩
  intro f hf
  simp only [centralEarly,mem_insert,mem_singleton] at hf
  rcases hf with rfl|rfl|rfl|rfl|rfl|rfl
  · simpa using safe 0 (by simp)
  · exact canonical_odd _ (by omega)
  · exact canonical_odd _ (by omega)
  · exact safe a (by simp)
  · exact safe c (by simp)
  · exact safe b (by simp)

theorem central_odd_root_six {H : ℕ} {D : Finset ℕ} (large : 10^9≤H)
    (sub : D ⊆ Icc 1 H) (hd : DoublingFree D) (budget : 1536*(chainCapacity H-D.card)<H)
    (supply : CentralTriangleSupply H D) (central : CentralOdd H D) : RootSix H D := by
  classical
  obtain ⟨g,hg,go,gl,gu⟩ := central
  let Z := quarterD (H/16) D
  have zh : (H/16)/4=H/64 := by omega
  have zsub : Z⊆Icc 1 (H/64) := by rw [←zh];exact filter_subset _ _
  have zfree : DoublingFree Z := quarter_doubling_free _ _ hd
  have dense : (5/8:ℝ)*(H/64:ℕ)+(3/4:ℝ)*(Real.log ((H/64:ℕ):ℝ)/Real.log 2)+13/8<Z.card := by
    simpa [Z] using supply ∅ (by simp)
  obtain ⟨a,c,b,_,ac,cb,bu,ha,hc,hb,hac,hba,hbc,shape⟩ :=
    upper_triangle_shapes (show 0<H/64 by omega) zsub zfree dense
  have div : H/64/4=H/256 := by omega
  rw [div] at bu
  obtain ⟨pat⟩ := triangle_pattern ac shape
  let F : Finset ℕ := {0,a,c,b}
  let X := residueCandidates (centralLower H g) (centralUpper H g) pat.modulus pat.codes
  let E := topMissing (H/4) D
  have ec : E.card≤chainCapacity H-D.card := by
    simpa [E] using band_canonical_holes_le H 1 D sub hd
  have eb : 1536*E.card<H := by omega
  obtain ⟨width,range'⟩ := reflected_window large gl gu
  have room : pat.load*E.card<X.card := (central_pattern_supplies pat large eb).1 width
  have geo (x : ℕ) (hx : x∈X) :
      H/4/2<x ∧ x≤H/4-4*(3*(H/256)+1) ∧ x≤g ∧
      H/4/2<g-x ∧ g-x≤H/4-4*(3*(H/256)+1) :=
    range' x (mem_filter.mp hx).1
  have residue (x : ℕ) (hx : x∈X) := pat.safe x (mem_filter.mp hx).2
  have covers (x : ℕ) (hx : x∈X) (f : ℕ) (hf : f∈F) :
      (x+4*f∉D → x+4*f∈E) ∧ (g-x+4*f∉D → g-x+4*f∈E) := by
    obtain ⟨xl,xu,xg,yl,yu⟩ := geo x hx
    obtain ⟨x4,_,can⟩ := residue x hx
    have fb : f≤b := by
      simp only [F,mem_insert,mem_singleton] at hf
      rcases hf with h|h|h|h <;> omega
    exact ⟨in_top_holes (by omega) (by omega) (can f hf),
      in_top_holes (by omega) (by omega) (canonical_odd _ (by omega))⟩
  obtain ⟨x,hx,cross⟩ := reflected_selection go
    (fun x hx=>⟨(geo x hx).2.2.1,(residue x hx).1,(residue x hx).2.1⟩)
    pat.fibres covers room
  let y := g-x
  obtain ⟨xl,xu,xg,yl,yu⟩ := geo x hx
  have x4 := (residue x hx).1
  have yo : y%2=1 := by dsimp [y];omega
  have sum : x+y=g := by dsimp [y];omega
  have xyD : x+y∈D := sum.symm ▸ hg
  obtain ⟨hF,hsmall⟩ := central_five (x:=x) (y:=y) large ac cb bu ha hc hb hac hba hbc
    xl xu yl yu (by omega) xyD cross
  let r := (12-y%8)%8
  let P := progression (H/2) (3*H/4) 8 r
  have cnt := progression_lower (H/2) (3*H/4) 8 r (Or.inr (Or.inl rfl)) (Nat.mod_lt _ (by decide))
  have tc := chain_capacity_with_top_loss H D sub hd
  have room' : 6*(topMissing H D).card<P.card := by
    change (3*H/4-H/2)/8≤P.card at cnt
    omega
  apply early_upper_common hF hsmall _ room'
  intro R hR
  obtain ⟨hi,mod'⟩ := mem_filter.mp hR
  obtain ⟨rlo,rhi⟩ := mem_Ioc.mp hi
  change R%8=(12-y%8)%8 at mod'
  refine ⟨by omega,by omega,?_⟩
  intro f hf
  simp only [centralEarly,mem_insert,mem_singleton] at hf
  rcases hf with rfl|rfl|rfl|rfl|rfl|rfl
  · exact canonical_odd _ (by omega)
  · exact canonical_four_residue _ (by omega)
  · exact canonical_odd _ (by omega)
  · exact canonical_odd _ (by omega)
  · exact canonical_odd _ (by omega)
  · exact canonical_odd _ (by omega)

end OP02.SharpK8

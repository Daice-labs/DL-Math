import K7AdditionalRows
import K7Prefix
import K7EndpointConversion
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

/-- Logical complement of the four complete formal profile rows. -/
def remainingProfiles (S:Finset ℕ) : Prop :=
  (oddOffsets S).card≠0 ∧
  ¬(4≤(oddOffsets S).card ∧ ∀x∈S,x%2=0→x%4=0) ∧
  ¬((oddOffsets S).card=3 ∧ (∀x∈S,x%2=0→x%4=0) ∧
    ∃c<4,c%2=1 ∧ ∀x∈S,x%2=1→x%4=c)

theorem remaining_seed (hD:Dousse7) (β:ℝ) (hb:0<β) : ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,
    SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∃S:Finset ℕ, InternalFive (B∩Icc 1 (n/4)) S ∧ remainingProfiles S := by
  obtain ⟨p,hp⟩:=prefix_admission hD β hb
  obtain ⟨u,hu⟩:=row01_all_even β hb
  obtain ⟨v,hv⟩:=rows17_22 hb
  obtain ⟨w,hw⟩:=row12_same_odd hb
  refine ⟨max (max p u) (max v w),?_⟩
  intro n hn B hf hd hg
  obtain ⟨S,hs⟩:=hp n (by omega) B hd hg
  refine ⟨S,hs,?_,?_,?_⟩
  · intro h0
    have hem:oddOffsets S=∅:=card_eq_zero.mp h0
    apply hu n (by omega) B hf hd hg S hs
    intro x hx;by_contra he
    have xx:x∈oddOffsets S:=mem_filter.mpr ⟨hx,by omega⟩
    simp [hem] at xx
  · rintro ⟨h4,hres⟩;exact hv n (by omega) B hf hd hg S hs h4 hres
  · rintro ⟨h3,hres,hmono⟩;exact hw n (by omega) B hf hd hg S hs h3 hres hmono

/-- The remaining formal row obligation, quantified before B and the seed. -/
def RemainingExclusion : Prop :=
  ∀β:ℝ,0<β→∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S → remainingProfiles S→False

theorem normalized_of_remaining (hD:Dousse7) (hrem:RemainingExclusion) : NormalizedK7Goal := by
  intro β hβ
  obtain ⟨U,hU⟩:=remaining_seed hD β hβ
  obtain ⟨V,hV⟩:=hrem β hβ
  refine ⟨max U V,?_⟩
  intro n hn B hsub hf hd
  have hnpg:¬(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ):=by
    intro hg;obtain ⟨S,hs,hrem⟩:=hU n (by omega) B hf hd hg
    exact hV n (by omega) B hsub hf hd hg S hs hrem
  have hident:=exact_inventory n B hsub hd
  have hid:B.card+totalBudget n B=2*n+(n+1)/2+(quarterD n B).card:=by unfold totalBudget;omega
  have hreal:(B.card:ℝ)+totalBudget n B=2*(n:ℝ)+((n+1)/2:ℕ)+(quarterD n B).card:=by exact_mod_cast hid
  have hceil:(2:ℝ)*((n+1)/2:ℕ)≤n+1:=by exact_mod_cast (show 2*((n+1)/2)≤n+1 by omega)
  linarith only [lt_of_not_ge hnpg,hreal,hceil]

theorem limit_of_remaining (hD:Dousse7) (hrem:RemainingExclusion) : SharpK7Limit :=
  limit_of_normalized hD (normalized_of_remaining hD hrem)

end OP02.SharpK7

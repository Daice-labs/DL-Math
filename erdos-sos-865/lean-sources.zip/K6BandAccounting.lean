import K6GapResources
open Finset
namespace OP02.SharpK6
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot OP02.SharpK5
set_option maxHeartbeats 1000000

def jointBandCost (n:ℕ) (B:Finset ℕ) :=
  2*(fourResources n B).card+(H2 n B).card+2*(Ho n B).card

/-- Paper (31),(33): one actual physical inventory, retaining t<=delta_hi.
This proves the budget conversion, not the yet-to-be-instantiated band cover. -/
theorem joint_band_budget (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    jointBandCost n B≤2*totalBudget n B ∧
    16*jointBandCost n B+4*(fourResources n B).card≤36*totalBudget n B := by
  have ht:=middle_two_le_singleton n B hd
  have hδ:=deficit_split n B hd
  have he:=excess_partition n B
  have hj:=four_resource_card n B
  unfold jointBandCost totalBudget
  omega

/-- Paper (32)--(34) and the final cancellation in signed real arithmetic.
Interval existence, coverage and profile selection remain separate geometric
obligations: this arithmetic lemma does not assert them for actual B. -/
theorem band_arithmetic_contradiction
    (n q δ β s m w K length : ℝ)
    (hn:65536≤n) (hq:0≤q) (hδ:δ≤q) (hβ:0<β) (hβu:β≤1/1024)
    (hmargin:100≤β*n) (hqsharp:q≤n/512-(β/2)*n)
    (hK:K≤n/16) (hs:s≤11*K/16-q-β*n+12)
    (hm:m≤n/2) (hw:w≤3*n/4)
    (hlower:min ((n-w)/2) ((n-m)/2-4*s)-2*(4*δ+4)-8≤length)
    (hupper:length≤36*q+4) : False := by
  have hnp:0≤n := by linarith
  have hqsmall:q≤n/512 := by nlinarith
  have hfirst : 5*n/64+4*q+4*β*n-48≤(n-w)/2 := by
    nlinarith [mul_nonneg (show 0≤1/1024-β by linarith) hnp]
  have hsecond : 5*n/64+4*q+4*β*n-48≤(n-m)/2-4*s := by linarith
  have hmin:=le_min hfirst hsecond
  nlinarith

#print axioms joint_band_budget
#print axioms band_arithmetic_contradiction
end OP02.SharpK6

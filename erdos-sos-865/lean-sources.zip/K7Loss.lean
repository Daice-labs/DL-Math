import K7Budget

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

def passes (Y O B : Finset ℕ) := Y.filter (fun x => ∀ t∈O, x+t∈B)

/-- Physical loss fibres indexed by their single missing label.
Aliases in the offset set are removed by Finset before loads are counted. -/
theorem shift_losses (Y O B E : Finset ℕ) (m r L : ℕ)
    (hres : ∀x∈Y, x%m=r)
    (hloss : ∀x∈Y,∀t∈O,x+t∉B → x+t∈E)
    (hload : ∀z∈E,(O.filter (fun t => (r+t)%m=z%m)).card ≤ L) :
    Y.card ≤ (passes Y O B).card + L*E.card := by
  classical
  let V := passes Y O B
  let fibre (z : ℕ) := Y.filter (fun x => ∃t∈O,x+t=z)
  have hcover : Y\V ⊆ E.biUnion fibre := by
    intro x hx
    obtain ⟨hxY,hv⟩ := mem_sdiff.mp hx
    have hw : ∃ t∈O,x+t∉B := by
      by_contra h;push Not at h
      exact hv (mem_filter.mpr ⟨hxY,h⟩)
    obtain ⟨t,ht,hb⟩ := hw
    exact mem_biUnion.mpr ⟨x+t,hloss x hxY t ht hb,mem_filter.mpr ⟨hxY,t,ht,rfl⟩⟩
  have hf z (hz : z∈E) : (fibre z).card ≤ L := by
    apply le_trans _ (hload z hz)
    apply card_le_card_of_injOn (fun x => z-x)
    · intro x hx; obtain ⟨hY,t,ht,h⟩ := mem_filter.mp hx
      have he : z-x=t := by omega
      change z-x ∈ O.filter (fun t => (r+t)%m=z%m)
      rw [he]; apply mem_filter.mpr; refine ⟨ht,?_⟩
      rw [←h,←hres x hY,Nat.mod_add_mod]
    · intro x hx y hy he
      obtain ⟨_,t,_,h₁⟩ := mem_filter.mp hx
      obtain ⟨_,w,_,h₂⟩ := mem_filter.mp hy
      dsimp at he;omega
  have hsum := (card_le_card hcover).trans (card_biUnion_le.trans (sum_le_sum hf))
  simp only [sum_const,nsmul_eq_mul] at hsum
  have hc := card_sdiff_add_card_eq_card (filter_subset _ _ : V⊆Y)
  change (Y\V).card+V.card=Y.card at hc
  change Y.card≤V.card+_
  change (Y \ V).card ≤ E.card*L at hsum
  rw [Nat.mul_comm E.card L] at hsum
  exact hc ▸ (by simpa [Nat.add_comm] using Nat.add_le_add_right hsum V.card)

def upperOriginal (n : ℕ) (B : Finset ℕ) :=
  (emptyPairs n B).filter (fun x=>n/4/2<x ∧ x≤n/4)
def gapOriginal (n : ℕ) (B : Finset ℕ) :=
  (emptyPairs n B).filter (fun x=>n/4/4<x ∧ x≤n/4/2)
def A_loss (n : ℕ) (B : Finset ℕ) := (emptyOuter (n/4/4) (quarterD n B)).card
def T_loss (n : ℕ) (B : Finset ℕ) := (emptyOuter (n/4) (quarterD n B)).card+(upperOriginal n B).card
def G_loss (n : ℕ) (B : Finset ℕ) := (gapOriginal n B).card

theorem common_inventory (n : ℕ) (B : Finset ℕ) :
    A_loss n B+T_loss n B+G_loss n B≤lambdaBudget n B := by
  have hdis : Disjoint (upperOriginal n B) (gapOriginal n B) := by
    apply disjoint_left.mpr;intro x hx hy
    have hx' := (mem_filter.mp hx).2;have hy' := (mem_filter.mp hy).2;omega
  have hh := card_le_card (union_subset (filter_subset _ _) (filter_subset _ _) :
    upperOriginal n B ∪ gapOriginal n B ⊆ emptyPairs n B)
  rw [card_union_of_disjoint hdis] at hh
  unfold A_loss T_loss G_loss lambdaBudget; omega

def absentTop (n : ℕ) (B : Finset ℕ) :=
  (Ioc (n/4/2) (n/4)).filter (fun x=>x%2=1 ∧ x∉B)

theorem absent_top_cost (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    (absentTop n B).card ≤ T_loss n B := by
  let H := n/4; let D := quarterD n B
  have hs : absentTop n B ⊆ emptyOuter H D ∪ upperOriginal n B := by
    intro x hx
    obtain ⟨hi,ho,habs⟩:=mem_filter.mp hx
    obtain ⟨hlo,hhi⟩ := mem_Ioc.mp hi
    by_cases hD : x∈D
    · apply mem_union_right
      have h4 := (mem_filter.mp hD).2
      have h2 : 2*x∉B := fun hm => hd (2*x) hm (by simpa [←Nat.mul_assoc] using h4)
      apply mem_filter.mpr
      refine ⟨mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,ho⟩,
        by omega,habs,h2⟩,hlo,hhi⟩
    · apply mem_union_left
      apply (singleton_empty_iff H x D (mem_Ioc.mpr ⟨by dsimp [H];omega,hhi⟩)
        (Or.inl ⟨x/2,by omega⟩)).mpr hD
  exact (card_le_card hs).trans (card_union_le _ _)

theorem absent_quarter_root {n x : ℕ} {B : Finset ℕ}
    (hl : n/4/8<x) (hu : x≤n/4/4) (ho : x%2=1) (hm : x∉quarterD n B) :
    x∈emptyOuter (n/4/4) (quarterD n B) := by
  apply (singleton_empty_iff _ _ _ (mem_Ioc.mpr ⟨by omega,hu⟩) (Or.inl ⟨x/2,by omega⟩)).mpr hm

end OP02.SharpK7

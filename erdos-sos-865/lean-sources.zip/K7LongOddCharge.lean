import K7LowerTags
import K7LongTestWindow
import K7LowerOT

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

/-- Construct just the actually missing images of the admitted testers.
Every missing position has at most one inverse for each of three offsets. -/
theorem fixed_even_charge {n t : ℕ} {B : Finset ℕ}
    (hf : SevenFree B) (hd : DoublingFree B) (middle : MiddleGap7 n B)
    (hc : 384*(chainDeficit n B+totalBudget n B)≤n/4) (hn : 65536≤n)
    (hΛ : 6*lambdaBudget n B < n/4/64)
    (sc : 16384≤n/4/64) (ht : 17*(n/4/64)<t) (hu : 3*t<n/4)
    (htB : t∈B) (ho : t%2=1) (heven : ActiveEvenSupply n B) : ChargeEvidence n B t := by
  classical
  obtain ⟨e,he,hee,_hmax,a,hpair,ae⟩:=heven
  obtain ⟨ha,apos,hac,hcS⟩:=mem_filter.mp hpair
  let c:=e-a
  have asc:a<c:=hac
  have es:a+c=e:=by dsimp [c];omega
  have eN:e≤n/4/64:=(mem_Icc.mp (mem_inter.mp he).2).2
  have ce:c%2=0:=by omega
  let Y:=lowerTesters (n/4) t c
  let G:=passes Y {0,a,c} (quarterD n B)
  let O:Finset ℕ:={0,4*a,4*c}
  let Z:=(G.biUnion (fun b=>O.image (fun o=> t-4*b+o))).filter (fun r=>r∉B)
  have gd {b:ℕ} (hb:b∈G) := lower_tester_data (mem_filter.mp hb).1 ht sc
  have bounds {b:ℕ} (hb:b∈G) {o:ℕ} (hO:o∈O) :
      n/4/8 < t-4*b+o ∧ t-4*b+o≤n/4/4 ∧ (t-4*b+o)%2=1 ∧ 4*b≤t := by
    have H:=gd hb
    simp only [O,mem_insert,mem_singleton] at hO
    rcases hO with rfl|rfl|rfl <;> omega
  have subset:Z⊆lowerHoles n B:=by
    intro r hz;obtain ⟨hmer,hmissing⟩:=mem_filter.mp hz
    obtain ⟨b,hb,himg⟩:=mem_biUnion.mp hmer
    obtain ⟨o,hO,rfl⟩:=mem_image.mp himg
    have H:=bounds hb hO
    exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨H.1,H.2.1⟩,H.2.2.1,hmissing⟩
  have cover : G⊆(Z.product O).image (fun q:ℕ×ℕ=>(t+q.2-q.1)/4) := by
    intro b hb
    have dat:=gd hb
    have good:=(mem_filter.mp hb).2
    have bd:=bounds hb (show 0∈O by simp [O])
    have forced:=lower_OT hf hd middle hc hn apos asc (by omega : c<b) (by omega)
      (by omega : n/4/8<t-4*b) (by omega) (by omega)
      (Or.inl ⟨ae,ce,dat.2.2.1⟩) hΛ (mem_inter.mp ha).1 (mem_inter.mp hcS).1
      (by simpa using good 0 (by simp)) (es.symm ▸ (mem_inter.mp he).1)
      (good a (by simp)) (good c (by simp))
      (by rwa [show t-4*b+4*b=t by omega])
    have fails:∃o∈O,t-4*b+o∉B:=by
      rcases forced with h|h|h
      · exact ⟨0,by simp [O],by simpa using h⟩
      · exact ⟨4*a,by simp [O],h⟩
      · exact ⟨4*c,by simp [O],h⟩
    obtain ⟨o,ho',failure⟩:=fails
    have hz:t-4*b+o∈Z:=mem_filter.mpr
      ⟨mem_biUnion.mpr ⟨b,hb,mem_image.mpr ⟨o,ho',rfl⟩⟩,failure⟩
    exact mem_image.mpr ⟨(t-4*b+o,o),mem_product.mpr ⟨hz,ho'⟩,by dsimp;omega⟩
  have hcG:= (card_le_card cover).trans card_image_le
  rw [Finset.product_eq_sprod,card_product] at hcG
  have cO:O.card≤3:=card_le_three
  have load:G.card≤3*Z.card:=hcG.trans (by simpa [Nat.mul_comm] using Nat.mul_le_mul_left Z.card cO)
  have cnt:=lower_tester_count (H:=n/4) (t:=t) (c:=c) (by omega) ht hu sc
  have flt:=lower_tester_filter (B:=B) ht sc apos asc (by omega) ⟨ae,ce⟩
  change Y.card≤G.card+3*(midOddLoss n B).card at flt
  change 4*((n/4/64:ℕ):ℤ)≤8*(Y.card:ℤ)+deviation n t+32 at cnt
  refine ⟨Z,subset,?_,by omega⟩
  exact (Nat.add_le_add_right (card_le_card subset) _).trans (joint_lower_upper n B hd)

theorem long_odd_shared_charge (hD:Dousse7) : PhysicalStatement := by
  intro β hb
  obtain ⟨U,hU⟩:=uniform_window_threshold β hb
  obtain ⟨V,hV⟩:=inventory_uniform β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  refine ⟨max (4*64*16384) (max U (max V W)),?_⟩
  intro n hn B sub hf hd hg t t' h k l ho ho' opp hp ko lo kl big hs largest ht active
  have ti:t∈insert (2*l) ({t,t',4*h,2*k}:Finset ℕ):=by simp
  have tB: t∈B:=(mem_inter.mp (hs.2.1 ti)).1
  have sum:=(mem_Icc.mp (mem_inter.mp (hs.2.2 t ti (2*l) (by simp) (by omega))).2).2
  obtain ⟨hcap,hlarge⟩:=hV n (by omega) B hd hg
  obtain ⟨hsc,hl⟩:=hU n (by omega)
  have budget:=signed_units hd hg hsc hl
  exact fixed_even_charge hf hd (hW n (by omega) B hf hd hg) hcap hlarge
    (by omega) (by omega) ht (by omega) tB ho active

theorem long_odd_shared_loss (hD:Dousse7) : LossStatement := by
  intro β hb
  obtain ⟨U,hU⟩:=long_odd_shared_charge hD β hb
  obtain ⟨V,hV⟩:=uniform_window_threshold β hb
  refine ⟨max U V,?_⟩
  intro n hn B sub hf hd hg t t' h k l ho ho' opp hp ko lo kl big hs largest ht active
  have z:=hU n (by omega) B sub hf hd hg t t' h k l ho ho' opp hp ko lo kl big hs largest ht active
  obtain ⟨hsc,hl⟩:=hV n (by omega)
  exact scalar_from_charge z (signed_units hd hg hsc hl)

end OP02.SharpK7.LongOddTask

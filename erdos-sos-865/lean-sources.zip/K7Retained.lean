import K7Affine
import K7Rigid
open Finset OP02.SmallExcess OP02.FewHole OP02.SharpK5
namespace OP02.SharpK7

/-- Membership at an odd candidate is tested in its exact original-level
singleton. The four upper-end remainders are included. -/
theorem miss_mid_odd {n v : ℕ} {B : Finset ℕ} (hv : 2*(n/4/64)<v)
    (hi : v≤n/4/16) (ho : v%2=1) (hm : v∉quarterD n B) :
    v∈midOddLoss n B := by
  let M := n/4/16
  have heq : M/4=n/4/64 := by unfold M;omega
  have hI : v∈Ioc (2*(M/4)) M := mem_Ioc.mpr ⟨by omega,hi⟩
  have hodd : Odd v := ⟨v/2,by omega⟩
  exact mem_filter.mpr ⟨(singleton_empty_iff M v (quarterD n B) hI (Or.inl hodd)).mpr hm,ho⟩

/-- At a fixed rigid tester, different rejected reflection pairs have
different missing odd singleton labels, for arbitrary mixed supplies. -/
theorem retained_count (n : ℕ) (B : Finset ℕ) {e b : ℕ} (he : e∈smallSupport n B)
    (hee : e%2=0) (hbe : b%2=0) (hb₁ : 2*(n/4/64)<b) (hb₂ : b≤3*(n/4/64)+1) :
    (reflectionPairs (smallSupport n B) e).card ≤
      (retainedEndpoints n B e b).card + (midOddLoss n B).card := by
  classical
  let D := quarterD n B
  let P := reflectionPairs (smallSupport n B) e
  let Q := retainedEndpoints n B e b
  let Z := P \ Q
  let dest (a : ℕ) := if b+a∉D then b+a else b+(e-a)
  have heN := (mem_Icc.mp (mem_inter.mp he).2).2
  have props (a : ℕ) (ha : a∈Z) : 0<a ∧ a<e-a ∧ a%2=1 ∧ dest a∉D := by
    obtain ⟨hp,hn⟩ := mem_sdiff.mp ha
    obtain ⟨_,ha1,ha2,_⟩ := mem_filter.mp hp
    have ho : ¬ a%2=0 := fun ho => hn (mem_filter.mpr ⟨hp,Or.inl ho⟩)
    refine ⟨ha1,ha2,by omega,?_⟩
    by_cases hba : b+a∈D
    · simp only [dest,hba,not_true_eq_false,ite_false]
      intro h';exact hn (mem_filter.mpr ⟨hp,Or.inr ⟨hba,h'⟩⟩)
    · simpa [dest,hba] using hba
  have maps (a : ℕ) (ha : a∈Z) : dest a∈midOddLoss n B := by
    obtain ⟨h1,h2,ho,hf⟩ := props a ha
    apply miss_mid_odd _ _ _ hf <;> unfold dest <;> split_ifs <;> omega
  have hi : Set.InjOn dest (Z : Set ℕ) := by
    intro x hx y hy h
    have hp := props x hx;have hq := props y hy
    unfold dest at h
    split_ifs at h <;> omega
  have hbound := card_le_card_of_injOn dest maps hi
  have hsub : Q⊆P := filter_subset _ _
  have hpart := card_sdiff_add_card_eq_card hsub
  change Z.card + Q.card=P.card at hpart
  change P.card≤Q.card+_
  omega

/-- Choose a rigid tester before knowing which parity interpolation will return. -/
theorem many_retained (β : ℝ) (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hpg : (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale : 64≤n/4) (hlarge : 10*(logLevels (n/4):ℝ)+1000≤β*n) :
    ∃ e∈smallSupport n B, e%2=0 ∧ (∀ x∈smallSupport n B, x%2=0 → x≤e) ∧
      ∃ w∈rigidPresent (n/4/64) (quarterD n B),
        lambdaBudget n B < (retainedEndpoints n B e (4*w)).card := by
  obtain ⟨e,he,hee,hm,hc⟩ := actual_reflection_supply β n B hd hpg (by omega) hlarge
  have hmny := many_rigid β n B hd hpg hscale hlarge
  obtain ⟨w,hw⟩ := card_pos.mp (show 0<(rigidPresent (n/4/64) (quarterD n B)).card by omega)
  have hw' := rigid_bounds (mem_filter.mp hw).1
  have hr := retained_count n B he hee (b:=4*w) (by omega) (by omega) (by omega)
  have hα := surplus_lower β n B hd hpg
  have hodd : ((midOddLoss n B).card:ℝ) ≤ (midEmpty n B).card :=
    by exact_mod_cast (card_le_card (filter_subset _ _) : (midOddLoss n B).card ≤ _)
  have hlog : (0:ℝ)≤logLevels (n/4) := by positivity
  have hsR : (surplus n B:ℝ) ≤ (reflectionPairs (smallSupport n B) e).card := by exact_mod_cast hc
  have hrR : ((reflectionPairs (smallSupport n B) e).card:ℝ) ≤
      (retainedEndpoints n B e (4*w)).card + ((midOddLoss n B).card:ℝ) := by exact_mod_cast hr
  refine ⟨e,he,hee,hm,w,hw,?_⟩
  have : (lambdaBudget n B:ℝ)<(retainedEndpoints n B e (4*w)).card := by linarith
  exact_mod_cast this

end OP02.SharpK7

import K7TwoBand
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7
set_option maxHeartbeats 1500000

def favTau (n:ℕ) (B:Finset ℕ):=4*(missingTopOdd n B).card+8
def favLo (n w:ℕ) (B:Finset ℕ):=n+w/2+favTau n B
def favLen (n:ℕ) (B:Finset ℕ):=n/8-2*favTau n B-5
def favFaults (n w:ℕ) (B:Finset ℕ):=
  (Ioc (favLo n w B) (favLo n w B+favLen n B+4*(n/16))).filter (fun y=>y%2=1 ∧ y∉B)
def favBases (n w σ:ℕ) (B:Finset ℕ):=progression (favLo n w B) (favLo n w B+favLen n B) 4 σ

private theorem fav_tau_bound {n:ℕ} {B:Finset ℕ} (hd:DoublingFree B) :
    favTau n B≤4*totalBudget n B+8:=by
  have :=missingTopOdd_le_deficit n B hd;unfold favTau totalBudget;omega

private theorem fav_id {n:ℕ} {B:Finset ℕ} (hd:DoublingFree B) (hn:65536≤n)
    (hq:2048*totalBudget n B≤n) : favLen n B+2*favTau n B+5=n/8 := by
  have ht:=fav_tau_bound (n:=n) hd
  dsimp only [favLen]
  omega

private theorem wide_upper (n:ℕ) : 3*n ≤ 4*(n-4*(n/16)) := by omega

private theorem forced_range_arith {n w y τ l k e : ℕ}
    (hlo:n+w/2+τ<y) (hhi:y≤n+w/2+τ+l+4*k)
    (hlen:l+2*τ+5=e) (h8:8*e≤n) (h16:16*k≤n) :
    2*n+2*τ<2*y-w ∧ 4*(2*y-w)+8*τ+3≤11*n ∧ w≤2*y := by
  have hwy:w≤2*y:=by omega
  have hsub:2*y-w+w=2*y:=Nat.sub_add_cancel hwy
  omega

private theorem upper_odd_central {n w τ y l e : ℕ}
    (hw:4*w≤3*n) (hlo:n+w/2+τ<y) (hhi:y≤n+w/2+τ+l)
    (hlen:l+2*τ+5=e) (h8:8*e≤n) :
    n+τ<y ∧ 2*y+2*τ+2≤3*n ∧ 4*y≤7*n:=by omega

private theorem partner_res {p w v y:ℕ} (hp:p+w=2*y) (ho:y%2=1)
    (h:v%2=w%2) (h':v%4≠w%4) : (p+v)%4=0:=by omega
private theorem outer_res {p w x y:ℕ} (hp:p+w=2*y) (h:x%2≠w%2) : (p+x)%2=1:=by omega

theorem favorable_faults_le {n w:ℕ} {B S:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hg:MiddleGap7 n B) (hn:65536≤n)
    (hq:2048*totalBudget n B≤n) (hs:internalOn B S) (hc:S.card=6)
    (hr:∀x∈insert 0 S,x≤n) (hw:4*w≤3*n)
    (hgroup:∀x∈insert 0 S,x%2=w%2→x≠w→x%4≠w%4 ∧ x≤n/4) :
    (favFaults n w B).card≤7*totalBudget n B:=by
  have ht:=fav_tau_bound (n:=n) hd
  have range {y:ℕ} (hy:y∈favFaults n w B) :
      2*n+2*favTau n B<2*y-w ∧ 2*y-w+n≤4*n ∧
      2*y-w+n/4<4*(n-4*(n/16))-2*favTau n B ∧ w≤2*y ∧ y%2=1 ∧ y∉B:=by
    obtain ⟨hi,ho,ha⟩:=mem_filter.mp hy
    have hh:=mem_Ioc.mp hi;dsimp only [favLo] at hh
    have d:=forced_range_arith hh.1 hh.2 (fav_id hd hn hq) (show 8*(n/8)≤n by omega) (show 16*(n/16)≤n by omega)
    obtain ⟨l,h,w'⟩:=d
    have k:=wide_upper n
    refine ⟨l,by omega,?_,w',ho,ha⟩
    omega
  apply failed_half_card (w:=w) hf hd hs hc
  · intro y hy;have hh:=range hy
    refine ⟨hh.2.2.2.1,?_⟩;intro hx;have :=hr _ (mem_insert_of_mem hx);omega
  · intro y hy x hx ha
    obtain ⟨ll,uu,central,hwt,yo,ya⟩:=range hy
    have xn:=hr x hx
    let p:=2*y-w
    have pe:p+w=2*y:=Nat.sub_add_cancel hwt
    have pl:2*n+2*favTau n B<p:=ll
    have pu:p+n≤4*n:=uu
    have pc:p+n/4<4*(n-4*(n/16))-2*favTau n B:=central
    have p0:2*n<p:=lt_of_le_of_lt (Nat.le_add_right _ _) pl
    have lz:2*n<p+x:=lt_of_lt_of_le p0 (Nat.le_add_right _ _)
    have uz:p+x≤4*n:=(Nat.add_le_add_left xn p).trans pu
    change p+x∈OP02.SharpK6.bootstrapResources n B
    change p+x∉B at ha
    by_cases hpar:x%2=w%2
    · by_cases eq:x=w
      · subst x
        rw [pe] at ha lz uz ⊢
        apply mem_union_left;apply mem_union_right
        exact OP02.SharpK6.bootstrap_missing_target n y 0 B yo (by simpa using ya) (by simpa using lz) (by simpa using uz) (by simpa using ha)
      · obtain ⟨opp,hh⟩:=hgroup x hx hpar eq
        apply mem_union_left;apply mem_union_left
        exact missing_gap_multiple hg (partner_res pe yo hpar opp) ha
          (lt_of_lt_of_le pl (Nat.le_add_right _ _)) (lt_of_le_of_lt (Nat.add_le_add_left hh p) pc)
    · apply mem_union_right
      exact OP02.SharpK6.bootstrap_missing_odd n _ B (outer_res pe hpar) lz uz ha

private theorem favorable_counts {n w σ:ℕ} {B T:Finset ℕ} (hd:DoublingFree B) (hn:65536≤n)
    (hq:2048*totalBudget n B≤n) (hw:4*w≤3*n)
    (h4:T.card=4) (ht:∀a∈T,a≤n/16) (hs:σ<4) (ho:σ%2=1)
    (hbad:(favFaults n w B).card≤7*totalBudget n B) :
    totalBudget n B<(passes (favBases n w σ B) (quartOffsets T) B).card:=by
  obtain ⟨hc,hr⟩:=quart_offset_counts h4 ht
  have hbd:=shift_losses (favBases n w σ B) (quartOffsets T) B (favFaults n w B) 1 0 5
    (by intro _ _;omega) (by
      intro y hy a ha hab;obtain ⟨hi,hyσ⟩:=mem_filter.mp hy;have hiy:=mem_Ioc.mp hi
      have hd':=hr a ha;exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,hab⟩)
    (fun _ _=>(card_filter_le _ _).trans hc)
  have hlen:=progression_lower (favLo n w B) (favLo n w B+favLen n B) 4 σ (by decide) hs
  change _≤(favBases n w σ B).card at hlen
  have ht':=fav_tau_bound (n:=n) hd
  have hi:=fav_id hd hn hq
  rw [Nat.add_sub_cancel_left] at hlen
  omega

theorem favorable_six {n w:ℕ} {B T S:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hg:MiddleGap7 n B) (hn:65536≤n)
    (hq:2048*totalBudget n B≤n) (h4:T.card=4) (hT:internalOn (quarterD n B) T) (ht:∀a∈T,a≤n/16)
    (hs:internalOn B S) (hc:S.card=6) (hsn:∀x∈S,x≤n) (hw:4*w≤3*n)
    (hgroup:∀x∈insert 0 S,x%2=w%2→x≠w→x%4≠w%4 ∧ x≤n/4) : False := by
  have hr:∀x∈insert 0 S,x≤n:=by intro x hx;rcases mem_insert.mp hx with rfl|hx;omega;exact hsn _ hx
  have fail:=favorable_faults_le hf hd hg hn hq hs hc hr hw hgroup
  let U:=passes (favBases n w 1 B) (quartOffsets T) B
  let V:=passes (favBases n w 3 B) (quartOffsets T) B
  have uj:totalBudget n B<U.card:=favorable_counts hd hn hq hw h4 ht (by decide) (by decide) fail
  have vj:totalBudget n B<V.card:=favorable_counts hd hn hq hw h4 ht (by decide) (by decide) fail
  have hE:(fourResources n B).card≤totalBudget n B:=by have :=four_resource_budget n B hd;omega
  have dt {σ y:ℕ} (hy:y∈passes (favBases n w σ B) (quartOffsets T) B) :
      n+favTau n B<y ∧ y<2*(n-4*(n/16))-favTau n B ∧ 4*y≤7*n ∧ y%4=σ:=by
    obtain ⟨hp,_⟩:=mem_filter.mp hy;obtain ⟨hi,hyσ⟩:=mem_filter.mp hp;have hh:=mem_Ioc.mp hi
    dsimp only [favLo] at hh
    have d:=upper_odd_central hw hh.1 hh.2 (fav_id hd hn hq) (show 8*(n/8)≤n by omega)
    have k:=wide_upper n
    exact ⟨d.1,by omega,d.2.2,hyσ⟩
  apply conflicting_neighbor_families hf hd hg hn (by omega) h4 hT ht
    (card_pos.mp (show 0<U.card by omega)) (lt_of_le_of_lt hE vj)
  · intro y hy;have hh:=dt hy;exact ⟨by omega,hh.2.2.1,by omega,(mem_filter.mp hy).2⟩
  · intro z hz;have hh:=dt hz;exact ⟨by omega,hh.2.2.1,by omega,(mem_filter.mp hz).2⟩
  · intro y hy z hz;have :=dt hy;have :=dt hz;omega
  · intro y hy z hz ha;have yb:=dt hy;have zb:=dt hz
    apply missing_gap_multiple hg (by omega) ha
    · change 2*n+2*favTau n B<_;omega
    · change _<4*(n-4*(n/16))-2*favTau n B;omega

theorem uniform_favorable_band (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B →
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,internalOn B S→S.card=6→(∀x∈S,x≤n)→∀w:ℕ,4*w≤3*n →
    (∀x∈insert 0 S,x%2=w%2→x≠w→x%4≠w%4 ∧ x≤n/4)→False := by
  obtain ⟨U,hU⟩:=small_quartet_uniform hD β hb
  obtain ⟨V,hV⟩:=middle_gap7 hD β hb
  obtain ⟨W,hW⟩:=strong_budget hD β hb
  refine ⟨max 65536 (max U (max V W)),?_⟩
  intro n hn B hf hd hg S hs hc hsn w hw hgroup
  obtain ⟨T,h4,hT,ht⟩:=hU n (by omega) B hd hg
  obtain ⟨_,hqw⟩:=hW n (by omega) B hf hd hg
  have hb' : (0:ℝ)≤β*n:=by positivity
  have qN:2048*totalBudget n B≤n:=by exact_mod_cast (show (2048:ℝ)*totalBudget n B≤n by linarith)
  exact favorable_six hf hd (hV n (by omega) B hf hd hg) (by omega) qN h4 hT ht hs hc hsn hw hgroup

end OP02.SharpK7

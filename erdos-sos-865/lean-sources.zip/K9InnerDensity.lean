import K9Spec
import K8SmallSupport

open Finset OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.SharpK5
namespace OP02.SharpK9

/-- The original word yields a single inner quarter set with a positive density
margin, a full unit of spare capacity in the 384 bound, and all six contacts
of a four chosen in its actual lower quarter. -/
theorem inner_density_supply {β : ℝ} (hb : 0<β) :
    ∃M : ℕ, ∀n : ℕ,M≤n → ∀B : Finset ℕ, B⊆Icc 1 (4*n) → DoublingFree B → SignedGap β n B →
      let J := n/4/4
      let h := J/4
      let G := quarterD J (quarterD n B)
      G⊆Icc 1 h ∧ DoublingFree G ∧ (85/128+β/2)*(h:ℝ)≤G.card ∧
        384*(chainCapacity h-G.card+1)<h ∧ ∃T : Finset ℕ,Internal 4 (G∩Icc 1 (h/4)) T := by
  obtain ⟨C,hC⟩ := capacity_uniform_error (β/2) (by positivity)
  obtain ⟨T₀,hT₀⟩ := OP02.SharpK7.fourfree_uniform
    (OP02.SharpK8.dousse7_of_dousse8 OP02.Midpoint.dousse8) (β/2) (by positivity)
  obtain ⟨V,hV⟩ := exists_nat_gt (4/β)
  refine ⟨max (256*(T₀+1)) (max (64*(C+1)) V),?_⟩
  intro n hn B _ hd gap
  let H := n/4
  let J := H/4
  let h := J/4
  let l := h/4
  let D := quarterD n B
  let G := quarterD J D
  let P := G∩Icc 1 l
  have dsub : D⊆Icc 1 H := filter_subset _ _
  have dfD : DoublingFree D := quarter_doubling_free n B hd
  have sub : G⊆Icc 1 h := filter_subset _ _
  have df : DoublingFree G := quarter_doubling_free J D dfD
  have cut := OP02.SharpK8.radial_identity H D dfD
  rw [show lower H D=D from inter_eq_left.mpr dsub] at cut
  have split := lower_card_eq J D
  have residue := residue_card_le J D dfD
  change (lower J D).card+_=D.card+_ at cut
  change (lower J D).card=(residueR J D).card+G.card at split
  have account : (D.card:ℝ)≤(G.card:ℝ)+((H+1)/2:ℕ)+((J+1)/2:ℕ) := by
    exact_mod_cast (show D.card≤G.card+(H+1)/2+(J+1)/2 by omega)
  have floors : (2048:ℝ)*(((H+1)/2:ℕ)+((J+1)/2:ℕ))+1360*h≤1365*H+2048 := by
    exact_mod_cast (show 2048*((H+1)/2+(J+1)/2)+1360*h≤1365*H+2048 by dsimp [h,J]; omega)
  have hHn : 4*(H:ℝ)≤n := by exact_mod_cast (show 4*H≤n by dsimp [H]; omega)
  have hhn : (h:ℝ)≤n := by exact_mod_cast (show h≤n by dsimp [h,J,H]; omega)
  have hln : (l:ℝ)≤n := by exact_mod_cast (show l≤n by dsimp [l,h,J,H]; omega)
  have vN : (V:ℝ)≤n := by exact_mod_cast (show V≤n by omega)
  have reserve := (div_lt_iff₀ hb).mp (lt_of_lt_of_le hV vN)
  change (1365/8192+β)*(n:ℝ)≤(D.card:ℝ)-totalBudget n B at gap
  have strong : (85/128:ℝ)*h+β*n-1≤G.card := by
    linarith only [gap,hHn,account,floors,Nat.cast_nonneg (α:=ℝ) (totalBudget n B)]
  have dense : (85/128+β/2)*(h:ℝ)≤G.card := by
    nlinarith only [strong,reserve,mul_nonneg hb.le (sub_nonneg.mpr hhn)]
  have cap := hC h (by dsimp [h,J,H]; omega)
  have room := chain_capacity_with_top_loss h G sub df
  let κ := chainCapacity h-G.card
  have bal : (κ:ℝ)+G.card=chainCapacity h := by
    exact_mod_cast (show κ+G.card=chainCapacity h by dsimp [κ]; omega)
  have deficit : 384*(κ+1)<h := by
    exact_mod_cast (show (384:ℝ)*((κ:ℝ)+1)<h by
      nlinarith only [bal,cap,strong,reserve,mul_nonneg hb.le (sub_nonneg.mpr hhn)])
  refine ⟨sub,df,dense,deficit,?_⟩
  have inside := OP02.SharpK8.radial_identity h G df
  rw [show lower h G=G from inter_eq_left.mpr sub] at inside
  change P.card+(h+1)/2=G.card+_ at inside
  have prefixCount : (G.card:ℝ)≤(P.card:ℝ)+((h+1)/2:ℕ) := by
    exact_mod_cast (show G.card≤P.card+(h+1)/2 by omega)
  have lastFloors : (128:ℝ)*((h+1)/2:ℕ)+84*l≤85*h+128 := by
    exact_mod_cast (show 128*((h+1)/2)+84*l≤85*h+128 by dsimp [l]; omega)
  by_contra no
  have empty : FourFree P := by
    rintro ⟨S,sS,kS,eS⟩
    exact no ⟨S,sS,kS,eS⟩
  have bound := hT₀ l (by dsimp [l,h,J,H]; omega) P inter_subset_right empty
  nlinarith only [strong,prefixCount,lastFloors,bound,reserve,mul_nonneg hb.le (sub_nonneg.mpr hln)]

#print axioms inner_density_supply
end OP02.SharpK9

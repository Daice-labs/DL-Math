import PivotRemaining
open Finset
namespace OP02.Focused
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit

/-- The exact hypotheses of the retained mixed-charge reduction. -/
def ChargeContext (n : ℕ) (B : Finset ℕ) : Prop :=
  20 ≤ n ∧ B ⊆ Icc 1 (4*n) ∧ FourFree B ∧ DoublingFree B ∧
  n ≤ 4*(holes n B).card ∧
  32*(deficit n B+(excessHoles n B).card)<n ∧
  Erdos865.HasTriple (lower n B) ∧
  (∀ S, LowerTriangle n B S → MixedResidueProfile S)

/-- Base case: saturated compression slots and no excess upper holes.
The constant is uniform, not chosen separately for each configuration. -/
def ZeroDefectChargeGoal : Prop :=
  ∃ K : ℕ, ∀ n B, ChargeContext n B →
    deficit n B + (excessHoles n B).card = 0 →
    8*(quarterD n B).card ≤ n+K

/-- Positive-defect case, with the exact coefficient required by the bridge. -/
def PositiveDefectChargeGoal : Prop :=
  ∃ K : ℕ, ∀ n B, ChargeContext n B →
    0 < deficit n B + (excessHoles n B).card →
    8*(quarterD n B).card ≤
      n+8*(deficit n B+(excessHoles n B).card)+K

/-- This target may use the proved zero-defect result, explicitly. -/
def RobustChargeGoal : Prop := ZeroDefectChargeGoal → PositiveDefectChargeGoal

theorem zero_defect_iff (n : ℕ) (B : Finset ℕ) (hdbl : DoublingFree B) :
    deficit n B + (excessHoles n B).card = 0 ↔
    (residueR n B).card = (n+1)/2 ∧ excessHoles n B = ∅ := by
  have hr := residue_card_le n B hdbl
  simp only [deficit, Nat.add_eq_zero_iff, Nat.sub_eq_zero_iff_le, card_eq_zero]
  constructor
  · rintro ⟨h,hE⟩
    exact ⟨by omega,hE⟩
  · rintro ⟨h,hE⟩
    exact ⟨by omega,hE⟩

theorem mixed_charge_of_cases
    (hzero : ZeroDefectChargeGoal) (hpositive : PositiveDefectChargeGoal) :
    MixedResidueChargeGoal := by
  obtain ⟨K0, h0⟩ := hzero
  obtain ⟨K1, h1⟩ := hpositive
  refine ⟨max K0 K1, ?_⟩
  intro n hn B hsub hfour hdbl hholes hsmall htri hprofile
  have hc : ChargeContext n B := ⟨hn,hsub,hfour,hdbl,hholes,hsmall,htri,hprofile⟩
  by_cases hz : deficit n B + (excessHoles n B).card = 0
  · have h := h0 n B hc hz
    omega
  · have h := h1 n B hc (by omega)
    omega

theorem zero_of_mixed (h : MixedResidueChargeGoal) : ZeroDefectChargeGoal := by
  obtain ⟨K, hK⟩ := h
  refine ⟨K, ?_⟩
  intro n B hc hz
  obtain ⟨hn,hsub,hfour,hdbl,hholes,hsmall,htri,hprofile⟩ := hc
  have h := hK n hn B hsub hfour hdbl hholes hsmall htri hprofile
  omega

theorem positive_of_mixed (h : MixedResidueChargeGoal) : PositiveDefectChargeGoal := by
  obtain ⟨K, hK⟩ := h
  refine ⟨K, ?_⟩
  intro n B hc _
  obtain ⟨hn,hsub,hfour,hdbl,hholes,hsmall,htri,hprofile⟩ := hc
  exact hK n hn B hsub hfour hdbl hholes hsmall htri hprofile

/-- No strengthening is silently required by this proposed decomposition. -/
theorem focused_iff_small_excess :
    (ZeroDefectChargeGoal ∧ RobustChargeGoal) ↔ SmallExcessGoal := by
  constructor
  · rintro ⟨h0, hr⟩
    exact small_excess_of_mixed_charge (mixed_charge_of_cases h0 (hr h0))
  · intro hs
    have hm := mixed_charge_of_small_excess hs
    exact ⟨zero_of_mixed hm, fun _ => positive_of_mixed hm⟩

theorem small_excess_of_focused (h0 : ZeroDefectChargeGoal) (hr : RobustChargeGoal) :
    SmallExcessGoal := focused_iff_small_excess.mp ⟨h0,hr⟩

theorem large_hole_of_focused (h0 : ZeroDefectChargeGoal) (hr : RobustChargeGoal) :
    OP02.Frontier.LargeHoleGoal := large_hole_of_small_excess (small_excess_of_focused h0 hr)

theorem k4_of_focused_and_dousse (h0 : ZeroDefectChargeGoal) (hr : RobustChargeGoal)
    (hD : OP02.Frontier.Dousse4) : OP02.K4Goal :=
  k4_of_small_excess_and_dousse (small_excess_of_focused h0 hr) hD

#print axioms zero_defect_iff
#print axioms focused_iff_small_excess
#print axioms small_excess_of_focused
#print axioms large_hole_of_focused
#print axioms k4_of_focused_and_dousse
end OP02.Focused

import K8SmallSupport
import K8FixedFourPair

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK7 OP02.SharpK8
namespace OP02.SharpK9

/-- Terminal position of a slot in one of the last three dyadic bands. -/
def lastPosition (h v : ℕ) : ℕ :=
  if h/2 < v then v else if h/4 < v then 2*v else 4*v

def unusedSlots (h : ℕ) (G : Finset ℕ) : Finset ℕ :=
  canonicalSlots h \ G.image chainCompress

/-- Each used terminal charge is the image of a real unused canonical slot. -/
def faultPositions (h : ℕ) (G : Finset ℕ) : Finset ℕ :=
  (unusedSlots h G).image (lastPosition h) ∩ Ioc (h/2) h

def shallowFaults (h : ℕ) (G : Finset ℕ) : Finset ℕ :=
  (faultPositions h G).filter (fun v => v%8 ≠ 0)

def deepFaults (h : ℕ) (G : Finset ℕ) : Finset ℕ :=
  (faultPositions h G).filter (fun v => v%8 = 0)

theorem faults_disjoint (h : ℕ) (G : Finset ℕ) :
    Disjoint (shallowFaults h G) (deepFaults h G) := by
  apply disjoint_left.mpr
  intro x hs hd
  exact (mem_filter.mp hs).2 (mem_filter.mp hd).2

theorem fault_budget {h : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (hd : DoublingFree G) :
    (shallowFaults h G).card + (deepFaults h G).card ≤ chainCapacity h-G.card := by
  classical
  have union : shallowFaults h G ∪ deepFaults h G = faultPositions h G := by
    ext x
    simp only [shallowFaults,deepFaults,mem_union,mem_filter]
    tauto
  have counted := card_union_of_disjoint (faults_disjoint h G)
  rw [union] at counted
  have inside : G.image chainCompress ⊆ canonicalSlots h := by
    rintro v hv
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hv
    exact chain_compression_mem h G sub hx
  have exactCount := card_sdiff_add_card_eq_card inside
  rw [card_image_of_injOn (chain_compression_injective h G sub hd)] at exactCount
  change (unusedSlots h G).card+G.card=chainCapacity h at exactCount
  have smaller : (faultPositions h G).card≤(unusedSlots h G).card :=
    (card_le_card (inter_subset_left : faultPositions h G ⊆ _)).trans card_image_le
  omega

theorem unused_canonical {h x : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (pos : 0<x) (up : x≤h) (can : canonical x=true)
    (absent : x∉G) (next : 2*x∉G) : x∈unusedSlots h G := by
  apply mem_sdiff.mpr
  refine ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨pos,up⟩,can⟩,?_⟩
  intro haveImage
  obtain ⟨u,hu,eq⟩ := mem_image.mp haveImage
  have posu := (mem_Icc.mp (sub hu)).1
  unfold chainCompress at eq
  split_ifs at eq with c
  · exact absent (eq ▸ hu)
  · have no : canonical u=false := by cases e : canonical u <;> simp_all
    have := (canonical_false_parent u posu no).1
    exact next ((show u=2*x by omega) ▸ hu)

private theorem top_from_slot {h x y : ℕ} {G : Finset ℕ}
    (slot : x∈unusedSlots h G) (eq : lastPosition h x=y)
    (lo : h/2<y) (up : y≤h) : y∈faultPositions h G :=
  mem_inter.mpr ⟨mem_image.mpr ⟨x,slot,eq⟩,mem_Ioc.mpr ⟨lo,up⟩⟩

theorem shallow_top_fault {h y : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (lo : h/2<y) (up : y≤h) (shape : y%2=1 ∨ y%8=4) (absent : y∉G) :
    y∈shallowFaults h G := by
  have can : canonical y=true := shape.elim (canonical_odd y) (canonical_four_residue y)
  have slot := unused_canonical sub (by omega) up can absent (fun q => by
    have := (mem_Icc.mp (sub q)).2; omega)
  exact mem_filter.mpr ⟨top_from_slot slot (by simp [lastPosition,lo]) lo up,by omega⟩

theorem shallow_half_fault {h y : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (lo : h/2<y) (up : y≤h) (shape : y%4=2) (absent : y∉G) (half : y/2∉G) :
    y∈shallowFaults h G := by
  have eq : 2*(y/2)=y := by omega
  have slot := unused_canonical sub (by omega : 0<y/2) (by omega)
    (canonical_odd _ (by omega)) half (eq.symm ▸ absent)
  have lift : lastPosition h (y/2)=y := by unfold lastPosition; split_ifs <;> omega
  exact mem_filter.mpr ⟨top_from_slot slot lift lo up,by omega⟩

private theorem terminal_of_missing {h u : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (hd : DoublingFree G) (pos : 0<u) (lo : h/2<4*u) (up : 4*u≤h)
    (can : canonical u=true) (absent : u∉G) : 4*u∈faultPositions h G := by
  by_cases middle : 2*u∈G
  · have ca : canonical (4*u)=true := (canonical_four u).trans can
    have miss : 4*u∉G := by simpa only [show 2*(2*u)=4*u by omega] using hd (2*u) middle
    have slot := unused_canonical sub (by omega) up ca miss (fun q => by
      have := (mem_Icc.mp (sub q)).2; omega)
    exact top_from_slot slot (by simp [lastPosition,lo]) lo up
  · have slot := unused_canonical sub pos (by omega) can absent middle
    exact top_from_slot slot (by unfold lastPosition; split_ifs <;> omega) lo up

theorem shallow_lower_fault {h x : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (hd : DoublingFree G) (lo : h/4/2+2<x) (up : x≤h/4) (odd : x%2=1)
    (absent : x∉G) : 4*x∈shallowFaults h G :=
  mem_filter.mpr ⟨terminal_of_missing sub hd (by omega) (by omega) (by omega)
    (canonical_odd x odd) absent,by omega⟩

theorem deep_canonical_fault {h x : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (hd : DoublingFree G) (lo : 2*(h/64)+12<x) (up : x≤4*(h/64))
    (can : canonical x=true) (absent : 4*x∉G) : 16*x∈deepFaults h G := by
  have slot := terminal_of_missing sub hd (by omega : 0<4*x) (by omega) (by omega)
    ((canonical_four x).trans can) absent
  rw [show 4*(4*x)=16*x by omega] at slot
  exact mem_filter.mpr ⟨slot,by omega⟩

end OP02.SharpK9

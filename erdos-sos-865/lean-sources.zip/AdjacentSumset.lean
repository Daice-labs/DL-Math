import AdjacentCover
open Finset
namespace OP02.EdgeBand
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot

def actualQ (n:ℕ) (B:Finset ℕ):=parityMiddle n B 0 ∪ (H0 n B).image (fun h=>h/2)
def rootSums (T G:Finset ℕ):=(T.product G).image (fun v:ℕ×ℕ=>v.1+4*v.2)

theorem root_sum_lower (T G:Finset ℕ) (hg:G.Nonempty)
    (ht:∀z∈T,z%2=1)
    (h1:(T.filter (fun z=>z%4=1)).Nonempty)
    (h3:(T.filter (fun z=>z%4=3)).Nonempty) :
    T.card+2*G.card≤(rootSums T G).card+2 := by
  let T1:=T.filter (fun z=>z%4=1)
  let T3:=T.filter (fun z=>z%4=3)
  let S:=rootSums T G
  let S1:=S.filter (fun z=>z%4=1)
  let S3:=S.filter (fun z=>z%4=3)
  let F:=G.image (fun d=>4*d)
  have hF:F.Nonempty:=hg.image _
  have hFc:F.card=G.card:=card_image_of_injective _ (by intro x y h;dsimp only at h;omega)
  have hsum:∀j,∀z∈T.filter (fun z=>z%4=j),∀y∈F,z+y∈S.filter (fun z=>z%4=j) := by
    intro j z hz y hy
    obtain ⟨d,hd,rfl⟩:=mem_image.mp hy
    obtain ⟨hzT,hzj⟩:=mem_filter.mp hz
    exact mem_filter.mpr ⟨mem_image.mpr ⟨(z,d),mem_product.mpr ⟨hzT,hd⟩,rfl⟩,by omega⟩
  have hL1:=sum_union_lower T1 F S1 h1 hF (hsum 1)
  have hL3:=sum_union_lower T3 F S3 h3 hF (hsum 3)
  have hTc:T.card=T1.card+T3.card := by
    apply partition_card
    · intro x
      simp only [T1,T3,mem_filter]
      constructor
      · intro hx
        have hxodd:=ht x hx
        by_cases h:x%4=1
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨h,_⟩|⟨h,_⟩) <;> exact h
    · intro x hx hy
      have :=(mem_filter.mp hx).2
      have :=(mem_filter.mp hy).2
      omega
  have hdis:Disjoint S1 S3 := by
    apply disjoint_left.mpr
    intro x hx hy
    have :=(mem_filter.mp hx).2
    have :=(mem_filter.mp hy).2
    omega
  have hc:=card_le_card (union_subset (filter_subset (fun z=>z%4=1) S) (filter_subset (fun z=>z%4=3) S))
  rw [card_union_of_disjoint hdis] at hc
  change T.card+2*G.card≤S.card+2
  omega

theorem missing_odd_union {n w:ℕ} {B:Finset ℕ}
    (hr:n<w ∧ w≤3*n) (ho:w%2=1) (hb:w∉B) :
    w∈missOdd n B ∪ lowOdd n B := by
  by_cases hm:w≤2*n
  · apply mem_union_left
    refine mem_sdiff.mpr ⟨oddPos_mem.mpr ⟨hr.1,hm,ho⟩,?_⟩
    intro h;exact hb (mem_inter.mp (mem_filter.mp h).1).1
  · apply mem_union_right
    apply mem_filter.mpr
    refine ⟨?_,hr.2⟩
    apply mem_filter.mpr
    refine ⟨?_,ho⟩
    rcases missing_split (n:=n) (by omega) hb with h|h
    · obtain ⟨v,hv,he⟩:=h;omega
    · exact h

theorem adjacent_translated_failure {n p z d:ℕ} {B:Finset ℕ}
    (hf:FourFree B) (hp:2*n<p) (hpB:p∈B)
    (hd:d∈quarterD n B) (hpd:p+4*d∈B)
    (hz:z∈goodAdjacent n p (actualQ n B) B) :
    z+4*d∉B ∨ z+4*d+2∉B := by
  obtain ⟨hzP,hzB,hz2B,hzQ,hclip,hpz,hpz2⟩:=mem_filter.mp hz
  have hzI:=oddPos_mem.mp hzP
  obtain ⟨hdI,hdB⟩:=mem_filter.mp hd
  have hdR:=mem_Icc.mp hdI
  have hcenter:z+(z+2)∈B := by
    have he:z+1∉parityMiddle n B 0 := by
      intro h;exact hzQ (mem_union_left _ h)
    have hh:2*(z+1)∉H0 n B := by
      intro h
      exact hzQ (mem_union_right _ (mem_image.mpr ⟨2*(z+1),h,by omega⟩))
    have h:=even_upper_present (n:=n) (v:=z+1) (by omega) (by omega) he hh
    convert h using 1 <;> omega
  by_cases h1:z+4*d∈B
  · right
    intro h2
    have hforbid:=four_forbidden B hf hdB hpB hzB hz2B
      (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      (by simpa [Nat.add_comm] using hpd)
      (by simpa [Nat.add_comm] using h1)
      (by convert h2 using 1 <;> omega) hpz
      (by convert hpz2 using 1 <;> omega) hcenter
    exact hforbid
  · exact Or.inl h1

theorem root_sum_upper {n p:ℕ} {B G:Finset ℕ}
    (hf:FourFree B) (hp:2*n<p) (hpB:p∈B)
    (hg:G⊆quarterD n B) (hpd:∀d∈G,p+4*d∈B) :
    (rootSums (goodAdjacent n p (actualQ n B) B) G).card≤
      2*((missOdd n B).card+(lowOdd n B).card) := by
  let T:=goodAdjacent n p (actualQ n B) B
  let F:=missOdd n B ∪ lowOdd n B
  have hs:rootSums T G⊆(F.product (range 2)).image (fun v:ℕ×ℕ=>v.1-2*v.2) := by
    intro w hw
    obtain ⟨⟨z,d⟩,hzd,rfl⟩:=mem_image.mp hw
    obtain ⟨hz,hd⟩:=mem_product.mp hzd
    have hzI:=oddPos_mem.mp (mem_filter.mp hz).1
    have hzclip:=(mem_filter.mp hz).2.2.2.2.1
    have hdI:=mem_Icc.mp (mem_filter.mp (hg hd)).1
    have hh:=adjacent_translated_failure hf hp hpB (hg hd) (hpd d hd) hz
    rcases hh with h|h
    · have hF:z+4*d∈F:=missing_odd_union (by omega) (by omega) h
      exact mem_image.mpr ⟨(z+4*d,0),mem_product.mpr ⟨hF,by simp⟩,by dsimp <;> omega⟩
    · have hF:z+4*d+2∈F:=missing_odd_union (by omega) (by omega) h
      exact mem_image.mpr ⟨(z+4*d+2,1),mem_product.mpr ⟨hF,by simp⟩,by dsimp <;> omega⟩
  have hc:=(card_le_card hs).trans card_image_le
  rw [product_eq_sprod,card_product,card_range] at hc
  have hu:=card_union_le (missOdd n B) (lowOdd n B)
  dsimp [T,F] at *
  omega

#print axioms root_sum_lower
#print axioms root_sum_upper
end OP02.EdgeBand

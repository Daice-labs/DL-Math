import Mathlib
open Finset Filter
open scoped Asymptotics
namespace Erdos865
noncomputable def f (N k : ℕ) : ℕ :=
  sInf {m | ∀ A ⊆ Icc 1 N, A.card ≥ m →
    ∃ S ⊆ A, S.card = k ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ A}


theorem known_k2 (N : ℕ) :
    ∀ A ⊆ Icc 1 (2 * N), A.card ≥ N + 2 →
    ∃ a ∈ A, ∃ b ∈ A, a ≠ b ∧ a + b ∈ A := by
  intro A hA hcard
  have hne : A.Nonempty := by
    rw [← Finset.card_pos]; omega
  set m := A.max' hne with hm
  have hmA : m ∈ A := Finset.max'_mem A hne
  have hmle : m ≤ 2 * N := by
    have := hA hmA
    rw [Finset.mem_Icc] at this
    omega
  have hcard' : (Icc 1 N).card < (A.erase m).card := by
    rw [Finset.card_erase_of_mem hmA, Nat.card_Icc]
    omega
  have hmaps : ∀ x ∈ A.erase m, min x (m - x) ∈ Icc 1 N := by
    intro x hx
    obtain ⟨hxm, hxA⟩ := Finset.mem_erase.mp hx
    have hxle : x ≤ m := Finset.le_max' A x hxA
    have hx1 := (Finset.mem_Icc.mp (hA hxA)).1
    rw [Finset.mem_Icc]
    omega
  obtain ⟨x, hx, y, hy, hxy, hxyeq⟩ :=
    Finset.exists_ne_map_eq_of_card_lt_of_maps_to hcard' hmaps
  obtain ⟨hxm, hxA⟩ := Finset.mem_erase.mp hx
  obtain ⟨hym, hyA⟩ := Finset.mem_erase.mp hy
  have hxle : x ≤ m := Finset.le_max' A x hxA
  have hyle : y ≤ m := Finset.le_max' A y hyA
  refine ⟨x, hxA, y, hyA, hxy, ?_⟩
  have : x + y = m := by omega
  rw [this]
  exact hmA


end Erdos865
namespace OP02
def GeneralGoal : Prop :=
    ∀ (k : ℕ) (_hk : 2 ≤ k),
    (fun N ↦ (Erdos865.f N k : ℝ)) ~[atTop] (fun N ↦ (1 / 2 : ℝ) * (1 + ∑ r ∈ Icc 1 (k - 2),
      (1 / 4 : ℝ) ^ r) * N)

def K4Goal : Prop :=
    (fun N ↦ (Erdos865.f N 4 : ℝ)) ~[atTop] (fun N ↦ (21 / 32 : ℝ) * N)
def RefutationGoal : Prop :=
  ∃ k : ℕ, 4 ≤ k ∧ ∃ ε : ℝ, 0 < ε ∧ ∀ N₀ : ℕ, ∃ N : ℕ,
    N₀ ≤ N ∧ 0 < N ∧ ∃ A : Finset ℕ, A ⊆ Icc 1 N ∧
      (A.card : ℝ) ≥ ((1 / 2 : ℝ) * (1 + ∑ r ∈ Icc 1 (k - 2), (1 / 4 : ℝ) ^ r) + ε) * N ∧
      ¬ ∃ S ⊆ A, S.card = k ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ A
end OP02

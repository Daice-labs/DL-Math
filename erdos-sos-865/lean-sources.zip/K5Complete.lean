import K5HighVertex
import K5Replacement
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 2000000

/-- The replacement is an actual internal four-clique, contradicting the
universal high-vertex theorem derived from both bands. No geometric supply is assumed. -/
theorem reduced_context_impossible (n:ℕ) (B:Finset ℕ)
    (hn:1024≤n) (hf:FiveFree B) (hd:DoublingFree B) (hq:128*totalBudget n B≤n)
    (hbudget:3*(chainDeficit n B+totalBudget n B)<n/32)
    (hk:96*(chainDeficit n B+totalBudget n B)≤n)
    (hdense:5*n+32*totalBudget n B+52<32*(quarterD n B).card)
    (hlow:¬FourFree (lower n B))
    (hedge:∃r∈quarterD n B,∃s∈quarterD n B,r≠s ∧ r+s∈quarterD n B ∧ r+s≤n/16) : False := by
  classical
  have hcBudget:=canonical_hole_total_budget n B hd
  have hcanon:3*(canonicalHoles n B).card<n/32 := by
    unfold totalBudget at hbudget; omega
  obtain ⟨r,hr,s,hs,hrs,hrsD,hsmall⟩:=hedge
  have hl:∃S⊆lower n B,S.card=4 ∧ ∀x∈S,∀y∈S,x≠y→x+y∈lower n B := by
    simpa only [FourFree,not_not] using hlow
  obtain ⟨S,hS,hSc,hpairs⟩:=hl
  obtain ⟨u,hu,v,hv,huv,hvhigh,hpar⟩:=every_lower_clique_high n r s B S hn hf hd hq hcanon hdense
    hr hs hrs hrsD hsmall hS hSc hpairs
  let V:=highThreshold n B
  let T:=S.erase v
  have hvI:=mem_Icc.mp (mem_inter.mp (hS hv)).2
  have hbud:=band_budget n 1 B hd (Or.inl rfl)
  have hV:8*V≤3*n+128 := by dsimp [V]; omega
  have hVP:V<n-V-1 := by omega
  have hTV:T⊆Icc 1 V := by
    intro x hx
    obtain ⟨hxv,hxS⟩:=mem_erase.mp hx
    have hxI:=mem_Icc.mp (mem_inter.mp (hS hxS)).2
    have hsum:=mem_Icc.mp (mem_inter.mp (hpairs x hxS v hv hxv)).2
    exact mem_Icc.mpr ⟨hxI.1,by change x≤highThreshold n B; omega⟩
  have hTc:T.card=3 := by dsimp only [T]; rw [card_erase_of_mem hv,hSc]
  have huT:u∈insert 0 T := by
    rcases mem_insert.mp hu with hu0|huS
    · exact mem_insert.mpr (Or.inl hu0)
    · exact mem_insert_of_mem (mem_erase.mpr ⟨by omega,huS⟩)
  have hparT:∀x∈insert 0 T\{u},x%2≠u%2 := by
    intro x hx
    obtain ⟨hxU,hxu⟩:=mem_sdiff.mp hx
    have hxu':x≠u := by simpa only [mem_singleton] using hxu
    have hxv:x≠v := by
      rcases mem_insert.mp hxU with hx0|hxT
      · omega
      · exact (mem_erase.mp hxT).1
    have hxS:x∈insert 0 S := by
      rcases mem_insert.mp hxU with hx0|hxT
      · exact mem_insert.mpr (Or.inl hx0)
      · exact mem_insert_of_mem (mem_erase.mp hxT).2
    exact hpar x (mem_sdiff.mpr ⟨hxS,by simp [hxu',hxv]⟩)
  have hsupply:=replacement_supply n V (chainDeficit n B) (totalBudget n B) (missingTopOdd n B).card
    hn hq hk hbud.2.2.2.2
  obtain ⟨p,hpL,hpH,hlabels⟩:=replacement_exists n V u B T hn hd hTV hTc huT hparT hV hsupply
  have hpB:p∈B := by simpa using hlabels 0 (by simp)
  have hpT:p∉T := by intro hh; have :=mem_Icc.mp (hTV hh); omega
  let S':=insert p T
  have hS'c:S'.card=4 := by simp [S',hpT,hTc]
  have hS'lower:S'⊆lower n B := by
    intro x hx
    rcases mem_insert.mp hx with hxp|hxT
    · subst x; exact mem_inter.mpr ⟨hpB,mem_Icc.mpr ⟨by omega,by omega⟩⟩
    · exact hS (mem_erase.mp hxT).2
  have hS'pairs:∀x∈S',∀y∈S',x≠y→x+y∈lower n B := by
    intro x hx y hy hxy
    rcases mem_insert.mp hx with hxp|hxT
    · subst x
      rcases mem_insert.mp hy with hyp|hyT
      · exact False.elim (hxy hyp.symm)
      · have hyI:=mem_Icc.mp (hTV hyT)
        exact mem_inter.mpr ⟨hlabels y (mem_insert_of_mem hyT),mem_Icc.mpr ⟨by omega,by omega⟩⟩
    · rcases mem_insert.mp hy with hyp|hyT
      · subst y
        have hxI:=mem_Icc.mp (hTV hxT)
        have hh:=hlabels x (mem_insert_of_mem hxT)
        rw [Nat.add_comm] at hh
        exact mem_inter.mpr ⟨hh,mem_Icc.mpr ⟨by omega,by omega⟩⟩
      · exact hpairs x (mem_erase.mp hxT).2 y (mem_erase.mp hyT).2 hxy
  obtain ⟨u',hu',v',hv',huv',hhigh',hpar'⟩:=every_lower_clique_high n r s B S' hn hf hd hq hcanon hdense
    hr hs hrs hrsD hsmall hS'lower hS'c hS'pairs
  have hv'P:v'≤n-V-1 := by
    rcases mem_insert.mp hv' with h|h
    · simpa only [h] using hpH
    · have hh:=mem_Icc.mp (hTV h); omega
  change n-v'≤V at hhigh'
  omega

/-- Complete normalized sharp k5 bound, conditional only on the fixed-order
midpoint input; the canonical-hole, two-band and replacement obligations are derived. -/
theorem complete_normalized_k5 (hD:Dousse5) : NormalizedGoal := by
  intro β hβ
  obtain ⟨N0,h0⟩:=positive_gap_reduction hD β hβ
  obtain ⟨N1,h1⟩:=exists_nat_gt (4/β)
  refine ⟨max N0 N1,?_⟩
  intro n hn B hB hf hd
  have hn0:N0≤n := by omega
  have hn1:N1≤n := by omega
  have hβn:(4:ℝ)<β*n := by
    have hr:(N1:ℝ)≤n := by exact_mod_cast hn1
    have hh:4/β<(n:ℝ) := lt_of_lt_of_le h1 hr
    have hh:4<(n:ℝ)*β := (div_lt_iff₀ hβ).mp hh
    nlinarith
  by_contra hbad
  push_neg at hbad
  have hinv:=exact_inventory n B hB hd
  have hinvR: (B.card:ℝ)+totalBudget n B=2*n+((n+1)/2:ℕ)+(quarterD n B).card := by
    have hi : B.card+totalBudget n B=2*n+(n+1)/2+(quarterD n B).card := by
      unfold totalBudget; omega
    exact_mod_cast hi
  have hhalf: (((n+1)/2:ℕ):ℝ)≤(n:ℝ)/2+1/2 := by
    have hh:2*((n+1)/2)≤n+1 := by omega
    have hhr:(2:ℝ)*((n+1)/2:ℕ)≤n+1 := by exact_mod_cast hh
    linarith
  have hgap:PositiveGap β n B := by unfold PositiveGap; linarith
  obtain ⟨hn1024,hq,hcanon,hlow,hedge,hκ⟩:=h0 n hn0 B hB hf hd hgap
  have hk:96*(chainDeficit n B+totalBudget n B)≤n := by
    have hnr:(0:ℝ)≤n := by positivity
    have hr:(96:ℝ)*(chainDeficit n B+totalBudget n B:ℕ)≤n := by nlinarith
    exact_mod_cast hr
  have hdense:5*n+32*totalBudget n B+52<32*(quarterD n B).card := by
    unfold PositiveGap at hgap
    have hr:(5:ℝ)*n+32*totalBudget n B+52<32*(quarterD n B).card := by nlinarith
    exact_mod_cast hr
  exact reduced_context_impossible n B hn1024 hf hd hq hcanon hk hdense hlow hedge

/-- Complete original-N endpoint. The sole mathematical input is Dousse5,
which also supplies Dousse4 for the checked k4 dependency. -/
theorem complete_k5_endpoint (hD:Dousse5) : K5Goal :=
  endpoint_of_normalized hD (complete_normalized_k5 hD)

#print axioms reduced_context_impossible
#print axioms complete_normalized_k5
#print axioms complete_k5_endpoint
end OP02.SharpK5

import K6QualifiedPrefix
open Finset Erdos865
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess
set_option maxHeartbeats 2000000

theorem triple_finset (A:Finset ℕ) (h:HasTriple A) :
    ∃T⊆A,T.card=3 ∧ ∀x∈T,∀y∈T,x≠y → x+y∈A := by
  classical
  obtain ⟨a,ha,b,hb,c,hc,hab,hac,hbc,habA,hacA,hbcA⟩:=h
  refine ⟨{a,b,c},?_,by simp [hab,hac,hbc],?_⟩
  · intro x hx
    simp only [mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl <;> assumption
  · intro x hx y hy hxy
    simp only [mem_insert,mem_singleton] at hx hy
    rcases hx with rfl|rfl|rfl <;> rcases hy with rfl|rfl|rfl <;>
      simp_all only [ne_eq,not_true_eq_false,Nat.add_comm]

/-- Failure of goodness forces all four residue labels exactly once. -/
theorem bad_triangle_residue_injective (T:Finset ℕ) (hc:T.card=3) (hz:0∉T)
    (hbad:¬∃j<4,∀s∈insert 0 T,s%4≠j) :
    Set.InjOn (fun t:ℕ=>t%4) (↑(insert 0 T : Finset ℕ)) := by
  classical
  have him:(insert 0 T).image (fun t=>t%4)=range 4 := by
    ext j
    constructor
    · intro hj
      obtain ⟨t,ht,rfl⟩:=mem_image.mp hj
      exact mem_range.mpr (by omega)
    · intro hj
      have hj4:=mem_range.mp hj
      by_contra hn
      apply hbad
      refine ⟨j,hj4,?_⟩
      intro t ht heq
      exact hn (mem_image.mpr ⟨t,ht,heq⟩)
  apply card_image_iff.mp
  rw [him]
  simp [hz,hc]

/-- Supplies a non-good qualified triangle from the same actual B. -/
theorem actual_bad_triangle (β:ℝ) (n u v:ℕ) (B:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hgap:PositiveGap6 β n B) (hbn:(10:ℝ)≤β*n)
    (hu:u∈lower n B) (hv:v∈lower n B) (huo:u%2=1) (hvo:v%2=1)
    (huv:u%4≠v%4) (hsum:u+v∈B)
    (huL:n<2*u) (hvL:n<2*v)
    (huH:u≤n-4*(n/16)) (hvH:v≤n-4*(n/16))
    (hbudget:3*(canonicalHoles n B).card<n/128) :
    ∃T⊆qualifiedPrefix n (n/16) u v B,T.card=3 ∧
      (∀x∈T,∀y∈T,x≠y → x+y∈quarterD n B) ∧
      Set.InjOn (fun t:ℕ=>t%4) (↑(insert 0 T : Finset ℕ)) := by
  obtain ⟨htri,hedge⟩:=actual_qualified_structures β n u v B hd hgap hbn huo hvo huv huL hvL huH hvH
  obtain ⟨T,hT,hTc,hpair⟩:=triple_finset _ htri
  have hTD:T⊆quarterD n B := fun x hx=>(mem_filter.mp (mem_filter.mp (hT hx)).1).1
  have hp:∀x∈T,∀y∈T,x≠y → x+y∈quarterD n B := by
    intro x hx y hy hxy
    exact (mem_filter.mp (mem_filter.mp (hpair x hx y hy hxy)).1).1
  refine ⟨T,hT,hTc,hp,?_⟩
  apply bad_triangle_residue_injective T hTc
  · intro hz
    have:=(mem_Icc.mp (mem_filter.mp (hTD hz)).1).1
    omega
  · intro hgood
    exact good_triangle_excluded n u v B T hf hu hv (by intro h; subst v; exact huv rfl)
      huo hvo hsum hTD hTc hp (fun x hx=>(mem_filter.mp (hT hx)).2) hgood hbudget

#print axioms bad_triangle_residue_injective
#print axioms actual_bad_triangle
end OP02.SharpK6

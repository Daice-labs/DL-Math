import K6PartialGap
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 4000000

theorem root_parity_count (Q:Finset ℕ) (r:ℕ)
    (hi:Set.InjOn (fun t:ℕ=>t%4) Q) :
    (Q.filter (fun t=>t%2=r)).card≤2 := by
  classical
  let F:=Q.filter (fun t=>t%2=r)
  have hif:Set.InjOn (fun t:ℕ=>t%4) F := hi.mono (by intro t ht; exact (mem_filter.mp ht).1)
  by_cases hr:r=0
  · have hs:F.image (fun t=>t%4)⊆{0,2} := by
      intro x hx
      obtain ⟨t,ht,rfl⟩:=mem_image.mp hx
      have:=(mem_filter.mp ht).2
      simp only [mem_insert,mem_singleton]
      omega
    have hc:=card_le_card hs
    rw [card_image_of_injOn hif] at hc
    exact le_trans hc card_le_two
  · have hs:F.image (fun t=>t%4)⊆{1,3} := by
      intro x hx
      obtain ⟨t,ht,rfl⟩:=mem_image.mp hx
      have:=(mem_filter.mp ht).2
      simp only [mem_insert,mem_singleton]
      omega
    have hc:=card_le_card hs
    rw [card_image_of_injOn hif] at hc
    exact le_trans hc card_le_two

theorem second_offset_load (u v:ℕ) (T:Finset ℕ)
    (hu:u%2=1) (hv:v%2=1) (hopp:u%4≠v%4)
    (hi:Set.InjOn (fun t:ℕ=>t%4) (↑(insert 0 T : Finset ℕ))) :
    ∀j:ℕ,((insert 0 (insert u (insert v (T.image (fun t=>4*t))))).filter (fun z=>z%8=j)).card≤2 := by
  classical
  let Q:=insert 0 T
  intro j
  by_cases hj:j%2=0
  · have hsub:((insert 0 (insert u (insert v (T.image (fun t=>4*t))))).filter (fun z=>z%8=j))⊆
      (Q.filter (fun t=>t%2=j/4)).image (fun t=>4*t) := by
      intro z hz
      obtain ⟨hz,hzr⟩:=mem_filter.mp hz
      rcases mem_insert.mp hz with rfl|hz
      · exact mem_image.mpr ⟨0,mem_filter.mpr ⟨by simp [Q],by omega⟩,by omega⟩
      · rcases mem_insert.mp hz with rfl|hz
        · omega
        · rcases mem_insert.mp hz with rfl|hz
          · omega
          · obtain ⟨t,ht,rfl⟩:=mem_image.mp hz
            exact mem_image.mpr ⟨t,mem_filter.mpr ⟨mem_insert_of_mem ht,by omega⟩,rfl⟩
    exact le_trans (card_le_card hsub) (le_trans card_image_le (root_parity_count Q (j/4) hi))
  · have hsub:((insert 0 (insert u (insert v (T.image (fun t=>4*t))))).filter (fun z=>z%8=j))⊆{u,v} := by
      intro z hz
      obtain ⟨hz,hzr⟩:=mem_filter.mp hz
      rcases mem_insert.mp hz with rfl|hz
      · omega
      · rcases mem_insert.mp hz with rfl|hz
        · simp
        · rcases mem_insert.mp hz with rfl|hz
          · simp
          · obtain ⟨t,ht,rfl⟩:=mem_image.mp hz
            omega
    exact le_trans (card_le_card hsub) card_le_two

theorem exceptional_offset_unique (u v:ℕ) (T:Finset ℕ)
    (hu:u%2=1) (hv:v%2=1)
    (hi:Set.InjOn (fun t:ℕ=>t%4) (↑(insert 0 T : Finset ℕ))) :
    ((insert 0 (insert u (insert v (T.image (fun t=>4*t))))).filter (fun z=>z%16=8)).card≤1 := by
  classical
  apply card_le_one.mpr
  intro x hx y hy
  obtain ⟨hx,hxm⟩:=mem_filter.mp hx
  obtain ⟨hy,hym⟩:=mem_filter.mp hy
  have hroot (z:ℕ) (hz:z∈insert 0 (insert u (insert v (T.image (fun t=>4*t))))) (hzm:z%16=8) :
      ∃t∈T,z=4*t := by
    rcases mem_insert.mp hz with rfl|hz
    · omega
    · rcases mem_insert.mp hz with rfl|hz
      · omega
      · rcases mem_insert.mp hz with rfl|hz
        · omega
        · obtain ⟨t,ht,rfl⟩:=mem_image.mp hz
          exact ⟨t,ht,rfl⟩
  obtain ⟨a,ha,rfl⟩:=hroot x hx hxm
  obtain ⟨b,hb,rfl⟩:=hroot y hy hym
  have hab:a=b:=hi (mem_insert_of_mem ha) (mem_insert_of_mem hb) (by dsimp; omega)
  omega

/-- The unique valuation-three class is the only noncanonical possibility. -/
theorem second_pivot_canonical_or_exception (u v p:ℕ) (T:Finset ℕ)
    (hu:u%2=1) (hv:v%2=1) (hp:p%32=16)
    (hi:Set.InjOn (fun t:ℕ=>t%4) (↑(insert 0 T : Finset ℕ))) :
    ∀s∈insert 0 (insert u (insert v (T.image (fun t=>4*t)))),canonical (p+s)=true ∨ (p+s)%16=8 := by
  intro s hs
  have hpc:canonical p=true:=canonical_selected p 0 (by omega) (by simp only [mem_insert,mem_singleton]; omega)
  rcases mem_insert.mp hs with rfl|hs
  · exact Or.inl (by simpa using hpc)
  · rcases mem_insert.mp hs with rfl|hs
    · exact Or.inl (canonical_odd _ (by omega))
    · rcases mem_insert.mp hs with rfl|hs
      · exact Or.inl (canonical_odd _ (by omega))
      · obtain ⟨t,ht,rfl⟩:=mem_image.mp hs
        by_cases hto:t%2=1
        · exact Or.inl (canonical_four_residue _ (by omega))
        · by_cases ht0:t%4=0
          · have heq:t=0:=hi (mem_insert_of_mem ht) (by simp) (by dsimp; omega)
            subst t
            exact Or.inl (by simpa using hpc)
          · exact Or.inr (by omega)

#print axioms second_offset_load
#print axioms exceptional_offset_unique
#print axioms second_pivot_canonical_or_exception
end OP02.SharpK6

import K8RothEndpoint

open Finset OP02.Midpoint
namespace OP02.AllOrders

private def Separated (S : Finset ℕ) (g : ℕ) : Prop :=
  ∀ x ∈ S, ∀ y ∈ S, x < y → x + g ≤ y

private def MidpointsIn (S A : Finset ℕ) : Prop :=
  ∀ x ∈ S, ∀ y ∈ S, ∃ z ∈ A, x + y = 2*z

/-- A start and its translate are two corners. Between copies, an old
midpoint translates by exactly one step. -/
private theorem double_corners {S A : Finset ℕ} {d g : ℕ}
    (hs : S ⊆ tripleStarts A d) (hm : MidpointsIn S (tripleStarts A d))
    (hg : 0 < g) (hd : g ≤ d) (hsplit : Separated S (2*d+g)) :
    ∃ U ⊆ A, U.card = 2*S.card ∧ Separated U g ∧ MidpointsIn U A := by
  classical
  let V := S.image (fun x => x+2*d)
  have hv {x} (hx : x ∈ V) : ∃ t ∈ S, t+2*d=x := mem_image.mp hx
  have dis : Disjoint S V := by
    apply disjoint_left.mpr
    intro x hx hx'
    obtain ⟨t,ht,rfl⟩ := hv hx'
    have big := hsplit t ht (t+2*d) hx (by omega)
    omega
  let U := S ∪ V
  have origin {x} (hx : x ∈ U) : ∃ t ∈ S, x=t ∨ x=t+2*d := by
    rcases mem_union.mp hx with h | h
    · exact ⟨x,h,Or.inl rfl⟩
    · obtain ⟨t,ht,rfl⟩ := hv h
      exact ⟨t,ht,Or.inr rfl⟩
  refine ⟨U,?_,?_,?_,?_⟩
  · intro x hx
    obtain ⟨t,ht,hx'⟩ := origin hx
    have mem := mem_tripleStarts (hs ht)
    rcases hx' with rfl|rfl
    · exact mem.1
    · exact mem.2.2
  · rw [show U = S ∪ V from rfl, card_union_of_disjoint dis]
    have hc : V.card = S.card :=
      card_image_of_injective _ (fun _ _ h => Nat.add_right_cancel h)
    omega
  · intro x hx y hy hxy
    obtain ⟨s,hs,hx'⟩ := origin hx
    obtain ⟨t,ht,hy'⟩ := origin hy
    have a := hsplit s hs t ht
    have b := hsplit t ht s hs
    rcases hx' with rfl|rfl <;> rcases hy' with rfl|rfl <;> omega
  · intro x hx y hy
    obtain ⟨s,hS,hx'⟩ := origin hx
    obtain ⟨t,hT,hy'⟩ := origin hy
    obtain ⟨z,hz,he⟩ := hm s hS t hT
    obtain ⟨m0,m1,m2⟩ := mem_tripleStarts hz
    rcases hx' with rfl|rfl <;> rcases hy' with rfl|rfl
    · exact ⟨z,m0,he⟩
    · exact ⟨z+d,m1,by omega⟩
    · exact ⟨z+d,m1,by omega⟩
    · exact ⟨z+2*d,m2,by omega⟩

/-- All density and spacing thresholds are chosen before the physical input.
The recursive spacing absorbs every value of the current popular step. -/
theorem corners_uniform (m : ℕ) : ∀ q g : ℕ, 0<q → 0<g →
    ∃ M : ℕ, 1≤M ∧ ∀ N : ℕ, M≤N → ∀ A : Finset ℕ, A⊆Icc 1 N →
    N≤q*A.card → ∃ S⊆A, S.card=2^m ∧
      (∀ x ∈ S, ∀ y ∈ S, x<y → x+g≤y) ∧
      ∀ x ∈ S, ∀ y ∈ S, ∃ z ∈ A, x+y=2*z := by
  induction m with
  | zero =>
    intro q g hq hg
    refine ⟨1,le_rfl,?_⟩
    intro N hN A _ mass
    have h : A.card ≠ 0 := by
      intro bad
      simp [bad] at mass
      omega
    obtain ⟨t,ht⟩ := card_pos.mp (Nat.pos_of_ne_zero h)
    refine ⟨{t}, by simpa using ht, by simp, ?_, ?_⟩
    · simp
    · simpa using (show ∃ z∈A, t+t=2*z from ⟨t,ht,by omega⟩)
  | succ m ih =>
    intro q g hq hg
    obtain ⟨K,M,hK,_,pop⟩ := popular_bounded_step q hq
    obtain ⟨L,hL⟩ := pop g hg
    obtain ⟨V,hV,rec⟩ := ih K (2*(g*M)+g) hK (by omega)
    refine ⟨max V L,by omega,?_⟩
    intro N hN A hA mass
    obtain ⟨d,hd,htop,starts⟩ := hL N (by omega) A hA mass
    obtain ⟨S,hs,hc,sep,hm⟩ := rec N (by omega) _ ((tripleStarts_subset A d).trans hA) starts
    obtain ⟨U,hu,count,hsep,hmids⟩ := double_corners hs hm hg hd
      (fun x hx y hy hxy => by have := sep x hx y hy hxy; omega)
    exact ⟨U,hu,by rw [count,hc,pow_succ,mul_comm],hsep,hmids⟩

theorem midpoints_all : ∀ k : ℕ, 2 ≤ k → ∀ δ : ℝ, 0 < δ →
    ∃ N₀ : ℕ, 1 ≤ N₀ ∧ ∀ N : ℕ, N₀ ≤ N → ∀ A : Finset ℕ,
      A ⊆ Icc 1 N → δ * (N : ℝ) ≤ (A.card : ℝ) →
      ∃ S ⊆ A, S.card = k ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y →
        ∃ z ∈ A, x + y = 2 * z := by
  intro k _ δ hδ
  obtain ⟨q,hq⟩ := exists_nat_gt (1/δ)
  have dens := (div_lt_iff₀ hδ).mp hq
  have hpos : 0<q := by
    by_contra! hz
    have : q=0 := by omega
    norm_num [this] at dens
  obtain ⟨M,hM,rec⟩ := corners_uniform k q 1 hpos (by decide)
  refine ⟨M,hM,?_⟩
  intro N hN A hA hcard
  have mass : N≤q*A.card := by
    have t : (N:ℝ) ≤ (q:ℝ)*A.card := calc
      (N:ℝ) ≤ ((q:ℝ)*δ)*N := by nlinarith only [mul_nonneg (sub_nonneg.mpr dens.le) (show (0:ℝ)≤N by positivity)]
      _ = (q:ℝ)*(δ*N) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left hcard (by positivity)
    exact_mod_cast t
  obtain ⟨U,hU,hc,_,hm⟩ := rec N hN A hA mass
  have hk : k ≤ 2^k := by
    clear * - k
    induction k with
    | zero => decide
    | succ n ih =>
      rw [pow_succ]
      have : 0 < 2^n := by positivity
      omega
  obtain ⟨S,hS,hSc⟩ := exists_subset_card_eq (show k≤U.card by omega)
  exact ⟨S,hS.trans hU,hSc,fun x hx y hy _ => hm x (hS hx) y (hS hy)⟩

end OP02.AllOrders

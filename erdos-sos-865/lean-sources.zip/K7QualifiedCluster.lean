import K7CentralPivot
import K7OnWindow
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7

private theorem canonical4mod8 {r:ℕ} (hr:r%8=4) : canonical r=true := by
  rw [show r=4*(r/4) by omega,canonical_four]
  exact canonical_odd _ (by omega)

private theorem canonical16 {r:ℕ} (hr:r%32=16) : canonical r=true := by
  rw [show r=4*(4*(r/16)) by omega,canonical_four,canonical_four]
  exact canonical_odd _ (by omega)

private theorem three_root_pivot {n a c b p χ:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B) (hn:65536≤n) (hc:384*(chainDeficit n B+totalBudget n B)≤n/4)
    (ha:0<a) (hac:a<c) (hcb:c<b) (hb:4*b≤n/4)
    (hop:p%2=1) (hoχ:χ%2=1) (hpH:p≤n/4) (hχH:χ≤n/4)
    (hpat:(a%2=0 ∧ c%2=0 ∧ b%2=1) ∨ (a%2=1 ∧ c%2=1 ∧ b%4=0)) :
    ∃ r:ℕ, n/4/2<r ∧ 4*r≤3*(n/4) ∧
     r∈quarterD n B ∧ r+a∈quarterD n B ∧ r+c∈quarterD n B ∧ r+b∈quarterD n B ∧
     4*r+p∈B ∧ 4*r+χ∈B := by
  classical
  let H:=n/4
  let O:Finset ℕ:={0,a,c,b}
  let m:=if a%2=0 then 8 else if b%8=0 then 8 else 32
  let v:=if a%2=0 then (12-b%8)%8 else if b%8=0 then 4 else 16
  let l:=if a%2=0 then 4 else 2
  let P:=progression (H/2) (3*H/4) m v
  let D:=quarterD n B
  let T:=topMissing H D
  let G:=passes P O D
  let F:=P\G
  let A:=missingTopOdd n B
  have hm:m=4 ∨ m=8 ∨ m=32:=by dsimp [m];split_ifs <;> decide
  have hv:v < m:=by dsimp [v,m];split_ifs <;> omega
  have pdat {r:ℕ} (hr:r∈P): H/2<r ∧ r≤3*H/4 ∧ r%m=v:=by
    obtain ⟨hI,hv'⟩:=mem_filter.mp hr;exact ⟨(mem_Ioc.mp hI).1,(mem_Ioc.mp hI).2,hv'⟩
  have hpar:∀r∈P,r%2=v%2:=by
    intro r hr;have hh:=pdat hr;dsimp only [m,v] at hh ⊢;split_ifs at * <;> omega
  have hcan:∀r∈P,∀x∈O,canonical (r+x)=true:=by
    intro r hr x hx;have hh:=pdat hr
    simp only [O,mem_insert,mem_singleton] at hx
    rcases hpat with ⟨ha',hc',hb'⟩|⟨ha',hc',hb'⟩
    · dsimp only [m,v] at hh;rw [if_pos ha',if_pos ha'] at hh
      rcases hx with rfl|rfl|rfl|rfl <;> first | exact canonical_odd _ (by omega) | exact canonical4mod8 (by omega)
    · have ha0:a%2≠0:=by omega
      dsimp only [m,v] at hh;rw [if_neg ha0,if_neg ha0] at hh
      by_cases hb0:b%8=0
      · rw [if_pos hb0,if_pos hb0] at hh
        rcases hx with rfl|rfl|rfl|rfl <;> first | exact canonical_odd _ (by omega) | exact canonical4mod8 (by omega)
      · rw [if_neg hb0,if_neg hb0] at hh
        rcases hx with rfl|rfl|rfl|rfl <;> first | exact canonical_odd _ (by omega) | exact canonical4mod8 (by omega) | exact canonical16 (by omega)
  have ht:T.card≤chainDeficit n B:=by
    have hh:=chain_capacity_with_top_loss H D (filter_subset _ _) (quarter_doubling_free n B hd)
    dsimp [T,D,H,chainDeficit] at *;omega
  have hcA:A.card≤totalBudget n B:=by have h:=missingTopOdd_le_deficit n B hd;unfold totalBudget;dsimp [A];omega
  have hx:∀x∈O,x≤ b:=by intro x hx;simp only [O,mem_insert,mem_singleton] at hx;rcases hx with rfl|rfl|rfl|rfl <;> omega
  have hbd:=shift_losses P O D T 2 (v%2) l hpar (by
    intro r hr x hx' hab;have hrr:=pdat hr;have hxb:=hx x hx'
    have hh:4*b≤H:=hb
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hcan r hr x hx'⟩,by omega,hab⟩) (by
    intro z hz;dsimp only [l]
    split_ifs with ha'
    · exact (card_filter_le _ _).trans (@card_le_four ℕ _ 0 a c b)
    · obtain ⟨ha1,hc1,hb4⟩:=hpat.resolve_left (fun h=>ha' h.1)
      by_cases hxpar:z%2=(v%2)%2
      · apply le_trans (card_le_card (t:={0,b}) _) card_le_two
        intro x hx';obtain ⟨hh,hr⟩:=mem_filter.mp hx';simp only [O,mem_insert,mem_singleton] at hh ⊢
        rcases hh with rfl|rfl|rfl|rfl <;>first | tauto | omega
      · apply le_trans (card_le_card (t:={a,c}) _) card_le_two
        intro x hx';obtain ⟨hh,hr⟩:=mem_filter.mp hx';simp only [O,mem_insert,mem_singleton] at hh ⊢
        rcases hh with rfl|rfl|rfl|rfl <;>first | tauto | omega)
  have hpart:=card_sdiff_add_card_eq_card (filter_subset _ _ :G⊆P)
  change F.card+G.card=P.card at hpart
  change P.card≤G.card+l*T.card at hbd
  have fail {z:ℕ} (hz:z%2=1) (hzH:z≤n/4) : (P.filter (fun r=>4*r+z∉B)).card≤A.card:=by
    apply card_le_card_of_injOn (fun r:ℕ=>4*r+z)
    · intro r hr;obtain ⟨hP,hf⟩:=mem_filter.mp hr;have hh:=pdat hP
      change 4*r+z∈missingTopOdd n B
      dsimp only [H] at hh
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega,hf⟩
    · intro x hx y hy hh;change 4*x+z=4*y+z at hh;omega
  have h1:=fail hop hpH; have h2:=fail hoχ hχH
  have hcnt:=progression_lower (H/2) (3*H/4) m v hm hv
  change _≤P.card at hcnt
  have surplus:F.card+2*A.card<P.card:=by
    dsimp only [m,l] at hcnt hbd;dsimp only [H] at hcnt
    split_ifs at * <;> omega
  have hex:∃r∈G,4*r+p∈B ∧ 4*r+χ∈B:=by
    by_contra! hh
    have hsub:G⊆(P.filter (fun r=>4*r+p∉B))∪(P.filter (fun r=>4*r+χ∉B)):=by
      intro r hr;have hP:=(mem_filter.mp hr).1
      by_cases hp:4*r+p∈B
      · exact mem_union_right _ (mem_filter.mpr ⟨hP,hh r hr hp⟩)
      · exact mem_union_left _ (mem_filter.mpr ⟨hP,hp⟩)
    have bnd:=(card_le_card hsub).trans (card_union_le _ _);omega
  obtain ⟨r,hr,hp,hχ⟩:=hex
  obtain ⟨hP,hgood⟩:=mem_filter.mp hr;have hpr:=pdat hP
  exact ⟨r,hpr.1,by change 4*r≤3*H;omega,by simpa using hgood 0 (by simp [O]),hgood a (by simp [O]),
    hgood c (by simp [O]),hgood b (by simp [O]),hp,hχ⟩

/-- This specializes J0 to the two tester types guaranteed by the O2
construction. The two odds need no ordering relative to the three evens. -/
theorem qualified_cluster_impossible {n a c b p χ:ℕ} {B:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hgap:MiddleGap7 n B)
    (hc:384*(chainDeficit n B+totalBudget n B)≤n/4) (hn:65536≤n)
    (ha:0<a) (hac:a<c) (hcb:c<b) (hop:p%2=1) (hχ:χ%2=1)
    (hpat:(a%2=0 ∧ c%2=0 ∧ b%2=1) ∨ (a%2=1 ∧ c%2=1 ∧ b%4=0))
    (hs:InternalFive (B∩Icc 1 (n/4)) {4*a,4*c,4*b,p,χ}) : False := by
  classical
  let S:Finset ℕ:={4*a,4*c,4*b,p,χ}
  have caps:∀x∈S,x≤n/4:=fun x hx=>(mem_Icc.mp (mem_inter.mp (hs.2.1 hx)).2).2
  obtain ⟨r,hr,hr',hrB,hra,hrc,hrb,hp,hχ'⟩:=three_root_pivot hd hn hc ha hac hcb
    (caps _ (by simp [S])) hop hχ (caps _ (by simp [S])) (caps _ (by simp [S])) hpat
  have rB:=(mem_filter.mp hrB).2
  have hroot {x:ℕ} (hx:r+x∈quarterD n B):4*r+4*x∈B:=by simpa only [Nat.mul_add] using (mem_filter.mp hx).2
  have old:internalOn B S:=⟨fun x hx=>(mem_inter.mp (hs.2.1 hx)).1,fun x hx y hy hne=>(mem_inter.mp (hs.2.2 x hx y hy hne)).1⟩
  have new:=append_clique old rB (by
    intro x hx;simp only [S,mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl|rfl|rfl <;>first | assumption | exact hroot hra | exact hroot hrc | exact hroot hrb)
  have rnot:4*r∉S:=by intro hh;have :=caps (4*r) hh;omega
  apply pv_six hf hd hgap hn (by omega) new (by rw [card_insert_of_notMem rnot];have hh:S.card=5:=hs.1;omega)
  · intro x hx;rcases mem_insert.mp hx with rfl|hx
    · omega
    · have :=caps x hx;omega
  · intro x hx hEven
    rcases mem_insert.mp hx with h|hx
    · omega
    · have :=caps x hx
      simp only [S,mem_insert,mem_singleton] at hx
      rcases hx with rfl|rfl|rfl|rfl|rfl <;> omega

theorem qualified_J0_exclusion {n:ℕ} {B:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hgap:MiddleGap7 n B)
    (hc:384*(chainDeficit n B+totalBudget n B)≤n/4) (hn:65536≤n) : ¬qualifiedJ0 n B := by
  rintro ⟨a,c,b,p,χ,ha,hac,hcb,_,_,ho,hχ,_,hpat,hs⟩
  exact qualified_cluster_impossible hf hd hgap hc hn ha hac hcb ho hχ hpat hs
end OP02.SharpK7

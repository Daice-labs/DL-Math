import K9GeometryComplete

open Finset
namespace OP02.AllOrders

noncomputable def coeff (k : ℕ) : ℝ := (2/3:ℝ)*(1-(1/4:ℝ)^(k-1))

def alpha256 (k : ℕ) : ℕ :=
  if k ≤ 7 then 64 else if k ≤ 9 then 48 else if k = 10 then 44 else if k = 11 then 42 else 52

def gamma256 (k : ℕ) : ℕ :=
  if k ≤ 7 then 192 else if k = 8 then 176 else if k = 9 then 168 else if k = 10 then 154 else if k = 11 then 149 else 144

def Sparse (F : Finset ℕ) : Prop :=
  ∃ c : ℕ, (c = 1 ∨ c = 3) ∧ (F.filter (fun x => x % 4 = c)).card ≤ 3

structure ShapeAt (k T : ℕ) (A F : Finset ℕ) (z : ℕ) : Prop where
  clique : OP02.SharpK8.Internal k A F
  top : z ∈ F
  above : T < 2*z
  height : 256*z ≤ gamma256 k * T
  small : ∀ x ∈ F, x ≠ z → 256*x ≤ alpha256 k * T
  sparse : Sparse F

def Shaped (k : ℕ) : Prop :=
  ∀ η : ℝ, 0 < η → ∃ M : ℕ, ∀ T : ℕ, M ≤ T → ∀ A : Finset ℕ,
    A ⊆ Icc 1 T → OP02.FewHole.DoublingFree A → (coeff k + η)*(T:ℝ) ≤ A.card →
    ∃ F z, ShapeAt k T A F z

end OP02.AllOrders

import K9OuterPhases

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK7 OP02.SharpK8
namespace OP02.SharpK9

/-- A four in the actual inner prefix whose offsets miss a residue has all four
contacts to an upper root of the same set. -/
theorem inner_five_missing_class {h : ℕ} {G T : Finset ℕ}
    (sub : G⊆Icc 1 h) (hd : DoublingFree G)
    (budget : 384*(chainCapacity h-G.card+1)<h)
    (seed : Internal 4 (G∩Icc 1 (h/4)) T)
    (missing : ∃a<4,∀x∈insert 0 T,x%4≠a) : InnerFive h G := by
  classical
  let O := insert 0 T
  have nz : 0∉T := by
    intro h0
    have hh := (mem_Icc.mp (mem_inter.mp (seed.1 h0)).2).1
    omega
  have cardO : O.card=5 := by simp [O,nz,seed.2.1]
  obtain ⟨a,ha,empty,cs,loads⟩ := inner_cells cardO missing
  obtain ⟨d,r,period,hr,fast,phase⟩ := outer_phase ha cs
  let L := if d=8 then 5 else 3
  let E := topMissing h G
  let Y := progression (h/2) (3*h/4) d r
  have sz := progression_lower (h/2) (3*h/4) d r (Or.inr period) hr
  change (3*h/4-h/2)/d≤Y.card at sz
  have cap := chain_capacity_with_top_loss h G sub hd
  have hE : E.card≤chainCapacity h-G.card := by dsimp only [E]; omega
  have enough : L*E.card<Y.card := by
    rcases period with h8|h32
    · subst d; simp only [L,if_true]; omega
    · subst d; simp only [L,show ¬(32:ℕ)=8 by decide,if_false]; omega
  have small : ∀x∈T,x≤h/4 := fun _ hx => (mem_Icc.mp (mem_inter.mp (seed.1 hx)).2).2
  have win (y : ℕ) (hy : y∈Y) : h/2<y ∧ y≤3*h/4 ∧ y%d=r :=
    ⟨(mem_Ioc.mp (mem_filter.mp hy).1).1,(mem_Ioc.mp (mem_filter.mp hy).1).2,
      (mem_filter.mp hy).2⟩
  have cnt := shift_losses Y O G E 4 (r%4) L (by
    intro y hy
    have pr := (win y hy).2.2
    rcases period with h8|h32 <;> subst d <;> omega) (by
    intro y hy u hu miss
    obtain ⟨lo,hi,pr⟩ := win y hy
    have bound : u≤h/4 := by
      rcases mem_insert.mp hu with rfl|hh
      · omega
      · exact small u hh
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,
      (phase y pr).2 u hu (empty u hu)⟩,by omega,miss⟩) (by
    intro z _
    by_cases quick : d=8
    · simp only [L,if_pos quick]
      exact (card_filter_le _ _).trans cardO.le
    · simp only [L,if_neg quick]
      obtain all := loads.resolve_left (fun hs=>quick (fast hs))
      let j := (z%4+4-r%4)%4
      apply (card_le_card (t:=residueCell O 4 j) ?_).trans (all j (Nat.mod_lt _ (by decide)))
      intro s hs
      obtain ⟨hm,he⟩ := mem_filter.mp hs
      exact mem_filter.mpr ⟨hm,by dsimp only [j]; omega⟩)
  obtain ⟨y,hy⟩ := card_pos.mp (show 0<(passes Y O G).card by omega)
  obtain ⟨hyY,pass⟩ := mem_filter.mp hy
  obtain ⟨lo,hi,_⟩ := win y hyY
  have fresh : y∉T := fun hyT => by have := small y hyT; omega
  refine ⟨T,y,seed.2.1,fresh,?_,by omega,by omega,small⟩
  exact internal_insert (internal_mono seed inter_subset_left)
    (by simpa using pass 0 (mem_insert_self _ _)) fresh
    (fun x hx=>pass x (mem_insert_of_mem hx))

end OP02.SharpK9

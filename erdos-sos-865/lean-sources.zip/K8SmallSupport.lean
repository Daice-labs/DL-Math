import K8Shell
import K7Budget
import K8UpperSixTools

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK8

theorem top_in_prefix (h : ℕ) (D : Finset ℕ) :
    unmatchedTop h (D∩Icc 1 h) = unmatchedTop h D := by
  ext y
  simp only [unmatchedTop,mem_filter,mem_Ioc,mem_inter,mem_Icc]
  constructor
  · rintro ⟨hy,missing,allD⟩
    refine ⟨hy,fun hh=>missing ⟨hh,by omega,hy.2⟩,?_⟩
    intro x hx e
    exact allD x ⟨hx,by omega,by omega⟩ e
  · rintro ⟨hy,missing,allD⟩
    exact ⟨hy,fun hh=>missing hh.1,fun x hx => allD x hx.1⟩

theorem radial_identity (h : ℕ) (D : Finset ℕ) (hd : DoublingFree D) :
    (lower (h/4) D).card + (h+1)/2 = (lower h D).card + (unmatchedTop h D).card := by
  have c := top_band_cancellation h (D∩Icc 1 h) inter_subset_right
    (fun x hx h2 => hd x (mem_inter.mp hx).1 (mem_inter.mp h2).1)
  have eq : (D∩Icc 1 h)∩Icc 1 (h/4) = lower (h/4) D := by
    ext x; simp only [lower,mem_inter,mem_Icc]
    exact ⟨fun t=>⟨t.1.1,t.2⟩,fun t=>⟨⟨t.1,t.2.1,by omega⟩,t.2⟩⟩
  rwa [eq,top_in_prefix] at c

/-- Three radial cuts and the nonmultiple-of-four compression give an exact-budget reflection surplus. -/
theorem fixed_pair_surplus {β : ℝ} {n : ℕ} {B : Finset ℕ}
    (hd : DoublingFree B) (hg : SignedGap β n B) :
    let H := n/4
    let D := quarterD n B
    let Z := quarterD (H/64) D
    ((H/256+1)/2:ℕ) + (totalBudget n B:ℝ) + β*n + (unmatchedTop H D).card +
        (unmatchedTop (H/4) D).card + (unmatchedTop (H/16) D).card - 4 ≤ Z.card := by
  dsimp only
  let H := n/4
  let D := quarterD n B
  let Z := quarterD (H/64) D
  have f := quarter_doubling_free n B hd
  have a := radial_identity H D f
  have b := radial_identity (H/4) D f
  have c := radial_identity (H/16) D f
  rw [show H/4/4=H/16 by omega] at b
  rw [show H/16/4=H/64 by omega] at c
  have top : lower H D = D := inter_eq_left.mpr (filter_subset _ _)
  rw [top] at a
  have d := lower_card_eq (H/64) D
  have e := residue_card_le (H/64) D f
  have cs : D.card + (unmatchedTop H D).card + (unmatchedTop (H/4) D).card +
      (unmatchedTop (H/16) D).card ≤ Z.card + (H+1)/2 + (H/4+1)/2 + (H/16+1)/2 + (H/64+1)/2 := by
    dsimp [Z];omega
  have floor : 512*((H+1)/2+(H/4+1)/2+(H/16+1)/2+(H/64+1)/2+(H/256+1)/2) ≤ 341*H+2048 := by omega
  have fr : (512:ℝ)*(((H+1)/2:ℕ)+((H/4+1)/2:ℕ)+((H/16+1)/2:ℕ)+((H/64+1)/2:ℕ)+((H/256+1)/2:ℕ)) ≤ 341*(H:ℝ)+2048 := by exact_mod_cast floor
  have cr : (D.card:ℝ)+(unmatchedTop H D).card+(unmatchedTop (H/4) D).card+(unmatchedTop (H/16) D).card ≤ (Z.card:ℝ)+((H+1)/2:ℕ)+((H/4+1)/2:ℕ)+((H/16+1)/2:ℕ)+((H/64+1)/2:ℕ) := by exact_mod_cast cs
  have hn : 4*(H:ℝ)≤n := by exact_mod_cast (show 4*H≤n by dsimp [H];omega)
  change (341/2048+β)*(n:ℝ) ≤ (D.card:ℝ)-totalBudget n B at hg
  change (((H/256+1)/2:ℕ):ℝ)+_+_+_+_+_-4≤(Z.card:ℝ)
  linarith only [hg,fr,cr,hn]

theorem fixed_actual_pairs {β : ℝ} {n : ℕ} {B : Finset ℕ}
    (hd : DoublingFree B) (hg : SignedGap β n B) (room : 4 < β*n) :
    let H := n/4
    let D := quarterD n B
    let Z := quarterD (H/64) D
    ∃ e∈Z, e%2=0 ∧ (∀x∈Z,x%2=0→x≤e) ∧
      (totalBudget n B:ℝ)+β*n+(unmatchedTop H D).card+(unmatchedTop (H/4) D).card+
        (unmatchedTop (H/16) D).card-4 ≤ (OP02.SharpK7.reflectionPairs Z e).card := by
  dsimp only
  let H := n/4
  let D := quarterD n B
  let Z := quarterD (H/64) D
  have h := fixed_pair_surplus hd hg
  change (((H/256+1)/2:ℕ):ℝ)+_+_+_+_+_-4≤(Z.card:ℝ) at h
  have big : ((H/256+1)/2:ℕ)<Z.card := by
    have nn : (0:ℝ) ≤ totalBudget n B := by positivity
    exact_mod_cast (show (((H/256+1)/2:ℕ):ℝ)<Z.card by linarith only [h,room,nn,Nat.cast_nonneg (α:=ℝ) (unmatchedTop H D).card,Nat.cast_nonneg (α:=ℝ) (unmatchedTop (H/4) D).card,Nat.cast_nonneg (α:=ℝ) (unmatchedTop (H/16) D).card])
  have zsub : Z⊆Icc 1 (H/256) := by change Z⊆_;rw [show H/256=H/64/4 by omega];exact filter_subset _ _
  obtain ⟨e,he,ee,hm,c⟩ := OP02.SharpK7.find_reflection_sum (H/256) Z zsub
    (quarter_doubling_free _ _ (quarter_doubling_free n B hd)) big
  refine ⟨e,he,ee,hm,?_⟩
  have cr : (Z.card:ℝ) ≤ (((H/256+1)/2:ℕ):ℝ)+(OP02.SharpK7.reflectionPairs Z e).card := by exact_mod_cast c
  change (totalBudget n B:ℝ)+β*n+(unmatchedTop H D).card+(unmatchedTop (H/4) D).card+
    (unmatchedTop (H/16) D).card-4 ≤ (OP02.SharpK7.reflectionPairs Z e).card
  linarith only [h,cr]

/-- The central supply permits deletion of any subset of at most the I4 unmatched holes. -/
theorem central_filtered_surplus {β : ℝ} {n : ℕ} {B W : Finset ℕ}
    (hd : DoublingFree B) (hg : SignedGap β n B)
    (cost : W.card ≤ (unmatchedTop (n/4/4) (quarterD n B)).card) :
    (5/8:ℝ)*(n/4/64:ℕ)+β*n-2 ≤ ((quarterD (n/4/16) (quarterD n B) \ W).card:ℝ) := by
  classical
  let H := n/4
  let D := quarterD n B
  let Z := quarterD (H/16) D
  have f := quarter_doubling_free n B hd
  have a := radial_identity H D f
  have b := radial_identity (H/4) D f
  rw [show H/4/4=H/16 by omega] at b
  have top : lower H D = D := inter_eq_left.mpr (filter_subset _ _)
  rw [top] at a
  have d := lower_card_eq (H/16) D
  have e := residue_card_le (H/16) D f
  have drop := card_sdiff_add_card_inter Z W
  have wi := card_le_card (inter_subset_right (s₁:=Z) (s₂:=W))
  change W.card ≤ (unmatchedTop (H/4) D).card at cost
  have cs : D.card ≤ (Z\W).card + (H+1)/2 + (H/4+1)/2 + (H/16+1)/2 := by
    change (lower (H/16) D).card = (residueR (H/16) D).card + Z.card at d;omega
  have floor : 512*((H+1)/2+(H/4+1)/2+(H/16+1)/2)+320*(H/64) ≤ 341*H+1024 := by omega
  have fr : (512:ℝ)*(((H+1)/2:ℕ)+((H/4+1)/2:ℕ)+((H/16+1)/2:ℕ))+320*(H/64:ℕ) ≤ 341*(H:ℝ)+1024 := by exact_mod_cast floor
  have cr : (D.card:ℝ) ≤ ((Z\W).card:ℝ)+((H+1)/2:ℕ)+((H/4+1)/2:ℕ)+((H/16+1)/2:ℕ) := by exact_mod_cast cs
  have hn : 4*(H:ℝ)≤n := by exact_mod_cast (show 4*H≤n by dsimp [H];omega)
  change (341/2048+β)*(n:ℝ) ≤ (D.card:ℝ)-totalBudget n B at hg
  change (5/8:ℝ)*(H/64:ℕ)+β*n-2 ≤ ((Z\W).card:ℝ)
  linarith only [hg,fr,cr,hn,Nat.cast_nonneg (α:=ℝ) (totalBudget n B)]

end OP02.SharpK8

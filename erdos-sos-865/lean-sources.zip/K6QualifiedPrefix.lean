import K6ActualTriangle
import K6SameParityEdge
import K6GoodTriangleUniform
open Finset Erdos865
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 3000000

def qualifiedPrefix (n J u v:ℕ) (B:Finset ℕ) :=
 ((quarterD n B).filter (fun x=>x≤J)).filter (fun x=>u+4*x∈B ∧ v+4*x∈B)

/-- Failed qualifications share one injective high-singleton charge. -/
theorem qualified_prefix_loss (n J u v:ℕ) (B:Finset ℕ)
 (hJ:J≤n/16) (huo:u%2=1) (hvo:v%2=1) (huv:u%4≠v%4)
 (huL:n<2*u) (hvL:n<2*v)
 (huH:u≤n-4*(n/16)) (hvH:v≤n-4*(n/16)) :
 ((quarterD n B).filter (fun x=>x≤J)).card≤
 (qualifiedPrefix n J u v B).card+(missingTopOdd n B).card := by
  classical
  let K:=J
  let D:=quarterD n B
  let X:=D.filter (fun x=>x≤K)
  let G:=X.filter (fun x=>u+4*x∈B ∧ v+4*x∈B)
  let F:=X\G
  let f:=fun x=>if u+4*x∉B then u+4*x else v+4*x
  have hfcard:F.card≤(missingTopOdd n B).card := by
    apply card_le_card_of_injOn f
    · intro x hx
      obtain ⟨hxX,hxG⟩ := mem_sdiff.mp hx
      obtain ⟨hxD,hxK⟩ := mem_filter.mp hxX
      have hx1 := (mem_Icc.mp (mem_filter.mp hxD).1).1
      have hbad:¬(u+4*x∈B ∧ v+4*x∈B) := by intro hg; exact hxG (mem_filter.mpr ⟨hxX,hg⟩)
      by_cases he:u+4*x∉B
      · simp only [f,if_pos he]
        refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,by omega⟩,by omega,he⟩
        dsimp only [K] at hxK; omega
      · simp only [f,if_neg he]
        have hh:v+4*x∉B := by tauto
        refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,by omega⟩,by omega,hh⟩
        dsimp only [K] at hxK; omega
    · intro x hx y hy he
      dsimp only [f] at he
      split_ifs at he <;> omega
  have hpart:G.card+F.card=X.card := by
    have := card_sdiff_add_card_eq_card (show G⊆X from filter_subset _ _)
    dsimp only [F]; omega
  change X.card≤G.card+(missingTopOdd n B).card
  omega

#print axioms qualified_prefix_loss

theorem qualified_prefix_subset (n J u v:ℕ) (B:Finset ℕ) :
    qualifiedPrefix n J u v B⊆Icc 1 J := by
  intro x hx
  obtain ⟨hxX,hqual⟩:=mem_filter.mp hx
  obtain ⟨hxD,hxJ⟩:=mem_filter.mp hxX
  exact mem_Icc.mpr ⟨(mem_Icc.mp (mem_filter.mp hxD).1).1,hxJ⟩

theorem actual_small_prefix_density (β:ℝ) (n:ℕ) (B:Finset ℕ)
    (hd:DoublingFree B) (hgap:PositiveGap6 β n B) :
    (n/64:ℕ)+(2:ℝ)*totalBudget n B+2*(β*n)≤
      2*((quarterD n B).filter (fun x=>x≤n/64)).card+6 := by
  let X:=actualRootPrefix n B
  have hX:X⊆Icc 1 (n/16) := by
    intro x hx
    obtain ⟨hxD,hxK⟩:=mem_filter.mp hx
    exact mem_Icc.mpr ⟨(mem_Icc.mp (mem_filter.mp hxD).1).1,hxK⟩
  have hdX:DoublingFree X := by
    intro x hx hx2
    exact quarter_doubling_free n B hd x (mem_filter.mp hx).1 (mem_filter.mp hx2).1
  have h1:=quarter_root_capacity (n/4) (n/16) (quarterD n B) (by omega)
    (filter_subset _ _) (quarter_doubling_free n B hd)
  have h2:=quarter_root_capacity (n/16) (n/64) X (by omega) hX hdX
  have he:X.filter (fun x=>x≤n/64)=(quarterD n B).filter (fun x=>x≤n/64) := by
    ext x
    simp only [X,actualRootPrefix,mem_filter]
    constructor
    · tauto
    · rintro ⟨hD,hsmall⟩
      exact ⟨⟨hD,by omega⟩,hsmall⟩
  rw [he] at h2
  have hh:(quarterD n B).card+n/16+2*(n/64)≤n/4+
      ((quarterD n B).filter (fun x=>x≤n/64)).card := by
    change (quarterD n B).card+2*(n/16)≤n/4+X.card at h1
    omega
  have hhr:((quarterD n B).card:ℝ)+(n/16:ℕ)+2*(n/64:ℕ)≤(n/4:ℕ)+
      ((quarterD n B).filter (fun x=>x≤n/64)).card := by exact_mod_cast hh
  have hfloor:(128:ℝ)*(n/4:ℕ)≤21*n+128*(n/16:ℕ)+192*(n/64:ℕ)+384 := by
    exact_mod_cast (show 128*(n/4)≤21*n+128*(n/16)+192*(n/64)+384 by omega)
  unfold PositiveGap6 at hgap
  linarith

/-- Both small structures are supplied by actual density, with all qualification
failures charged once to the same high-singleton inventory. -/
theorem actual_qualified_structures (β:ℝ) (n u v:ℕ) (B:Finset ℕ)
    (hd:DoublingFree B) (hgap:PositiveGap6 β n B) (hbn:(10:ℝ)≤β*n)
    (huo:u%2=1) (hvo:v%2=1) (huv:u%4≠v%4)
    (huL:n<2*u) (hvL:n<2*v)
    (huH:u≤n-4*(n/16)) (hvH:v≤n-4*(n/16)) :
    HasTriple (qualifiedPrefix n (n/16) u v B) ∧
    ∃r∈qualifiedPrefix n (n/64) u v B,∃s∈qualifiedPrefix n (n/64) u v B,
      r≠s ∧ r%2=s%2 ∧ r+s∈qualifiedPrefix n (n/64) u v B := by
  have hs:=deficit_split n B hd
  have hq:(missingTopOdd n B).card≤totalBudget n B := by unfold totalBudget; omega
  have hqr:((missingTopOdd n B).card:ℝ)≤totalBudget n B := by exact_mod_cast hq
  have hX:=actual_prefix_density β n B hd hgap
  have hZ:=actual_small_prefix_density β n B hd hgap
  have hXloss:=qualified_prefix_loss n (n/16) u v B (by omega) huo hvo huv huL hvL huH hvH
  have hZloss:=qualified_prefix_loss n (n/64) u v B (by omega) huo hvo huv huL hvL huH hvH
  have hXr:((actualRootPrefix n B).card:ℝ)≤(qualifiedPrefix n (n/16) u v B).card+(missingTopOdd n B).card := by exact_mod_cast hXloss
  have hZr:(((quarterD n B).filter (fun x=>x≤n/64)).card:ℝ)≤(qualifiedPrefix n (n/64) u v B).card+(missingTopOdd n B).card := by exact_mod_cast hZloss
  constructor
  · apply erdos865_contains_triple (n/16) _ (qualified_prefix_subset n (n/16) u v B)
    have hh:(5:ℝ)*(n/16:ℕ)+53<8*(qualifiedPrefix n (n/16) u v B).card := by linarith
    exact_mod_cast hh
  · apply same_parity_edge (n/64) _ (qualified_prefix_subset n (n/64) u v B)
    · intro x hx hx2
      exact quarter_doubling_free n B hd x (mem_filter.mp (mem_filter.mp hx).1).1 (mem_filter.mp (mem_filter.mp hx2).1).1
    · have hh:(n/64:ℕ)+(1:ℝ)<2*(qualifiedPrefix n (n/64) u v B).card := by linarith
      have hn:n/64+1<2*(qualifiedPrefix n (n/64) u v B).card := by exact_mod_cast hh
      omega

#print axioms actual_small_prefix_density
#print axioms actual_qualified_structures

end OP02.SharpK6

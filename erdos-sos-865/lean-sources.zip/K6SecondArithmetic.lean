import K6BandAccounting
namespace OP02.SharpK6
set_option maxHeartbeats 500000

theorem second_gap_upper (n q δ p s:ℕ) (hn:65536≤n) (hq:384*q≤n)
    (hδ:δ≤q) (hp:p≤5*n/2) (hs:s≤n/4) :
    p+s<4*(n-4*(n/16))-2*(4*δ+4) := by omega

theorem second_count_contradiction (n κ q δ c f g y:ℕ)
    (hn:65536≤n) (hq:384*(κ+q)≤n) (hδ:δ≤q)
    (hc:c≤κ+q) (hf:f≤2*c) (hg:g≤q) (hy:f+g=y)
    (hl:(5*n/2-(2*n+2*(4*δ+4)))/32≤y) : False := by omega

#print axioms second_gap_upper
#print axioms second_count_contradiction
end OP02.SharpK6

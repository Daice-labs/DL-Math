import K7CentralPivot
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7
set_option maxHeartbeats 1800000

/-- Internal four roots in the bottom quarter of D, including all six
pair labels, follow directly from the checked order-four endpoint. -/
theorem small_quartet_uniform (hD:Dousse7) (β:ℝ) (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,DoublingFree B →
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∃T:Finset ℕ,T.card=4 ∧ internalOn (quarterD n B) T ∧ ∀a∈T,a≤n/16 := by
  obtain ⟨U,hU⟩:=fourfree_uniform hD β hb
  obtain ⟨W,hW⟩:=exists_nat_gt (10/β)
  refine ⟨max (16*U) W,?_⟩
  intro n hn B hd hg
  let X:=(quarterD n B).filter (fun a=>a≤n/16)
  have hbound:=root_fraction_bound n B hd
  change _≤n/4+X.card at hbound
  have hsub:X⊆Icc 1 (n/16):=by
    intro x hx
    obtain ⟨hR,hh⟩:=mem_filter.mp hx
    exact mem_Icc.mpr ⟨(mem_Icc.mp (mem_filter.mp hR).1).1,hh⟩
  have h4:¬FourFree X:=by
    intro hf
    have hh:=hU (n/16) (by omega) X hsub hf
    have hbnd:((quarterD n B).card:ℝ)+2*(n/16:ℕ)≤(n/4:ℕ)+(X.card:ℝ):=by exact_mod_cast hbound
    have floor:(512:ℝ)*(n/4:ℕ)≤85*(n:ℝ)+688*(n/16:ℕ)+1024:=by
      exact_mod_cast (show 512*(n/4)≤85*n+688*(n/16)+1024 by omega)
    have hhalf:(2:ℝ)*(n/16:ℕ)≤(n:ℝ):=by exact_mod_cast (show 2*(n/16)≤n by omega)
    have hw:=lt_of_lt_of_le hW (show (W:ℝ)≤n by exact_mod_cast (show W≤n by omega))
    have hβ:=(div_lt_iff₀ hb).mp hw
    have hq:0≤(totalBudget n B:ℝ):=by positivity
    nlinarith only [hg,hbnd,hh,hβ,floor,hq,mul_nonneg hb.le (sub_nonneg.mpr hhalf)]
  obtain ⟨T,hT,hsize,hpair⟩:=Classical.not_not.mp h4
  exact ⟨T,hsize,⟨fun _ h=>(mem_filter.mp (hT h)).1,
    fun a ha b hb' hne=>(mem_filter.mp (hpair a ha b hb' hne)).1⟩,
    fun _ h=>(mem_filter.mp (hT h)).2⟩

def quartOffsets (T:Finset ℕ) : Finset ℕ:=insert 0 (T.image (fun a:ℕ=>4*a))

/-- Independence at the actual cutoff 7n/4. The upper pivot pays all
seven tests from one original q; the actual roots may have repeated labels. -/
theorem common_neighbors_independent {n y z:ℕ} {B T:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hg:MiddleGap7 n B)
    (hn:65536≤n) (hq:256*totalBudget n B≤n)
    (h4:T.card=4) (hT:internalOn (quarterD n B) T) (ht:∀a∈T,a≤n/16)
    (hy:n<y) (hz:n<z) (hy':4*y≤7*n) (hz':4*z≤7*n) (ho:y%2=1) (ho':z%2=1)
    (hne:y≠z) (hY:∀a∈quartOffsets T,y+a∈B) (hZ:∀a∈quartOffsets T,z+a∈B) : y+z∉B := by
  classical
  intro hsum
  let O:=quartOffsets T
  let A:=insert y (insert z O)
  let E:=fourResources n B ∪ Ho n B
  let q:=totalBudget n B
  let τ:=4*(missingTopOdd n B).card+8
  let P:=progression (2*n+2*τ) (2*n+2*τ+32*q+8) 4 0
  have hE:E.card≤q:=(card_union_le _ _).trans (four_resource_budget n B hd)
  have hδ:(missingTopOdd n B).card≤q:=by unfold q totalBudget;have :=missingTopOdd_le_deficit n B hd;omega
  have hO:O.card≤5:=by
    have hp:=card_image_le (s:=T) (f:=fun a:ℕ=>4*a)
    have hi:=card_insert_le 0 (T.image (fun a:ℕ=>4*a))
    dsimp [O,quartOffsets];omega
  have hA:A.card≤7:=by have :=card_insert_le z O;have :=card_insert_le y (insert z O);dsimp [A];omega
  have od {a:ℕ} (ha:a∈O):a%4=0 ∧ a≤4*(n/16):=by
    rcases mem_insert.mp ha with rfl|h
    · exact ⟨rfl,Nat.zero_le _⟩
    · obtain ⟨r,hr,rfl⟩:=mem_image.mp h
      have :=ht r hr;omega
  have pdat {p:ℕ} (hp:p∈P):2*n+2*τ<p ∧ p≤2*n+2*τ+32*q+8 ∧ p%4=0:=by
    obtain ⟨hi,hr⟩:=mem_filter.mp hp;exact ⟨(mem_Ioc.mp hi).1,(mem_Ioc.mp hi).2,hr⟩
  have hcnt:=shift_losses P A B E 1 0 7 (by intro _ _;omega) (by
    intro p hp a ha haB
    have pd:=pdat hp
    change 256*q≤n at hq
    rcases mem_insert.mp ha with rfl|ha
    · apply mem_union_right;apply OP02.SharpK6.bootstrap_missing_odd n _ B (by omega) (by omega) _ haB
      dsimp only [τ] at pd;omega
    rcases mem_insert.mp ha with rfl|ha
    · apply mem_union_right;apply OP02.SharpK6.bootstrap_missing_odd n _ B (by omega) (by omega) _ haB
      dsimp only [τ] at pd;omega
    have ad:=od ha
    apply mem_union_left;apply missing_gap_multiple hg (by omega) haB <;> dsimp only [τ] at pd <;> omega)
    (fun _ _=>(card_filter_le _ _).trans hA)
  have plen:=progression_lower (2*n+2*τ) (2*n+2*τ+32*q+8) 4 0 (by decide) (by decide)
  change _≤P.card at plen
  obtain ⟨p,hp⟩:=card_pos.mp (show 0<(passes P A B).card by omega)
  obtain ⟨hP,hpx⟩:=mem_filter.mp hp
  have pd:=pdat hP
  have hyB:y∈B:=by simpa using hY 0 (mem_insert_self _ _)
  have hzB:z∈B:=by simpa using hZ 0 (mem_insert_self _ _)
  have pB:p∈B:=by simpa using hpx 0 (mem_insert_of_mem (mem_insert_of_mem (mem_insert_self _ _)))
  let V:Finset ℕ:={y,z,p}
  have hpy:p+y∈B:=hpx y (by simp [A])
  have hpz:p+z∈B:=hpx z (by simp [A])
  have hv:internalOn B V:=by
    constructor
    · intro a ha;simp only [V,mem_insert,mem_singleton] at ha;rcases ha with rfl|rfl|rfl <;> assumption
    · intro a ha b hb hne';simp only [V,mem_insert,mem_singleton] at ha hb
      rcases ha with rfl|rfl|rfl <;> rcases hb with rfl|rfl|rfl <;>
        first | exact False.elim (hne' rfl) | assumption | simpa only [Nat.add_comm] using hsum |
                simpa only [Nat.add_comm] using hpy | simpa only [Nat.add_comm] using hpz
  have hyp:y≠p:=by omega
  have hzp:z≠p:=by omega
  apply combine_roots (T:=T) (n:=n) hT hv _ (by simp [V,h4,hne,hyp,hzp]) _ hf
  · intro a ha u hu;have :=ht a ha;simp only [V,mem_insert,mem_singleton] at hu
    rcases hu with rfl|rfl|rfl <;> omega
  · intro a ha u hu;have haO:4*a∈O:=mem_insert_of_mem (mem_image.mpr ⟨a,ha,rfl⟩)
    simp only [V,mem_insert,mem_singleton] at hu;rcases hu with rfl|rfl|rfl
    · exact hY _ haO
    · exact hZ _ haO
    · exact hpx _ (mem_insert_of_mem (mem_insert_of_mem haO))

end OP02.SharpK7

import K7Selection
import K7Budget

open Finset
namespace OP02.SharpK7

/-- The tested domain includes every shift of every base along the same lattice. -/
def testedIndices (I A : Finset ℤ) (e : ℤ) : Finset ℤ :=
  I ∪ I.biUnion (fun g => (A.image (fun a => g+a)) ∪ (A.image (fun a => g+(e-a))))

def prefixWord (H : ℕ) (B : Finset ℕ) : Finset ℤ :=
  (B ∩ Icc 1 H).image (fun z : ℕ => (z : ℤ))

def latticeBad (H : ℕ) (B : Finset ℕ) (p₀ e : ℤ) (I A : Finset ℤ) :=
  (testedIndices I A e).filter (fun g => p₀+4*g ∉ prefixWord H B)

def latticeVeto (H : ℕ) (B : Finset ℕ) (p₀ b : ℤ) (I : Finset ℤ) :=
  I.filter (fun g => p₀+4*g+4*b ∉ prefixWord H B)

/-- Keep every even pair and exactly those odd pairs with both translated
endpoints in the actual quarter roots of the same B. -/
def retainedEndpoints (n : ℕ) (B : Finset ℕ) (e b : ℕ) :=
  (reflectionPairs (smallSupport n B) e).filter
    (fun a => a%2=0 ∨ (b+a ∈ OP02.SmallExcess.quarterD n B ∧
      b+(e-a) ∈ OP02.SmallExcess.quarterD n B))

/-- Physical selection on the full tested progression. The finite cardinality
premise is explicit so its use by a geometric placement can be audited. -/
theorem physical_interpolation (n : ℕ) (B : Finset ℕ) (e b : ℕ) (p₀ : ℤ)
    (I : Finset ℤ)
    (A : Finset ℕ) (hsub : A ⊆ retainedEndpoints n B e b) (hne : A.Nonempty)
    (hcard :
      ((latticeVeto (n/4) B p₀ b I).card:ℤ) +
      max ((latticeBad (n/4) B p₀ e I (A.image (fun z : ℕ => (z : ℤ)))).card:ℤ)
        (3*((latticeBad (n/4) B p₀ e I (A.image (fun z : ℕ => (z : ℤ)))).card:ℤ)-2*(A.card:ℤ)+2)
        < (I.card:ℤ)) :
    ∃ g∈I, ∃ a∈A,
      p₀+4*g ∈ prefixWord (n/4) B ∧ p₀+4*g+4*b ∈ prefixWord (n/4) B ∧
      p₀+4*g+4*a ∈ prefixWord (n/4) B ∧
      p₀+4*g+4*(e-a : ℕ) ∈ prefixWord (n/4) B ∧
      a∈smallSupport n B ∧ e-a∈smallSupport n B ∧
      (a%2=0 ∨ (b+a∈OP02.SmallExcess.quarterD n B ∧ b+(e-a)∈OP02.SmallExcess.quarterD n B)) := by
  classical
  let A' := A.image (fun z : ℕ => (z : ℤ))
  let W := prefixWord (n/4) B
  let U := latticeBad (n/4) B p₀ e I A'
  let F := latticeVeto (n/4) B p₀ b I
  have hsafe {g : ℤ} (ht : g∈testedIndices I A' e) (hu : g∉U) : p₀+4*g∈W := by
    by_contra hm; exact hu (mem_filter.mpr ⟨ht,hm⟩)
  have ha' : A'.Nonempty := hne.image _
  have hs a (ha : a∈A) := (mem_filter.mp (hsub ha))
  have haj {a : ℕ} (ha : a∈A) : 0<a ∧ a<e-a ∧ e-a∈smallSupport n B :=
    (mem_filter.mp (hs a ha).1).2
  have hsm (x : ℤ) (hx : x∈A') : 0<x ∧ x<(e:ℤ)-x := by
    obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
    obtain ⟨h1,h2,_⟩ := haj ha
    omega
  have heq : I ∩ F = F := inter_eq_right.mpr (filter_subset _ _)
  have hlen : A'.card=A.card := card_image_of_injective _ Int.ofNat_injective
  have hc : ((I∩F).card:ℤ)+max (U.card:ℤ) (3*(U.card:ℤ)-2*(A'.card:ℤ)+2)<I.card := by
    rw [heq,hlen];exact hcard
  obtain ⟨g,hg,hgU,hgF,x,hx,h1,h2⟩ := commonBaseSelection I U F A' (e:ℤ) ha' hsm hc
  have ht1 : g+x∈testedIndices I A' e := mem_union_right _ (mem_biUnion.mpr
    ⟨g,hg,mem_union_left _ (mem_image.mpr ⟨x,hx,rfl⟩)⟩)
  have ht2 : g+((e:ℤ)-x)∈testedIndices I A' e := mem_union_right _ (mem_biUnion.mpr
    ⟨g,hg,mem_union_right _ (mem_image.mpr ⟨x,hx,rfl⟩)⟩)
  have hp := hsafe (mem_union_left _ hg) hgU
  have hp1 := hsafe ht1 h1
  have hp2 := hsafe ht2 h2
  obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
  have haj' := haj ha
  have hle : a≤e := by omega
  refine ⟨g,hg,a,ha,hp,?_,?_,?_,(mem_filter.mp (hs a ha).1).1,haj'.2.2,(hs a ha).2⟩
  · by_contra hh; exact hgF (mem_filter.mpr ⟨hg,hh⟩)
  · simpa only [W,mul_add,add_assoc] using hp1
  · rw [Int.natCast_sub hle]
    simpa only [mul_add,add_assoc] using hp2

end OP02.SharpK7

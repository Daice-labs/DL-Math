import ZeroParity
open Finset
namespace OP02.ZeroExcess
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

structure Critical (n:ℕ) (B:Finset ℕ) (a b c:ℕ) : Prop where
  tri : LowerTriangle n B {a,b,c}
  lt : a<b
  ao : a%2=1
  bo : b%2=1
  co : c%4=2
  ab : a%4≠b%4

theorem small_side (n:ℕ) (B:Finset ℕ) (hf:FourFree B) (hd:DoublingFree B)
    (he:(excessHoles n B).card=0) :
    ∃r<2, (parityMiddle n B r).card ≤ 2*deficit n B+2 := by
  rcases one_middle_side_edgeless n B hf hd he with h|h
  · exact ⟨0,by omega,by have := even_edgeless_small n B hd he h; omega⟩
  · exact ⟨1,by omega,odd_edgeless_small n B hd he h⟩

theorem small_side_pivot_count (n:ℕ) (B S:Finset ℕ) (hf:FourFree B)
    (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (ht:LowerTriangle n B S) {r α:ℕ} (hr:r<2) (hα:α<8)
    (T:Finset ℕ) (hT:T.card≤2)
    (hallow:∀u∈insert 0 S, (α+u)%2=0 → u∈T ∧ (α+u)%4=2*r) :
    n/8 ≤ 2*(parityMiddle n B r).card := by
  have hm : ∀x∈S,x≤n := fun x hx => (mem_Icc.mp (mem_inter.mp (ht.2.1 hx)).2).2
  have hs : pivots n n α ⊆ (T.product (parityMiddle n B r)).image
      (fun z:ℕ×ℕ=>2*z.2-z.1) := by
    intro p hp
    have hpa := (mem_filter.mp hp).2
    obtain ⟨u,hu,hmiss⟩ := pivot_missing n n B S hf ht hm p (mem_filter.mp hp).1
    obtain ⟨v,hv,hve⟩ := (upper_missing_iff n B hd he (mem_sdiff.mp hmiss).1).mp
      (mem_sdiff.mp hmiss).2
    have heu : (α+u)%2=0 := by omega
    obtain ⟨huT,hu4⟩ := hallow u hu heu
    have hvp : v%2=r := by omega
    refine mem_image.mpr ⟨(u,v),mem_product.mpr ⟨huT,mem_filter.mpr ⟨hv,hvp⟩⟩,?_⟩
    dsimp
    omega
  have hc := (card_le_card hs).trans card_image_le
  rw [product_eq_sprod,card_product] at hc
  have hsize := pivot_card_lower n n α (by omega) hα
  have hmul := Nat.mul_le_mul_right (parityMiddle n B r).card hT
  omega

theorem noncritical_translate {a b c r:ℕ}
    (hao:a%2=1) (hbo:b%2=1) (hce:c%2=0) (hr:r<2)
    (hn:c%4≠2 ∨ a%4=b%4) :
    ∃α<8, ∃T:Finset ℕ, T.card≤2 ∧
      ∀u∈insert 0 ({a,b,c}:Finset ℕ), (α+u)%2=0 → u∈T ∧ (α+u)%4=2*r := by
  by_cases hc:c%4=0
  · refine ⟨2*r,by omega,{0,c},by simpa using (card_insert_le 0 ({c}:Finset ℕ)),?_⟩
    intro u hu he
    simp only [mem_insert,mem_singleton] at hu
    rcases hu with rfl|rfl|rfl|rfl
    · exact ⟨by simp,by omega⟩
    · omega
    · omega
    · exact ⟨by simp,by omega⟩
  · have hab:a%4=b%4 := by omega
    let α := (2*r+4-a%4)%4
    have hα:α%2=1 := by dsimp [α]; omega
    have hαa:(α+a)%4=2*r := by dsimp [α]; omega
    refine ⟨α,by dsimp [α]; omega,{a,b},by simpa using (card_insert_le a ({b}:Finset ℕ)),?_⟩
    intro u hu he
    simp only [mem_insert,mem_singleton] at hu
    rcases hu with rfl|rfl|rfl|rfl
    · omega
    · exact ⟨by simp,hαa⟩
    · exact ⟨by simp,by omega⟩
    · omega

theorem mixed_is_critical (n:ℕ) (B:Finset ℕ)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hmargin:32*deficit n B+40<n) {a b c:ℕ}
    (ht:LowerTriangle n B {a,b,c}) (hao:a%2=1) (hbo:b%2=1) (hce:c%2=0) :
    c%4=2 ∧ a%4≠b%4 := by
  by_contra hn
  have hn' : c%4≠2 ∨ a%4=b%4 := by omega
  obtain ⟨r,hr,hsmall⟩ := small_side n B hf hd he
  obtain ⟨α,hα,T,hT,hallow⟩ := noncritical_translate hao hbo hce hr hn'
  have hb := small_side_pivot_count n B {a,b,c} hf hd he ht hr hα T hT hallow
  omega

theorem critical_from_context (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (he:(excessHoles n B).card=0) (hmargin:32*deficit n B+40<n) :
    ∃a b c, Critical n B a b c := by
  obtain ⟨hn,hsub,hfour,hdbl,hholes,hbudget,htri,hprofile⟩ := hc
  obtain ⟨x,hx,y,hy,z,hz,hxy,hxz,hyz,hxs,hys,hzs⟩ := htri
  have ht : LowerTriangle n B {x,y,z} := by
    refine ⟨by simp [hxy,hxz,hyz],?_,?_⟩
    · intro u hu
      simp only [mem_insert,mem_singleton] at hu
      rcases hu with rfl|rfl|rfl <;> assumption
    · intro u hu v hv huv
      have hxsB := (mem_inter.mp hxs).1
      have hysB := (mem_inter.mp hys).1
      have hzsB := (mem_inter.mp hzs).1
      simp only [mem_insert,mem_singleton] at hu hv
      rcases hu with rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl <;>
        simp_all [Nat.add_comm]
  obtain ⟨a,b,c,hset,hao,hbo,hce,hab8,hc8⟩ := hprofile _ ht
  rw [hset] at ht
  have hab:a≠b := by
    intro hh
    exact hab8 (hh ▸ rfl)
  have hcrit := mixed_is_critical n B hfour hdbl he hmargin ht hao hbo hce
  by_cases hlt:a<b
  · exact ⟨a,b,c,ht,hlt,hao,hbo,hcrit.1,hcrit.2⟩
  · have hswap : ({b,a,c}:Finset ℕ)={a,b,c} := by ext u; simp; tauto
    exact ⟨b,a,c,by rw [hswap]; exact ht,by omega,hbo,hao,hcrit.1,Ne.symm hcrit.2⟩

#print axioms critical_from_context
end OP02.ZeroExcess

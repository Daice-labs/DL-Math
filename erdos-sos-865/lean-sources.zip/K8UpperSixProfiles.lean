import K8UpperSixTools

open Finset
namespace OP02.SharpK8

/-- A full-support six-offset profile has a singleton different from the
largest offset. Every offset except that largest one is at most half the prefix. -/
theorem complement_small_singleton {H : ℕ} {D F : Finset ℕ} (hF : ShortFive H D F)
    (full : ∀j<4, ∃x∈insert 0 F, x%4=j) :
    ∃ w∈insert 0 F, ∃ b∈insert 0 F, w ≠ b ∧ w≤H/8 ∧
      (∀s∈insert 0 F, s%4=w%4 → s=w) ∧
      (∀s∈insert 0 F, s≠b → s≤H/8) := by
  classical
  let O := insert 0 F
  let C (r:ℕ) := O.filter (fun x => x%4=r)
  have z : 0∉F := by intro hz; have := (mem_Icc.mp (mem_inter.mp (hF.1.1 hz)).2).1; omega
  have nO : O.card=6 := by simp [O,z,hF.1.2.1]
  have nonempty : O.Nonempty := ⟨0,by simp [O]⟩
  let b := O.max' nonempty
  have hbo : b∈O := O.max'_mem nonempty
  have rest : ∀s∈O, s≠b → s≤H/8 := by
    intro s hs hne
    have hsb : s≤b := O.le_max' s hs
    rcases mem_insert.mp hs with rfl|hsF
    · omega
    · rcases mem_insert.mp hbo with hzero|hbF
      · omega
      · have hsum := (mem_Icc.mp (mem_inter.mp (hF.1.2.2 s hsF b hbF hne)).2).2
        omega
  have pos (i : ℕ) (hi : i<4) : 0 < (C i).card := by
    obtain ⟨s,hs,hsi⟩ := full i hi
    exact card_pos.mpr ⟨s,mem_filter.mpr ⟨hs,hsi⟩⟩
  have count := card_eq_sum_card_fiberwise (s:=O) (t:=range 4) (f:=fun s : ℕ => s%4)
      (fun s _ => mem_range.mpr (by change s%4<4; omega))
  simp only [sum_range_succ,sum_range_zero,zero_add] at count
  change O.card=(C 0).card+(C 1).card+(C 2).card+(C 3).card at count
  have single : ∃ r<4, r≠b%4 ∧ (C r).card=1 := by
    by_contra! h
    have h0 := h 0 (by omega); have h1 := h 1 (by omega)
    have h2 := h 2 (by omega); have h3 := h 3 (by omega)
    have p0 := pos 0 (by omega); have p1 := pos 1 (by omega)
    have p2 := pos 2 (by omega); have p3 := pos 3 (by omega)
    omega
  obtain ⟨r,hr,hbr,hsize⟩ := single
  obtain ⟨w,hw,honly⟩ := card_eq_one_iff_existsUnique.mp hsize
  obtain ⟨hwO,hwr⟩ := mem_filter.mp hw
  have hwb : w≠b := by intro he; exact hbr (he ▸ hwr.symm)
  refine ⟨w,hwO,b,hbo,hwb,rest w hwO hwb,?_,rest⟩
  intro s hs hsw
  exact honly s (mem_filter.mpr ⟨hs,hsw.trans hwr⟩)

end OP02.SharpK8

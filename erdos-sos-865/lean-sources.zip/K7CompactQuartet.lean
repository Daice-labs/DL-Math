import K7DirectPairHalf
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

theorem padded_inventory {β:ℝ} (hb:0<β) :
    ∃U:ℕ,∀n:ℕ,U≤n→∀B:Finset ℕ,DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ)→
    384*(chainDeficit n B+totalBudget n B)+10000*logLevels (n/4)+300000≤n/4 := by
  obtain ⟨U,hU⟩:=uniform_window_threshold (β/100) (by positivity)
  refine ⟨U,?_⟩
  intro n hn B hd hg
  obtain ⟨_,pay⟩:=hU n hn
  have w:=chain_capacity_with_top_loss (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  have actual:chainDeficit n B+(quarterD n B).card=chainCapacity (n/4):=by unfold chainDeficit;omega
  have c:=capacity_log_bound (n/4) (n/4) le_rfl
  have cc:(3:ℝ)*(chainDeficit n B+(quarterD n B).card)≤2*(n/4:ℕ)+logLevels (n/4):=by
    exact_mod_cast (show 3*(chainDeficit n B+(quarterD n B).card)≤2*(n/4)+logLevels (n/4) by omega)
  have four:(4:ℝ)*(n/4:ℕ)≤n:=by exact_mod_cast (show 4*(n/4)≤n by omega)
  apply_mod_cast (show (384:ℝ)*(chainDeficit n B+totalBudget n B)+10000*logLevels (n/4)+300000≤(n/4:ℕ) by
    nlinarith only [cc,four,hg,pay,show (0:ℝ)≤logLevels (n/4) by positivity])

def canBand (l u:ℕ) := (Ioc l u).filter (fun v=>canonical v=true)

theorem canBand_card {l u H:ℕ} (lu:l≤u) (uh:u≤H) :
    2*(u-l)≤3*(canBand l u).card+2*logLevels H := by
  have eq:canBand l u=canonicalSlots u \ canonicalSlots l:=by
    ext v
    simp only [canBand,canonicalSlots,mem_filter,mem_Ioc,mem_sdiff,mem_Icc]
    constructor
    · rintro ⟨⟨lo,hi⟩,can⟩
      exact ⟨⟨⟨by omega,hi⟩,can⟩,by rintro ⟨⟨_,h⟩,_⟩;omega⟩
    · rintro ⟨⟨⟨po,hi⟩,can⟩,no⟩
      have lb:l<v:=by by_contra! h;exact no ⟨⟨po,h⟩,can⟩
      exact ⟨⟨lb,hi⟩,can⟩
  have sub:canonicalSlots l ⊆ canonicalSlots u:=by
    intro x hi; obtain ⟨ii,par⟩:=mem_filter.mp hi;have z:=mem_Icc.mp ii
    exact mem_filter.mpr ⟨mem_Icc.mpr ⟨z.1,by omega⟩,par⟩
  have cut:=card_sdiff_add_card_eq_card sub
  rw [←eq] at cut
  change (canBand l u).card+chainCapacity l=chainCapacity u at cut
  have lo:=cap_lower_log u H uh;have hi:=capacity_log_bound l H (by omega)
  omega

theorem canonical_intersection {l u j H:ℕ} (lu:l≤u) (cap:u+j≤H) :
    u-l≤3*((canBand l u).filter (fun v=>canonical (v+j)=true)).card+4*logLevels H := by
  let I:=Ioc l u
  let A:=canBand l u
  let B:=I.filter (fun v=>canonical (v+j)=true)
  have bind:(B.image (fun v:ℕ=>v+j))=canBand (l+j) (u+j):=by
    ext x;constructor
    · intro h;obtain ⟨v,hv,rfl⟩:=mem_image.mp h;obtain ⟨vi,p⟩:=mem_filter.mp hv;have :=mem_Ioc.mp vi
      exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,p⟩
    · intro h;obtain ⟨vi,p⟩:=mem_filter.mp h;have :=mem_Ioc.mp vi
      exact mem_image.mpr ⟨x-j,mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by rwa [Nat.sub_add_cancel (by omega)]⟩,by omega⟩
  have bc:B.card=(canBand (l+j) (u+j)).card:=by
    rw [←bind];symm;exact card_image_of_injective _ (fun _ _ h=>Nat.add_right_cancel h)
  have ca:=canBand_card (H:=H) lu (by omega)
  have cb:=canBand_card (H:=H) (show l+j≤u+j by omega) cap
  have un:A∪B⊆I:=union_subset (filter_subset _ _) (filter_subset _ _)
  have ib:I.card=u-l:=Nat.card_Ioc _ _
  have card:=card_union_add_card_inter A B
  have ov:A∩B=A.filter (fun v=>canonical (v+j)=true):=by
    ext v; change (v∈A ∩ I.filter (fun v=>canonical (v+j)=true)) ↔ v∈A.filter (fun v=>canonical (v+j)=true)
    simp only [mem_inter,mem_filter];constructor
    · exact fun h=>⟨h.1,h.2.2⟩
    · exact fun h=>⟨h.1,(mem_filter.mp h.1).1,h.2⟩
  rw [ov] at card
  have total:=card_le_card un
  change 2*(u-l)≤3*A.card+2*logLevels H at ca
  change _≤3*(A.filter _).card+_ 
  omega

/-- A quartic lift of the two simultaneous canonical tests. Bounds use one
interval overlap and all four actual root memberships at the selected index. -/
theorem short_odd_star {H n a c b l u:ℕ} {B:Finset ℕ} (eqH:H=n/4)
    (hd:DoublingFree B) (ac:a<c) (cb:c<b) (ao:a%2=1) (co:c%2=1) (bo:b%4=0)
    (lu:l≤u) (lb:H/8≤4*l+3) (uc:4*u+b≤H/4)
    (supply:6*(quarterMissing H (quarterD n B)).card+4*logLevels H<u-l) :
    ∃z, H/8<z ∧ z≤4*u ∧ ∀x∈({0,a,c,b}:Finset ℕ),z+x∈quarterD n B:=by
  classical
  let J:=(canBand l u).filter (fun v=>canonical (v+b/4)=true)
  let P:=J.image (fun v:ℕ=>4*v)
  let O:Finset ℕ:={0,a,c,b}
  let L:=quarterMissing H (quarterD n B)
  have enough:=canonical_intersection (j:=b/4) (H:=H) lu (by omega)
  have count:P.card=J.card:=card_image_of_injective _ (fun i j h=>by change 4*i=4*j at h;omega)
  have dat {z:ℕ} (hz:z∈P) : H/8<z ∧ z≤4*u ∧ z%2=0 ∧ ∀x∈O,canonical (z+x)=true := by
    obtain ⟨v,jv,rfl⟩:=mem_image.mp hz
    obtain ⟨h,canb⟩:=mem_filter.mp jv;obtain ⟨vi,canv⟩:=mem_filter.mp h
    have ii:=mem_Ioc.mp vi
    refine ⟨by omega,by omega,by omega,?_⟩
    intro x hx;simp only [O,mem_insert,mem_singleton] at hx
    rcases hx with hx|hx|hx|hx <;> subst x
    · simpa only [Nat.add_zero,canonical_four] using canv
    · exact canonical_odd _ (by omega)
    · exact canonical_odd _ (by omega)
    · rwa [show 4*v+b=4*(v+b/4) by omega,canonical_four]
  have load:=shift_losses P O (quarterD n B) L 2 0 2 (fun _ h=>(dat h).2.2.1)
    (by intro z hz x hx ha;have zz:=dat hz
        have ub:x≤b:=by simp only [O,mem_insert,mem_singleton] at hx;omega
        exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,zz.2.2.2 x hx⟩,by omega,by omega,ha⟩)
    (by intro z hz; by_cases even:z%2=0
        · apply (card_le_card (t:={0,b}) _).trans card_le_two
          intro x hx;obtain ⟨h,r⟩:=mem_filter.mp hx;simp only [O,mem_insert,mem_singleton] at h ⊢;omega
        · apply (card_le_card (t:={a,c}) _).trans card_le_two
          intro x hx;obtain ⟨h,r⟩:=mem_filter.mp hx;simp only [O,mem_insert,mem_singleton] at h ⊢;omega)
  change u-l≤3*J.card+4*logLevels H at enough
  have ne:0<(passes P O (quarterD n B)).card:=by change P.card≤_+2*L.card at load;change 6*L.card+_<u-l at supply;omega
  obtain ⟨z,hz⟩:=card_pos.mp ne;obtain ⟨hp,good⟩:=mem_filter.mp hz
  exact ⟨z,(dat hp).1,(dat hp).2.1,good⟩

end OP02.SharpK7.LongOddTask

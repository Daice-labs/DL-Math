import K9PhysicalProfiles

open Finset OP02.SharpK8
namespace OP02.AllOrders

private theorem classes_disjoint (U : Finset ℕ) {a b : ℕ} (ne : a ≠ b) :
    Disjoint (residueCell U 4 a) (residueCell U 4 b) := by
  apply disjoint_left.mpr
  intro x hx hy
  exact ne ((mem_filter.mp hx).2.symm.trans (mem_filter.mp hy).2)

private theorem three_classes (U : Finset ℕ) (b : ℕ) (small : U.card<12) :
    ∃ c<4, (residueCell U 4 c).card ≤ 3 ∧ (c+2)%4≠b%4 := by
  classical
  let x := b%4
  let y := (b+1)%4
  let z := (b+3)%4
  let X := residueCell U 4 x
  let Y := residueCell U 4 y
  let Z := residueCell U 4 z
  have hxy : Disjoint X Y := classes_disjoint U (by dsimp [x,y]; omega)
  have hxz : Disjoint X Z := classes_disjoint U (by dsimp [x,z]; omega)
  have hyz : Disjoint Y Z := classes_disjoint U (by dsimp [y,z]; omega)
  have hsub : X ∪ Y ∪ Z ⊆ U := union_subset (union_subset (filter_subset _ _) (filter_subset _ _)) (filter_subset _ _)
  have hc := card_le_card hsub
  rw [card_union_of_disjoint (disjoint_union_left.mpr ⟨hxz,hyz⟩), card_union_of_disjoint hxy] at hc
  by_cases h : X.card≤3
  · exact ⟨x,by dsimp [x]; omega,h,by dsimp [x]; omega⟩
  by_cases h' : Y.card≤3
  · exact ⟨y,by dsimp [y]; omega,h',by dsimp [y]; omega⟩
  exact ⟨z,by dsimp [z]; omega,by change Z.card≤3; omega,by dsimp [z]; omega⟩

/-- One residue progression controls all translates simultaneously.  The short-order
choice excludes the prescribed largest offset.  At later orders the given odd
sparse class is used and any offset can become the failed target. -/
theorem window_residues {k b : ℕ} {U : Finset ℕ} (hc : U.card=k)
    (sparse : ∃ c, (c=1 ∨ c=3) ∧ (residueCell U 4 c).card≤3) :
    ∃ a d r : ℕ, a<4 ∧ (d=8 ∨ d=32) ∧ r<d ∧
      (residueCell U 4 ((a+2)%4)).card≤3 ∧
      (d=32 → (residueCell U 4 a).card+2≤k) ∧
      (k<12 → b%4≠a) ∧ (12≤k → a%2=1) ∧
      ∀ R, R%d=r → R%4=(6-a)%4 ∧
        (∀ u∈residueCell U 4 a, (R+u)%4=2) ∧
        ∀ u∈U, u∉residueCell U 4 a →
          (R+u)%2=1 ∨ (R+u)%8=4 ∨ (R+u)%32=16 := by
  classical
  have pick : ∃ c<4, (residueCell U 4 c).card≤3 ∧
      (k<12 → (c+2)%4≠b%4) ∧ (12≤k → c%2=1) := by
    by_cases hs : k<12
    · obtain ⟨c,hc',cs,tb⟩ := three_classes U b (by omega)
      exact ⟨c,hc',cs,fun _ => tb,by omega⟩
    · obtain ⟨c,co,cs⟩ := sparse
      exact ⟨c,by omega,cs,by omega,by omega⟩
  obtain ⟨c,cl,cs,bs,co⟩ := pick
  let a := (c+2)%4
  let C := residueCell U 4 c
  let B := residueCell U 4 a
  have cip : (a+2)%4=c := by dsimp [a]; omega
  let ph := (6-a)%4
  have rel : ∀ u∈C,(ph+u)%4=0 := by
    intro u hu
    have uc : u%4=c := (mem_filter.mp hu).2
    dsimp [ph,a]; omega
  obtain ⟨d,r,ds,rd,short,safe⟩ := control_progression C ph (Nat.mod_lt _ (by decide)) cs rel
  refine ⟨a,d,r,Nat.mod_lt _ (by decide),ds,rd,by rwa [cip],?_,?_,?_,?_⟩
  · intro hd
    have c2 : 2≤C.card := by by_contra! h; have := short (by omega); omega
    have cd := classes_disjoint U (show a ≠ c by dsimp [a]; omega)
    have sub : B ∪ C ⊆ U := union_subset (filter_subset _ _) (filter_subset _ _)
    have sz := card_le_card sub
    change (residueCell U 4 a ∪ residueCell U 4 c).card≤U.card at sz
    rw [card_union_of_disjoint cd] at sz
    change 2≤(residueCell U 4 c).card at c2
    omega
  · exact fun hs => (bs hs).symm
  · intro hs; have := co hs; dsimp [a]; omega
  · intro R hR
    obtain ⟨hr,cc⟩ := safe R hR
    refine ⟨hr,?_,?_⟩
    · intro u hu
      have hu' : u%4=a := (mem_filter.mp hu).2
      change R%4=(6-a)%4 at hr
      have : a<4 := Nat.mod_lt _ (by decide)
      omega
    · intro u hu nt
      by_cases h : u%4=c
      · exact Or.inr (cc u (mem_filter.mpr ⟨hu,h⟩))
      · have ua : u%4≠a := fun e => nt (mem_filter.mpr ⟨hu,e⟩)
        change R%4=(6-((c+2)%4))%4 at hr
        change u%4≠(c+2)%4 at ua
        exact Or.inl (by omega)

end OP02.AllOrders

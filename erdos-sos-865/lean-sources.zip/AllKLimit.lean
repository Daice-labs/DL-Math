import AllKLimitUpper

open Finset Filter
open scoped Asymptotics
namespace OP02.AllOrders

theorem coeff_formula (k : ℕ) (hk : 2≤k) :
    (1/2:ℝ)*(1+∑ r ∈ Icc 1 (k-2), (1/4:ℝ)^r) = coeff k := by
  let n := k-2
  have h : insert 0 (Icc 1 n) = range (n+1) := by
    ext x
    simp only [mem_insert,mem_Icc,mem_range]
    omega
  have sumid : 1+∑ r ∈ Icc 1 n,(1/4:ℝ)^r = ∑ r ∈ range (n+1),(1/4:ℝ)^r := by
    rw [←h,sum_insert (by simp)]
    simp
  change (1/2:ℝ)*(1+∑ r ∈ Icc 1 n,(1/4:ℝ)^r) = _
  rw [sumid]
  have geom := geom_sum_mul (1/4:ℝ) (n+1)
  unfold coeff
  rw [show k-1=n+1 by dsimp [n]; omega]
  linarith only [geom]

theorem sharp_limit_of_upper (k : ℕ) (hk : 2≤k) (up : Upper k) :
    Tendsto (fun N : ℕ => (Erdos865.f N k : ℝ) / (N : ℝ)) atTop (nhds (coeff k)) := by
  apply Metric.tendsto_atTop.mpr
  intro ε hε
  let b := ∑ j ∈ range (k-1), (4:ℕ)^j
  obtain ⟨M,hm⟩ := exists_nat_gt ((b:ℝ)/ε)
  obtain ⟨U,hu⟩ := up (ε/2) (by positivity)
  refine ⟨max 1 (max M U),?_⟩
  intro N hN
  have pN : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  have hMN : (M:ℝ)≤N := by exact_mod_cast (show M≤N by omega)
  have hroom := (div_lt_iff₀ hε).mp (hm.trans_le hMN)
  have low : coeff k*(N:ℝ) ≤ (Erdos865.f N k:ℝ) + (b:ℝ) := band_lower_real k N hk
  have high := hu N (by omega)
  rw [Real.dist_eq,abs_lt]
  constructor
  · apply lt_sub_iff_add_lt.mpr
    apply (lt_div_iff₀ pN).mpr
    nlinarith only [low,hroom]
  · apply sub_lt_iff_lt_add.mpr
    apply (div_lt_iff₀ pN).mpr
    nlinarith only [high,mul_pos hε pN]

theorem sharp_limit_of_shaped (shape : ∀ k : ℕ, 6 ≤ k → Shaped k) :
    ∀ k : ℕ, 2 ≤ k →
    Tendsto (fun N : ℕ => (Erdos865.f N k : ℝ) / (N : ℝ)) atTop
      (nhds ((2 / 3 : ℝ) * (1 - (1 / 4 : ℝ) ^ (k - 1)))) :=
  fun k hk => sharp_limit_of_upper k hk (upper_all_of_shaped shape k hk)

theorem erdos_sos_of_sharp (sharp : ∀ k : ℕ, 2≤k →
    Tendsto (fun N : ℕ => (Erdos865.f N k : ℝ) / (N : ℝ)) atTop (nhds (coeff k))) :
    OP02.GeneralGoal := by
  intro k hk
  rw [coeff_formula k hk]
  apply Asymptotics.isEquivalent_iff_tendsto_one ?_ |>.mpr
  · have cp := coeff_pos k hk
    have t := (sharp k hk).div_const (coeff k)
    rw [div_self cp.ne'] at t
    apply t.congr'
    filter_upwards with N
    change (Erdos865.f N k:ℝ)/(N:ℝ)/coeff k = (Erdos865.f N k:ℝ)/(coeff k*(N:ℝ))
    ring
  · filter_upwards [eventually_ge_atTop 1] with N hN
    have hpos : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
    exact (mul_pos (coeff_pos k hk) hpos).ne'

end OP02.AllOrders

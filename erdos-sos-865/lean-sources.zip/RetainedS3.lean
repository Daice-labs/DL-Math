import OP02Spec
import KnownK3
import FrontierSpec
open Finset Filter
open scoped Asymptotics
namespace OP02ReviewedS3
theorem result : (OP02.Frontier.ConditionalK4Goal) :=
by
  classical
  intro hD hL
  obtain ⟨C0, hC0⟩ := hL
  let C : ℕ := max C0 53
  have hC0C : C0 ≤ C := le_max_left _ _
  have h53C : 53 ≤ C := le_max_right _ _
  have hnorm (n : ℕ) (hn : 1 ≤ n) (B : Finset ℕ)
      (hsub : B ⊆ Finset.Icc 1 (4 * n))
      (hfour : OP02.FewHole.FourFree B)
      (hdbl : OP02.FewHole.DoublingFree B) :
      8 * B.card ≤ 21 * n + C := by
    by_cases hh : n ≤ 4 * (OP02.FewHole.holes n B).card
    · have hc := hC0 n hn B hsub hfour hdbl hh
      omega
    · have hh' : 4 * (OP02.FewHole.holes n B).card < n := by omega
      have hc := OP02.FewHole.few_holes_explicit n B hsub hfour hdbl hh'
      omega
  have hnormAny (N : ℕ) (B : Finset ℕ)
      (hsub : B ⊆ Finset.Icc 1 N)
      (hfour : OP02.FewHole.FourFree B)
      (hdbl : OP02.FewHole.DoublingFree B) :
      (B.card : ℝ) ≤ (21 / 32 : ℝ) * (N : ℝ) + (C : ℝ) + 3 := by
    let n : ℕ := N / 4 + 1
    have hn : 1 ≤ n := by dsimp [n]; omega
    have hNn : N ≤ 4 * n := by dsimp [n]; omega
    have hnN : 4 * n ≤ N + 4 := by dsimp [n]; omega
    have hsub' : B ⊆ Finset.Icc 1 (4 * n) := by
      intro x hx
      obtain ⟨hx1, hxN⟩ := Finset.mem_Icc.mp (hsub hx)
      exact Finset.mem_Icc.mpr ⟨hx1, by omega⟩
    have hb := hnorm n hn B hsub' hfour hdbl
    have hBN : 32 * B.card ≤ 21 * N + 4 * C + 84 := by omega
    have hBR : (32 : ℝ) * (B.card : ℝ) ≤
        21 * (N : ℝ) + 4 * (C : ℝ) + 84 := by
      exact_mod_cast hBN
    have hCnonneg : 0 ≤ (C : ℝ) := by positivity
    nlinarith only [hBR, hCnonneg]
  have deletion (δ : ℝ) (hδ : 0 < δ) :
      ∃ N0 : ℕ, 1 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N →
        ∀ A : Finset ℕ, A ⊆ Finset.Icc 1 N →
          OP02.FewHole.FourFree A →
          ∃ B : Finset ℕ, B ⊆ Finset.Icc 1 N ∧
            OP02.FewHole.FourFree B ∧
            OP02.FewHole.DoublingFree B ∧
            (A.card : ℝ) ≤ (B.card : ℝ) + δ * (N : ℝ) := by
    obtain ⟨N0, hN0, hD0⟩ := hD δ hδ
    refine ⟨N0, hN0, ?_⟩
    intro N hN A hsub hfour
    let T : Finset ℕ := A.filter (fun x => 2 * x ∈ A)
    have hTA : T ⊆ A := by
      intro x hx
      exact (Finset.mem_filter.mp hx).1
    have hTI : T ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hTA hx)
    have ht : (T.card : ℝ) < δ * (N : ℝ) := by
      by_contra hn
      have hd : δ * (N : ℝ) ≤ (T.card : ℝ) := le_of_not_gt hn
      obtain ⟨S, hST, hSc, hm⟩ := hD0 N hN T hTI hd
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hTA (hST hx)
      · intro x hx y hy hxy
        obtain ⟨z, hz, hzxy⟩ := hm x hx y hy hxy
        rw [hzxy]
        exact (Finset.mem_filter.mp hz).2
    let B : Finset ℕ := A \ T
    have hBA : B ⊆ A := by
      intro x hx
      exact (Finset.mem_sdiff.mp hx).1
    have hBI : B ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hBA hx)
    have hfB : OP02.FewHole.FourFree B := by
      rintro ⟨S, hSB, hSc, hpair⟩
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hBA (hSB hx)
      · intro x hx y hy hxy
        exact hBA (hpair x hx y hy hxy)
    have hdB : OP02.FewHole.DoublingFree B := by
      intro x hx h2
      obtain ⟨hxA, hxT⟩ := Finset.mem_sdiff.mp hx
      apply hxT
      exact Finset.mem_filter.mpr ⟨hxA, hBA h2⟩
    have hcard : B.card + T.card = A.card :=
      Finset.card_sdiff_add_card_eq_card hTA
    have hcardR : (B.card : ℝ) + (T.card : ℝ) = (A.card : ℝ) := by
      exact_mod_cast hcard
    refine ⟨B, hBI, hfB, hdB, ?_⟩
    linarith only [hcardR, ht]
  have blocks (N : ℕ) :
      ∃ A : Finset ℕ, A ⊆ Finset.Icc 1 N ∧
        OP02.FewHole.FourFree A ∧ A.card = 21 * (N / 32) := by
    let m : ℕ := N / 32
    let J0 : Finset ℕ := Finset.Icc (m + 1) (2 * m)
    let J1 : Finset ℕ := Finset.Icc (4 * m + 1) (8 * m)
    let J2 : Finset ℕ := Finset.Icc (16 * m + 1) (32 * m)
    let A : Finset ℕ := J0 ∪ J1 ∪ J2
    have hmem (x : ℕ) :
        x ∈ A ↔
          (m + 1 ≤ x ∧ x ≤ 2 * m) ∨
          (4 * m + 1 ≤ x ∧ x ≤ 8 * m) ∨
          (16 * m + 1 ≤ x ∧ x ≤ 32 * m) := by
      simp only [A, J0, J1, J2, Finset.mem_union, Finset.mem_Icc] <;> tauto
    have hmN : 32 * m ≤ N := by dsimp [m]; omega
    have hsub : A ⊆ Finset.Icc 1 N := by
      intro x hx
      have hx' := (hmem x).mp hx
      refine Finset.mem_Icc.mpr ⟨?_, ?_⟩
      · rcases hx' with hx' | hx' | hx' <;> omega
      · rcases hx' with hx' | hx' | hx' <;> omega
    have hc0 : J0.card = m := by
      dsimp [J0]
      rw [Nat.card_Icc]
      omega
    have hc1 : J1.card = 4 * m := by
      dsimp [J1]
      rw [Nat.card_Icc]
      omega
    have hc2 : J2.card = 16 * m := by
      dsimp [J2]
      rw [Nat.card_Icc]
      omega
    have h01 : Disjoint J0 J1 := by
      apply Finset.disjoint_left.mpr
      intro x hx hy
      have hx' : m + 1 ≤ x ∧ x ≤ 2 * m := Finset.mem_Icc.mp hx
      have hy' : 4 * m + 1 ≤ x ∧ x ≤ 8 * m := Finset.mem_Icc.mp hy
      omega
    have h012 : Disjoint (J0 ∪ J1) J2 := by
      apply Finset.disjoint_left.mpr
      intro x hx hy
      have hy' : 16 * m + 1 ≤ x ∧ x ≤ 32 * m := Finset.mem_Icc.mp hy
      rcases Finset.mem_union.mp hx with hx | hx
      · have hx' : m + 1 ≤ x ∧ x ≤ 2 * m := Finset.mem_Icc.mp hx
        omega
      · have hx' : 4 * m + 1 ≤ x ∧ x ≤ 8 * m := Finset.mem_Icc.mp hx
        omega
    have hcard : A.card = 21 * m := by
      change (J0 ∪ J1 ∪ J2).card = 21 * m
      rw [Finset.card_union_of_disjoint h012,
        Finset.card_union_of_disjoint h01, hc0, hc1, hc2]
      omega
    have hfour : OP02.FewHole.FourFree A := by
      rintro ⟨S, hSA, hSc, hpairs⟩
      let col : ℕ → ℕ := fun x =>
        if x ≤ 2 * m then 0 else if x ≤ 8 * m then 1 else 2
      have hmaps : ∀ x ∈ S, col x ∈ Finset.Icc 0 2 := by
        intro x hx
        dsimp [col]
        split_ifs <;> norm_num [Finset.mem_Icc]
      have hlt : (Finset.Icc (0 : ℕ) 2).card < S.card := by
        norm_num [hSc, Nat.card_Icc]
      obtain ⟨x, hx, y, hy, hxy, hcol⟩ :=
        Finset.exists_ne_map_eq_of_card_lt_of_maps_to hlt hmaps
      have hxA := (hmem x).mp (hSA hx)
      have hyA := (hmem y).mp (hSA hy)
      have hsumA := (hmem (x + y)).mp (hpairs x hx y hy hxy)
      dsimp [col] at hcol
      split_ifs at hcol <;> omega
    exact ⟨A, hsub, hfour, hcard⟩
  let P : ℕ → ℕ → Prop := fun N t =>
    ∀ A : Finset ℕ, A ⊆ Finset.Icc 1 N → t ≤ A.card →
      ∃ S ⊆ A, S.card = 4 ∧
        ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ A
  have f_spec (N : ℕ) : P N (Erdos865.f N 4) := by
    have hne : ({t : ℕ | P N t} : Set ℕ).Nonempty := by
      refine ⟨N + 1, ?_⟩
      intro A hA hc
      have hcc := Finset.card_le_card hA
      have hIc : (Finset.Icc 1 N).card = N := by
        rw [Nat.card_Icc]
        omega
      rw [hIc] at hcc
      omega
    change sInf {t : ℕ | P N t} ∈ {t : ℕ | P N t}
    exact Nat.sInf_mem hne
  have f_le (N t : ℕ) (ht : P N t) : Erdos865.f N 4 ≤ t := by
    change sInf {u : ℕ | P N u} ≤ t
    exact Nat.sInf_le ht
  have f_lower (N : ℕ) : 21 * (N / 32) < Erdos865.f N 4 := by
    obtain ⟨A, hsub, hfour, hcard⟩ := blocks N
    by_contra hn
    have hfA : Erdos865.f N 4 ≤ A.card := by omega
    exact hfour (f_spec N A hsub hfA)
  have f_witness (N : ℕ) :
      ∃ A : Finset ℕ, A ⊆ Finset.Icc 1 N ∧
        OP02.FewHole.FourFree A ∧ Erdos865.f N 4 ≤ A.card + 1 := by
    have hfpos : 0 < Erdos865.f N 4 := by
      have hf := f_lower N
      omega
    by_contra hno
    have hp : P N (Erdos865.f N 4 - 1) := by
      intro A hA hc
      by_contra hbad
      apply hno
      refine ⟨A, hA, hbad, ?_⟩
      omega
    have hle := f_le N (Erdos865.f N 4 - 1) hp
    omega
  have f_lower_real (N : ℕ) :
      (21 / 32 : ℝ) * (N : ℝ) - 21 ≤ (Erdos865.f N 4 : ℝ) := by
    have hn : N ≤ 32 * (N / 32) + 31 := by omega
    have hf := f_lower N
    have hnr : (N : ℝ) ≤ 32 * ((N / 32 : ℕ) : ℝ) + 31 := by
      exact_mod_cast hn
    have hfr : (21 : ℝ) * ((N / 32 : ℕ) : ℝ) <
        (Erdos865.f N 4 : ℝ) := by
      exact_mod_cast hf
    linarith only [hnr, hfr]
  have f_upper (δ : ℝ) (hδ : 0 < δ) :
      ∃ N0 : ℕ, ∀ N : ℕ, N0 ≤ N →
        (Erdos865.f N 4 : ℝ) ≤
          (21 / 32 : ℝ) * (N : ℝ) + δ * (N : ℝ) + (C : ℝ) + 4 := by
    obtain ⟨N0, hN0, hdel⟩ := deletion δ hδ
    refine ⟨N0, ?_⟩
    intro N hN
    obtain ⟨A, hAI, hAfour, hfA⟩ := f_witness N
    obtain ⟨B, hBI, hBfour, hBdbl, hloss⟩ := hdel N hN A hAI hAfour
    have hb := hnormAny N B hBI hBfour hBdbl
    have hfa : (Erdos865.f N 4 : ℝ) ≤ (A.card : ℝ) + 1 := by
      exact_mod_cast hfA
    linarith only [hb, hloss, hfa]
  change Asymptotics.IsLittleO Filter.atTop
    (fun N : ℕ => (Erdos865.f N 4 : ℝ) - (21 / 32 : ℝ) * (N : ℝ))
    (fun N : ℕ => (21 / 32 : ℝ) * (N : ℝ))
  apply Asymptotics.isLittleO_iff.mpr
  intro ε hε
  let δ : ℝ := ε * (21 / 32 : ℝ) / 2
  have hδ : 0 < δ := by dsimp [δ]; positivity
  obtain ⟨N0, hN0⟩ := f_upper δ hδ
  obtain ⟨M, hM⟩ := exists_nat_gt (((C : ℝ) + 25) / δ)
  apply Filter.eventually_atTop.mpr
  refine ⟨max N0 M, ?_⟩
  intro N hN
  have hN0' : N0 ≤ N := le_trans (le_max_left _ _) hN
  have hMN : M ≤ N := le_trans (le_max_right _ _) hN
  have hMNreal : (M : ℝ) ≤ (N : ℝ) := by exact_mod_cast hMN
  have hdiv : ((C : ℝ) + 25) / δ < (N : ℝ) :=
    lt_of_lt_of_le hM hMNreal
  have hsmall : (C : ℝ) + 25 ≤ δ * (N : ℝ) := by
    have hh : (C : ℝ) + 25 < (N : ℝ) * δ :=
      (div_lt_iff₀ hδ).mp hdiv
    nlinarith only [hh]
  have hup := hN0 N hN0'
  have hlo := f_lower_real N
  have hCnonneg : 0 ≤ (C : ℝ) := by positivity
  have hnn : 0 ≤ (21 / 32 : ℝ) * (N : ℝ) := by positivity
  change ‖(Erdos865.f N 4 : ℝ) - (21 / 32 : ℝ) * (N : ℝ)‖ ≤
    ε * ‖(21 / 32 : ℝ) * (N : ℝ)‖
  simp only [Real.norm_eq_abs, abs_of_nonneg hnn]
  apply abs_le.mpr
  dsimp [δ] at hup hsmall
  constructor <;> nlinarith only [hup, hlo, hsmall, hCnonneg]
end OP02ReviewedS3

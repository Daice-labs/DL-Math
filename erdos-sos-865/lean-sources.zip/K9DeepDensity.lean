import K9DeepTriangle

open Finset OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.SharpK5 OP02.SharpK7 OP02.SharpK8
namespace OP02.SharpK9

/-- One radial prefix and one physical division lose at most one unit in the real-valued projection. -/
theorem deep_projected_density {h : ℕ} {G : Finset ℕ} {g : ℝ}
    (sub : G ⊆ Icc 1 h) (hd : DoublingFree G)
    (density : (85/128:ℝ)*h+g ≤ G.card) :
    (5/8:ℝ)*(h/16:ℕ)+g-1 ≤ (quarterD (h/4) G).card := by
  have c := top_band_cancellation h G sub hd
  change (lower (h/4) G).card+(h+1)/2=G.card+(unmatchedTop h G).card at c
  have d := lower_card_eq (h/4) G
  have e := residue_card_le (h/4) G hd
  have total : G.card ≤ (quarterD (h/4) G).card + (h+1)/2 + (h/4+1)/2 := by omega
  have num : 128*(((h+1)/2)+((h/4+1)/2))+80*(h/16) ≤ 85*h+128 := by omega
  have tr : (G.card:ℝ) ≤ ((quarterD (h/4) G).card:ℝ) + ((h+1)/2:ℕ) + ((h/4+1)/2:ℕ) := by
    exact_mod_cast total
  have nr : (128:ℝ)*(((h+1)/2:ℕ)+((h/4+1)/2:ℕ))+80*(h/16:ℕ) ≤ 85*(h:ℝ)+128 := by
    exact_mod_cast num
  linarith only [tr,nr,density]

/-- The complement of the canonical indices consists of the doubles of the canonical indices. -/
theorem capacity_complement (h : ℕ) : chainCapacity h+chainCapacity (h/2)=h := by
  induction h using Nat.strong_induction_on with
  | h h ih =>
    by_cases z : h=0
    · subst h; simp [chainCapacity,canonicalSlots]
    · have small := ih (h/4) (by omega)
      have a := canonical_capacity_recurrence h
      have b := canonical_capacity_recurrence (h/2)
      rw [show (h/2)/4=(h/4)/2 by omega] at b
      have low : (h/2+1)/2+h/4=h/2 := by omega
      have high : (h+1)/2+h/2=h := by omega
      omega

/-- A positive density margin in G alone supplies the uniform delayed triangle. All
trials are charged against the same finite inventory at h, including the shallow reserve. -/
theorem deep_triangle_for_reserve (ε : ℝ) (he : 0<ε) :
    ∃ M : ℕ, ∀ h : ℕ, M≤h → ∀ G : Finset ℕ, G⊆Icc 1 h → DoublingFree G →
      (85/128+ε)*(h:ℝ) ≤ G.card → ∀ s : ℕ, s+(deepFaults h G).card≤chainCapacity h-G.card →
      6*s<h/64 ∧ 384*(chainCapacity h-G.card)<h ∧ DelayedTriangle h s G := by
  obtain ⟨C,hC⟩ := capacity_uniform_error (ε/8) (by positivity)
  obtain ⟨N,hN⟩ := exists_nat_gt (100/ε)
  refine ⟨max (2048*(C+1)) N,?_⟩
  intro h large G sub hd density s reserve
  let b := h/64
  let d := (deepFaults h G).card
  let K := chainCapacity h-G.card
  let E : ℝ := (ε/8)*h
  have enn : 0≤E := by dsimp [E]; positivity
  have hNr : (N:ℝ) ≤ h := by exact_mod_cast (show N≤h by omega)
  have mass := (div_lt_iff₀ he).mp (lt_of_lt_of_le hN hNr)
  have strong : (85/128:ℝ)*h+4*E+20 ≤ G.card := by dsimp [E]; nlinarith only [density,mass]
  have major {x : ℕ} (low : C≤x) (high : x≤h) :
      (chainCapacity x:ℝ) ≤ (2/3:ℝ)*x+E := by
    have xr : (x:ℝ) ≤ h := by exact_mod_cast high
    exact (hC x low).trans (add_le_add_right (mul_le_mul_of_nonneg_left xr (by positivity : 0≤ε/8)) _)
  have cap := major (x:=h) (by omega) le_rfl
  have base := chain_capacity_with_top_loss h G sub hd
  have balance : K+G.card=chainCapacity h := by dsimp [K]; omega
  have br : (K:ℝ)+G.card=chainCapacity h := by exact_mod_cast balance
  have kr : (K:ℝ)≤(h:ℝ)/384-3*E-20 := by linarith only [br,cap,strong]
  have fr : (s:ℝ)+d≤K := by exact_mod_cast reserve
  have dn : (0:ℝ)≤d := by positivity
  have sn : (0:ℝ) ≤ s := by positivity
  have hr : (h:ℝ)≤64*(b:ℝ)+63 := by exact_mod_cast (show h≤64*b+63 by dsimp [b]; omega)
  have sSmall : 6*s<b := by
    exact_mod_cast (show 6*(s:ℝ)<b by linarith only [kr,fr,dn,hr,enn])
  have kSmall : 384*K<h := by
    exact_mod_cast (show 384*(K:ℝ)<h by linarith only [kr,enn])
  refine ⟨sSmall,kSmall,deep_triangle_finite sub hd ?_ ?_ ?_⟩
  · have y := deep_projected_density (g:=4*E+20) sub hd (by linarith only [strong])
    have diag : 8*((h/64+1)/2+(h/16+1)/2)≤5*(h/16)+8 := by omega
    have rr : (8:ℝ)*(((h/64+1)/2:ℕ)+((h/16+1)/2:ℕ))≤5*(h/16:ℕ)+8 := by exact_mod_cast diag
    exact_mod_cast (show (((h/64+1)/2:ℕ):ℝ)+((h/16+1)/2:ℕ) < (quarterD (h/4) G).card by
      linarith only [y,rr,enn])
  · let p := (deepStart h s+1)/2
    let q := (deepEnd h+1)/2
    have pr : 2*(p:ℝ)≤2*(b:ℝ)+4*(s:ℝ)+13 := by
      exact_mod_cast (show 2*p≤2*b+4*s+13 by dsimp [p,deepStart,b]; omega)
    have qr : 3*(b:ℝ)≤2*(q:ℝ) := by
      exact_mod_cast (show 3*b≤2*q by dsimp [q,deepEnd,b]; omega)
    have bigger : 3*d+p<q := by
      exact_mod_cast (show 3*(d:ℝ)+p<q by linarith only [pr,qr,kr,fr,hr,enn,sn])
    change 3*d<q-p
    omega
  · let A := deepEnd h/4
    let B := deepStart h s/4
    have mA := major (x:=A/2) (by dsimp [A,deepEnd]; omega) (by dsimp [A,deepEnd]; omega)
    have mB := major (x:=B) (by dsimp [B,deepStart]; omega) (by
      dsimp [B,deepStart]; dsimp only [b] at sSmall; omega)
    have halfA : 2*((A/2:ℕ):ℝ)≤(A:ℝ) := by exact_mod_cast (show 2*(A/2)≤A by omega)
    have comp : (chainCapacity A:ℝ)+chainCapacity (A/2)=A := by exact_mod_cast capacity_complement A
    have lowA : (2/3:ℝ)*A-E ≤ chainCapacity A := by linarith only [mA,halfA,comp]
    have floorA : 3*(b:ℝ)≤4*(A:ℝ)+3 := by
      exact_mod_cast (show 3*b≤4*A+3 by dsimp [A,deepEnd,b]; omega)
    have floorB : 4*(B:ℝ)≤2*(b:ℝ)+4*(s:ℝ)+12 := by
      exact_mod_cast (show 4*B≤2*b+4*s+12 by dsimp [B,deepStart,b]; omega)
    have bigger : d+chainCapacity B<chainCapacity A := by
      exact_mod_cast (show (d:ℝ)+chainCapacity B<chainCapacity A by
        linarith only [lowA,mB,floorA,floorB,kr,fr,hr,enn,sn])
    change d<chainCapacity A-chainCapacity B
    omega

theorem deep_triangle_uniform (ε : ℝ) (he : 0<ε) :
    ∃ M : ℕ, ∀ h : ℕ, M≤h → ∀ G : Finset ℕ, G⊆Icc 1 h → DoublingFree G →
      (85/128+ε)*(h:ℝ) ≤ G.card →
      6*(shallowFaults h G).card<h/64 ∧ 384*(chainCapacity h-G.card)<h ∧
        DelayedTriangle h (shallowFaults h G).card G := by
  obtain ⟨M,supply⟩ := deep_triangle_for_reserve ε he
  exact ⟨M,fun h large G sub hd den => supply h large G sub hd den _ (fault_budget sub hd)⟩

end OP02.SharpK9

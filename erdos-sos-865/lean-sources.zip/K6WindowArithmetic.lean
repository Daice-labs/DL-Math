import K6BandAccounting
namespace OP02.SharpK6
set_option maxHeartbeats 1000000

def finalWindowL (n δ w:ℕ) := n+(4*δ+4)+w/2+2
def finalWindowU (n δ w m s:ℕ) :=
  min ((3*n+w)/2-4*s)
    (min ((4*(n-4*(n/16))-2*(4*δ+4)+w-m)/2-4*s-2)
      (2*(n-4*(n/16))-(4*δ+4)-1))

theorem final_window_length (n δ w m s q:ℕ)
    (hn:65536 ≤ n) (hq:384*q ≤ n) (hδ:δ ≤ q)
    (hw:4*w ≤ 3*n) (hm:2*m ≤ n) (hs:s ≤ n/16) :
    min (n-w) (n-m-8*s) ≤ 
      2*(finalWindowU n δ w m s-finalWindowL n δ w)+4*(4*δ+4)+16 := by
  let k:=min (n-w) (n-m-8*s)
  have hk1:k+w ≤ n := by have:=min_le_left (n-w) (n-m-8*s); dsimp only [k]; omega
  have hk2:k+m+8*s ≤ n := by have:=min_le_right (n-w) (n-m-8*s); dsimp only [k]; omega
  have h1:k+2*(n+(4*δ+4)+w/2+2) ≤ 2*((3*n+w)/2-4*s)+4*(4*δ+4)+16 := by omega
  have h2:k+2*(n+(4*δ+4)+w/2+2) ≤ 2*((4*(n-4*(n/16))-2*(4*δ+4)+w-m)/2-4*s-2)+4*(4*δ+4)+16 := by omega
  have h3:k+2*(n+(4*δ+4)+w/2+2) ≤ 2*(2*(n-4*(n/16))-(4*δ+4)-1)+4*(4*δ+4)+16 := by omega
  change k ≤ _
  unfold finalWindowL finalWindowU
  omega

theorem final_window_point (n δ w m s q y t:ℕ)
    (hn:65536 ≤ n) (hq:384*q ≤ n) (hδ:δ ≤ q)
    (hw:4*w ≤ 3*n) (hm:2*m ≤ n) (hs:s ≤ n/16) (ht:t ≤ s)
    (hyL : finalWindowL n δ w  <  y) (hyU : y  ≤  finalWindowU n δ w m s) :
    n < y ∧ y < 2*(n-4*(n/16))-(4*δ+4) ∧ n+(4*δ+4) < y ∧ 4*y ≤ 7*n ∧
    n < y+4*t ∧ y+4*t ≤ 2*n ∧ 2*n+w < 2*(y+4*t) ∧
    2*(y+4*t)+n ≤ 4*n+w ∧
    2*n+2*(4*δ+4) < 2*(y+4*t)-w ∧
    2*(y+4*t)-w+m < 4*(n-4*(n/16))-2*(4*δ+4) := by
  unfold finalWindowL at hyL
  unfold finalWindowU at hyU
  have hu1:=le_trans hyU (min_le_left _ _)
  have hu2:=le_trans (le_trans hyU (min_le_right _ _)) (min_le_left _ _)
  have hu3:=le_trans (le_trans hyU (min_le_right _ _)) (min_le_right _ _)
  clear hyU
  repeat' constructor  <;> omega

#print axioms final_window_length
#print axioms final_window_point
end OP02.SharpK6

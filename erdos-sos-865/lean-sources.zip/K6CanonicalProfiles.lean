import K6MiddleGapComplete
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 4000000

theorem canonical_upper_profile6 (n b:ℕ) (B S:Finset ℕ)
    (hf:SixFree B) (hS:S⊆lower n B) (hSc:S.card=5)
    (hpairs:∀x∈S,∀y∈S,x≠y → x+y∈B)
    (hb:b<4) (havoid:∀s∈insert 0 S,(b+s)%4≠2)
    (he:((insert 0 S).filter (fun s=>(b+s)%2=0)).card≤3)
    (hbudget:6*(canonicalHoles n B).card<n/32) : False := by
  classical
  let Q:=insert 0 S
  have hQc:Q.card≤6 := by have:=card_insert_le 0 S; dsimp only [Q]; omega
  obtain ⟨v,hv,hvb,hcan⟩:=canonical_profile_class Q b hb havoid he
  let Y:=progression (2*n) (3*n) 32 v
  have hY (p:ℕ) (hp:p∈Y):2*n<p ∧ p≤3*n ∧ p%32=v := by
    obtain ⟨hi,hr⟩:=mem_filter.mp hp
    exact ⟨(mem_Ioc.mp hi).1,(mem_Ioc.mp hi).2,hr⟩
  have hbnd:∀s∈Q,s≤n := by
    intro s hs
    rcases mem_insert.mp hs with rfl|hs
    · omega
    · exact (mem_Icc.mp (mem_inter.mp (hS hs)).2).2
  have hc:Y.card≤6*(canonicalHoles n B).card := by
    apply affine_cover_bound Y Q (canonicalHoles n B) 0 (v%4) 1 6 (by omega)
    · intro p hp; have:=hY p hp; omega
    · intro j; exact le_trans (card_filter_le _ _) hQc
    · intro p hp
      have hpI:=hY p hp
      have hpS:p∉S:=by intro hs; have:=hbnd p (mem_insert_of_mem hs); omega
      obtain ⟨s,hs,hbad⟩:=five_clique_missing_label B S hf
        (fun x hx=>(mem_inter.mp (hS hx)).1) hSc hpairs p hpS
      have hsn:=hbnd s hs
      exact ⟨s,hs,p+s,mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hbad⟩,hcan p hpI.2.2 s hs⟩,by omega⟩
  have hl:=progression_lower (2*n) (3*n) 32 v (by simp) hv
  change (3*n-2*n)/32≤Y.card at hl
  omega

/-- A finite residue statement used only to dispatch the canonical profiles.
Counts retain multiplicity: coincident residue labels are not identified. -/
def easyResidues (a b c d e:Fin 4) : Prop :=
 let V:List ℕ:=[a.val,b.val,c.val,d.val,e.val]
 let o:=(if a.val%2=1 then 1 else 0)+(if b.val%2=1 then 1 else 0)+(if c.val%2=1 then 1 else 0)+(if d.val%2=1 then 1 else 0)+(if e.val%2=1 then 1 else 0)
 o=0 ∨ o=1 ∨ o=5 ∨
 ((o=2 ∨ o=3) ∧ (∀x∈V,∀y∈V,x%2=1 → y%2=1 → x%4=y%4)) ∨
 ((o=3 ∨ o=4) ∧ (∀x∈V,x%2=0 → x%4=0))

theorem easy_residue_selection : ∀a b c d e:Fin 4,easyResidues a b c d e →
 ∃p:Fin 4,
 (∀x∈([0,a.val,b.val,c.val,d.val,e.val]:List ℕ),(p.val+x)%4≠2) ∧
 ((if p.val%2=0 then 1 else 0)+(if (p.val+a.val)%2=0 then 1 else 0)+(if (p.val+b.val)%2=0 then 1 else 0)+(if (p.val+c.val)%2=0 then 1 else 0)+(if (p.val+d.val)%2=0 then 1 else 0)+(if (p.val+e.val)%2=0 then 1 else 0))≤3 := by
  unfold easyResidues
  decide

#print axioms canonical_upper_profile6
#print axioms easy_residue_selection

def EasyProfile (S:Finset ℕ) : Prop :=
 let o:=(S.filter (fun x=>x%2=1)).card
 o=0 ∨ o=1 ∨ o=5 ∨
 ((o=2 ∨ o=3) ∧ (∀x∈S,∀y∈S,x%2=1 → y%2=1 → x%4=y%4)) ∨
 ((o=3 ∨ o=4) ∧ (∀x∈S,x%2=0 → x%4=0))

theorem easy_profile_selection (S:Finset ℕ) (hSc:S.card=5) (hz:0∉S) (hEasy:EasyProfile S) :
    ∃b<4,(∀s∈insert 0 S,(b+s)%4≠2) ∧
      ((insert 0 S).filter (fun s=>(b+s)%2=0)).card≤3 := by
  classical
  have hn:S.Nonempty:=card_pos.mp (by omega)
  obtain ⟨a,ha⟩:=hn
  have hc:(S.erase a).card=4:=by rw [card_erase_of_mem ha,hSc]
  obtain ⟨b,c,d,e,hbc,hbd,hbe,hcd,hce,hde,hT⟩:=card_eq_four.mp hc
  have hb:b∈S.erase a:=by simp [hT]
  have hc:c∈S.erase a:=by simp [hT]
  have hd:d∈S.erase a:=by simp [hT]
  have he:e∈S.erase a:=by simp [hT]
  have hab:a≠b:=(mem_erase.mp hb).1.symm
  have hac:a≠c:=(mem_erase.mp hc).1.symm
  have had:a≠d:=(mem_erase.mp hd).1.symm
  have hae:a≠e:=(mem_erase.mp he).1.symm
  have hS:S={a,b,c,d,e} := by rw [←insert_erase ha,hT]
  have ha0:0≠a:=by intro h; exact hz (h ▸ ha)
  have hb0:0≠b:=by intro h; exact hz (h ▸ (mem_erase.mp hb).2)
  have hc0:0≠c:=by intro h; exact hz (h ▸ (mem_erase.mp hc).2)
  have hd0:0≠d:=by intro h; exact hz (h ▸ (mem_erase.mp hd).2)
  have he0:0≠e:=by intro h; exact hz (h ▸ (mem_erase.mp he).2)
  have hcount:(S.filter (fun x=>x%2=1)).card=
      (if a%2=1 then 1 else 0)+(if b%2=1 then 1 else 0)+(if c%2=1 then 1 else 0)+
      (if d%2=1 then 1 else 0)+(if e%2=1 then 1 else 0) := by
    rw [card_eq_sum_ones,sum_filter]
    simp only [hS,sum_insert,mem_insert,mem_singleton,hab,hac,had,hae,hbc,hbd,hbe,hcd,hce,hde,
      false_or,not_false_eq_true,sum_singleton,Nat.add_zero,Nat.add_assoc]
  have mod42 (x:ℕ):(x%4)%2=x%2:=by omega
  have hfinite:easyResidues ⟨a%4,by omega⟩ ⟨b%4,by omega⟩ ⟨c%4,by omega⟩ ⟨d%4,by omega⟩ ⟨e%4,by omega⟩ := by
    unfold EasyProfile at hEasy
    rw [hcount] at hEasy
    unfold easyResidues
    dsimp only
    simp only [mod42]
    rcases hEasy with h0|h1|h5|⟨ho,hodd⟩|⟨ho,heven⟩
    · exact Or.inl h0
    · exact Or.inr (Or.inl h1)
    · exact Or.inr (Or.inr (Or.inl h5))
    · apply Or.inr; apply Or.inr; apply Or.inr; apply Or.inl
      refine ⟨ho,?_⟩
      intro x hx y hy hxo hyo
      simp only [List.mem_cons,List.mem_singleton,List.not_mem_nil,or_false] at hx hy
      rcases hx with rfl|rfl|rfl|rfl|rfl <;>
        rcases hy with rfl|rfl|rfl|rfl|rfl <;>
        simp only [Nat.mod_mod,mod42] at * <;>
        apply hodd <;> (first | assumption | simp [hS])
    · apply Or.inr; apply Or.inr; apply Or.inr; apply Or.inr
      refine ⟨ho,?_⟩
      intro x hx hxe
      simp only [List.mem_cons,List.mem_singleton,List.not_mem_nil,or_false] at hx
      rcases hx with rfl|rfl|rfl|rfl|rfl <;>
        simp only [Nat.mod_mod,mod42] at * <;>
        apply heven <;> (first | assumption | simp [hS])
  obtain ⟨p,havoid,hpc⟩:=easy_residue_selection _ _ _ _ _ hfinite
  refine ⟨p.val,p.isLt,?_,?_⟩
  · intro s hs
    simp only [hS,mem_insert,mem_singleton] at hs
    have hp0:=havoid 0 (by simp)
    have hpa:=havoid (a%4) (by simp)
    have hpb:=havoid (b%4) (by simp)
    have hpc:=havoid (c%4) (by simp)
    have hpd:=havoid (d%4) (by simp)
    have hpe:=havoid (e%4) (by simp)
    rcases hs with rfl|rfl|rfl|rfl|rfl|rfl <;> omega
  · have hcard:((insert 0 S).filter (fun s=>(p.val+s)%2=0)).card=
      (if p.val%2=0 then 1 else 0)+(if (p.val+a)%2=0 then 1 else 0)+
      (if (p.val+b)%2=0 then 1 else 0)+(if (p.val+c)%2=0 then 1 else 0)+
      (if (p.val+d)%2=0 then 1 else 0)+(if (p.val+e)%2=0 then 1 else 0) := by
      rw [card_eq_sum_ones,sum_filter]
      simp only [hS,sum_insert,mem_insert,mem_singleton,ha0,hb0,hc0,hd0,he0,hab,hac,had,hae,hbc,hbd,hbe,hcd,hce,hde,
        false_or,not_false_eq_true,sum_singleton,Nat.add_zero,Nat.add_assoc]
    rw [hcard]
    have hmod (x:ℕ):(p.val+x%4)%2=(p.val+x)%2:=by omega
    simpa only [hmod] using hpc

theorem easy_profile_excluded (n:ℕ) (B S:Finset ℕ)
    (hf:SixFree B) (hS:S⊆lower n B) (hSc:S.card=5)
    (hpairs:∀x∈S,∀y∈S,x≠y → x+y∈B)
    (hbudget:6*(canonicalHoles n B).card<n/32) : ¬EasyProfile S := by
  intro hEasy
  have hz:0∉S:=by intro h; have:=(mem_Icc.mp (mem_inter.mp (hS h)).2).1; omega
  obtain ⟨b,hb,havoid,he⟩:=easy_profile_selection S hSc hz hEasy
  exact canonical_upper_profile6 n b B S hf hS hSc hpairs hb havoid he hbudget

#print axioms easy_profile_selection
#print axioms easy_profile_excluded


/-- Exhaustive dispatch after canonical exclusions. The two- and four-odd
replacement branches are explicit, not silently assumed discharged. -/
theorem canonical_profile_dispatch (n:ℕ) (B S:Finset ℕ)
    (hf:SixFree B) (hS:S⊆lower n B) (hSc:S.card=5)
    (hpairs:∀x∈S,∀y∈S,x≠y → x+y∈B)
    (hbudget:6*(canonicalHoles n B).card<n/32) :
    let o:=(S.filter (fun x=>x%2=1)).card
    (o=2 ∧ ∃u∈S,∃v∈S,u%2=1 ∧ v%2=1 ∧ u%4≠v%4) ∨
    (o=4 ∧ ∃v∈S,v%4=2) ∨
    (o=3 ∧ (∃u∈S,∃v∈S,u%2=1 ∧ v%2=1 ∧ u%4≠v%4) ∧ ∃v∈S,v%4=2) := by
  have he:=easy_profile_excluded n B S hf hS hSc hpairs hbudget
  let o:=(S.filter (fun x=>x%2=1)).card
  have ho:o≤5:=by have:=card_filter_le S (fun x=>x%2=1); omega
  have ho0:o≠0:=by intro h; exact he (Or.inl h)
  have ho1:o≠1:=by intro h; exact he (Or.inr (Or.inl h))
  have ho5:o≠5:=by intro h; exact he (Or.inr (Or.inr (Or.inl h)))
  have hodd (h:o=2 ∨ o=3):∃u∈S,∃v∈S,u%2=1 ∧ v%2=1 ∧ u%4≠v%4 := by
    by_contra hh
    push_neg at hh
    apply he
    apply Or.inr; apply Or.inr; apply Or.inr; apply Or.inl
    refine ⟨h,?_⟩
    intro u hu v hv huo hvo
    exact hh u hu v hv huo hvo
  have heven (h:o=3 ∨ o=4):∃v∈S,v%4=2 := by
    by_contra hh
    push_neg at hh
    apply he
    apply Or.inr; apply Or.inr; apply Or.inr; apply Or.inr
    refine ⟨h,?_⟩
    intro v hv hv0
    have:=hh v hv
    omega
  have hcsmall:∀k:ℕ,k≤5 → k≠0 → k≠1 → k≠5 → k=2 ∨ k=3 ∨ k=4 := by
    intro k hk h0 h1 h5
    omega
  have hcases:o=2 ∨ o=3 ∨ o=4:=hcsmall o ho ho0 ho1 ho5
  rcases hcases with h|h|h
  · exact Or.inl ⟨h,hodd (Or.inl h)⟩
  · exact Or.inr (Or.inr ⟨h,hodd (Or.inr h),heven (Or.inl h)⟩)
  · exact Or.inr (Or.inl ⟨h,heven (Or.inr h)⟩)

#print axioms canonical_profile_dispatch

end OP02.SharpK6

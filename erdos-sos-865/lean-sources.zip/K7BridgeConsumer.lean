import K7BridgeQuartet
import K7HistoricalRows

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- A quartet of actual roots cannot have a common odd neighbor in the
low interval. The six sums among the roots need only be actual. The
largest of the four sums with the odd neighbor is allowed to exceed H. -/
theorem quartet_has_no_odd_half {n y:ℕ} {B Q:Finset ℕ} (hf:SevenFree B)
    (hd:DoublingFree B) (hg:MiddleGap7 n B) (hn:65536≤n)
    (hcap:384*(chainDeficit n B+totalBudget n B)≤n/4)
    (hc:Q.card=4) (hQ:internalOn B Q) (hsmall:∀x∈Q,x≤n/4 ∧ x%4=0)
    (hy:y≤n/4) (hyo:y%2=1) (hyB:y∈B) (hcross:∀x∈Q,y+x∈B) : False := by
  classical
  let T:=insert y Q
  let O:=insert 0 T
  let r:=(12-y%8)%8
  let P:=progression (n/2) (3*n/4) 8 r
  let E:=(Ioc (n/2) n).filter (fun v=>canonical v=true ∧ v∉B)
  have ny:y∉Q:=by intro h;have :=hsmall _ h;omega
  have T5:T.card=5:=by simp [T,ny,hc]
  have Tsize:∀x∈T,x≤n/4:=by intro x hx;rcases mem_insert.mp hx with rfl|h;exact hy;exact (hsmall _ h).1
  have data {x} (h:x∈P):n/2<x ∧ x≤3*n/4 ∧ x%8=r:=by
    rcases mem_filter.mp h with ⟨h,he⟩;exact ⟨(mem_Ioc.mp h).1,(mem_Ioc.mp h).2,he⟩
  have hE:E.card≤chainDeficit n B+totalBudget n B:=canonical_lower_losses n B hd
  have hO:O.card≤6:=by have :=card_insert_le 0 T;dsimp [O];omega
  have cnt:=shift_losses P O B E 1 0 6 (by intro _ _;omega) (by
    intro w hw v hv hm
    have ww:=data hw
    have wr:w%2=1 ∧ (w+y)%8=4:=by dsimp [r] at ww;omega
    have xh:v≤n/4:=by rcases mem_insert.mp hv with rfl|h;omega;exact Tsize v h
    refine mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,?_,hm⟩
    rcases mem_insert.mp hv with rfl|vT
    · exact canonical_odd _ (by omega)
    rcases mem_insert.mp vT with rfl|vQ
    · rw [show w+v=4*((w+v)/4) by omega,canonical_four]
      exact canonical_odd _ (by omega)
    · have :=hsmall _ vQ;exact canonical_odd _ (by omega))
    (fun _ _=>(card_filter_le _ _).trans hO)
  have sup:=progression_lower (n/2) (3*n/4) 8 r (by decide) (by dsimp [r];omega)
  change _≤P.card at sup
  obtain ⟨w,hw⟩:=card_pos.mp (show 0<(passes P O B).card by omega)
  obtain ⟨pw,hh⟩:=mem_filter.mp hw;have ww:=data pw
  have wo:w%2=1:=by dsimp [r] at ww;omega
  have wn:w∉T:=by intro h;have :=Tsize _ h;omega
  have tcl:internalOn B T:=append_clique hQ hyB hcross
  have scl:=append_clique tcl (by simpa using hh 0 (mem_insert_self _ _)) (fun x hx=>hh _ (mem_insert_of_mem hx))
  apply pv_six hf hd hg hn (by omega) scl (by simp [wn,T5])
  · intro x hx;rcases mem_insert.mp hx with rfl|h;omega;have :=Tsize _ h;omega
  · intro x hx xe;rcases mem_insert.mp hx with rfl|h;omega
    rcases mem_insert.mp h with rfl|h;omega
    have :=hsmall _ h;exact ⟨this.2,by omega⟩

/-- Physical form for the quartet returned by actual_bridge_quartet. -/
theorem selected_common_half_impossible {n a c b z y:ℕ} {B:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hg:MiddleGap7 n B) (hn:65536≤n)
    (hcap:384*(chainDeficit n B+totalBudget n B)≤n/4)
    (ac:a<c) (cb:c<b) (bz:b<z) (zs:4*z≤n/4) (ys:y≤n/4) (yo:y%2=1)
    (ha:a∈quarterD n B) (hc:c∈quarterD n B) (hb:b∈quarterD n B) (hz:z∈quarterD n B)
    (h₁:a+c∈quarterD n B) (h₂:b+a∈quarterD n B) (h₃:b+c∈quarterD n B)
    (h₄:z+a∈quarterD n B) (h₅:z+c∈quarterD n B) (h₆:z+b∈quarterD n B)
    (hy:y∈B) (hxy:∀x∈({a,c,b,z}:Finset ℕ),y+4*x∈B):False:=by
  let T:Finset ℕ:={a,c,b,z}
  have hT:T.card=4:=by simp [T,show a≠c by omega,show a≠b by omega,show a≠z by omega,
    show c≠b by omega,show c≠z by omega,show b≠z by omega]
  have hcl:internalOn (quarterD n B) T:=by
    constructor
    · intro x hx;simp only [T,mem_insert,mem_singleton] at hx
      rcases hx with rfl|rfl|rfl|rfl <;> assumption
    · intro x hx v hv hne;simp only [T,mem_insert,mem_singleton] at hx hv
      rcases hx with rfl|rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl|rfl <;>
        first | exact (hne rfl).elim | assumption | rw [Nat.add_comm];assumption
  let Q:=T.image (fun x:ℕ=>4*x)
  have hsize:Q.card=4:=by exact (card_image_of_injective _ (show Function.Injective (fun x:ℕ=>4*x) from fun x y h=>by change 4*x=4*y at h;omega)).trans hT
  apply quartet_has_no_odd_half (Q:=Q) hf hd hg hn hcap hsize _ _ ys yo hy
  · intro x hx;obtain ⟨j,hj,rfl⟩:=mem_image.mp hx;exact hxy _ hj
  · constructor
    · intro x hx;obtain ⟨j,hj,rfl⟩:=mem_image.mp hx;exact (mem_filter.mp (hcl.1 hj)).2
    · intro x hx w hw hne;obtain ⟨i,hi,rfl⟩:=mem_image.mp hx;obtain ⟨j,hj,rfl⟩:=mem_image.mp hw
      simpa only [Nat.mul_add] using (mem_filter.mp (hcl.2 i hi j hj (by omega))).2
  · intro x hx;obtain ⟨j,hj,rfl⟩:=mem_image.mp hx
    have jz:j≤z:=by simp only [T,mem_insert,mem_singleton] at hj;omega
    exact ⟨by omega,by omega⟩

end OP02.SharpK7

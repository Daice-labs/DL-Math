import K5BandCompatibility
import K5CliqueShape
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 1000000

/-- Both bands of the same actual clique force its designated high vertex.
All partner supply and clipping losses have been discharged in the preceding lemmas. -/
theorem designated_high_vertex (n u v r s:ℕ) (B S:Finset ℕ)
    (hn:1024≤n) (hf:FiveFree B) (hd:DoublingFree B) (hq:128*totalBudget n B≤n)
    (hbudget:3*(canonicalHoles n B).card<n/32)
    (hdense:5*n+32*totalBudget n B+52<32*(quarterD n B).card)
    (hS:S⊆lower n B) (hc:S.card=4)
    (hp:∀x∈S,∀y∈S,x≠y→x+y∈B)
    (hu:u∈insert 0 S) (hv:v∈insert 0 S) (hul:2*u<n)
    (hres:(u+2)%4=v%4)
    (hother:∀x∈insert 0 S\{u,v},x%2≠u%2)
    (hload:∀j:ℕ,((insert 0 S\{u,v}).filter (fun x=>x%4=j)).card≤2)
    (hr:r∈quarterD n B) (hs:s∈quarterD n B) (hrs:r≠s)
    (hrsD:r+s∈quarterD n B) (hsmall:r+s≤n/16) : n-v≤highThreshold n B := by
  have hSI:S⊆Icc 1 n := fun x hx=>(mem_inter.mp (hS hx)).2
  have hvn:v≤n := by
    rcases mem_insert.mp hv with rfl|hh
    · omega
    · exact (mem_Icc.mp (hSI hh)).2
  obtain ⟨σ,hσ,hσres⟩ : ∃σ:ℕ,(σ=1 ∨ σ=3) ∧ (2*σ+v)%8=(u+4)%8 := by
    by_cases hh:(2+v)%8=(u+4)%8
    · exact ⟨1,Or.inl rfl,by omega⟩
    · exact ⟨3,Or.inr rfl,by omega⟩
  have hband1:=forced_band_bound n u v σ B S hf hS hc hp hu hv hσ hσres hother hload
  change (forcedBand n S u σ\B).card≤bandCost n σ B at hband1
  have hempty:=opposite_neighbors_empty n u σ r s B S hn hf hd hq hbudget hdense hul hσ hSI
    hr hs hrs hrsD hsmall hband1
  have hσ2:4-σ=1 ∨ 4-σ=3 := by omega
  have hres2:(2*(4-σ)+u)%8=(v+4)%8 := by omega
  have hother2:∀x∈insert 0 S\{v,u},x%2≠v%2 := by
    intro x hx
    have hh:=hother x (by simpa only [pair_comm] using hx)
    omega
  have hload2:∀j:ℕ,((insert 0 S\{v,u}).filter (fun x=>x%4=j)).card≤2 := by
    intro j; simpa only [pair_comm] using hload j
  have hband2:=forced_band_bound n v u (4-σ) B S hf hS hc hp hv hu hσ2 hres2 hother2 hload2
  change (forcedBand n S v (4-σ)\B).card≤bandCost n (4-σ) B at hband2
  exact high_vertex_from_empty n v (4-σ) r s B S hn hq hd hvn hσ2 hSI hsmall hband2 hempty

/-- Uniform conclusion for every actual internal lower four-clique. -/
theorem every_lower_clique_high (n r s:ℕ) (B S:Finset ℕ)
    (hn:1024≤n) (hf:FiveFree B) (hd:DoublingFree B) (hq:128*totalBudget n B≤n)
    (hbudget:3*(canonicalHoles n B).card<n/32)
    (hdense:5*n+32*totalBudget n B+52<32*(quarterD n B).card)
    (hr:r∈quarterD n B) (hs:s∈quarterD n B) (hrs:r≠s)
    (hrsD:r+s∈quarterD n B) (hsmall:r+s≤n/16)
    (hS:S⊆lower n B) (hc:S.card=4)
    (hp:∀x∈S,∀y∈S,x≠y→x+y∈lower n B) :
    ∃u∈insert 0 S,∃v∈S,u<v ∧ n-v≤highThreshold n B ∧
      (∀x∈insert 0 S\{u,v},x%2≠u%2) := by
  have hpB:∀x∈S,∀y∈S,x≠y→x+y∈B := fun x hx y hy hxy=>(mem_inter.mp (hp x hx y hy hxy)).1
  have hSI:S⊆Icc 1 n := fun x hx=>(mem_inter.mp (hS hx)).2
  have hprofile:=full_clique_profile n B S hf hS hc hpB hbudget
  obtain ⟨u,hu,v,hv,huv,hul,hres,hother,hload⟩:=clique_shape n S hSI hc
    (fun x hx y hy hxy=>(mem_Icc.mp (mem_inter.mp (hp x hx y hy hxy)).2).2) hprofile
  have hvS:v∈S := (mem_insert.mp hv).resolve_left (by omega)
  have hhigh:=designated_high_vertex n u v r s B S hn hf hd hq hbudget hdense hS hc hpB
    hu hv hul hres hother hload hr hs hrs hrsD hsmall
  exact ⟨u,hu,v,hvS,huv,hhigh,hother⟩

#print axioms designated_high_vertex
#print axioms every_lower_clique_high
end OP02.SharpK5

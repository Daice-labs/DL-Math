import K8FixedFourPair
import K8FixedFourGap
import K8SupplyInterfaces
import K8Budget

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7
namespace OP02.SharpK8

/-- Construct the five vertices and their ten *prefix* sums from the two
odd gap roots, the real reflected pair and the fifth root. -/
theorem fixed_alternative_short {H a b u v z : ℕ} {D : Finset ℕ}
    (hH : 16777216≤H) (apos : 0<a) (ab : a<b) (bup : b≤H/256)
    (uo : u%2=1) (vo : v%2=1) (uv : u≠v)
    (us : u≤fifthCeil H+2) (vs : v≤fifthCeil H+2)
    (zl : H/4/2<z) (zu : z≤fifthCap H)
    (ma : 4*a∈D) (mb : 4*b∈D) (mu : u∈D) (mv : v∈D) (mz : z∈D)
    (abD : 4*a+4*b∈D) (au : u+4*a∈D) (bu : u+4*b∈D)
    (av : v+4*a∈D) (bv : v+4*b∈D) (uvD : u+v∈D)
    (za : z+4*a∈D) (zb : z+4*b∈D) (zuD : z+u∈D) (zvD : z+v∈D) :
    ∃ F : Finset ℕ, ShortFive H D F := by
  classical
  let F : Finset ℕ := {4*a,4*b,u,v,z}
  have sel {x} (hx : x∈F) : x=4*a ∨ x=4*b ∨ x=u ∨ x=v ∨ x=z := by
    simpa only [F,mem_insert,mem_singleton] using hx
  dsimp only [fifthCap,fifthCeil] at zu us vs
  have top (x : ℕ) (hx : x∈F) : 0<x ∧ x≤z ∧ (x=z ∨ x≤(111*H+1023)/1024+2) := by
    have := sel hx
    omega
  have mem (x : ℕ) (hx : x∈F) : x∈D := by
    rcases sel hx with rfl|rfl|rfl|rfl|rfl <;> assumption
  have edges (x : ℕ) (hx : x∈F) (y : ℕ) (hy : y∈F) (ne : x≠y) : x+y∈D := by
    rcases sel hx with rfl|rfl|rfl|rfl|rfl <;> rcases sel hy with rfl|rfl|rfl|rfl|rfl
    all_goals first | exact (ne rfl).elim | assumption | rw [Nat.add_comm]; assumption
  have count : F.card=5 := by
    simp [F,show 4*a≠4*b by omega,show 4*a≠u by omega,show 4*a≠v by omega,
      show 4*a≠z by omega,show 4*b≠u by omega,show 4*b≠v by omega,show 4*b≠z by omega,
      uv,show u≠z by omega,show v≠z by omega]
  refine ⟨F,⟨?_,count,?_⟩,?_⟩
  · intro x hx
    have t := top x hx
    exact mem_inter.mpr ⟨mem x hx,mem_Icc.mpr ⟨by omega,by omega⟩⟩
  · intro x hx y hy hxy
    have xt := top x hx;have yt := top y hy
    exact mem_inter.mpr ⟨edges x hx y hy hxy,mem_Icc.mpr ⟨by omega,by omega⟩⟩
  · intro x hx
    have xt := top x hx
    omega

/-- In either outcome, the four companions may now be taken from the actual
large-five case furnished by order five. -/
theorem signed_short_five_of_full_branch
    (full_failure : ∀ H : ℕ, 16777216≤H → ∀ D X Z : Finset ℕ,
      D⊆Icc 1 H → DoublingFree D → 1536*(chainCapacity H-D.card)<H →
      Z⊆Icc 1 (H/256) → (∀x∈Z,4*x∈D) →
      (∃ e∈Z, e%2=0 ∧ (unmatchedTop (H/4) D).card+(unmatchedTop (H/4/4) D).card <
        (reflectionPairs Z e).card) →
      Internal 4 (D∩Icc 1 (H/4)) X → (∀x∈X,128*x<5*H) →
      ∀ a b : ℕ, GapPair (insert 0 X) a b →
      (missingGap H D a b).card+(missingGap H D b a).card≤3*(chainCapacity H-D.card) →
      ∃F,ShortFive H D F)
    (h5 : Dousse5) {β : ℝ} (hb : 0<β) :
    ∃M : ℕ, ∀ n : ℕ, M≤n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
      ∃F, ShortFive (n/4) (quarterD n B) F := by
  classical
  obtain ⟨P,hP⟩ := signed_prefix_five h5 hb
  obtain ⟨C,hC⟩ := strict_capacity hb
  obtain ⟨R,hR⟩ := uniform_fixed_pair_supply hb
  refine ⟨max (4*16777216) (max P (max C R)),?_⟩
  intro n hn B hd hg
  let H := n/4
  let D := quarterD n B
  let Z := quarterD (H/64) D
  have hH : 16777216≤H := by dsimp only [H];omega
  have dsub : D⊆Icc 1 H := filter_subset _ _
  have ddf : DoublingFree D := quarter_doubling_free n B hd
  have bud := hC n (by omega) B hd hg
  have cap : 1536*(chainCapacity H-D.card)<H := by
    unfold chainDeficit at bud; change _ < n/4 at bud; dsimp only [H,D];omega
  obtain ⟨F,hF⟩ := hP n (by omega) B hd hg
  rcases split_prefix_five hF with ready|⟨w,_,_,companions,small⟩
  · exact ⟨F,ready⟩
  · let X := F.erase w
    change Internal 4 (D∩Icc 1 (H/4)) X at companions
    change ∀x∈X,128*x<5*H at small
    by_cases replacement : FixedReplacement H D X
    · exact short_five_of_fixed_replacement companions replacement
    have noMiss : ∀j<4,∃s∈insert 0 X,s%4=j := by
      by_contra! missing
      have hmissing : ∃j<4,∀x∈insert 0 X,x%4≠j := by
        obtain ⟨j,hj,abs⟩ := missing
        exact ⟨j,hj,abs⟩
      exact replacement (fixed_replacement_missing_residue (by omega) dsub ddf cap companions small hmissing)
    have cO : (insert 0 X).card=5 := by
      have none : 0∉X := by
        intro hx
        have := (mem_Icc.mp (mem_inter.mp (companions.1 hx)).2).1
        omega
      rw [card_insert_of_notMem none,companions.2.1]
    obtain ⟨a,b,hpair⟩ := gap_pair_of_full cO noMiss
    have smallO (x : ℕ) (hx : x∈insert 0 X) : 128*x<5*H := by
      rcases mem_insert.mp hx with h|h
      · omega
      · exact small x h
    have fault := fixed_gap_failures dsub ddf (by omega) smallO hpair replacement
    have zsub : Z⊆Icc 1 (H/256) := by
      rw [show H/256=H/64/4 by omega]
      exact filter_subset _ _
    obtain ⟨e,he,ee,_,pop⟩ := hR n (by omega) B hd hg
    change (unmatchedTop (H/4) D).card+(unmatchedTop (H/16) D).card < (reflectionPairs Z e).card at pop
    rw [show H/16=H/4/4 by omega] at pop
    exact full_failure H hH D X Z dsub ddf cap zsub (fun _ h=>(mem_filter.mp h).2)
      ⟨e,he,ee,pop⟩ companions small a b hpair fault

end OP02.SharpK8

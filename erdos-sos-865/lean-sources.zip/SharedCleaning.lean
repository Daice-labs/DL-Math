import SharedResources
open Finset
namespace OP02.SharpK4
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot OP02.BothEdges OP02.EdgeBand
set_option maxHeartbeats 2000000
noncomputable section

def zeroCommon (n : ℕ) (B : Finset ℕ) (x y : ℕ) :=
  (middleZero n B).filter (fun z=>x+z∈B ∧ y+z∈B)

theorem odd_subset_union_bound (n : ℕ) (B P : Finset ℕ) (hd : DoublingFree B)
    (hp : P⊆parityMiddle n B 1) (hn : NoEdge B P) :
    P.card ≤ 2*((middle n B).filter (fun x=>x%4=2)).card+
      2*(H0 n B).card+(H2 n B).card+((parityMiddle n B 1)\P).card+2 := by
  have h := actual_odd_subset_sharp n B P hd hp hn
  have h4 : (res8 (excessHoles n B) 4).card≤(H0 n B).card := by
    apply card_le_card
    intro x hx
    obtain ⟨he,hr⟩ := mem_filter.mp hx
    exact mem_filter.mpr ⟨he,by omega⟩
  have h26 : (H2 n B).card=(res8 (excessHoles n B) 2).card+(res8 (excessHoles n B) 6).card := by
    apply partition_card
    · intro x
      simp only [H2,res8,mem_filter]
      constructor
      · rintro ⟨he,hr⟩
        by_cases hh : x%8=2
        · exact Or.inl ⟨he,hh⟩
        · exact Or.inr ⟨he,by omega⟩
      · rintro (⟨he,hr⟩|⟨he,hr⟩) <;> exact ⟨he,by omega⟩
    · intro x hx hy
      have h1 := (mem_filter.mp hx).2
      have h2 := (mem_filter.mp hy).2
      omega
  omega

theorem zero_edge_odd_population (n : ℕ) (B : Finset ℕ)
    (hf : FourFree B) (hd : DoublingFree B) (he : ¬NoEdge B (middleZero n B)) :
    (parityMiddle n B 1).card ≤ 4*(Ho n B).card+
      2*((middle n B).filter (fun x=>x%4=2)).card+2*(H0 n B).card+(H2 n B).card+2 := by
  classical
  obtain ⟨x,hx,y,hy,hxy,hE⟩ : ∃x∈middleZero n B,∃y∈middleZero n B,x≠y ∧ x+y∈B := by
    simpa [NoEdge,not_forall] using he
  obtain ⟨P,hP,hn,hfP⟩ := edge_clean_subset (r:=1) (by omega) hf
    (mem_filter.mp hx).1 (mem_filter.mp hy).1
    (by have := (mem_filter.mp hx).2;omega)
    (by have := (mem_filter.mp hy).2;omega) hxy hE
  have ho := odd_subset_union_bound n B P hd hP hn
  have hc := card_sdiff_add_card_eq_card hP
  omega

theorem zero_common_noedge (n x y : ℕ) (B : Finset ℕ) (hf : FourFree B)
    (hx : x∈parityMiddle n B 1) (hy : y∈parityMiddle n B 1)
    (hxy : x≠y) (he : x+y∈B) : NoEdge B (zeroCommon n B x y) := by
  intro z hz w hw hzw hE
  obtain ⟨hz0,hxz,hyz⟩ := mem_filter.mp hz
  obtain ⟨hw0,hxw,hyw⟩ := mem_filter.mp hw
  have hzp := (mem_filter.mp hz0).2
  have hwp := (mem_filter.mp hw0).2
  have hxp := (mem_filter.mp hx).2
  have hyp := (mem_filter.mp hy).2
  exact four_forbidden B hf (mem_inter.mp (mem_filter.mp hx).1).1
    (mem_inter.mp (mem_filter.mp hy).1).1
    (mem_inter.mp (mem_filter.mp hz0).1).1 (mem_inter.mp (mem_filter.mp hw0).1).1
    hxy (by omega) (by omega) (by omega) (by omega) hzw he hxz hxw hyz hyw hE

theorem zero_fail_count (n x : ℕ) (B : Finset ℕ) (hx : x∈parityMiddle n B 1) :
    ((middleZero n B).filter (fun z=>x+z∉B)).card ≤ (res4 (Ho n B) (x%4)).card := by
  classical
  apply card_le_card_of_injOn (fun z=>x+z)
  · intro z hz
    change x+z∈res4 (Ho n B) (x%4)
    obtain ⟨hz0,hn⟩ := mem_filter.mp hz
    obtain ⟨hzM,hz4⟩ := mem_filter.mp hz0
    obtain ⟨hxM,hx2⟩ := mem_filter.mp hx
    have hxi := mem_Icc.mp (mem_inter.mp hxM).2
    have hzi := mem_Icc.mp (mem_inter.mp hzM).2
    refine mem_filter.mpr ⟨mem_filter.mpr ⟨?_,by omega⟩,by omega⟩
    rcases missing_split (n:=n) (by omega) hn with hm|he
    · obtain ⟨v,hv,heq⟩ := hm
      omega
    · exact he
  · intro z hz w hw heq
    dsimp only at heq
    omega

theorem zero_common_omitted (n x y : ℕ) (B : Finset ℕ)
    (hx : x∈parityMiddle n B 1) (hy : y∈parityMiddle n B 1) :
    ((middleZero n B)\zeroCommon n B x y).card ≤
      (res4 (Ho n B) (x%4)).card+(res4 (Ho n B) (y%4)).card := by
  classical
  have hs : (middleZero n B)\zeroCommon n B x y ⊆
      (middleZero n B).filter (fun z=>x+z∉B) ∪ (middleZero n B).filter (fun z=>y+z∉B) := by
    intro z hz
    obtain ⟨hz0,hznot⟩ := mem_sdiff.mp hz
    by_cases hh : x+z∈B
    · exact mem_union_right _ (mem_filter.mpr ⟨hz0,by intro hyz;exact hznot (mem_filter.mpr ⟨hz0,hh,hyz⟩)⟩)
    · exact mem_union_left _ (mem_filter.mpr ⟨hz0,hh⟩)
  have hc := (card_le_card hs).trans (card_union_le _ _)
  have hxC := zero_fail_count n x B hx
  have hyC := zero_fail_count n y B hy
  omega

theorem odd_edge_zero_population (n x y : ℕ) (B : Finset ℕ)
    (hf : FourFree B) (hd : DoublingFree B)
    (hx : x∈parityMiddle n B 1) (hy : y∈parityMiddle n B 1)
    (hxy : x≠y) (he : x+y∈B) :
    (middleZero n B).card ≤
      2*((res4 (Ho n B) (x%4)).card+(res4 (Ho n B) (y%4)).card)+
      ((middle n B).filter (fun x=>x%4=2)).card+(H0 n B).card+1 := by
  have hs : zeroCommon n B x y⊆middleZero n B := filter_subset _ _
  have hp := zero_subset_sum_bound n B (zeroCommon n B x y) hd hs
    (zero_common_noedge n x y B hf hx hy hxy he)
  have hc := card_sdiff_add_card_eq_card hs
  have hfC := zero_common_omitted n x y B hx hy
  omega

theorem odd_hole_partition (n : ℕ) (B : Finset ℕ) :
    (Ho n B).card=(res4 (Ho n B) 1).card+(res4 (Ho n B) 3).card := by
  apply partition_card
  · intro x
    simp only [res4,mem_filter]
    constructor
    · intro hx
      have hp := (mem_filter.mp hx).2
      by_cases hh : x%4=1
      · exact Or.inl ⟨hx,hh⟩
      · exact Or.inr ⟨hx,by omega⟩
    · rintro (⟨hx,_⟩|⟨hx,_⟩) <;> exact hx
  · intro x hx hy
    have h1 := (mem_filter.mp hx).2
    have h2 := (mem_filter.mp hy).2
    omega

def residueWeight (A C r : ℕ) := if r=1 then A else C

theorem large_pairs_same (A C r s t u : ℕ)
    (hr : r=1 ∨ r=3) (hs : s=1 ∨ s=3) (ht : t=1 ∨ t=3) (hu : u=1 ∨ u=3)
    (h1 : A+C < residueWeight A C r+residueWeight A C s)
    (h2 : A+C < residueWeight A C t+residueWeight A C u) :
    r=s ∧ t=r ∧ u=r := by
  rcases hr with rfl|rfl <;> rcases hs with rfl|rfl <;>
    rcases ht with rfl|rfl <;> rcases hu with rfl|rfl <;>
    norm_num [residueWeight] at * <;> omega

#print axioms odd_subset_union_bound
#print axioms zero_edge_odd_population
#print axioms zero_common_noedge
#print axioms zero_fail_count
#print axioms zero_common_omitted
#print axioms odd_edge_zero_population
#print axioms odd_hole_partition
#print axioms large_pairs_same
end
end OP02.SharpK4

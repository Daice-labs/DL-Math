import K7GapFirst
open Finset OP02.SmallExcess OP02.FewHole OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7

def absentWitness (u v s z:ℕ) : Prop := z=2*s-v ∨ z=2*s ∨ z=2*s-(v-u)
def middleClass (u v σ:ℕ) : Prop := σ<4 ∧ σ%2=1 ∧ (2*σ+8-(v-u)%8)%8=4

theorem middle_class_exists {u v:ℕ} (hu:u%2=1) (hv:v%2=1) (hp:(u+v)%4=0) (hl:u<v) :
    ∃σ,middleClass u v σ := by
  by_cases h:(v-u)%8=2
  · exact ⟨3,by unfold middleClass;omega⟩
  · exact ⟨1,by unfold middleClass;omega⟩

/-- Each absent middle odd label has a physical witness among three maps,
whose images are in different residue classes. -/
theorem absent_witness {β:ℝ} {n u v s σ:ℕ} {B:Finset ℕ} (hb:0<β)
    (hf:SevenFree B) (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hbn:(10:ℝ)≤β*n) (h4:rootFourBound β n)
    (hu:u∈B) (hv:v∈B) (huv:u<v) (hou:u%2=1) (hov:v%2=1)
    (hres:(u+v)%4=0) (he:u+v∈B) (huL:n<2*u) (hvH:v≤n-4*(n/16))
    (hσ:middleClass u v σ) (hs:s%4=σ) (hl:2*n+v<2*s) (hh:s≤2*n) (ha:s∉B) :
    ∃ z∈OP02.SharpK6.bootstrapResources n B, absentWitness u v s z := by
  have hσ':=hσ.2.2
  have hso:=hσ.2.1
  have ban:=no_upper_triangle (p:=2*s-v) hb hf hd hg hbn h4 hu hv huv hou hov hres he huL hvH
    (by omega) (by omega) (by omega)
  by_cases hp:2*s-v∈B
  · by_cases hc:2*s-(v-u)∈B
    · have ht:2*s∉B:=by
        intro ht;exact ban ⟨hp,by rwa [show 2*s-v+u=2*s-(v-u) by omega],
          by rwa [show 2*s-v+v=2*s by omega]⟩
      have h2:=OP02.SharpK6.bootstrap_missing_target n s 0 B (by omega) (by simpa using ha)
        (by omega) (by omega) (by simpa using ht)
      exact ⟨2*s,mem_union_left _ (mem_union_right _ (by simpa using h2)),Or.inr (Or.inl rfl)⟩
    · have hm:=OP02.SharpK6.bootstrap_missing_common n (2*s-(v-u)) B
        (by omega) (by omega) (by omega) hc
      exact ⟨2*s-(v-u),mem_union_left _ (mem_union_left _ hm),Or.inr (Or.inr rfl)⟩
  · exact ⟨2*s-v,mem_union_right _ (OP02.SharpK6.bootstrap_missing_odd n _ B
      (by omega) (by omega) (by omega) hp),Or.inl rfl⟩

theorem absent_witness_unique {u v σ s r z:ℕ} (hu:u%2=1) (hv:v%2=1) (huv:u<v)
    (hσ:middleClass u v σ) (hs:s%4=σ) (hr:r%4=σ) (hvs:v<2*s) (hvr:v<2*r)
    (hz:absentWitness u v s z) (hz':absentWitness u v r z) : s=r := by
  have h₀:=hσ.2.2;have h₁:=hσ.2.1
  rcases hz with hz|hz|hz <;> rcases hz' with hz'|hz'|hz' <;> omega

theorem physical_injection {X E:Finset ℕ} {R:ℕ→ℕ→Prop}
    (hf:∀x∈X,∃z∈E,R x z) (hi:∀x∈X,∀y∈X,∀z,R x z→R y z→x=y) : X.card≤E.card := by
  classical
  let f (x:ℕ) := if hx:x∈X then (hf x hx).choose else 0
  have hspec {x} (hx:x∈X) : f x ∈ E ∧ R x (f x) := by simpa only [f,dif_pos hx] using (hf x hx).choose_spec
  apply card_le_card_of_injOn f (fun x hx=>(hspec hx).1)
  intro x hx y hy hxy
  exact hi x hx y hy _ (hspec hx).2 (hxy ▸ (hspec hy).2)

theorem middle_upper_edge {n u v σ:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B) (hn:65536≤n) (hq:256*totalBudget n B≤n)
    (hu:u%2=1) (hv:v%2=1) (huv:u<v) (hvH:v≤n-4*(n/16)) (hσ:middleClass u v σ)
    (hw:∀s:ℕ,s%4=σ→2*n+v<2*s→s≤2*n→s∉B→
      ∃z∈OP02.SharpK6.bootstrapResources n B,absentWitness u v s z) :
    ∃p y:ℕ,2*n<p ∧ p≤2*n+4*totalBudget n B+4 ∧ p%4=(4-σ)%4 ∧ p∈B ∧
      p+n+v<2*y ∧ y+p≤4*n ∧ y%4=σ ∧ y∈B ∧ y+p∈B := by
  classical
  let q:=totalBudget n B
  let E:=OP02.SharpK6.bootstrapResources n B
  have hE:E.card≤q:=OP02.SharpK6.bootstrap_resource_budget n B hd
  have h₀:=hσ.1;have h₁:=hσ.2.1;have h₂:=hσ.2.2
  let P:=progression (2*n) (2*n+4*q+4) 4 ((4-σ)%4)
  have pdat {p:ℕ} (hp:p∈P) : 2*n<p ∧ p≤2*n+4*q+4 ∧ p%4=(4-σ)%4 := by
    obtain ⟨hi,hr⟩:=mem_filter.mp hp;exact ⟨(mem_Ioc.mp hi).1,(mem_Ioc.mp hi).2,hr⟩
  have plen:=progression_lower (2*n) (2*n+4*q+4) 4 ((4-σ)%4) (by decide) (by omega)
  change _≤P.card at plen
  have hpQ:256*q≤n:=hq
  have hex:∃p∈P,p∈B:=by
    by_contra! ha
    have hsub:P⊆E:=by
      intro p hp;have h:=pdat hp
      apply mem_union_right;apply OP02.SharpK6.bootstrap_missing_odd n _ B (by omega) (by omega) (by omega) (ha p hp)
    have hh:=card_le_card hsub;omega
  obtain ⟨p,hp,hpB⟩:=hex;have hdP:=pdat hp
  let Y:=progression ((p+n+v)/2) (4*n-p) 8 ((12-p%8)%8)
  have ydat {y:ℕ} (hy:y∈Y) : p+n+v<2*y ∧ y+p≤4*n ∧ y%4=σ ∧ (y+p)%8=4 ∧ y≤2*n := by
    obtain ⟨hi,hr⟩:=mem_filter.mp hy;have hI:=mem_Ioc.mp hi
    exact ⟨by omega,by omega,by omega,by omega,by omega⟩
  let F:=Y.filter (fun y=>y∉B)
  let G:=Y.filter (fun y=>y+p∉B)
  have hF:F.card≤q:=by
    apply le_trans _ hE
    apply physical_injection (R:=absentWitness u v)
    · intro y hy;obtain ⟨hy,ha⟩:=mem_filter.mp hy;have hy':=ydat hy
      exact hw y hy'.2.2.1 (by omega) hy'.2.2.2.2 ha
    · intro x hx y hy z hz hz'
      have hx':=ydat (mem_filter.mp hx).1;have hy':=ydat (mem_filter.mp hy).1
      exact absent_witness_unique hu hv huv hσ hx'.2.2.1 hy'.2.2.1 (by omega) (by omega) hz hz'
  have hG:G.card≤q:=by
    apply le_trans _ hE;apply card_le_card_of_injOn (fun y:ℕ=>y+p)
    · intro y hy;obtain ⟨hy,ha⟩:=mem_filter.mp hy;have hy':=ydat hy
      change y+p∈E
      exact mem_union_left _ (mem_union_left _ (OP02.SharpK6.bootstrap_missing_common
        n _ B hy'.2.2.2.1 (by omega) hy'.2.1 ha))
    · intro a ha b hb he;change a+p=b+p at he;omega
  have hlen:=progression_lower ((p+n+v)/2) (4*n-p) 8 ((12-p%8)%8) (by decide) (by omega)
  change _≤Y.card at hlen
  have hyex:∃y∈Y,y∈B ∧ y+p∈B:=by
    by_contra! ha
    have hsub:Y⊆F∪G:=by
      intro y hy;by_cases hh:y∈B
      · exact mem_union_right _ (mem_filter.mpr ⟨hy,ha y hy hh⟩)
      · exact mem_union_left _ (mem_filter.mpr ⟨hy,hh⟩)
    have hh:=card_le_card hsub;have hu:=card_union_le F G;omega
  obtain ⟨y,hy,hyB,hyp⟩:=hyex
  have hdy:=ydat hy
  exact ⟨p,y,hdP.1,hdP.2.1,hdP.2.2,hpB,hdy.1,hdy.2.1,hdy.2.2.1,hyB,hyp⟩
end OP02.SharpK7

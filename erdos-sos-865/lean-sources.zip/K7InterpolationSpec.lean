import Mathlib

namespace OP02.SharpK7

/-- The smaller endpoints in A specify the unordered pairs (a, e-a). -/
def CommonBaseSelection : Prop :=
  ∀ (I U F A : Finset ℤ) (e : ℤ), A.Nonempty →
    (∀ a ∈ A, 0 < a ∧ a < e - a) →
    ((I ∩ F).card : ℤ) +
        max (U.card : ℤ) (3 * (U.card : ℤ) - 2 * (A.card : ℤ) + 2) <
      (I.card : ℤ) →
    ∃ g ∈ I, g ∉ U ∧ g ∉ F ∧ ∃ a ∈ A, g + a ∉ U ∧ g + (e - a) ∉ U

end OP02.SharpK7


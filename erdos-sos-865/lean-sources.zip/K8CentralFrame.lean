import K8CentralCodes
import K8CentralCounting
import K8UpperSixComplement
import K8SupplyInterfaces
import K8Shell
import K8Selection

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8

def centralEarly (a c b x y : ℕ) : Finset ℕ :=
  insert y (insert x {4*a,4*c,4*b})

theorem central_five {H a c b x y : ℕ} {D : Finset ℕ} (large : 10^9≤H)
    (ac : a<c) (cb : c<b) (bhigh : b≤3*(H/256)+1)
    (ha : a∈quarterD (H/16) D) (hc : c∈quarterD (H/16) D) (hb : b∈quarterD (H/16) D)
    (hac : a+c∈quarterD (H/16) D) (hba : b+a∈quarterD (H/16) D)
    (hbc : b+c∈quarterD (H/16) D)
    (xlo : H/4/2<x) (xhi : x≤H/4-4*(3*(H/256)+1))
    (ylo : H/4/2<y) (yhi : y≤H/4-4*(3*(H/256)+1))
    (hxy : x≠y) (sum : x+y∈D)
    (passes : ∀f∈({0,a,c,b}:Finset ℕ), x+4*f∈D ∧ y+4*f∈D) :
    Internal 5 D (centralEarly a c b x y) ∧
    ∀u∈centralEarly a c b x y, 128*u+5*H≤128*(H/4) := by
  classical
  have ad := (mem_filter.mp ha).2
  have cd := (mem_filter.mp hc).2
  have bd := (mem_filter.mp hb).2
  have acd : 4*a+4*c∈D := by simpa only [Nat.mul_add] using (mem_filter.mp hac).2
  have bad : 4*b+4*a∈D := by simpa only [Nat.mul_add] using (mem_filter.mp hba).2
  have bcd : 4*b+4*c∈D := by simpa only [Nat.mul_add] using (mem_filter.mp hbc).2
  let G : Finset ℕ := {4*a,4*c,4*b}
  have tri : Internal 3 D G := by
    refine ⟨?_,?_,?_⟩
    · intro u hu
      simp only [G,mem_insert,mem_singleton] at hu
      rcases hu with rfl|rfl|rfl <;> assumption
    · simp [G,show 4*a≠4*c by omega,show 4*a≠4*b by omega,show 4*c≠4*b by omega]
    · intro u hu v hv ne
      simp only [G,mem_insert,mem_singleton] at hu hv
      rcases hu with rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl <;>
        first | contradiction | assumption | simpa only [Nat.add_comm] using acd |
          simpa only [Nat.add_comm] using bad | simpa only [Nat.add_comm] using bcd
  have small (u : ℕ) (hu : u∈G) : u≤4*(3*(H/256)+1) := by
    simp only [G,mem_insert,mem_singleton] at hu
    rcases hu with h|h|h <;> omega
  have edge (u : ℕ) (hu : u∈G) : x+u∈D ∧ y+u∈D := by
    simp only [G,mem_insert,mem_singleton] at hu
    rcases hu with rfl|rfl|rfl
    · exact passes a (by simp)
    · exact passes c (by simp)
    · exact passes b (by simp)
  have verts : x∈D ∧ y∈D := by simpa using passes 0 (by simp)
  have xf : x∉G := fun h => by have := small x h;omega
  have yf : y∉insert x G := by
    intro h;rcases mem_insert.mp h with eq|h
    · omega
    · have := small y h;omega
  have fourth := internal_insert tri verts.1 xf (fun u hu=>(edge u hu).1)
  refine ⟨internal_insert fourth verts.2 yf ?_,?_⟩
  · intro u hu
    rcases mem_insert.mp hu with rfl|h
    · simpa only [Nat.add_comm] using sum
    · exact (edge u h).2
  · intro u hu
    change u∈insert y (insert x G) at hu
    rcases mem_insert.mp hu with rfl|h
    · omega
    rcases mem_insert.mp h with rfl|h
    · omega
    · have := small u h;omega

theorem in_top_holes {H v : ℕ} {D : Finset ℕ} (lo : H<2*v) (hi : v≤H)
    (can : canonical v=true) (absent : v∉D) : v∈topMissing H D :=
  mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hi⟩,can⟩,lo,absent⟩

theorem early_upper_common {H a c b x y : ℕ} {D : Finset ℕ}
    (hF : Internal 5 D (centralEarly a c b x y))
    (hsmall : ∀u∈centralEarly a c b x y, 128*u+5*H≤128*(H/4))
    {P : Finset ℕ} (geo : ∀R∈P,H<2*R ∧ 4*R≤3*H ∧
      ∀f∈insert 0 (centralEarly a c b x y), canonical (R+f)=true)
    (room : 6*(topMissing H D).card<P.card) : RootSix H D := by
  classical
  let F := centralEarly a c b x y
  have small (f : ℕ) (hf : f∈insert 0 F) : f≤H/4 := by
    rcases mem_insert.mp hf with eq|h
    · omega
    · have := hsmall f h;omega
  have card : (insert 0 F).card≤6 := (card_insert_le _ _).trans (by change F.card+1≤_;have := hF.2.1;change F.card=5 at this;omega)
  have fault (R : ℕ) (hR : R∈P) (f : ℕ) (hf : f∈insert 0 F) (absent : R+f∉D) :
      R+f∈topMissing H D := by
    obtain ⟨rl,rh,can⟩ := geo R hR
    have fs := small _ hf
    exact in_top_holes (by omega) (by omega) (can f hf) absent
  have bound := Nat.mul_le_mul_right (topMissing H D).card card
  obtain ⟨R,hR,pass⟩ := plain_selection fault (Nat.lt_of_le_of_lt bound room)
  exact common_upper_root_six hF hsmall (geo R hR).1 (geo R hR).2.1 pass

end OP02.SharpK8

import AllKPhysical
import AllKSpec
import K9OuterTrials

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK8
namespace OP02.AllOrders

private theorem small_le_quarter {k H x : ℕ} (h : 256*x≤alpha256 k*H) :
    4*x≤H := by
  have a : alpha256 k≤64 := by unfold alpha256; split_ifs <;> decide
  have b := Nat.mul_le_mul_right H a
  omega

private theorem sparse_direct {p a : ℕ} {F : Finset ℕ} (prev : Sparse F) (ha : a<4)
    (ctrl : (residueCell (insert 0 F) 4 ((a+2)%4)).card≤3)
    (phase : p%4=(6-a)%4) : Sparse (insert p F) := by
  classical
  by_cases even : p%2=0
  · obtain ⟨c,odd,bound⟩ := prev
    refine ⟨c,odd,le_trans (card_le_card ?_) bound⟩
    intro x hx
    obtain ⟨ins,eq⟩ := mem_filter.mp hx
    rcases mem_insert.mp ins with rfl|h
    · rcases odd with h|h <;> omega
    · exact mem_filter.mpr ⟨h,eq⟩
  · let c := (a+2)%4
    have codd : c=1 ∨ c=3 := by dsimp [c]; omega
    have ne : p%4≠c := by dsimp [c]; omega
    refine ⟨c,codd,le_trans (card_le_card ?_) ctrl⟩
    intro x hx
    obtain ⟨ins,eq⟩ := mem_filter.mp hx
    rcases mem_insert.mp ins with rfl|h
    · exact False.elim (ne eq)
    · exact mem_filter.mpr ⟨mem_insert_of_mem h,eq⟩

theorem direct_shape {k H p a : ℕ} {A F : Finset ℕ}
    (hk : 1≤k) (seed : Internal (k-1) A F) (prev : Sparse F)
    (ha : a<4) (ctrl : (residueCell (insert 0 F) 4 ((a+2)%4)).card≤3)
    (phase : p%4=(6-a)%4) (lo : H<2*p) (hi : 256*p≤gamma256 k*H)
    (small : ∀x∈F,256*x≤alpha256 k*H) (pass : ∀u∈insert 0 F,p+u∈A) :
    ShapeAt k H A (insert p F) p := by
  have fresh : p∉F := fun h=>by have := small_le_quarter (small p h); omega
  have add := internal_insert seed (by simpa using pass 0 (mem_insert_self 0 F))
    fresh (fun y hy=>pass y (mem_insert_of_mem hy))
  rw [show k-1+1=k by omega] at add
  exact ⟨add,mem_insert_self _ _,lo,hi,
    fun x hx ne=>small x ((mem_insert.mp hx).resolve_left ne), sparse_direct prev ha ctrl phase⟩

/-- For an actual failed target u on the already selected progression, the
admitted half supplies precisely the edge with z in the new clique. -/
theorem replacement_seed {k p u z : ℕ} {A W : Finset ℕ}
    (hk : 2≤k) (seed : Internal (k-2) A W) (even : ∀w∈W,w%2=0)
    (half : (p+u)/2∈A) (zm : z≤(p+u)/2) (odd : ((p+u)/2-z)%2=1)
    (lower : ∀w∈insert 0 (W.erase z),(p+u)/2-z+w∈A) :
    Internal (k-1) A (insert ((p+u)/2-z) W) := by
  let v := (p+u)/2-z
  have actual : v∈A := by simpa only [Nat.add_zero] using lower 0 (mem_insert_self _ _)
  have fresh : v∉W := fun h=>by have := even v h; dsimp [v] at *; omega
  have edges (w) (hw : w∈W) : v+w∈A := by
    by_cases wz : w=z
    · have eq : v+w=(p+u)/2 := by dsimp only [v]; omega
      exact eq.symm ▸ half
    · exact lower w (mem_insert_of_mem (mem_erase.mpr ⟨wz,hw⟩))
  have add := internal_insert seed actual fresh edges
  rwa [show k-2+1=k-1 by omega] at add

/-- Choose a new upper vertex for the fixed reflected clique using the
complete deficit inventory of the original A. -/
theorem replacement_finish {k H v : ℕ} {A W : Finset ℕ}
    (hk : 1≤k) (sub : A⊆Icc 1 H) (df : DoublingFree A)
    (seed : Internal (k-1) A (insert v W)) (even : ∀w∈W,w%2=0) (odd : v%2=1)
    (small : ∀w∈insert v W,256*w≤alpha256 k*H)
    (room : k*(chainCapacity H-A.card)<(9*H/16-H/2)/8) :
    ∃F P,ShapeAt k H A F P := by
  classical
  let O := insert 0 (insert v W)
  let r := (12-v%8)%8
  let P := progression (H/2) (9*H/16) 8 r
  have nO : O.card≤k := by
    have n := card_insert_le 0 (insert v W)
    rw [seed.2.1] at n
    change (insert 0 (insert v W)).card≤k
    omega
  have supply := progression_lower (H/2) (9*H/16) 8 r (by decide) (Nat.mod_lt _ (by decide))
  change (9*H/16-H/2)/8≤P.card at supply
  let E := deficientChains H A
  have eBound : E.card≤chainCapacity H-A.card := deficient_card sub df
  have size : O.card*E.card<P.card := (Nat.mul_le_mul nO eBound).trans_lt (room.trans_le supply)
  have bnd (p) (hp : p∈P) : H/2<p ∧ p≤9*H/16 ∧ p%8=(12-v%8)%8 :=
    ⟨(mem_Ioc.mp (mem_filter.mp hp).1).1,(mem_Ioc.mp (mem_filter.mp hp).1).2,(mem_filter.mp hp).2⟩
  obtain ⟨p,hp,pass⟩ := plain_selection (P:=P) (F:=O) (D:=A) (E:=E) (by
    intro p hp s hs absent
    obtain ⟨lo,hi,pr⟩ := bnd p hp
    have ub : 4*s≤H := by
      rcases mem_insert.mp hs with rfl|hs
      · omega
      · exact small_le_quarter (small s hs)
    have can : canonical (p+s)=true := by
      rcases mem_insert.mp hs with e|hs
      · exact canonical_odd _ (by omega)
      · rcases mem_insert.mp hs with e|sw
        · exact canonical_four_residue _ (by omega)
        · have := even s sw; exact canonical_odd _ (by omega)
    exact missing_top sub (by omega) (by omega) can absent) size
  obtain ⟨lo,hi,pr⟩ := bnd p hp
  have fresh : p∉insert v W := fun h=>by have := small_le_quarter (small p h); omega
  have clique := internal_insert seed (by simpa using pass 0 (mem_insert_self 0 _))
    fresh (fun w hw=>pass w (mem_insert_of_mem hw))
  rw [show k-1+1=k by omega] at clique
  have γ : 144≤gamma256 k := by unfold gamma256; split_ifs <;> decide
  have γH := Nat.mul_le_mul_right H γ
  refine ⟨_,p,clique,mem_insert_self _ _,by omega,by omega,
    (fun x hx hn=>small x ((mem_insert.mp hx).resolve_left hn)),1,Or.inl rfl,?_⟩
  have incl : ((insert p (insert v W)).filter (fun x => x%4=1))⊆{p,v} := by
    intro x hx
    obtain ⟨ins,res⟩ := mem_filter.mp hx
    rcases mem_insert.mp ins with rfl|h
    · exact mem_insert_self _ _
    rcases mem_insert.mp h with rfl|h
    · exact mem_insert_of_mem (mem_singleton_self _)
    · have := even x h; omega
  have smallPair := card_insert_le p ({v} : Finset ℕ)
  simp only [card_singleton] at smallPair
  exact (card_le_card incl).trans (by omega)

theorem replacement_shape {k H p u z : ℕ} {A W : Finset ℕ}
    (hk : 2≤k) (sub : A⊆Icc 1 H) (df : DoublingFree A)
    (seed : Internal (k-2) A W) (even : ∀w∈W,w%2=0)
    (half : (p+u)/2∈A) (zm : z≤(p+u)/2) (odd : ((p+u)/2-z)%2=1)
    (lower : ∀w∈insert 0 (W.erase z),(p+u)/2-z+w∈A)
    (smallW : ∀w∈W,256*w≤alpha256 k*H) (smallV : 256*((p+u)/2-z)≤alpha256 k*H)
    (room : k*(chainCapacity H-A.card)<(9*H/16-H/2)/8) :
    ∃F P,ShapeAt k H A F P := by
  apply replacement_finish (by omega) sub df
    (replacement_seed hk seed even half zm odd lower) even odd _ room
  intro w hw
  rcases mem_insert.mp hw with rfl|hw
  · exact smallV
  · exact smallW w hw

end OP02.AllOrders

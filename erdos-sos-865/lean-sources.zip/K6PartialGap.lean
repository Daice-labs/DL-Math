import K6FirstStage
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 4000000

/-- The open middle gap follows from the actual odd-slot inventory. All
representations use opposite odd residues and share one injective hole charge. -/
theorem partial_middle_gap (β:ℝ) (n:ℕ) (B:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hgap6:PositiveGap6 β n B)
    (hn:65536≤n) (hbn:(10:ℝ)≤β*n)
    (hcap:384*(chainDeficit n B+totalBudget n B)≤n)
    (hbudget:3*(canonicalHoles n B).card<n/128) :
    ∀m∈middle n B,m%8=4 →
      ¬(n+4*(missingTopOdd n B).card+4< m ∧
        m<2*(n-4*(n/16))-(4*(missingTopOdd n B).card+4)) := by
  classical
  intro m hm hm4 hgap
  let h:=(missingTopOdd n B).card
  let W:=n-4*(n/16)
  let L:=max (n/2) (m-W-1)
  let U:=min W (m-n/2-1)
  let Y:=progression L U 4 1
  have hmB := (mem_inter.mp hm).1
  have hmI := mem_Icc.mp (mem_inter.mp hm).2
  have hlen:4*(h+1)≤U-L := by dsimp [U,L,W,h]; omega
  have hY (u:ℕ) (hu:u∈Y) : n<2*u ∧ u≤W ∧ n<2*(m-u) ∧ m-u≤W ∧ u< m ∧ u%4=1 ∧ (m-u)%4=3 := by
    obtain ⟨huI,hur⟩ := mem_filter.mp hu
    have huI := mem_Ioc.mp huI
    dsimp only [L,U] at huI
    dsimp only [W] at *
    omega
  let f:=fun u=>if u∉B then u else m-u
  have hc:Y.card≤h := by
    apply card_le_card_of_injOn f
    · intro u hu
      have huI := hY u hu
      have hbad:¬(u∈B ∧ m-u∈B) := by
        rintro ⟨huB,hvB⟩
        have hun:u≤n := by dsimp [W] at huI; omega
        have hvn:m-u≤n := by dsimp [W] at huI; omega
        have huL:u∈lower n B:=mem_inter.mpr ⟨huB,mem_Icc.mpr ⟨by omega,hun⟩⟩
        have hvL:m-u∈lower n B:=mem_inter.mpr ⟨hvB,mem_Icc.mpr ⟨by omega,hvn⟩⟩
        have he:u+(m-u)=m := by omega
        by_cases huv:u < m-u
        · have hno:=no_high_sum_four β n u (m-u) B hf hd hgap6 hn hbn hcap hbudget
            huL hvL huv (by omega) (by omega) huI.1 huI.2.2.1 huI.2.1 huI.2.2.2.1 (by omega)
          exact hno (he.symm ▸ hmB)
        · have hno:=no_high_sum_four β n (m-u) u B hf hd hgap6 hn hbn hcap hbudget
            hvL huL (by omega) (by omega) (by omega) huI.2.2.1 huI.1 huI.2.2.2.1 huI.2.1 (by omega)
          apply hno
          simpa only [Nat.add_comm] using (he.symm ▸ hmB)
      by_cases he:u∉B
      · simp only [f,if_pos he]
        refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,by omega⟩,by omega,he⟩
        dsimp [W] at huI; omega
      · simp only [f,if_neg he]
        have hh:m-u∉B := by tauto
        refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,by omega⟩,by omega,hh⟩
        dsimp [W] at huI; omega
    · intro u hu v hv he
      have huI := hY u hu
      have hvI := hY v hv
      dsimp only [f] at he
      split_ifs at he <;> omega
  have hl := progression_lower L U 4 1 (by omega) (by omega)
  change (U-L)/4≤Y.card at hl
  omega

#print axioms partial_middle_gap
end OP02.SharpK6

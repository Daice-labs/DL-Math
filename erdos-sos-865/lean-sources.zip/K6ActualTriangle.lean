import K6RootAdmission
import K6GapReduction
open Finset Erdos865
namespace OP02.SharpK6
open OP02.FewHole OP02.SmallExcess OP02.SharpK5
set_option maxHeartbeats 2000000

/-- The root prefix is filtered from the same actual B. -/
def actualRootPrefix (n:ℕ) (B:Finset ℕ) := (quarterD n B).filter (fun x=>x≤n/16)

/-- Paper (13), retaining the exact physical budget and one floor error. -/
theorem actual_prefix_density (β:ℝ) (n:ℕ) (B:Finset ℕ)
    (hd:DoublingFree B) (hgap:PositiveGap6 β n B) :
    (5:ℝ)*(n/16:ℕ)+8*totalBudget n B+8*(β*n)≤8*(actualRootPrefix n B).card+16 := by
  have hc:=quarter_root_capacity (n/4) (n/16) (quarterD n B) (by omega)
    (filter_subset _ _) (quarter_doubling_free n B hd)
  have hcr : ((quarterD n B).card:ℝ)+2*(n/16:ℕ)≤(n/4:ℕ)+(actualRootPrefix n B).card := by exact_mod_cast hc
  have hfloor : 128*(n/4)≤21*n+176*(n/16)+256 := by omega
  have hfr : (128:ℝ)*(n/4:ℕ)≤21*n+176*(n/16:ℕ)+256 := by exact_mod_cast hfloor
  unfold PositiveGap6 at hgap
  linarith

/-- Complete source-bound early triangle admission. Its capacity and cutoff
conditions are derived uniformly from actual doubling-freeness and target violation. -/
theorem actual_early_triangle (β:ℝ) (hβ:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,DoublingFree B→PositiveGap6 β n B→
    ∃U:ℕ,EarlyTriangle (actualRootPrefix n B) U ∧
      (16:ℝ)*U+16*totalBudget n B+16*(β*n)≤11*(n/16:ℕ)+192 := by
  obtain ⟨K₀,hK₀⟩:=capacity_uniform_error (1/12) (by norm_num)
  obtain ⟨N,hN⟩:=exists_nat_gt (20/β)
  refine ⟨max (16*(max 128 K₀)) N,?_⟩
  intro n hn B hd hgap
  let X := actualRootPrefix n B
  have hs : X⊆Icc 1 (n/16) := by
    intro x hx
    obtain ⟨hxD,hxK⟩:=mem_filter.mp hx
    have hi:=mem_Icc.mp (mem_filter.mp hxD).1
    exact mem_Icc.mpr ⟨hi.1,hxK⟩
  have hdX : DoublingFree X := by
    intro x hx hx2
    exact quarter_doubling_free n B hd x (mem_filter.mp hx).1 (mem_filter.mp hx2).1
  have hc:=chain_capacity_with_top_loss (n/16) X hs hdX
  have hu:=hK₀ (n/16) (by omega)
  have hcr : (X.card:ℝ)≤chainCapacity (n/16) := by exact_mod_cast (show X.card≤chainCapacity (n/16) by omega)
  have hcap : 4*X.card≤3*(n/16) := by
    have hr : (4:ℝ)*X.card≤3*(n/16:ℕ) := by linarith
    exact_mod_cast hr
  have hg : (20:ℝ)≤β*n := by
    have hNr : (N:ℝ)≤n := by exact_mod_cast (show N≤n by omega)
    have hh:20/β<(n:ℝ):=lt_of_lt_of_le hN hNr
    have := (div_lt_iff₀ hβ).mp hh
    nlinarith
  exact root_early_cutoff_real (n/16) (totalBudget n B) (β*n) X (by omega) hg hs hcap
    (actual_prefix_density β n B hd hgap)

#print axioms actual_prefix_density
#print axioms actual_early_triangle
end OP02.SharpK6

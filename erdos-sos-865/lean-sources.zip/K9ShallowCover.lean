import K9Spec

open Finset OP02.SharpK8
namespace OP02.SharpK9

/-- A four using all four residue cells after adjoining zero has two singleton
cells of one parity. The smaller actual offset of that parity is at most l/2. -/
theorem quartet_roles {l : ℕ} {T G : Finset ℕ} (seed : Internal 4 (G ∩ Icc 1 l) T)
    (full : ∀j<4, ∃x∈insert 0 T, x%4=j) :
    ∃ u∈insert 0 T, ∃ c∈insert 0 T, 2*u≤l ∧ u%2=c%2 ∧ u%4≠c%4 ∧
      (∀s∈insert 0 T, s%4=u%4 → s=u) ∧
      (∀s∈insert 0 T, s%4=c%4 → s=c) ∧
      ∀j<4, ((insert 0 T).filter (fun s=>s%4=j)).card≤2 := by
  classical
  let U := insert 0 T
  let C := fun r : ℕ => U.filter (fun x => x%4=r)
  have zero : 0∉T := by intro hz;have := (mem_Icc.mp (mem_inter.mp (seed.1 hz)).2).1;omega
  have nU : U.card=5 := by simp [U,zero,seed.2.1]
  have pos (i : ℕ) (hi : i<4) : 0<(C i).card := by
    obtain ⟨a,ha,hi'⟩ := full i hi
    exact card_pos.mpr ⟨a,mem_filter.mpr ⟨ha,hi'⟩⟩
  have count := card_eq_sum_card_fiberwise (s:=U) (t:=range 4) (f:=fun x : ℕ => x%4)
    (fun x _ => mem_range.mpr (show x%4<4 by omega))
  simp only [sum_range_succ,sum_range_zero,zero_add] at count
  change U.card=(C 0).card+(C 1).card+(C 2).card+(C 3).card at count
  have p0 := pos 0 (by decide)
  have p1 := pos 1 (by decide)
  have p2 := pos 2 (by decide)
  have p3 := pos 3 (by decide)
  have bound (j) (hj : j<4) : (C j).card≤2 := by interval_cases j <;> omega
  have cells : ∃ k<2,(C k).card=1 ∧ (C (k+2)).card=1 := by
    by_cases h0 : (C 0).card=1 ∧ (C 2).card=1
    · exact ⟨0,by decide,h0⟩
    · exact ⟨1,by decide,by omega,by simpa using (show (C 3).card=1 by omega)⟩
  obtain ⟨k,hk,one,two⟩ := cells
  obtain ⟨a,ha,ua⟩ := card_eq_one_iff_existsUnique.mp one
  obtain ⟨b,hb,ub⟩ := card_eq_one_iff_existsUnique.mp two
  obtain ⟨aU,ar⟩ := mem_filter.mp ha
  obtain ⟨bU,br⟩ := mem_filter.mp hb
  have ab : a≠b := by omega
  have sa (x) (hx : x∈U) (he : x%4=a%4) : x=a := ua _ (mem_filter.mpr ⟨hx,he.trans ar⟩)
  have sb (x) (hx : x∈U) (he : x%4=b%4) : x=b := ub _ (mem_filter.mpr ⟨hx,he.trans br⟩)
  have low : 2*a≤l ∨ 2*b≤l := by
    rcases mem_insert.mp aU with rfl|haT
    · exact Or.inl (by omega)
    rcases mem_insert.mp bU with rfl|hbT
    · exact Or.inr (by omega)
    have := (mem_Icc.mp (mem_inter.mp (seed.2.2 a haT b hbT ab)).2).2
    omega
  rcases low with la|lb
  · exact ⟨a,aU,b,bU,la,by omega,by omega,sa,sb,bound⟩
  · exact ⟨b,bU,a,aU,lb,by omega,by omega,sb,sa,bound⟩

/-- Simultaneous selection against one set of physical chain terminals.
A terminal of residue four modulo eight has just one upper role; other
terminals have at most two upper roles and cannot be a lower quadruple. -/
theorem shared_shallow_selection {X U W A : Finset ℕ} {c r : ℕ} {v : ℕ → ℕ}
    (phase : ∀p∈X, p%4=r) (load : ∀j<4,(U.filter (fun s=>s%4=j)).card≤2)
    (control : ∀p∈X,∀s∈U,(p+s)%8=4 → s=c)
    (wc : W.card≤3) (lowerPhase : ∀p∈X,∀w∈W,(4*(v p+w))%8=4)
    (vinj : Set.InjOn v (X:Set ℕ)) (room : 4*A.card<X.card) :
    ∃p∈X, (∀s∈U,p+s∉A) ∧ ∀w∈W,4*(v p+w)∉A := by
  classical
  let top := fun e : ℕ => X.filter (fun p => ∃s∈U,p+s=e)
  let low := fun e : ℕ => X.filter (fun p => ∃w∈W,4*(v p+w)=e)
  have top_two (e : ℕ) : (top e).card≤2 := by
    rcases (top e).eq_empty_or_nonempty with empty|⟨p,hp⟩
    · simp [empty]
    obtain ⟨hpX,s,hs,eqs⟩ := mem_filter.mp hp
    have pr := phase p hpX
    apply le_trans _ (load (s%4) (by omega))
    apply card_le_card_of_injOn (fun a=>e-a)
    · intro a ha
      obtain ⟨aX,t,tU,at'⟩ := mem_filter.mp ha
      have va : e-a=t := by omega
      have ha' := phase a aX
      change e-a∈U.filter (fun x => x%4=s%4)
      rw [va]
      exact mem_filter.mpr ⟨tU,by omega⟩
    · intro a ha b hb he
      obtain ⟨_,t,_,ht⟩ := mem_filter.mp ha
      obtain ⟨_,w,_,hw⟩ := mem_filter.mp hb
      change e-a=e-b at he
      omega
  have one (e) (mod : e%8=4) : (top e).card≤1 := by
    apply card_le_one.mpr
    intro p hp q hq
    obtain ⟨pX,s,sU,ps⟩ := mem_filter.mp hp
    obtain ⟨qX,t,tU,qt⟩ := mem_filter.mp hq
    have := control p pX s sU (ps ▸ mod)
    have := control q qX t tU (qt ▸ mod)
    omega
  have low_bound (e : ℕ) : (low e).card≤W.card := by
    have sub : low e ⊆ rejected X W {e} (fun w p => 4*(v p+w)) := by
      intro p hp
      obtain ⟨pX,w,wW,eq⟩ := mem_filter.mp hp
      exact mem_rejected.mpr ⟨w,wW,pX,mem_singleton.mpr eq⟩
    have cnt := rejected_card X W {e} (fun w p => 4*(v p+w)) (by
      intro w hw a ha b hb he
      apply vinj ha hb
      change 4*(v a+w)=4*(v b+w) at he
      omega)
    simpa using (card_le_card sub).trans cnt
  have jointly (e : ℕ) : (top e ∪ low e).card≤4 := by
    by_cases m : e%8=4
    · have := one e m;have := low_bound e;have := card_union_le (top e) (low e);omega
    · have emp : low e=∅ := eq_empty_iff_forall_notMem.mpr (by
        intro p h
        obtain ⟨pX,w,wW,eq⟩ := mem_filter.mp h
        exact m (eq ▸ lowerPhase p pX w wW))
      rw [emp,union_empty]
      exact (top_two e).trans (by decide)
  let bad := A.biUnion (fun e => top e ∪ low e)
  have bound : bad.card≤4*A.card := by
    have t := (card_biUnion_le (s:=A) (t:=fun e => top e ∪ low e)).trans
      (sum_le_sum (fun e (_ : e∈A) => jointly e))
    change (A.biUnion (fun e => top e ∪ low e)).card ≤ 4*A.card
    simp only [sum_const,nsmul_eq_mul] at t
    simpa [mul_comm] using t
  obtain ⟨p,hp,hgood⟩ := exists_mem_notMem_of_card_lt_card (bound.trans_lt room)
  refine ⟨p,hp,?_,?_⟩
  · intro s hs he
    exact hgood (mem_biUnion.mpr ⟨_,he,mem_union_left _ (mem_filter.mpr ⟨hp,s,hs,rfl⟩)⟩)
  · intro w hw he
    exact hgood (mem_biUnion.mpr ⟨_,he,mem_union_right _ (mem_filter.mpr ⟨hp,w,hw,rfl⟩)⟩)

end OP02.SharpK9

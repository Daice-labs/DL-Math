import K7OpenWindows

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit

namespace OP02.SharpK7.LongOddTask

/-- A physical even reflection pair at the actual largest even member of S.
    Other reflection pairs may be odd. -/
def ActiveEvenSupply (n : ℕ) (B : Finset ℕ) : Prop :=
  ∃ e ∈ smallSupport n B, e % 2 = 0 ∧
    (∀ x ∈ smallSupport n B, x % 2 = 0 → x ≤ e) ∧
    ∃ a ∈ reflectionPairs (smallSupport n B) e, a % 2 = 0

/-- One threshold per β, before B, the seed and the choice of largest odd.
    t is the largest companion; the largest vertex of the seed is 2*l. -/
def LargeOddCases (conclusion : ℕ → Finset ℕ → ℕ → Prop) : Prop :=
  ∀ β : ℝ, 0 < β → ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n →
    ∀ B : Finset ℕ, B ⊆ Icc 1 (4*n) → SevenFree B → DoublingFree B →
    (85/512 + β) * (n : ℝ) ≤ ((quarterD n B).card : ℝ) - (totalBudget n B : ℝ) →
    ∀ t t' h k l : ℕ, t % 2 = 1 → t' % 2 = 1 → t % 4 ≠ t' % 4 → 0 < h →
      k % 2 = 1 → l % 2 = 1 → k < l → 2*(n/4) < 3*(2*l) →
      InternalFive (B ∩ Icc 1 (n/4)) (insert (2*l) {t, t', 4*h, 2*k}) →
      (∀ x ∈ ({t, t', 4*h, 2*k} : Finset ℕ), x ≤ t) →
      17*(n/4/64) < t → ActiveEvenSupply n B → conclusion n B t

def deviation (n t : ℕ) : ℤ :=
  abs ((t : ℤ) - 20 * ((n / 4 / 64 : ℕ) : ℤ))

def lowerHoles (n : ℕ) (B : Finset ℕ) : Finset ℕ :=
  (Ioc (n/4/8) (n/4/4)).filter (fun r => r % 2 = 1 ∧ r ∉ B)

/-- Physical lower roots and the simultaneous budget estimate of (7).
    The second inequality clears the denominator 8 before casting. -/
def ChargeEvidence (n : ℕ) (B : Finset ℕ) (t : ℕ) : Prop :=
  ∃ Z : Finset ℕ, Z ⊆ lowerHoles n B ∧
    Z.card + T_loss n B ≤ lambdaBudget n B ∧
    4 * ((n / 4 / 64 : ℕ) : ℤ) ≤
      24 * (Z.card : ℤ) + 24 * ((midOddLoss n B).card : ℤ) + deviation n t + 32

def LossBound (n : ℕ) (B : Finset ℕ) (t : ℕ) : Prop :=
  24 * (T_loss n B : ℤ) ≤ deviation n t + 48

def PhysicalStatement : Prop := LargeOddCases ChargeEvidence
def LossStatement : Prop := LargeOddCases LossBound
def WindowStatement : Prop := LargeOddCases (fun _ _ _ => False)

end OP02.SharpK7.LongOddTask

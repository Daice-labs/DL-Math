import PositiveOdd
open Finset
namespace OP02.SharpK4
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot
set_option maxRecDepth 4000
set_option maxHeartbeats 2000000
-- Source-bound strengthening of retained PositiveOdd, with original files unchanged.
/-- The finite residue calculation includes empty and singleton residue classes. -/
theorem four_residue_algebra_sharp (A B C D X Y Z:ℕ)
    (hAB:A=0 ∨ B=0 ∨ A+B≤X+1) (hCD:C=0 ∨ D=0 ∨ C+D≤X+1)
    (hAC:A=0 ∨ C=0 ∨ A+C≤B+D+Z+1)
    (hBD:B=0 ∨ D=0 ∨ B+D≤A+C+Y+1)
    (hA:A=0 ∨ 2*A≤A+C+Y+1) (hC:C=0 ∨ 2*C≤A+C+Y+1)
    (hB:B=0 ∨ 2*B≤B+D+Z+1) (hD:D=0 ∨ 2*D≤B+D+Z+1) :
    A+B+C+D≤2*X+Y+Z+2 := by
  omega

/-- Positive-excess odd-side bound, with all omitted members charged once. -/
theorem actual_odd_subset_sharp (n:ℕ) (B P:Finset ℕ) (hd:DoublingFree B)
    (hP:P⊆parityMiddle n B 1) (hn:NoEdge B P) :
    P.card≤2*((middle n B).filter (fun x=>x%4=2)).card+
      2*(res8 (excessHoles n B) 4).card+(res8 (excessHoles n B) 2).card+
      (res8 (excessHoles n B) 6).card+((parityMiddle n B 1)\P).card+2 := by
  let O:=parityMiddle n B 1
  let F:=O\P
  let A:=res8 P 1
  let C:=res8 P 5
  let V:=res8 P 3
  let W:=res8 P 7
  let O1:=res4 P 1
  let O3:=res4 P 3
  let F1:=res4 F 1
  let F3:=res4 F 3
  let H4:=res8 (excessHoles n B) 4
  let Hx:=res8 (excessHoles n B) 2
  let Hy:=res8 (excessHoles n B) 6
  let T2:=(middle n B).filter (fun x=>x%4=2)
  have hpodd:∀x∈P,x%2=1:=fun x hx=>(mem_filter.mp (hP hx)).2
  have hfodd:∀x∈F,x%2=1:=fun x hx=>(mem_filter.mp (mem_sdiff.mp hx).1).2
  have hc1:O1.card=A.card+C.card := by
    apply partition_card
    · intro x
      simp only [O1,A,C,res4,res8,mem_filter]
      constructor
      · rintro ⟨hx,hr⟩
        by_cases h:x%8=1
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨hx,hr⟩|⟨hx,hr⟩) <;> exact ⟨hx,by omega⟩
    · intro x hx hy
      have h1:=(mem_filter.mp hx).2
      have h2:=(mem_filter.mp hy).2
      omega
  have hc3:O3.card=V.card+W.card := by
    apply partition_card
    · intro x
      simp only [O3,V,W,res4,res8,mem_filter]
      constructor
      · rintro ⟨hx,hr⟩
        by_cases h:x%8=3
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨hx,hr⟩|⟨hx,hr⟩) <;> exact ⟨hx,by omega⟩
    · intro x hx hy
      have h1:=(mem_filter.mp hx).2
      have h2:=(mem_filter.mp hy).2
      omega
  have hsplit:∀S:Finset ℕ,(∀x∈S,x%2=1)→S.card=(res4 S 1).card+(res4 S 3).card := by
    intro S hodd
    apply partition_card
    · intro x
      simp only [res4,mem_filter]
      constructor
      · intro hx
        have hp:=hodd x hx
        by_cases h:x%4=1
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨hx,_⟩|⟨hx,_⟩) <;> exact hx
    · intro x hx hy
      have h1:=(mem_filter.mp hx).2
      have h2:=(mem_filter.mp hy).2
      omega
  have hcP:=hsplit P hpodd
  have hcF:=hsplit F hfodd
  change P.card=O1.card+O3.card at hcP
  change F.card=F1.card+F3.card at hcF
  have hpc:∀r:ℕ,r%2=1→(res4 (middle n B) r).card≤
      (res4 P r).card+(res4 F r).card := by
    intro r hro
    have hs:res4 (middle n B) r⊆res4 P r∪res4 F r := by
      intro x hx
      obtain ⟨hxM,hxr⟩:=mem_filter.mp hx
      have hxO:x∈O:=mem_filter.mpr ⟨hxM,by omega⟩
      by_cases hxp:x∈P
      · exact mem_union_left _ (mem_filter.mpr ⟨hxp,hxr⟩)
      · exact mem_union_right _ (mem_filter.mpr ⟨mem_sdiff.mpr ⟨hxO,hxp⟩,hxr⟩)
    exact (card_le_card hs).trans (card_union_le _ _)
  have hp1:=hpc 1 (by omega)
  have hp3:=hpc 3 (by omega)
  have hp2:(res4 (middle n B) 2).card=T2.card:=rfl
  have hrr:∀r s p:ℕ,p<4→(r+s)%8=2*p→
      (res8 P r).card=0 ∨ (res8 P s).card=0 ∨
      (res8 P r).card+(res8 P s).card≤(res4 (middle n B) p).card+
        (res8 (excessHoles n B) (2*p)).card+1 := by
    intro r s p hp hrs
    by_cases hr0:(res8 P r).card=0
    · exact Or.inl hr0
    by_cases hs0:(res8 P s).card=0
    · exact Or.inr (Or.inl hs0)
    apply Or.inr;apply Or.inr
    apply pair_bound n B P (res8 P r) (res8 P s) (res4 (middle n B) p)
      (res8 (excessHoles n B) (2*p)) hd (fun x hx=>(mem_filter.mp (hP hx)).1) hn
      (filter_subset _ _) (filter_subset _ _)
      (card_pos.mp (by omega)) (card_pos.mp (by omega))
    · intro x hx y hy v hv he
      have hxr:=(mem_filter.mp hx).2
      have hys:=(mem_filter.mp hy).2
      exact mem_filter.mpr ⟨hv,by omega⟩
    · intro x hx y hy hhole
      have hxr:=(mem_filter.mp hx).2
      have hys:=(mem_filter.mp hy).2
      exact mem_filter.mpr ⟨hhole,by omega⟩
  have hAB:=hrr 1 3 2 (by omega) (by omega)
  have hCD:=hrr 5 7 2 (by omega) (by omega)
  have hAC:=hrr 1 5 3 (by omega) (by omega)
  have hBD:=hrr 3 7 1 (by omega) (by omega)
  have hAA:=hrr 1 1 1 (by omega) (by omega)
  have hCC:=hrr 5 5 1 (by omega) (by omega)
  have hBB:=hrr 3 3 3 (by omega) (by omega)
  have hDD:=hrr 7 7 3 (by omega) (by omega)
  norm_num only at hAB hCD hAC hBD hAA hCC hBB hDD
  change A.card=0 ∨ V.card=0 ∨ A.card+V.card≤_ at hAB
  change C.card=0 ∨ W.card=0 ∨ C.card+W.card≤_ at hCD
  change A.card=0 ∨ C.card=0 ∨ A.card+C.card≤_ at hAC
  change V.card=0 ∨ W.card=0 ∨ V.card+W.card≤_ at hBD
  change A.card=0 ∨ A.card=0 ∨ A.card+A.card≤_ at hAA
  change C.card=0 ∨ C.card=0 ∨ C.card+C.card≤_ at hCC
  change V.card=0 ∨ V.card=0 ∨ V.card+V.card≤_ at hBB
  change W.card=0 ∨ W.card=0 ∨ W.card+W.card≤_ at hDD
  change (res4 (middle n B) 1).card≤O1.card+F1.card at hp1
  change (res4 (middle n B) 3).card≤O3.card+F3.card at hp3
  have hfour:=four_residue_algebra_sharp A.card V.card C.card W.card
    (T2.card+H4.card) (F1.card+Hx.card) (F3.card+Hy.card)
    (by dsimp [H4];omega) (by dsimp [H4];omega)
    (by dsimp [Hy];omega) (by dsimp [Hx];omega)
    (by dsimp [Hx];omega) (by dsimp [Hx];omega)
    (by dsimp [Hy];omega) (by dsimp [Hy];omega)
  change P.card≤2*T2.card+2*H4.card+Hx.card+Hy.card+F.card+2
  omega

#print axioms four_residue_algebra_sharp
#print axioms actual_odd_subset_sharp
end OP02.SharpK4

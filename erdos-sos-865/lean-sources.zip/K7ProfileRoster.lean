import K7Assembly
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- Full original chain rooted at the odd primitive u. The bound j≤H
includes every possible member of [1,H]. -/
def originalChain (H u:ℕ) : Finset ℕ :=
  ((range (H+1)).image (fun j=>u*2^j)) ∩ Icc 1 H

def lowPrimitiveLoss (H:ℕ) (D:Finset ℕ) : ℕ :=
  ∑ u ∈ (Icc 1 (H/4)).filter (fun u=>u%2=1),
    (((originalChain H u).card+1)/2-((originalChain H u)∩D).card)

def twoOffsets (S:Finset ℕ) := S.filter (fun x=>x%4=2)
def largest (S:Finset ℕ) := S.sup id
def sameOdd (S:Finset ℕ) : Prop :=
  ∃c<4,c%2=1 ∧ ∀x∈S,x%2=1→x%4=c
def evenZero (S:Finset ℕ) : Prop := ∀x∈S,x%2=0→x%4=0

/-- (G) of the reviewed M4 paper, using actual inventory and the gap
of the *other* same-residue pair to choose P-even or P-odd. -/
def mixedGuard (n:ℕ) (B S:Finset ℕ) : Prop :=
  let H:=n/4
  let D:=quarterD n B
  let O:=((Ioc (H/2) H).filter (fun x=>x%2=1 ∧ x∉D)).card
  let L:=lowPrimitiveLoss H D
  let hi:=(missingTopOdd n B).card
  let p:=(emptyPairs n B).card
  ∃ x₀∈S,∃ x₁∈S,∃ y₀∈S,∃ y₁∈S,
    x₀<x₁ ∧ y₀<y₁ ∧ x₀%2=1 ∧ y₀%2=1 ∧ x₁%4=x₀%4 ∧ y₁%4=y₀%4 ∧ x₀%4≠y₀%4 ∧
    (x₁≠largest S ∨ 20*x₁≤13*H) ∧
    let η:=if (y₁-y₀)/4%2=0 then 4*(10*O+hi+8*p)+8 else 8*(9*O+2*L+hi+8*p)+24
    8*(x₁-x₀)+16*(4+η)≤5*H

/-- Current 22-row ledger. For j=2 use the larger residue-two vertex
even when a different vertex is the overall maximum. Equality is row 8. -/
noncomputable def rowNumber (n:ℕ) (B S:Finset ℕ) : ℕ := by
  classical
  let o:=(oddOffsets S).card
  let j:=(twoOffsets S).card
  let s:=largest S
  let m:=largest (twoOffsets S)
  let low:=3*m≤2*(n/4)
  exact if o=0 then 1 else if o=1 then 2 else if o=2 then
    (if sameOdd S then 3 else if j=0 then 4 else if j=1 then
      (if m≠s then 5 else if low then 6 else 7) else if j=2 then (if low then 8 else 9) else 10)
    else if o=3 then (if sameOdd S then (if evenZero S then 12 else 11)
      else if j=0 then 13 else if j=1 then (if m≠s then 14 else 15) else 16)
    else if o=4 then (if evenZero S then 17 else if sameOdd S then 18
      else if (S.filter (fun x=>x%4=1)).card≠2 then 19 else if mixedGuard n B S then 20 else 21)
    else 22

def openRows : Finset ℕ := Icc 1 22 \ {1,12,17,22}

theorem exact_dispatch (n:ℕ) (B S:Finset ℕ) : ∃! i:ℕ,i∈Icc 1 22 ∧ rowNumber n B S=i := by
  classical
  refine ⟨rowNumber n B S,⟨?_,rfl⟩,fun i hi=>hi.2.symm⟩
  unfold rowNumber
  dsimp only
  split_ifs <;> decide

theorem remaining_row {n:ℕ} {B S:Finset ℕ} (hS:S.card=5) (h:remainingProfiles S) :
    rowNumber n B S∈openRows := by
  classical
  have ho:(oddOffsets S).card≤5 := (card_filter_le _ _).trans hS.le
  obtain ⟨hn,hm,hd⟩:=h
  change ¬(4≤(oddOffsets S).card ∧ evenZero S) at hm
  change ¬((oddOffsets S).card=3 ∧ evenZero S ∧ sameOdd S) at hd
  have h5:(oddOffsets S).card=5 → evenZero S := by
    intro h
    have hcard:=parity_partition S
    have hnil:evenOffsets S=∅:=card_eq_zero.mp (by omega)
    intro x hx he;have hh:x∈evenOffsets S:=mem_filter.mpr ⟨hx,he⟩
    simp [hnil] at hh
  have hex:(oddOffsets S).card=1 ∨ (oddOffsets S).card=2 ∨ (oddOffsets S).card=3 ∨ (oddOffsets S).card=4:=by
    by_contra h;have h5':(oddOffsets S).card=5:=by omega
    exact hm ⟨by omega,h5 h5'⟩
  rcases hex with e|e|e|e
  · simp [rowNumber,e,openRows]
  · simp only [rowNumber,e];norm_num;split_ifs <;> decide
  · have hh:sameOdd S → ¬evenZero S:=fun h he=>hd ⟨e,he,h⟩
    by_cases h:sameOdd S
    · simp [rowNumber,e,h,hh h,openRows]
    · simp only [rowNumber,e,h];norm_num;split_ifs <;> decide
  · have hh:¬evenZero S:=fun he=>hm ⟨by omega,he⟩
    simp only [rowNumber,e,hh];norm_num;split_ifs <;> decide

def RowExclusion (i:ℕ) : Prop :=
  ∀β:ℝ,0<β→∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S → rowNumber n B S=i→False

/-- The maximum of finitely many genuine per-row thresholds is independent
of n, the physical set and every subsequently admitted seed. -/
theorem remaining_of_row_proofs (hr:∀ i∈openRows,RowExclusion i) : RemainingExclusion := by
  classical
  intro β hb
  let threshold (i:ℕ):ℕ:=if hi:i∈openRows then (hr i hi β hb).choose else 0
  refine ⟨openRows.sup threshold,?_⟩
  intro n hn B hsub hf hd hg S hs hrem
  let i:=rowNumber n B S
  have hi:i∈openRows:=remaining_row hs.1 hrem
  have ht:threshold i≤n:=(le_sup (f:=threshold) hi).trans hn
  dsimp only [threshold] at ht;rw [dif_pos hi] at ht
  exact (hr i hi β hb).choose_spec n ht B hsub hf hd hg S hs rfl

theorem normalized_of_open_rows (hD:Dousse7) (h:∀i∈openRows,RowExclusion i) : NormalizedK7Goal :=
  normalized_of_remaining hD (remaining_of_row_proofs h)
theorem limit_of_open_rows (hD:Dousse7) (h:∀i∈openRows,RowExclusion i) : SharpK7Limit :=
  limit_of_normalized hD (normalized_of_open_rows hD h)

end OP02.SharpK7

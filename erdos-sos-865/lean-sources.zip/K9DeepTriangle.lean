import K9DeepTests

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7 OP02.SharpK8
namespace OP02.SharpK9

/-- Exact signed reflection supply in the small prefix of the physical twice-projected set. -/
theorem deep_reflected_supply {h : ℕ} {G : Finset ℕ} (hd : DoublingFree G)
    (enough : (h/64+1)/2 + (h/16+1)/2 < (quarterD (h/4) G).card) :
    let Y := quarterD (h/4) G
    let S := Y ∩ Icc 1 (h/64)
    ∃ e∈S, e%2=0 ∧ (unmatchedTop (h/16) Y).card < (reflectionPairs S e).card := by
  dsimp only
  let Y := quarterD (h/4) G
  let S := Y ∩ Icc 1 (h/64)
  have yd : DoublingFree Y := quarter_doubling_free _ _ hd
  have ys : Y ⊆ Icc 1 (h/16) := by
    rw [show h/16=h/4/4 by omega]
    exact filter_subset _ _
  have radial := top_band_cancellation (h/16) Y ys yd
  rw [show h/16/4=h/64 by omega] at radial
  change S.card+(h/16+1)/2=Y.card+(unmatchedTop (h/16) Y).card at radial
  change _ < Y.card at enough
  have sd : DoublingFree S := fun a ha h2 => yd a (mem_inter.mp ha).1 (mem_inter.mp h2).1
  obtain ⟨e,he,ep,_,bound⟩ := find_reflection_sum (h/64) S inter_subset_right sd (by omega)
  refine ⟨e,he,ep,?_⟩
  change (unmatchedTop (h/16) Y).card < (reflectionPairs S e).card
  omega

/-- Construct and dilate the same three pairwise adjacent vertices in both parity branches. -/
theorem deep_triangle_finite {h σ : ℕ} {G : Finset ℕ} (sub : G ⊆ Icc 1 h)
    (hd : DoublingFree G)
    (pairs : (h/64+1)/2 + (h/16+1)/2 < (quarterD (h/4) G).card)
    (odds : 3*(deepFaults h G).card < (deepEnd h+1)/2-(deepStart h σ+1)/2)
    (evens : (deepFaults h G).card < chainCapacity (deepEnd h/4)-chainCapacity (deepStart h σ/4)) :
    DelayedTriangle h σ G := by
  classical
  let Y := quarterD (h/4) G
  let S := Y ∩ Icc 1 (h/64)
  obtain ⟨e,he,ee,pop⟩ := deep_reflected_supply hd pairs
  change e∈S at he
  change (unmatchedTop (h/16) Y).card < (reflectionPairs S e).card at pop
  have small : S⊆Icc 1 (h/64) := inter_subset_right
  have phys {j} (hj : j∈S) : 4*j∈G := (mem_filter.mp (mem_inter.mp hj).1).2
  have build {a z : ℕ} (ha : a∈reflectionPairs S e)
      (zl : deepStart h σ<z) (zu : z≤deepEnd h)
      (zG : 4*z∈G) (za : 4*(z+a)∈G) (zc : 4*(z+(e-a))∈G) : DelayedTriangle h σ G := by
    obtain ⟨as,apos,ac,cs⟩ := mem_filter.mp ha
    have eb := (mem_Icc.mp (small he)).2
    have cb := (mem_Icc.mp (small cs)).2
    dsimp only [deepStart,deepEnd] at zl zu
    refine ⟨4*a,4*(e-a),4*z,by omega,by omega,by omega,by omega,by omega,by omega,
      by omega,by omega,by omega,phys as,phys cs,zG,?_,?_,?_⟩
    · simpa only [show 4*a+4*(e-a)=4*e by omega] using phys he
    · simpa only [Nat.mul_add] using za
    · simpa only [Nat.mul_add] using zc
  by_cases hasEven : ∃a∈reflectionPairs S e, a%2=0
  · obtain ⟨a,ha,even⟩ := hasEven
    obtain ⟨as,apos,ac,cs⟩ := mem_filter.mp ha
    obtain ⟨z,zlo,zup,zG,za,zc⟩ := deep_even_pair_tester sub hd even (by omega : (e-a)%2=0)
      (mem_Icc.mp (small as)).2 (mem_Icc.mp (small cs)).2 odds
    exact build ha zlo zup zG za zc
  · have oddPairs : ∀ a∈reflectionPairs S e, a%2=1 := by
      intro a ha
      by_contra! no
      exact hasEven ⟨a,ha,by omega⟩
    obtain ⟨z,zlo,zup,ze,zG⟩ := deep_odd_pair_tester sub hd evens
    obtain ⟨a,ha,za,zc⟩ := deep_pair_after_tester small ee oddPairs pop zlo zup ze
    exact build ha zlo zup zG za zc

end OP02.SharpK9

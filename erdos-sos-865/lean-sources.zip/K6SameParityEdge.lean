import K5Canonical
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole
set_option maxHeartbeats 4000000

/-- Reflection about the greatest actual even member, including the absent diagonal. -/
theorem no_same_parity_edge_capacity (J:ℕ) (A:Finset ℕ)
    (hs:A⊆Icc 1 J) (hd:DoublingFree A)
    (he : ∀ r ∈ A, ∀ s ∈ A, r ≠ s → r % 2 = s % 2 → r+s ∉ A) : A.card≤(J+1)/2 := by
  classical
  let E:=A.filter (fun x=>x%2=0)
  by_cases hE:E.Nonempty
  · let m:=E.max' hE
    have hmE:m∈E:=max'_mem E hE
    have hmA:m∈A:=(mem_filter.mp hmE).1
    have hm2:m%2=0:=(mem_filter.mp hmE).2
    have hmJ:=mem_Icc.mp (hs hmA)
    have hodd (x:ℕ) (hx:x∈A) (hmx:m<x):x%2=1 := by
      by_contra h
      have hxE:x∈E:=mem_filter.mpr ⟨hx,by omega⟩
      have:=le_max' E x hxE
      change x≤ m at this
      omega
    have hdiag (x:ℕ) (hx:x∈A):2*x≠m := by
      intro hh
      exact hd x hx (hh.symm ▸ hmA)
    let f:=fun x:ℕ=>if x≤ m then min x (m-x)+1 else m/2+(x-m+1)/2
    have hf:∀x∈A,f x∈Icc 1 ((J+1)/2) := by
      intro x hx
      have hxJ:=mem_Icc.mp (hs hx)
      have hxD:=hdiag x hx
      simp only [f]
      split_ifs with hxm
      · have hmin:min x (m-x)≤x:=min_le_left _ _
        have hmin':min x (m-x)≤ m-x:=min_le_right _ _
        apply mem_Icc.mpr; omega
      · have hxodd:=hodd x hx (by omega)
        apply mem_Icc.mpr; omega
    have hi:Set.InjOn f A := by
      intro x hx y hy hxy
      have hxJ:=mem_Icc.mp (hs hx)
      have hyJ:=mem_Icc.mp (hs hy)
      have hxD:=hdiag x hx
      have hyD:=hdiag y hy
      dsimp only [f] at hxy
      split_ifs at hxy with hxm hym hym
      · by_cases hxy':x=y
        · exact hxy'
        · have hsum:x+y=m := by
            by_cases hxlow:x≤ m-x <;> by_cases hylow:y≤ m-y
            · rw [min_eq_left hxlow,min_eq_left hylow] at hxy; omega
            · rw [min_eq_left hxlow,min_eq_right (by omega)] at hxy; omega
            · rw [min_eq_right (by omega),min_eq_left hylow] at hxy; omega
            · rw [min_eq_right (by omega),min_eq_right (by omega)] at hxy; omega
          exact False.elim (he x hx y hy hxy' (by omega) (hsum.symm ▸ hmA))
      · have hyodd:=hodd y hy (by omega)
        have hmin:=min_le_left x (m-x)
        have hmin':=min_le_right x (m-x)
        omega
      · have hxodd:=hodd x hx (by omega)
        have hmin:=min_le_left y (m-y)
        have hmin':=min_le_right y (m-y)
        omega
      · have hxodd:=hodd x hx (by omega)
        have hyodd:=hodd y hy (by omega)
        omega
    have hc:A.card≤(Icc 1 ((J+1)/2)).card := by
      rw [←card_image_of_injOn hi]
      exact card_le_card (image_subset_iff.mpr hf)
    simpa using hc
  · have hodd:∀x∈A,x%2=1 := by
      intro x hx
      by_contra hh
      exact hE ⟨x,mem_filter.mpr ⟨hx,by omega⟩⟩
    have hi:Set.InjOn (fun x:ℕ=>(x+1)/2) A := by
      intro x hx y hy hxy
      have:=hodd x hx
      have:=hodd y hy
      dsimp only at hxy
      omega
    have hc:A.card≤(Icc 1 ((J+1)/2)).card := by
      rw [←card_image_of_injOn hi]
      apply card_le_card
      intro y hy
      obtain ⟨x,hx,rfl⟩:=mem_image.mp hy
      have:=mem_Icc.mp (hs hx)
      exact mem_Icc.mpr ⟨by omega,by omega⟩
    simpa using hc

theorem same_parity_edge (J:ℕ) (A:Finset ℕ)
    (hs:A⊆Icc 1 J) (hd:DoublingFree A) (hc:(J+1)/2<A.card) :
    ∃r∈A,∃s∈A,r≠s ∧ r%2=s%2 ∧ r+s∈A := by
  by_contra h
  push_neg at h
  have hcap:=no_same_parity_edge_capacity J A hs hd h
  omega

#print axioms no_same_parity_edge_capacity
#print axioms same_parity_edge
end OP02.SharpK6

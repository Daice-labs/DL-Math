import K6ForcedBands
import K5BandBudgets
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 1000000

def bandCost (n σ:ℕ) (B:Finset ℕ) :=
  ((middle n B).filter (fun x=>x%4=2)).card+(res8 (excessHoles n B) 4).card+
  (res8 (excessHoles n B) ((2*σ)%8)).card+4*(Ho n B).card

def maximalBandCost (n:ℕ) (B:Finset ℕ) :=
  ((middle n B).filter (fun x=>x%4=2)).card+(res8 (excessHoles n B) 4).card+
  max (res8 (excessHoles n B) 2).card (res8 (excessHoles n B) 6).card+4*(Ho n B).card

def highThreshold (n:ℕ) (B:Finset ℕ) :=32*maximalBandCost n B+8*(missingTopOdd n B).card+16

theorem band_budget (n σ:ℕ) (B:Finset ℕ) (hd:DoublingFree B) (hσ:σ=1 ∨ σ=3) :
    bandCost n σ B≤ maximalBandCost n B ∧
    2*(missingTopOdd n B).card+4*bandCost n σ B+(fourResources n B).card≤16*totalBudget n B ∧
    4*bandCost n σ B+(missingTopOdd n B).card≤16*totalBudget n B ∧
    highThreshold n B≤128*totalBudget n B+16 ∧
    highThreshold n B+32*(missingTopOdd n B).card≤128*totalBudget n B+16 := by
  have ht:=middle_two_le_singleton n B hd
  have hdelt:=deficit_split n B hd
  have hE:=excess_partition n B
  obtain ⟨he0,he2⟩:=even_resource_partition n B
  have hJ:=four_resource_card n B
  simp only [bandCost,maximalBandCost,highThreshold,totalBudget]
  rcases hσ with rfl|rfl <;> norm_num <;> omega

#print axioms band_budget
end OP02.SharpK6

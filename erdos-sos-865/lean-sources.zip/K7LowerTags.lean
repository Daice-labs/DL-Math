import K7LongOddContract

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

/-- The part of the original empty-slot inventory used by lower odd labels. -/
def lowerOriginal (n : ℕ) (B : Finset ℕ) :=
  (emptyPairs n B).filter (fun r => r ≤ n/4/4)

/-- Missing physical odd roots below the quarter boundary and both components of T.
The same level-quarter singleton may occur in A. -/
theorem joint_lower_upper (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    (lowerHoles n B).card + T_loss n B ≤ lambdaBudget n B := by
  let E := emptyOuter (n/4/4) (quarterD n B)
  let L := lowerOriginal n B
  let U := upperOriginal n B
  have source : lowerHoles n B ⊆ E ∪ L := by
    intro r hr
    obtain ⟨hi,ho,hm⟩ := mem_filter.mp hr
    obtain ⟨hlo,hhi⟩ := mem_Ioc.mp hi
    by_cases hroot : r ∈ quarterD n B
    · have hfour := (mem_filter.mp hroot).2
      have htwo : 2*r ∉ B := fun h => hd (2*r) h (by simpa [←Nat.mul_assoc] using hfour)
      exact mem_union_right _ (mem_filter.mpr ⟨mem_filter.mpr
        ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,ho⟩,by omega,hm,htwo⟩,hhi⟩)
    · exact mem_union_left _ (absent_quarter_root hlo hhi ho hroot)
  have split : Disjoint L U := by
    apply disjoint_left.mpr
    intro r hl hu
    have h1 := (mem_filter.mp hl).2
    have h2 := (mem_filter.mp hu).2
    omega
  have both := card_le_card (union_subset (filter_subset _ _) (filter_subset _ _) :
    L ∪ U ⊆ emptyPairs n B)
  rw [card_union_of_disjoint split] at both
  have pay := (card_le_card source).trans (card_union_le _ _)
  change (lowerHoles n B).card +
    ((emptyOuter (n/4) (quarterD n B)).card + U.card) ≤
      E.card + (emptyOuter (n/4) (quarterD n B)).card + (emptyPairs n B).card
  omega

theorem signed_units {β : ℝ} {n : ℕ} {B : Finset ℕ} (hd : DoublingFree B)
    (hg : (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale : 64 ≤ n/4) (hl : 10*(logLevels (n/4):ℝ)+1000 ≤ β*n) :
    6*(lambdaBudget n B + (midOddLoss n B).card)+6000 < n/4/64 := by
  have s := (signed_supply β n B hd hg (by omega) hl).2.1
  exact_mod_cast (show (6:ℝ)*((lambdaBudget n B:ℝ)+(midOddLoss n B).card)+6000 <
    (n/4/64:ℕ) by linarith only [s])

theorem scalar_from_charge {n t : ℕ} {B : Finset ℕ}
    (h : ChargeEvidence n B t)
    (hbudget : 6*(lambdaBudget n B+(midOddLoss n B).card)+6000 < n/4/64) :
    LossBound n B t := by
  obtain ⟨Z,_,hp,hc⟩ := h
  unfold LossBound
  omega

end OP02.SharpK7.LongOddTask

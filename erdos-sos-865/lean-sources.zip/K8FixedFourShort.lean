import K8FixedFourFinish
import K8GapMatch

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7
namespace OP02.SharpK8

/-- The two failed-target classes, together with the actual reflected-pair surplus,
construct a new short five including all ten prefix sums. -/
theorem fixed_four_full_failure {H e p q : ℕ} {D X Z : Finset ℕ}
    (hH : 16777216≤H) (ds : D⊆Icc 1 H) (hd : DoublingFree D)
    (cap : 1536*(chainCapacity H-D.card)<H)
    (zs : Z⊆Icc 1 (H/256)) (roots : ∀x∈Z,4*x∈D)
    (eZ : e∈Z) (ee : e%2=0)
    (pop : (unmatchedTop (H/4) D).card+(unmatchedTop (H/4/4) D).card < (reflectionPairs Z e).card)
    (small : ∀x∈X,128*x<5*H) (pair : GapPair (insert 0 X) p q)
    (miss : (missingGap H D p q).card+(missingGap H D q p).card ≤ 3*(chainCapacity H-D.card)) :
    ∃F, ShortFive H D F := by
  classical
  have osmall (x : ℕ) (hx : x∈insert 0 X) : 128*x<5*H := by
    rcases mem_insert.mp hx with hh|hh
    · omega
    · exact small x hh
  have gaps {a b z : ℕ} (ab : a≤b) (bs : b≤H/256)
      (window : z=0 ∨ (H/4<2*z ∧ z+fifthCeil H≤H/4 ∧ z%4=0)) :
      ∃u v, GapMember H D (4*a) (4*b) z u ∧ GapMember H D (4*a) (4*b) z v ∧
        u≠v ∧ u≤fifthCeil H+2 ∧ v≤fifthCeil H+2 ∧ u+v∈D := by
    obtain ⟨u,v,uu,vv,_,_,modSum,sum⟩ := select_gap_pair (by omega) ds hd cap
      (osmall p pair.left_mem) (osmall q pair.right_mem) pair.same pair.different miss
      (A:=4*a) (C:=4*b) (by omega) (by omega) (by omega) (by omega) window
    have uodd := uu.odd
    have uq := uu.upper;have vq := vv.upper
    exact ⟨u,v,uu,vv,by intro h;omega,by dsimp [fifthCeil];omega,by dsimp [fifthCeil];omega,sum⟩
  by_cases evenPair : ∃a∈reflectionPairs Z e,a%2=0
  · obtain ⟨a,ha,ae⟩ := evenPair
    obtain ⟨az,apos,ab,bz⟩ := mem_filter.mp ha
    let b := e-a
    change a<b at ab
    change b∈Z at bz
    have bs := (mem_Icc.mp (zs bz)).2
    have be : b%2=0 := by dsimp only [b] at *;omega
    have hsum : 4*a+4*b∈D := by
      have eq : 4*a+4*b=4*e := by dsimp only [b] at *;omega
      rw [eq]; exact roots e eZ
    obtain ⟨u,v,uu,vv,uv,us,vs,guv⟩ := gaps (z:=0) ab.le bs (Or.inl rfl)
    obtain ⟨z,mz,zlo,zhi,_,za,zb,zu,zv⟩ :=
      choose_even_pair_fifth ds hd hH cap ae be ab.le bs uu.odd vv.odd us vs
    exact fixed_alternative_short hH apos ab bs uu.odd vv.odd uv us vs zlo zhi
      (roots a az) (roots b bz) uu.mem vv.mem mz hsum uu.contactA uu.contactC
      vv.contactA vv.contactC guv za zb zu zv
  · have oddPairs (a : ℕ) (ha : a∈reflectionPairs Z e) : a%2=1 := by
      by_contra! bad
      exact evenPair ⟨a,ha,by omega⟩
    obtain ⟨a,b,z,apos,ab,bs,_,_,ra,rb,rs,mz,lo,hi,z16,za,zb⟩ :=
      odd_pair_and_fifth ds hd hH cap zs roots eZ ee oddPairs pop
    have zwin : H/4<2*z ∧ z+fifthCeil H≤H/4 ∧ z%4=0 := by
      dsimp only [fifthCap,fifthCeil] at hi ⊢
      omega
    obtain ⟨u,v,uu,vv,uv,us,vs,guv⟩ := gaps ab.le bs (Or.inr zwin)
    exact fixed_alternative_short hH apos ab bs uu.odd vv.odd uv us vs lo hi
      ra rb uu.mem vv.mem mz rs uu.contactA uu.contactC vv.contactA vv.contactC
      guv za zb uu.contactZ vv.contactZ

/-- The signed original rooted set uniformly provides an actual short five
without a seed and with Dousse5 as its only mathematical premise. -/
theorem signed_short_five (h5 : Dousse5) {β : ℝ} (hb : 0<β) :
    ∃M : ℕ, ∀ n : ℕ, M≤n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
      ∃F, ShortFive (n/4) (quarterD n B) F := by
  apply signed_short_five_of_full_branch _ h5 hb
  intro H hH D X Z sub hd cap zs roots witnesses _ small p q pair miss
  obtain ⟨e,he,ee,pop⟩ := witnesses
  exact fixed_four_full_failure hH sub hd cap zs roots he ee pop small pair miss

end OP02.SharpK8

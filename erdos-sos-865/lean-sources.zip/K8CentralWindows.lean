import K8CentralCodes
import K8CentralCounting

open Finset OP02.SharpK5
namespace OP02.SharpK8

theorem central_pattern_supplies {F : Finset ℕ} (pat : CentralPattern F)
    {H l u d : ℕ} (large : 10^9≤H) (budget : 1536*d<H) :
    let P := residueCandidates l u pat.modulus pat.codes
    (68*H≤1024*(u-l+32) → pat.load*d<P.card) ∧
    (H/4≤u-l+1 → 6*d<P.card) := by
  let m := pat.modulus
  have period : pat.modulus=32 ∨ pat.modulus=2048 := pat.size.elim (fun h=>Or.inl h.1) (fun h=>Or.inr h.1)
  have count := codes_supply (l:=l) (u:=u) period pat.bounded
  dsimp only
  rcases pat.size with ⟨eq,ct,lk⟩ | ⟨eq,ct,lk⟩
  · have n := Nat.mul_le_mul_left ((u-l)/pat.modulus-1) ct
    rw [eq] at count n ⊢
    rw [lk]
    simp only [Nat.mul_one] at n
    constructor <;> intro h <;> omega
  · have n := Nat.mul_le_mul_left ((u-l)/pat.modulus-1) ct
    rw [eq] at count n ⊢
    rw [lk]
    constructor <;> intro h <;> omega

def centralLower (H g : ℕ) := max (H/4/2) (g-(H/4-4*(3*(H/256)+1)))
def centralUpper (H g : ℕ) := min (H/4-4*(3*(H/256)+1)) (g-(H/4/2+1))

theorem reflected_window {H g : ℕ} (large : 10^9≤H)
    (gl : 324*H≤1024*g) (gu : 1024*g≤348*H) :
    68*H≤1024*(centralUpper H g-centralLower H g+32) ∧
    ∀x∈Ioc (centralLower H g) (centralUpper H g),
      H/4/2<x ∧ x≤H/4-4*(3*(H/256)+1) ∧ x≤g ∧
      H/4/2<g-x ∧ g-x≤H/4-4*(3*(H/256)+1) := by
  unfold centralLower centralUpper
  constructor
  · omega
  · intro x hx
    obtain ⟨xl,xu⟩ := mem_Ioc.mp hx
    omega

end OP02.SharpK8

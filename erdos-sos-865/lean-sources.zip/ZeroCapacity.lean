import ZeroSource
open Finset
namespace OP02.ZeroExcess
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

theorem odd_block_member {n A m z:ℕ} {B:Finset ℕ}
    (hm:0 < m) (hAo:A%2=1)
    (hblock:parityMiddle n B 1=(range m).image (fun i=>A+2*i)) :
    z∈parityMiddle n B 1 ↔ A≤z ∧ z≤A+2*(m-1) ∧ z%2=1 := by
  rw [hblock]
  constructor
  · rintro hz
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hz
    have hi':=mem_range.mp hi
    omega
  · rintro ⟨hl,hu,ho⟩
    exact mem_image.mpr ⟨(z-A)/2,mem_range.mpr (by omega),by omega⟩

theorem upper_even_present (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B)
    (he:(excessHoles n B).card=0) {v:ℕ}
    (hr:2*v∈Icc (2*n+1) (4*n)) (hv:v∉middle n B) : 2*v∈B := by
  by_contra hn
  obtain ⟨w,hw,hwe⟩:=(upper_missing_iff n B hd he hr).mp hn
  have heq:w=v := by omega
  exact hv (heq ▸ hw)

theorem usable_window {n A m x p z:ℕ} {B:Finset ℕ}
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hm:0 < m) (hAo:A%2=1) (hAn:n<A) (hAl:A+2*(m-1)≤2*n)
    (hblock:parityMiddle n B 1=(range m).image (fun i=>A+2*i))
    (hxB:x∈B) (hxn:x≤n) (hx4:x%4=0) (hxp:0<x)
    (hpB:p∈B) (hpxB:p+x∈B) (hpn:2*n<p) (hp4:p%4=0)
    (hzl:A≤z) (hzu:z+2≤A+2*(m-1)) (hzo:z%2=1)
    (hclip:p+z+2≤4*n) (hmid:z+1∉parityMiddle n B 0) :
    A+2*(m-1)<x+z+2 ∧ x+z≤2*n := by
  have hzM:=((odd_block_member hm hAo hblock).mpr ⟨hzl,by omega,hzo⟩)
  have hz2M:=((odd_block_member hm hAo hblock).mpr ⟨by omega,hzu,by omega⟩)
  have hzzB: z+(z+2)∈B := by
    have hv:z+1∉middle n B := by
      intro hh
      exact hmid (mem_filter.mpr ⟨hh,by omega⟩)
    have hh:=upper_even_present n B hd he (v:=z+1)
      (mem_Icc.mpr ⟨by omega,by omega⟩) hv
    convert hh using 1 <;> omega
  have hpzB:p+z∈B:=upper_odd n B hd he (mem_Icc.mpr ⟨by omega,by omega⟩) (by omega)
  have hpz2B:p+(z+2)∈B:=upper_odd n B hd he (mem_Icc.mpr ⟨by omega,by omega⟩) (by omega)
  have hforbid:(x+z+2≤A+2*(m-1) ∨ 2*n<x+z) → False := by
    intro hh
    have hxs:x+z∈B ∧ x+(z+2)∈B := by
      rcases hh with hh|hh
      · constructor
        · exact (mem_inter.mp (mem_filter.mp ((odd_block_member hm hAo hblock).mpr
            ⟨by omega,by omega,by omega⟩)).1).1
        · exact (mem_inter.mp (mem_filter.mp ((odd_block_member hm hAo hblock).mpr
            ⟨by omega,by omega,by omega⟩)).1).1
      · exact ⟨upper_odd n B hd he (mem_Icc.mpr ⟨by omega,by omega⟩) (by omega),
          upper_odd n B hd he (mem_Icc.mpr ⟨by omega,by omega⟩) (by omega)⟩
    exact four_forbidden B hf hxB hpB (mem_inter.mp (mem_filter.mp hzM).1).1
      (mem_inter.mp (mem_filter.mp hz2M).1).1 (by omega) (by omega) (by omega)
      (by omega) (by omega) (by omega) (by simpa [Nat.add_comm] using hpxB)
      hxs.1 hxs.2 hpzB hpz2B hzzB
  constructor
  · by_contra hh
    exact hforbid (Or.inl (by omega))
  · by_contra hh
    exact hforbid (Or.inr (by omega))

theorem avoid_card (E:Finset ℕ) (f:ℕ→ℕ)
    (hi:Set.InjOn f (range (E.card+1))) :
    ∃i∈range (E.card+1), f i∉E := by
  by_contra hh
  push_neg at hh
  have hs:(range (E.card+1)).image f⊆E := by
    intro z hz
    obtain ⟨i,hi,rfl⟩:=mem_image.mp hz
    exact hh i hi
  have hc:=card_le_card hs
  rw [card_image_of_injOn hi,card_range] at hc
  omega

/-- Every admissible lower multiple lies in one common interval; no charge per x. -/
theorem capacity_endpoints {n A m x p C:ℕ} {B:Finset ℕ}
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hAo:A%2=1) (hAn:n<A) (hAl:A+2*(m-1)≤2*n)
    (hblock:parityMiddle n B 1=(range m).image (fun i=>A+2*i))
    (hlarge:C+2*(parityMiddle n B 0).card+4<2*m) (hCe:C%2=0)
    (hxB:x∈B) (hxn:x≤n) (hx4:x%4=0) (hxp:0<x)
    (hpB:p∈B) (hpxB:p+x∈B) (hpn:2*n<p) (hp4:p%4=0) (hpu:p≤2*n+C) :
    2*m≤x+2*(parityMiddle n B 0).card+4 ∧
    x+(A+2*(m-1))≤2*n+2*(parityMiddle n B 0).card+C+2 := by
  let k:=(parityMiddle n B 0).card
  let Z:=A+2*(m-1)
  have hm:0 < m:=by omega
  have hf_inj:Set.InjOn (fun i:ℕ=>A+2*i+1) (range (k+1)) := by
    intro i hi j hj hij
    dsimp at hij
    omega
  obtain ⟨i,hi,hnot⟩:=avoid_card (parityMiddle n B 0) (fun i=>A+2*i+1) hf_inj
  have hi':i≤k:=by have := mem_range.mp hi;omega
  have hfirst:=usable_window hf hd he hm hAo hAn hAl hblock hxB hxn hx4 hxp hpB hpxB hpn hp4
    (z:=A+2*i) (by omega) (by omega) (by omega) (by omega) hnot
  have hl_inj:Set.InjOn (fun j:ℕ=>Z-C-2-2*j+1) (range (k+1)) := by
    intro i hi j hj hij
    have hi':=mem_range.mp hi
    have hj':=mem_range.mp hj
    dsimp [Z,k] at *
    omega
  obtain ⟨j,hj,hnot'⟩:=avoid_card (parityMiddle n B 0) (fun j=>Z-C-2-2*j+1) hl_inj
  have hj':j≤k:=by have := mem_range.mp hj;omega
  have hlast:=usable_window hf hd he hm hAo hAn hAl hblock hxB hxn hx4 hxp hpB hpxB hpn hp4
    (z:=Z-C-2-2*j) (by dsimp [Z];omega) (by dsimp [Z];omega)
    (by dsimp [Z];omega) (by dsimp [Z];omega) hnot'
  dsimp [Z,k] at *
  omega

/-- Global capacity for any subset of quarter-roots with the same pivot bound. -/
theorem capacity_card {n A m C:ℕ} {B D:Finset ℕ}
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hAo:A%2=1) (hAn:n<A) (hAl:A+2*(m-1)≤2*n)
    (hblock:parityMiddle n B 1=(range m).image (fun i=>A+2*i))
    (hlarge:C+2*(parityMiddle n B 0).card+4<2*m) (hCe:C%2=0)
    (hD:D⊆quarterD n B)
    (hp:∀d∈D, ∃p, p∈B ∧ p+4*d∈B ∧ 2*n<p ∧ p%4=0 ∧ p≤2*n+C) :
    D.card=0 ∨ 4*D.card+4*m≤n+4*(parityMiddle n B 0).card+C+11 := by
  by_cases hne:D.Nonempty
  · let lo:=D.min' hne
    let hi:=D.max' hne
    have hlo:lo∈D:=min'_mem D hne
    have hhi:hi∈D:=max'_mem D hne
    have hDinterval:D⊆Icc lo hi := by
      intro x hx
      exact mem_Icc.mpr ⟨min'_le D x hx,le_max' D x hx⟩
    have hcard:=card_le_card hDinterval
    rw [Nat.card_Icc] at hcard
    have hlh:lo≤hi:=le_max' D lo hlo
    have hends:∀d∈D, 2*m≤4*d+2*(parityMiddle n B 0).card+4 ∧
        4*d+(A+2*(m-1))≤2*n+2*(parityMiddle n B 0).card+C+2 := by
      intro d hdD
      have hdq:=hD hdD
      obtain ⟨hdI,hdB⟩:=mem_filter.mp hdq
      have hdi:=mem_Icc.mp hdI
      obtain ⟨p,hpB,hpxB,hpn,hp4,hpu⟩:=hp d hdD
      exact capacity_endpoints hf hd he hAo hAn hAl hblock hlarge hCe hdB
        (by omega) (by omega) (by omega) hpB hpxB hpn hp4 hpu
    have h1:=hends lo hlo
    have h2:=hends hi hhi
    right
    omega
  · left
    exact card_eq_zero.mpr (not_nonempty_iff_eq_empty.mp hne)

#print axioms usable_window
#print axioms capacity_card
end OP02.ZeroExcess

import Mathlib
namespace OP02.EdgeBand

theorem residue_positive (n δ k h0 h2 eo m Q hi r b T:ℕ)
    (hm:32*(δ+h0+h2+eo)+64 < n)
    (hk:k ≤ 2*δ+h0+1) (hp:n/2 ≤ m+2*k+2*h0+4*eo+h2)
    (hQ:Q ≤ k+h0) (hh:hi ≤ eo) (hr:r+b ≤ k+h0)
    (ht:n/4+m ≤ n/2+T+Q+hi+r+2) : 0 < T := by omega

theorem restore_joint (n m d g b r k h0 eo Q hi lo T S V:ℕ)
    (hrestore:g+b=d) (hpay:r+b ≤ k+h0) (hQ:Q ≤ k+h0)
    (hholes:hi+lo=eo) (hmiss:V+m=n/2)
    (ht:2*m ≤ n/2+T+Q+2*hi+2*r+3)
    (hl:T+2*g ≤ S+2) (hu:S ≤ 2*(V+lo)) :
    2*d+4*m ≤ 3*(n/2)+3*(k+h0)+2*eo+5 := by omega

theorem restore_target (n δ k h0 h2 eo m d:ℕ)
    (hm:32*(δ+h0+h2+eo)+64 < n)
    (hk:k ≤ 2*δ+h0+1) (hp:n/2 ≤ m+2*k+2*h0+4*eo+h2)
    (hj:2*d+4*m ≤ 3*(n/2)+3*(k+h0)+2*eo+5) :
    8*d ≤ n+8*(δ+h0+h2+eo)+69 := by omega

#print axioms residue_positive
#print axioms restore_joint
#print axioms restore_target
end OP02.EdgeBand

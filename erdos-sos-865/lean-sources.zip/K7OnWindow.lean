import K7MixedPhysical
import K7FiveEighthsLog
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

def strictWindowCount (n : ℕ) (B : Finset ℕ) (e b : ℕ) (p₀ : ℤ) (I : Finset ℤ) : Prop :=
  let A:=retainedEndpoints n B e b
  let U:=latticeBad (n/4) B p₀ e I (A.image (fun z:ℕ=>(z:ℤ)))
  ((latticeVeto (n/4) B p₀ b I).card:ℤ)+max (U.card:ℤ)
    (3*(U.card:ℤ)-2*(A.card:ℤ)+2)<(I.card:ℤ)

def j0Witness (n : ℕ) (B : Finset ℕ) : Prop :=
  ∃ a c b p χ : ℕ, 0<a ∧ a<c ∧ c<b ∧ 4*b<p ∧ p<χ ∧
    p%2=1 ∧ χ%2=1 ∧ p%4≠χ%4 ∧
    InternalFive (B∩Icc 1 (n/4)) {4*a,4*c,4*b,p,χ}


/-- Record the winning pair parity before the selected roots are forgotten. -/
def qualifiedJ0 (n:ℕ) (B:Finset ℕ) : Prop :=
  ∃ a c b p χ : ℕ, 0<a ∧ a<c ∧ c<b ∧ 4*b<p ∧ p<χ ∧
    p%2=1 ∧ χ%2=1 ∧ p%4≠χ%4 ∧
    ((a%2=0 ∧ c%2=0 ∧ b%2=1) ∨ (a%2=1 ∧ c%2=1 ∧ b%4=0)) ∧
    InternalFive (B∩Icc 1 (n/4)) {4*a,4*c,4*b,p,χ}

theorem forget_qualification {n:ℕ} {B:Finset ℕ} (h:qualifiedJ0 n B) : j0Witness n B := by
  obtain ⟨a,c,b,p,χ,h₁,h₂,h₃,h₄,h₅,h₆,h₇,h₈,_,hc⟩:=h
  exact ⟨a,c,b,p,χ,h₁,h₂,h₃,h₄,h₅,h₆,h₇,h₈,hc⟩

private theorem prefixNat {H x:ℕ} {B:Finset ℕ} (h:(x:ℤ)∈prefixWord H B) : x∈B := by
  obtain ⟨v,hv,he⟩:=mem_image.mp h
  have h':v=x:=Int.ofNat_injective he
  exact h' ▸ (mem_inter.mp hv).1

/-- Interpolation and both tester alternatives, composed up to the actual
J0 clique. The per-placement count of failed indices remains explicit. -/
theorem qualified_j0_on_window {β : ℝ} {n e w : ℕ} {B : Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (he:e∈smallSupport n B) (he₂:e%2=0) (hw:w∈rigidPresent (n/4/64) (quarterD n B))
    (hj:lambdaBudget n B<(retainedEndpoints n B e (4*w)).card)
    (p₀:ℤ) (I:Finset ℤ) (hcnt:strictWindowCount n B e (4*w) p₀ I)
    (hwin:∀g∈I,∃p:ℕ,(p:ℤ)=p₀+4*g ∧ p%2=1 ∧ 3*(n/4)≤8*p ∧ 2*p≤n/4 ∧
      A_loss n B+3*T_loss n B<(progression (n/4/2) (n/4-p) 8 ((12-p%8)%8)).card) :
    qualifiedJ0 n B := by
  classical
  obtain ⟨g,hgI,a,ha,hp,hfar,hpa,hpc,haS,hcS,hqual⟩:=
    physical_interpolation n B e (4*w) p₀ I (retainedEndpoints n B e (4*w))
      Subset.rfl (card_pos.mp (by omega)) hcnt
  obtain ⟨p,heq,hop,hp₀,hp₁,hwidth⟩:=hwin g hgI
  rw [←heq] at hp hfar hpa hpc
  have hpn:p∈B:=prefixNat hp
  have hpa':p+4*a∈B:=prefixNat (by push_cast;exact hpa)
  have hpc':p+4*(e-a)∈B:=prefixNat (by push_cast;exact hpc)
  have hfar':p+4*(4*w)∈B:=prefixNat (by push_cast;exact hfar)
  obtain ⟨_,ha₁,hac,_⟩:=mem_filter.mp (mem_filter.mp ha).1
  -- Return the actual increasing order from the two sequential selections.
  -- The witness construction below uses the bounded tester also when the winner is even.
  have hsum:a+(e-a)=e:=by omega
  have heN:e≤n/4/64:=(mem_Icc.mp (mem_inter.mp he).2).2
  have hcand:∃ b, e-a<b ∧ 4*b<p ∧ ((a%2=0 ∧ (e-a)%2=0 ∧ b%2=1) ∨ (a%2=1 ∧ (e-a)%2=1 ∧ b%4=0)) ∧ b∈quarterD n B ∧
       a+b∈quarterD n B ∧ (e-a)+b∈quarterD n B ∧ p+4*b∈B := by
    by_cases ho:a%2=0
    · obtain ⟨d,h1,h2,h3,h4,h5,h6,h7⟩:=choose_even_tester hd hg hscale hl ha₁ hac
        (by omega) hp₀ hp₁ hop ⟨ho,by omega⟩
      exact ⟨d,h1,h2,Or.inl ⟨ho,by omega,h3⟩,h4,h5,h6,h7⟩
    · have hh:=hqual.resolve_left ho
      have hr:=rigid_bounds (mem_filter.mp hw).1
      exact ⟨4*w,by omega,by omega,Or.inr ⟨by omega,by omega,by omega⟩,(mem_filter.mp hw).2,
        by simpa [Nat.add_comm] using hh.1,by simpa [Nat.add_comm] using hh.2,hfar'⟩
  obtain ⟨d,hcd,hdp,hpar,hD,had,hcd',hpd⟩:=hcand
  obtain ⟨x,hhalf,hcap,hodd,ho,hx,hxa,hxc,hxd,hxp⟩:=
    select_partner n a (e-a) d p B hd hac hcd hdp hp₁ hop (by rcases hpar with hh|hh;exact Or.inr hh.2.2;exact Or.inl hh.1) hwidth
  exact ⟨a,e-a,d,p,x,ha₁,hac,hcd,hdp,by omega,hop,hodd,Ne.symm ho,hpar,
    actual_five n a (e-a) d p x B ha₁ hac hcd hdp (by omega) hcap
      (mem_inter.mp haS).1 (mem_inter.mp hcS).1 hD (hsum.symm ▸ (mem_inter.mp he).1)
      had hcd' hpn hpa' hpc' hpd hx hxa hxc hxd hxp⟩

theorem j0_witness_on_window {β : ℝ} {n e w : ℕ} {B : Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (he:e∈smallSupport n B) (he₂:e%2=0) (hw:w∈rigidPresent (n/4/64) (quarterD n B))
    (hj:lambdaBudget n B<(retainedEndpoints n B e (4*w)).card)
    (p₀:ℤ) (I:Finset ℤ) (hcnt:strictWindowCount n B e (4*w) p₀ I)
    (hwin:∀g∈I,∃p:ℕ,(p:ℤ)=p₀+4*g ∧ p%2=1 ∧ 3*(n/4)≤8*p ∧ 2*p≤n/4 ∧
      A_loss n B+3*T_loss n B<(progression (n/4/2) (n/4-p) 8 ((12-p%8)%8)).card) :
    j0Witness n B :=
  forget_qualification (qualified_j0_on_window hd hg hscale hl he he₂ hw hj p₀ I hcnt hwin)

/-- The actual gap produces a restricted EE or rigid OO triangle in the
admissible window, on the same root support as the tested pair. -/
theorem actual_restricted_triangle {β:ℝ} {n:ℕ} {B:Finset ℕ} (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n) :
    ¬RestrictedClear (n/4/16) (quarterD n B) := by
  intro hnone
  obtain ⟨e,he,hee,hmax,w,hw,hj⟩:=many_retained β n B hd hg hscale hl
  have hchoose : ∃ a∈retainedEndpoints n B e (4*w), a%2=0 ∨
      ∀v∈reflectionPairs (smallSupport n B) e,v%2=1 := by
    by_cases hc:∃a∈reflectionPairs (smallSupport n B) e,a%2=0
    · obtain ⟨a,ha,h₀⟩:=hc;exact ⟨a,mem_filter.mpr ⟨ha,Or.inl h₀⟩,Or.inl h₀⟩
    · obtain ⟨a,ha⟩:=card_pos.mp (show 0<(retainedEndpoints n B e (4*w)).card by omega)
      exact ⟨a,ha,Or.inr (by intro v hv;have hne:v%2≠0:=fun hh=>hc ⟨v,hv,hh⟩;omega)⟩
  obtain ⟨a,ha,hhall⟩:=hchoose
  obtain ⟨hp,hqual⟩:=mem_filter.mp ha
  obtain ⟨haS,ha₀,hac,hcS⟩:=mem_filter.mp hp
  have heN:e≤n/4/64:=(mem_Icc.mp (mem_inter.mp he).2).2
  have heq : a+(e-a)=e:=by omega
  have hfloor:n/4/16/4=n/4/64:=by omega
  have hspos:0<surplus n B:=(signed_supply β n B hd hg (by omega) hl).2.2
  unfold surplus at hspos
  have hbig:(n/4/16/4+1)/2<(prefixRoots (n/4/16/4) (quarterD n B)).card:=by
    rw [hfloor];change _<(smallSupport n B).card;omega
  have hmx:∀v∈prefixRoots (n/4/16/4) (quarterD n B),v%2=0→v≤a+(e-a):=by
    rw [hfloor,heq];exact hmax
  have head:=hnone hbig a (mem_inter.mp haS).1 (e-a) (mem_inter.mp hcS).1
  by_cases ho:a%2=0
  · have hc:=ee_margin β n a (e-a) B hd hg (by omega) ha₀ (by omega) (by omega) ⟨ho,by omega⟩
    have hl₀:(0:ℝ)≤logLevels (n/4):=by positivity
    have hΛ:(0:ℝ)≤lambdaBudget n B:=by positivity
    have hpos:0<(evenPairTesters n a (e-a) B).card:=by
      exact_mod_cast (show (0:ℝ)<(evenPairTesters n a (e-a) B).card by linarith only [hc,hl,hl₀,hΛ])
    obtain ⟨b,hb⟩:=card_pos.mp hpos
    obtain ⟨hwin,ht⟩:=mem_filter.mp hb
    have hh:=oddTestWindow_mem hwin
    have hn:=head b (by simpa using ht 0 (by simp)) ha₀ hac (by omega) (by omega)
      (heq.symm ▸ (mem_inter.mp he).1) hmx (by omega) (by omega) (Or.inl ⟨ho,by omega,hh.2.2⟩)
    exact hn.elim (fun h=>h (ht a (by simp))) (fun h=>h (ht (e-a) (by simp)))
  · have hh:=hqual.resolve_left ho
    have hr:=rigid_bounds (mem_filter.mp hw).1
    have hh':=head (4*w) (mem_filter.mp hw).2 ha₀ hac (by omega) (by omega)
      (heq.symm ▸ (mem_inter.mp he).1) hmx (by omega) (by omega)
      (Or.inr ⟨by omega,by omega,by rw [hfloor,heq];exact hhall.resolve_left ho,
        by by_cases heq₄:a%4=(e-a)%4;exact Or.inl ⟨heq₄,by omega⟩;exact Or.inr ⟨heq₄,by omega⟩⟩)
    exact hh'.elim (fun h=>h hh.1) (fun h=>h hh.2)

end OP02.SharpK7

import K8RothSpec

open Finset
namespace OP02.Midpoint

private theorem dense_window {k M L N : ℕ} (hN : L*M+1 ≤ N) (hNpos : 0<N)
    (R : Finset ℕ) (hR : R ⊆ Icc 1 N) (hd : N ≤ 2*k*R.card) :
    ∃ t : ℕ, ∃ S : Finset ℕ, S ⊆ range M ∧ M ≤ 4*k*S.card ∧
      ∀ i ∈ S, ∃ x ∈ R, x+L*i=t := by
  classical
  let pairs := R ×ˢ range M
  let total : ℕ × ℕ → ℕ := fun z => z.1+L*z.2
  let T := range (2*N)
  have ht : T.Nonempty := ⟨0, mem_range.mpr (by omega)⟩
  have maps : ∀ z ∈ pairs, total z ∈ T := by
    rintro ⟨x,i⟩ hz
    obtain ⟨hx,hi⟩ := mem_product.mp hz
    have hx' := (mem_Icc.mp (hR hx)).2
    have hi' : L*i ≤ L*M := Nat.mul_le_mul_left L (mem_range.mp hi).le
    exact mem_range.mpr (show x+L*i<2*N by omega)
  let fiber := fun t => pairs.filter (fun z => total z=t)
  obtain ⟨t,_,hmax⟩ := T.exists_max_image (fun t => (fiber t).card) ht
  have bound := card_le_mul_card_image_of_maps_to maps (fiber t).card hmax
  change pairs.card ≤ (fiber t).card * T.card at bound
  simp only [pairs, card_product, card_range,T] at bound
  let S := (fiber t).image Prod.snd
  have hinj : Set.InjOn Prod.snd (↑(fiber t) : Set (ℕ × ℕ)) := by
    rintro ⟨x,i⟩ hx ⟨y,j⟩ hy hij
    change i=j at hij
    subst j
    have ha : x+L*i=t := (mem_filter.mp hx).2
    have hb : y+L*i=t := (mem_filter.mp hy).2
    have : x=y := by omega
    simp [this]
  have hcard : S.card=(fiber t).card := card_image_of_injOn hinj
  have hsize : M ≤ 4*k*S.card := by
    rw [hcard]
    have hp := Nat.mul_le_mul_right M hd
    have hq := Nat.mul_le_mul_left (2*k) bound
    have scaled : N*M ≤ N*(4*k*(fiber t).card) := by nlinarith only [hp,hq]
    exact Nat.le_of_mul_le_mul_left scaled hNpos
  refine ⟨t,S,?_,hsize,?_⟩
  · intro i hi
    obtain ⟨⟨x,j⟩, hz,rfl⟩ := mem_image.mp hi
    exact (mem_product.mp (mem_filter.mp hz).1).2
  · intro i hi
    obtain ⟨⟨x,j⟩, hz,rfl⟩ := mem_image.mp hi
    exact ⟨x,(mem_product.mp (mem_filter.mp hz).1).1,(mem_filter.mp hz).2⟩

private theorem window_free {t L M : ℕ} {S R A : Finset ℕ}
    (hS : S ⊆ range M) (hR : R ⊆ A)
    (hwin : ∀ i ∈ S, ∃ x ∈ R, x+L*i=t)
    (havoid : ∀ h ∈ Icc 1 M, ∀ x ∈ R, x ∉ tripleStarts A (L*h)) :
    ThreeAPFree (↑S : Set ℕ) := by
  have ordered : ∀ i ∈ S, ∀ j ∈ S, ∀ c ∈ S, i<j → i+c=j+j → False := by
    intro i hi j hj c hc hij he
    let h := j-i
    have jh : i+h=j := by dsimp [h]; omega
    have ch : j+h=c := by omega
    have hloc : h ∈ Icc 1 M := by
      have := mem_range.mp (hS hj)
      exact mem_Icc.mpr ⟨by omega,by omega⟩
    obtain ⟨xi,hxi,ei⟩ := hwin i hi
    obtain ⟨xj,hxj,ej⟩ := hwin j hj
    obtain ⟨xc,hxc,ec⟩ := hwin c hc
    have shift1 : xc+L*h=xj := by
      rw [← ch, Nat.mul_add] at ec
      omega
    have shift2 : xj+L*h=xi := by
      rw [← jh, Nat.mul_add] at ej
      omega
    apply havoid h hloc xc hxc
    apply mem_filter.mpr
    exact ⟨hR hxc,shift1 ▸ hR hxj,(show xc+2*(L*h)=xi by omega) ▸ hR hxi⟩
  intro i hi j hj c hc he
  by_contra hn
  rcases lt_or_gt_of_ne hn with h|h
  · exact ordered i hi j hj c hc h he
  · exact ordered c hc j hj i hi (by omega) (by omega)

theorem popular_bounded_step : PopularBound := by
  classical
  intro k hk
  let ε : ℝ := 1/(4*k)
  have hε : 0<ε := by dsimp [ε]; positivity
  let M := cornersTheoremBound (ε/3) + 1
  have hM : 0<M := by dsimp [M]; omega
  let K := 2*k*M
  refine ⟨K,M,by dsimp [K]; positivity,hM,?_⟩
  intro L hL
  refine ⟨L*M+1,?_⟩
  intro N hN A hA hd
  let T := Icc 1 M
  have hnT : T.Nonempty := ⟨1,mem_Icc.mpr ⟨le_rfl,hM⟩⟩
  let starts := fun h => tripleStarts A (L*h)
  obtain ⟨h,hh,hmax⟩ := T.exists_max_image (fun h => (starts h).card) hnT
  have hmem := mem_Icc.mp hh
  refine ⟨L*h,by simpa using Nat.mul_le_mul_left L hmem.1, Nat.mul_le_mul_left L hmem.2,?_⟩
  by_contra! hsmall
  change K*(starts h).card < N at hsmall
  let bad := T.biUnion starts
  let R := A \ bad
  have hbad : bad.card ≤ M*(starts h).card := by
    simpa [bad,T] using card_biUnion_le_card_mul T starts (starts h).card hmax
  have hba : bad ⊆ A := by
    intro x hx
    obtain ⟨u,_,hu⟩ := mem_biUnion.mp hx
    exact tripleStarts_subset A _ hu
  have hsplit : R.card+bad.card=A.card := card_sdiff_add_card_eq_card hba
  have hRd : N ≤ 2*k*R.card := by
    dsimp only [K] at hsmall
    have h' := Nat.mul_le_mul_left k hbad
    have h'' := congrArg (k*·) hsplit
    nlinarith only [hsmall, h',h'',hd]
  have hRA : R ⊆ A := sdiff_subset
  obtain ⟨t,S,hSM,hsize,hwin⟩ := dense_window hN (by omega) R (hRA.trans hA) hRd
  have hfree := window_free hSM hRA hwin (by
    intro u hu x hx hstart
    exact (mem_sdiff.mp hx).2 (mem_biUnion.mpr ⟨u,hu,hstart⟩))
  apply roth_3ap_theorem_nat ε hε (n:=M) (by dsimp [M]; omega) S hSM _ hfree
  dsimp [ε]
  rw [one_div, ← div_eq_inv_mul]
  apply (div_le_iff₀ (by positivity : (0:ℝ)<4*k)).mpr
  exact_mod_cast (show M ≤ S.card*(4*k) by simpa [mul_comm] using hsize)

end OP02.Midpoint

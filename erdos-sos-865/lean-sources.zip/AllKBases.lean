import AllKSpec

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.AllOrders

/-- Realize the specified quarter-root set with all lower odd slots filled,
an empty middle, and a full upper interval. -/
private def prefixWord (J : ℕ) (A : Finset ℕ) : Finset ℕ :=
  ((Icc 1 (4*J)).filter (fun x=> x%2=1 ∨ (x%4=0 ∧ x/4∈A))) ∪
  Ioc (8*J) (16*J)

private theorem prefix_word_data {J : ℕ} {A : Finset ℕ} (hA : A⊆Icc 1 J)
    (hd : DoublingFree A) :
    let B := prefixWord J A
    B⊆Icc 1 (4*(4*J)) ∧ DoublingFree B ∧ quarterD (4*J) B=A ∧ totalBudget (4*J) B=0 := by
  classical
  let B := prefixWord J A
  change B⊆Icc 1 (4*(4*J)) ∧ DoublingFree B ∧ quarterD (4*J) B=A ∧ totalBudget (4*J) B=0
  have hm (x : ℕ) : x∈B ↔
      ((1≤x ∧ x≤4*J) ∧ (x%2=1 ∨ x%4=0 ∧ x/4∈A)) ∨ (8*J<x ∧ x≤16*J) := by
    simp only [B,prefixWord,mem_union,mem_filter,mem_Icc,mem_Ioc]
  have hb : B⊆Icc 1 (4*(4*J)) := by
    intro x hx; have := (hm x).mp hx; apply mem_Icc.mpr; omega
  have df : DoublingFree B := by
    intro x hx h2
    have hx' := (hm x).mp hx
    have h2' := (hm (2*x)).mp h2
    have even : x%4=0 ∧ x/4∈A ∧ (2*x)/4∈A := by
      rcases hx' with ⟨_,h|⟨h,k⟩⟩|h <;>
        rcases h2' with ⟨_,h'|⟨h',k'⟩⟩|h' <;> first | exact ⟨h,k,k'⟩ | omega
    have eq : 2*(x/4)=(2*x)/4 := by omega
    exact hd (x/4) even.2.1 (eq.symm ▸ even.2.2)
  have roots : quarterD (4*J) B = A := by
    ext x
    simp only [quarterD,mem_filter,mem_Icc,hm]
    have hh := @hA x
    constructor
    · rintro ⟨⟨_,up⟩,h⟩
      rcases h with ⟨_,h|⟨_,hx⟩⟩|h
      · omega
      · simpa using hx
      · omega
    · intro hx
      obtain ⟨lo,up⟩ := mem_Icc.mp (hh hx)
      exact ⟨⟨lo,by omega⟩,Or.inl ⟨⟨by omega,by omega⟩,Or.inr ⟨by omega,by simpa using hx⟩⟩⟩
  have odds : ∀x∈oddSlots (4*J),x∈B := by
    intro x hx
    obtain ⟨hi,odd⟩ := mem_filter.mp hx
    exact (hm x).mpr (Or.inl ⟨mem_Icc.mp hi,Or.inl odd⟩)
  have he : emptyPairs (4*J) B = ∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro x hx
    obtain ⟨h,_,miss,_⟩ := mem_filter.mp hx
    exact miss (odds x h)
  have ho : missingTopOdd (4*J) B = ∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro x hx
    obtain ⟨h,_,miss⟩ := mem_filter.mp hx
    exact miss (odds x h)
  have hh : excessHoles (4*J) B = ∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro x hx
    obtain ⟨hi,miss⟩ := mem_sdiff.mp (mem_sdiff.mp hx).1
    obtain ⟨lo,up⟩ := mem_Icc.mp hi
    exact miss ((hm x).mpr (Or.inr ⟨by omega,by omega⟩))
  exact ⟨hb,df,roots,by simp [totalBudget,deficit_split _ _ df,he,ho,hh]⟩


theorem sparse_of_card {F : Finset ℕ} (hc : F.card ≤ 7) : Sparse F := by
  classical
  let U := F.filter (fun x => x%4=1)
  let V := F.filter (fun x => x%4=3)
  have dis : Disjoint U V := by
    apply disjoint_left.mpr
    intro x hx hy
    have := (mem_filter.mp hx).2
    have := (mem_filter.mp hy).2
    omega
  have sub : U ∪ V ⊆ F := union_subset (filter_subset _ _) (filter_subset _ _)
  have count := card_le_card sub
  rw [card_union_of_disjoint dis] at count
  by_cases h : U.card ≤ 3
  · exact ⟨1,Or.inl rfl,h⟩
  · exact ⟨3,Or.inr rfl,show V.card≤3 by omega⟩

theorem shaped_six : Shaped 6 := by
  intro η hη
  obtain ⟨M,hm⟩ := OP02.SharpK8.root_supply_of_dousse5 (OP02.SharpK8.dousse5_of_dousse8 OP02.Midpoint.dousse8) (η/4) (by positivity)
  refine ⟨M,?_⟩
  intro T ht A sub df dense
  obtain ⟨bound,nodbl,roots,free⟩ := prefix_word_data sub df
  have gap : OP02.SharpK8.SignedGap (η/4) (4*T) (prefixWord T A) := by
    unfold OP02.SharpK8.SignedGap
    rw [roots,free]
    norm_num [coeff] at dense ⊢
    linarith
  have h := hm (4*T) (by omega) _ bound nodbl gap
  rw [roots,show 4*T/4=T by omega] at h
  obtain ⟨F,z,card,fresh,clq,above,height,small⟩ := h
  refine ⟨insert z F,z,⟨clq,mem_insert_self _ _,above,?_,?_,sparse_of_card (by rw [clq.2.1]; decide)⟩⟩
  · change 256*z≤192*T
    omega
  · intro x hx ne
    have := small x ((mem_insert.mp hx).resolve_left ne)
    change 256*x≤64*T
    omega

theorem shaped_seven : Shaped 7 := by
  intro η hη
  obtain ⟨M,hm⟩ := OP02.SharpK9.root_seven_supply (η/4) (by positivity)
  refine ⟨M,?_⟩
  intro T ht A sub df dense
  obtain ⟨bound,nodbl,roots,free⟩ := prefix_word_data sub df
  have gap : OP02.SharpK9.SignedGap (η/4) (4*T) (prefixWord T A) := by
    unfold OP02.SharpK9.SignedGap
    rw [roots,free]
    norm_num [coeff] at dense ⊢
    linarith
  have h := hm (4*T) (by omega) _ bound nodbl gap
  rw [roots,show 4*T/4=T by omega] at h
  obtain ⟨F,z,card,fresh,clq,above,height,small⟩ := h
  refine ⟨insert z F,z,⟨clq,mem_insert_self _ _,above,?_,?_,sparse_of_card (by rw [clq.2.1])⟩⟩
  · change 256*z≤192*T
    omega
  · intro x hx ne
    have := small x ((mem_insert.mp hx).resolve_left ne)
    change 256*x≤64*T
    omega

end OP02.AllOrders

import K7MiddleGap
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7

theorem append_clique {B S:Finset ℕ} {p:ℕ} (hs:internalOn B S)
    (hp:p∈B) (hx:∀x∈S,p+x∈B) : internalOn B (insert p S) := by
  refine ⟨insert_subset hp hs.1,?_⟩
  intro x hx' y hy hne
  rcases mem_insert.mp hx' with h|h <;> rcases mem_insert.mp hy with h'|h'
  · exact (hne (h.trans h'.symm)).elim
  · rw [h];exact hx y h'
  · rw [h',Nat.add_comm];exact hx x h
  · exact hs.2 x h y h' hne

theorem missing_gap_multiple {n z:ℕ} {B:Finset ℕ} (hg:MiddleGap7 n B)
    (hz:z%4=0) (ha:z∉B) (hl:2*n+2*(4*(missingTopOdd n B).card+8)<z)
    (hu:z<4*(n-4*(n/16))-2*(4*(missingTopOdd n B).card+8)) : z∈fourResources n B := by
  have hh:z∈holes n B:=mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,ha⟩
  by_cases he:z∈excessHoles n B
  · exact mem_union_right _ (mem_filter.mpr ⟨he,hz⟩)
  · have hi:z∈(middle n B).image (fun x=>2*x):=by by_contra h;exact he (mem_sdiff.mpr ⟨hh,h⟩)
    obtain ⟨x,hx,rfl⟩:=mem_image.mp hi
    have h4:x%4≠0:=fun h=>hg x hx h ⟨by omega,by omega⟩
    exact mem_union_left _ (mem_image.mpr ⟨x,mem_filter.mpr ⟨hx,by omega⟩,rfl⟩)

/-- Historical pivot PV. Only even offsets require the central gap. Odd
offsets can reach n, including for an arbitrary placement in the lower six. -/
theorem pv_six {n:ℕ} {B S:Finset ℕ} (h7:SevenFree B) (hd:DoublingFree B)
    (hg:MiddleGap7 n B) (hn:65536≤n) (hq:256*totalBudget n B≤n)
    (hs:internalOn B S) (hsize:S.card=6) (hmax:∀x∈S,x≤n)
    (he:∀x∈S,x%2=0→x%4=0 ∧ x≤3*(n/4)) : False := by
  classical
  let H:=n/4
  let W:=n-4*(n/16)
  let τ:=4*(missingTopOdd n B).card+8
  let O:=insert 0 S
  let E:=fourResources n B∪Ho n B
  let P:=progression (2*n+2*τ) (4*W-2*τ-3*H-1) 4 0
  have hE:E.card≤totalBudget n B:=(card_union_le _ _).trans (four_resource_budget n B hd)
  have hδ:(missingTopOdd n B).card≤totalBudget n B:=by unfold totalBudget;have :=missingTopOdd_le_deficit n B hd;omega
  have hO:O.card≤7:=by have :=card_insert_le 0 S;dsimp [O];omega
  have hpl:=progression_lower (2*n+2*τ) (4*W-2*τ-3*H-1) 4 0 (by decide) (by decide)
  change _≤P.card at hpl
  have hlong:7*E.card<P.card:=by dsimp only [W,τ,H] at hpl;omega
  have pData {p:ℕ} (hp:p∈P):2*n+2*τ<p ∧ p≤4*W-2*τ-3*H-1 ∧ p%4=0 :=by
    obtain ⟨hi,hr⟩:=mem_filter.mp hp;exact ⟨(mem_Ioc.mp hi).1,(mem_Ioc.mp hi).2,hr⟩
  have cnt:=shift_losses P O B E 1 0 7 (by intro x hx;omega) (by
    intro p hp s hso ha
    have hpd:=pData hp
    have hsN:s≤n:=by rcases mem_insert.mp hso with rfl|hs;omega;exact hmax s hs
    by_cases even:s%2=0
    · have he':s%4=0 ∧ s≤3*H:=by
        rcases mem_insert.mp hso with rfl|hs
        · exact ⟨rfl,by omega⟩
        · exact he s hs even
      apply mem_union_left;apply missing_gap_multiple hg (by omega) ha
      · dsimp only [τ] at hpd;omega
      · dsimp only [τ,H,W] at hpd he';omega
    · apply mem_union_right;apply OP02.SharpK6.bootstrap_missing_odd n _ B (by omega) _ _ ha
      · dsimp only [τ] at hpd;omega
      · dsimp only [τ,H,W] at hpd;omega) (fun z hz=>(card_filter_le _ _).trans hO)
  obtain ⟨p,hp⟩:=card_pos.mp (show 0<(passes P O B).card by omega)
  obtain ⟨hpP,hpx⟩:=mem_filter.mp hp
  have hpB:p∈B:=by simpa using hpx 0 (mem_insert_self 0 S)
  have hno:p∉S:=by intro ha;have h:=hmax p ha;have hh:=pData hpP;omega
  have hcl:=append_clique hs hpB (fun x hx=>hpx x (mem_insert_of_mem hx))
  exact h7 ⟨insert p S,hcl.1,by simp [hno,hsize],hcl.2⟩

end OP02.SharpK7

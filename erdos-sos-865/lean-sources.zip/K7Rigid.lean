import K7Budget
open Finset OP02.SharpK5 OP02.FewHole OP02.SmallExcess
namespace OP02.SharpK7

def rigidOwners (N : ℕ) :=
  canonicalSlots ((3*N+1)/4) \ canonicalSlots (N/2)
def rigidPresent (N : ℕ) (D : Finset ℕ) :=
  (rigidOwners N).filter (fun w => 4*w∈D)

theorem cap_lower_trunc (j t : ℕ) :
    2*t ≤ 3*chainCapacity t + j + 2*(t/4^j) := by
  induction j generalizing t with
  | zero => simp
  | succ j ih =>
    have hi := ih (t/4)
    have hr := canonical_capacity_recurrence t
    have eqd : t/4/4^j = t/4^(j+1) := by
      rw [Nat.div_div_eq_div_mul,pow_succ];congr 1;omega
    rw [eqd] at hi; omega

theorem cap_lower_log (t H : ℕ) (ht : t≤H) : 2*t≤3*chainCapacity t+logLevels H := by
  have hz : t/4^(logLevels H)=0 := Nat.div_eq_of_lt
    (lt_of_le_of_lt ht (Nat.lt_pow_succ_log_self (b:=4) (by decide) H))
  simpa [hz] using cap_lower_trunc (logLevels H) t

theorem rigid_bounds {N w : ℕ} (hw : w∈rigidOwners N) :
    N/2<w ∧ w≤(3*N+1)/4 ∧ canonical w=true := by
  obtain ⟨hi,hn⟩ := mem_sdiff.mp hw
  obtain ⟨hI,hc⟩ := mem_filter.mp hi
  have hp := mem_Icc.mp hI
  refine ⟨?_,hp.2,hc⟩
  by_contra! hbad
  exact hn (mem_filter.mpr ⟨mem_Icc.mpr ⟨hp.1,hbad⟩,hc⟩)

theorem rigid_raw (N H : ℕ) (hNH : N≤H) :
    N ≤ 6*(rigidOwners N).card + 4*logLevels H + 6 := by
  have hsub : canonicalSlots (N/2) ⊆ canonicalSlots ((3*N+1)/4) := by
    intro w hw
    obtain ⟨hi,hc⟩:=mem_filter.mp hw
    have :=mem_Icc.mp hi
    exact mem_filter.mpr ⟨mem_Icc.mpr ⟨this.1,by omega⟩,hc⟩
  have hcards := card_sdiff_add_card_eq_card hsub
  change (rigidOwners N).card+chainCapacity (N/2)=chainCapacity ((3*N+1)/4) at hcards
  have hi := cap_lower_log ((3*N+1)/4) H (by omega)
  have lo := capacity_log_bound (N/2) H (by omega)
  omega

/-- A missing 4w is charged to the even empty class at 4w if its half is
absent. An occupied half instead forces the distinct canonical top w absent. -/
theorem rigid_charge (M : ℕ) (D : Finset ℕ) (hd : DoublingFree D) (hM : 4 ≤ M) :
    (rigidOwners (M/4)).card ≤ (rigidPresent (M/4) D).card +
      ((emptyOuter M D).filter (fun v => v%2=0)).card +
      (topMissing (M/4) (prefixRoots (M/4) D)).card := by
  classical
  let N := M/4
  let P := rigidPresent N D
  let missing := rigidOwners N \ P
  let L := missing.filter (fun w=>2*w∉D)
  let R := missing \ L
  have hfail {w} (hw : w∈missing) : w∈rigidOwners N ∧ 4*w∉D := by
    obtain ⟨h₁,h₂⟩ := mem_sdiff.mp hw
    exact ⟨h₁,fun hp => h₂ (mem_filter.mpr ⟨h₁,hp⟩)⟩
  have hL : L.card ≤ ((emptyOuter M D).filter (fun v=>v%2=0)).card := by
    apply card_le_card_of_injOn (fun w => 4*w)
    · intro w hw
      obtain ⟨hm,ha⟩ := mem_filter.mp hw
      obtain ⟨how,hno⟩ := hfail hm
      have h := rigid_bounds how
      have h2 : 2*w ∈ Ioc (M/4) (2*(M/4)) := by
        apply mem_Ioc.mpr;dsimp [N] at *;omega
      have hc := (pair_empty_iff M (2*w) D h2).mpr ⟨ha,by simpa [← Nat.mul_assoc] using hno⟩
      exact mem_filter.mpr ⟨by simpa [← Nat.mul_assoc] using hc, by dsimp;omega⟩
    · intro x _ y _ h; dsimp at h;omega
  have hR : R ⊆ topMissing N (prefixRoots N D) := by
    intro w hw
    obtain ⟨hm,hL⟩ := mem_sdiff.mp hw
    obtain ⟨ho,hno⟩ := hfail hm
    have h := rigid_bounds ho
    have parent : 2*w∈D := by by_contra hh;exact hL (mem_filter.mpr ⟨hm,hh⟩)
    refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,h.2.2⟩,by omega,?_⟩
    intro hp;exact hd w (mem_inter.mp hp).1 parent
  have h₁ := card_sdiff_add_card_eq_card (filter_subset _ _ : P⊆rigidOwners N)
  change missing.card+P.card=(rigidOwners N).card at h₁
  have h₂ := card_sdiff_add_card_eq_card (filter_subset _ _ : L⊆missing)
  change R.card + L.card = missing.card at h₂
  have h₃ := card_le_card hR
  change (rigidOwners N).card ≤ P.card + _ + (topMissing N (prefixRoots N D)).card
  omega

/-- Actual rigid testers are numerous before selecting the parity of any pair. -/
theorem many_rigid (β : ℝ) (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hpg : (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale : 64≤n/4) (hlarge : 10*(logLevels (n/4):ℝ)+1000≤β*n) :
    lambdaBudget n B + (midOddLoss n B).card <
      (rigidPresent (n/4/64) (quarterD n B)).card := by
  let H := n/4; let N := H/64; let M := H/16; let D := quarterD n B
  have hdD := quarter_doubling_free n B hd
  have hr := rigid_raw N H (by dsimp [N];omega)
  have hcut := rigid_charge M D hdD (by dsimp [M,H];omega)
  have hm : M/4=N := by dsimp [M,N];omega
  rw [hm] at hcut
  have hds : DoublingFree (prefixRoots N D) := fun x hx hx2 =>
    hdD x (mem_inter.mp hx).1 (mem_inter.mp hx2).1
  have htop := chain_capacity_with_top_loss N (prefixRoots N D) inter_subset_right hds
  have hc := canonical_capacity_recurrence N
  have hcap := capacity_log_bound (N/4) H (by dsimp [N];omega)
  have hparts := card_filter_add_card_filter_not (s:=emptyOuter M D) (fun v=>v%2=1)
  have hcpart : ((emptyOuter M D).filter (fun v=>¬v%2=1)) =
      ((emptyOuter M D).filter (fun v=>v%2=0)) := by
    ext v
    simp only [mem_filter]
    have iffMod : (¬v%2=1) ↔ v%2=0 := by omega
    rw [iffMod]
  rw [hcpart] at hparts
  have hl := surplus_lower β n B hd hpg
  have hs : (lambdaBudget n B:ℝ)+(midEmpty n B).card +
      10*logLevels H+996 ≤ (surplus n B:ℝ) := by dsimp [H];linarith
  have hi : lambdaBudget n B + (emptyOuter M D).card + 10*logLevels H+996+
      (N+1)/2 ≤ (prefixRoots N D).card := by
    simp only [surplus,Int.cast_sub,Int.cast_natCast] at hs
    change (lambdaBudget n B:ℝ)+(emptyOuter M D).card+10*logLevels H+996 ≤
      ((prefixRoots N D).card:ℝ)-((N+1)/2:ℕ) at hs
    exact_mod_cast (le_sub_iff_add_le.mp hs)
  change lambdaBudget n B + ((emptyOuter M D).filter (fun v=>v%2=1)).card <
    (rigidPresent N D).card
  omega

end OP02.SharpK7

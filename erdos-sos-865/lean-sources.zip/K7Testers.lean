import K7Retained
import K7Loss
open Finset OP02.SmallExcess OP02.SharpK5 OP02.FewHole
namespace OP02.SharpK7

def oddTestWindow (N : ℕ) :=
  (range (N/2+1)).image (fun i => 2*N+2*i+1)
def evenPairTesters (n a c : ℕ) (B : Finset ℕ) :=
  passes (oddTestWindow (n/4/64)) {0,a,c} (quarterD n B)

theorem oddTestWindow_card (N : ℕ) : (oddTestWindow N).card=N/2+1 := by
  unfold oddTestWindow
  rw [card_image_of_injective _ (by intro i j he; dsimp at he;omega),card_range]

theorem oddTestWindow_mem {N x : ℕ} (hx : x∈oddTestWindow N) :
    2*N<x ∧ x≤3*N+1 ∧ x%2=1 := by
  obtain ⟨i,hi,rfl⟩ := mem_image.mp hx
  have := mem_range.mp hi
  exact ⟨by omega,by omega,by omega⟩

theorem ee_count (n a c : ℕ) (B : Finset ℕ) (ha : 0<a) (hcpos : 0<c) (he : a+c≤n/4/64)
    (hpar : a%2=0 ∧ c%2=0) :
    (n/4/64)/2+1 ≤ (evenPairTesters n a c B).card+3*(midOddLoss n B).card := by
  let N := n/4/64
  have h := shift_losses (oddTestWindow N) {0,a,c} (quarterD n B) (midOddLoss n B)
    1 0 3 (by intro x hx;omega)
    (by
      intro x hx t ht hn
      have hp := oddTestWindow_mem hx
      simp only [mem_insert,mem_singleton] at ht
      rcases ht with rfl|rfl|rfl <;> apply miss_mid_odd _ _ _ hn <;> dsimp [N] at * <;> omega)
    (fun _ _ => (card_filter_le _ _).trans card_le_three)
  simpa only [oddTestWindow_card,evenPairTesters,N] using h

theorem ee_margin (β : ℝ) (n a c : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hpg : (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale : 16≤n/4) (ha : 0<a) (hcpos : 0<c) (he : a+c≤n/4/64) (hpar : a%2=0 ∧ c%2=0) :
    3*(lambdaBudget n B:ℝ)+3*β*n-6*(logLevels (n/4):ℝ) ≤
      (evenPairTesters n a c B).card := by
  have hc := ee_count n a c B ha hcpos he hpar
  have hcr : (((n/4/64)/2:ℕ):ℝ)+1 ≤ (evenPairTesters n a c B).card+
      3*((midOddLoss n B).card:ℝ) := by exact_mod_cast hc
  have hl := surplus_lower β n B hd hpg
  have hu := surplus_upper n B hd
  have hodd : ((midOddLoss n B).card:ℝ)≤(midEmpty n B).card :=
    by exact_mod_cast (card_le_card (filter_subset _ _) : (midOddLoss n B).card ≤ _)
  have hflo : ((n/4/64:ℕ):ℝ) ≤ 2*((n/4/64/2:ℕ):ℝ)+1 :=
    by exact_mod_cast (show n/4/64 ≤ 2*(n/4/64/2)+1 by omega)
  have hj : 2≤Nat.log 4 (n/4) := Nat.le_log_of_pow_le (by decide) (by norm_num;exact hscale)
  have hj' : (3:ℝ)≤logLevels (n/4) := by exact_mod_cast (show 3≤logLevels (n/4) by unfold logLevels;omega)
  linarith only [hl,hu,hcr,hodd,hflo,hj']

theorem rigid_margin (β : ℝ) (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hpg : (85/512+β)*(n:ℝ) ≤ ((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale : 64≤n/4) :
    (lambdaBudget n B:ℝ)+(midOddLoss n B).card+β*n-3*logLevels (n/4) ≤
      (rigidPresent (n/4/64) (quarterD n B)).card := by
  let H := n/4; let N := H/64; let M := H/16; let D := quarterD n B
  have hdD := quarter_doubling_free n B hd
  have hraw := rigid_raw N H (by dsimp [N];omega)
  have hm : M/4=N := by dsimp [M,N];omega
  have hch := rigid_charge M D hdD (by dsimp [M,H];omega)
  rw [hm] at hch
  have hds : DoublingFree (prefixRoots N D) := fun x hx hx2 =>
    hdD x (mem_inter.mp hx).1 (mem_inter.mp hx2).1
  have htop := chain_capacity_with_top_loss N (prefixRoots N D) inter_subset_right hds
  have hc := canonical_capacity_recurrence N
  have hcap := capacity_log_bound (N/4) H (by dsimp [N];omega)
  have hparts := card_filter_add_card_filter_not (s:=emptyOuter M D) (fun v=>v%2=1)
  have hce : ((emptyOuter M D).filter (fun v=>¬v%2=1)) =
      ((emptyOuter M D).filter (fun v=>v%2=0)) := by
    ext v; simp only [mem_filter];rw [show (¬v%2=1) ↔ v%2=0 by omega]
  rw [hce] at hparts
  have hnr : 6*(prefixRoots N D).card + 6*((emptyOuter M D).filter (fun v=>v%2=1)).card ≤
      6*(rigidPresent N D).card + 6*(emptyOuter M D).card + 6*((N+1)/2) + 6*logLevels H + 6 := by omega
  have hR : (6:ℝ)*(prefixRoots N D).card + 6*(midOddLoss n B).card ≤
      6*(rigidPresent N D).card + 6*(midEmpty n B).card + 6*((N+1)/2:ℕ) + 6*logLevels H + 6 := by
    exact_mod_cast hnr
  have hl := surplus_lower β n B hd hpg
  simp only [surplus,Int.cast_sub,Int.cast_natCast] at hl
  change _ ≤ ((prefixRoots N D).card:ℝ)-((N+1)/2:ℕ) at hl
  have hj : 2≤Nat.log 4 H := Nat.le_log_of_pow_le (by decide) (by dsimp [H];omega)
  have hj' : (3:ℝ)≤logLevels H := by exact_mod_cast (show 3≤logLevels H by unfold logLevels;omega)
  change (lambdaBudget n B:ℝ)+(midOddLoss n B).card+β*n-3*logLevels H ≤ (rigidPresent N D).card
  linarith only [hl,hR,hj']

end OP02.SharpK7

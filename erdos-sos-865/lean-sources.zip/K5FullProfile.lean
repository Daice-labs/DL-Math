import K5Profile
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.PositivePivot
set_option maxHeartbeats 6000000

theorem canonical_one_class (T:Finset ℕ) (b:ℕ) (hb:b<4)
    (havoid:∀s∈T,(b+s)%4≠2)
    (he:(T.filter (fun s=>(b+s)%2=0)).card=1) :
    ∃v<8,∀p:ℕ,p%8=v→∀s∈T,canonical (p+s)=true := by
  classical
  obtain ⟨a,ha⟩ := card_eq_one.mp he
  have haE:a∈T.filter (fun s=>(b+s)%2=0) := by rw [ha]; simp
  have haT:=(mem_filter.mp haE).1
  have haeven:=(mem_filter.mp haE).2
  have haa:=havoid a haT
  let v:=(12-a%8)%8
  have hv:v<8 := by dsimp [v]; omega
  have hv4:v%4=b := by dsimp [v]; omega
  have hva:(v+a)%8=4 := by dsimp [v]; omega
  refine ⟨v,hv,?_⟩
  intro p hp s hs
  by_cases hsE:s∈T.filter (fun s=>(b+s)%2=0)
  · have hsa:s=a := by rw [ha] at hsE; exact mem_singleton.mp hsE
    subst s
    apply canonical_four_residue
    omega
  · have hso:(b+s)%2=1 := by
      have hh:¬(b+s)%2=0 := by intro h; exact hsE (mem_filter.mpr ⟨hs,h⟩)
      omega
    exact canonical_odd _ (by omega)

/-- Every candidate pivot is rejected by a physical canonical hole; all
preimages of each hole are counted together. -/
theorem clique_canonical_count (n v m c:ℕ) (B S:Finset ℕ)
    (hf:FiveFree B) (hS:S⊆lower n B) (hc:S.card=4)
    (hp:∀x∈S,∀y∈S,x≠y→x+y∈B)
    (hm:m=4 ∨ m=8 ∨ m=32) (hv : v < m)
    (hcan:∀p:ℕ,p%m=v→∀s∈insert 0 S,canonical (p+s)=true)
    (hload:∀j:ℕ,((insert 0 S).filter (fun s=>s%4=j)).card≤c) :
    n/m≤c*(canonicalHoles n B).card := by
  classical
  let Y:=progression (2*n) (3*n) m v
  have hY (p:ℕ) (hp:p∈Y) : 2*n<p ∧ p≤3*n ∧ p%m=v := by
    obtain ⟨hpI,hpv⟩ := mem_filter.mp hp
    exact ⟨(mem_Ioc.mp hpI).1,(mem_Ioc.mp hpI).2,hpv⟩
  have hcover:∀p∈Y,∃s∈insert 0 S,∃h∈canonicalHoles n B,1*p+s=h+0 := by
    intro p hpY
    have hpI:=hY p hpY
    have hpS:p∉S := by
      intro hh
      have hhI:=mem_Icc.mp (mem_inter.mp (hS hh)).2
      omega
    obtain ⟨s,hs,hbad⟩ := four_clique_missing_label B S hf
      (fun x hx=>(mem_inter.mp (hS hx)).1) hc hp p hpS
    refine ⟨s,hs,p+s,mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,hbad⟩,
      hcan p hpI.2.2 s hs⟩,by omega⟩
    rcases mem_insert.mp hs with rfl|hs
    · omega
    · have hsI:=mem_Icc.mp (mem_inter.mp (hS hs)).2; omega
  have hmod:∀p∈Y,p%4=v%4 := by
    intro p hpY
    have hpv:=(hY p hpY).2.2
    rcases hm with rfl|rfl|rfl <;> omega
  have hb:=affine_cover_bound Y (insert 0 S) (canonicalHoles n B) 0 (v%4) 1 c (by omega) hmod hload hcover
  have hl:=progression_lower (2*n) (3*n) m v hm hv
  change (3*n-2*n)/m≤Y.card at hl
  have he:3*n-2*n=n := by omega
  rw [he] at hl
  exact le_trans hl hb

/-- Full residue profile of every actual lower four-clique, derived solely
from the small canonical-hole budget. -/
theorem full_clique_profile (n:ℕ) (B S:Finset ℕ)
    (hf:FiveFree B) (hS:S⊆lower n B) (hc:S.card=4)
    (hp:∀x∈S,∀y∈S,x≠y→x+y∈B)
    (hbudget:3*(canonicalHoles n B).card<n/32) :
    ∀j<4,∃s∈insert 0 S,s%4=j := by
  classical
  by_contra hn
  push_neg at hn
  have hz:0∉S := by intro hz; have hh:=mem_Icc.mp (mem_inter.mp (hS hz)).2; omega
  obtain ⟨b,hb,havoid,he⟩ := profile_pivot S hc hz hn
  let T:=insert 0 S
  let E:=T.filter (fun s=>(b+s)%2=0)
  let O:=T.filter (fun s=>(b+s)%2=1)
  have hTc:T.card=5 := by simp [T,hz,hc]
  have hpart:E.card+O.card=5 := by
    have hh:T.card=E.card+O.card := by
      apply partition_card
      · intro x
        simp only [E,O,mem_filter]
        constructor
        · intro hx; by_cases h:(b+x)%2=0
          · exact Or.inl ⟨hx,h⟩
          · exact Or.inr ⟨hx,by omega⟩
        · tauto
      · intro x hx hy
        have h0:=(mem_filter.mp hx).2
        have h1:=(mem_filter.mp hy).2
        omega
    omega
  change E.card≤3 at he
  by_cases he0:E.card=0
  · have hcan:∀p:ℕ,p%4=b→∀s∈T,canonical (p+s)=true := by
      intro p hp s hs
      have hh:(b+s)%2=1 := by
        have hE:E=∅ := card_eq_zero.mp he0
        by_contra hn
        have hsE:s∈E := mem_filter.mpr ⟨hs,by omega⟩
        rw [hE] at hsE; simpa using hsE
      exact canonical_odd _ (by omega)
    have hh:=clique_canonical_count n b 4 5 B S hf hS hc hp (by omega) hb hcan
      (fun j=>le_trans (card_le_card (filter_subset _ _)) (le_of_eq hTc))
    omega
  by_cases he1:E.card=1
  · obtain ⟨v,hv,hcan⟩ := canonical_one_class T b hb havoid he1
    have hload:=profile_load T b 4 (by change E.card≤4; omega) (by change O.card≤4; omega)
    have hh:=clique_canonical_count n v 8 4 B S hf hS hc hp (by omega) hv hcan hload
    omega
  · obtain ⟨v,hv,hv4,hcan⟩ := canonical_profile_class T b hb havoid he
    have hload:=profile_load T b 3 (by change E.card≤3; omega) (by change O.card≤3; omega)
    have hh:=clique_canonical_count n v 32 3 B S hf hS hc hp (by omega) hv hcan hload
    omega

#print axioms canonical_one_class
#print axioms clique_canonical_count
#print axioms full_clique_profile
end OP02.SharpK5

import K8RothEndpoint

open Finset Filter OP02.FewHole OP02.SmallExcess OP02.SharpK5

namespace OP02.SharpK9

abbrev Internal := OP02.SharpK8.Internal

def NineFree (B : Finset ℕ) : Prop := ¬ ∃ S, Internal 9 B S

def Dousse9 : Prop :=
  ∀ δ : ℝ, 0 < δ → ∃ N₀ : ℕ, 1 ≤ N₀ ∧ ∀ N : ℕ, N₀ ≤ N →
    ∀ T : Finset ℕ, T ⊆ Icc 1 N → δ * (N : ℝ) ≤ T.card →
    ∃ S ⊆ T, S.card = 9 ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y →
      ∃ z ∈ T, x + y = 2 * z

def SignedGap (β : ℝ) (n : ℕ) (B : Finset ℕ) : Prop :=
  (1365 / 8192 + β) * (n : ℝ) ≤ ((quarterD n B).card : ℝ) - totalBudget n B

def RootSeven (H : ℕ) (D : Finset ℕ) : Prop :=
  ∃ (F : Finset ℕ) (R : ℕ), F.card = 6 ∧ R ∉ F ∧ Internal 7 D (insert R F) ∧
    H < 2*R ∧ 4*R ≤ 3*H ∧ ∀ x ∈ F, 64*x + H ≤ 64*(H/4)

def SmallEvenFive (J : ℕ) (D : Finset ℕ) : Prop :=
  ∃ (F : Finset ℕ) (z : ℕ), F.card = 4 ∧ z ∉ F ∧ Internal 5 D (insert z F) ∧
    (∀ x ∈ insert z F, x%2=0) ∧ J < 2*z ∧ 4*z ≤ 3*J ∧ ∀ x ∈ F, 4*x ≤ J

def InnerFive (h : ℕ) (G : Finset ℕ) : Prop :=
  ∃ (F : Finset ℕ) (P : ℕ), F.card=4 ∧ P ∉ F ∧ Internal 5 G (insert P F) ∧
    h < 2*P ∧ 4*P ≤ 3*h ∧ ∀ x ∈ F, x ≤ h/4

def RootSevenSupply : Prop :=
  ∀ β : ℝ, 0 < β → ∃ M : ℕ, ∀ n : ℕ, M ≤ n → ∀ B : Finset ℕ,
    B ⊆ Icc 1 (4*n) → DoublingFree B → SignedGap β n B →
    RootSeven (n/4) (quarterD n B)

def NormalizedK9Goal : Prop :=
  ∀ β : ℝ, 0 < β → ∃ M : ℕ, ∀ n : ℕ, M ≤ n → ∀ B : Finset ℕ,
    B ⊆ Icc 1 (4*n) → NineFree B → DoublingFree B →
    (B.card : ℝ) < (21845 / 8192 + β) * n + 1/2

def SharpK9Limit : Prop :=
  Tendsto (fun N : ℕ => (Erdos865.f N 9 : ℝ) / N) atTop (nhds (21845 / 32768 : ℝ))

end OP02.SharpK9

import K7CentralPivot
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7
set_option maxHeartbeats 1000000

/-- If p is a potential seventh vertex then at least one of the seven
original shifts fails in the same set. Zero tests p itself. -/
theorem failed_extension {B S:Finset ℕ} {p:ℕ} (hf:SevenFree B)
    (hs:internalOn B S) (hc:S.card=6) (hn:p∉S) :
    ∃x∈insert 0 S,p+x∉B := by
  classical
  by_contra! h
  have hp:p∈B:=by simpa using h 0 (mem_insert_self _ _)
  have hh:=append_clique hs hp (fun x hx=>h x (mem_insert_of_mem hx))
  exact hf ⟨insert p S,hh.1,by simp [hn,hc],hh.2⟩

/-- The target label is 2y and its half is absent. The injective inverse
y = (z+w−x)/2 uses one original slot z and one of the seven offsets x.
This applies to every tested set Y once its range and actual loss map are proved. -/
theorem failed_half_card {n w:ℕ} {B S Y:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hs:internalOn B S) (hc:S.card=6)
    (hn:∀y∈Y,w≤2*y ∧ 2*y-w∉S)
    (hl:∀y∈Y,∀x∈insert 0 S,2*y-w+x∉B →
      2*y-w+x∈OP02.SharpK6.bootstrapResources n B) :
    Y.card≤7*totalBudget n B := by
  let E:=OP02.SharpK6.bootstrapResources n B
  let O:=insert 0 S
  have ho:O.card≤7:=by have :=card_insert_le 0 S;dsimp [O];omega
  have he:E.card≤totalBudget n B:=OP02.SharpK6.bootstrap_resource_budget n B hd
  have hsub:Y⊆(O.product E).image (fun a:ℕ×ℕ=>(a.2+w-a.1)/2):=by
    intro y hy;obtain ⟨hwy,hno⟩:=hn y hy
    obtain ⟨x,hx,hbad⟩:=failed_extension hf hs hc hno
    refine mem_image.mpr ⟨(x,2*y-w+x),mem_product.mpr ⟨hx,hl y hy x hx hbad⟩,?_⟩
    change ((2*y-w+x+w-x)/2)=y;omega
  calc Y.card≤((O.product E).image (fun a:ℕ×ℕ=>(a.2+w-a.1)/2)).card:=card_le_card hsub
       _≤(O.product E).card:=card_image_le
       _=O.card*E.card:=card_product _ _
       _≤7*totalBudget n B:=Nat.mul_le_mul ho he

def twoBandFaults (n w σ:ℕ) (B:Finset ℕ) : Finset ℕ :=
  (Ioc (n+w/2) (n+w/2+n/2)).filter (fun y=>y%4=σ%4 ∧ y∉B)

/-- w and v are the two members of one parity group of the seven offsets,
and are opposite modulo four. All seven tests use a single upper inventory. -/
theorem two_band_faults_le {n w v σ:ℕ} {B S:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hs:internalOn B S) (hc:S.card=6)
    (hr:∀x∈insert 0 S,x≤n) (hw:w∈insert 0 S) (hv:v∈insert 0 S)
    (hclass:∀x∈insert 0 S,x%2=w%2→x=w ∨ x=v)
    (hσ:σ%2=1) (hres:(2*σ+v)%8=(4+w)%8) :
    (twoBandFaults n w σ B).card≤7*totalBudget n B := by
  have hwN:=hr w hw
  apply failed_half_card (w:=w) hf hd hs hc
  · intro y hy;obtain ⟨hi,_⟩:=mem_filter.mp hy;have hh:=mem_Ioc.mp hi
    refine ⟨by omega,?_⟩
    intro hh';have :=hr _ (mem_insert_of_mem hh');omega
  · intro y hy x hx ha
    obtain ⟨hi,hyc,hyB⟩:=mem_filter.mp hy;have hh:=mem_Ioc.mp hi
    have hxN:=hr x hx
    have yo:y%2=1:=by omega
    have hl:2*n<2*y-w+x:=by omega
    have hu:2*y-w+x≤4*n:=by omega
    by_cases hpar:x%2=w%2
    · rcases hclass x hx hpar with rfl|rfl
      · have heq:2*y-x+x=2*y+8*0:=by omega
        rw [heq] at ha hl hu ⊢
        apply mem_union_left;apply mem_union_right
        exact OP02.SharpK6.bootstrap_missing_target n y 0 B yo (by simpa using hyB) hl hu ha
      · apply mem_union_left;apply mem_union_left
        exact OP02.SharpK6.bootstrap_missing_common n _ B (by omega) hl hu ha
    · apply mem_union_right
      exact OP02.SharpK6.bootstrap_missing_odd n _ B (by omega) hl hu ha

end OP02.SharpK7

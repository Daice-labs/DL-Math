import K5RootNeighborhood
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 4000000

/-- One missing high singleton pays for at most one failed root across the two
opposite-residue translations. This is an aggregate, not per-translation, charge. -/
theorem high_odd_edge_capacity (n u v:ℕ) (B:Finset ℕ)
    (hf:FiveFree B) (hd:DoublingFree B)
    (hu:u∈lower n B) (hv:v∈lower n B) (huo:u%2=1) (hvo:v%2=1)
    (huv:u%4≠v%4) (hs:u+v∈B)
    (huL:n<2*u) (hvL:n<2*v)
    (huH:u≤n-4*(n/16)) (hvH:v≤n-4*(n/16))
    (hbudget:3*(canonicalHoles n B).card<n/32) :
    32*(quarterD n B).card≤5*n+32*(missingTopOdd n B).card+52 := by
  classical
  let K:=n/16
  let D:=quarterD n B
  let X:=D.filter (fun x=>x≤K)
  let G:=X.filter (fun x=>u+4*x∈B ∧ v+4*x∈B)
  let F:=X\G
  have hdf := quarter_doubling_free n B hd
  have hG : G⊆Icc 1 K := by
    intro x hx
    obtain ⟨hxX,hgood⟩ := mem_filter.mp hx
    obtain ⟨hxD,hxK⟩ := mem_filter.mp hxX
    have hx1 := (mem_Icc.mp (mem_filter.mp hxD).1).1
    exact mem_Icc.mpr ⟨hx1,hxK⟩
  have hsum : ∀x∈G,∀y∈G,x+y∉G := by
    intro x hx y hy hxy
    obtain ⟨hxX,hxu,hxv⟩ := mem_filter.mp hx
    obtain ⟨hyX,hyu,hyv⟩ := mem_filter.mp hy
    have hxD := (mem_filter.mp hxX).1
    have hyD := (mem_filter.mp hyX).1
    have hxyD := (mem_filter.mp (mem_filter.mp hxy).1).1
    by_cases he:x=y
    · subst y
      apply hdf x hxD
      convert hxyD using 1 <;> omega
    · exact root_neighborhood_independent n u v x y B hf hu hv huo hvo
        (by intro he; exact huv (congrArg (fun z:ℕ=>z%4) he)) hs hxD hyD he hxu hyu hxv hyv hbudget hxyD
  have hgcard := sumfree_card K G hG hsum
  let f:=fun x=>if u+4*x∉B then u+4*x else v+4*x
  have hfcard:F.card≤(missingTopOdd n B).card := by
    apply card_le_card_of_injOn f
    · intro x hx
      obtain ⟨hxX,hxG⟩ := mem_sdiff.mp hx
      obtain ⟨hxD,hxK⟩ := mem_filter.mp hxX
      have hx1 := (mem_Icc.mp (mem_filter.mp hxD).1).1
      have hbad:¬(u+4*x∈B ∧ v+4*x∈B) := by intro hg; exact hxG (mem_filter.mpr ⟨hxX,hg⟩)
      by_cases he:u+4*x∉B
      · simp only [f,if_pos he]
        refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,by omega⟩,by omega,he⟩
        dsimp only [K] at hxK; omega
      · simp only [f,if_neg he]
        have hh:v+4*x∉B := by tauto
        refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,by omega⟩,by omega,hh⟩
        dsimp only [K] at hxK; omega
    · intro x hx y hy he
      dsimp only [f] at he
      split_ifs at he <;> omega
  have hpart:G.card+F.card=X.card := by
    have := card_sdiff_add_card_eq_card (show G⊆X from filter_subset _ _)
    dsimp only [F]; omega
  have hcap := quarter_root_capacity (n/4) K D (by dsimp [K]; omega) (filter_subset _ _) hdf
  change D.card+2*K≤n/4+X.card at hcap
  change 32*D.card≤5*n+32*(missingTopOdd n B).card+52
  dsimp only [K] at hgcard hcap
  omega

/-- Density, not a selected favorable pair, excludes every actual high odd edge
with opposite residues. -/
theorem no_high_odd_edge (n u v:ℕ) (B:Finset ℕ)
    (hf:FiveFree B) (hd:DoublingFree B)
    (hu:u∈lower n B) (hv:v∈lower n B) (huo:u%2=1) (hvo:v%2=1)
    (huv:u%4≠v%4) (huL:n<2*u) (hvL:n<2*v)
    (huH:u≤n-4*(n/16)) (hvH:v≤n-4*(n/16))
    (hbudget:3*(canonicalHoles n B).card<n/32)
    (hdense:5*n+32*totalBudget n B+52<32*(quarterD n B).card) : u+v∉B := by
  intro hs
  have hc := high_odd_edge_capacity n u v B hf hd hu hv huo hvo huv hs huL hvL huH hvH hbudget
  have hdelt := deficit_split n B hd
  unfold totalBudget at hdense
  omega

#print axioms high_odd_edge_capacity
#print axioms no_high_odd_edge
end OP02.SharpK5

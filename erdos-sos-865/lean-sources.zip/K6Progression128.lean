import K5Progressions
open Finset
namespace OP02.SharpK6
open OP02.SharpK5
/-- Exact physical arithmetic-progression count, retaining both endpoint floors. -/
theorem progression128_card (L U m r:ℕ) (hm:m=128) (hr : r < m) :
    (progression L U m r).card=(U+m-r)/m-(L+m-r)/m := by
  classical
  have he : (progression L U m r).card=(Ioc ((L+m-r)/m) ((U+m-r)/m)).card := by
    apply card_bij (fun x _=>(x+m-r)/m)
    · intro x hx
      obtain ⟨hxI,hxr⟩ := mem_filter.mp hx
      obtain ⟨hxL,hxU⟩ := mem_Ioc.mp hxI
      apply mem_Ioc.mpr
      subst m; omega
    · intro x hx y hy hxy
      obtain ⟨hxI,hxr⟩ := mem_filter.mp hx
      obtain ⟨hyI,hyr⟩ := mem_filter.mp hy
      subst m; omega
    · intro j hj
      obtain ⟨hjL,hjU⟩ := mem_Ioc.mp hj
      refine ⟨m*(j-1)+r,?_,?_⟩
      · apply mem_filter.mpr
        refine ⟨mem_Ioc.mpr ⟨?_,?_⟩,?_⟩ <;> (subst m; omega)
      · subst m; omega
  rw [he,Nat.card_Ioc]

theorem progression128_lower (L U m r:ℕ) (hm:m=128) (hr : r < m) :
    (U-L)/m≤(progression L U m r).card := by
  rw [progression128_card L U m r hm hr]
  subst m; omega

theorem progression128_upper (L U m r:ℕ) (hm:m=128) (hr : r < m) :
    (progression L U m r).card≤(U-L)/m+1 := by
  rw [progression128_card L U m r hm hr]
  subst m; omega


#print axioms progression128_card
end OP02.SharpK6

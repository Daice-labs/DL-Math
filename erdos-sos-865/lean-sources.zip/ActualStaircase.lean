import OrderedActual
import PositiveEdges
import ZeroEdgeless
open Finset
namespace OP02.SharpK4
noncomputable section
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot OP02.BothEdges OP02.EdgeBand
set_option maxHeartbeats 2000000

theorem adjacent_actual (S B : Finset ℕ) {i : ℕ} (hi : i ∈ range (S.card-1)) :
    enumActual S i ∈ S ∧ enumActual S (i+1) ∈ S ∧ enumActual S i < enumActual S (i+1) := by
  have hh := mem_range.mp hi
  exact ⟨enumActual_mem S (by omega), enumActual_mem S (by omega), enumActual_strict S (by omega)⟩

theorem bad_zero_bound (n : ℕ) (B : Finset ℕ) :
    (badIndices (middleZero n B) B).card ≤
      ((middle n B).filter (fun x=>x%4=2)).card+(H0 n B).card := by
  classical
  let S := middleZero n B
  let T := (middle n B).filter (fun x=>x%4=2)
  let K := T.image (fun x=>2*x) ∪ H0 n B
  have hb : (badIndices S B).card ≤ K.card := by
    apply bad_indices_bound
    intro i hi
    obtain ⟨hir,hinot⟩ := mem_filter.mp hi
    obtain ⟨hxi,hyi,hxy⟩ := adjacent_actual S B hir
    obtain ⟨hxM,hx4⟩ := mem_filter.mp hxi
    obtain ⟨hyM,hy4⟩ := mem_filter.mp hyi
    have hxr := mem_Icc.mp (mem_inter.mp hxM).2
    have hyr := mem_Icc.mp (mem_inter.mp hyM).2
    rcases missing_split (n:=n) (by omega) hinot with hm|he
    · obtain ⟨v,hv,hve⟩ := hm
      have hvm : v ∈ T := by
        apply mem_filter.mpr
        refine ⟨hv,?_⟩
        by_contra hh
        have hz : v%4=0 := by omega
        have hvS : v∈S := mem_filter.mpr ⟨hv,hz⟩
        exact no_actual_between S (i:=i) hvS (by omega) (by omega)
      exact mem_union_left _ (mem_image.mpr ⟨v,hvm,hve⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨he,by omega⟩)
  have hc := card_union_le (T.image (fun x=>2*x)) (H0 n B)
  have ht := card_image_le (s:=T) (f:=fun x=>2*x)
  dsimp only [K] at hb
  change (badIndices S B).card≤T.card+(H0 n B).card
  omega

theorem bad_odd_class_bound (n r : ℕ) (B : Finset ℕ) (hr : r=1 ∨ r=3) :
    (badIndices (res4 (parityMiddle n B 1) r) B).card ≤
      ((parityMiddle n B 1)\res4 (parityMiddle n B 1) r).card+(H2 n B).card := by
  classical
  let O := parityMiddle n B 1
  let Y := res4 O r
  let I := O\Y
  let K := I.image (fun x=>2*x) ∪ H2 n B
  have hb : (badIndices Y B).card ≤ K.card := by
    apply bad_indices_bound
    intro i hi
    obtain ⟨hir,hinot⟩ := mem_filter.mp hi
    obtain ⟨hxi,hyi,hxy⟩ := adjacent_actual Y B hir
    obtain ⟨hxO,hx4⟩ := mem_filter.mp hxi
    obtain ⟨hyO,hy4⟩ := mem_filter.mp hyi
    have hxM := (mem_filter.mp hxO).1
    have hyM := (mem_filter.mp hyO).1
    have hxr := mem_Icc.mp (mem_inter.mp hxM).2
    have hyr := mem_Icc.mp (mem_inter.mp hyM).2
    rcases missing_split (n:=n) (by rcases hr with hr|hr <;> omega) hinot with hm|he
    · obtain ⟨v,hv,hve⟩ := hm
      have hvi : v∈I := by
        apply mem_sdiff.mpr
        refine ⟨mem_filter.mpr ⟨hv,by rcases hr with hr|hr <;> omega⟩,?_⟩
        intro hvY
        exact no_actual_between Y (i:=i) hvY (by omega) (by omega)
      exact mem_union_left _ (mem_image.mpr ⟨v,hvi,hve⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨he,by rcases hr with hr|hr <;> omega⟩)
  have hc := card_union_le (I.image (fun x=>2*x)) (H2 n B)
  have ht := card_image_le (s:=I) (f:=fun x=>2*x)
  dsimp only [K] at hb
  change (badIndices Y B).card≤I.card+(H2 n B).card
  omega

theorem actual_staircase_cover (n r : ℕ) (B : Finset ℕ) (hf : FourFree B)
    (i : ℕ) (hi : i∈goodIndices (middleZero n B) B)
    (j : ℕ) (hj : j∈goodIndices (res4 (parityMiddle n B 1) r) B) :
    ∃ di : Fin 2, ∃ dj : Fin 2,
      enumActual (middleZero n B) (i+di.val)+
      enumActual (res4 (parityMiddle n B 1) r) (j+dj.val) ∈ Ho n B := by
  classical
  let S := middleZero n B
  let T := res4 (parityMiddle n B 1) r
  obtain ⟨hir,hedge⟩ := mem_filter.mp hi
  obtain ⟨hjr,hedge'⟩ := mem_filter.mp hj
  change i∈range (S.card-1) at hir
  change j∈range (T.card-1) at hjr
  obtain ⟨hx,hy,hxy⟩ := adjacent_actual S B hir
  obtain ⟨hz,hw,hzw⟩ := adjacent_actual T B hjr
  have hxM := (mem_filter.mp hx).1
  have hyM := (mem_filter.mp hy).1
  have hzO := (mem_filter.mp hz).1
  have hwO := (mem_filter.mp hw).1
  have hzM := (mem_filter.mp hzO).1
  have hwM := (mem_filter.mp hwO).1
  have hxp := (mem_filter.mp hx).2
  have hyp := (mem_filter.mp hy).2
  have hzp := (mem_filter.mp hzO).2
  have hwp := (mem_filter.mp hwO).2
  have missing : ∃ di : Fin 2, ∃ dj : Fin 2, enumActual S (i+di.val)+enumActual T (j+dj.val)∉B := by
    by_contra hh
    push_neg at hh
    have h00 := hh 0 0
    have h01 := hh 0 1
    have h10 := hh 1 0
    have h11 := hh 1 1
    simp only [Fin.val_zero, Fin.val_one, Nat.add_zero] at h00 h01 h10 h11
    exact four_forbidden B hf (mem_inter.mp hxM).1 (mem_inter.mp hyM).1
      (mem_inter.mp hzM).1 (mem_inter.mp hwM).1 (by omega) (by omega) (by omega)
      (by omega) (by omega) (by omega) hedge h00 h01 h10 h11 hedge'
  obtain ⟨di,dj,hnot⟩ := missing
  refine ⟨di,dj,?_⟩
  change enumActual S (i+di.val)+enumActual T (j+dj.val) ∈ Ho n B
  have hix : i+di.val < S.card := by have := mem_range.mp hir;have := di.isLt;omega
  have hjx : j+dj.val < T.card := by have := mem_range.mp hjr;have := dj.isLt;omega
  obtain ⟨hXM,hX4⟩ := mem_filter.mp (enumActual_mem S hix)
  obtain ⟨hYO,hYr⟩ := mem_filter.mp (enumActual_mem T hjx)
  obtain ⟨hYM,hY2⟩ := mem_filter.mp hYO
  have hXI := mem_Icc.mp (mem_inter.mp hXM).2
  have hYI := mem_Icc.mp (mem_inter.mp hYM).2
  apply mem_filter.mpr
  refine ⟨?_,by omega⟩
  rcases missing_split (n:=n) (by omega) hnot with hm|he
  · obtain ⟨v,hv,hve⟩ := hm
    omega
  · exact he

theorem actual_staircase_count (n r : ℕ) (B : Finset ℕ) (hf : FourFree B)
    (hr : r=1 ∨ r=3)
    (hx : (goodIndices (middleZero n B) B).Nonempty)
    (hy : (goodIndices (res4 (parityMiddle n B 1) r) B).Nonempty) :
    (middleZero n B).card + (res4 (parityMiddle n B 1) r).card ≤
      4*(Ho n B).card + ((middle n B).filter (fun x=>x%4=2)).card +
      (H0 n B).card + ((parityMiddle n B 1)\res4 (parityMiddle n B 1) r).card +
      (H2 n B).card + 3 := by
  let X := goodIndices (middleZero n B) B
  let Y := goodIndices (res4 (parityMiddle n B 1) r) B
  have hc := staircase_bound (enumActual (middleZero n B))
    (enumActual (res4 (parityMiddle n B 1) r))
    (enumActual_strict _) (enumActual_strict _) X Y (Ho n B) (X.min' hx) (Y.max' hy)
    (min'_mem _ _) (max'_mem _ _) (fun i hi=>min'_le _ _ hi) (fun j hj=>le_max' _ _ hj)
    (actual_staircase_cover n r B hf)
  have hbx := bad_zero_bound n B
  have hby := bad_odd_class_bound n r B hr
  have hpx := indices_partition (middleZero n B) B
  have hpy := indices_partition (res4 (parityMiddle n B 1) r) B
  dsimp only [X,Y] at hc
  omega

#print axioms bad_zero_bound
#print axioms bad_odd_class_bound
#print axioms actual_staircase_cover
#print axioms actual_staircase_count
end
end OP02.SharpK4

import K7DirectPairGeometry
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

def offsetFailures (P O L:Finset ℕ) (f:ℕ→ℕ) := O.biUnion (fun o=>P.filter (fun y=>f y+o∈L))

theorem offset_cost (P O L:Finset ℕ) (f:ℕ→ℕ) (inj:Set.InjOn f ↑P) :
    (offsetFailures P O L f).card ≤ O.card*L.card := by
  have one (o:ℕ): (P.filter (fun y=>f y+o∈L)).card≤L.card:=by
    apply card_le_card_of_injOn (fun y=>f y+o) (fun _ hy=>(mem_filter.mp hy).2)
    intro x hx y hy eq
    exact inj (mem_filter.mp hx).1 (mem_filter.mp hy).1 (Nat.add_right_cancel eq)
  have hh: (offsetFailures P O L f).card≤∑o∈O,(P.filter (fun y=>f y+o∈L)).card :=card_biUnion_le
  exact hh.trans (by simpa using Finset.sum_le_sum (s:=O) (fun o _=>one o))

theorem hit_offset {P O L:Finset ℕ} {f:ℕ→ℕ} {y o:ℕ} (hy:y∈P) (ho:o∈O)
    (bad:f y+o∈L) : y∈offsetFailures P O L f :=
  mem_biUnion.mpr ⟨o,ho,mem_filter.mpr ⟨hy,bad⟩⟩

/-- The odd top is absent as a root or the original slot is empty. -/
theorem absent_top_primitive {n:ℕ} {B:Finset ℕ} (hd:DoublingFree B) :
    (absentTop n B).card≤(oddTopMissing (n/4) (quarterD n B)).card+(emptyPairs n B).card := by
  apply le_trans (card_le_card (t:=oddTopMissing (n/4) (quarterD n B) ∪ emptyPairs n B) _) (card_union_le _ _)
  intro x hx;obtain ⟨xi,xo,absent⟩:=mem_filter.mp hx
  have xx:=mem_Ioc.mp xi
  by_cases hr:x∈quarterD n B
  · apply mem_union_right
    have hw:4*x∈B:=(mem_filter.mp hr).2
    have h2:2*x∉B:=fun h=>hd _ h (by rwa [show 2*(2*x)=4*x by omega])
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,xo⟩,by omega,absent,h2⟩
  · apply mem_union_left
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,xx.2⟩,
      canonical_odd _ xo⟩,by omega,hr⟩,xo⟩

/-- Select a half and all four translated labels of a physical quartet.
The smaller of the two actual odd seed anchors is p. -/
def pairEta (n:ℕ) (B:Finset ℕ) := 20*((oddTopMissing (n/4) (quarterD n B)).card+totalBudget n B)+56

theorem pair_half_selection_fitted {n s p x a c b z:ℕ} {B E:Finset ℕ} (hd:DoublingFree B)
    (hH:64≤n/4) (p₁:p%2=1) (x₁:x%2=1) (opp:p%4≠x%4) (px:p<x)
    (xs:x≤ s) (sH:s≤n/4) (ac:a<c) (cb:c<b) (bz:b<z) (zH:4*z≤n/4)
    (four:E.card≤4) (ev:∀v∈E,v%2=0 ∧ v≤ s)
    (wid:pairEta n B ≤
      halfHi (n/4) s (p/2) b z-halfLo (n/4) (p/2) z) :
    ∃y w:ℕ, y≤halfLo (n/4) (p/2) z+pairEta n B ∧ n/4/2<y ∧ y≤n/4 ∧ y%2=1 ∧ n/2<w ∧ w+s≤n ∧ w%2=1 ∧
      w+p=2*(y+4*z) ∧ w+x∈B ∧ y+4*z∉emptyPairs n B ∧ 2*(y+4*z)≤n ∧
      (∀v∈({0,4*a,4*c,4*b}:Finset ℕ),y+v∈B) ∧ (∀v∈E,w+v∈B) := by
  classical
  let H:=n/4
  let lo:=halfLo H (p/2) z
  let hi:=min (halfHi H s (p/2) b z) (lo+pairEta n B)
  let r:=(6-((x-p)/2)%4)%4
  let P:=progression (lo+3) hi 4 r
  let w (y:ℕ):=2*(y+4*z)-p
  let root (y:ℕ):=(w y+x)/4
  let offs:Finset ℕ:={0,4*a,4*c,4*b}
  let tops:=absentTop n B
  let high:=missingTopOdd n B
  let prim:=oddTopMissing H (quarterD n B)
  let gaps:=emptyPairs n B
  have pR:r<4:=by dsimp [r];omega
  have wid':pairEta n B≤hi-lo:=by have hh:pairEta n B≤halfHi H s (p/2) b z-lo:=wid;dsimp only [hi];unfold pairEta at *;omega
  have bounds {y:ℕ} (hy:y∈P) :
      H/2<y ∧ y+4*b≤H ∧ y%2=1 ∧ 2*H+2<w y ∧ w y+s≤4*H ∧ w y%2=1 ∧
      w y+p=2*(y+4*z) ∧ (w y+x)%8=4 ∧ H/2<root y ∧ root y≤H ∧ 2*(y+4*z)≤n := by
    obtain ⟨ii,rr⟩:=mem_filter.mp hy;have yi:=mem_Ioc.mp ii
    change y%4=r at rr
    exact half_numeric rfl px xs sH bz zH p₁ x₁ opp yi.1 (yi.2.trans (min_le_left _ _)) rr
  have Omax (v:ℕ) (hv:v∈offs): v%2=0 ∧ v≤4*b:=by
    simp only [offs,mem_insert,mem_singleton] at hv;omega
  let bad₀:=offsetFailures P offs tops id
  let bad₁:=offsetFailures P E high w
  let bad₂:=offsetFailures P {0} prim root
  let bad₃:=offsetFailures P {4*z} gaps id
  have c₀:=offset_cost P offs tops id (fun _ _ _ _ h=>h)
  have c₁:=offset_cost P E high w (by intro i hi j hj eq;have a:=(bounds hi).2.2.2.2.2.2.1;have b:=(bounds hj).2.2.2.2.2.2.1;omega)
  have c₂:=offset_cost P {0} prim root (by
    intro i hi j hj eq;have ia:=(bounds hi).2.2.2.2.2.2.1;have ib:=(bounds hi).2.2.2.2.2.2.2.1
    have ja:=(bounds hj).2.2.2.2.2.2.1;have jb:=(bounds hj).2.2.2.2.2.2.2.1
    dsimp only [root] at eq;omega)
  have c₃:=offset_cost P {4*z} gaps id (fun _ _ _ _ h=>h)
  have noff:offs.card≤4:=card_le_four
  have f₀:bad₀.card≤4*tops.card:=c₀.trans (Nat.mul_le_mul_right _ noff)
  have f₁:bad₁.card≤4*high.card:=c₁.trans (Nat.mul_le_mul_right _ four)
  have f₂:bad₂.card≤prim.card:=by simpa [bad₂] using c₂
  have f₃:bad₃.card≤gaps.card:=by simpa [bad₃] using c₃
  have cost:high.card+gaps.card≤totalBudget n B:=by
    have h:=deficit_split n B hd;dsimp only [high,gaps];unfold totalBudget;omega
  have co:prim.card≤chainDeficit n B:=by have :=actual_quarter_top_joint n B hd;dsimp [prim,H];omega
  have ct:tops.card≤prim.card+gaps.card:=absent_top_primitive hd
  have count:=progression_lower (lo+3) hi 4 r (Or.inl rfl) pR
  change _≤P.card at count
  have η:pairEta n B=20*(prim.card+totalBudget n B)+56:=rfl
  have win:bad₀.card+bad₁.card+bad₂.card+bad₃.card<P.card:=by omega
  have choose:∃y∈P,y∉bad₀ ∧ y∉bad₁ ∧ y∉bad₂ ∧ y∉bad₃:=by
    by_contra! no
    have sub:P⊆(bad₀∪bad₁∪bad₂∪bad₃):=by
      intro y hy;by_contra hn
      simp only [mem_union,not_or] at hn
      exact hn.2 (no y hy hn.1.1.1 hn.1.1.2 hn.1.2)
    have h:=card_le_card sub
    have f:=card_union_le (bad₀∪bad₁∪bad₂) bad₃
    have g:=card_union_le (bad₀∪bad₁) bad₂; have i:=card_union_le bad₀ bad₁;omega
  obtain ⟨y,hy,b₀,b₁,b₂,b₃⟩:=choose
  obtain ⟨yl,yu,yo,wl,wu,wo,we,wr,rl,ru,ex⟩:=bounds hy
  have nh:4*H≤n ∧ n≤4*H+3:=by dsimp [H];omega
  have rd:root y∈quarterD n B:=by
    by_contra absent;apply b₂
    apply hit_offset hy (mem_singleton_self 0)
    rw [Nat.add_zero];dsimp only [prim]
    have ro:root y%2=1:=by dsimp only [root];omega
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,ru⟩,
      canonical_odd _ ro⟩,by omega,absent⟩,ro⟩
  have re:w y+x∈B:=by
    have eq:4*root y=w y+x:=by dsimp only [root];omega
    exact eq ▸ (mem_filter.mp rd).2
  have grow:y≤lo+pairEta n B:=(mem_Ioc.mp (mem_filter.mp hy).1).2.trans (min_le_right _ _)
  refine ⟨y,w y,grow,yl,by omega,yo,by omega,by omega,wo,we,re,
    (fun absent=>b₃ (hit_offset hy (mem_singleton_self _) absent)),ex,?_,?_⟩
  · intro v hv
    have ov:=Omax v hv
    by_contra absent;apply b₀
    exact hit_offset hy hv (mem_filter.mpr ⟨mem_Ioc.mpr ⟨by change H/2<y+v;omega,by change y+v≤H;omega⟩,by change (y+v)%2=1;omega,absent⟩)
  · intro v hv
    have ov:=ev v hv
    by_contra absent;apply b₁
    exact hit_offset hy hv (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega,absent⟩)

theorem pair_half_selection {n s p x a c b z:ℕ} {B E:Finset ℕ} (hd:DoublingFree B)
    (hH:64≤n/4) (p₁:p%2=1) (x₁:x%2=1) (opp:p%4≠x%4) (px:p<x)
    (xs:x≤ s) (sH:s≤n/4) (ac:a<c) (cb:c<b) (bz:b<z) (zH:4*z≤n/4)
    (four:E.card≤4) (ev:∀v∈E,v%2=0 ∧ v≤ s)
    (wid:40*chainDeficit n B+32*totalBudget n B+64 ≤
      halfHi (n/4) s (p/2) b z-halfLo (n/4) (p/2) z) :
    ∃y w:ℕ, n/4/2<y ∧ y≤n/4 ∧ y%2=1 ∧ n/2<w ∧ w+s≤n ∧ w%2=1 ∧
      w+p=2*(y+4*z) ∧ w+x∈B ∧ y+4*z∉emptyPairs n B ∧ 2*(y+4*z)≤n ∧
      (∀v∈({0,4*a,4*c,4*b}:Finset ℕ),y+v∈B) ∧ (∀v∈E,w+v∈B) := by
  have bound:=actual_quarter_top_joint n B hd
  have enough:pairEta n B≤halfHi (n/4) s (p/2) b z-halfLo (n/4) (p/2) z:=by unfold pairEta;omega
  obtain ⟨y,w,_,h⟩:=pair_half_selection_fitted hd hH p₁ x₁ opp px xs sH ac cb bz zH four ev enough
  exact ⟨y,w,h⟩

end OP02.SharpK7.LongOddTask

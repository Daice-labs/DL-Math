import K9Spec
import K8Shell

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK9

/-- Realize the specified quarter-root set with all lower odd slots filled,
an empty middle, and a full upper interval. -/
private def prefixWord (J : ℕ) (A : Finset ℕ) : Finset ℕ :=
  ((Icc 1 (4*J)).filter (fun x=> x%2=1 ∨ (x%4=0 ∧ x/4∈A))) ∪
  Ioc (8*J) (16*J)

private theorem prefix_word_data {J : ℕ} {A : Finset ℕ} (hA : A⊆Icc 1 J)
    (hd : DoublingFree A) :
    let B := prefixWord J A
    B⊆Icc 1 (4*(4*J)) ∧ DoublingFree B ∧ quarterD (4*J) B=A ∧ totalBudget (4*J) B=0 := by
  classical
  let B := prefixWord J A
  change B⊆Icc 1 (4*(4*J)) ∧ DoublingFree B ∧ quarterD (4*J) B=A ∧ totalBudget (4*J) B=0
  have hm (x : ℕ) : x∈B ↔
      ((1≤x ∧ x≤4*J) ∧ (x%2=1 ∨ x%4=0 ∧ x/4∈A)) ∨ (8*J<x ∧ x≤16*J) := by
    simp only [B,prefixWord,mem_union,mem_filter,mem_Icc,mem_Ioc]
  have hb : B⊆Icc 1 (4*(4*J)) := by
    intro x hx; have := (hm x).mp hx; apply mem_Icc.mpr; omega
  have df : DoublingFree B := by
    intro x hx h2
    have hx' := (hm x).mp hx
    have h2' := (hm (2*x)).mp h2
    have even : x%4=0 ∧ x/4∈A ∧ (2*x)/4∈A := by
      rcases hx' with ⟨_,h|⟨h,k⟩⟩|h <;>
        rcases h2' with ⟨_,h'|⟨h',k'⟩⟩|h' <;> first | exact ⟨h,k,k'⟩ | omega
    have eq : 2*(x/4)=(2*x)/4 := by omega
    exact hd (x/4) even.2.1 (eq.symm ▸ even.2.2)
  have roots : quarterD (4*J) B = A := by
    ext x
    simp only [quarterD,mem_filter,mem_Icc,hm]
    have hh := @hA x
    constructor
    · rintro ⟨⟨_,up⟩,h⟩
      rcases h with ⟨_,h|⟨_,hx⟩⟩|h
      · omega
      · simpa using hx
      · omega
    · intro hx
      obtain ⟨lo,up⟩ := mem_Icc.mp (hh hx)
      exact ⟨⟨lo,by omega⟩,Or.inl ⟨⟨by omega,by omega⟩,Or.inr ⟨by omega,by simpa using hx⟩⟩⟩
  have odds : ∀x∈oddSlots (4*J),x∈B := by
    intro x hx
    obtain ⟨hi,odd⟩ := mem_filter.mp hx
    exact (hm x).mpr (Or.inl ⟨mem_Icc.mp hi,Or.inl odd⟩)
  have he : emptyPairs (4*J) B = ∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro x hx
    obtain ⟨h,_,miss,_⟩ := mem_filter.mp hx
    exact miss (odds x h)
  have ho : missingTopOdd (4*J) B = ∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro x hx
    obtain ⟨h,_,miss⟩ := mem_filter.mp hx
    exact miss (odds x h)
  have hh : excessHoles (4*J) B = ∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro x hx
    obtain ⟨hi,miss⟩ := mem_sdiff.mp (mem_sdiff.mp hx).1
    obtain ⟨lo,up⟩ := mem_Icc.mp hi
    exact miss ((hm x).mpr (Or.inr ⟨by omega,by omega⟩))
  exact ⟨hb,df,roots,by simp [totalBudget,deficit_split _ _ df,he,ho,hh]⟩

/-- The signed order-nine gap supplies an order-eight rooted six inside the
actual first quarter of D, with its fifteen sums still in that same prefix. -/
theorem outer_seed_six {β : ℝ} (hb : 0<β) :
    ∃M : ℕ, ∀n : ℕ,M≤n → ∀B : Finset ℕ, DoublingFree B → SignedGap β n B →
      OP02.SharpK8.RootSix ((n/4)/4) (quarterD n B∩Icc 1 ((n/4)/4)) := by
  obtain ⟨U,hU⟩ := OP02.SharpK8.root_supply_of_dousse5
    (OP02.SharpK8.dousse5_of_dousse8 OP02.Midpoint.dousse8) (β/2) (by positivity)
  obtain ⟨V,hV⟩ := exists_nat_gt (1/β)
  refine ⟨max (16*(U+1)) V,?_⟩
  intro n hn B df gap
  let H := n/4
  let J := H/4
  let D := quarterD n B
  let A := D∩Icc 1 J
  have subD : D⊆Icc 1 H := filter_subset _ _
  have dfD : DoublingFree D := quarter_doubling_free n B df
  have dfA : DoublingFree A := fun x hx h2 => dfD x (mem_inter.mp hx).1 (mem_inter.mp h2).1
  obtain ⟨subA,dfWord,roots,free⟩ := prefix_word_data (J:=J) (A:=A) inter_subset_right dfA
  have partition := OP02.SharpK8.top_band_cancellation H D subD dfD
  change A.card+(H+1)/2=D.card+_ at partition
  have cardr : (D.card:ℝ)≤A.card+((H+1)/2:ℕ) := by
    exact_mod_cast (show D.card≤A.card+(H+1)/2 by omega)
  have ceil : 2*(((H+1)/2:ℕ):ℝ)≤(H:ℝ)+1 := by exact_mod_cast (show 2*((H+1)/2)≤H+1 by omega)
  have hnH : 4*(H:ℝ)≤n := by exact_mod_cast (show 4*H≤n by dsimp [H]; omega)
  have hHJ : 4*(J:ℝ)≤H := by exact_mod_cast (show 4*J≤H by dsimp [J]; omega)
  have hJn : 4*(J:ℝ)≤n := by exact_mod_cast (show 4*J≤n by dsimp [J,H]; omega)
  have vN : (V:ℝ)≤n := by exact_mod_cast (show V≤n by omega)
  have reserve := (div_lt_iff₀ hb).mp (lt_of_lt_of_le hV vN)
  change (1365/8192+β)*(n:ℝ)≤(D.card:ℝ)-totalBudget n B at gap
  have hg : OP02.SharpK8.SignedGap (β/2) (4*J) (prefixWord J A) := by
    unfold OP02.SharpK8.SignedGap
    rw [roots,free]
    push_cast
    nlinarith only [cardr,ceil,hnH,hHJ,reserve,gap,
      mul_nonneg hb.le (sub_nonneg.mpr hJn),Nat.cast_nonneg (α:=ℝ) (totalBudget n B)]
  have six := hU (4*J) (by dsimp [J,H]; omega) _ subA dfWord hg
  rw [roots,show 4*J/4=J by omega] at six
  exact six

/-- Retain an integer unit of slack before selecting any outer progression. -/
theorem outer_strict_budget {β : ℝ} (hb : 0<β) :
    ∃M : ℕ, ∀n : ℕ,M≤n → ∀B : Finset ℕ,DoublingFree B → SignedGap β n B →
      6144*(chainCapacity (n/4)-(quarterD n B).card+1)<n/4 := by
  obtain ⟨U,hU⟩ := capacity_uniform_error (2*β) (by positivity)
  obtain ⟨V,hV⟩ := exists_nat_gt (2/β)
  refine ⟨max (4*U) V,?_⟩
  intro n hn B hd gap
  let H := n/4
  let D := quarterD n B
  let κ := chainCapacity H-D.card
  have cap := hU H (by dsimp [H]; omega)
  have bound := chain_capacity_with_top_loss H D (filter_subset _ _) (quarter_doubling_free n B hd)
  have eqr : (κ:ℝ)+D.card=chainCapacity H := by
    exact_mod_cast (show κ+D.card=chainCapacity H by dsimp [κ]; omega)
  have hnH : 4*(H:ℝ)≤n := by exact_mod_cast (show 4*H≤n by dsimp [H]; omega)
  have vN : (V:ℝ)≤n := by exact_mod_cast (show V≤n by omega)
  have reserve := (div_lt_iff₀ hb).mp (lt_of_lt_of_le hV vN)
  change (1365/8192+β)*(n:ℝ)≤(D.card:ℝ)-totalBudget n B at gap
  have out : (6144:ℝ)*((κ:ℝ)+1)<H := by
    nlinarith only [cap,eqr,hnH,gap,reserve,mul_nonneg hb.le (sub_nonneg.mpr hnH),
      Nat.cast_nonneg (α:=ℝ) (totalBudget n B)]
  exact_mod_cast out

end OP02.SharpK9

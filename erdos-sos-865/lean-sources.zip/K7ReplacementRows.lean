import K7PhysicalReductions
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

private theorem opposite_not_mono {S:Finset ℕ} {u v:ℕ} (hu:u∈S) (hv:v∈S)
    (uo:u%2=1) (vo:v%2=1) (hop:u%4≠v%4) : ¬sameOdd S := by
  rintro ⟨r,_,_,hh⟩
  exact hop ((hh u hu uo).trans (hh v hv vo).symm)

theorem odd_replacement_in_row14 {n u v h k:ℕ} {B:Finset ℕ}
    (hu:u%2=1) (hv:v%2=1) (hop:u%4≠v%4) (hk:k%2=1)
    (hrep:oddReplacement n u v h k B) :
    ∃S,InternalFive (B∩Icc 1 (n/4)) S ∧ rowNumber n B S=14 := by
  classical
  obtain ⟨x,_,hli,hxo,hmax⟩:=hrep
  let S:Finset ℕ:=insert x {u,v,4*h,2*k}
  have hux:=hmax u (by simp)
  have hvx:=hmax v (by simp)
  have hek:=hmax (2*k) (by simp)
  have heh:=hmax (4*h) (by simp)
  have xo:x%2=1:=by omega
  have hne:x≠u ∧ x≠v ∧ u≠v:=by omega
  have htwo:twoOffsets S={2*k}:=by
    ext a;simp only [twoOffsets,S,mem_filter,mem_insert,mem_singleton];omega
  have hod:oddOffsets S={x,u,v}:=by
    ext a;simp only [oddOffsets,S,mem_filter,mem_insert,mem_singleton];omega
  have ho:(oddOffsets S).card=3:=by simp [hod,hne.1,hne.2.1,hne.2.2]
  have hnm:=opposite_not_mono (S:=S) (by simp [S]:u∈S) (by simp [S]:v∈S) hu hv hop
  have hlarge:largest S=x:=by
    apply le_antisymm
    · apply Finset.sup_le;intro i hi;simp only [S,mem_insert,mem_singleton] at hi;change i≤x;omega
    · exact le_sup (f:=id) (by simp [S]:x∈S)
  have hneq:2*k≠x:=by omega
  have hsups : 2*k≠S.sup id := fun e=>hneq (e.trans hlarge)
  exact ⟨S,hli,by simp [rowNumber,ho,htwo,hnm,largest,hsups]⟩

theorem even_replacement_in_row5 {n u v h k:ℕ} {B:Finset ℕ}
    (hu:u%2=1) (hv:v%2=1) (hop:u%4≠v%4) (hk:k%2=1)
    (hrep:evenReplacement n u v h k B) :
    ∃S,InternalFive (B∩Icc 1 (n/4)) S ∧ rowNumber n B S=5 := by
  classical
  obtain ⟨z,_,hli,hmax⟩:=hrep
  let S:Finset ℕ:=insert (4*z) {u,v,4*h,2*k}
  have hux:=hmax u (by simp)
  have hvx:=hmax v (by simp)
  have hek:=hmax (2*k) (by simp)
  have heh:=hmax (4*h) (by simp)
  have hne:u≠v:=by omega
  have htwo:twoOffsets S={2*k}:=by
    ext a;simp only [twoOffsets,S,mem_filter,mem_insert,mem_singleton];omega
  have hod:oddOffsets S={u,v}:=by
    ext a;simp only [oddOffsets,S,mem_filter,mem_insert,mem_singleton];omega
  have ho:(oddOffsets S).card=2:=by simp [hod,hne]
  have hnm:=opposite_not_mono (S:=S) (by simp [S]:u∈S) (by simp [S]:v∈S) hu hv hop
  have hlarge:largest S=4*z:=by
    apply le_antisymm
    · apply Finset.sup_le;intro i hi;simp only [S,mem_insert,mem_singleton] at hi;change i≤4*z;omega
    · exact le_sup (f:=id) (by simp [S]:4*z∈S)
  have hneq:2*k≠4*z:=by omega
  have hsups : 2*k≠S.sup id := fun e=>hneq (e.trans hlarge)
  exact ⟨S,hli,by simp [rowNumber,ho,htwo,hnm,largest,hsups]⟩

/-- This specific open row would already close the short-odd part of
O2. Its uniform scope is the exact ledger type, not a per-seed oracle. -/
def Common02RowGoal : Prop := RowExclusion 14
def T2SingleTwoRowGoal : Prop := RowExclusion 5

end OP02.SharpK7

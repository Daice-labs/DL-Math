import K9OuterInner
import K9OuterReflection
import K9InnerDensity
import K9DeepPartition
import K9QuartetComplete
import K9ShallowChoice

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7 OP02.SharpK8
namespace OP02.SharpK9

/-- The initial four either omit a residue after adjoining zero or occupy all
four. In the second case an absent singleton target supplies its occupied
half, which closes the alternative four with the same delayed triangle. -/
theorem inner_five_all_classes {h : ℕ} {G T : Finset ℕ}
    (sub : G⊆Icc 1 h) (hd : DoublingFree G) (large : 100000≤h)
    (cap : 384*(chainCapacity h-G.card+1)<h)
    (seed : Internal 4 (G∩Icc 1 (h/4)) T)
    (smallLoss : 6*(shallowFaults h G).card<h/64)
    (tri : DelayedTriangle h (shallowFaults h G).card G) : InnerFive h G := by
  classical
  by_cases missing : ∃j<4,∀s∈insert 0 T,s%4≠j
  · exact inner_five_missing_class sub hd cap seed missing
  have full : ∀j<4,∃x∈insert 0 T,x%4=j := by
    push_neg at missing
    exact missing
  obtain ⟨w₁,w₂,z,wp,wo,zo,ws,zs,delay,e₁,e₂,ez,g₁,g₂,gz,g₁₂,gz₁,gz₂⟩:=tri
  rcases full_class_choice large sub hd smallLoss seed full wp wo zo ws zs delay e₁ e₂ ez with direct|second
  · obtain ⟨p,lo,hi,pass⟩:=direct
    exact inner_five_of_pass seed lo hi pass
  · obtain ⟨v,sv,ov,gv,gv₁,gv₂,gvz⟩:=second
    exact inner_five_reflected sub hd large cap wo (by omega) (by omega) (by omega) sv
      e₁ e₂ ez ov g₁ g₂ gz gv g₁₂ (Nat.add_comm z w₁ ▸ gz₁) (Nat.add_comm v w₁ ▸ gv₁)
      (Nat.add_comm z w₂ ▸ gz₂) (Nat.add_comm v w₂ ▸ gv₂) (Nat.add_comm v z ▸ gvz)

/-- Multiplication by four preserves the five distinct vertices and all ten
sums. The inequalities here use the true floor J/4. -/
theorem small_even_of_inner {J : ℕ} {D : Finset ℕ}
    (h : InnerFive (J/4) (quarterD J D)) : SmallEvenFive J D := by
  classical
  obtain ⟨F,R,card,fresh,clique,lo,hi,small⟩:=h
  have inj : Function.Injective (fun x : ℕ => 4*x) := by
    intro x y e;change 4*x=4*y at e;omega
  let V := F.image (fun x=>4*x)
  have newR : 4*R∉V := by
    intro hR
    obtain ⟨x,hx,eq⟩:=mem_image.mp hR
    exact fresh (inj eq ▸ hx)
  have expand : insert (4*R) V=(insert R F).image (fun x=>4*x) := by simp [V]
  refine ⟨V,4*R,(card_image_of_injective _ inj).trans card,newR,?_,?_,by omega,by omega,?_⟩
  · rw [expand]
    refine ⟨?_,(card_image_of_injective _ inj).trans clique.2.1,?_⟩
    · intro y hy
      obtain ⟨x,xF,rfl⟩:=mem_image.mp hy
      exact (mem_filter.mp (clique.1 xF)).2
    · intro a ha b hb ab
      obtain ⟨x,hx,rfl⟩:=mem_image.mp ha
      obtain ⟨y,hy,rfl⟩:=mem_image.mp hb
      have mem := (mem_filter.mp (clique.2.2 x hx y hy (fun eq => ab (congrArg _ eq)))).2
      simpa only [Nat.mul_add] using mem
  · intro y hy
    rw [expand] at hy
    obtain ⟨x,_,rfl⟩:=mem_image.mp hy
    omega
  · intro y hy
    obtain ⟨x,hx,rfl⟩:=mem_image.mp hy
    have := small x hx
    omega

private theorem delayed_triangle_mono {h s b : ℕ} {G : Finset ℕ} (le : s≤b)
    (tri : DelayedTriangle h b G) : DelayedTriangle h s G := by
  obtain ⟨x,y,z,A,B,C,D,E,delay,rest⟩:=tri
  exact ⟨x,y,z,A,B,C,D,E,by omega,rest⟩

/-- The root geometry supplies seven mutually compatible physical roots under
the signed gap for every sufficiently large original word. -/
theorem root_seven_supply : RootSevenSupply := by
  intro β hb
  obtain ⟨N,hN⟩:=inner_density_supply hb
  obtain ⟨U,hU⟩:=deep_triangle_original_partition (β/2) (by positivity)
  obtain ⟨T,hT⟩:=outer_second_reflection hb
  refine ⟨max (max N T) (64*(max 100000 U+1)),?_⟩
  intro n hn B sub hd gap
  obtain ⟨subG,hdG,density,cap,F,seed⟩:=hN n (by omega) B sub hd gap
  obtain ⟨part,loss,_,delayed⟩:=hU (n/4/4/4) (by omega)
    (quarterD (n/4/4) (quarterD n B)) subG hdG density
  have delay' := delayed_triangle_mono part delayed
  have five:=inner_five_all_classes subG hdG (by omega) cap seed
    ((Nat.mul_le_mul_left 6 part).trans_lt loss) delay'
  exact hT n (by omega) B sub hd gap (small_even_of_inner five)

end OP02.SharpK9

import OP02Spec
import KnownK3
open Finset Filter
open scoped Asymptotics
namespace OP02Candidate
theorem result : (∀ (n : ℕ) (A S : Finset ℕ), S ⊆ Finset.Icc 1 n → (S.card + 1) * ((Finset.Icc (2 * n + 1) (4 * n)) \ A).card < n → ∃ h ∈ A, n < h ∧ ∀ x ∈ S, h + x ∈ A) :=
by
  classical
  intro n A S hS hsmall
  let H : Finset ℕ := Finset.Icc (2 * n + 1) (4 * n) \ A
  let P : Finset ℕ := Finset.Icc (2 * n + 1) (3 * n)
  let U : Finset ℕ := insert 0 S
  have hzero : (0 : ℕ) ∉ S := by
    intro hz
    have hz' := Finset.mem_Icc.mp (hS hz)
    omega
  have hPc : P.card = n := by
    dsimp [P]
    rw [Nat.card_Icc]
    omega
  have hUc : U.card = S.card + 1 := by
    simp [U, hzero]
  by_contra hno
  have hcover : ∀ p ∈ P, ∃ u ∈ U, p + u ∈ H := by
    intro p hp
    have hpI : p ∈ Finset.Icc (2 * n + 1) (3 * n) := hp
    obtain ⟨hp1, hp2⟩ := Finset.mem_Icc.mp hpI
    have hpn : n < p := by omega
    by_cases hpA : p ∈ A
    · by_cases hlink : ∀ x ∈ S, p + x ∈ A
      · exact False.elim (hno ⟨p, hpA, hpn, hlink⟩)
      · push_neg at hlink
        obtain ⟨x, hx, hpx⟩ := hlink
        obtain ⟨hx1, hxn⟩ := Finset.mem_Icc.mp (hS hx)
        refine ⟨x, ?_, ?_⟩
        · simp [U, hx]
        · change p + x ∈ Finset.Icc (2 * n + 1) (4 * n) \ A
          exact Finset.mem_sdiff.mpr ⟨Finset.mem_Icc.mpr ⟨by omega, by omega⟩, hpx⟩
    · refine ⟨0, ?_, ?_⟩
      · simp [U]
      · change p + 0 ∈ Finset.Icc (2 * n + 1) (4 * n) \ A
        simp only [Nat.add_zero]
        exact Finset.mem_sdiff.mpr ⟨Finset.mem_Icc.mpr ⟨by omega, by omega⟩, hpA⟩
  have hsub : P ⊆ (U.product H).image (fun z : ℕ × ℕ => z.2 - z.1) := by
    intro p hp
    obtain ⟨u, hu, hpu⟩ := hcover p hp
    apply Finset.mem_image.mpr
    refine ⟨(u, p + u), Finset.mem_product.mpr ⟨hu, hpu⟩, ?_⟩
    simp
  have hc : P.card ≤ U.card * H.card := by
    calc
      P.card ≤ ((U.product H).image (fun z : ℕ × ℕ => z.2 - z.1)).card := Finset.card_le_card hsub
      _ ≤ (U.product H).card := Finset.card_image_le
      _ = U.card * H.card := by simp
  have hsmall' : (S.card + 1) * H.card < n := hsmall
  rw [hPc, hUc] at hc
  omega
end OP02Candidate

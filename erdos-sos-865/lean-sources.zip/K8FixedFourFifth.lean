import K8Shell
import K8UpperSixTools
import K7CanonicalStar

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK7
namespace OP02.SharpK8

def fifthCeil (H : ℕ) : ℕ := (111*H+1023)/1024
def fifthCap (H : ℕ) : ℕ := H/4-fifthCeil H-2

/-- A missing 4 modulo 8 label either uses its unmatched top or the absent
odd quarter in the next band. Both cases are injected into the original sets. -/
theorem valuation_two_upper_cost (J : ℕ) (D : Finset ℕ) (hd : DoublingFree D) :
    ((Ioc (J/2) J).filter (fun v => v%8=4 ∧ v∉D)).card ≤
      (unmatchedTop J D).card+(unmatchedTop (J/4) D).card := by
  classical
  let M := (Ioc (J/2) J).filter (fun v => v%8=4 ∧ v∉D)
  have cov : M ⊆ unmatchedTop J D ∪ (unmatchedTop (J/4) D).image (fun v => 4*v) := by
    intro y hy
    obtain ⟨hi,h4,ha⟩ := mem_filter.mp hy
    obtain ⟨lo,up⟩ := mem_Ioc.mp hi
    by_cases hh : ∀u∈D, 2*u≠y
    · exact mem_union_left _ (mem_filter.mpr ⟨hi,ha,hh⟩)
    · push Not at hh
      obtain ⟨u,hu,he⟩ := hh
      have eq : 2*(y/4)=u := by omega
      apply mem_union_right
      apply mem_image.mpr
      refine ⟨y/4,mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,?_,?_⟩,by omega⟩
      · intro hg; exact hd _ hg (eq.symm ▸ hu)
      · intro x hx; omega
  have cnt := (card_le_card cov).trans (card_union_le _ _)
  have im := card_image_le (s:=unmatchedTop (J/4) D) (f:=fun v => 4*v)
  change M.card ≤ _
  omega

private def fifthResidues : Finset ℕ :=
  (range 128).filter (fun v => v%2=1 ∨ v%8=4 ∨ v%32=16)

private theorem fifth_residue_count : fifthResidues.card=84 := by decide

/-- For the odd reflected-pair branch, first choose an actual z divisible by
16. The fixed residue supply occupies 21/32 of the possible quotients. -/
theorem choose_odd_pair_fifth {H : ℕ} {D : Finset ℕ}
    (hs : D⊆Icc 1 H) (hd : DoublingFree D) (hscale : 16777216≤H)
    (hκ : 1536*(chainCapacity H-D.card)<H) :
    ∃z∈D, H/4/2 < z ∧ z≤fifthCap H ∧ z%16=0 := by
  classical
  let L := H/4/2/16
  let U := fifthCap H/16
  let P := (Ioc L U).filter (fun u => u%128∈fifthResidues)
  have count := block128_count L U fifthResidues (fun _ h => mem_range.mp (mem_filter.mp h).1)
  change ((U-L)/128)*fifthResidues.card≤P.card at count
  rw [fifth_residue_count] at count
  have can {u} (hh : u%128∈fifthResidues) : canonical (16*u)=true := by
    have eq : 16*u=4*(4*u) := by omega
    rw [eq,canonical_four,canonical_four]
    rcases (mem_filter.mp hh).2 with h|h|h
    · exact canonical_odd _ (by omega)
    · exact canonical_four_residue _ (by omega)
    · rw [show u=4*(u/4) by omega,canonical_four]
      exact canonical_four_residue _ (by omega)
  have loss := band_canonical_holes_le H 1 D hs hd
  change (topMissing (H/4) D).card ≤ _ at loss
  by_contra! bad
  have mapInto : ∀u∈P, 16*u∈topMissing (H/4) D := by
    intro u hu
    obtain ⟨hi,hr⟩ := mem_filter.mp hu
    obtain ⟨lo,up⟩ := mem_Ioc.mp hi
    dsimp [L] at lo; dsimp [U] at up
    have upper : fifthCap H≤H/4 := by dsimp [fifthCap]; omega
    refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,can hr⟩,by omega,?_⟩
    intro hx
    exact bad (16*u) hx (by omega) (by omega) (by omega)
  have bound := card_le_card_of_injOn (s:=P) (t:=topMissing (H/4) D)
    (fun u:ℕ =>16*u) mapInto (by intro a ha b hb hh; change 16*a=16*b at hh; omega)
  dsimp [U,L,fifthCap,fifthCeil] at count
  omega

/-- In an even reflected pair, the fifth can wait until the two odd gap
roots have been chosen. All five contacts are charged to one canonical top set. -/
theorem choose_even_pair_fifth {H a b g₁ g₂ : ℕ} {D : Finset ℕ}
    (hs : D⊆Icc 1 H) (hd : DoublingFree D) (hscale : 16777216≤H)
    (hκ : 1536*(chainCapacity H-D.card)<H)
    (ha : a%2=0) (hb : b%2=0) (hab : a≤b) (hsz : b≤H/256)
    (ho₁ : g₁%2=1) (ho₂ : g₂%2=1)
    (hg₁ : g₁≤fifthCeil H+2) (hg₂ : g₂≤fifthCeil H+2) :
    ∃ z∈D, H/4/2<z ∧ z≤fifthCap H ∧ z%8=4 ∧
      z+4*a∈D ∧ z+4*b∈D ∧ z+g₁∈D ∧ z+g₂∈D := by
  classical
  let Y := progression (H/4/2) (fifthCap H) 8 4
  let O : Finset ℕ := {0,4*a,4*b,g₁,g₂}
  let E := topMissing (H/4) D
  have hY {z} (hz : z∈Y) : H/4/2 < z ∧ z≤fifthCap H ∧ z%8=4 := by
    obtain ⟨hI,hr⟩ := mem_filter.mp hz
    exact ⟨(mem_Ioc.mp hI).1,(mem_Ioc.mp hI).2,hr⟩
  have cnt := shift_losses Y O D E 8 4 3 (fun _ h => (hY h).2.2) (by
    intro z hz s hsO hm
    have ⟨lo,up,hres⟩ := hY hz
    have hI : z+s≤H/4 := by
      simp only [O,mem_insert,mem_singleton] at hsO
      dsimp [fifthCap,fifthCeil] at up hg₁ hg₂
      omega
    have c : canonical (z+s)=true := by
      simp only [O,mem_insert,mem_singleton] at hsO
      rcases hsO with h|h|h|h|h
      · exact canonical_four_residue _ (by omega)
      · exact canonical_four_residue _ (by omega)
      · exact canonical_four_residue _ (by omega)
      · exact canonical_odd _ (by omega)
      · exact canonical_odd _ (by omega)
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hI⟩,c⟩,by omega,hm⟩) (by
    intro t ht
    by_cases ho : t%2=1
    · apply (card_le_card (t:={g₁,g₂}) _).trans (card_le_two.trans (by decide))
      intro s hsO
      obtain ⟨hm,he⟩ := mem_filter.mp hsO
      simp only [O,mem_insert,mem_singleton] at hm ⊢; omega
    · apply (card_le_card (t:={0,4*a,4*b}) _).trans card_le_three
      intro s hsO
      obtain ⟨hm,he⟩ := mem_filter.mp hsO
      simp only [O,mem_insert,mem_singleton] at hm ⊢; omega)
  have loss := band_canonical_holes_le H 1 D hs hd
  change E.card ≤ _ at loss
  have width := progression_lower (H/4/2) (fifthCap H) 8 4 (by decide) (by decide)
  change _≤Y.card at width
  dsimp [fifthCap,fifthCeil] at width
  obtain ⟨z,hz⟩ := card_pos.mp (show 0<(passes Y O D).card by omega)
  obtain ⟨hy,hq⟩ := mem_filter.mp hz
  obtain ⟨h1,h2,h3⟩ := hY hy
  exact ⟨z,by simpa using hq 0 (by simp [O]),h1,h2,h3,
    hq _ (by simp [O]),hq _ (by simp [O]),hq _ (by simp [O]),hq _ (by simp [O])⟩

end OP02.SharpK8

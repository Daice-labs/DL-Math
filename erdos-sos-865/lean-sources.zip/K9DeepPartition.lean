import K9DeepDensity

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK7 OP02.SharpK8
namespace OP02.SharpK9

/-- Precisely those nodes whose primitive odd head is above floor(h/8). -/
def shortChainNode (h x : ℕ) : Prop :=
  (x%2=1 ∧ h/8<x) ∨ (x%4=2 ∧ h/8<x/2) ∨ (x%8=4 ∧ h/8<x/4)

instance (h x : ℕ) : Decidable (shortChainNode h x) := by unfold shortChainNode; infer_instance

theorem shortChainNode_iff_head {h x : ℕ} (up : x≤h) :
    shortChainNode h x ↔ ∃ a k : ℕ, a%2=1 ∧ h/8<a ∧ x=2^k*a := by
  constructor
  · rintro (⟨odd,hi⟩|⟨two,hi⟩|⟨four,hi⟩)
    · exact ⟨x,0,odd,hi,by simp⟩
    · exact ⟨x/2,1,by omega,hi,by norm_num; omega⟩
    · exact ⟨x/4,2,by omega,hi,by norm_num; omega⟩
  · rintro ⟨a,k,odd,hi,eq⟩
    rcases k with _|k
    · norm_num at eq
      exact Or.inl ⟨by omega,by omega⟩
    rcases k with _|k
    · norm_num at eq
      exact Or.inr (Or.inl ⟨by omega,by omega⟩)
    rcases k with _|k
    · norm_num at eq
      exact Or.inr (Or.inr ⟨by omega,by omega⟩)
    · have prod : a≤2^k*a := by
        have pp : 0<(2:ℕ)^k := by positivity
        simpa only [one_mul] using Nat.mul_le_mul_right a (show 1≤2^k by omega)
      simp only [pow_succ] at eq
      have : 8*a≤x := by nlinarith only [eq,prod]
      omega

def shallowChainDeficit (h : ℕ) (G : Finset ℕ) :=
  ((canonicalSlots h).filter (shortChainNode h)).card-(G.filter (shortChainNode h)).card

private theorem short_compress {h x : ℕ} (pos : 0<x) (up : x≤h) :
    shortChainNode h (chainCompress x) ↔ shortChainNode h x := by
  unfold chainCompress
  split_ifs with can
  · rfl
  · have no : canonical x=false := by cases s : canonical x <;> simp_all
    have eq := (canonical_false_parent x pos no).1
    unfold shortChainNode
    omega

private theorem short_terminal {h x : ℕ} (up : x≤h) :
    shortChainNode h x ↔ h/2<lastPosition h x ∧ lastPosition h x≤h ∧ lastPosition h x%8≠0 := by
  unfold shortChainNode lastPosition
  split_ifs <;> omega

private theorem restricted_capacity {h : ℕ} {G : Finset ℕ} (sub : G⊆Icc 1 h) (hd : DoublingFree G)
    (p : ℕ → Prop) [DecidablePred p] (invar : ∀ x∈G, p x → p (chainCompress x)) :
    (G.filter p).card≤((canonicalSlots h).filter p).card := by
  apply card_le_card_of_injOn chainCompress
  · intro x hx
    obtain ⟨xG,where'⟩ := mem_filter.mp hx
    exact mem_filter.mpr ⟨chain_compression_mem h G sub xG,invar x xG where'⟩
  · intro x hx y hy eq
    exact chain_compression_injective h G sub hd (mem_filter.mp hx).1 (mem_filter.mp hy).1 eq

theorem shallow_capacity_attained (h : ℕ) :
    let A := (canonicalSlots h).filter (shortChainNode h)
    DoublingFree A ∧ ∀ X : Finset ℕ, X⊆(Icc 1 h).filter (shortChainNode h) →
      DoublingFree X → X.card≤A.card := by
  dsimp only
  constructor
  · intro x hx present
    obtain ⟨xi,xc⟩ := mem_filter.mp (mem_filter.mp hx).1
    have dc := (mem_filter.mp (mem_filter.mp present).1).2
    rw [canonical_double _ (mem_Icc.mp xi).1,xc] at dc
    contradiction
  · intro X sub hd
    have actual : X⊆Icc 1 h := fun x hx => (mem_filter.mp (sub hx)).1
    have eq : X.filter (shortChainNode h)=X := filter_eq_self.mpr (fun x hx => (mem_filter.mp (sub hx)).2)
    have bound := restricted_capacity actual hd (shortChainNode h) (by
      intro x xG sh
      exact (short_compress (mem_Icc.mp (actual xG)).1 (mem_Icc.mp (actual xG)).2).mpr sh)
    rwa [eq] at bound

def deepChainDeficit (h : ℕ) (G : Finset ℕ) :=
  ((canonicalSlots h).filter (fun x => ¬shortChainNode h x)).card-(G.filter (fun x => ¬shortChainNode h x)).card

theorem deficits_partition_exact {h : ℕ} {G : Finset ℕ} (sub : G⊆Icc 1 h) (hd : DoublingFree G) :
    shallowChainDeficit h G+deepChainDeficit h G=chainCapacity h-G.card := by
  classical
  have split (X : Finset ℕ) :
      (X.filter (shortChainNode h)).card+(X.filter (fun x => ¬shortChainNode h x)).card=X.card := by
    have dis : Disjoint (X.filter (shortChainNode h)) (X.filter (fun x => ¬shortChainNode h x)) :=
      disjoint_left.mpr (fun _ h1 h2 => (mem_filter.mp h2).2 (mem_filter.mp h1).2)
    rw [←card_union_of_disjoint dis]
    congr 1; ext x; simp only [mem_union,mem_filter]; tauto
  have invar (x : ℕ) (hx : x∈G) := short_compress (mem_Icc.mp (sub hx)).1 (mem_Icc.mp (sub hx)).2
  have a := restricted_capacity sub hd (shortChainNode h) (fun x hx hh => (invar x hx).mpr hh)
  have b := restricted_capacity sub hd (fun x => ¬shortChainNode h x) (fun x hx hh sh => hh ((invar x hx).mp sh))
  have whole := split (canonicalSlots h)
  have actual := split G
  unfold shallowChainDeficit deepChainDeficit chainCapacity
  omega

/-- Cardinal equality for the literal shallow side of the original deficit partition. -/
theorem short_unused_exact {h : ℕ} {G : Finset ℕ} (sub : G⊆Icc 1 h) (hd : DoublingFree G) :
    ((unusedSlots h G).filter (shortChainNode h)).card=shallowChainDeficit h G := by
  classical
  let V := (canonicalSlots h).filter (shortChainNode h)
  let S := G.filter (shortChainNode h)
  let I := S.image chainCompress
  have on (x : ℕ) (hx : x∈G) : shortChainNode h (chainCompress x) ↔ shortChainNode h x :=
    short_compress (mem_Icc.mp (sub hx)).1 (mem_Icc.mp (sub hx)).2
  have restrict {v} (short : shortChainNode h v) : v∈G.image chainCompress ↔ v∈I := by
    constructor
    · intro hv
      obtain ⟨x,hx,eq⟩ := mem_image.mp hv
      exact mem_image.mpr ⟨x,mem_filter.mpr ⟨hx,(on x hx).mp (eq.symm ▸ short)⟩,eq⟩
    · intro hv
      obtain ⟨x,hx,eq⟩ := mem_image.mp hv
      exact mem_image.mpr ⟨x,(mem_filter.mp hx).1,eq⟩
  have inside : I⊆V := by
    intro v hv
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hv
    obtain ⟨xG,xs⟩ := mem_filter.mp hx
    exact mem_filter.mpr ⟨chain_compression_mem h G sub xG,(on x xG).mpr xs⟩
  have eq : (unusedSlots h G).filter (shortChainNode h)=V\I := by
    ext v
    constructor
    · intro hv
      obtain ⟨un,short⟩ := mem_filter.mp hv
      obtain ⟨slot,noimage⟩ := mem_sdiff.mp un
      exact mem_sdiff.mpr ⟨mem_filter.mpr ⟨slot,short⟩,fun hh=>noimage ((restrict short).mpr hh)⟩
    · intro hv
      obtain ⟨inV,notI⟩ := mem_sdiff.mp hv
      obtain ⟨slot,short⟩ := mem_filter.mp inV
      exact mem_filter.mpr ⟨mem_sdiff.mpr ⟨slot,fun hh=>notI ((restrict short).mp hh)⟩,short⟩
  have same : I.card = S.card := by
    apply card_image_of_injOn
    intro x hx y hy eq
    exact chain_compression_injective h G sub hd (mem_filter.mp hx).1 (mem_filter.mp hy).1 eq
  have counted := card_sdiff_add_card_eq_card inside
  rw [eq]
  change (V\I).card=V.card-S.card
  omega

/-- Both projected physical fault sets are paid inside their original side. The
shallow budget is capacity minus occupancy on *all* chains of odd head above h/8. -/
theorem original_partition {h : ℕ} {G : Finset ℕ} (sub : G⊆Icc 1 h) (hd : DoublingFree G) :
    (shallowFaults h G).card ≤ shallowChainDeficit h G ∧
    shallowChainDeficit h G+(deepFaults h G).card≤chainCapacity h-G.card := by
  classical
  let U := unusedSlots h G
  let S := U.filter (shortChainNode h)
  have sEq : S.card = shallowChainDeficit h G := short_unused_exact sub hd
  have uTop {v} (uv : v∈U) : v≤h := (mem_Icc.mp (mem_filter.mp (mem_sdiff.mp uv).1).1).2
  have shallow : shallowFaults h G⊆S.image (lastPosition h) := by
    intro t ht
    obtain ⟨htP,hs⟩ := mem_filter.mp ht
    obtain ⟨inImage,top⟩ := mem_inter.mp htP
    obtain ⟨v,hv,eq⟩ := mem_image.mp inImage
    obtain ⟨lo,up⟩ := mem_Ioc.mp top
    exact mem_image.mpr ⟨v,mem_filter.mpr ⟨hv,(short_terminal (uTop hv)).mpr (eq.symm ▸ ⟨lo,up,hs⟩)⟩,eq⟩
  have deep : deepFaults h G⊆(U\S).image (lastPosition h) := by
    intro t ht
    obtain ⟨htP,ds⟩ := mem_filter.mp ht
    obtain ⟨inImage,_⟩ := mem_inter.mp htP
    obtain ⟨v,hv,eq⟩ := mem_image.mp inImage
    refine mem_image.mpr ⟨v,mem_sdiff.mpr ⟨hv,?_⟩,eq⟩
    intro vs
    have mod := ((short_terminal (uTop hv)).mp (mem_filter.mp vs).2).2.2
    exact mod (eq.symm ▸ ds)
  have sBound : (shallowFaults h G).card≤S.card := (card_le_card shallow).trans card_image_le
  have dBound : (deepFaults h G).card≤(U\S).card := (card_le_card deep).trans card_image_le
  have part := card_sdiff_add_card_eq_card (filter_subset (shortChainNode h) U)
  change (U\S).card+S.card=U.card at part
  have into : G.image chainCompress⊆canonicalSlots h := by
    intro x hx
    obtain ⟨v,hv,rfl⟩ := mem_image.mp hx
    exact chain_compression_mem h G sub hv
  have total := card_sdiff_add_card_eq_card into
  rw [card_image_of_injOn (chain_compression_injective h G sub hd)] at total
  change U.card+G.card=chainCapacity h at total
  omega

theorem deep_triangle_original_partition (ε : ℝ) (he : 0<ε) :
    ∃ M : ℕ, ∀ h : ℕ, M≤h → ∀ G : Finset ℕ, G⊆Icc 1 h → DoublingFree G →
      (85/128+ε)*(h:ℝ) ≤ G.card →
      (shallowFaults h G).card ≤ shallowChainDeficit h G ∧
      6*shallowChainDeficit h G<h/64 ∧ 384*(chainCapacity h-G.card)<h ∧
        DelayedTriangle h (shallowChainDeficit h G) G := by
  obtain ⟨M,supply⟩ := deep_triangle_for_reserve ε he
  refine ⟨M,?_⟩
  intro h large G sub hd den
  obtain ⟨shallow,deep⟩ := original_partition sub hd
  exact ⟨shallow,supply h large G sub hd den _ deep⟩

#print axioms shortChainNode_iff_head
#print axioms shallow_capacity_attained
#print axioms deficits_partition_exact
#print axioms original_partition
#print axioms deep_triangle_original_partition

end OP02.SharpK9

import K7CertifiedEndpoint

open Finset Filter
namespace OP02.SharpK8

def Internal (j : ℕ) (B S : Finset ℕ) : Prop :=
  S ⊆ B ∧ S.card = j ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ B

def EightFree (B : Finset ℕ) : Prop := ¬ ∃ S, Internal 8 B S

def Dousse8 : Prop :=
  ∀ δ : ℝ, 0 < δ → ∃ N₀ : ℕ, 1 ≤ N₀ ∧ ∀ N : ℕ, N₀ ≤ N →
    ∀ T : Finset ℕ, T ⊆ Icc 1 N → δ * (N : ℝ) ≤ T.card →
    ∃ S ⊆ T, S.card = 8 ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y →
      ∃ z ∈ T, x + y = 2 * z

def SignedGap (β : ℝ) (n : ℕ) (B : Finset ℕ) : Prop :=
  (341 / 2048 + β) * (n : ℝ) ≤
    ((OP02.SmallExcess.quarterD n B).card : ℝ) - OP02.SharpK5.totalBudget n B

def AllProfileLift : Prop :=
  ∀ β : ℝ, 0 < β → ∃ N₀ : ℕ, ∀ n : ℕ, N₀ ≤ n →
    ∀ B : Finset ℕ, B ⊆ Icc 1 (4*n) → OP02.FewHole.DoublingFree B →
    SignedGap β n B → ∀ S : Finset ℕ, Internal 7 (B ∩ Icc 1 n) S →
    ∃ W, Internal 8 B W

def NormalizedK8Goal : Prop :=
  ∀ β : ℝ, 0 < β → ∃ N₀ : ℕ, ∀ n : ℕ, N₀ ≤ n →
    ∀ B : Finset ℕ, B ⊆ Icc 1 (4*n) → EightFree B → OP02.FewHole.DoublingFree B →
    (B.card : ℝ) < (5461 / 2048 + β) * (n : ℝ) + 1 / 2

def SharpK8Limit : Prop :=
  Tendsto (fun N : ℕ => (Erdos865.f N 8 : ℝ) / N) atTop (nhds (5461 / 8192 : ℝ))

theorem dousse7_of_dousse8 (h : Dousse8) : OP02.SharpK7.Dousse7 := by
  intro δ hδ
  obtain ⟨N₀,hN₀,ht⟩ := h δ hδ
  refine ⟨N₀,hN₀,?_⟩
  intro N hN T hT hd
  obtain ⟨S,hST,hSc,hm⟩ := ht N hN T hT hd
  obtain ⟨U,hUS,hUc⟩ := exists_subset_card_eq (show 7 ≤ S.card by omega)
  exact ⟨U,Subset.trans hUS hST,hUc,fun x hx y hy hxy => hm x (hUS hx) y (hUS hy) hxy⟩

theorem dousse5_of_dousse8 (h : Dousse8) : OP02.SharpK5.Dousse5 :=
  OP02.SharpK7.dousse5_of_seven (dousse7_of_dousse8 h)

end OP02.SharpK8

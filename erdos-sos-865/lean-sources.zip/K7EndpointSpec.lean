import K6Complete

open Finset Filter

namespace OP02.SharpK7

def SevenFree (B : Finset ℕ) : Prop :=
  ¬ ∃ S ⊆ B, S.card = 7 ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ B

/-- External mathematical premise, in the convention of the retained Dousse6. -/
def Dousse7 : Prop :=
  ∀ δ : ℝ, 0 < δ → ∃ N₀ : ℕ, 1 ≤ N₀ ∧ ∀ X : ℕ, N₀ ≤ X →
    ∀ T : Finset ℕ, T ⊆ Icc 1 X → δ * (X : ℝ) ≤ (T.card : ℝ) →
    ∃ S ⊆ T, S.card = 7 ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y →
      ∃ z ∈ T, x + y = 2 * z

def InternalFive (C S : Finset ℕ) : Prop :=
  S.card = 5 ∧ S ⊆ C ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ C

def ActualO2Seed (H : ℕ) (C : Finset ℕ) : Prop :=
  ∃ u v h k l : ℕ,
    Odd u ∧ Odd v ∧ u % 4 ≠ v % 4 ∧ 0 < h ∧ Odd k ∧ Odd l ∧
    k < l ∧ 2 * H < 3 * (2 * l) ∧
    InternalFive C {u, v, 4 * h, 2 * k, 2 * l}

/-- Outer threshold is chosen before n, B and the seed. -/
def ActualO2Goal : Prop :=
  ∀ β : ℝ, 0 < β → ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n →
    ∀ B : Finset ℕ, B ⊆ Icc 1 (4 * n) →
    SevenFree B → OP02.FewHole.DoublingFree B →
    (85 / 512 + β) * (n : ℝ) ≤
      ((OP02.SmallExcess.quarterD n B).card : ℝ) -
        (OP02.SharpK5.totalBudget n B : ℝ) →
    ActualO2Seed (n / 4) (B ∩ Icc 1 (n / 4)) →
    β * (n : ℝ) + (OP02.SharpK5.totalBudget n B : ℝ) ≤
      (3 / 2 : ℝ) * (Real.log ((n / 4 : ℕ) : ℝ) / Real.log 2) + 1

def NormalizedK7Goal : Prop :=
  ∀ β : ℝ, 0 < β → ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n →
    ∀ B : Finset ℕ, B ⊆ Icc 1 (4 * n) →
    SevenFree B → OP02.FewHole.DoublingFree B →
    (B.card : ℝ) < (1365 / 512 + β) * (n : ℝ) + 1 / 2

def SharpK7Limit : Prop :=
  Tendsto (fun X : ℕ => (Erdos865.f X 7 : ℝ) / (X : ℝ)) atTop
    (nhds (1365 / 2048 : ℝ))

end OP02.SharpK7


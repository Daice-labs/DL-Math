import K6SecondResidues
import K6SecondArithmetic
open Finset Erdos865
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 300000

/-- The partial gap turns the sole noncanonical even label into excess.
Canonical failures and this exceptional class retain their distinct loads. -/
theorem no_high_opposite_edge6 (β:ℝ) (n u v:ℕ) (B:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hgap:PositiveGap6 β n B)
    (hn:65536≤n) (hbn:(10:ℝ)≤β*n)
    (hcap:384*(chainDeficit n B+totalBudget n B)≤n)
    (hbudget:3*(canonicalHoles n B).card<n/128)
    (hu:u∈lower n B) (hv:v∈lower n B)
    (huo:u%2=1) (hvo:v%2=1) (hopp:u%4≠v%4)
    (huL:n<2*u) (hvL:n<2*v)
    (huH:u≤n-4*(n/16)) (hvH:v≤n-4*(n/16)) : u+v∉B := by
  classical
  intro hsum
  obtain ⟨T,hT,hTc,hpair,hres⟩:=actual_bad_triangle β n u v B hf hd hgap hbn hu hv huo hvo hopp hsum huL hvL huH hvH hbudget
  have huv:u≠v:=by intro hh; subst v; exact hopp rfl
  have hTD:T⊆quarterD n B:=fun t ht=>(mem_filter.mp (mem_filter.mp (hT ht)).1).1
  have hTqual:∀t∈T,u+4*t∈B ∧ v+4*t∈B:=fun t ht=>(mem_filter.mp (hT ht)).2
  let S:=insert u (insert v (T.image (fun t=>4*t)))
  have hcl:=qualified_triangle_explicit_clique n u v B T
    (mem_inter.mp hu).1 (mem_inter.mp hv).1 huv huo hvo hsum hTD hTc hpair hTqual
  change S⊆B ∧ S.card=5 ∧ _ at hcl
  let τ:=4*(missingTopOdd n B).card+4
  let Y:=progression (2*n+2*τ) (5*n/2) 32 16
  let F:=Y.filter (fun p=>∃s∈insert 0 S,p+s∈canonicalHoles n B)
  let G:=Y\F
  let V:=(insert 0 S).filter (fun s=>s%16=8)
  have hδ:=deficit_split n B hd
  have hqδ:(missingTopOdd n B).card≤totalBudget n B:=by unfold totalBudget; omega
  have hsb:∀s∈insert 0 S,s≤n := by
    intro s hs
    rcases mem_insert.mp hs with rfl|hs
    · omega
    · rcases mem_insert.mp hs with rfl|hs
      · exact (mem_Icc.mp (mem_inter.mp hu).2).2
      · rcases mem_insert.mp hs with rfl|hs
        · exact (mem_Icc.mp (mem_inter.mp hv).2).2
        · obtain ⟨t,ht,rfl⟩:=mem_image.mp hs
          have:=(mem_Icc.mp (mem_filter.mp (hTD ht)).1).2
          omega
  have hexbound:∀s∈insert 0 S,s%16=8 → s≤n/4 := by
    intro s hs hsm
    rcases mem_insert.mp hs with rfl|hs
    · omega
    · rcases mem_insert.mp hs with rfl|hs
      · omega
      · rcases mem_insert.mp hs with rfl|hs
        · omega
        · obtain ⟨t,ht,rfl⟩:=mem_image.mp hs
          have:=(mem_filter.mp (mem_filter.mp (hT ht)).1).2
          omega
  have hY (p:ℕ) (hp:p∈Y):2*n+2*τ<p ∧ p≤5*n/2 ∧ p%32=16 := by
    obtain ⟨hi,hr⟩:=mem_filter.mp hp
    exact ⟨(mem_Ioc.mp hi).1,(mem_Ioc.mp hi).2,hr⟩
  have hFc:F.card≤2*(canonicalHoles n B).card := by
    apply affine_cover_bound8 F (insert 0 S) (canonicalHoles n B) 0 0 1 2 (by omega)
    · intro p hp
      have:=hY p (mem_filter.mp hp).1
      omega
    · exact second_offset_load u v T huo hvo hopp hres
    · intro p hp
      obtain ⟨hpY,s,hs,hcan⟩:=mem_filter.mp hp
      exact ⟨s,hs,p+s,hcan,by omega⟩
  have hGc:G.card≤(H0 n B).card := by
    have hc:G.card≤1*(H0 n B).card := by
      apply affine_cover_bound8 G V (H0 n B) 0 0 1 1 (by omega)
      · intro p hp
        have:=hY p (mem_sdiff.mp hp).1
        omega
      · intro j
        exact le_trans (card_filter_le _ _) (exceptional_offset_unique u v T huo hvo hres)
      · intro p hp
        obtain ⟨hpY,hpF⟩:=mem_sdiff.mp hp
        have hpI:=hY p hpY
        have hpS:p∉S := by
          intro hi
          have:=hsb p (mem_insert_of_mem hi)
          dsimp only [τ] at hpI
          omega
        obtain ⟨s,hs,hbad⟩:=five_clique_missing_label B S hf hcl.1 hcl.2.1 hcl.2.2 p hpS
        have hsn:=hsb s hs
        have hzL:2*n<p+s:=by dsimp only [τ] at hpI; omega
        have hzU:p+s≤4*n:=by omega
        have hhole:p+s∈holes n B:=mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,hzU⟩,hbad⟩
        have hz16:(p+s)%16=8 := by
          rcases second_pivot_canonical_or_exception u v p T huo hvo hpI.2.2 hres s hs with hcan|hex
          · exact False.elim (hpF (mem_filter.mpr ⟨hpY,s,hs,mem_filter.mpr ⟨hhole,hcan⟩⟩))
          · exact hex
        have hs16:s%16=8:=by omega
        have hsn4:=hexbound s hs hs16
        have he:p+s∈excessHoles n B := by
          apply mem_sdiff.mpr
          refine ⟨hhole,?_⟩
          intro hi
          obtain ⟨m,hm,heq⟩:=mem_image.mp hi
          change 2*m=p+s at heq
          have hm8:m%8=4:=by omega
          apply partial_middle_gap β n B hf hd hgap hn hbn hcap hbudget m hm hm8
          dsimp only [τ] at hpI
          constructor
          · omega
          · have hb:=second_gap_upper n (totalBudget n B) (missingTopOdd n B).card p s hn (by omega) hqδ hpI.2.1 hsn4
            omega
        refine ⟨s,mem_filter.mpr ⟨hs,hs16⟩,p+s,mem_filter.mpr ⟨he,by omega⟩,by omega⟩
    simpa only [one_mul] using hc
  have hpart:F.card+G.card=Y.card:=by
    have:=card_sdiff_add_card_eq_card (show F⊆Y from filter_subset _ _)
    dsimp only [G]; omega
  have hcan:=canonical_hole_total_budget n B hd
  have hH0:(H0 n B).card≤totalBudget n B := by
    have:=card_le_card (show H0 n B⊆excessHoles n B from filter_subset _ _)
    unfold totalBudget
    omega
  have hl:=progression_lower (2*n+2*τ) (5*n/2) 32 16 (by simp) (by omega)
  change (5*n/2-(2*n+2*τ))/32≤Y.card at hl
  have hcan':(canonicalHoles n B).card≤chainDeficit n B+totalBudget n B := by
    unfold totalBudget; omega
  dsimp only [τ] at hl
  exact second_count_contradiction n (chainDeficit n B) (totalBudget n B) (missingTopOdd n B).card (canonicalHoles n B).card F.card G.card Y.card hn hcap hqδ hcan' hFc (le_trans hGc hH0) hpart hl

#print axioms no_high_opposite_edge6
end OP02.SharpK6

import AdjacentCounts
open Finset
namespace OP02.EdgeBand
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot

theorem union5_card (A B C D E:Finset ℕ) :
    ((((A∪B)∪C)∪D)∪E).card≤A.card+B.card+C.card+D.card+E.card := by
  have h1:=card_union_le A B
  have h2:=card_union_le (A∪B) C
  have h3:=card_union_le ((A∪B)∪C) D
  have h4:=card_union_le (((A∪B)∪C)∪D) E
  omega

theorem adjacent_total_count (n p r:ℕ) (Q B:Finset ℕ)
    (hp:2*n<p) (hpe:p%2=0) (hpu:p≤2*n+4*r+4) :
    2*(parityMiddle n B 1).card≤n/2+(goodAdjacent n p Q B).card+
      Q.card+2*(highOdd n B).card+2*r+3 := by
  let T:=goodAdjacent n p Q B
  let M:=((missOdd n B).product (range 2)).image (fun v:ℕ×ℕ=>v.1-2*v.2)
  let F:=Q.image (fun v=>v-1)
  let H:=((highOdd n B).product (range 2)).image (fun v:ℕ×ℕ=>v.1-p-2*v.2)
  let C:=clipOdd n p
  have hs:oddPos n⊆(((T∪M)∪F)∪H)∪C := by
    intro z hz
    simp only [mem_union]
    by_cases ht:z∈T
    · exact Or.inl (Or.inl (Or.inl (Or.inl ht)))
    obtain hm|hq|hh|hc:=adjacent_failure hp hpe hz ht
    · have hmem:z∈M := by
        rcases hm with h|h
        · exact mem_image.mpr ⟨(z,0),mem_product.mpr ⟨h,by simp⟩,by simp⟩
        · exact mem_image.mpr ⟨(z+2,1),mem_product.mpr ⟨h,by simp⟩,by dsimp;omega⟩
      exact Or.inl (Or.inl (Or.inl (Or.inr hmem)))
    · have hmem:z∈F:=mem_image.mpr ⟨z+1,hq,by omega⟩
      exact Or.inl (Or.inl (Or.inr hmem))
    · have hmem:z∈H := by
        rcases hh with h|h
        · exact mem_image.mpr ⟨(p+z,0),mem_product.mpr ⟨h,by simp⟩,by dsimp;omega⟩
        · exact mem_image.mpr ⟨(p+z+2,1),mem_product.mpr ⟨h,by simp⟩,by dsimp;omega⟩
      exact Or.inl (Or.inr hmem)
    · exact Or.inr hc
  have hc:=(card_le_card hs).trans (union5_card T M F H C)
  have hM:=card_image_le (s:=(missOdd n B).product (range 2)) (f:=fun v:ℕ×ℕ=>v.1-2*v.2)
  have hF:=card_image_le (s:=Q) (f:=fun v:ℕ=>v-1)
  have hH:=card_image_le (s:=(highOdd n B).product (range 2)) (f:=fun v:ℕ×ℕ=>v.1-p-2*v.2)
  simp only [product_eq_sprod,card_product,card_range] at hM hH
  have hC:=clip_count n p r hpu
  have hmiss:=missOdd_card n B
  rw [oddPos_card] at hc
  dsimp [T,M,F,H,C] at *
  omega

def residueRecover (j off h:ℕ):=if (h-off)%4=j then h-off else h-off-2

theorem residueRecover_spec {j off h z:ℕ} (hz:z%4=j)
    (hh:h=off+z ∨ h=off+z+2) : residueRecover j off h=z := by
  dsimp [residueRecover]
  split_ifs <;> rcases hh with h|h <;> omega

theorem adjacent_residue_count (n p r j:ℕ) (Q B:Finset ℕ)
    (hp:2*n<p) (hpe:p%2=0) (hpu:p≤2*n+4*r+4) (hj:j=1 ∨ j=3) :
    n/4+(parityMiddle n B 1).card≤n/2+
      ((goodAdjacent n p Q B).filter (fun z=>z%4=j)).card+
      Q.card+(highOdd n B).card+r+2 := by
  let T:=(goodAdjacent n p Q B).filter (fun z=>z%4=j)
  let M:=(missOdd n B).image (residueRecover j 0)
  let F:=Q.image (fun v=>v-1)
  let H:=(highOdd n B).image (residueRecover j p)
  let C:=(clipOdd n p).filter (fun z=>z%4=j)
  have hs:(oddPos n).filter (fun z=>z%4=j)⊆(((T∪M)∪F)∪H)∪C := by
    intro z hz
    obtain ⟨hzP,hzJ⟩:=mem_filter.mp hz
    simp only [mem_union]
    by_cases ht:z∈goodAdjacent n p Q B
    · exact Or.inl (Or.inl (Or.inl (Or.inl (mem_filter.mpr ⟨ht,hzJ⟩))))
    obtain hm|hq|hh|hc:=adjacent_failure hp hpe hzP ht
    · have hmem:z∈M := by
        rcases hm with h|h
        · exact mem_image.mpr ⟨z,h,residueRecover_spec hzJ (Or.inl (by omega))⟩
        · exact mem_image.mpr ⟨z+2,h,residueRecover_spec hzJ (Or.inr (by omega))⟩
      exact Or.inl (Or.inl (Or.inl (Or.inr hmem)))
    · have hmem:z∈F:=mem_image.mpr ⟨z+1,hq,by omega⟩
      exact Or.inl (Or.inl (Or.inr hmem))
    · have hmem:z∈H := by
        rcases hh with h|h
        · exact mem_image.mpr ⟨p+z,h,residueRecover_spec hzJ (Or.inl rfl)⟩
        · exact mem_image.mpr ⟨p+z+2,h,residueRecover_spec hzJ (Or.inr rfl)⟩
      exact Or.inl (Or.inr hmem)
    · exact Or.inr (mem_filter.mpr ⟨hc,hzJ⟩)
  have hc:=(card_le_card hs).trans (union5_card T M F H C)
  have hM:=card_image_le (s:=missOdd n B) (f:=residueRecover j 0)
  have hF:=card_image_le (s:=Q) (f:=fun v:ℕ=>v-1)
  have hH:=card_image_le (s:=highOdd n B) (f:=residueRecover j p)
  have hC:=clip_residue_count n p r j hpu
  have hmiss:=missOdd_card n B
  have hpos:=odd_residue_lower n j hj
  dsimp [T,M,F,H,C] at *
  omega

#print axioms adjacent_total_count
#print axioms adjacent_residue_count
end OP02.EdgeBand

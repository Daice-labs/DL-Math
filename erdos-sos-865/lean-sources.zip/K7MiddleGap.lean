import K7GapMiddle
import K7CleanResidues
open Finset OP02.SmallExcess OP02.FewHole OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7

def paidRoot (u v p y a z:ℕ) : Prop :=
  z=p+4*a ∨ z=y+4*a ∨ absentWitness u v (y+4*a) z

/-- Recover the root from a single original physical witness. Direct odd
labels are below p+n; every indirect odd label is strictly above p+n. -/
theorem root_payment_unique {n u v p y σ a b z:ℕ} (hu:u%2=1) (hv:v%2=1) (huv:u<v)
    (hσ:middleClass u v σ) (hp:p%4=(4-σ)%4) (hy:y%4=σ)
    (hlo:p+n+v<2*y) (hhi:y≤p) (ha:4*a≤n) (hb:4*b≤n)
    (hz:paidRoot u v p y a z) (hz':paidRoot u v p y b z) : a=b := by
  have h0:=hσ.1;have h1:=hσ.2.1;have h2:=hσ.2.2
  rcases hz with hz|hz|hz|hz|hz <;> rcases hz' with hz'|hz'|hz'|hz'|hz' <;> omega

theorem no_high_edge {β:ℝ} {n u v:ℕ} {B:Finset ℕ} (hb:0<β)
    (hf:SevenFree B) (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hbn:(10:ℝ)≤β*n) (hn:65536≤n) (hq:256*totalBudget n B≤n)
    (h4:rootFourBound β n) (h5:rootFiveBound β n)
    (hu:u∈B) (hv:v∈B) (huv:u<v) (hou:u%2=1) (hov:v%2=1)
    (hres:(u+v)%4=0) (huL:n<2*u) (hvH:v≤n-4*(n/16)) : u+v∉B := by
  classical
  intro he
  obtain ⟨σ,hσ⟩:=middle_class_exists hou hov hres huv
  have hw:=fun (s:ℕ) (hs:s%4=σ) (hl:2*n+v<2*s) (hh:s≤2*n) (ha:s∉B)=>
    absent_witness hb hf hd hg hbn h4 hu hv huv hou hov hres he huL hvH hσ hs hl hh ha
  obtain ⟨p,y,hpL,hpH,hpr,hpB,hyL,hyH,hyr,hyB,hyp⟩:=
    middle_upper_edge hd hn hq hou hov huv hvH hσ hw
  let D:=quarterD n B
  let Y:=D.filter (fun a=>y+4*a∈B ∧ p+4*a∈B)
  let F:=D\Y
  let E:=OP02.SharpK6.bootstrapResources n B
  have hσ1:=hσ.1;have hσ2:=hσ.2.1;have hσ3:=hσ.2.2
  have bounds {a:ℕ} (ha:a∈D) : 0<a ∧ 4*a≤n:=by
    have hh:=mem_Icc.mp (mem_filter.mp ha).1;omega
  have hF:F.card≤totalBudget n B:=by
    apply le_trans _ (OP02.SharpK6.bootstrap_resource_budget n B hd)
    apply physical_injection (R:=paidRoot u v p y)
    · intro a ha;obtain ⟨haD,hnY⟩:=mem_sdiff.mp ha
      have hab:=bounds haD
      by_cases hm:p+4*a∈B
      · have has:y+4*a∉B:=fun hy=>hnY (mem_filter.mpr ⟨haD,hy,hm⟩)
        by_cases hh:2*n<y+4*a
        · refine ⟨y+4*a,mem_union_right _ (OP02.SharpK6.bootstrap_missing_odd n _ B (by omega) hh (by omega) has),
            Or.inr (Or.inl rfl)⟩
        · obtain ⟨z,hz,hz'⟩:=hw (y+4*a) (by omega) (by omega) (by omega) has
          exact ⟨z,hz,Or.inr (Or.inr hz')⟩
      · exact ⟨p+4*a,mem_union_right _ (OP02.SharpK6.bootstrap_missing_odd n _ B
          (by omega) (by omega) (by omega) hm),Or.inl rfl⟩
    · intro a ha b hb' z hz hz'
      exact root_payment_unique hou hov huv hσ hpr hyr hyL (by omega)
        (bounds (mem_sdiff.mp ha).1).2 (bounds (mem_sdiff.mp hb').1).2 hz hz'
  have hpart:=card_sdiff_add_card_eq_card (filter_subset _ _ :Y⊆D)
  have hden:D.card≤Y.card+totalBudget n B:=by change F.card+Y.card=D.card at hpart;omega
  have hhden:((quarterD n B).card:ℝ)≤(Y.card:ℝ)+totalBudget n B:=by exact_mod_cast hden
  have hY: Y⊆Icc 1 (n/4):=fun a ha=>(mem_filter.mp (mem_filter.mp ha).1).1
  have hfree:¬FiveFree Y:=by
    intro hh;have hh':=h5 Y hY hh
    have h1:(4:ℝ)*(n/4:ℕ)≤(n:ℝ):=by exact_mod_cast (show 4*(n/4)≤n by omega)
    nlinarith only [hhden,hg,hh',h1,hbn,mul_nonneg hb.le (sub_nonneg.mpr h1)]
  obtain ⟨S,hs,hsc,hpair⟩:=Classical.not_not.mp hfree
  let V:Finset ℕ:={y,p}
  have hyp':y≠p:=by omega
  have hV:internalOn B V:=by
    constructor
    · intro a ha;simp only [V,mem_insert,mem_singleton] at ha;rcases ha with rfl | rfl <;> assumption
    · intro a ha b hb' hne;simp only [V,mem_insert,mem_singleton] at ha hb'
      rcases ha with rfl | rfl <;> rcases hb' with rfl | rfl <;>
        first | exact False.elim (hne rfl) | exact hyp | simpa only [Nat.add_comm] using hyp
  apply combine_roots (n:=n) (T:=S) (V:=V) (B:=B) _ hV _ _ _ hf
  · exact ⟨fun a ha=>(mem_filter.mp (hs ha)).1,fun a ha b hb' hh=>(mem_filter.mp (hpair a ha b hb' hh)).1⟩
  · intro a ha w hw';have hh:=bounds (mem_filter.mp (hs ha)).1
    simp only [V,mem_insert,mem_singleton] at hw';rcases hw' with rfl | rfl <;>omega
  · simp [V,hsc,hyp']
  · intro a ha w hw';have hq:=(mem_filter.mp (hs ha)).2
    simp only [V,mem_insert,mem_singleton] at hw';rcases hw' with rfl | rfl <;>tauto

def MiddleGap7 (n:ℕ) (B:Finset ℕ) : Prop :=
  ∀m∈middle n B,m%4=0→¬(n+(4*(missingTopOdd n B).card+8)< m ∧
    m<2*(n-4*(n/16))-(4*(missingTopOdd n B).card+8))

/-- Quantification over the original physical B. P4 and P5 enter through the
same explicit seven-point midpoint premise as the endpoint contract. -/
theorem middle_gap7 (hD:Dousse7) (β:ℝ) (hb:0<β) :
    ∃N₀:ℕ,∀n:ℕ,N₀≤n→∀B:Finset ℕ, SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) → MiddleGap7 n B := by
  classical
  obtain ⟨T,hT⟩:=fourfree_uniform hD β hb
  obtain ⟨U,hU⟩:=fivefree_uniform hD β hb
  obtain ⟨V,hV⟩:=inventory_uniform β hb
  obtain ⟨W₀,hW₀⟩:=exists_nat_gt (10/β)
  refine ⟨max (16*T) (max (4*U) (max V W₀)),?_⟩
  intro n hn B hf hd hg m hm hm4 hgap
  let h := (missingTopOdd n B).card
  let W:=n-4*(n/16)
  let L:=max (n/2) (m-W-1)
  let U':=min W (m-n/2-1)
  let Y:=progression L U' 4 1
  have mB:=(mem_inter.mp hm).1
  have mI:=mem_Icc.mp (mem_inter.mp hm).2
  have h4:rootFourBound β n:=by
    intro X hx hfree;simpa only [add_mul] using hT (n/16) (by omega) X hx hfree
  have h5:rootFiveBound β n:=by
    intro X hx hfree;simpa only [add_mul] using hU (n/4) (by omega) X hx hfree
  obtain ⟨hcap,hbig⟩:=hV n (by omega) B hd hg
  have hq:256*totalBudget n B≤n:=by omega
  have hbn:(10:ℝ)≤β*n:=by
    have hgt:10/β<(n:ℝ):=lt_of_lt_of_le hW₀ (by exact_mod_cast (show W₀≤n by omega))
    have :=(div_lt_iff₀ hb).mp hgt; linarith
  have hlen:4*(h+1)≤U'-L:=by dsimp [U',L,W,h];omega
  have hY {a:ℕ} (ha:a∈Y): n<2*a ∧ a≤W ∧ n<2*(m-a) ∧ m-a≤W ∧ a< m ∧ a%4=1 ∧ (m-a)%4=3:=by
    obtain ⟨hi,hr⟩:=mem_filter.mp ha; have hI:=mem_Ioc.mp hi
    dsimp only [L,U',W] at hI ⊢; omega
  have hsmall:Y.card≤h:=by
    apply card_le_card_of_injOn (fun a=>if a∉B then a else m-a)
    · intro a ha;have hh:=hY ha
      have hbad:¬(a∈B ∧ m-a∈B):=by
        rintro ⟨h1,h2⟩
        have hsum:a+(m-a)=m:=by omega
        have hsum':m-a+a=m:=by omega
        by_cases he:a < m-a
        · exact no_high_edge hb hf hd hg hbn hbig hq h4 h5 h1 h2 he (by omega) (by omega)
            (by omega) hh.1 hh.2.2.2.1 (hsum.symm ▸ mB)
        · exact no_high_edge hb hf hd hg hbn hbig hq h4 h5 h2 h1 (by omega) (by omega) (by omega)
            (by omega) hh.2.2.1 hh.2.1 (hsum'.symm ▸ mB)
      change (if a∉B then a else m-a)∈missingTopOdd n B
      have haN:a≤n ∧ m-a≤n:=by dsimp [W] at hh;omega
      by_cases he:a∉B
      · rw [if_pos he];exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,haN.1⟩,by omega⟩,by omega,he⟩
      · rw [if_neg he];exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,haN.2⟩,by omega⟩,by omega,by tauto⟩
    · intro a ha b hb' hEq;have ha':=hY ha;have hby:=hY hb'
      change (if a∉B then a else m-a)=(if b∉B then b else m-b) at hEq
      split_ifs at hEq <;> omega
  have hlength:=progression_lower L U' 4 1 (by decide) (by decide)
  change _≤Y.card at hlength
  omega
end OP02.SharpK7

import K8FixedFourPrefix

open Finset OP02.FewHole OP02.SmallExcess

namespace OP02.SharpK8

/-- A new root above half the prefix joins all four actual companions and zero. -/
def FixedReplacement (H : ℕ) (D X : Finset ℕ) : Prop :=
  ∃ y : ℕ, H/4 < 2*y ∧ 128*y + 5*H ≤ 128*(H/4) ∧
    ∀ x ∈ insert 0 X, y+x ∈ D ∩ Icc 1 (H/4)

/-- The large member is removed from the same actual internal five. -/
theorem split_prefix_five {H : ℕ} {D F : Finset ℕ}
    (hF : Internal 5 (D ∩ Icc 1 (H/4)) F) :
    ShortFive H D F ∨ ∃ w ∈ F, 128*(H/4) < 128*w + 5*H ∧
      Internal 4 (D ∩ Icc 1 (H/4)) (F.erase w) ∧
      ∀ x ∈ F.erase w, 128*x < 5*H := by
  classical
  by_cases hshort : ∀ x ∈ F, 128*x + 5*H ≤ 128*(H/4)
  · exact Or.inl ⟨hF,hshort⟩
  · push Not at hshort
    obtain ⟨w,hw,hlarge⟩ := hshort
    refine Or.inr ⟨w,hw,hlarge,⟨Subset.trans (erase_subset _ _) hF.1,?_,?_⟩,?_⟩
    · rw [card_erase_of_mem hw,hF.2.1]
    · intro x hx y hy hxy
      exact hF.2.2 x (mem_of_mem_erase hx) y (mem_of_mem_erase hy) hxy
    · intro x hx
      obtain ⟨hneq,hxF⟩ := mem_erase.mp hx
      have hi := (mem_Icc.mp (mem_inter.mp (hF.2.2 x hxF w hw hneq)).2).2
      omega

/-- Read all ten prefix sums for an actual fixed replacement. -/
theorem short_five_of_fixed_replacement {H : ℕ} {D X : Finset ℕ}
    (hX : Internal 4 (D ∩ Icc 1 (H/4)) X) (hR : FixedReplacement H D X) :
    ∃ F : Finset ℕ, ShortFive H D F := by
  classical
  obtain ⟨y,hylo,hyhi,hjoins⟩ := hR
  have hy : y ∈ D ∩ Icc 1 (H/4) := by simpa using hjoins 0 (mem_insert_self _ _)
  have join (x : ℕ) (hx : x∈X) := hjoins x (mem_insert_of_mem hx)
  have bound (x : ℕ) (hx : x∈X) : x<y := by
    have h := (mem_Icc.mp (mem_inter.mp (join x hx)).2).2
    omega
  have hnot : y∉X := fun h => (lt_irrefl y) (bound y h)
  refine ⟨insert y X,⟨?_,by rw [card_insert_of_notMem hnot,hX.2.1],?_⟩,?_⟩
  · intro x hx
    obtain rfl | hx := mem_insert.mp hx
    · exact hy
    · exact hX.1 hx
  · intro a ha b hb hab
    by_cases hay : a = y
    · subst a
      exact join b ((mem_insert.mp hb).resolve_left hab.symm)
    · have haX := (mem_insert.mp ha).resolve_left hay
      by_cases hby : b = y
      · subst b
        simpa only [Nat.add_comm] using join a haX
      · exact hX.2.2 a haX b ((mem_insert.mp hb).resolve_left hby) hab
  · intro x hx
    obtain rfl | hx := mem_insert.mp hx
    · exact hyhi
    · have h := bound x hx
      omega

/-- The alternative constructed in fixed-four §6 is short after rounding every endpoint. -/
theorem short_five_of_144Q {H : ℕ} {D F : Finset ℕ} (hH : 16 ≤ H)
    (hF : Internal 5 (D ∩ Icc 1 (H/4)) F) (hsmall : ∀ x ∈ F,64*x ≤ 9*H) :
    ShortFive H D F := by
  refine ⟨hF,?_⟩
  intro x hx
  have h := hsmall x hx
  omega

/-- Assemble either of the two distinct fixed-four outcomes for the actual companions. -/
theorem shorten_prefix_five {H : ℕ} {D F : Finset ℕ} (hH : 16 ≤ H)
    (hF : Internal 5 (D ∩ Icc 1 (H/4)) F)
    (outcome : ∀ X : Finset ℕ, Internal 4 (D ∩ Icc 1 (H/4)) X →
      (∀ x ∈ X, 128*x < 5*H) →
      FixedReplacement H D X ∨
        ∃ Z : Finset ℕ, Internal 5 (D ∩ Icc 1 (H/4)) Z ∧ ∀ x ∈ Z, 64*x ≤ 9*H) :
    ∃ Z : Finset ℕ, ShortFive H D Z := by
  rcases split_prefix_five hF with hshort | ⟨w,_,_,hX,hs⟩
  · exact ⟨F,hshort⟩
  · rcases outcome (F.erase w) hX hs with hr | ⟨Z,hZ,hz⟩
    · exact short_five_of_fixed_replacement hX hr
    · exact ⟨Z,short_five_of_144Q hH hZ hz⟩

end OP02.SharpK8

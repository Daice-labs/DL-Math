import K7LongOddProof
import K7OddOnlyTwoK
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

/-- Uniformly excludes every odd-largest companion for every reflection supply.
Also excludes the stated two kinds of odd-only placements. The variable m
is a bound on the four companions and can be taken equal to their maximum. -/
theorem more_O2_windows (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ)→
    ∀t t' h k l:ℕ,t%2=1→t'%2=1→t%4≠t'%4→0<h→k%2=1→l%2=1→k<l→2*(n/4)<3*(2*l)→
    InternalFive (B∩Icc 1 (n/4)) (insert (2*l) {t,t',4*h,2*k})→
    ((∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤t) ∨
      (¬ActiveEvenSupply n B ∧
        ((∃m, (∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤ m) ∧ 3*m<n/4 ∧
            m≤t+4*(n/4/64)+4*lambdaBudget n B) ∨
          (h%2=0 ∧ ∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤2*k))))→False := by
  obtain ⟨A,hA⟩:=long_odd_even_mixed_window hD β hb
  obtain ⟨B₀,hB₀⟩:=closed_O2_windows hD hb
  obtain ⟨C,hC⟩:=uniform_window_threshold β hb
  obtain ⟨D,hG⟩:=middle_gap7 hD β hb
  obtain ⟨E,hE⟩:=inventory_uniform β hb
  obtain ⟨F,hF⟩:=(bridge_rows_of_dispatch hD (i:=14) (Or.inr rfl)) β hb
  obtain ⟨G,hJ⟩:=(bridge_rows_of_dispatch hD (i:=5) (Or.inl rfl)) β hb
  refine ⟨max (4*64*16384) (max A (max B₀ (max C (max D (max E (max F G)))))),?_⟩
  intro n hn B sub hf hd hg t t' h k l ho ho' opp hp ko lo kl big seed guards
  have sc:16384≤n/4/64:=by omega
  obtain ⟨_,hl⟩:=hC n (by omega)
  obtain ⟨cap,large⟩:=hE n (by omega) B hd hg
  have noJ:=qualified_J0_exclusion hf hd (hG n (by omega) B hf hd hg) cap large
  have noOdd (rep:oddReplacement n t t' h k B):False:=by
    obtain ⟨S,hS,row⟩:=odd_replacement_in_row14 ho ho' opp ko rep
    exact hF n (by omega) B sub hf hd hg S hS row
  have near (m:ℕ) (bd:∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤ m)
      (up:3*m<n/4) (dist:m≤t+4*(n/4/64)+4*lambdaBudget n B) (pure:¬ActiveEvenSupply n B) : False :=
    (odd_only_near_max hd hg seed sc hl ho ho' opp ko bd up dist pure).elim noOdd noJ
  rcases guards with top | ⟨pure,⟨m,bd,up,dist⟩|⟨he,bd⟩⟩
  · by_cases ht:t≤17*(n/4/64)
    · exact hB₀ n (by omega) B sub hf hd hg _ _ _ _ _ seed ho ho' opp ko (Or.inl ⟨top,ht⟩)
    have sum:=(mem_Icc.mp (mem_inter.mp (seed.2.2 t (by simp) (2*l) (by simp) (by omega))).2).2
    by_cases active:ActiveEvenSupply n B
    · exact hA n (by omega) B sub hf hd hg t t' h k l ho ho' opp hp ko lo kl big seed top (by omega) active
    · exact near t top (by omega) (by omega) active
  · exact near m bd up dist pure
  · have sum:=(mem_Icc.mp (mem_inter.mp (seed.2.2 (2*k) (by simp) (2*l) (by simp) (by omega))).2).2
    rcases odd_only_two_k hd hg seed sc hl ho ho' opp ko he bd (by omega) pure with rep|five
    · obtain ⟨S,hS,row⟩:=even_replacement_in_row5 ho ho' opp ko rep
      exact hJ n (by omega) B sub hf hd hg S hS row
    · exact noJ five

end OP02.SharpK7.LongOddTask

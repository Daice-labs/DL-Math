import K8FixedFourPrefix

open Finset OP02.FewHole OP02.SharpK5
namespace OP02.SharpK8

/-- The deficit of the whole set splits exactly across a quarter cut. -/
theorem quarter_defect_eq (H : ℕ) (D : Finset ℕ) (hs : D ⊆ Icc 1 H) (hd : DoublingFree D) :
    chainCapacity H - D.card =
      (chainCapacity (H/4) - (D ∩ Icc 1 (H/4)).card) + (unmatchedTop H D).card := by
  have partition := top_band_cancellation H D hs hd
  have prefixDF : DoublingFree (D ∩ Icc 1 (H/4)) := by
    intro x hx hx2;exact hd x (mem_inter.mp hx).1 (mem_inter.mp hx2).1
  have prefixCap := chain_capacity_with_top_loss (H/4) (D ∩ Icc 1 (H/4)) inter_subset_right prefixDF
  rw [canonical_capacity_recurrence]
  omega

theorem prefix_defect_le (H j : ℕ) (D : Finset ℕ) (hs : D ⊆ Icc 1 H) (hd : DoublingFree D) :
    chainCapacity (H/4^j) - (D ∩ Icc 1 (H/4^j)).card ≤ chainCapacity H-D.card := by
  induction j generalizing H D with
  | zero => simp [inter_eq_left.mpr hs]
  | succ j ih =>
    let F := D ∩ Icc 1 (H/4)
    have df : DoublingFree F := by
      intro x hx hx2;exact hd x (mem_inter.mp hx).1 (mem_inter.mp hx2).1
    have inner := ih (H/4) F inter_subset_right df
    have sep := quarter_defect_eq H D hs hd
    have eq : H/4/4^j=H/4^(j+1) := by rw [Nat.div_div_eq_div_mul,pow_succ]; congr 1; omega
    rw [eq] at inner
    have le : H/4^(j+1)≤H/4 := by rw [←eq]; exact Nat.div_le_self _ _
    have cut : F ∩ Icc 1 (H/4^(j+1)) = D ∩ Icc 1 (H/4^(j+1)) := by
      ext x
      simp only [F,mem_inter,mem_Icc]
      constructor
      · intro hx;exact ⟨hx.1.1,hx.2⟩
      · intro hx;exact ⟨⟨hx.1,hx.2.1,hx.2.2.trans le⟩,hx.2⟩
    rw [cut] at inner
    dsimp [F] at inner
    omega

theorem band_canonical_holes_le (H j : ℕ) (D : Finset ℕ)
    (hs : D ⊆ Icc 1 H) (hd : DoublingFree D) :
    (topMissing (H/4^j) D).card ≤ chainCapacity H-D.card := by
  let h := H/4^j
  let F := D ∩ Icc 1 h
  have df : DoublingFree F := by
    intro x hx hx2;exact hd x (mem_inter.mp hx).1 (mem_inter.mp hx2).1
  have cap := chain_capacity_with_top_loss h F inter_subset_right df
  have same : topMissing h D = topMissing h F := by
    ext x
    simp only [topMissing,canonicalSlots,F,mem_filter,mem_inter,mem_Icc]; tauto
  have cut := prefix_defect_le H j D hs hd
  change chainCapacity h - F.card ≤ _ at cut
  change (topMissing h D).card ≤ _
  rw [same];omega

end OP02.SharpK8

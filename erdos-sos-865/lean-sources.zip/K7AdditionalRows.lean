import K7CleanResidues
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

def evenOffsets (S:Finset ℕ):=S.filter (fun s=>s%2=0)
def oddOffsets (S:Finset ℕ):=S.filter (fun s=>s%2=1)

theorem parity_partition (S:Finset ℕ) : (evenOffsets S).card+(oddOffsets S).card=S.card := by
  have h:=card_filter_add_card_filter_not (s:=S) (fun x=>x%2=0)
  have he:S.filter (fun x=>¬x%2=0)=oddOffsets S:=by
    ext x; simp only [oddOffsets,mem_filter];rw [show (¬x%2=0)↔x%2=1 by omega]
  rw [he] at h;exact h

private theorem clean_zero {T:Finset ℕ} (hr:∀s∈T,s%2=0→s%4=0) (hc:(evenOffsets T).card≤3) : cleanResidue T 0 := by
  refine ⟨by decide,?_,by simpa [evenOffsets] using hc⟩
  intro s hs;by_cases he:s%2=0
  · have :=hr s hs he;omega
  · omega

private theorem even_insert (x:ℕ) (S:Finset ℕ) :
    (evenOffsets (insert x S)).card ≤ (evenOffsets S).card+1 := by
  apply le_trans (card_le_card (t:=insert x (evenOffsets S)) _) (card_insert_le _ _)
  intro z hz
  obtain ⟨hi,he⟩:=mem_filter.mp hz
  rcases mem_insert.mp hi with hh|hz
  · exact mem_insert.mpr (Or.inl hh)
  · exact mem_insert_of_mem (mem_filter.mpr ⟨hz,he⟩)

private theorem even_insert_odd {x:ℕ} (S:Finset ℕ) (ho:x%2=1) :
    evenOffsets (insert x S)=evenOffsets S := by
  ext z
  simp only [evenOffsets,mem_filter,mem_insert]
  constructor
  · rintro ⟨h|hz,he⟩
    · omega
    · exact ⟨hz,he⟩
  · tauto

/-- Uniformly covers row 17 and row 22, including every placement and both
homogeneous and mixed odd anchors. -/
theorem rows17_22 {β:ℝ} (hb:0<β) : ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,
    SevenFree B→DoublingFree B→(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→4≤(oddOffsets S).card→
      (∀x∈S,x%2=0→x%4=0)→False := by
  obtain ⟨U,hU⟩:=inventory_uniform β hb
  refine ⟨U,?_⟩
  intro n hn B hf hd hg S hs ho hres
  obtain ⟨hc,hsize⟩:=hU n hn B hd hg
  have hp:=parity_partition S
  have h5:=hs.1
  have he: (evenOffsets S).card≤1:=by omega
  have hO:=even_insert 0 S
  have hfirst:∀x∈insert 0 S,x%2=0→x%4=0:=by
    intro x hx h;rcases mem_insert.mp hx with h0|hx
    · omega
    · exact hres x hx h
  apply two_clean_residues hf hd hc hsize hs (r:=0) (clean_zero hfirst (by omega))
  intro y hy
  refine ⟨0,clean_zero ?_ ?_⟩
  · intro x hx h
    rcases mem_insert.mp hx with heq|hx
    · omega
    · exact hfirst x hx h
  · have hh:=even_insert y (insert 0 S);omega

/-- All of row 12: three odd vertices in one residue class and two
multiples of four. The first base is opposite to the common odd residue;
the outer base is zero modulo four. -/
theorem row12_same_odd {β:ℝ} (hb:0<β) : ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,
    SevenFree B→DoublingFree B→(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→(oddOffsets S).card=3→
      (∀x∈S,x%2=0→x%4=0)→(∃c<4,c%2=1 ∧ ∀x∈S,x%2=1→x%4=c)→False := by
  obtain ⟨U,hU⟩:=inventory_uniform β hb
  refine ⟨U,?_⟩
  intro n hn B hf hd hg S hs ho hres hmono
  obtain ⟨c,hc,hodd,hm⟩:=hmono
  obtain ⟨hcap,hsize⟩:=hU n hn B hd hg
  let r:=(4-c)%4
  have hr:r<4 ∧ r%2=1 ∧ (r+c)%4=0 := by dsimp [r];omega
  have hp:=parity_partition S; have h5:=hs.1
  have hf₀:cleanResidue (insert 0 S) r := by
    refine ⟨hr.1,?_,?_⟩
    · intro x hx
      rcases mem_insert.mp hx with h0|hx
      · omega
      · by_cases he:x%2=0
        · omega
        · have hh:=hm x hx (by omega);dsimp [r] at *;omega
    · apply le_trans (card_le_card (t:=oddOffsets S) _) (by omega)
      intro x hx
      obtain ⟨hx,he⟩:=mem_filter.mp hx
      rcases mem_insert.mp hx with h0|hx
      · omega
      · exact mem_filter.mpr ⟨hx,by omega⟩
  apply two_clean_residues hf hd hcap hsize hs hf₀
  intro y hy
  have hyo:y%2=1:=by omega
  refine ⟨0,clean_zero ?_ ?_⟩
  · intro x hx h0
    rcases mem_insert.mp hx with heq|hx
    · omega
    · rcases mem_insert.mp hx with heq|hx
      · omega
      · exact hres x hx h0
  · rw [even_insert_odd _ hyo];have :=even_insert 0 S;omega

end OP02.SharpK7

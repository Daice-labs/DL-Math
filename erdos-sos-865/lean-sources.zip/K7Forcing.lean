import K7OnWindow
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- Replace the fifth vertex. The six edges internal to the retained four
come from the old physical clique, and each of the four new edges is required. -/
theorem replace_fifth {C Q:Finset ℕ} {s y:ℕ} (h:InternalFive C (insert s Q))
    (hc:Q.card≤4) (hy:y∈C) (hsep:∀x∈Q,x<y) (hnew:∀x∈Q,y+x∈C) :
    InternalFive C (insert y Q) := by
  have hQ:Q.card=4:=by have :=card_insert_le s Q;have :=h.1;omega
  have hyQ:y∉Q:=fun hy' => (lt_irrefl y) (hsep _ hy')
  refine ⟨by rw [card_insert_of_notMem hyQ,hQ],insert_subset hy (fun x hx=>h.2.1 (mem_insert_of_mem hx)),?_⟩
  intro x hx v hv hne
  rcases mem_insert.mp hx with he|hxQ <;> rcases mem_insert.mp hv with he'|hvQ
  · exact False.elim (hne (he.trans he'.symm))
  · rw [he];exact hnew v hvQ
  · rw [he',Nat.add_comm];exact hnew x hxQ
  · exact h.2.2 x (mem_insert_of_mem hxQ) v (mem_insert_of_mem hvQ) hne

private theorem occupied_double {n p:ℕ} {B:Finset ℕ} (hp:0<p) (hodd:p%2=1)
    (hr:2*p≤n) (hem:p∉emptyPairs n B) (ha:p∉B) : 2*p∈B := by
  by_contra hn
  exact hem (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨hp,by omega⟩,hodd⟩,hr,ha,hn⟩)

def evenBases (H m : ℕ) := ((Ioc (H/8) ((H-m)/4)).filter (fun z=>z%2=1))
def evenTests (n u v h k z : ℕ) (B : Finset ℕ) : Prop :=
  z∈quarterD n B ∧ z+h∈quarterD n B ∧ 4*z+u∈B ∧ 4*z+v∈B ∧ k+2*z∉emptyPairs n B
instance (n u v h k z : ℕ) (B:Finset ℕ):Decidable (evenTests n u v h k z B):=
  inferInstanceAs (Decidable (z∈quarterD n B ∧ z+h∈quarterD n B ∧ 4*z+u∈B ∧ 4*z+v∈B ∧ k+2*z∉emptyPairs n B))

theorem even_base_alternative {n u v h k s m z:ℕ} {B:Finset ℕ}
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {u,v,4*h,2*k}))
    (hm:3*m≤n/4) (hm₀:∀x∈({u,v,4*h,2*k}:Finset ℕ),x≤ m)
    (hk:k%2=1) (hz:z∈evenBases (n/4) m) (ht:evenTests n u v h k z B) :
    k+2*z∈B ∨
      (InternalFive (B∩Icc 1 (n/4)) (insert (4*z) {u,v,4*h,2*k}) ∧
        ∀x∈({u,v,4*h,2*k}:Finset ℕ),x<4*z) := by
  classical
  by_cases hp:k+2*z∈B
  · exact Or.inl hp
  right
  have hh:=mem_Ioc.mp (mem_filter.mp hz).1
  have hmH:m≤n/4:=by omega
  have htop:0<z ∧ 4*z+m≤n/4 ∧ m<4*z:=by omega
  have hk':2*k≤ m:=hm₀ _ (by simp)
  have he:=occupied_double (by omega) (show (k+2*z)%2=1 by omega) (by omega) ht.2.2.2.2 hp
  have hze := (mem_filter.mp ht.1).2
  have hhe := (mem_filter.mp ht.2.1).2
  have hfar:∀x∈({u,v,4*h,2*k}:Finset ℕ),x<4*z:=fun x hx=>lt_of_le_of_lt (hm₀ x hx) htop.2.2
  refine ⟨replace_fifth hs (by have h1:=card_insert_le u ({v,4*h,2*k}:Finset ℕ); have h2:=@card_le_three ℕ _ v (4*h) (2*k); omega) (mem_inter.mpr ⟨hze,mem_Icc.mpr ⟨by omega,by omega⟩⟩)
    hfar ?_,hfar⟩
  intro x hx
  have bound:=hm₀ x hx
  apply mem_inter.mpr;refine ⟨?_,mem_Icc.mpr ⟨by omega,by omega⟩⟩
  simp only [mem_insert,mem_singleton] at hx
  rcases hx with rfl|rfl|rfl|rfl
  · exact ht.2.2.1
  · exact ht.2.2.2.1
  · simpa only [Nat.mul_add] using hhe
  · rwa [show 2*(k+2*z)=4*z+2*k by omega] at he

/-- Count the complete odd-z forcing domain by physical cause. The two
top translations share one charge because the source anchors differ mod four. -/
theorem even_base_failures {n u v h k m:ℕ} {B:Finset ℕ} (hd:DoublingFree B)
    (hu:u%2=1) (hv:v%2=1) (huv:u%4≠v%4) (hh:h%2=0) (hk:k%2=1)
    (hgeom:3*m≤n/4) (hum:u≤ m) (hvm:v≤ m) (hhm:4*h≤ m) (hkm:2*k≤ m) :
    ((evenBases (n/4) m).filter (fun z=>¬evenTests n u v h k z B)).card ≤
      2*A_loss n B+T_loss n B+G_loss n B := by
  classical
  let Y:=evenBases (n/4) m
  let A:=emptyOuter (n/4/4) (quarterD n B)
  let T:=absentTop n B
  let E:=gapOriginal n B
  let Z:=Y.filter (fun z=>¬evenTests n u v h k z B)
  let X:=(A.image (fun r=>r-h))∪A
  let J:=T.image (fun a=>if a%4=u%4 then (a-u)/4 else (a-v)/4)
  let V:=E.image (fun a=>(a-k)/2)
  have hsub:Z ⊆ X ∪ J ∪ V:=by
    intro z hz
    obtain ⟨hY,hn⟩:=mem_filter.mp hz
    obtain ⟨hI,hzo⟩:=mem_filter.mp hY
    have hwin:=mem_Ioc.mp hI
    have hδ : 4*z+m≤n/4 := by omega
    by_cases h1:z∈quarterD n B
    · by_cases h2:z+h∈quarterD n B
      · by_cases h3:4*z+u∈B
        · by_cases h4:4*z+v∈B
          · have hp:k+2*z∈emptyPairs n B:=by by_contra hg;exact hn ⟨h1,h2,h3,h4,hg⟩
            apply mem_union_right;apply mem_image.mpr
            exact ⟨k+2*z,mem_filter.mpr ⟨hp,by omega,by omega⟩,by omega⟩
          · apply mem_union_left;apply mem_union_right;apply mem_image.mpr
            have he:(4*z+v)%4≠u%4:=by omega
            exact ⟨4*z+v,mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,h4⟩,
              by rw [if_neg he];omega⟩
        · apply mem_union_left;apply mem_union_right;apply mem_image.mpr
          have he:(4*z+u)%4=u%4:=by omega
          exact ⟨4*z+u,mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,h3⟩,
            by rw [if_pos he];omega⟩
      · apply mem_union_left;apply mem_union_left;apply mem_union_left
        apply mem_image.mpr
        exact ⟨z+h,absent_quarter_root (by omega) (by omega) (by omega) h2,by omega⟩
    · apply mem_union_left;apply mem_union_left;apply mem_union_right
      exact absent_quarter_root (by omega) (by omega) (by omega) h1
  have h1:=card_union_le X J;have h2:=card_union_le (X∪J) V
  have h3:=card_union_le (A.image (fun r=>r-h)) A
  have hT:=absent_top_cost n B hd
  have hi : (A.image (fun r=>r-h)).card≤A.card:=card_image_le
  have hj:J.card≤T.card:=card_image_le
  have hv':V.card≤E.card:=card_image_le
  have hx:X.card≤2*A.card:=by dsimp [X];omega
  have hh': T.card≤T_loss n B:=hT
  change Z.card≤2*A.card+T_loss n B+E.card
  have hh₂:=card_le_card hsub;omega

end OP02.SharpK7

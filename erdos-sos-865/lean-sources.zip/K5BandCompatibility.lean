import K5BandSupply
import K5BandBudgets
import K5BandArithmetic
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 1000000

/-- Opposite-residue common neighbors are excluded by injecting the entire
first-band supply into the same doubled-gap resource union. -/
theorem opposite_neighbors_empty (n u σ r s:ℕ) (B S:Finset ℕ)
    (hn:1024≤n) (hf:FiveFree B) (hd:DoublingFree B) (hq:128*totalBudget n B≤n)
    (hbudget:3*(canonicalHoles n B).card<n/32)
    (hdense:5*n+32*totalBudget n B+52<32*(quarterD n B).card)
    (hu:2*u<n) (hσ:σ=1 ∨ σ=3) (hS:S⊆Icc 1 n)
    (hr:r∈quarterD n B) (hs:s∈quarterD n B) (hrs:r≠s)
    (hrsD:r+s∈quarterD n B) (hsmall:r+s≤n/16)
    (hband:(forcedBand n S u σ\B).card≤bandCost n σ B) :
    bandNeighbors n r s (4-σ) B=∅ := by
  classical
  have hsup:=first_band_supply n u σ r s B S hn hq hd hu hσ hS hsmall
  have hb:=band_budget n σ B hd hσ
  have hmany:(fourResources n B).card<(bandNeighbors n r s σ B).card := by omega
  apply eq_empty_iff_forall_notMem.mpr
  intro z hz
  obtain ⟨hzM,hzσ,hzr,hzs,hzL,hzU⟩:=mem_filter.mp hz
  have hzin:=mem_Icc.mp (mem_inter.mp hzM).2
  have hz7:4*z≤7*n := le_of_lt (gap_domain n z hn (by omega))
  have hc:(bandNeighbors n r s σ B).card≤(fourResources n B).card := by
    apply card_le_card_of_injOn (fun y=>y+z)
    · intro y hy
      obtain ⟨hyM,hyσ,hyr,hys,hyL,hyU⟩:=mem_filter.mp hy
      have hyo:y%2=1 := by omega
      have hzo:z%2=1 := by omega
      have hy7:4*y≤7*n := le_of_lt (gap_domain n y hn (by omega))
      have hyz:y≠z := by omega
      have hbad:=gap_neighborhood_independent n r s y z B hn hf hd hq hbudget hdense
        hr hs hrs hrsD hsmall hyM hzM hyo hzo hy7 hz7 hyz hyr hys hzr hzs
      apply missing_in_doubled_gap n (y+z) B hf hd hbudget hdense (by omega) hbad (by omega) (by omega)
    · intro x hx y hy he
      change x+z=y+z at he
      omega
  omega

/-- The second band supplies the quantitative high-vertex conclusion. Every
clipped candidate is either a common neighbor or fails an actual band membership. -/
theorem high_vertex_from_empty (n v σ r s:ℕ) (B S:Finset ℕ)
    (hn:1024≤n) (hq:128*totalBudget n B≤n) (hd:DoublingFree B)
    (hv:v≤n) (hσ:σ=1 ∨ σ=3) (hS:S⊆Icc 1 n) (hsmall:r+s≤n/16)
    (hband:(forcedBand n S v σ\B).card≤bandCost n σ B)
    (hempty:bandNeighbors n r s σ B=∅) : n-v≤highThreshold n B := by
  classical
  let τ:=4*(missingTopOdd n B).card+4
  let W:=n-4*(n/16)
  let L:=max (n+v/2) (n+τ)
  let U:=min (n+v/2+n/4) (2*W-τ-1)
  let Y:=progression L U 4 σ
  have hY (y:ℕ) (hy:y∈Y) : n+v/2<y ∧ y≤n+v/2+n/4 ∧ n+τ<y ∧ y<2*W-τ ∧ y%4=σ := by
    obtain ⟨hyI,hyσ⟩:=mem_filter.mp hy
    have hyI:=mem_Ioc.mp hyI
    dsimp only [L,U] at hyI
    have hhiq:(missingTopOdd n B).card≤totalBudget n B := by
      have hh:=deficit_split n B hd
      unfold totalBudget; omega
    dsimp only [W,τ] at *
    omega
  have hF:∀y∈Y,y∈forcedBand n S v σ ∧ y+4*r∈forcedBand n S v σ ∧ y+4*s∈forcedBand n S v σ := by
    intro y hy
    have hyI:=hY y hy
    have hmem (j:ℕ) (hj:j≤n/16) : y+4*j∈forcedBand n S v σ := by
      simp only [forcedBand,mem_filter,mem_Icc]
      refine ⟨⟨by omega,by omega⟩,by omega,?_,by omega⟩
      intro a ha
      rcases mem_insert.mp ha with rfl|ha
      · omega
      · have haI:=mem_Icc.mp (hS ha); omega
    exact ⟨by simpa using hmem 0 (by omega),hmem r (by omega),hmem s (by omega)⟩
  let G:=Y.filter (fun y=>y∈B ∧ y+4*r∈B ∧ y+4*s∈B)
  have hG:G=∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro y hy
    obtain ⟨hyY,hyB,hyr,hys⟩:=mem_filter.mp hy
    have hyI:=hY y hyY
    have hh:y∈bandNeighbors n r s σ B := by
      refine mem_filter.mpr ⟨mem_inter.mpr ⟨hyB,mem_Icc.mpr ⟨by omega,by omega⟩⟩,
        hyI.2.2.2.2,hyr,hys,hyI.2.2.1,hyI.2.2.2.1⟩
    rw [hempty] at hh
    simpa using hh
  have hloss:=triple_membership_loss Y (forcedBand n S v σ) B r s σ
    (fun y hy=>(hY y hy).2.2.2.2) hF
  change Y.card≤G.card+3*(forcedBand n S v σ\B).card at hloss
  rw [hG,card_empty,zero_add] at hloss
  have hl:=progression_lower L U 4 σ (by omega) (by omega)
  change (U-L)/4≤Y.card at hl
  have hb:=band_budget n σ B hd hσ
  have hc:(U-L)/4≤3*bandCost n σ B := by omega
  have hh:=second_band_arithmetic n v (missingTopOdd n B).card (bandCost n σ B) (totalBudget n B)
    hn hv hq hb.2.2.1 hc
  unfold highThreshold
  omega

#print axioms opposite_neighbors_empty
#print axioms high_vertex_from_empty
end OP02.SharpK5

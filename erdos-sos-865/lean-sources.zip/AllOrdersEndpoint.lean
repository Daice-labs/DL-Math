import AllKStep
import AllKLimit

open Filter
namespace OP02.AllOrders

theorem shaped_step (k : ℕ) (hk : 8 ≤ k) : Shaped (k-2) → Shaped (k-1) → Shaped k :=
  shaped_of_geometry hk (geometric_step k hk)

theorem shaped_all : ∀ k : ℕ, 6 ≤ k → Shaped k :=
  shaped_induction shaped_step

/-- Sharp fixed-order asymptotic for the least threshold on the original interval. -/
theorem sharp_limit : ∀ k : ℕ, 2 ≤ k →
    Tendsto (fun N : ℕ => (Erdos865.f N k : ℝ) / (N : ℝ)) atTop
      (nhds ((2 / 3 : ℝ) * (1 - (1 / 4 : ℝ) ^ (k - 1)))) :=
  sharp_limit_of_shaped shaped_all

theorem erdos_sos : OP02.GeneralGoal := erdos_sos_of_sharp sharp_limit

end OP02.AllOrders

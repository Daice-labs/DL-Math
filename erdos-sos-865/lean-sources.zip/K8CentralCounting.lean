import K8UpperSixTools
import K8Selection

open Finset OP02.SharpK5
namespace OP02.SharpK8

def residueCandidates (l u m : ℕ) (A : Finset ℕ) : Finset ℕ :=
  (Ioc l u).filter (fun x=>x%m∈A)

/-- All complete blocks of admissible residues inside the common interval. -/
theorem codes_supply {l u m : ℕ} {A : Finset ℕ} (period : m=32 ∨ m=2048)
    (bounded : ∀ r∈A,r < m) :
    ((u-l)/m-1)*A.card ≤ (residueCandidates l u m A).card := by
  classical
  let B := (range ((u-l)/m-1)).product A
  let f := fun h : ℕ×ℕ => m*(l/m+1+h.1)+h.2
  have inj : Set.InjOn f (B : Set (ℕ×ℕ)) := by
    intro p hp q hq eq
    obtain ⟨pb,pr⟩ := mem_product.mp hp
    obtain ⟨qb,qr⟩ := mem_product.mp hq
    have pbd := bounded _ pr
    have qbd := bounded _ qr
    dsimp [f] at eq
    apply Prod.ext <;> rcases period with rfl|rfl <;> omega
  have sub : B.image f ⊆ residueCandidates l u m A := by
    intro x hx
    obtain ⟨p,hp,rfl⟩ := mem_image.mp hx
    obtain ⟨hi,ha⟩ := mem_product.mp hp
    have ih := mem_range.mp hi
    have rb := bounded _ ha
    refine mem_filter.mpr ⟨mem_Ioc.mpr ⟨?_,?_⟩,?_⟩
    · dsimp [f]; rcases period with rfl|rfl <;> omega
    · dsimp [f]; rcases period with rfl|rfl <;> omega
    · have eq : (f p)%m=p.2 := by dsimp [f];rcases period with rfl|rfl <;> omega
      rwa [eq]
  have h := card_le_card sub
  rw [card_image_of_injOn inj] at h
  simpa [B] using h

/-- Shared inverse counts for an even candidate and its odd reflected partner.
Their two lists use disjoint parities of physical missing labels. -/
theorem reflected_selection {X F D E : Finset ℕ} {g σ k : ℕ}
    (godd : g%2=1) (xr : ∀x∈X,x≤g ∧ x%4=0 ∧ x%16=σ)
    (load : ∀ j : ℕ,(F.filter (fun f=>f%4=j)).card≤k)
    (fault : ∀ x∈X, ∀ f∈F, (x+4*f∉D → x+4*f∈E) ∧
      (g-x+4*f∉D → g-x+4*f∈E))
    (room : k*E.card<X.card) :
    ∃ x∈X, ∀f∈F, x+4*f∈D ∧ g-x+4*f∈D := by
  classical
  by_contra! no
  let fibre (h : ℕ) := X.filter (fun x=>∃ f∈F, x+4*f=h ∨ g-x+4*f=h)
  have cover : X⊆E.biUnion fibre := by
    intro x hx
    obtain ⟨f,hf,bad⟩ := no x hx
    by_cases hd : x+4*f∈D
    · have hy : g-x+4*f∉D := bad hd
      exact mem_biUnion.mpr ⟨_,(fault x hx f hf).2 hy,mem_filter.mpr ⟨hx,f,hf,Or.inr rfl⟩⟩
    · exact mem_biUnion.mpr ⟨_,(fault x hx f hf).1 hd,mem_filter.mpr ⟨hx,f,hf,Or.inl rfl⟩⟩
  let offset (h x : ℕ) := if h%2=0 then (h-x)/4 else (h+x-g)/4
  have index (h x : ℕ) (hx : x∈fibre h) :
      offset h x∈F ∧ x≤g ∧ x%16=σ ∧
      (if h%2=0 then x+4*(offset h x)=h else g-x+4*(offset h x)=h) := by
    obtain ⟨hx,f,hf,he⟩ := mem_filter.mp hx
    obtain ⟨gx,xe,xr'⟩ := xr x hx
    by_cases even : h%2=0
    · have hz : x+4*f=h := he.resolve_right (by omega)
      have ho : offset h x=f := by simp only [offset,if_pos even];omega
      exact ⟨ho.symm ▸ hf,gx,xr',by simpa only [if_pos even,ho] using hz⟩
    · have hz : g-x+4*f=h := he.resolve_left (by omega)
      have ho : offset h x=f := by simp only [offset,if_neg even];omega
      exact ⟨ho.symm ▸ hf,gx,xr',by simpa only [if_neg even,ho] using hz⟩
  have hfibre (h : ℕ) (_ : h∈E) : (fibre h).card≤k := by
    rcases (fibre h).eq_empty_or_nonempty with empty | ⟨y,hy⟩
    · simp [empty]
    obtain ⟨fy,yg,yr,ey⟩ := index h y hy
    apply le_trans _ (load ((offset h y)%4))
    apply card_le_card_of_injOn (offset h)
    · intro x hx
      obtain ⟨fx,xg,xr',ex⟩ := index h x hx
      apply mem_filter.mpr
      refine ⟨fx,?_⟩
      by_cases he : h%2=0
      · simp only [if_pos he] at ex ey;omega
      · simp only [if_neg he] at ex ey;omega
    · intro x hx t ht eq
      obtain ⟨_,xg,_,ex⟩ := index h x hx
      obtain ⟨_,tg,_,et⟩ := index h t ht
      by_cases he : h%2=0
      · simp only [if_pos he] at ex et;omega
      · simp only [if_neg he] at ex et;omega
  have h := (card_le_card cover).trans (card_biUnion_le.trans (sum_le_sum hfibre))
  simp only [sum_const,nsmul_eq_mul] at h
  change X.card≤E.card*k at h
  rw [Nat.mul_comm E.card k] at h
  omega

theorem plain_selection {P F D E : Finset ℕ}
    (fault : ∀p∈P,∀f∈F,p+f∉D→p+f∈E) (room : F.card*E.card<P.card) :
    ∃ p∈P,∀ f∈F, p+f∈D := by
  classical
  have hc := rejected_card P F E (fun f p=>p+f)
    (fun _ _ _ _ _ _ eq=>by dsimp at eq;omega)
  obtain ⟨p,hp,pass⟩ := exists_mem_notMem_of_card_lt_card (lt_of_le_of_lt hc room)
  refine ⟨p,hp,?_⟩
  intro f hf
  by_contra h
  exact pass (mem_rejected.mpr ⟨f,hf,hp,fault p hp f hf h⟩)

end OP02.SharpK8

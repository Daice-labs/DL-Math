import K7DirectPairHalf
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7.LongOddTask

/-- A favorable six-clique may have a larger repeated-residue offset W if
the actual small quartet still fits alongside the forced interval. -/
theorem flexible_favorable_six {n f W z:ℕ} {B S T:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (gap:MiddleGap7 n B)
    (hn:65536≤n) (hq:1536*totalBudget n B≤n)
    (h4:T.card=4) (hT:internalOn (quarterD n B) T) (Tmax:∀v∈T,v≤ z) (zH:4*z≤n/4)
    (hs:internalOn B S) (hc:S.card=6) (maxS:∀v∈S,v≤W) (fH:f≤n/4)
    (res:∀v∈insert 0 S,v%2=f%2→v≠f→v%4≠f%4)
    (fits:W+8*z+288*totalBudget n B+4*favTau n B+100≤n) : False := by
  classical
  let τ:=favTau n B
  let q:=totalBudget n B
  let lo:=n+f/2+τ
  let len:=144*q+24
  let faults:=(Ioc lo (lo+len+4*z)).filter (fun y=>y%2=1 ∧ y∉B)
  let base (σ:ℕ):=progression lo (lo+len) 4 σ
  let U:=passes (base 1) (quartOffsets T) B
  let V:=passes (base 3) (quartOffsets T) B
  have ft:τ≤4*q+8:=by
    have h:=missingTopOdd_le_deficit n B hd
    dsimp [τ,favTau,q];unfold totalBudget;omega
  have wn:W≤n:=by omega
  have wide:3*n≤4*(n-4*(n/16)):=by omega
  have allSmall (v:ℕ) (hv:v∈insert 0 S):v≤W:=by
    rcases mem_insert.mp hv with rfl|mem;omega;exact maxS _ mem
  have off (a:ℕ) (ha:a∈quartOffsets T):a%4=0 ∧ a≤4*z:=by
    rcases mem_insert.mp ha with rfl|aI
    · exact ⟨rfl,Nat.zero_le _⟩
    · obtain ⟨v,hv,rfl⟩:=mem_image.mp aI;have :=Tmax v hv;omega
  have yc {y:ℕ} (hy:y∈faults):
      f≤2*y ∧ 2*n+2*τ<2*y-f ∧ 2*y-f+W+2*τ<3*n ∧ y%2=1 ∧ y∉B := by
    obtain ⟨hI,yp,ya⟩:=mem_filter.mp hy
    have h:=mem_Ioc.mp hI
    change W+8*z+288*q+4*τ+100≤n at fits
    dsimp only [lo,len] at h
    exact ⟨by omega,by omega,by omega,yp,ya⟩
  have budget:faults.card≤7*q:=by
    apply failed_half_card (w:=f) hf hd hs hc
    · intro y hy;have a:=yc hy
      refine ⟨a.1,?_⟩;intro m;have :=maxS _ m;omega
    · intro y hy v hv miss
      obtain ⟨fl,pll,pu,yp,absent⟩:=yc hy
      have vw:=allSmall v hv
      have eq:2*y-f+f=2*y:=Nat.sub_add_cancel fl
      have lower:2*n<2*y-f+v:=by omega
      have upper:2*y-f+v≤4*n:=by omega
      by_cases same:v%2=f%2
      · by_cases e:v=f
        · subst v;rw [eq] at miss lower upper ⊢
          exact mem_union_left _ (mem_union_right _ (OP02.SharpK6.bootstrap_missing_target n y 0 B yp
            (by simpa using absent) (by simpa using lower) (by simpa using upper) (by simpa using miss)))
        · have op:=res v hv same e
          apply mem_union_left;apply mem_union_left
          exact missing_gap_multiple gap (by omega) miss (by change 2*n+2*τ<_;omega)
            (by change _<4*(n-4*(n/16))-2*τ;omega)
      · exact mem_union_right _ (OP02.SharpK6.bootstrap_missing_odd n _ B (by omega) lower upper miss)
  have quartBound:=quart_offset_counts (n:=n) h4 (fun v hv=>by have :=Tmax v hv;omega)
  have lots (σ:ℕ) (sr:σ<4) (so:σ%2=1) :
      q<(passes (base σ) (quartOffsets T) B).card := by
    have losses:=shift_losses (base σ) (quartOffsets T) B faults 1 0 5 (by intro y hy;omega)
      (by intro y hy a ha miss;obtain ⟨i,r⟩:=mem_filter.mp hy;have ii:=mem_Ioc.mp i;have h:=off a ha
          exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,miss⟩)
      (fun v _=>(card_filter_le _ _).trans quartBound.1)
    have nb:=progression_lower lo (lo+len) 4 σ (Or.inl rfl) sr
    change _≤(base σ).card at nb;rw [Nat.add_sub_cancel_left] at nb
    dsimp only [len] at nb;omega
  have dt {σ y:ℕ} (hy:y∈passes (base σ) (quartOffsets T) B):
      n+τ<y ∧ y≤lo+len ∧ 4*y≤7*n ∧ y%4=σ ∧ ∀a∈quartOffsets T,y+a∈B := by
    obtain ⟨hp,good⟩:=mem_filter.mp hy;obtain ⟨hI,r⟩:=mem_filter.mp hp
    have ii:=mem_Ioc.mp hI
    change 1536*q≤n at hq
    have low:lo<y:=ii.1;have up:y≤lo+len:=ii.2
    dsimp only [lo,len] at low up
    exact ⟨by omega,ii.2,by omega,r,good⟩
  have nu:q<U.card:=lots 1 (by decide) (by decide)
  have nv:q<V.card:=lots 3 (by decide) (by decide)
  have re:(fourResources n B).card≤q:=by have :=four_resource_budget n B hd;change _≤totalBudget n B;omega
  apply conflicting_neighbor_families hf hd gap hn (by omega) h4 hT
    (fun a ha=>by have :=Tmax a ha;omega) (card_pos.mp (show 0<U.card by omega)) (re.trans_lt nv)
  · intro y hy;obtain ⟨low,up,cap,par,good⟩:=dt hy;exact ⟨by omega,cap,by omega,good⟩
  · intro y hy;obtain ⟨low,up,cap,par,good⟩:=dt hy;exact ⟨by omega,cap,by omega,good⟩
  · intro y hy v hv;have hh:=dt hy;have hh':=dt hv;omega
  · intro y hy v hv miss
    obtain ⟨ly,uy,_,py,_⟩:=dt hy;obtain ⟨lv,uv,_,pv,_⟩:=dt hv
    change 1536*q≤n at hq
    dsimp only [len,lo] at uy uv
    exact missing_gap_multiple gap (by omega) miss (by change 2*n+2*τ<_;omega)
      (by change _<4*(n-4*(n/16))-2*τ;omega)

end OP02.SharpK7.LongOddTask

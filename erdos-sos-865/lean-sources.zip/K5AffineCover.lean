import K5GapReduction
open Finset
namespace OP02.SharpK5
set_option maxHeartbeats 3000000

/-- One physical union, with the load of every label proved from residue fibres.
The affine preimages may overlap; no disjointness of different offsets is assumed. -/
theorem affine_cover_bound (Y T H:Finset ℕ) (b σ k c:ℕ) (hk:0<k)
    (hy:∀y∈Y,y%4=σ)
    (hc:∀r:ℕ,(T.filter (fun s=>s%4=r)).card≤c)
    (cover:∀y∈Y,∃s∈T,∃h∈H,k*y+s=h+b) : Y.card≤c*H.card := by
  classical
  let F := fun h=>T.filter (fun s=>(s+k*σ)%4=(h+b)%4)
  have hF : ∀h:ℕ,(F h).card≤c := by
    intro h
    by_cases hn:(F h).Nonempty
    · obtain ⟨r,hr⟩ := hn
      have hs : F h⊆T.filter (fun s=>s%4=r%4) := by
        intro s hs
        obtain ⟨hsT,hse⟩ := mem_filter.mp hs
        obtain ⟨hrT,hre⟩ := mem_filter.mp hr
        exact mem_filter.mpr ⟨hsT,by omega⟩
      exact le_trans (card_le_card hs) (hc (r%4))
    · have he : F h=∅ := not_nonempty_iff_eq_empty.mp hn
      simp [he]
  let P := fun h=>(F h).image (fun s=>(h+b-s)/k)
  have hsub : Y⊆H.biUnion P := by
    intro y hY
    obtain ⟨s,hs,h,hh,he⟩ := cover y hY
    apply mem_biUnion.mpr
    refine ⟨h,hh,mem_image.mpr ⟨s,?_,?_⟩⟩
    · have hyr := hy y hY
      refine mem_filter.mpr ⟨hs,?_⟩
      have hmod := congrArg (fun x:ℕ=>x%4) he
      have hσ : σ%4=σ := by omega
      have hm : (k*y)%4=(k*σ)%4 := by
        rw [Nat.mul_mod k y 4,Nat.mul_mod k σ 4,hyr,hσ]
      have hm1 := Nat.add_mod (k*y) s 4
      have hm2 := Nat.add_mod s (k*σ) 4
      omega
    · have hsub : h+b-s=k*y := by omega
      rw [hsub]
      exact Nat.mul_div_cancel_left y hk
  calc
    Y.card≤(H.biUnion P).card := card_le_card hsub
    _≤∑h∈H,(P h).card := card_biUnion_le
    _≤∑h∈H,c := by
      apply sum_le_sum
      intro h hh
      exact le_trans card_image_le (hF h)
    _=c*H.card := by simp [Nat.mul_comm]

/-- Explicit extension of a four-clique. Repeated sum labels are not excluded. -/
theorem four_clique_missing_label (B S:Finset ℕ) (hf:FiveFree B)
    (hs:S⊆B) (hc:S.card=4) (hpairs:∀x∈S,∀y∈S,x≠y→x+y∈B)
    (p:ℕ) (hp:p∉S) : ∃s∈insert 0 S,p+s∉B := by
  classical
  by_contra hh
  push_neg at hh
  have hpB : p∈B := by simpa using hh 0 (by simp)
  have hsum : ∀x∈S,p+x∈B := fun x hx=>hh x (mem_insert_of_mem hx)
  apply hf
  refine ⟨insert p S,insert_subset hpB hs,by simp [hp,hc],?_⟩
  intro x hx y hy hxy
  rcases mem_insert.mp hx with hxp|hxS
  · subst x
    rcases mem_insert.mp hy with hyp|hyS
    · exact False.elim (hxy hyp.symm)
    · exact hsum y hyS
  · rcases mem_insert.mp hy with hyp|hyS
    · subst y
      simpa [Nat.add_comm] using hsum x hxS
    · exact hpairs x hxS y hyS hxy

#print axioms affine_cover_bound
#print axioms four_clique_missing_label
end OP02.SharpK5

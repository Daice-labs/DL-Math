import K5Arithmetic
namespace OP02.SharpK6
set_option maxHeartbeats 1000000

/-- Both endpoint clips are retained. The small budget excludes every branch
of min/max except the one that forces the designated vertex near n. -/
theorem second_band_arithmetic (n v hi k q:ℕ) (hn:65536≤n) (hv:v≤n)
    (hq:512*q≤n) (hk:4*k+hi≤16*q)
    (hc:(min (n+v/2+n/4) (2*(n-4*(n/16))-(4*hi+4)-1)-
      max (n+v/2) (n+4*hi+4))/4≤4*k) : n-v≤32*k+8*hi+16 := by
  omega


#print axioms second_band_arithmetic
end OP02.SharpK6

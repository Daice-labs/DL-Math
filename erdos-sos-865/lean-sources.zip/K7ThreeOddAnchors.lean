import K7CompleteO2
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

theorem odd_triple_source {S:Finset ℕ} (hh:(oddOffsets S).card=3) (hm:¬sameOdd S) :
    ∃p x y:ℕ,x<y ∧ x∈S ∧ y∈S ∧ p∈S ∧ p%2=1 ∧ x%2=1 ∧ y%2=1 ∧
      p%4≠x%4 ∧ x%4=y%4 ∧ (∀v∈S,v%2=1→v=p ∨ v=x ∨ v=y) ∧
      (∀v∈S,v%2=p%2→v≠p→v%4≠p%4):=by
  classical
  obtain ⟨a,b,c,ab,ac,bc,eq⟩:=card_eq_three.mp hh
  have cert {i j p:ℕ} (order:i≠j) (sm:i%4=j%4) (op:p%4≠i%4)
      (ii:i∈S ∧ i%2=1) (jj:j∈S ∧ j%2=1) (pp:p∈S ∧ p%2=1)
      (all:∀v∈S,v%2=1→v=p ∨ v=i ∨ v=j):
      ∃p x y:ℕ,x<y ∧ x∈S ∧ y∈S ∧ p∈S ∧ p%2=1 ∧ x%2=1 ∧ y%2=1 ∧
        p%4≠x%4 ∧ x%4=y%4 ∧ (∀v∈S,v%2=1→v=p ∨ v=x ∨ v=y) ∧
        (∀v∈S,v%2=p%2→v≠p→v%4≠p%4):=by
    have f (v:ℕ) (hv:v∈S) (vp:v%2=p%2) (ne:v≠p):v%4≠p%4:=by
      have :=all _ hv (vp.trans pp.2);omega
    rcases lt_or_gt_of_ne order with lt|gt
    · exact ⟨p,i,j,lt,ii.1,jj.1,pp.1,pp.2,ii.2,jj.2,op,sm,all,f⟩
    · refine ⟨p,j,i,gt,jj.1,ii.1,pp.1,pp.2,jj.2,ii.2,by omega,sm.symm,?_,f⟩
      intro v hv vo;rcases all v hv vo with h|h|h;exact Or.inl h;exact Or.inr (Or.inr h);exact Or.inr (Or.inl h)
  have aa:=mem_filter.mp (show a∈oddOffsets S by simp [eq])
  have bb:=mem_filter.mp (show b∈oddOffsets S by simp [eq])
  have cc:=mem_filter.mp (show c∈oddOffsets S by simp [eq])
  have all (v:ℕ) (hv:v∈S) (vo:v%2=1):v=a ∨ v=b ∨ v=c:=by
    have ov:v∈oddOffsets S:=mem_filter.mpr ⟨hv,vo⟩;simpa only [eq,mem_insert,mem_singleton] using ov
  have notmono:¬(a%4=b%4 ∧ a%4=c%4):=by
    rintro ⟨h1,h2⟩;apply hm;refine ⟨a%4,by omega,by omega,?_⟩
    intro v hv vo;have :=all _ hv vo;omega
  by_cases h:a%4=b%4
  · apply cert ab h (by omega : c%4≠a%4) aa bb cc
    intro v hv vo;have :=all _ hv vo;omega
  by_cases k:a%4=c%4
  · apply cert ac k (Ne.symm h) aa cc bb
    intro v hv vo;have :=all _ hv vo;omega
  · apply cert bc (by omega) h bb cc aa all

end OP02.SharpK7.LongOddTask

import K6GapResources
open Finset
namespace OP02.SharpK6
open OP02.SharpK5
set_option maxHeartbeats 3000000

/-- One physical union, with the load of every label proved from residue fibres.
The affine preimages may overlap; no disjointness of different offsets is assumed. -/
theorem affine_cover_bound8 (Y T H:Finset ℕ) (b σ k c:ℕ) (hk:0<k)
    (hy:∀y∈Y,y%8=σ)
    (hc:∀r:ℕ,(T.filter (fun s=>s%8=r)).card≤c)
    (cover:∀y∈Y,∃s∈T,∃h∈H,k*y+s=h+b) : Y.card≤c*H.card := by
  classical
  let F := fun h=>T.filter (fun s=>(s+k*σ)%8=(h+b)%8)
  have hF : ∀h:ℕ,(F h).card≤c := by
    intro h
    by_cases hn:(F h).Nonempty
    · obtain ⟨r,hr⟩ := hn
      have hs : F h⊆T.filter (fun s=>s%8=r%8) := by
        intro s hs
        obtain ⟨hsT,hse⟩ := mem_filter.mp hs
        obtain ⟨hrT,hre⟩ := mem_filter.mp hr
        exact mem_filter.mpr ⟨hsT,by omega⟩
      exact le_trans (card_le_card hs) (hc (r%8))
    · have he : F h=∅ := not_nonempty_iff_eq_empty.mp hn
      simp [he]
  let P := fun h=>(F h).image (fun s=>(h+b-s)/k)
  have hsub : Y⊆H.biUnion P := by
    intro y hY
    obtain ⟨s,hs,h,hh,he⟩ := cover y hY
    apply mem_biUnion.mpr
    refine ⟨h,hh,mem_image.mpr ⟨s,?_,?_⟩⟩
    · have hyr := hy y hY
      refine mem_filter.mpr ⟨hs,?_⟩
      have hmod := congrArg (fun x:ℕ=>x%8) he
      have hσ : σ%8=σ := by omega
      have hm : (k*y)%8=(k*σ)%8 := by
        rw [Nat.mul_mod k y 8,Nat.mul_mod k σ 8,hyr,hσ]
      have hm1 := Nat.add_mod (k*y) s 8
      have hm2 := Nat.add_mod s (k*σ) 8
      omega
    · have hsub : h+b-s=k*y := by omega
      rw [hsub]
      exact Nat.mul_div_cancel_left y hk
  calc
    Y.card≤(H.biUnion P).card := card_le_card hsub
    _≤∑h∈H,(P h).card := card_biUnion_le
    _≤∑h∈H,c := by
      apply sum_le_sum
      intro h hh
      exact le_trans card_image_le (hF h)
    _=c*H.card := by simp [Nat.mul_comm]


#print axioms affine_cover_bound8
end OP02.SharpK6

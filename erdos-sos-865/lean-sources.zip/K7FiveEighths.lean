import K7Testers
open Finset OP02.FewHole OP02.SharpK5
namespace OP02.SharpK7

/-- Only actual triangles, including all three of their sum labels, are tested. -/
def Profile123 (Y : Finset ℕ) : Prop :=
  ∀ a∈Y,∀ c∈Y,∀ z∈Y,a<c→c<z→a+c∈Y→a+z∈Y→c+z∈Y→
    ({a%4,c%4,z%4} : Finset ℕ)={1,2,3}

private theorem residue_profile {a c z : ℕ} (h : ({a%4,c%4,z%4} : Finset ℕ)={1,2,3}) :
    z%4≠0 ∧ (¬(a%2=0 ∧ c%2=0)) ∧ ¬(a%4=c%4 ∧ z%2=0) := by
  have hz : z%4∈({1,2,3} : Finset ℕ) := h ▸ (by simp)
  have h₁ : 1∈({a%4,c%4,z%4} : Finset ℕ) := h.symm ▸ (by decide)
  have h₃ : 3∈({a%4,c%4,z%4} : Finset ℕ) := h.symm ▸ (by decide)
  simp only [mem_insert,mem_singleton] at hz h₁ h₃
  omega

private theorem odd_empty {t x : ℕ} {Y : Finset ℕ} (h₁ : 2*(t/4)<x)
    (h₂ : x≤t) (h₃ : x%2=1) (h₄ : x∉Y) : x∈emptyOuter t Y :=
  (singleton_empty_iff t x Y (mem_Ioc.mpr ⟨h₁,h₂⟩) (Or.inl ⟨x/2,by omega⟩)).mpr h₄

/-- Proposition S restricted EE, OS and OP tests at the largest even sum. The odd-pair tests apply only when every occupied pair there is odd. -/
def RestrictedClear (t : ℕ) (Y : Finset ℕ) : Prop :=
  (t/4+1)/2<(prefixRoots (t/4) Y).card →
  ∀ a∈Y,∀ c∈Y,∀ z∈Y,0<a→a<c→c<z→a+c≤t/4→a+c∈Y→
    (∀v∈prefixRoots (t/4) Y,v%2=0→v≤a+c)→
    2*(t/4)<z→z≤3*(t/4)+1→
    ((a%2=0 ∧ c%2=0 ∧ z%2=1) ∨
      (a%2=1 ∧ c%2=1 ∧ (∀v∈reflectionPairs (prefixRoots (t/4) Y) (a+c), v%2=1) ∧
        ((a%4=c%4 ∧ z%2=0) ∨ (a%4≠c%4 ∧ z%4=0))))→
    z+a∉Y ∨ z+c∉Y

theorem restricted_of_profile {t : ℕ} {Y : Finset ℕ} (hp:Profile123 Y) :
    RestrictedClear t Y := by
  intro _ a ha c hc z hz _ hac hcz _ he _ _ _ hh
  by_contra! bad
  have hr:=residue_profile (hp a ha c hc z hz hac hcz he
    (by simpa only [Nat.add_comm] using bad.1) (by simpa only [Nat.add_comm] using bad.2))
  rcases hh with hh|⟨_,_,_,hh|hh⟩
  · exact hr.2.1 ⟨hh.1,hh.2.1⟩
  · exact hr.2.2 hh
  · exact hr.1 hh.2

/-- A single actually occupied even pair forces empty singleton classes of
the outer partition. A given missing physical label spoils at most three tests. -/
theorem even_pair_empty {t a c : ℕ} {Y : Finset ℕ} (h : RestrictedClear t Y) (hpos:(t/4+1)/2<(prefixRoots (t/4) Y).card)
    (ha : a∈Y) (hc:c∈Y) (he:a+c∈Y) (ha₀:0<a) (hac:a<c)
    (heN:a+c≤t/4) (hmax:∀v∈prefixRoots (t/4) Y,v%2=0→v≤a+c) (hae:a%2=0) (hce:c%2=0) :
    t/4/2+1≤3*(emptyOuter t Y).card := by
  let W:=oddTestWindow (t/4)
  let O : Finset ℕ:={0,a,c}
  have hpass : passes W O Y=∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro z hz
    obtain ⟨hzW,hh⟩:=mem_filter.mp hz
    have hw:=oddTestWindow_mem hzW
    have hzY : z∈Y := by simpa using hh 0 (by simp [O])
    rcases h hpos a ha c hc z hzY ha₀ hac (by omega) heN he hmax hw.1 hw.2.1
        (Or.inl ⟨hae,hce,hw.2.2⟩) with hn|hn
    · exact hn (hh a (by simp [O]))
    · exact hn (hh c (by simp [O]))
  have hh:=shift_losses W O Y (emptyOuter t Y) 1 0 3 (by intro;intro;omega)
    (by
      intro z hz d hd hn
      have hp:=oddTestWindow_mem hz
      change d∈({0,a,c}:Finset ℕ) at hd
      simp only [mem_insert,mem_singleton] at hd
      rcases hd with rfl|rfl|rfl <;> apply odd_empty _ _ _ hn <;> omega)
    (fun _ _=>(card_filter_le _ _).trans card_le_three)
  rwa [hpass,card_empty,zero_add,show W.card=t/4/2+1 from oddTestWindow_card _] at hh

/-- At one actual rigid tester the full set of odd occupied pairs is charged
by an injection to empty singleton classes; no choice of an extra pair is assumed. -/
theorem odd_pairs_empty {t e w : ℕ} {Y : Finset ℕ} (h : RestrictedClear t Y) (hpos:(t/4+1)/2<(prefixRoots (t/4) Y).card)
    (he:e∈prefixRoots (t/4) Y) (hee:e%2=0)
    (hmaximal:∀v∈prefixRoots (t/4) Y,v%2=0→v≤e)
    (hp:∀a∈reflectionPairs (prefixRoots (t/4) Y) e,a%2=1)
    (hw:w∈rigidPresent (t/4) Y) :
    (reflectionPairs (prefixRoots (t/4) Y) e).card≤(emptyOuter t Y).card := by
  classical
  let P:=reflectionPairs (prefixRoots (t/4) Y) e
  let f (a:ℕ):=if 4*w+a∉Y then 4*w+a else 4*w+(e-a)
  have hwin:=rigid_bounds (mem_filter.mp hw).1
  have hz:4*w∈Y:=(mem_filter.mp hw).2
  have hmax: e≤t/4:=(mem_Icc.mp (mem_inter.mp he).2).2
  have hp' a (hx:a∈P):0<a ∧ a<e-a ∧ 4*w+(if 4*w+a∉Y then a else e-a)∉Y := by
    obtain ⟨ha,h₁,h₂,hc⟩:=mem_filter.mp hx
    refine ⟨h₁,h₂,?_⟩
    by_cases hh : 4*w+a∈Y
    · simp only [hh,not_true_eq_false,ite_false]
      intro hbad
      have ho:=hp a hx
      have hv:=h hpos a (mem_inter.mp ha).1 (e-a) (mem_inter.mp hc).1 (4*w) hz h₁ h₂
        (by omega) (by omega) (by simpa [show a+(e-a)=e by omega] using (mem_inter.mp he).1)
        (by simpa [show a+(e-a)=e by omega] using hmaximal)
        (by omega) (by omega) (Or.inr ⟨ho,by omega,by simpa [show a+(e-a)=e by omega] using hp,
          by by_cases ha4 : a%4=(e-a)%4; exact Or.inl ⟨ha4,by omega⟩; exact Or.inr ⟨ha4,by omega⟩⟩)
      exact hv.elim (fun hn=>hn hh) (fun hn=>hn hbad)
    · simpa [hh] using hh
  apply card_le_card_of_injOn f
  · intro a hx
    have hₐ:=hp' a hx;have ho:=hp a hx
    by_cases hh:4*w+a∈Y
    · have hn:=hₐ.2.2
      simp only [hh,not_true_eq_false,ite_false] at hn
      simp only [f,hh,not_true_eq_false,ite_false]
      apply odd_empty _ _ _ hn <;> omega
    · simp only [f,hh,not_false_eq_true,ite_true]
      apply odd_empty _ _ _ hh <;> omega
  · intro a ha c hc heq
    have h₁:=hp' a ha;have h₂:=hp' c hc
    unfold f at heq;split_ifs at heq <;> omega

/-- The exact finite five-eighths theorem, including all t mod 4 and empty
supports. Natural subtraction implements the positive part of the two corrections. -/
theorem restricted_five_eighths_exact (t : ℕ) (Y : Finset ℕ) (hs:Y⊆Icc 1 t)
    (hd:DoublingFree Y) (hp:RestrictedClear t Y) :
    Y.card ≤ (t/4+1)/2+(t-2*(t/4))+
      max (chainCapacity (t/4/4)-(t/4/2+3)/3)
          (chainCapacity (t/4/4)-(rigidOwners (t/4)).card) := by
  classical
  let N:=t/4;let S:=prefixRoots N Y;let r:=(emptyOuter t Y).card
  let κ:=chainCapacity (N/4);let R:=rigidOwners N
  have hpart:=shell_count t Y hd
  rw [show prefixRoots t Y=Y from inter_eq_left.mpr hs] at hpart
  change Y.card+r=S.card+(t-2*N) at hpart
  have hdS:DoublingFree S:=fun x hx hx2=>hd x (mem_inter.mp hx).1 (mem_inter.mp hx2).1
  have hcap:=chain_capacity_with_top_loss N S inter_subset_right hdS
  rw [canonical_capacity_recurrence] at hcap
  change S.card+(topMissing N S).card≤(N+1)/2+κ at hcap
  change Y.card≤(N+1)/2+(t-2*N)+ max (κ-(N/2+3)/3) (κ-R.card)
  by_cases hbig:(N+1)/2<S.card
  · obtain ⟨e,he,hee,hmaximal,hcnt⟩:=find_reflection_sum N S inter_subset_right hdS hbig
    by_cases hEE:∃a∈reflectionPairs S e,a%2=0
    · obtain ⟨a,ha,hae⟩:=hEE
      obtain ⟨haS,ha₀,hac,hcS⟩:=mem_filter.mp ha
      have hc:=even_pair_empty (t:=t) hp hbig (mem_inter.mp haS).1 (mem_inter.mp hcS).1
        (by simpa [show a+(e-a)=e by omega] using (mem_inter.mp he).1) ha₀ hac
        (by have := (mem_Icc.mp (mem_inter.mp he).2).2;dsimp [N] at *;omega)
        (by simpa [show a+(e-a)=e by omega] using hmaximal) hae (by omega)
      change N/2+1≤3*r at hc; omega
    · have hall:∀a∈reflectionPairs S e,a%2=1:=by
        intro a ha;have hh : a%2≠0:=fun h₀=>hEE ⟨a,ha,h₀⟩;omega
      by_cases hw:(rigidPresent N Y).Nonempty
      · obtain ⟨w,hw⟩:=hw
        have hc:=odd_pairs_empty hp hbig he hee hmaximal hall hw
        change (reflectionPairs S e).card≤r at hc;omega
      · have hz:(rigidPresent N Y).card=0:=by
          rw [not_nonempty_iff_eq_empty.mp hw];rfl
        have ht:4≤t:=by
          by_contra! ht
          have hf:N=0:=by dsimp [N];omega
          have hκ:κ=0:=by simp [κ,hf,chainCapacity,canonicalSlots]
          omega
        have hr:=rigid_charge t Y hd ht
        have hle : ((emptyOuter t Y).filter (fun v=>v%2=0)).card≤r:=card_filter_le _ _
        change R.card≤(rigidPresent N Y).card+_+(topMissing N S).card at hr
        omega
  · omega

theorem five_eighths_exact (t : ℕ) (Y : Finset ℕ) (hs:Y⊆Icc 1 t)
    (hd:DoublingFree Y) (hp:Profile123 Y) :
    Y.card ≤ (t/4+1)/2+(t-2*(t/4))+
      max (chainCapacity (t/4/4)-(t/4/2+3)/3)
          (chainCapacity (t/4/4)-(rigidOwners (t/4)).card) :=
  restricted_five_eighths_exact t Y hs hd (restricted_of_profile hp)

end OP02.SharpK7

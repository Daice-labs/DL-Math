import K5CapacityError
import K4Uniform
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 3000000

def totalBudget (n:ℕ) (B:Finset ℕ) := deficit n B+(excessHoles n B).card

def PositiveGap (β:ℝ) (n:ℕ) (B:Finset ℕ) : Prop :=
  (5/32:ℝ)*n+β*n≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ)

/-- Entire preliminary reduction, with all conditions derived from the same
actual FiveFree set and a positive target violation. -/
theorem positive_gap_reduction (hD:Dousse5) (β:ℝ) (hβ:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→FiveFree B→DoublingFree B→PositiveGap β n B→
      1024≤n ∧ 128*totalBudget n B≤n ∧
      3*(chainDeficit n B+totalBudget n B)<n/32 ∧
      ¬FourFree (lower n B) ∧
      (∃r∈quarterD n B,∃s∈quarterD n B,r≠s ∧ r+s∈quarterD n B ∧ r+s≤n/16) ∧
      ((chainDeficit n B+totalBudget n B:ℕ):ℝ)≤(n:ℝ)/96-(β/2)*n := by
  obtain ⟨N0,h0⟩ := positive_gap_canonical_budget β hβ
  obtain ⟨N1,h1⟩ := OP02.SharpK4.fourfree_uniform (dousse4_of_dousse5 hD) β hβ
  obtain ⟨N2,h2⟩ := OP02.SharpK4.fourfree_uniform (dousse4_of_dousse5 hD) (β/2) (by positivity)
  obtain ⟨N3,h3⟩ := exists_nat_gt (4/β)
  refine ⟨max 1024 (max N0 (max (4*N1) (max N2 N3))),?_⟩
  intro n hn B hs hf hd hgap
  have hn1024 : 1024≤n := le_trans (le_max_left _ _) hn
  have hn0 : N0≤n := by omega
  have hn1 : N1≤n/4 := by omega
  have hn2 : N2≤n := by omega
  have hn3 : N3≤n := by omega
  have hn3r : (N3:ℝ)≤n := by exact_mod_cast hn3
  have hβn : (4:ℝ)<β*n := by
    have hdiv := lt_of_lt_of_le h3 hn3r
    have := (div_lt_iff₀ hβ).mp hdiv
    linarith
  have hbudget := h0 n hn0 B hd hgap
  simp only [Nat.add_assoc] at hbudget
  change ((chainDeficit n B+totalBudget n B:ℕ):ℝ)≤(n:ℝ)/96-(β/2)*n at hbudget
  have hqNon : (0:ℝ)≤chainDeficit n B := by positivity
  have hqSmall : 96*totalBudget n B≤n := by
    have hr : (96:ℝ)*totalBudget n B≤n := by push_cast at hbudget; nlinarith
    exact_mod_cast hr
  have hE : (Ho n B).card≤(excessHoles n B).card := card_le_card (filter_subset _ _)
  have hHo : 10*(Ho n B).card<n := by unfold totalBudget at hqSmall; omega
  have hrootFour := quarter_four_free n B hf hHo
  have hdc := h1 (n/4) hn1 (quarterD n B) (filter_subset _ _) hrootFour
  have hn4 : (4:ℝ)*(n/4:ℕ)≤n := by exact_mod_cast (show 4*(n/4)≤n by omega)
  change (5/32:ℝ)*n+β*n≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) at hgap
  have hq128 : 128*totalBudget n B≤n := by
    have hr : (128:ℝ)*totalBudget n B≤n := by
      nlinarith [mul_nonneg (le_of_lt hβ) (show (0:ℝ)≤n-4*(n/4:ℕ) by linarith)]
    exact_mod_cast hr
  have hcanon : 3*(chainDeficit n B+totalBudget n B)<n/32 := by
    have hr : (96:ℝ)*(chainDeficit n B+totalBudget n B:ℕ)+32≤n := by
      push_cast at hbudget ⊢
      nlinarith
    have hi : 96*(chainDeficit n B+totalBudget n B)+32≤n := by exact_mod_cast hr
    omega
  have hlow : ¬FourFree (lower n B) := by
    intro hl
    have hu := h2 n hn2 (lower n B) (inter_subset_right) hl
    have hcard := lower_card_eq n B
    have hres := residue_card_le n B hd
    have hc : (lower n B).card+deficit n B=(n+1)/2+(quarterD n B).card := by unfold deficit; omega
    have hcr : ((lower n B).card:ℝ)+deficit n B=((n+1)/2:ℕ)+(quarterD n B).card := by exact_mod_cast hc
    have hn2r : (n:ℝ)≤2*((n+1)/2:ℕ) := by exact_mod_cast (show n≤2*((n+1)/2) by omega)
    have hEnon : (0:ℝ)≤(excessHoles n B).card := by positivity
    unfold totalBudget at hgap
    push_cast at hgap
    nlinarith
  have hdense : 32*(quarterD n B).card>5*n+52 := by
    have hqnon : (0:ℝ)≤totalBudget n B := by positivity
    have hr : (5:ℝ)*n+52<32*(quarterD n B).card := by nlinarith
    exact_mod_cast hr
  exact ⟨hn1024,hq128,hcanon,hlow,small_root_edge n B hd hdense,hbudget⟩

#print axioms positive_gap_reduction
end OP02.SharpK5

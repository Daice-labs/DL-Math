import RetainedPivot

open Finset

namespace OP02.FewHole

/-- Exactly the forbidden configuration in the campaign's extremal specification. -/
def FourFree (B : Finset ℕ) : Prop :=
  ¬ ∃ S ⊆ B, S.card = 4 ∧
    ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ B

def DoublingFree (B : Finset ℕ) : Prop := ∀ x ∈ B, 2 * x ∉ B

def lower (n : ℕ) (B : Finset ℕ) := B ∩ Icc 1 n
def middle (n : ℕ) (B : Finset ℕ) := B ∩ Icc (n + 1) (2 * n)
def upper (n : ℕ) (B : Finset ℕ) := B ∩ Icc (2 * n + 1) (4 * n)
def holes (n : ℕ) (B : Finset ℕ) := Icc (2 * n + 1) (4 * n) \ B
def excessHoles (n : ℕ) (B : Finset ℕ) :=
  holes n B \ (middle n B).image (fun x => 2 * x)

/-- The common pivot makes a lower-quarter triple into a forbidden quadruple.
This implication itself does not need doubling-freeness. -/
theorem lower_triple_free (n : ℕ) (B : Finset ℕ)
    (hfour : FourFree B) (hfew : 4 * (holes n B).card < n) :
    Erdos865.IsTripleFree (lower n B) := by
  classical
  intro htri
  obtain ⟨a, ha, b, hb, c, hc, hab, hac, hbc, habs, hacs, hbcs⟩ := htri
  have haB := (mem_inter.mp ha).1
  have hbB := (mem_inter.mp hb).1
  have hcB := (mem_inter.mp hc).1
  have han := (mem_Icc.mp (mem_inter.mp ha).2).2
  have hbn := (mem_Icc.mp (mem_inter.mp hb).2).2
  have hcn := (mem_Icc.mp (mem_inter.mp hc).2).2
  let S : Finset ℕ := {a, b, c}
  have hS : S ⊆ Icc 1 n := by
    intro x hx
    simp only [S, mem_insert, mem_singleton] at hx
    rcases hx with rfl | rfl | rfl
    · exact (mem_inter.mp ha).2
    · exact (mem_inter.mp hb).2
    · exact (mem_inter.mp hc).2
  have hSc : S.card = 3 := by simp [S, hab, hac, hbc]
  have hprem : (S.card + 1) * (Icc (2 * n + 1) (4 * n) \ B).card < n := by
    simpa [hSc, holes] using hfew
  obtain ⟨h, hhB, hhn, hsum⟩ := OP02Candidate.result n B S hS hprem
  have hhS : h ∉ S := by
    intro hh
    have := (mem_Icc.mp (hS hh)).2
    omega
  have hSB : S ⊆ B := by
    intro x hx
    simp only [S, mem_insert, mem_singleton] at hx
    rcases hx with rfl | rfl | rfl <;> assumption
  have hpair : ∀ x ∈ S, ∀ y ∈ S, x ≠ y → x + y ∈ B := by
    have habB := (mem_inter.mp habs).1
    have hacB := (mem_inter.mp hacs).1
    have hbcB := (mem_inter.mp hbcs).1
    intro x hx y hy hxy
    simp only [S, mem_insert, mem_singleton] at hx hy
    rcases hx with rfl | rfl | rfl <;>
      rcases hy with rfl | rfl | rfl <;> simp_all [add_comm]
  apply hfour
  refine ⟨insert h S, insert_subset hhB hSB, ?_, ?_⟩
  · simp [hhS, hSc]
  · intro x hx y hy hxy
    rcases mem_insert.mp hx with hxh | hxS
    · subst x
      rcases mem_insert.mp hy with hyh | hyS
      · exact (hxy hyh.symm).elim
      · exact hsum y hyS
    · rcases mem_insert.mp hy with hyh | hyS
      · subst y
        simpa [add_comm] using hsum x hxS
      · exact hpair x hxS y hyS hxy

/-- Exact finite accounting. Doubling-freeness places every doubled middle
element in the upper-half holes; the remaining holes are counted explicitly. -/
theorem counting_identity (n : ℕ) (B : Finset ℕ)
    (hsub : B ⊆ Icc 1 (4 * n)) (hdbl : DoublingFree B) :
    B.card + (excessHoles n B).card = 2 * n + (lower n B).card := by
  classical
  have hpartition : B = lower n B ∪ middle n B ∪ upper n B := by
    ext x
    simp only [lower, middle, upper, mem_union, mem_inter, mem_Icc]
    constructor
    · intro hx
      have hbounds := mem_Icc.mp (hsub hx)
      by_cases hxn : x ≤ n
      · exact Or.inl (Or.inl ⟨hx, hbounds.1, hxn⟩)
      · by_cases hx2n : x ≤ 2 * n
        · exact Or.inl (Or.inr ⟨hx, by omega, hx2n⟩)
        · exact Or.inr ⟨hx, by omega, hbounds.2⟩
    · intro hx
      tauto
  have hd1 : Disjoint (lower n B) (middle n B) := by
    apply disjoint_left.mpr
    intro x hx hy
    have := mem_Icc.mp (mem_inter.mp hx).2
    have := mem_Icc.mp (mem_inter.mp hy).2
    omega
  have hd2 : Disjoint (lower n B ∪ middle n B) (upper n B) := by
    apply disjoint_left.mpr
    intro x hx hy
    have hy' := mem_Icc.mp (mem_inter.mp hy).2
    rcases mem_union.mp hx with hx | hx
    · have := mem_Icc.mp (mem_inter.mp hx).2
      omega
    · have := mem_Icc.mp (mem_inter.mp hx).2
      omega
  have hcB : B.card = (lower n B).card + (middle n B).card + (upper n B).card := by
    conv_lhs => rw [hpartition]
    rw [card_union_of_disjoint hd2, card_union_of_disjoint hd1]
  have hupper : (holes n B).card + (upper n B).card = 2 * n := by
    have h := card_sdiff_add_card_inter (Icc (2 * n + 1) (4 * n)) B
    have hi : (Icc (2 * n + 1) (4 * n)).card = 2 * n := by
      rw [Nat.card_Icc]
      omega
    simpa [holes, upper, inter_comm, hi] using h
  have himage : (middle n B).image (fun x => 2 * x) ⊆ holes n B := by
    intro x hx
    obtain ⟨q, hq, rfl⟩ := mem_image.mp hx
    have hqB := (mem_inter.mp hq).1
    have hqb := mem_Icc.mp (mem_inter.mp hq).2
    exact mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega, by omega⟩, hdbl q hqB⟩
  have hicard : ((middle n B).image (fun x => 2 * x)).card = (middle n B).card := by
    apply card_image_of_injective
    intro x y hxy
    change 2 * x = 2 * y at hxy
    omega
  have he := card_sdiff_add_card_eq_card himage
  change (excessHoles n B).card + ((middle n B).image (fun x => 2 * x)).card =
    (holes n B).card at he
  rw [hicard] at he
  omega

/-- Stronger finite few-hole theorem, retaining the benefit of excess holes. -/
theorem few_holes_with_excess (n : ℕ) (B : Finset ℕ)
    (hsub : B ⊆ Icc 1 (4 * n)) (hfour : FourFree B)
    (hdbl : DoublingFree B) (hfew : 4 * (holes n B).card < n) :
    8 * B.card + 8 * (excessHoles n B).card ≤ 21 * n + 53 := by
  have htri := lower_triple_free n B hfour hfew
  have hk3 := Erdos865.erdos865_upper_bound n (lower n B) inter_subset_right htri
  have hcount := counting_identity n B hsub hdbl
  omega

/-- Requested finite theorem. The structural hypotheses are explicit. -/
theorem few_holes (n : ℕ) (B : Finset ℕ)
    (hsub : B ⊆ Icc 1 (4 * n)) (hfour : FourFree B)
    (hdbl : DoublingFree B) (hfew : 4 * (holes n B).card < n) :
    8 * B.card ≤ 21 * n + 53 := by
  have := few_holes_with_excess n B hsub hfour hdbl hfew
  omega

end OP02.FewHole

import AllKSpec
import K7Blocks
import K4Uniform

open Finset OP02.SharpK7
namespace OP02.AllOrders

/-- Original interval, all floors retained, including zero-length bands. -/
theorem band_lower (k N : ℕ) (hk : 2 ≤ k) :
    1 + (∑ j ∈ range (k - 1), (4 : ℕ) ^ j) * (N / (2 * 4 ^ (k - 2)))
      ≤ Erdos865.f N k := by
  let D := 2 * 4^(k-2)
  let m := N / D
  let A := geometricBlocks m (k-1)
  have hd : D*m≤N := by simpa [D,m,Nat.mul_comm] using Nat.div_mul_le_self N D
  have hp : 4^(k-1) = 4^(k-2)*4 := by
    rw [show k-1=(k-2)+1 by omega, pow_succ]
  have hA : A⊆Icc 1 N := by
    intro x hx
    obtain ⟨h1,h2⟩ := blocks_range m (k-1) x hx
    rw [hp] at h2
    change (2*4^(k-2))*m≤N at hd
    exact mem_Icc.mpr ⟨h1, by nlinarith only [h2,hd]⟩
  have hc : A.card = (∑ j ∈ range (k-1),4^j)*m := by
    change (geometricBlocks m (k-1)).card = _
    rw [blocks_card,sum_mul]
  by_contra! hh
  have hf : Erdos865.f N k ≤ A.card := by rw [hc]; dsimp [m,D]; omega
  obtain ⟨S,hS,hSc,hpS⟩ := OP02.SharpK4.threshold_spec N k A hA hf
  have := blocks_clique_size m (k-1) S hS hpS
  omega

theorem coeff_band (k : ℕ) (hk : 2≤k) :
    coeff k * (2 * 4 ^ (k-2) : ℕ) = (∑ j ∈ range (k-1), (4:ℕ)^j : ℕ) := by
  obtain ⟨n,rfl⟩ := Nat.exists_eq_add_of_le hk
  have h1 : 2+n-1 = n+1 := by omega
  have h2 : 2+n-2 = n := by omega
  simp only [coeff,h1,h2,Nat.cast_mul,Nat.cast_ofNat,Nat.cast_pow,Nat.cast_sum]
  have geom := geom_sum_mul (4 : ℝ) (n+1)
  rw [one_div,inv_pow,pow_succ] 
  have hn : (4:ℝ)^n ≠ 0 := by positivity
  field_simp
  rw [pow_succ] at geom
  nlinarith only [geom]

theorem coeff_pos (k : ℕ) (hk : 2≤k) : 0<coeff k := by
  unfold coeff
  have := pow_lt_one₀ (show (0:ℝ)≤1/4 by norm_num) (show (1/4:ℝ)<1 by norm_num)
    (show k-1≠0 by omega)
  positivity

/-- A lower bound with absolute error independent of the interval length. -/
theorem band_lower_real (k N : ℕ) (hk : 2≤k) :
    coeff k * (N:ℝ) ≤ (Erdos865.f N k:ℝ) + (∑ j ∈ range (k-1), (4:ℕ)^j : ℕ) := by
  let D := 2*4^(k-2)
  let b := ∑ j ∈ range (k-1), (4:ℕ)^j
  have hD : 0<D := by dsimp [D]; positivity
  have hr : N ≤ D*(N/D)+D := by
    have := Nat.mod_add_div N D
    have := Nat.mod_lt N hD
    omega
  have hR : (N:ℝ)≤(D:ℝ)*((N/D:ℕ):ℝ)+(D:ℝ) := by exact_mod_cast hr
  have hB : (b:ℝ)*((N/D:ℕ):ℝ)≤(Erdos865.f N k:ℝ) := by
    exact_mod_cast (show b*(N/D) ≤ Erdos865.f N k by have := band_lower k N hk; dsimp [b,D]; omega)
  have hcoeff : coeff k * (D:ℝ) = (b:ℝ) := coeff_band k hk
  calc
    _ ≤ coeff k * ((D:ℝ)*((N/D:ℕ):ℝ)+(D:ℝ)) := mul_le_mul_of_nonneg_left hR (coeff_pos k hk).le
    _ = (b:ℝ)*((N/D:ℕ):ℝ)+(b:ℝ) := by rw [mul_add,←mul_assoc,hcoeff]
    _ ≤ _ := by linarith only [hB]

end OP02.AllOrders

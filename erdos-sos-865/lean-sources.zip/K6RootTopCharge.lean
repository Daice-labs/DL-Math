import K6BootstrapLabels
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 3000000

/-- Root failures are charged to actual missing chain tops, independently of
qualification failures. Fixed-residue maps control the aggregate load. -/
theorem root_top_failure_charge (n σ c:ℕ) (B Y T:Finset ℕ)
    (hd:DoublingFree B) (hσ:∀x∈Y,x%8=σ)
    (hload:∀j:ℕ,(T.filter (fun s=>s%8=j)).card≤c)
    (hfail:∀x∈Y,∃s∈T,n/4<2*(x+s) ∧ x+s≤n/4 ∧
      canonical (x+s)=true ∧ x+s∉quarterD n B) :
    Y.card≤c*chainDeficit n B := by
  have htop:(topMissing (n/4) (quarterD n B)).card≤chainDeficit n B := by
    have hc:=chain_capacity_with_top_loss (n/4) (quarterD n B)
      (filter_subset _ _) (quarter_doubling_free n B hd)
    unfold chainDeficit
    omega
  have hc:=affine_cover_bound8 Y T (topMissing (n/4) (quarterD n B)) 0 σ 1 c (by omega) hσ hload (by
    intro x hx
    obtain ⟨s,hs,hl,hh,hcan,hbad⟩:=hfail x hx
    refine ⟨s,hs,x+s,mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hh⟩,hcan⟩,hl,hbad⟩,by omega⟩)
  exact le_trans hc (Nat.mul_le_mul_left c htop)

/-- The unrestricted three-shift charge requires no residue disjointness. -/
theorem root_top_failure_charge_three (n:ℕ) (B Y:Finset ℕ) (r s:ℕ)
    (hd:DoublingFree B)
    (hfail:∀x∈Y,∃t∈({0,r,s}:Finset ℕ),n/4<2*(x+t) ∧ x+t≤n/4 ∧
      canonical (x+t)=true ∧ x+t∉quarterD n B) :
    Y.card≤3*chainDeficit n B := by
  classical
  let H:=topMissing (n/4) (quarterD n B)
  let T:Finset ℕ:={0,r,s}
  let P:=fun t=>H.image (fun h=>h-t)
  have hsub:Y⊆T.biUnion P := by
    intro x hx
    obtain ⟨t,ht,hl,hh,hcan,hbad⟩:=hfail x hx
    refine mem_biUnion.mpr ⟨t,ht,mem_image.mpr ⟨x+t,?_,by omega⟩⟩
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hh⟩,hcan⟩,hl,hbad⟩
  have hc:Y.card≤T.card*H.card := by
    calc
      Y.card≤(T.biUnion P).card:=card_le_card hsub
      _≤∑t∈T,(P t).card:=card_biUnion_le
      _≤∑t∈T,H.card:=sum_le_sum (fun t ht=>card_image_le)
      _=T.card*H.card:=by simp
  have hT:T.card≤3:=card_le_three
  have htop:H.card≤chainDeficit n B := by
    have hb:=chain_capacity_with_top_loss (n/4) (quarterD n B)
      (filter_subset _ _) (quarter_doubling_free n B hd)
    unfold chainDeficit
    change (topMissing (n/4) (quarterD n B)).card≤chainCapacity (n/4)-(quarterD n B).card
    omega
  exact le_trans hc (Nat.mul_le_mul hT htop)

#print axioms root_top_failure_charge
#print axioms root_top_failure_charge_three
end OP02.SharpK6

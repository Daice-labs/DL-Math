import Mathlib

open Finset
namespace OP02.SharpK7

/-- An outer class is named by its unique upper coordinate in (2m,t].
Every vertex in its lower half d shares the name 2d with its double. -/
def outerOwner (t x : ℕ) := if x ≤ 2*(t/4) then 2*x else x

def outerMembers (t : ℕ) (D : Finset ℕ) := D ∩ Ioc (t/4) t

def emptyOuter (t : ℕ) (D : Finset ℕ) :=
  Ioc (2*(t/4)) t \ (outerMembers t D).image (outerOwner t)

theorem exact_outer_partition (t : ℕ) (D : Finset ℕ)
    (hd : ∀ x ∈ D, 2*x ∉ D) :
    (outerMembers t D).card + (emptyOuter t D).card = t-2*(t/4) := by
  classical
  let Y := outerMembers t D
  have hs : Y.image (outerOwner t) ⊆ Ioc (2*(t/4)) t := by
    intro v hv
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hv
    obtain ⟨hx₀,hx₁⟩ := mem_Ioc.mp (mem_inter.mp hx).2
    simp only [outerOwner,mem_Ioc]
    split_ifs <;> omega
  have hi : Set.InjOn (outerOwner t) (Y : Set ℕ) := by
    intro x hx y hy he
    have hxD := (mem_inter.mp hx).1; have hyD := (mem_inter.mp hy).1
    have hxy := hd x hxD; have hyx := hd y hyD
    unfold outerOwner at he
    split_ifs at he <;> first | omega | subst y; contradiction | subst x; contradiction
  have hc := card_sdiff_add_card_eq_card hs
  rw [card_image_of_injOn hi,Nat.card_Ioc] at hc
  unfold emptyOuter; change Y.card+((Ioc (2*(t/4)) t) \ Y.image (outerOwner t)).card=_
  omega

/-- Odd upper positions and the possible stray even position above 4m are
singletons. This includes every floor remainder. -/
theorem singleton_empty_iff (t v : ℕ) (D : Finset ℕ)
    (hv : v ∈ Ioc (2*(t/4)) t) (hs : Odd v ∨ 4*(t/4)<v) :
    v ∈ emptyOuter t D ↔ v ∉ D := by
  classical
  obtain ⟨hlo,hhi⟩ := mem_Ioc.mp hv
  constructor
  · intro he hmem
    apply (mem_sdiff.mp he).2
    exact mem_image.mpr ⟨v,mem_inter.mpr ⟨hmem,mem_Ioc.mpr ⟨by omega,hhi⟩⟩,
      by simp [outerOwner,show ¬v≤2*(t/4) by omega]⟩
  · intro hm
    refine mem_sdiff.mpr ⟨hv,?_⟩
    rintro h; obtain ⟨x,hx,he⟩ := mem_image.mp h
    have hmem := (mem_inter.mp hx).1
    unfold outerOwner at he
    split_ifs at he with hle
    · rcases hs with ⟨j,hj⟩ | hfar <;> omega
    · exact hm (he ▸ hmem)

/-- The two physical members of a paired class (including the top 4m). -/
theorem pair_empty_iff (t d : ℕ) (D : Finset ℕ) (hd : d ∈ Ioc (t/4) (2*(t/4))) :
    2*d ∈ emptyOuter t D ↔ d ∉ D ∧ 2*d ∉ D := by
  classical
  obtain ⟨hlo,hhi⟩ := mem_Ioc.mp hd
  have hd' : d ∈ Ioc (t/4) t := mem_Ioc.mpr ⟨hlo,by omega⟩
  have h2d : 2*d ∈ Ioc (t/4) t := mem_Ioc.mpr ⟨by omega,by omega⟩
  constructor
  · intro he
    have hmiss := (mem_sdiff.mp he).2
    constructor
    · intro hm; exact hmiss (mem_image.mpr ⟨d,mem_inter.mpr ⟨hm,hd'⟩,by simp [outerOwner,hhi]⟩)
    · intro hm; exact hmiss (mem_image.mpr ⟨2*d,mem_inter.mpr ⟨hm,h2d⟩,
        by simp [outerOwner,show ¬2*d≤2*(t/4) by omega]⟩)
  · rintro ⟨h1,h2⟩
    refine mem_sdiff.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,?_⟩
    intro hx
    obtain ⟨x,hm,he⟩ := mem_image.mp hx
    have hmD := (mem_inter.mp hm).1
    unfold outerOwner at he
    split_ifs at he
    · have : x=d := by omega
      exact h1 (this ▸ hmD)
    · exact h2 (he ▸ hmD)

def prefixRoots (t : ℕ) (D : Finset ℕ) := D ∩ Icc 1 t

theorem shell_count (t : ℕ) (D : Finset ℕ) (hd : ∀ x∈D, 2*x∉D) :
    (prefixRoots t D).card + (emptyOuter t D).card =
    (prefixRoots (t/4) D).card + (t-2*(t/4)) := by
  have hun : prefixRoots t D = prefixRoots (t/4) D ∪ outerMembers t D := by
    ext x
    simp only [prefixRoots,outerMembers,mem_union,mem_inter,mem_Icc,mem_Ioc]
    constructor
    · rintro ⟨hx,hl,hh⟩; by_cases hb : x≤t/4
      · exact Or.inl ⟨hx,hl,hb⟩
      · exact Or.inr ⟨hx,by omega,hh⟩
    · rintro (⟨hx,hl,hh⟩|⟨hx,hl,hh⟩) <;> exact ⟨hx,by omega,by omega⟩
  have hdis : Disjoint (prefixRoots (t/4) D) (outerMembers t D) := by
    apply disjoint_left.mpr
    intro x hx hy
    have h1 := (mem_Icc.mp (mem_inter.mp hx).2).2
    have h2 := (mem_Ioc.mp (mem_inter.mp hy).2).1
    omega
  rw [hun,card_union_of_disjoint hdis]
  have := exact_outer_partition t D hd
  omega

end OP02.SharpK7

import K7CentralPivot
import K7AdditionalRows
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- Three odd offsets in any residue pattern and two multiples of four.
A fourth even pivot is possible because its six offsets include only
three evens. The second pivot then uses the actual order-seven middle gap. -/
theorem three_odd_zero_impossible {n:ℕ} {B S:Finset ℕ} (hf:SevenFree B) (hd:DoublingFree B)
    (hg:MiddleGap7 n B) (hc:384*(chainDeficit n B+totalBudget n B)≤n/4) (hn:65536≤n)
    (hs:InternalFive (B∩Icc 1 (n/4)) S) (ho:(oddOffsets S).card=3)
    (he:∀x∈S,x%2=0→x%4=0) : False := by
  classical
  let O:=insert 0 S
  have h5:=hs.1
  have hO:O.card≤6:=by have :=card_insert_le 0 S;dsimp [O];omega
  have hx {x:ℕ} (hr:x∈S):x≤n/4:=(mem_Icc.mp (mem_inter.mp (hs.2.1 hr)).2).2
  have hrange {x:ℕ} (hr:x∈O):x≤n/4:=by
    rcases mem_insert.mp hr with h|h
    · omega
    · exact hx h
  have hclean:∀x∈O,(0+x)%4≠2:=by
    intro x hx';simp only [zero_add];rcases mem_insert.mp hx' with h|h
    · omega
    · intro bad;have :=he x h (by omega);omega
  have hEO:(O.filter (fun s=>(0+s)%2=0)).card≤3:=by
    have hh:=parity_partition S
    have hsub:O.filter (fun s=>(0+s)%2=0)⊆insert 0 (evenOffsets S):=by
      intro x hx';obtain ⟨hi,hr⟩:=mem_filter.mp hx'
      rcases mem_insert.mp hi with h|h
      · exact mem_insert.mpr (Or.inl h)
      · exact mem_insert_of_mem (mem_filter.mpr ⟨h,by omega⟩)
    have :=(card_le_card hsub).trans (card_insert_le _ _);omega
  obtain ⟨v,hv,hr,hcan⟩:=canonical_profile_class O 0 (by decide) hclean hEO
  let P:=progression (n/2) (3*(n/4)) 32 v
  let E:=(Ioc (n/2) n).filter (fun z=>canonical z=true ∧ z∉B)
  have hE:E.card≤chainDeficit n B+totalBudget n B:=canonical_lower_losses n B hd
  have hp {r:ℕ} (hr':r∈P):n/2<r ∧ r≤3*(n/4) ∧ r%32=v:=by
    obtain ⟨hi,hh⟩:=mem_filter.mp hr';exact ⟨(mem_Ioc.mp hi).1,(mem_Ioc.mp hi).2,hh⟩
  have hbd:=shift_losses P O B E 1 0 6 (by intro x hx';omega) (by
    intro r hR x hX ha
    have hrr:=hp hR; have hrx:=hrange hX
    exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,hcan r hrr.2.2 x hX,ha⟩)
    (fun _ _=>(card_filter_le _ _).trans hO)
  have hlen:=progression_lower (n/2) (3*(n/4)) 32 v (by decide) hv
  change _≤P.card at hlen
  obtain ⟨r,hr'⟩:=card_pos.mp (show 0<(passes P O B).card by omega)
  obtain ⟨hP,pass⟩:=mem_filter.mp hr'
  have hrB:r∈B:=by simpa using pass 0 (mem_insert_self _ _)
  have rdata:=hp hP
  have hnot:r∉S:=by intro h;have :=hx h;omega
  have hold:internalOn B S:=⟨fun _ h=>(mem_inter.mp (hs.2.1 h)).1,
    fun x h y h' ne=>(mem_inter.mp (hs.2.2 x h y h' ne)).1⟩
  have hfull:=append_clique hold hrB (fun x h=>pass x (mem_insert_of_mem h))
  apply pv_six hf hd hg hn (by omega) hfull (by simp [hnot,h5])
  · intro x hx';rcases mem_insert.mp hx' with h|h
    · omega
    · have :=hx h;omega
  · intro x hx' hev;rcases mem_insert.mp hx' with h|h
    · omega
    · exact ⟨he x h hev,by have :=hx h;omega⟩

theorem row13_all_three_odd_zero (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→(oddOffsets S).card=3→
      (∀x∈S,x%2=0→x%4=0)→False := by
  obtain ⟨u,hu⟩:=middle_gap7 hD β hb
  obtain ⟨v,hv⟩:=inventory_uniform β hb
  refine ⟨max u v,?_⟩
  intro n hn B hf hd hpg S hs ho he
  obtain ⟨hc,hbig⟩:=hv n (by omega) B hd hpg
  exact three_odd_zero_impossible hf hd (hu n (by omega) B hf hd hpg) hc hbig hs ho he

end OP02.SharpK7

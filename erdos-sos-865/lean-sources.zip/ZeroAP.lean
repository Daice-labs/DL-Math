import ZeroParity
open Finset
namespace OP02.ZeroExcess
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

theorem parity_source_AP (n:ℕ) (B:Finset ℕ) {r:ℕ} (hr:r<2)
    {a d:ℤ} {k:ℕ} (hd:0<d) (ho:d%2=1) (hk:0<k)
    (hap:parityIndices n B r=progression a d k) :
    ∃C s:ℕ, 0<s ∧ s%2=1 ∧ n<C ∧ C%2=r ∧ C+2*s*(k-1)≤2*n ∧
      parityMiddle n B r=(range k).image (fun i=>C+2*s*i) := by
  have hfirst:a∈parityIndices n B r := by
    rw [hap]
    exact mem_image.mpr ⟨0,mem_range.mpr hk,by simp⟩
  obtain ⟨C,hC,hCa⟩ := (parity_indices_mem n B hr).mp hfirst
  have hCi:=mem_Icc.mp (mem_inter.mp (mem_filter.mp hC).1).2
  have hCp: C%2=r := (mem_filter.mp hC).2
  let s:=d.toNat
  have hsd:(s:ℤ)=d := Int.toNat_of_nonneg (by omega)
  have hs:0<s := by omega
  have hso:s%2=1 := by omega
  have hlast:a+d*((k-1:ℕ):ℤ)∈parityIndices n B r := by
    rw [hap]
    exact mem_image.mpr ⟨k-1,mem_range.mpr (by omega),rfl⟩
  obtain ⟨Z,hZ,hZe⟩ := (parity_indices_mem n B hr).mp hlast
  have hZi:=mem_Icc.mp (mem_inter.mp (mem_filter.mp hZ).1).2
  have hZeq:Z=C+2*s*(k-1) := by
    have hi: (Z:ℤ)=(C:ℤ)+2*(s:ℤ)*((k-1:ℕ):ℤ) := by rw [hsd]; nlinarith
    exact_mod_cast hi
  refine ⟨C,s,hs,hso,by omega,hCp,by omega,?_⟩
  ext x
  constructor
  · intro hx
    have hxi : ((x/2:ℕ):ℤ)∈parityIndices n B r := mem_image.mpr ⟨x,hx,rfl⟩
    rw [hap] at hxi
    obtain ⟨i,hi,hie⟩ := mem_image.mp hxi
    have hxp: x%2=r := (mem_filter.mp hx).2
    refine mem_image.mpr ⟨i,hi,?_⟩
    have hxe: (x:ℤ)=2*((x/2:ℕ):ℤ)+r := by omega
    have heq:(C:ℤ)+2*(s:ℤ)*(i:ℤ)=x := by rw [hsd]; nlinarith
    exact_mod_cast heq
  · intro hx
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hx
    have hidx:a+d*(i:ℤ)∈parityIndices n B r := by
      rw [hap]
      exact mem_image.mpr ⟨i,hi,rfl⟩
    obtain ⟨y,hy,hye⟩ := (parity_indices_mem n B hr).mp hidx
    have hyeq:y=C+2*s*i := by
      have hi:(y:ℤ)=(C:ℤ)+2*(s:ℤ)*(i:ℤ) := by rw [hsd]; nlinarith
      exact_mod_cast hi
    exact hyeq ▸ hy

theorem parity_progression (n:ℕ) (B:Finset ℕ) {r:ℕ} (hr:r<2)
    (hclosed:MidClosed (parityIndices n B r)) (hk:0<(parityMiddle n B r).card) :
    ∃C s:ℕ, 0<s ∧ s%2=1 ∧ n<C ∧ C%2=r ∧
      C+2*s*((parityMiddle n B r).card-1)≤2*n ∧
      parityMiddle n B r=(range (parityMiddle n B r).card).image (fun i=>C+2*s*i) := by
  obtain ⟨a,d,k,hd,ho,hap⟩ := midpoint_progression (parityIndices n B r) hclosed
  have heq:k=(parityMiddle n B r).card := by
    rw [←parity_indices_card n B r,hap,progression_card hd]
  subst k
  exact parity_source_AP n B hr hd ho hk hap

/-- A sufficiently dense entire parity side cannot have physical step at least six. -/
theorem dense_parity_interval (n:ℕ) (B:Finset ℕ) {r:ℕ} (hr:r<2)
    (hclosed:MidClosed (parityIndices n B r))
    (hdense:n+16<4*(parityMiddle n B r).card) :
    ∃C:ℕ, n<C ∧ C%2=r ∧ C+2*((parityMiddle n B r).card-1)≤2*n ∧
      parityMiddle n B r=(range (parityMiddle n B r).card).image (fun i=>C+2*i) := by
  have hk:0<(parityMiddle n B r).card := by omega
  obtain ⟨C,s,hs,hso,hCn,hCp,hspan,hap⟩ := parity_progression n B hr hclosed hk
  have hs1:s=1 := by
    by_contra hh
    have hs3:3 ≤ s := by omega
    have hprod:=Nat.mul_le_mul_right ((parityMiddle n B r).card-1) hs3
    have hkpred:(parityMiddle n B r).card-1+1=(parityMiddle n B r).card := by omega
    nlinarith
  subst s
  norm_num at hspan hap
  exact ⟨C,hCn,hCp,hspan,hap⟩

#print axioms parity_progression
#print axioms dense_parity_interval
end OP02.ZeroExcess

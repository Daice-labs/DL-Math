import K7LongOddContract

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

theorem lower_unordered_five (n a c b p χ : ℕ) (B : Finset ℕ)
    (ha : 0<a) (hac : a<c) (hcb : c<b) (hbcap : 4*b≤n/4/4) (hpcap : p≤n/4/4) (hxcap : χ≤3*(n/4)/4)
    (hpx : p<χ) (hop : p%2=1) (hox : χ%2=1)
    (hra : a∈quarterD n B) (hrc : c∈quarterD n B) (hrb : b∈quarterD n B)
    (hrac : a+c∈quarterD n B) (hrab : a+b∈quarterD n B) (hrcb : c+b∈quarterD n B)
    (hp : p∈B) (hpa : p+4*a∈B) (hpc : p+4*c∈B) (hpb : p+4*b∈B)
    (hx : χ∈B) (hxa : χ+4*a∈B) (hxc : χ+4*c∈B) (hxb : χ+4*b∈B) (hxp : χ+p∈B) :
    InternalFive (B∩Icc 1 (n/4)) {4*a,4*c,4*b,p,χ} := by
  have sc {x} (hm : x∈quarterD n B) : 4*x∈B := (mem_filter.mp hm).2
  have h₁ : 4*a∈B := sc hra;have h₂ : 4*c∈B := sc hrc;have h₃ : 4*b∈B := sc hrb
  have h₄ : 4*a+4*c∈B := by simpa only [Nat.mul_add] using sc hrac
  have h₅ : 4*a+4*b∈B := by simpa only [Nat.mul_add] using sc hrab
  have h₆ : 4*c+4*b∈B := by simpa only [Nat.mul_add] using sc hrcb
  have hdis₁ : 4*a ∉ ({4*c,4*b,p,χ} : Finset ℕ) := by simp only [mem_insert,mem_singleton];omega
  have hdis₂ : 4*c ∉ ({4*b,p,χ} : Finset ℕ) := by simp only [mem_insert,mem_singleton];omega
  have hdis₃ : 4*b ∉ ({p,χ} : Finset ℕ) := by simp only [mem_insert,mem_singleton];omega
  refine ⟨by simp [card_insert_of_notMem,hdis₁,hdis₂,hdis₃,hpx.ne],?_,?_⟩
  · intro x hx'
    simp only [mem_insert,mem_singleton] at hx'
    rcases hx' with rfl|rfl|rfl|rfl|rfl <;>
      exact mem_inter.mpr ⟨by assumption,mem_Icc.mpr ⟨by omega,by omega⟩⟩
  · intro x hx' y hy' hne
    simp only [mem_insert,mem_singleton] at hx' hy'
    rcases hx' with rfl|rfl|rfl|rfl|rfl <;> rcases hy' with rfl|rfl|rfl|rfl|rfl <;>
      first | exact False.elim (hne rfl) |
        exact mem_inter.mpr ⟨by first | assumption | rw [Nat.add_comm];assumption,
                              mem_Icc.mpr ⟨by omega,by omega⟩⟩

/-- Lower O-T has no ordering assumption on the odd vertex and 4b. -/
theorem lower_OT {n a c b y : ℕ} {B : Finset ℕ}
    (hf : SevenFree B) (hd : DoublingFree B) (hm : MiddleGap7 n B)
    (hc : 384*(chainDeficit n B+totalBudget n B)≤n/4) (hn : 65536≤n)
    (ha : 0<a) (hac : a<c) (hcb : c<b) (hb : 4*b≤n/4/4)
    (hy : n/4/8<y) (hy' : y≤n/4/4) (hyo : y%2=1)
    (pat : (a%2=0 ∧ c%2=0 ∧ b%2=1) ∨ (a%2=1 ∧ c%2=1 ∧ b%4=0))
    (hΛ : 6*lambdaBudget n B < n/4/64)
    (da : a∈quarterD n B) (dc : c∈quarterD n B) (db : b∈quarterD n B)
    (de : a+c∈quarterD n B) (dab : b+a∈quarterD n B) (dcb : b+c∈quarterD n B)
    (ht : y+4*b∈B) : y∉B ∨ y+4*a∉B ∨ y+4*c∉B := by
  classical
  by_contra! yes
  let H:=n/4
  let v:=(12-y%8)%8
  let Y:=progression (H/2) (3*H/4) 8 v
  let O:Finset ℕ:={0,4*a,4*c,4*b}
  let G:=passes Y O B
  have dat {x:ℕ} (hx:x∈Y) : H/2<x ∧ x≤3*H/4 ∧ (y+x)%8=4 ∧ x%2=1 := by
    obtain ⟨hi,hr⟩:=mem_filter.mp hx
    have hh:=mem_Ioc.mp hi
    change x%8=(12-y%8)%8 at hr
    omega
  have cov:=shift_losses Y O B (absentTop n B) 1 0 4 (by intro x hx;omega)
    (by
      intro x hx z hz hmiss
      have h:=dat hx
      change z∈({0,4*a,4*c,4*b}:Finset ℕ) at hz
      simp only [mem_insert,mem_singleton] at hz
      apply mem_filter.mpr
      rcases hz with rfl|rfl|rfl|rfl <;>
        exact ⟨mem_Ioc.mpr ⟨by change H/2<_;omega,by change _≤H;dsimp [H] at *;omega⟩,by omega,hmiss⟩)
    (fun _ _ => (card_filter_le _ _).trans card_le_four)
  change Y.card≤G.card+4*(absentTop n B).card at cov
  have top:=absent_top_cost n B hd
  have cap:=common_inventory n B
  have raw:=progression_lower (H/2) (3*H/4) 8 v (by decide) (by dsimp [v];omega)
  change _/8≤Y.card at raw
  have haveRoot:∃x∈G,(y+x)/4∈quarterD n B:=by
    by_contra! none
    have cost:G.card≤A_loss n B:=by
      apply card_le_card_of_injOn (fun x:ℕ=>(y+x)/4)
      · intro x hx
        have h:=dat (mem_filter.mp hx).1
        exact absent_quarter_root (x:=(y+x)/4) (by dsimp only [H] at h;omega) (by dsimp only [H] at h;omega) (by omega) (none x hx)
      · intro x hx z hz he
        have h₁:=dat (mem_filter.mp hx).1
        have h₂:=dat (mem_filter.mp hz).1
        dsimp at he;omega
    dsimp only [H] at raw
    omega
  obtain ⟨x,hx,hroot⟩:=haveRoot
  have h:=dat (mem_filter.mp hx).1
  have direct:=(mem_filter.mp hx).2
  have hxy:x+y∈B:= by
    have hh:=(mem_filter.mp hroot).2
    rwa [show 4*((y+x)/4)=x+y by omega] at hh
  exact qualified_cluster_impossible hf hd hm hc hn ha hac hcb hyo h.2.2.2 pat
    (lower_unordered_five n a c b y x B ha hac hcb hb hy' h.2.1 (by dsimp [H] at *;omega)
      hyo h.2.2.2 da dc db de (Nat.add_comm b a ▸ dab) (Nat.add_comm b c ▸ dcb)
      yes.1 yes.2.1 yes.2.2 ht (by simpa using direct 0 (by simp [O]))
      (direct _ (by simp [O])) (direct _ (by simp [O])) (direct _ (by simp [O])) hxy)

end OP02.SharpK7.LongOddTask

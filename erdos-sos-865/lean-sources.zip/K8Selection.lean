import K8Spec

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK8

/-- Every failed candidate is counted once even when several roles fail. -/
def rejected (P R I : Finset ℕ) (label : ℕ → ℕ → ℕ) : Finset ℕ :=
  R.biUnion (fun r => P.filter (fun p => label r p ∈ I))

theorem mem_rejected {P R I : Finset ℕ} {label : ℕ → ℕ → ℕ} {p : ℕ} :
    p ∈ rejected P R I label ↔ ∃ r ∈ R, p ∈ P ∧ label r p ∈ I := by
  simp only [rejected,mem_biUnion,mem_filter]

theorem rejected_card (P R I : Finset ℕ) (label : ℕ → ℕ → ℕ)
    (inj : ∀ r ∈ R, Set.InjOn (label r) (P : Set ℕ)) :
    (rejected P R I label).card ≤ R.card * I.card := by
  classical
  induction R using Finset.induction_on with
  | empty => simp [rejected]
  | @insert r R hr ih =>
    have hs : (P.filter (fun p => label r p ∈ I)).card ≤ I.card :=
      card_le_card_of_injOn (label r) (fun _ h => (mem_filter.mp h).2)
        (fun _ hp _ ht he => inj r (mem_insert_self _ _) (mem_filter.mp hp).1 (mem_filter.mp ht).1 he)
    have ht := ih (fun a ha => inj a (mem_insert_of_mem ha))
    rw [rejected,biUnion_insert,card_insert_of_notMem hr,Nat.add_mul,one_mul]
    exact (card_union_le _ _).trans (by unfold rejected at ht; omega)

/-- Adjacencies are memberships of actual sums. Other edges may share a label. -/
theorem internal_insert {j x : ℕ} {B S : Finset ℕ} (hS : Internal j B S)
    (hx : x ∈ B) (fresh : x ∉ S) (edges : ∀ y ∈ S, x+y ∈ B) :
    Internal (j+1) B (insert x S) := by
  refine ⟨insert_subset hx hS.1,by rw [card_insert_of_notMem fresh,hS.2.1],?_⟩
  intro a ha b hb hne
  by_cases ax : a=x
  · subst a
    exact edges b ((mem_insert.mp hb).resolve_left (Ne.symm hne))
  · have aS := (mem_insert.mp ha).resolve_left ax
    rcases mem_insert.mp hb with bx|bS
    · subst b
      simpa only [Nat.add_comm] using edges a aS
    · exact hS.2.2 a aS b bS hne


theorem internal_mono {j : ℕ} {B L S : Finset ℕ} (h : Internal j L S) (sub : L ⊆ B) :
    Internal j B S := ⟨Subset.trans h.1 sub,h.2.1,fun x hx y hy hxy => sub (h.2.2 x hx y hy hxy)⟩

/-- Final odd upper selection, uniformly for the fixed six evens and the admitted odd vertex. -/
theorem finish_six_odd {n v : ℕ} {B W : Finset ℕ} (hd : DoublingFree B)
    (hn : 8≤n) (hcap : 1536*(chainDeficit n B+totalBudget n B) < n/4)
    (hW : Internal 6 B W) (ev : ∀x∈W, x%2=0) (bd : ∀x∈W, 0<x ∧ x≤n)
    (hv : v∈B) (odd : v%2=1) (low : v≤n) (edges : ∀x∈W, v+x∈B) :
    ∃ Z, Internal 8 B Z := by
  classical
  let R := insert 0 (insert v W)
  let r := (12-v%8)%8
  let P := progression (2*n) (3*n) 8 r
  have hr : r<8 := Nat.mod_lt _ (by decide)
  have supply := progression_lower (2*n) (3*n) 8 r (Or.inr (Or.inl rfl)) hr
  have rf : v∉W := fun hvW => by have := ev v hvW; omega
  have nozero : 0∉insert v W := by
    intro hh;rcases mem_insert.mp hh with h|h
    · omega
    · have := bd 0 h;omega
  have hcard : R.card=8 := by simp [R,nozero,rf,hW.2.1]
  have loss := canonical_hole_total_budget n B hd
  have fail := rejected_card P R (canonicalHoles n B) (fun a p => p+a)
    (fun _ _ _ _ _ _ he => by dsimp at he;omega)
  have less : (rejected P R (canonicalHoles n B) (fun a p=>p+a)).card < P.card := by
    unfold totalBudget at hcap
    change (3*n-2*n)/8 ≤ P.card at supply
    have subeq : 3*n-2*n=n := by omega
    rw [subeq] at supply
    rw [hcard] at fail
    omega
  obtain ⟨p,hp,hkeep⟩ := exists_mem_notMem_of_card_lt_card less
  have pi := mem_Ioc.mp (mem_filter.mp hp).1
  have pres := (mem_filter.mp hp).2
  change p%8=(12-v%8)%8 at pres
  have good : ∀a∈R, p+a ∈ B := by
    intro a ha
    have upper : 2*n < p+a ∧ p+a ≤ 4*n := by
      rcases mem_insert.mp ha with h | h
      · omega
      · rcases mem_insert.mp h with h | h
        · omega
        · have := bd a h; omega
    have can : canonical (p+a) = true := by
      rcases mem_insert.mp ha with h | h
      · exact canonical_odd _ (by omega)
      · rcases mem_insert.mp h with h | h
        · exact canonical_four_residue _ (by omega)
        · have := ev a h;exact canonical_odd _ (by omega)
    by_contra hmiss
    exact hkeep (mem_rejected.mpr ⟨a,ha,hp,mem_filter.mpr ⟨mem_sdiff.mpr
      ⟨mem_Icc.mpr ⟨by omega,upper.2⟩,hmiss⟩,can⟩⟩)
  have pv : Internal 7 B (insert v W) := internal_insert hW hv rf edges
  have fresh : p∉insert v W := by
    intro hh;rcases mem_insert.mp hh with h|h
    · omega
    · have := bd p h;omega
  exact ⟨_,internal_insert pv (by simpa using good 0 (mem_insert_self _ _)) fresh
    (fun x hx => good x (mem_insert_of_mem hx))⟩

end OP02.SharpK8

import K5GapResources
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 1000000

def bandCost (n σ:ℕ) (B:Finset ℕ) :=
  ((middle n B).filter (fun x=>x%4=2)).card+(res8 (excessHoles n B) 4).card+
  (res8 (excessHoles n B) ((2*σ)%8)).card+2*(Ho n B).card

def maximalBandCost (n:ℕ) (B:Finset ℕ) :=
  ((middle n B).filter (fun x=>x%4=2)).card+(res8 (excessHoles n B) 4).card+
  max (res8 (excessHoles n B) 2).card (res8 (excessHoles n B) 6).card+2*(Ho n B).card

def highThreshold (n:ℕ) (B:Finset ℕ) :=24*maximalBandCost n B+8*(missingTopOdd n B).card+16

theorem even_resource_partition (n:ℕ) (B:Finset ℕ) :
    (H0 n B).card=(res8 (excessHoles n B) 0).card+(res8 (excessHoles n B) 4).card ∧
    (H2 n B).card=(res8 (excessHoles n B) 2).card+(res8 (excessHoles n B) 6).card := by
  constructor <;> apply partition_card
  · intro x
    simp only [H0,res8,mem_filter]
    constructor
    · rintro ⟨hx,hr⟩
      by_cases h:x%8=0
      · exact Or.inl ⟨hx,h⟩
      · exact Or.inr ⟨hx,by omega⟩
    · rintro (⟨hx,hr⟩|⟨hx,hr⟩) <;> exact ⟨hx,by omega⟩
  · intro x hx hy
    have :=(mem_filter.mp hx).2; have :=(mem_filter.mp hy).2; omega
  · intro x
    simp only [H2,res8,mem_filter]
    constructor
    · rintro ⟨hx,hr⟩
      by_cases h:x%8=2
      · exact Or.inl ⟨hx,h⟩
      · exact Or.inr ⟨hx,by omega⟩
    · rintro (⟨hx,hr⟩|⟨hx,hr⟩) <;> exact ⟨hx,by omega⟩
  · intro x hx hy
    have :=(mem_filter.mp hx).2; have :=(mem_filter.mp hy).2; omega

theorem band_budget (n σ:ℕ) (B:Finset ℕ) (hd:DoublingFree B) (hσ:σ=1 ∨ σ=3) :
    bandCost n σ B≤ maximalBandCost n B ∧
    2*(missingTopOdd n B).card+3*bandCost n σ B+(fourResources n B).card≤6*totalBudget n B ∧
    3*bandCost n σ B+(missingTopOdd n B).card≤6*totalBudget n B ∧
    highThreshold n B≤48*totalBudget n B+16 ∧
    highThreshold n B+24*(missingTopOdd n B).card≤56*totalBudget n B+16 := by
  have ht:=middle_two_le_singleton n B hd
  have hdelt:=deficit_split n B hd
  have hE:=excess_partition n B
  obtain ⟨he0,he2⟩:=even_resource_partition n B
  have hJ:=four_resource_card n B
  simp only [bandCost,maximalBandCost,highThreshold,totalBudget]
  rcases hσ with rfl|rfl <;> norm_num <;> omega

#print axioms even_resource_partition
#print axioms band_budget
end OP02.SharpK5

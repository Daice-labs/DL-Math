import K7Forcing
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

def evenReplacement (n u v h k:ℕ) (B:Finset ℕ) : Prop :=
  ∃ z∈evenBases (n/4) (2*k), InternalFive (B∩Icc 1 (n/4)) (insert (4*z) {u,v,4*h,2*k}) ∧
      ∀x∈({u,v,4*h,2*k}:Finset ℕ),x<4*z

private theorem tested_repr {n e b : ℕ} {B:Finset ℕ} {Y:Finset ℕ} {g:ℤ}
    (hg:g∈testedIndices (Y.image (fun x:ℕ=>((x/2:ℕ):ℤ)))
      ((retainedEndpoints n B e b).image (fun a:ℕ=>(a:ℤ))) (e:ℤ)) :
    ∃x∈Y,∃d:ℕ,d≤n/4/64 ∧ g=((x/2:ℕ):ℤ)+(d:ℤ) := by
  rcases mem_union.mp hg with hg|hg
  · obtain ⟨x,hx,rfl⟩:=mem_image.mp hg; exact ⟨x,hx,0,by omega,by simp⟩
  · obtain ⟨g',hg',hs⟩:=mem_biUnion.mp hg
    obtain ⟨x,hx,rfl⟩:=mem_image.mp hg'
    rcases mem_union.mp hs with hs|hs
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp hs
      obtain ⟨u,hu,heu⟩:=mem_image.mp ha
      subst a
      have hh:=(mem_filter.mp (mem_filter.mp hu).1).1
      exact ⟨x,hx,u,(mem_Icc.mp (mem_inter.mp hh).2).2,rfl⟩
    · obtain ⟨a,ha,rfl⟩:=mem_image.mp hs
      obtain ⟨u,hu,heu⟩:=mem_image.mp ha
      subst a
      obtain ⟨_,_,hac,hc⟩:=mem_filter.mp (mem_filter.mp hu).1
      exact ⟨x,hx,e-u,(mem_Icc.mp (mem_inter.mp hc).2).2,by omega⟩

private theorem odd_progression_lower (l u:ℕ) : (u-l)/2≤(progression l u 2 1).card := by
  have h:=@card_le_card_of_injOn ℕ ℕ (range ((u-l)/2)) (progression l u 2 1)
    (fun i:ℕ=>l+1+l%2+2*i) (by
      intro i hi;have hi':=mem_range.mp hi
      change l+1+l%2+2*i∈progression l u 2 1
      exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega⟩) (by
      intro i hi j hj hh;change l+1+l%2+2*i=l+1+l%2+2*j at hh;omega)
  simpa using h

/-- Section 5 on the exact guarded 2k placement, with its mixed pair winner.
The numerical cut from the separate even-free-band theorem is visible. -/
theorem two_k_window_qualified {β:ℝ} {n s u v h k:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {u,v,4*h,2*k}))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (ho:u%2=1) (ho':v%2=1) (hopp:u%4≠v%4) (hk:k%2=1) (hevh:h%2=0)
    (hm:3*(2*k)≤n/4) (hm₀:∀z∈({u,v,4*h,2*k}:Finset ℕ),z≤2*k)
    (hband:32*(2*k)<9*(n/4)+384*logLevels (n/4)+160) :
    evenReplacement n u v h k B ∨ qualifiedJ0 n B := by
  classical
  by_cases hex:evenReplacement n u v h k B
  · exact Or.inl hex
  right
  let H:=n/4
  let N:=H/64
  let Y:=progression (max (H/8) ((3*H-8*k)/16)) ((H-2*k)/4-2*N) 2 1
  let I:=Y.image (fun x:ℕ=>((x/2:ℕ):ℤ))
  let p₀:ℤ:=(k:ℤ)+2
  have hn:6*lambdaBudget n B+58*logLevels H+5976≤N:=by
    have hh:=surplus_lower β n B hd hg
    have hu:=surplus_upper n B hd
    have h₀:(0:ℝ)≤(midEmpty n B).card:=by positivity
    exact_mod_cast (show 6*(lambdaBudget n B:ℝ)+58*(logLevels (n/4):ℝ)+5976≤(n/4/64:ℕ)
      by linarith only [hh,hu,h₀,hl])
  have hHt : H=64*N+H%64:=by dsimp [N];omega
  have hband':32*(2*k)<9*H+384*logLevels H+160:=hband
  have hm':3*(2*k)≤H:=hm
  have hlow:=even_base_failures hd ho ho' hopp hevh hk hm
    (hm₀ _ (by simp)) (hm₀ _ (by simp)) (hm₀ _ (by simp)) (le_refl _)
  have ydata {x:ℕ} (hx:x∈Y) :
      max (H/8) ((3*H-8*k)/16)<x ∧ x≤(H-2*k)/4-2*N ∧ x%2=1 := by
    obtain ⟨hI,hr⟩:=mem_filter.mp hx
    exact ⟨(mem_Ioc.mp hI).1,(mem_Ioc.mp hI).2,hr⟩
  have hIeq:I.card=Y.card:= by
    apply card_image_of_injOn;intro x hx y hy he
    have h1:=ydata hx;have h2:=ydata hy
    change ((x/2:ℕ):ℤ)=((y/2:ℕ):ℤ) at he
    omega
  have hlen:4*lambdaBudget n B<I.card:=by
    rw [hIeq]
    have hdY:=odd_progression_lower (max (H/8) ((3*H-8*k)/16)) ((H-2*k)/4-2*N)
    change _ / 2 ≤ Y.card at hdY
    omega
  obtain ⟨e,he,hee,hmax,w,hw,hj⟩:=many_retained β n B hd hg hscale hl
  let A:=retainedEndpoints n B e (4*w)
  let U:=latticeBad H B p₀ e I (A.image (fun a:ℕ=>(a:ℤ)))
  let V:=latticeVeto H B p₀ (4*w) I
  have data {x:ℕ} (hx:x∈Y) {d:ℕ} (hD:d≤N) :
      x+2*d∈evenBases H (2*k) ∧
      p₀+4*(((x/2:ℕ):ℤ)+d)=((k+2*(x+2*d):ℕ):ℤ) := by
    have hxy:=ydata hx
    constructor
    · apply mem_filter.mpr
      exact ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega⟩
    · dsimp only [p₀];omega
  have hU:U.card≤2*A_loss n B+T_loss n B+G_loss n B := by
    apply le_trans _ hlow
    apply card_le_card_of_injOn (fun g:ℤ=>(1+2*g).toNat)
    · intro g hgu
      obtain ⟨hgt,hmiss⟩:=mem_filter.mp hgu
      obtain ⟨x,hx,d,hdN,hgi⟩:=tested_repr hgt
      have hxy:=ydata hx
      have hgpos:(1+2*g).toNat=x+2*d := by omega
      change (1+2*g).toNat∈(evenBases (n/4) (2*k)).filter (fun z=>¬evenTests n u v h k z B)
      rw [hgpos]
      obtain ⟨had,haeq⟩:=data hx hdN
      apply mem_filter.mpr;refine ⟨had,?_⟩;intro hpass
      rcases even_base_alternative hs hm hm₀ hk had hpass with hp|hc
      · apply hmiss;apply mem_image.mpr
        refine ⟨k+2*(x+2*d),mem_inter.mpr ⟨hp,mem_Icc.mpr ⟨by omega,by omega⟩⟩,?_⟩
        rw [hgi];exact haeq.symm
      · exact hex ⟨x+2*d,had,hc⟩
    · intro g hg g' hg' hEq
      obtain ⟨x,hx,d,hdN,heq⟩:=tested_repr (mem_filter.mp hg).1
      obtain ⟨y,hy,v,hvN,heq'⟩:=tested_repr (mem_filter.mp hg').1
      change (1+2*g).toNat=(1+2*g').toNat at hEq
      omega
  have hw':=rigid_bounds (mem_filter.mp hw).1
  have base {g:ℤ} (hgI:g∈I) : ∃p:ℕ,(p:ℤ)=p₀+4*g ∧ p%2=1 ∧
       3*H≤8*p ∧ p+4*N≤H/2 := by
    obtain ⟨x,hx,rfl⟩:=mem_image.mp hgI
    have hxy:=ydata hx
    refine ⟨k+2*x,?_,by omega,by omega,by omega⟩
    dsimp only [p₀];omega
  have hV:V.card≤T_loss n B := by
    apply le_trans _ (absent_top_cost n B hd)
    apply card_le_card_of_injOn (fun g:ℤ=>(p₀+4*g+4*(4*w)).toNat)
    · intro g hbad
      obtain ⟨hI,hnmem⟩:=mem_filter.mp hbad
      obtain ⟨p,hp,ho,pmin,pmax⟩:=base hI
      have h2:N/2<w ∧ w≤(3*N+1)/4:=⟨hw'.1,hw'.2.1⟩
      have heq:(p₀+4*g+4*(4*w)).toNat=p+16*w:=by omega
      change (p₀+4*g+4*(4*w)).toNat∈absentTop n B
      rw [heq];apply mem_filter.mpr
      refine ⟨mem_Ioc.mpr ⟨?_,?_⟩,by omega,?_⟩
      · change H/2<p+16*w;omega
      · change p+16*w≤H;omega
      · intro htB;apply hnmem;apply mem_image.mpr
        exact ⟨p+16*w,mem_inter.mpr ⟨htB,mem_Icc.mpr ⟨by omega,by omega⟩⟩,by omega⟩
    · intro i hi j hj hEq
      obtain ⟨p,hp,_⟩:=base (mem_filter.mp hi).1
      obtain ⟨p',hp',_⟩:=base (mem_filter.mp hj).1
      change (p₀+4*i+4*(4*w)).toNat=(p₀+4*j+4*(4*w)).toNat at hEq
      omega
  have inv:=common_inventory n B
  have jpos:lambdaBudget n B<A.card:=hj
  apply qualified_j0_on_window hd hg hscale hl he hee hw hj p₀ I
  · change (V.card:ℤ)+max (U.card:ℤ) (3*(U.card:ℤ)-2*(A.card:ℤ)+2)<(I.card:ℤ)
    omega
  · intro g hgI
    obtain ⟨p,hp,hodd,hlo,hup⟩:=base hgI
    exact ⟨p,hp,hodd,hlo,by change 2*p≤H;omega,standard_partner_width hd hg hscale hl hup⟩

theorem two_k_window {β:ℝ} {n s u v h k:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {u,v,4*h,2*k}))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (ho:u%2=1) (ho':v%2=1) (hopp:u%4≠v%4) (hk:k%2=1) (hevh:h%2=0)
    (hm:3*(2*k)≤n/4) (hm₀:∀z∈({u,v,4*h,2*k}:Finset ℕ),z≤2*k)
    (hband:32*(2*k)<9*(n/4)+384*logLevels (n/4)+160) :
    evenReplacement n u v h k B ∨ j0Witness n B :=
  (two_k_window_qualified hd hg hs hscale hl ho ho' hopp hk hevh hm hm₀ hband).imp_right forget_qualification

end OP02.SharpK7

import K7BridgeConsumer
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

abbrev LossTest := (ℕ → ℕ) × Finset ℕ

/-- For each role the map is injective on the original candidates. The
sum contains one factor per role, including every repeated owner pool.
No step can create a replacement resource. -/
theorem avoid_physical_tests (P:Finset ℕ) (L:List LossTest)
    (hinj:∀j∈L,∀a∈P,∀b∈P,j.1 a=j.1 b→a=b)
    (hs:(L.map fun j=>j.2.card).sum<P.card) :
    ∃x∈P,∀j∈L,j.1 x∉j.2:=by
  classical
  induction L generalizing P with
  | nil => obtain ⟨x,hx⟩:=card_pos.mp (show 0<P.card by simpa using hs);exact ⟨x,hx,by simp⟩
  | cons j l ih =>
    let P':=P.filter (fun a=>j.1 a∉j.2)
    have sub:P'⊆P:=filter_subset _ _
    have bound:(P \ P').card≤j.2.card:=by
      apply card_le_card_of_injOn j.1
      · intro x hx;obtain ⟨hp,hn⟩:=mem_sdiff.mp hx
        exact of_not_not (fun neg=>hn (mem_filter.mpr ⟨hp,neg⟩))
      · intro a ha b hb he;exact hinj j (by simp) _ (mem_sdiff.mp ha).1 _ (mem_sdiff.mp hb).1 he
    have cnt:=card_sdiff_add_card_eq_card sub
    simp only [List.map_cons,List.sum_cons] at hs
    obtain ⟨x,hx,hh⟩:=ih P' (by intro i hi a ha b hb he;exact hinj i (by simp [hi]) _ (sub ha) _ (sub hb) he) (by omega)
    refine ⟨x,sub hx,?_⟩
    intro i hi;rcases List.mem_cons.mp hi with rfl|hi
    · exact (mem_filter.mp hx).2
    · exact hh i hi

/-- One of the three root shifts is designated as the possible even
one. If all three are even shifts, the designated shift is the dummy 1
and every actual root is odd. -/
def minorShift (h j:ℕ):ℕ:=if h%2=0 then (if j%2=0 then 1 else j)
  else (if j%2=0 then h else 0)

def halfResidues (d:ℕ):Finset ℕ:=
  ({4,12,16,20,28}:Finset ℕ).image (fun v=>(v+32-d%32)%32)

theorem half_residue_data (h j:ℕ) :
    (halfResidues (minorShift h j)).card=5 ∧
    ∀r:ℕ,r%32∈halfResidues (minorShift h j) →
    (∀v∈({0,h,j}:Finset ℕ),canonical (r+v)=true) ∧
    ∀v∈({0,h,j}:Finset ℕ), (r+v)%2=0→v=minorShift h j :=by
  let d:=minorShift h j
  have cnt:(halfResidues d).card=5:=by
    unfold halfResidues
    rw [card_image_of_injOn]
    · decide
    · intro a ha b hb eq
      change a∈({4,12,16,20,28}:Finset ℕ) at ha
      change b∈({4,12,16,20,28}:Finset ℕ) at hb
      simp only [mem_insert,mem_singleton] at ha hb
      have aa:a<32:=by omega
      have bb:b<32:=by omega
      dsimp only at eq;omega
  refine ⟨cnt,?_⟩
  intro r hr
  obtain ⟨v,hv,he⟩:=mem_image.mp hr
  have good:(r+d)%8=4 ∨ (r+d)%32=16:=by
    simp only [mem_insert,mem_singleton] at hv
    change (v+32-d%32)%32=r%32 at he
    omega
  have even:(r+d)%2=0:=by omega
  have eqD:∀v∈({0,h,j}:Finset ℕ),(r+v)%2=0→v=d:=by
    intro v hv even'
    simp only [mem_insert,mem_singleton] at hv
    dsimp [d,minorShift] at even ⊢
    split_ifs at even ⊢ <;> omega
  refine ⟨?_,eqD⟩
  intro v hv
  by_cases odd:(r+v)%2=1
  · exact canonical_odd _ odd
  · rw [eqD v hv (by omega)]
    rcases good with g|g
    · rw [show r+d=4*((r+d)/4) by omega,canonical_four];exact canonical_odd _ (by omega)
    · rw [show r+d=4*(4*((r+d)/16)) by omega,canonical_four,canonical_four];exact canonical_odd _ (by omega)

/-- A single full period supplies the five translated even-valuation
residues; this bound works at every position of the left endpoint. -/
theorem count_halves (l u d:ℕ) :
    ((u-l)/32)*5≤((Ioc l u).filter (fun r=>r%32∈halfResidues d)).card:=by
  let R:=halfResidues d
  have bound:∀v∈R,v<32:=by intro v hv;obtain ⟨j,_,rfl⟩:=mem_image.mp hv;omega
  have cnt:R.card=5:=by
    change (halfResidues d).card=5
    unfold halfResidues;rw [card_image_of_injOn]
    · decide
    · intro a ha b hb eq
      change a∈({4,12,16,20,28}:Finset ℕ) at ha
      change b∈({4,12,16,20,28}:Finset ℕ) at hb
      simp only [mem_insert,mem_singleton] at ha hb
      have aa:a<32:=by omega
      have bb:b<32:=by omega
      dsimp only at eq;omega
  let A:=(range ((u-l)/32)).product R
  let g (e:ℕ×ℕ):=l+1+32*e.1+(e.2+32-(l+1)%32)%32
  have gd {e:ℕ×ℕ} (he:e∈A):e.1<(u-l)/32 ∧ e.2<32 ∧ (g e)%32=e.2 ∧ l<g e ∧ g e≤u:=by
    obtain ⟨ha,hb⟩:=mem_product.mp he;have j:=mem_range.mp ha;have b:=bound _ hb;dsimp [g];omega
  have hc:A.card≤((Ioc l u).filter (fun r=>r%32∈R)).card:=by
    apply card_le_card_of_injOn g
    · intro e he;have hh:=gd he;exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨hh.2.2.2.1,hh.2.2.2.2⟩,hh.2.2.1 ▸ (mem_product.mp he).2⟩
    · intro e he f hf eq;have e':=gd he;have f':=gd hf
      apply Prod.ext
      · dsimp only [g] at eq;omega
      · omega
  simpa [A,cnt] using hc

end OP02.SharpK7

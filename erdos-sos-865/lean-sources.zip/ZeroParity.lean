import ZeroSource
open Finset
namespace OP02.ZeroExcess
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

def parityIndices (n : ℕ) (B : Finset ℕ) (r : ℕ) : Finset ℤ :=
  (parityMiddle n B r).image (fun x : ℕ => (x/2:ℕ))

theorem parity_indices_mem (n : ℕ) (B : Finset ℕ) {r:ℕ} (hr:r<2) {i:ℤ} :
    i∈parityIndices n B r ↔ ∃x∈parityMiddle n B r, (x:ℤ)=2*i+r := by
  constructor
  · rintro hi
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hi
    refine ⟨x,hx,?_⟩
    have hp := (mem_filter.mp hx).2
    omega
  · rintro ⟨x,hx,he⟩
    refine mem_image.mpr ⟨x,hx,?_⟩
    omega

theorem parity_indices_card (n : ℕ) (B : Finset ℕ) (r:ℕ) :
    (parityIndices n B r).card=(parityMiddle n B r).card := by
  apply card_image_of_injOn
  intro x hx y hy he
  have hp := (mem_filter.mp hx).2
  have hq := (mem_filter.mp hy).2
  dsimp at he
  omega

theorem parity_indices_closed (n : ℕ) (B : Finset ℕ)
    (hd : DoublingFree B) (he : (excessHoles n B).card=0)
    {r:ℕ} (hr:r<2) (hn : NoEdge B (parityMiddle n B r)) :
    MidClosed (parityIndices n B r) := by
  intro i hi j hj z hz
  obtain ⟨x,hx,hxi⟩ := (parity_indices_mem n B hr).mp hi
  obtain ⟨y,hy,hyj⟩ := (parity_indices_mem n B hr).mp hj
  have hmid : (x+y)%2=0 := by omega
  let v := (x+y)/2
  have hv : x+y=2*v := by dsimp [v]; omega
  have hvM := noedge_midpoint n B hd he hn hx hy hv
  have hvp : v%2=r := by omega
  exact (parity_indices_mem n B hr).mpr ⟨v,mem_filter.mpr ⟨hvM,hvp⟩,by omega⟩

theorem progression_card {a d:ℤ} {k:ℕ} (hd:0<d) :
    (progression a d k).card=k := by
  unfold progression
  rw [card_image_of_injective]
  · exact card_range k
  · intro i j he
    have he' : (i:ℤ)=(j:ℤ) := by nlinarith
    exact_mod_cast he'

theorem progression_parity_lower {a d:ℤ} {k:ℕ} (hd:0<d) (ho:d%2=1)
    {r:ℤ} (hr:0≤r) (hr':r<2) :
    k/2 ≤ ((progression a d k).filter (fun x=>x%2=r)).card := by
  let b:ℕ := if a%2=r then 0 else 1
  have hb:b≤1 := by dsimp [b]; split_ifs <;> omega
  let f := fun i:ℕ => a+d*(2*(i:ℤ)+(b:ℤ))
  have hsub : (range (k/2)).image f ⊆ (progression a d k).filter (fun x=>x%2=r) := by
    intro x hx
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hx
    have hi' := mem_range.mp hi
    refine mem_filter.mpr ⟨?_,?_⟩
    · refine mem_image.mpr ⟨2*i+b,mem_range.mpr (by omega),?_⟩
      dsimp [f]
    · have hbr : (a+(b:ℤ))%2=r := by
        dsimp [b]
        split_ifs <;> omega
      have hm := Int.mul_emod d (2*(i:ℤ)+(b:ℤ)) 2
      rw [ho] at hm
      have ha := Int.add_emod a (d*(2*(i:ℤ)+(b:ℤ))) 2
      dsimp [f]
      omega
  have hinj : Function.Injective f := by
    intro i j he
    dsimp [f] at he
    have hij:(i:ℤ)=(j:ℤ) := by nlinarith
    exact_mod_cast hij
  have hc := card_le_card hsub
  rw [card_image_of_injective _ hinj,card_range] at hc
  exact hc

theorem even_edgeless_small (n:ℕ) (B:Finset ℕ)
    (hd : DoublingFree B) (he : (excessHoles n B).card=0)
    (hn : NoEdge B (parityMiddle n B 0)) :
    (parityMiddle n B 0).card≤2*deficit n B+1 := by
  obtain ⟨a,d,k,hdp,hdo,hap⟩ := midpoint_progression (parityIndices n B 0)
    (parity_indices_closed n B hd he (by omega) hn)
  have hk : k=(parityMiddle n B 0).card := by
    rw [←parity_indices_card n B 0,hap,progression_card hdp]
  have hlow := progression_parity_lower (k:=k) (a:=a) hdp hdo (r:=1) (by omega) (by omega)
  rw [←hap] at hlow
  have hs : ((parityIndices n B 0).filter (fun x=>x%2=1)) ⊆
      ((middle n B).filter (fun v=>v%4=2)).image (fun v:ℕ=>((v/2:ℕ):ℤ)) := by
    intro i hi
    obtain ⟨hi,hio⟩ := mem_filter.mp hi
    obtain ⟨x,hx,hxe⟩ := (parity_indices_mem n B (by omega : 0<2)).mp hi
    refine mem_image.mpr ⟨x,mem_filter.mpr ⟨(mem_filter.mp hx).1,by omega⟩,by omega⟩
  have hcard := card_le_card hs
  have him := card_image_le (s:=((middle n B).filter (fun v=>v%4=2)))
    (f:=fun v:ℕ=>((v/2:ℕ):ℤ))
  have hbudget := middle_two_mod_four n B hd
  omega

theorem even_indices_odd_budget (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    ((parityIndices n B 0).filter (fun x=>x%2=1)).card ≤ deficit n B := by
  have hs : ((parityIndices n B 0).filter (fun x=>x%2=1)) ⊆
      ((middle n B).filter (fun v=>v%4=2)).image (fun v:ℕ=>((v/2:ℕ):ℤ)) := by
    intro i hi
    obtain ⟨hi,hio⟩ := mem_filter.mp hi
    obtain ⟨x,hx,hxe⟩ := (parity_indices_mem n B (by omega : 0<2)).mp hi
    refine mem_image.mpr ⟨x,mem_filter.mpr ⟨(mem_filter.mp hx).1,by omega⟩,by omega⟩
  exact le_trans (card_le_card hs) (le_trans card_image_le (middle_two_mod_four n B hd))

theorem adjacent_midpoints_even (n:ℕ) (B:Finset ℕ)
    (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hn:NoEdge B (parityMiddle n B 1))
    {a d:ℤ} {k:ℕ} (ho:d%2=1)
    (hap:parityIndices n B 1=progression a d k) :
    progression (a+(d+1)/2) d (k-1) ⊆ parityIndices n B 0 := by
  intro z hz
  obtain ⟨i,hi,rfl⟩ := mem_image.mp hz
  have hi' := mem_range.mp hi
  have hp : a+d*(i:ℤ)∈parityIndices n B 1 := by
    rw [hap]
    exact mem_image.mpr ⟨i,mem_range.mpr (by omega),rfl⟩
  have hq : a+d*((i+1:ℕ):ℤ)∈parityIndices n B 1 := by
    rw [hap]
    exact mem_image.mpr ⟨i+1,mem_range.mpr (by omega),rfl⟩
  obtain ⟨x,hx,hxe⟩ := (parity_indices_mem n B (by omega : 1<2)).mp hp
  obtain ⟨y,hy,hye⟩ := (parity_indices_mem n B (by omega : 1<2)).mp hq
  have hshift : a+d*((i+1:ℕ):ℤ)=a+d*(i:ℤ)+d := by push_cast; ring
  rw [hshift] at hye
  have hpar : (x+y)%2=0 := by omega
  have hvM := noedge_midpoint n B hd he hn hx hy
    (z:=(x+y)/2) (by omega)
  have hvp : ((x+y)/2)%2=0 := by omega
  apply (parity_indices_mem n B (by omega : 0<2)).mpr
  refine ⟨(x+y)/2,mem_filter.mpr ⟨hvM,hvp⟩,?_⟩
  omega

theorem odd_edgeless_small (n:ℕ) (B:Finset ℕ)
    (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    (hn:NoEdge B (parityMiddle n B 1)) :
    (parityMiddle n B 1).card ≤ 2*deficit n B+2 := by
  obtain ⟨a,d,k,hdp,hdo,hap⟩ := midpoint_progression (parityIndices n B 1)
    (parity_indices_closed n B hd he (by omega) hn)
  have hk : k=(parityMiddle n B 1).card := by
    rw [←parity_indices_card n B 1,hap,progression_card hdp]
  have hs := adjacent_midpoints_even n B hd he hn hdo hap
  have hs' : ((progression (a+(d+1)/2) d (k-1)).filter (fun x=>x%2=1)) ⊆
      (parityIndices n B 0).filter (fun x=>x%2=1) := by
    intro x hx
    exact mem_filter.mpr ⟨hs (mem_filter.mp hx).1,(mem_filter.mp hx).2⟩
  have hlow := progression_parity_lower (k:=k-1) (a:=a+(d+1)/2)
    hdp hdo (r:=1) (by omega) (by omega)
  have hc := card_le_card hs'
  have hb := even_indices_odd_budget n B hd
  omega

#print axioms parity_indices_closed
#print axioms even_edgeless_small
#print axioms odd_edgeless_small
end OP02.ZeroExcess

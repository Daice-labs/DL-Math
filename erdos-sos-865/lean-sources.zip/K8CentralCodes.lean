import K8UpperTriangleShapes

open Finset OP02.SharpK5
namespace OP02.SharpK8

private def GoodCode (v : ℕ) : Prop :=
  v%2=1 ∨ v%8=4 ∨ v%32=16 ∨ v%128=64

private theorem canonical_of_code {v : ℕ} (h : GoodCode v) : canonical v = true := by
  rcases h with h|h|h|h
  · exact canonical_odd v h
  · exact canonical_four_residue v h
  · have eq : v=4*(v/4) := by omega
    rw [eq,canonical_four]
    exact canonical_four_residue _ (by omega)
  · have eq : v=4*(4*(v/16)) := by omega
    rw [eq,canonical_four,canonical_four]
    exact canonical_four_residue _ (by omega)

private def evenCodes := (range 128).filter (fun v => v%8=4 ∨ v%32=16 ∨ v%128=64)

private theorem code_bank (d : ℕ) :
    ∃ A : Finset ℕ, 42≤A.card ∧ (∀j∈A,j<128) ∧
      ∀ v : ℕ, v%128∈A → GoodCode v ∧ GoodCode (v+d) := by
  classical
  by_cases hd : d%2=0
  · let A := (range 128).filter (fun v => v%2=1)
    refine ⟨A,by decide,fun _ h=>mem_range.mp (mem_filter.mp h).1,?_⟩
    intro v hv
    have ho := (mem_filter.mp hv).2
    change (v%128)%2=1 at ho
    exact ⟨Or.inl (by omega),Or.inl (by omega)⟩
  let rot := fun j : ℕ => (j+128-d%128)%128
  let B := evenCodes.image rot
  have ecard : evenCodes.card=21 := by decide
  have eji (j : ℕ) (hj : j∈evenCodes) :
      j<128 ∧ (j%8=4 ∨ j%32=16 ∨ j%128=64) := ⟨mem_range.mp (mem_filter.mp hj).1,(mem_filter.mp hj).2⟩
  have inj : Set.InjOn rot (evenCodes : Set ℕ) := by
    intro j hj k hk he
    have hji := (eji j hj).1
    have hki := (eji k hk).1
    dsimp [rot] at he
    omega
  have bc : B.card=21 := (card_image_of_injOn inj).trans ecard
  have dj : Disjoint evenCodes B := by
    apply disjoint_left.mpr
    intro u he hr
    obtain ⟨j,hj,rfl⟩ := mem_image.mp hr
    obtain ⟨_,hj'⟩ := eji j hj
    obtain ⟨_,he'⟩ := eji (rot j) he
    dsimp [rot] at he'
    rcases hj' with h|h|h <;> rcases he' with h'|h'|h' <;> omega
  refine ⟨evenCodes ∪ B,by rw [card_union_of_disjoint dj,ecard,bc],?_,?_⟩
  · intro j hj
    rcases mem_union.mp hj with h|h
    · exact (eji _ h).1
    · obtain ⟨i,_,rfl⟩:=mem_image.mp h
      exact Nat.mod_lt _ (by decide)
  · intro v hv
    rcases mem_union.mp hv with h|h
    · obtain ⟨_,hj⟩ := eji _ h
      unfold GoodCode
      rcases hj with hj|hj|hj <;> omega
    · obtain ⟨j,hj,eq⟩ := mem_image.mp h
      obtain ⟨jlt,hj'⟩ := eji j hj
      dsimp [rot] at eq
      unfold GoodCode
      rcases hj' with hj'|hj'|hj' <;> omega

structure CentralPattern (F : Finset ℕ) where
  modulus : ℕ
  codes : Finset ℕ
  residue : ℕ
  load : ℕ
  size : (modulus=32 ∧ 1≤codes.card ∧ load=3) ∨
    (modulus=2048 ∧ 42≤codes.card ∧ load=2)
  bounded : ∀ r∈codes,r < modulus
  safe : ∀ x : ℕ, x%modulus∈codes →
    x%4=0 ∧ x%16=residue ∧ ∀ f∈F, canonical (x+4*f)=true
  fibres : ∀ j : ℕ, (F.filter (fun f=> f%4=j)).card≤load

private theorem pair_pattern {s₀ s₁ : ℕ} {F : Finset ℕ}
    (hs : s₀ ≤ s₁) (hmod : s₀%4=s₁%4)
    (others : ∀ f∈F, f=s₀ ∨ f=s₁ ∨ f%2≠s₀%2)
    (fib : ∀ j : ℕ, (F.filter (fun f=>f%4=j)).card≤2) : Nonempty (CentralPattern F) := by
  classical
  let d := (s₁-s₀)/4
  have step : s₁=s₀+4*d := by dsimp [d];omega
  obtain ⟨A,card,bd,goods⟩ := code_bank d
  let rot := fun j : ℕ => (16*j+2048-(4*s₀)%2048)%2048
  let C := A.image rot
  have inj : Set.InjOn rot (A : Set ℕ) := by
    intro x hx y hy eq
    have bx := bd _ hx
    have by' := bd _ hy
    dsimp [rot] at eq
    omega
  have cc : C.card=A.card := card_image_of_injOn inj
  refine ⟨⟨2048,C,(16-(4*s₀)%16)%16,2,Or.inr ⟨rfl,by omega,rfl⟩,?_,?_,fib⟩⟩
  · intro x hx
    obtain ⟨j,hj,rfl⟩ := mem_image.mp hx
    exact Nat.mod_lt _ (by decide)
  · intro x hx
    obtain ⟨j,hj,eq⟩ := mem_image.mp hx
    have jl := bd j hj
    dsimp [rot] at eq
    let v := (x+4*s₀)/16
    have ve : x+4*s₀=16*v := by dsimp [v];omega
    have vm : v%128=j := by dsimp [v];omega
    obtain ⟨g₀,g₁⟩ := goods v (vm.symm ▸ hj)
    refine ⟨by omega,by omega,?_⟩
    intro f hf
    rcases others f hf with h|h|h
    · have he : x+4*f=4*(4*v) := by omega
      rw [he,canonical_four,canonical_four]
      exact canonical_of_code g₀
    · have he : x+4*f=4*(4*(v+d)) := by omega
      rw [he,canonical_four,canonical_four]
      exact canonical_of_code g₁
    · have he : x+4*f=4*(x/4+f) := by omega
      rw [he,canonical_four]
      exact canonical_odd _ (by omega)

theorem triangle_pattern {a c b : ℕ} (ac : a<c) (shape : UpperTriangleShape a c b) :
    Nonempty (CentralPattern ({0,a,c,b}:Finset ℕ)) := by
  classical
  rcases shape with ⟨ae,ce,bo⟩ | ⟨ao,co,other⟩
  · let r := (12-b%8)%8
    let code := 4*r
    have rl : r<8 := Nat.mod_lt _ (by decide)
    refine ⟨⟨32,{code},code%16,3,Or.inl ⟨rfl,by simp,rfl⟩,?_,?_,?_⟩⟩
    · intro j hj
      have := mem_singleton.mp hj
      dsimp [code] at this
      omega
    · intro x hx
      have eq := mem_singleton.mp hx
      change x%32=4*((12-b%8)%8) at eq
      refine ⟨by omega,by dsimp [code,r];omega,?_⟩
      intro f hf
      have he : x+4*f = 4*(x/4+f) := by omega
      rw [he,canonical_four]
      simp only [mem_insert,mem_singleton] at hf
      rcases hf with rfl|rfl|rfl|rfl
      · exact canonical_odd _ (by omega)
      · exact canonical_odd _ (by omega)
      · exact canonical_odd _ (by omega)
      · exact canonical_four_residue _ (by omega)
    · intro j
      by_cases h : j%2=0
      · apply (card_le_card (t:={0,a,c}) ?_).trans card_le_three
        intro f hf
        obtain ⟨hf,he⟩ := mem_filter.mp hf
        simp only [mem_insert,mem_singleton] at hf ⊢
        rcases hf with h'|h'|h'|h' <;> omega
      · apply (card_le_card (t:={b}) ?_).trans (by simp : ({b}:Finset ℕ).card≤3)
        intro f hf
        obtain ⟨hf,he⟩ := mem_filter.mp hf
        simp only [mem_insert,mem_singleton] at hf ⊢
        rcases hf with h'|h'|h'|h' <;> omega
  · have be : b%2=0 := by rcases other with ⟨_,h⟩|⟨_,h⟩ <;> omega
    have fib (j : ℕ) : (({0,a,c,b}:Finset ℕ).filter (fun f=>f%4=j)).card≤2 := by
      by_cases h : j%2=0
      · apply (card_le_card (t:={0,b}) ?_).trans card_le_two
        intro f hf
        obtain ⟨hf,he⟩ := mem_filter.mp hf
        simp only [mem_insert,mem_singleton] at hf ⊢
        rcases hf with h'|h'|h'|h' <;> omega
      · apply (card_le_card (t:={a,c}) ?_).trans card_le_two
        intro f hf
        obtain ⟨hf,he⟩ := mem_filter.mp hf
        simp only [mem_insert,mem_singleton] at hf ⊢
        rcases hf with h'|h'|h'|h' <;> omega
    by_cases h4 : b%4=0
    · apply pair_pattern (s₀:=0) (s₁:=b) (by omega) (by omega) _ fib
      intro f hf
      simp only [mem_insert,mem_singleton] at hf
      rcases hf with h|h|h|h <;> omega
    · have eq : a%4=c%4 := by rcases other with ⟨h,_⟩|⟨_,h⟩ <;> omega
      apply pair_pattern (s₀:=a) (s₁:=c) ac.le eq _ fib
      intro f hf
      simp only [mem_insert,mem_singleton] at hf
      rcases hf with h|h|h|h <;> omega

end OP02.SharpK8

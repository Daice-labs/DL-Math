import K6BadTriangle
import K6RootTopCharge
open Finset Erdos865
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 6000000

/-- First bootstrap stage: an actual high odd edge of sum 4 modulo 8
cannot survive the joint root-top and qualification budgets. -/
theorem no_high_sum_four (β:ℝ) (n u v:ℕ) (B:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hgap:PositiveGap6 β n B)
    (hn:65536≤n) (hbn:(10:ℝ)≤β*n)
    (hcap:384*(chainDeficit n B+totalBudget n B)≤n)
    (hbudget:3*(canonicalHoles n B).card<n/128)
    (hu:u∈lower n B) (hv:v∈lower n B) (huv:u<v)
    (huo:u%2=1) (hvo:v%2=1) (huL:n<2*u) (hvL:n<2*v)
    (huH:u≤n-4*(n/16)) (hvH:v≤n-4*(n/16))
    (hsum8:(u+v)%8=4) : u+v∉B := by
  classical
  intro hsum
  have hop:u%4≠v%4:=by omega
  obtain ⟨T,hT,hTc,hpair,hres⟩:=actual_bad_triangle β n u v B hf hd hgap hbn hu hv huo hvo hop hsum huL hvL huH hvH hbudget
  obtain ⟨_,r,hr,s,hs,hrs,hrpar,hrsum⟩:=actual_qualified_structures β n u v B hd hgap hbn huo hvo hop huL hvL huH hvH
  have hrD: r∈quarterD n B := (mem_filter.mp (mem_filter.mp hr).1).1
  have hsD: s∈quarterD n B := (mem_filter.mp (mem_filter.mp hs).1).1
  have hrsD:r+s∈quarterD n B := (mem_filter.mp (mem_filter.mp hrsum).1).1
  have hrI:=mem_Icc.mp (qualified_prefix_subset n (n/64) u v B hr)
  have hsI:=mem_Icc.mp (qualified_prefix_subset n (n/64) u v B hs)
  have hrqual:=(mem_filter.mp hr).2
  have hsqual:=(mem_filter.mp hs).2
  have hTD:T⊆quarterD n B:=fun t ht=>(mem_filter.mp (mem_filter.mp (hT ht)).1).1
  have hTqual:∀t∈T,u+4*t∈B ∧ v+4*t∈B:=fun t ht=>(mem_filter.mp (hT ht)).2
  let L:=(2*n-u)/8
  let U:=n/4-max r s
  let m:=if r%2=0 then 4 else 8
  let a:=if r%2=0 then 1 else 4
  let Y:=progression L U m a
  let F:=Y.filter (fun x=>∃t∈({0,r,s}:Finset ℕ),x+t∉quarterD n B)
  let G:=Y.filter (fun x=>u+4*x∉B ∨ v+4*x∉B)
  have hY (x:ℕ) (hx:x∈Y): L<x ∧ x≤U ∧
      ((r%2=0 ∧ x%4=1) ∨ (r%2=1 ∧ x%8=4)) := by
    obtain ⟨hxI,hxr⟩:=mem_filter.mp hx
    obtain ⟨hl,hh⟩:=mem_Ioc.mp hxI
    refine ⟨hl,hh,?_⟩
    dsimp only [m,a] at hxr
    split_ifs at hxr with he
    · exact Or.inl ⟨he,hxr⟩
    · exact Or.inr ⟨by omega,hxr⟩
  have hgeom (x:ℕ) (hx:x∈Y): n/4<2*x ∧ n/64<x ∧ x+r≤n/4 ∧ x+s≤n/4 ∧
      2*n<u+8*x ∧ 2*n<v+8*x ∧ u+8*x+n≤4*n ∧ v+8*x+n≤4*n := by
    have hh:=hY x hx
    dsimp only [L,U] at hh
    have hm1:=le_max_left r s
    have hm2:=le_max_right r s
    omega
  have hcan (x:ℕ) (hx:x∈Y) (t:ℕ) (ht:t∈({0,r,s}:Finset ℕ)):canonical (x+t)=true := by
    have hh:=hY x hx
    simp only [mem_insert,mem_singleton] at ht
    rcases hh.2.2 with ⟨he,hxmod⟩|⟨he,hxmod⟩
    · rcases ht with rfl|rfl|rfl <;> apply canonical_odd <;> omega
    · rcases ht with rfl|rfl|rfl
      · exact canonical_four_residue _ (by omega)
      · exact canonical_odd _ (by omega)
      · exact canonical_odd _ (by omega)
  have hfail:∀x∈F,∃t∈({0,r,s}:Finset ℕ),n/4<2*(x+t) ∧ x+t≤n/4 ∧
      canonical (x+t)=true ∧ x+t∉quarterD n B := by
    intro x hx
    obtain ⟨hxY,t,ht,hbad⟩:=mem_filter.mp hx
    have hg:=hgeom x hxY
    refine ⟨t,ht,by omega,?_,hcan x hxY t ht,hbad⟩
    simp only [mem_insert,mem_singleton] at ht
    rcases ht with rfl|rfl|rfl <;> omega
  have hFc:F.card≤(if r%2=0 then 3 else 2)*chainDeficit n B := by
    by_cases he:r%2=0
    · simp only [if_pos he]
      exact root_top_failure_charge_three n B F r s hd hfail
    · simp only [if_neg he]
      apply root_top_failure_charge n 4 2 B F {0,r,s} hd
      · intro x hx
        have hh:=hY x (mem_filter.mp hx).1
        omega
      · intro j
        by_cases hj:j%2=0
        · have hsub:({0,r,s}:Finset ℕ).filter (fun t=>t%8=j)⊆{0} := by
            intro t ht
            obtain ⟨ht,htr⟩:=mem_filter.mp ht
            simp only [mem_insert,mem_singleton] at ht ⊢
            rcases ht with rfl|rfl|rfl <;> omega
          have:=card_le_card hsub
          simp only [card_singleton] at this
          omega
        · have hsub:({0,r,s}:Finset ℕ).filter (fun t=>t%8=j)⊆{r,s} := by
            intro t ht
            obtain ⟨ht,htr⟩:=mem_filter.mp ht
            simp only [mem_insert,mem_singleton] at ht ⊢
            rcases ht with rfl|rfl|rfl <;> omega
          exact le_trans (card_le_card hsub) card_le_two
      · exact hfail
  have hGc:G.card≤totalBudget n B := by
    apply actual_bootstrap_qualification_charge n u v (if r%2=0 then 1 else 0) B T G hf hd hu hv (by omega) huo hvo hsum hsum8 hTD hTc hpair hTqual hres
    · intro x hx
      have hh:=hY x (mem_filter.mp hx).1
      split_ifs <;> omega
    · intro x hx
      have hh:=hgeom x (mem_filter.mp hx).1
      exact ⟨hh.2.2.2.2.1,hh.2.2.2.2.2.1,hh.2.2.2.2.2.2.1,hh.2.2.2.2.2.2.2⟩
    · intro x hx
      exact (mem_filter.mp hx).2
  have hlarge:F.card+G.card<Y.card := by
    have hm1:=le_max_left r s
    have hm2:=le_max_right r s
    have hm3:max r s≤n/64:=max_le hrI.2 hsI.2
    by_cases he:r%2=0
    · have hlow:=progression_lower L U 4 1 (by simp) (by omega)
      have hYeq:Y=progression L U 4 1 := by simp [Y,m,a,he]
      rw [←hYeq] at hlow
      simp only [if_pos he] at hFc
      dsimp only [L,U] at hlow
      omega
    · have hlow:=progression_lower L U 8 4 (by simp) (by omega)
      have hYeq:Y=progression L U 8 4 := by simp [Y,m,a,he]
      rw [←hYeq] at hlow
      simp only [if_neg he] at hFc
      dsimp only [L,U] at hlow
      omega
  have hex:∃x∈Y,x∉F ∧ x∉G := by
    by_contra h
    have hsub:Y⊆F∪G := by
      intro x hx
      by_cases hxF:x∈F
      · exact mem_union_left _ hxF
      · apply mem_union_right
        by_contra hxG
        exact h ⟨x,hx,hxF,hxG⟩
    have hc:=card_le_card hsub
    have hu:=card_union_le F G
    omega
  obtain ⟨x,hxY,hxF,hxG⟩:=hex
  have hxgeom:=hgeom x hxY
  have hxroots:∀t∈({0,r,s}:Finset ℕ),x+t∈quarterD n B := by
    intro t ht
    by_contra hbad
    exact hxF (mem_filter.mpr ⟨hxY,t,ht,hbad⟩)
  have hxD:x∈quarterD n B := by simpa using hxroots 0 (by simp)
  have hxrD:x+r∈quarterD n B:=hxroots r (by simp)
  have hxsD:x+s∈quarterD n B:=hxroots s (by simp)
  have hxqual:u+4*x∈B ∧ v+4*x∈B := by
    by_contra h
    have hh:u+4*x∉B ∨ v+4*x∉B := by tauto
    exact hxG (mem_filter.mpr ⟨hxY,hh⟩)
  let T':Finset ℕ:={r,s,x}
  have hT'D:T'⊆quarterD n B := by
    intro t ht
    simp only [T',mem_insert,mem_singleton] at ht
    rcases ht with rfl|rfl|rfl <;> assumption
  have hT'c:T'.card=3 := by
    have hrx:r≠x:=by omega
    have hsx:s≠x:=by omega
    simp [T',hrs,hrx,hsx]
  have hT'pair:∀a∈T',∀b∈T',a≠b → a+b∈quarterD n B := by
    intro a ha b hb hab
    simp only [T',mem_insert,mem_singleton] at ha hb
    rcases ha with rfl|rfl|rfl <;> rcases hb with rfl|rfl|rfl <;>
      simp_all only [ne_eq,not_true_eq_false,Nat.add_comm]
  have hT'q:∀a∈T',u+4*a∈B ∧ v+4*a∈B := by
    intro a ha
    simp only [T',mem_insert,mem_singleton] at ha
    rcases ha with rfl|rfl|rfl <;> assumption
  have hgood:∃j<4,∀t∈insert 0 T',t%4≠j := by
    have hh:=hY x hxY
    rcases hh.2.2 with ⟨he,hxm⟩|⟨he,hxm⟩
    · refine ⟨3,by omega,?_⟩
      intro t ht
      simp only [T',mem_insert,mem_singleton] at ht
      rcases ht with rfl|rfl|rfl|rfl <;> omega
    · refine ⟨2,by omega,?_⟩
      intro t ht
      simp only [T',mem_insert,mem_singleton] at ht
      rcases ht with rfl|rfl|rfl|rfl <;> omega
  exact good_triangle_excluded n u v B T' hf hu hv (by omega) huo hvo hsum hT'D hT'c hT'pair hT'q hgood hbudget

#print axioms no_high_sum_four
end OP02.SharpK6

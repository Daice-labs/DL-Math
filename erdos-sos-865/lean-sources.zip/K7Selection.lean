import K7Newton

open Finset Polynomial
namespace OP02.SharpK7

/-- The disjoint reflection pairs admit a common surviving base, under the
strict signed threshold, even when the two veto sets intersect. -/
theorem commonBaseSelection : CommonBaseSelection := by
  classical
  intro I U F A e hA hsmall hcard
  let node (a : ℤ) := a*(e-a)
  let nodes := A.toList.map node
  have hinj : ∀ a ∈ A.toList, ∀ b ∈ A.toList, node a = node b → a=b := by
    intro a ha b hb hab
    obtain ⟨_,ha'⟩ := hsmall a (mem_toList.mp ha)
    obtain ⟨_,hb'⟩ := hsmall b (mem_toList.mp hb)
    have hz : (a-b)*(e-a-b)=0 := by
      unfold node at hab; nlinarith only [hab]
    rcases mul_eq_zero.mp hz with he | he <;> omega
  have hn : nodes.Nodup := List.Nodup.map_on hinj A.nodup_toList
  have hlen : (nodes.take (U.card+1)).length = min (U.card+1) A.card := by
    simp [nodes]
  have hapos : 0 < A.card := card_pos.mpr hA
  cases hc : nodes.take (U.card+1) with
  | nil => simp [hc] at hlen; omega
  | cons x xs =>
    rw [hc, List.length_cons] at hlen
    have hnd : (x::xs).Nodup := hc ▸ (List.take_sublist _ nodes).nodup hn
    have hxl : xs.length ≤ U.toList.length := by simp; omega
    obtain ⟨hpoly, hdeg, _⟩ := Interpolation.certificate_degree e U.toList x xs hxl
    let G := (I \ F) \ U
    by_contra hwin
    have hroots : G.val ⊆ (Interpolation.certificate e U.toList x xs).roots := by
      intro g hg
      have hg' : g ∈ G := hg
      obtain ⟨hIF,hU⟩ := mem_sdiff.mp hg'
      obtain ⟨hI,hF⟩ := mem_sdiff.mp hIF
      apply (mem_roots hpoly).mpr
      apply Interpolation.vanish e U.toList g x xs hnd
      intro y hy
      have hm : y ∈ nodes.take (U.card+1) := hc.symm ▸ hy
      obtain ⟨a,ha,hay⟩ := List.mem_map.mp (List.mem_of_mem_take hm : y ∈ nodes)
      have haA := mem_toList.mp ha
      subst y
      by_cases hleft : g+a ∈ U
      · exact Interpolation.singleton_zero e g (node a) (g+a) U.toList
          (mem_toList.mpr hleft) (by unfold node; ring)
      · have hright : g+(e-a) ∈ U := by
          by_contra hn'; exact hwin ⟨g,hI,hU,hF,a,haA,hleft,hn'⟩
        exact Interpolation.singleton_zero e g (node a) (g+(e-a)) U.toList
          (mem_toList.mpr hright) (by unfold node; ring)
    have hnum := Polynomial.card_le_degree_of_subset_roots hroots
    rw [hdeg, length_toList] at hnum
    have h1 := card_sdiff_add_card_inter I F
    have h2 := card_sdiff_add_card_inter (I \ F) U
    have h3 : ((I \ F) ∩ U).card ≤ U.card := card_le_card inter_subset_right
    change ((I \ F) \ U).card ≤ _ at hnum
    omega

end OP02.SharpK7

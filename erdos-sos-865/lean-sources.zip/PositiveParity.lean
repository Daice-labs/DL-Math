import PivotResources
open Finset
namespace OP02.PositivePivot
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess

/-- Two translates meet only at their common extreme; no additive-combinatorics oracle. -/
theorem sum_union_lower (S T F:Finset ℕ) (hS:S.Nonempty) (hT:T.Nonempty)
    (hadd:∀ x ∈ S, ∀ y ∈ T, x+y∈F) : S.card+T.card≤F.card+1 := by
  let a:=S.max' hS
  let b:=T.min' hT
  let X:=S.image (fun x=>x+b)
  let Y:=T.image (fun y=>a+y)
  have ha:a∈S:=max'_mem S hS
  have hb:b∈T:=min'_mem T hT
  have hX:X.card=S.card := card_image_of_injective _ (by intro x y h; dsimp only at h; omega)
  have hY:Y.card=T.card := card_image_of_injective _ (by intro x y h; dsimp only at h; omega)
  have hsub:X∪Y⊆F := by
    intro z hz
    rcases mem_union.mp hz with hx|hy
    · obtain ⟨x,hxs,rfl⟩:=mem_image.mp hx
      exact hadd x hxs b hb
    · obtain ⟨y,hyt,rfl⟩:=mem_image.mp hy
      exact hadd a ha y hyt
  have hi:X∩Y⊆{a+b} := by
    intro z hz
    obtain ⟨x,hx,hxz⟩:=mem_image.mp (mem_inter.mp hz).1
    obtain ⟨y,hy,hyz⟩:=mem_image.mp (mem_inter.mp hz).2
    have hxa:x≤a:=le_max' S x hx
    have hby:b≤y:=min'_le T y hy
    simp only [mem_singleton]
    omega
  have hc:=card_union_add_card_inter X Y
  have hcu:=card_le_card hsub
  have hci:=card_le_card hi
  simp only [card_singleton] at hci
  omega

/-- Missing upper positions split into doubled actual middle members or actual excess. -/
theorem missing_split {n z:ℕ} {B:Finset ℕ} (hz:2*n<z ∧ z≤4*n) (hB:z∉B) :
    (∃v∈middle n B,2*v=z) ∨ z∈excessHoles n B := by
  by_cases h:z∈(middle n B).image (fun v=>2*v)
  · exact Or.inl (mem_image.mp h)
  · exact Or.inr (mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,hz.2⟩,hB⟩,h⟩)

/-- Positive-excess version: omitted even members and H0 holes remain visible. -/
theorem actual_even_subset (n:ℕ) (B P:Finset ℕ) (hd:DoublingFree B)
    (hP:P⊆parityMiddle n B 0) (hn:NoEdge B P) :
    P.card≤2*deficit n B+(H0 n B).card+((parityMiddle n B 0)\P).card+1 := by
  let E:=parityMiddle n B 0
  let P0:=P.filter (fun x=>x%4=0)
  let P2:=P.filter (fun x=>x%4=2)
  have hpart:P0∪P2=P := by
    ext x
    simp only [P0,P2,mem_union,mem_filter]
    constructor
    · rintro (⟨h,_⟩|⟨h,_⟩) <;> exact h
    · intro hx
      have hp: x%2=0 := (mem_filter.mp (hP hx)).2
      by_cases h:x%4=0
      · exact Or.inl ⟨hx,h⟩
      · exact Or.inr ⟨hx,by omega⟩
  have hdis:Disjoint P0 P2 := by
    apply disjoint_left.mpr
    intro x hx hy
    have h0:=(mem_filter.mp hx).2
    have h2:=(mem_filter.mp hy).2
    omega
  have hcards:P0.card+P2.card=P.card := by rw [←card_union_of_disjoint hdis,hpart]
  have hp2:P2.card≤deficit n B := by
    have hs:P2⊆(middle n B).filter (fun x=>x%4=2) := by
      intro x hx
      exact mem_filter.mpr ⟨(mem_filter.mp (hP (mem_filter.mp hx).1)).1,(mem_filter.mp hx).2⟩
    exact le_trans (card_le_card hs) (middle_two_mod_four n B hd)
  have hrestore: (E\P).card+P.card=E.card := card_sdiff_add_card_eq_card hP
  by_cases hzero:P0=∅
  · have hc:P0.card=0:=by rw [hzero,card_empty]
    omega
  have hne:P0.Nonempty:=nonempty_iff_ne_empty.mpr hzero
  let F:=(E.image (fun x=>2*x))∪H0 n B
  have hsum:∀ x ∈ P0, ∀ y ∈ P0, x+y∈F := by
    intro x hx y hy
    obtain ⟨hxP,hx4⟩:=mem_filter.mp hx
    obtain ⟨hyP,hy4⟩:=mem_filter.mp hy
    have hxM:=(mem_filter.mp (hP hxP)).1
    have hyM:=(mem_filter.mp (hP hyP)).1
    have hxi:=mem_Icc.mp (mem_inter.mp hxM).2
    have hyi:=mem_Icc.mp (mem_inter.mp hyM).2
    have hb:x+y∉B := by
      by_cases he:x=y
      · subst y
        have hh:=hd x (mem_inter.mp hxM).1
        simpa [two_mul] using hh
      · exact hn x hxP y hyP he
    rcases missing_split (n:=n) (by omega) hb with him|hh
    · obtain ⟨v,hv,hve⟩:=him
      apply mem_union_left
      exact mem_image.mpr ⟨v,mem_filter.mpr ⟨hv,by omega⟩,hve⟩
    · apply mem_union_right
      exact mem_filter.mpr ⟨hh,by omega⟩
  have hc:=sum_union_lower P0 P0 F hne hne hsum
  have hF:F.card≤E.card+(H0 n B).card := by
    have hu:=card_union_le (E.image (fun x=>2*x)) (H0 n B)
    have hi:=card_image_le (s:=E) (f:=fun x=>2*x)
    dsimp [F]
    omega
  dsimp [E] at *
  omega

theorem actual_even_edgeless (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B)
    (hn:NoEdge B (parityMiddle n B 0)) :
    (parityMiddle n B 0).card≤2*deficit n B+(H0 n B).card+1 := by
  have h:=actual_even_subset n B (parityMiddle n B 0) hd (by exact Subset.rfl) hn
  simpa using h

#print axioms sum_union_lower
#print axioms actual_even_subset
#print axioms actual_even_edgeless
end OP02.PositivePivot

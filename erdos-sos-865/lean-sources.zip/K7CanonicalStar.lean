import K7StarOwners
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- The finite residues in this proof use only odd normalized roots
and roots of valuations two and four. No native computation is trusted. -/
def basicCanonical (x:ℕ):Prop:=x%2=1 ∨ x%8=4 ∨ x%32=16
instance (x:ℕ) : Decidable (basicCanonical x):=inferInstanceAs (Decidable (_∨_∨_))

private theorem basic_canonical_sound {x:ℕ} (h:basicCanonical x):canonical x=true:=by
  rcases h with h|h|h
  · exact canonical_odd _ h
  · rw [show x=4*(x/4) by omega,canonical_four];exact canonical_odd _ (by omega)
  · rw [show x=4*(4*(x/16)) by omega,canonical_four,canonical_four];exact canonical_odd _ (by omega)

def starResidues (b:ℕ) (ee:Bool):Finset ℕ:=(range 128).filter (fun r=>
  if ee then (r+b)%8=4 else r%4=0 ∧ basicCanonical (r/4) ∧ basicCanonical ((r+b)/4))

/-- One fixed finite residue calculation for a cyclic shift on 32
normalized classes; every larger parameter is reduced to this period. -/
private theorem residue_template :
    (∀j:Fin 8,16≤(starResidues j true).card) ∧
    (∀j:Fin 32,10≤(starResidues (4*(j:ℕ)) false).card) := by
  set_option maxRecDepth 20000 in
    set_option maxHeartbeats 4000000 in decide

theorem star_residue_card (b:ℕ) :
    16≤(starResidues b true).card ∧ (b%4=0→10≤(starResidues b false).card):=by
  have ee:starResidues b true=starResidues (b%8) true:=by
    ext r;simp only [starResidues,mem_filter,mem_range,ite_true];omega
  have oo:starResidues b false=starResidues (b%128) false:=by
    ext r;simp only [starResidues,mem_filter,mem_range,Bool.false_eq_true,ite_false,basicCanonical];omega
  constructor
  · rw [ee];exact residue_template.1 ⟨b%8,by omega⟩
  · intro h;rw [oo,show b%128=4*((b/4)%32) by omega]
    exact residue_template.2 ⟨(b/4)%32,by omega⟩

def starTests (l u b:ℕ) (ee:Bool):Finset ℕ:=(Ioc l u).filter (fun z=>z%128∈starResidues b ee)

/-- First pack complete consecutive blocks of 128. For every chosen
class there is one actual integer in each block, including a fractional
initial endpoint. A single final partial block is lost globally. -/
theorem block128_count (l u:ℕ) (R:Finset ℕ) (hr:∀r∈R,r<128) :
    ((u-l)/128)*R.card≤((Ioc l u).filter (fun z=>z%128∈R)).card:=by
  let A:=(range ((u-l)/128)).product R
  let g (e:ℕ×ℕ):=l+1+128*e.1+(e.2+128-(l+1)%128)%128
  have hge {e:ℕ×ℕ} (he:e∈A):
      e.1<(u-l)/128 ∧ e.2<128 ∧ (g e)%128=e.2 ∧ l<g e ∧ g e≤u:=by
    obtain ⟨hx,hy⟩:=mem_product.mp he
    have j:=mem_range.mp hx;have r:=hr _ hy
    dsimp [g];omega
  have h: A.card≤((Ioc l u).filter (fun z=>z%128∈R)).card:=by
    apply card_le_card_of_injOn g
    · intro e he;have hh:=hge he;exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨hh.2.2.2.1,hh.2.2.2.2⟩,hh.2.2.1 ▸ (mem_product.mp he).2⟩
    · intro x hx y hy hxy
      have xx:=hge hx;have yy:=hge hy
      apply Prod.ext
      · dsimp only [g] at hxy;omega
      · omega
  simpa [A] using h

private theorem star_data {l u b a c z:ℕ} (P:(a%2=0 ∧ c%2=0 ∧ b%2=1) ∨ (a%2=1 ∧ c%2=1 ∧ b%4=0))
    (hz:z∈starTests l u b (decide (a%2=0))) :
    z%2=(if a%2=0 then 1 else 0) ∧ ∀x∈({0,a,c,b}:Finset ℕ),canonical (z+x)=true:=by
  have hz':=(mem_filter.mp (mem_filter.mp hz).2).2
  rcases P with ⟨ae,ce,bo⟩|⟨ao,co,b4⟩
  · simp only [ae,decide_true,if_true] at hz' ⊢
    have zodd:z%2=1:=by omega
    refine ⟨zodd,?_⟩
    intro x hx;simp only [mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl|rfl <;> first | exact canonical_odd _ (by omega) | apply basic_canonical_sound;right;left;omega
  · have ane:a%2≠0:=by omega
    simp only [ane,decide_false,Bool.false_eq_true,ite_false] at hz' ⊢
    obtain ⟨z4,zc,bc⟩:=hz'
    have sound {x y:ℕ} (h:x%4=0) (h32:(x/4)%32=y%32) (hg:basicCanonical y):canonical x=true:=by
      rw [show x=4*(x/4) by omega,canonical_four]
      apply basic_canonical_sound
      dsimp only [basicCanonical] at hg ⊢;omega
    refine ⟨by omega,?_⟩
    intro x hx;simp only [mem_insert,mem_singleton] at hx
    rcases hx with h|h|h|h
    · subst x;apply sound _ _ zc <;> omega
    · subst x;exact canonical_odd _ (by omega)
    · subst x;exact canonical_odd _ (by omega)
    · subst x;apply sound _ _ bc <;> omega

/-- For any actual EE or OO test triangle this is an admissible fourth
root in the same set. The sufficient width uses only one set of missing
canonical positions. -/
theorem qualified_lower_star {n l u a c b:ℕ} {B:Finset ℕ}
    (hD:DoublingFree B) (hac:a<c) (hcb:c<b) (hlo:n/4/8≤l) (hhi:u+b≤n/4/4)
    (hpat:(a%2=0 ∧ c%2=0 ∧ b%2=1) ∨ (a%2=1 ∧ c%2=1 ∧ b%4=0))
    (hlen:(if a%2=0 then 3 else 2)*(quarterMissing (n/4) (quarterD n B)).card<
      ((u-l)/128)*(if a%2=0 then 16 else 10)) :
    ∃z:ℕ,l<z ∧ z≤u ∧ ∀x∈({0,a,c,b}:Finset ℕ),z+x∈quarterD n B:=by
  classical
  let O:Finset ℕ:={0,a,c,b}
  let R:=starResidues b (decide (a%2=0))
  let P:=starTests l u b (decide (a%2=0))
  let C:=quarterMissing (n/4) (quarterD n B)
  let k:=if a%2=0 then 3 else 2
  let σ:=if a%2=0 then 1 else 0
  have hcnt:=shift_losses P O (quarterD n B) C 2 σ k
    (fun z hz=>(star_data hpat hz).1) (by
      intro z hz x hx ha
      have zz:=mem_Ioc.mp (mem_filter.mp hz).1
      have xb:x≤b:=by simp only [O,mem_insert,mem_singleton] at hx;omega
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,(star_data hpat hz).2 x hx⟩,by omega,by omega,ha⟩) (by
      intro z hz
      rcases hpat with ⟨ae,ce,bo⟩|⟨ao,co,b4⟩
      · simp only [k,σ,if_pos ae]
        by_cases odd:z%2=1
        · apply (card_le_card (t:={0,a,c}) _).trans card_le_three
          intro x hx;obtain ⟨h,p⟩:=mem_filter.mp hx;simp only [O,mem_insert,mem_singleton] at h ⊢;omega
        · apply (card_le_card (t:={b}) _).trans (by simp)
          intro x hx;obtain ⟨h,p⟩:=mem_filter.mp hx;simp only [O,mem_insert,mem_singleton] at h ⊢;omega
      · have ne:a%2≠0:=by omega
        simp only [k,σ,if_neg ne]
        by_cases odd:z%2=1
        · apply (card_le_card (t:={a,c}) _).trans card_le_two
          intro x hx;obtain ⟨h,p⟩:=mem_filter.mp hx;simp only [O,mem_insert,mem_singleton] at h ⊢;omega
        · apply (card_le_card (t:={0,b}) _).trans card_le_two
          intro x hx;obtain ⟨h,p⟩:=mem_filter.mp hx;simp only [O,mem_insert,mem_singleton] at h ⊢;omega)
  have hR:(if a%2=0 then 16 else 10)≤R.card:=by
    rcases hpat with ⟨he,_,_⟩|⟨ho,_,hb⟩
    · simpa [R,he] using (star_residue_card b).1
    · have he:a%2≠0:=by omega
      simpa [R,he] using (star_residue_card b).2 hb
  have hh:((u-l)/128)*R.card≤P.card:=block128_count l u R (fun r hr=>mem_range.mp (mem_filter.mp hr).1)
  have hstrong:k*C.card<P.card:=lt_of_lt_of_le hlen ((Nat.mul_le_mul_left _ hR).trans hh)
  obtain ⟨z,hz⟩:=card_pos.mp (show 0<(passes P O (quarterD n B)).card by omega)
  have hI:=mem_Ioc.mp (mem_filter.mp (mem_filter.mp hz).1).1
  exact ⟨z,hI.1,hI.2,(mem_filter.mp hz).2⟩

end OP02.SharpK7

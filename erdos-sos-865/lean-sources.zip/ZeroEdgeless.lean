import ActualPrefix
import CriticalFromZero
import NearBudget
import BranchArithmetic
open Finset
namespace OP02.BothEdges
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot OP02.EdgeBand

/-- Complete inherited branch theorem, with every counting and selection condition derived. -/
theorem zero_edgeless_bound (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (hen:NoEdge B (middleZero n B)) :
    8*(quarterD n B).card≤n+8*(deficit n B+(excessHoles n B).card)+69 := by
  by_cases hn:n≤32*(deficit n B+(excessHoles n B).card)+64
  · exact near_budget_bound n B hc hn
  have hmargin:32*(deficit n B+(excessHoles n B).card)+64<n:=by omega
  have he:=excess_partition n B
  have hmargin':32*(deficit n B+(H0 n B).card+(H2 n B).card+(Ho n B).card)+64<n := by
    simpa only [he,Nat.add_assoc] using hmargin
  have hek:=even_zero_bound n B hc.2.2.2.1 hen
  obtain ⟨a,b,c,hcrit⟩:=critical_from_zero_edgeless n B hc hen hmargin
  have hpop:=actual_population hcrit hc.2.2.1
  have hsmall:4*((parityMiddle n B 0).card+(H0 n B).card)+4≤n:=by omega
  obtain ⟨r,p,G,bad,hrestore,hpay,hGsub,hp,hp4,hpu,hpB,hpG⟩:=actual_prefix_data n B hsmall
  by_cases hG:G.Nonempty
  · let T:=goodAdjacent n p (actualQ n B) B
    have hQ:(actualQ n B).card≤(parityMiddle n B 0).card+(H0 n B).card := by
      have hu:=card_union_le (parityMiddle n B 0) ((H0 n B).image (fun h=>h/2))
      have hi:=card_image_le (s:=H0 n B) (f:=fun h:ℕ=>h/2)
      dsimp [actualQ];omega
    have hholes:=odd_hole_partition n B
    have hres:∀j,j=1 ∨ j=3→(T.filter (fun z=>z%4=j)).Nonempty := by
      intro j hj
      have hcj:=adjacent_residue_count n p r j (actualQ n B) B hp (by omega) hpu hj
      change n/4+(parityMiddle n B 1).card≤n/2+
        (T.filter (fun z=>z%4=j)).card+(actualQ n B).card+(highOdd n B).card+r+2 at hcj
      have hhi:(highOdd n B).card≤(Ho n B).card:=card_le_card (filter_subset _ _)
      exact card_pos.mp (residue_positive _ _ _ _ _ _ _ _ _ _ _ _ hmargin' hek hpop hQ hhi hpay hcj)
    have hodd:∀z∈T,z%2=1 := by
      intro z hz
      exact (oddPos_mem.mp (mem_filter.mp hz).1).2.2
    have hlow:=root_sum_lower T G hG hodd (hres 1 (Or.inl rfl)) (hres 3 (Or.inr rfl))
    have hup:=root_sum_upper hc.2.2.1 hp hpB hGsub hpG
    change (rootSums T G).card≤2*((missOdd n B).card+(lowOdd n B).card) at hup
    have ht:=adjacent_total_count n p r (actualQ n B) B hp (by omega) hpu
    change 2*(parityMiddle n B 1).card≤n/2+T.card+(actualQ n B).card+2*(highOdd n B).card+2*r+3 at ht
    have hm:=missOdd_card n B
    have hjoint:2*(quarterD n B).card+4*(parityMiddle n B 1).card≤
        3*(n/2)+3*((parityMiddle n B 0).card+(H0 n B).card)+2*(Ho n B).card+5 :=
      restore_joint _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ hrestore hpay hQ hholes hm ht hlow hup
    have hfinal:=restore_target _ _ _ _ _ _ _ _ hmargin' hek hpop hjoint
    simpa only [he,Nat.add_assoc] using hfinal
  · have hg0:G.card=0:=card_eq_zero.mpr (not_nonempty_iff_eq_empty.mp hG)
    omega

#print zero_edgeless_bound
#print axioms zero_edgeless_bound
end OP02.BothEdges

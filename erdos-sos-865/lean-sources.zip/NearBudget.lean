import FocusedSpec
open Finset
namespace OP02.PositivePivot
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

/-- Actual-context bound, without zero-excess or geometric assumptions. -/
theorem near_budget_bound (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (hn:n≤32*(deficit n B+(excessHoles n B).card)+64) :
    8*(quarterD n B).card≤n+8*(deficit n B+(excessHoles n B).card)+69 := by
  have hq:=hc.2.2.2.2.2.1
  have he:8*(excessHoles n B).card<n := by omega
  have ht:=quarter_triple_free n B hc.2.2.1 he
  have hs:quarterD n B⊆Icc 1 (n/4):=filter_subset _ _
  have hu:=Erdos865.erdos865_upper_bound (n/4) (quarterD n B) hs ht
  omega

/-- The exact actual-context necessary margin for any large residual. -/
theorem actual_violation_margin (n K:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (hb:n+8*(deficit n B+(excessHoles n B).card)+K<8*(quarterD n B).card) :
    32*(deficit n B+(excessHoles n B).card)+4*K<n+212 := by
  have hq:=hc.2.2.2.2.2.1
  have ht:=quarter_triple_free n B hc.2.2.1 (by omega)
  have hs:quarterD n B⊆Icc 1 (n/4):=filter_subset _ _
  have hu:=Erdos865.erdos865_upper_bound (n/4) (quarterD n B) hs ht
  omega

#print near_budget_bound
#print axioms near_budget_bound
#print axioms actual_violation_margin
end OP02.PositivePivot

import K6LocalFolding
open Finset Erdos865
namespace OP02.SharpK6
set_option maxHeartbeats 2000000

/-- Vertices lie below U; every sum is tested in the same ambient A. -/
def EarlyTriangle (A : Finset ℕ) (U : ℕ) : Prop :=
  ∃ x∈A, ∃ y∈A, ∃ z∈A, x≠y ∧ x≠z ∧ y≠z ∧
    x≤U ∧ y≤U ∧ z≤U ∧ x+y∈A ∧ x+z∈A ∧ y+z∈A

theorem prefix_free {A : Finset ℕ} {U j : ℕ} (ha : ¬EarlyTriangle A U) (hj : j≤U) :
    IsTripleFree (A ∩ Icc 1 j) := by
  rintro ⟨x,hx,y,hy,z,hz,hxy,hxz,hyz,hxyA,hxzA,hyzA⟩
  exact ha ⟨x,(mem_inter.mp hx).1,y,(mem_inter.mp hy).1,z,(mem_inter.mp hz).1,
    hxy,hxz,hyz,le_trans (mem_Icc.mp (mem_inter.mp hx).2).2 hj,
    le_trans (mem_Icc.mp (mem_inter.mp hy).2).2 hj,
    le_trans (mem_Icc.mp (mem_inter.mp hz).2).2 hj,
    (mem_inter.mp hxyA).1,(mem_inter.mp hxzA).1,(mem_inter.mp hyzA).1⟩

theorem pivot_local {A : Finset ℕ} {N U h : ℕ} (hsub : A⊆Icc 1 N)
    (ha : ¬EarlyTriangle A U) (hh : h∈A) (hhu : h≤U) (hnu : N≤h+U) :
    NoTriangleAt A h := by
  intro x hx y hy hxy hxh hyh hsum hxsum hysum
  have hxI:=mem_Icc.mp (hsub hxsum)
  have hyI:=mem_Icc.mp (hsub hysum)
  exact ha ⟨x,hx,y,hy,h,hh,hxy,hxh,hyh,by omega,by omega,hhu,hsum,hxsum,hysum⟩

/-- Integer form of the full early ambient triangle theorem. No global
triangle-freeness or cropped sum-label assumption occurs. -/
theorem early_triangle (M U : ℕ) (A : Finset ℕ)
    (hM : 64≤M) (hsub : A⊆Icc 1 (2*M))
    (hdense : 5*M+40<4*A.card) (hlo : M≤U) (hhi : 2*U≤3*M)
    (hcut : 21*M+56≤8*(A.card+U)) : EarlyTriangle A U := by
  classical
  by_contra hno
  have hlow : (A ∩ Icc 1 M).Nonempty := by
    by_contra he
    have hs : A⊆Icc (M+1) (2*M) := by
      intro x hx
      have hi:=mem_Icc.mp (hsub hx)
      have hn : x∉A ∩ Icc 1 M := by rw [not_nonempty_iff_eq_empty.mp he]; simp
      exact mem_Icc.mpr ⟨by by_contra hh; exact hn (mem_inter.mpr ⟨hx,mem_Icc.mpr ⟨hi.1,by omega⟩⟩),hi.2⟩
    have hc:=card_le_card hs
    simp only [Nat.card_Icc] at hc
    omega
  have hhigh : (A ∩ Icc M (2*M)).Nonempty := by
    by_contra he
    have hs : A⊆Icc 1 M := by
      intro x hx
      have hi:=mem_Icc.mp (hsub hx)
      have hn : x∉A ∩ Icc M (2*M) := by rw [not_nonempty_iff_eq_empty.mp he]; simp
      exact mem_Icc.mpr ⟨hi.1,by by_contra hh; exact hn (mem_inter.mpr ⟨hx,mem_Icc.mpr ⟨by omega,hi.2⟩⟩)⟩
    have hc:=card_le_card hs
    simp only [Nat.card_Icc] at hc
    omega
  let p := (A ∩ Icc 1 M).max' hlow
  let v := (A ∩ Icc M (2*M)).min' hhigh
  have hpMem := max'_mem (A ∩ Icc 1 M) hlow
  have hvMem := min'_mem (A ∩ Icc M (2*M)) hhigh
  have hpA : p∈A := (mem_inter.mp hpMem).1
  have hvA : v∈A := (mem_inter.mp hvMem).1
  have hpI : 1≤p ∧ p≤M := mem_Icc.mp (mem_inter.mp hpMem).2
  have hvI : M≤v ∧ v≤2*M := mem_Icc.mp (mem_inter.mp hvMem).2
  have hpmax : ∀x∈A,x≤M→x≤p := by
    intro x hx hxM
    exact le_max' _ _ (mem_inter.mpr ⟨hx,mem_Icc.mpr ⟨(mem_Icc.mp (hsub hx)).1,hxM⟩⟩)
  have hvmin : ∀x∈A,M≤x→v≤x := by
    intro x hx hxM
    exact min'_le _ _ (mem_inter.mpr ⟨hx,mem_Icc.mpr ⟨hxM,(mem_Icc.mp (hsub hx)).2⟩⟩)
  have hvU : v≤U := by
    by_contra hh
    have hs : A⊆(A ∩ Icc 1 M) ∪ Icc (U+1) (2*M) := by
      intro x hx
      have hi:=mem_Icc.mp (hsub hx)
      by_cases hxM:x≤M
      · exact mem_union.mpr (Or.inl (mem_inter.mpr ⟨hx,mem_Icc.mpr ⟨hi.1,hxM⟩⟩))
      · have hhx:=hvmin x hx (by omega)
        exact mem_union.mpr (Or.inr (mem_Icc.mpr ⟨by omega,hi.2⟩))
    have hc:=le_trans (card_le_card hs) (card_union_le _ _)
    have hk:=erdos865_upper_bound M (A ∩ Icc 1 M) inter_subset_right (prefix_free hno hlo)
    simp only [Nat.card_Icc] at hc
    omega
  by_cases hcase : v-M≤4*(M-p)
  · have hloc:=pivot_local hsub hno hvA hvU (by omega)
    have hf:=local_folding hloc hvA (show 2≤v by omega) (N:=2*M)
    have hi:=card_le_card (case1_I_sub hvI.1 hvmin hpmax)
    have hc:=card_A_bound hsub v
    simp only [Nat.card_Ico] at hi
    omega
  · have hpm : 2≤p := by omega
    have hloc:=pivot_local hsub hno hpA (by omega) (by omega)
    have hf:=local_folding hloc hpA hpm (N:=2*M)
    have hg : v-p≤p := by omega
    have hi:=card_le_card (case2_I_sub hg hvmin hpmax)
    let j := v-p-1
    have hjU : j≤U := by dsimp [j]; omega
    have heq : Ico 1 (v-p)=Icc 1 j := by
      ext x; simp only [mem_Ico,mem_Icc]; dsimp [j]; omega
    have hk:=erdos865_upper_bound j (A ∩ Icc 1 j) inter_subset_right (prefix_free hno hjU)
    have hcount : (Ico 1 (v-p) \ A).card+(A ∩ Ico 1 (v-p)).card=(Ico 1 (v-p)).card := by
      rw [card_sdiff,inter_comm]
      have hh := card_le_card (show Ico 1 (v-p) ∩ A⊆Ico 1 (v-p) from inter_subset_left)
      omega
    rw [heq] at hi hcount
    have hc:=card_A_bound hsub p
    simp only [Nat.card_Icc] at hcount
    dsimp [j] at hk hcount hi
    omega

#print axioms prefix_free
#print axioms pivot_local
#print axioms early_triangle
end OP02.SharpK6

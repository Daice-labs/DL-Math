import K7InterpolationSpec

open Polynomial
namespace OP02.SharpK7.Interpolation

/-- The factor at node y is this quadratic plus C y. -/
private noncomputable def quad (e s : ℤ) : ℤ[X] :=
  (X - C s) * (X - C s + C e)

/-- Newton divided difference at z followed by the nodes zs.  Multiplication
by a linear factor in the node variable gives this division-free recurrence. -/
noncomputable def certificate (e : ℤ) : List ℤ → ℤ → List ℤ → ℤ[X]
  | [], _, zs => if zs = [] then 1 else 0
  | s :: us, z, zs =>
    (quad e s + C z) * certificate e us z zs +
      match zs with
      | [] => 0
      | w :: ws => certificate e us w ws

private theorem swap (e : ℤ) (us : List ℤ) (x y : ℤ) (l : List ℤ) :
    certificate e us x l - certificate e us y l =
      C (x-y) * certificate e us x (y::l) := by
  induction us with
  | nil => simp [certificate]
  | cons s us ih =>
    simp only [certificate, map_sub] at ih ⊢
    linear_combination (quad e s + C x) * ih

private def AtCoeff (p : ℤ[X]) (d m : ℕ) : Prop :=
  p.natDegree ≤ d ∧ p.coeff d = (m : ℤ)

private theorem mul_cert {p q : ℤ[X]} {d k c b : ℕ}
    (hp : AtCoeff p d c) (hq : AtCoeff q k b) :
    AtCoeff (p*q) (d+k) (c*b) := by
  constructor
  · exact (Polynomial.natDegree_mul_le).trans (Nat.add_le_add hp.1 hq.1)
  · rw [coeff_mul_add_eq_of_natDegree_le hp.1 hq.1, hp.2, hq.2, Nat.cast_mul]

private theorem add_cert {p q : ℤ[X]} {d c b : ℕ}
    (hp : AtCoeff p d c) (hq : AtCoeff q d b) :
    AtCoeff (p+q) d (c+b) := by
  exact ⟨(Polynomial.natDegree_add_le _ _).trans (max_le hp.1 hq.1),
    by rw [coeff_add,hp.2,hq.2,Nat.cast_add]⟩

private theorem quad_cert (e s z : ℤ) : AtCoeff (quad e s + C z) 2 1 := by
  constructor
  · unfold quad
    compute_degree
  · unfold quad
    compute_degree
    norm_num

private theorem no_coeff (e : ℤ) (us : List ℤ) (z : ℤ) (zs : List ℤ)
    (h : us.length < zs.length) : certificate e us z zs = 0 := by
  induction us generalizing z zs with
  | nil =>
    cases zs with
    | nil => simp at h
    | cons w ws => simp [certificate]
  | cons s us ih =>
    cases zs with
    | nil => simp at h
    | cons w ws =>
      simp only [List.length_cons] at h
      simp [certificate, ih z (w::ws) (by simp; omega), ih w ws (by omega)]

private theorem grading (e : ℤ) (us : List ℤ) (z : ℤ) (zs : List ℤ)
    (h : zs.length ≤ us.length) :
    AtCoeff (certificate e us z zs) (2*(us.length-zs.length))
      (us.length.choose zs.length) := by
  induction us generalizing z zs with
  | nil =>
    have : zs = [] := List.length_eq_zero_iff.mp (by simpa using h)
    subst zs
    simp [certificate, AtCoeff]
  | cons s us ih =>
    cases zs with
    | nil =>
      have hz := mul_cert (quad_cert e s z) (ih z [] (by simp))
      simpa [certificate, Nat.mul_add, Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hz
    | cons w ws =>
      simp only [List.length_cons] at h ⊢
      have hw := ih w ws (by omega)
      by_cases he : ws.length+1 ≤ us.length
      · have hz := mul_cert (quad_cert e s z) (ih z (w::ws) (by simpa))
        simp only [List.length_cons, one_mul] at hz
        have hd : 2 + 2*(us.length-(ws.length+1)) = 2*(us.length-ws.length) := by omega
        rw [hd] at hz
        simpa only [certificate, Nat.add_sub_add_right, Nat.choose_succ_succ, Nat.add_comm] using
          add_cert hz hw
      · have heq : ws.length = us.length := by omega
        have hz := no_coeff e us z (w::ws) (by simp; omega)
        simpa [certificate, hz, heq] using hw

/-- An actual polynomial of degree 2(u+1-j), with binomial leading coefficient. -/
theorem certificate_degree (e : ℤ) (us : List ℤ) (z : ℤ) (zs : List ℤ)
    (h : zs.length ≤ us.length) :
    certificate e us z zs ≠ 0 ∧
    (certificate e us z zs).natDegree = 2*(us.length-zs.length) ∧
    (certificate e us z zs).leadingCoeff = (us.length.choose zs.length : ℤ) := by
  obtain ⟨hd,hc⟩ := grading e us z zs h
  have hp : 0 < us.length.choose zs.length := Nat.choose_pos h
  have hn : (certificate e us z zs).coeff (2*(us.length-zs.length)) ≠ 0 := by
    rw [hc]; exact_mod_cast (Nat.ne_of_gt hp)
  have eqd := Nat.le_antisymm hd (le_natDegree_of_ne_zero hn)
  exact ⟨fun hz => hn (by simp [hz]), eqd, by rwa [← coeff_natDegree,eqd]⟩

/-- A vanished factor at one physical loss kills the one-node polynomial. -/
theorem singleton_zero (e g y s : ℤ) (us : List ℤ) (hs : s ∈ us)
    (hv : (g-s)*(g-s+e)+y=0) : (certificate e us y []).eval g = 0 := by
  induction us with
  | nil => simp at hs
  | cons t us ih =>
    rcases List.mem_cons.mp hs with he | ht
    · subst t
      simp [certificate, quad, hv]
    · simp [certificate, ih ht]

/-- Distinct-node divided differences vanish wherever all singleton evaluations vanish. -/
theorem vanish (e : ℤ) (us : List ℤ) (g z : ℤ) (zs : List ℤ) (hn : (z::zs).Nodup)
    (h : ∀ y ∈ z::zs, (certificate e us y []).eval g = 0) :
    (certificate e us z zs).eval g = 0 := by
  induction zs generalizing z with
  | nil => exact h z (by simp)
  | cons w ws ih =>
    obtain ⟨hz,hs⟩ := List.nodup_cons.mp hn
    have hzw : z ≠ w := fun eq => hz (by simp [eq])
    have h1 := ih z (List.nodup_cons.mpr
      ⟨fun hmem => hz (List.mem_cons_of_mem _ hmem), (List.nodup_cons.mp hs).2⟩)
      (fun t ht => h t (by rcases List.mem_cons.mp ht with he|he <;> simp [he]))
    have h2 := ih w hs (fun t ht => h t (List.mem_cons_of_mem _ ht))
    have heq := congrArg (Polynomial.eval g) (swap e us z w ws)
    simp only [eval_sub,eval_mul,eval_C,h1,h2,sub_self] at heq
    exact (mul_eq_zero.mp heq.symm).resolve_left (sub_ne_zero.mpr hzw)

end OP02.SharpK7.Interpolation

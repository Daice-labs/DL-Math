import K6Roots
import K6P5Input
open Finset
namespace OP02.SharpK6
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot OP02.SharpK5
set_option maxHeartbeats 3000000
theorem positive_gap_canonical_budget6 (β:ℝ) (hβ:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,DoublingFree B→
    (21/128:ℝ)*n+β*n≤((quarterD n B).card:ℝ)-((deficit n B+(excessHoles n B).card:ℕ):ℝ)→
    ((chainDeficit n B+deficit n B+(excessHoles n B).card:ℕ):ℝ)≤
      (n:ℝ)/384-(β/2)*n := by
  obtain ⟨H₀,hH₀⟩ := capacity_uniform_error (2*β) (by positivity)
  refine ⟨4*H₀,?_⟩
  intro n hn B hd hgap
  have hH : H₀≤n/4 := by omega
  have hc := hH₀ (n/4) hH
  have hnH : (4:ℝ)*(n/4:ℕ)≤n := by exact_mod_cast (show 4*(n/4)≤n by omega)
  have hcap := chain_capacity_with_top_loss (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  have hk : chainDeficit n B+(quarterD n B).card=chainCapacity (n/4) := by unfold chainDeficit; omega
  have hkr : (chainDeficit n B:ℝ)+(quarterD n B).card=chainCapacity (n/4) := by exact_mod_cast hk
  push_cast at hgap ⊢
  nlinarith [mul_nonneg (le_of_lt hβ) (show (0:ℝ)≤n-4*(n/4:ℕ) by linarith)]


/-- A violation uses the same actual root set and exact deficit/excess budget. -/
def PositiveGap6 (β:ℝ) (n:ℕ) (B:Finset ℕ) : Prop :=
  (21/128:ℝ)*n+β*n≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ)

/-- All preliminary order-six conditions are derived, including lower five-clique
existence and the full negative beta term in the actual q bound. -/
theorem positive_gap_reduction6 (hD:Dousse6) (β:ℝ) (hβ:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,B⊆Icc 1 (4*n)→SixFree B→DoublingFree B→PositiveGap6 β n B→
      65536≤n ∧ OP02.SharpK5.FiveFree (quarterD n B) ∧
      ¬OP02.SharpK5.FiveFree (lower n B) ∧
      (totalBudget n B:ℝ)≤(n:ℝ)/512-(β/2)*n ∧
      ((chainDeficit n B+totalBudget n B:ℕ):ℝ)≤(n:ℝ)/384-(β/2)*n := by
  obtain ⟨N0,h0⟩ := positive_gap_canonical_budget6 β hβ
  obtain ⟨N1,h1⟩ := fivefree_uniform (dousse5_of_dousse6 hD) (2*β) (by positivity)
  obtain ⟨N2,h2⟩ := fivefree_uniform (dousse5_of_dousse6 hD) (β/2) (by positivity)
  refine ⟨max 65536 (max N0 (max (4*N1) N2)),?_⟩
  intro n hn B hs hf hd hgap
  have hn0:N0≤n := by omega
  have hn1:N1≤n/4 := by omega
  have hn2:N2≤n := by omega
  have hb := h0 n hn0 B hd hgap
  simp only [Nat.add_assoc] at hb
  change ((chainDeficit n B+totalBudget n B:ℕ):ℝ)≤(n:ℝ)/384-(β/2)*n at hb
  have hq : 384*totalBudget n B≤n := by
    have hr : (384:ℝ)*totalBudget n B≤n := by
      push_cast at hb
      have hκ:(0:ℝ)≤chainDeficit n B := by positivity
      have hnn:(0:ℝ)≤n := by positivity
      nlinarith
    exact_mod_cast hr
  have hE : (Ho n B).card≤(excessHoles n B).card := card_le_card (filter_subset _ _)
  have hHo : 12*(Ho n B).card<n := by unfold totalBudget at hq; omega
  have hroot:=quarter_five_free n B hf hHo
  have hdc:=h1 (n/4) hn1 (quarterD n B) (filter_subset _ _) hroot
  have hn4 : (4:ℝ)*(n/4:ℕ)≤n := by exact_mod_cast (show 4*(n/4)≤n by omega)
  change (21/128:ℝ)*n+β*n≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) at hgap
  have hqsharp : (totalBudget n B:ℝ)≤(n:ℝ)/512-(β/2)*n := by
    nlinarith [mul_nonneg (le_of_lt hβ) (show (0:ℝ)≤n-4*(n/4:ℕ) by linarith)]
  have hlow : ¬OP02.SharpK5.FiveFree (lower n B) := by
    intro hl
    have hu:=h2 n hn2 (lower n B) inter_subset_right hl
    have hcard:=lower_card_eq n B
    have hres:=residue_card_le n B hd
    have hc : (lower n B).card+deficit n B=(n+1)/2+(quarterD n B).card := by unfold deficit; omega
    have hcr : ((lower n B).card:ℝ)+deficit n B=((n+1)/2:ℕ)+(quarterD n B).card := by exact_mod_cast hc
    have hn2r : (n:ℝ)≤2*((n+1)/2:ℕ) := by exact_mod_cast (show n≤2*((n+1)/2) by omega)
    have hEnon : (0:ℝ)≤(excessHoles n B).card := by positivity
    have hnp : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
    unfold totalBudget at hgap
    push_cast at hgap
    nlinarith
  exact ⟨by omega,hroot,hlow,hqsharp,hb⟩

#print axioms positive_gap_canonical_budget6
#print axioms positive_gap_reduction6
end OP02.SharpK6

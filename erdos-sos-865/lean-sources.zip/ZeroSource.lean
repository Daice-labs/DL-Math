import ZeroMidpoint
open Finset
namespace OP02.ZeroExcess
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

def parityMiddle (n : ℕ) (B : Finset ℕ) (r : ℕ) : Finset ℕ :=
  (middle n B).filter (fun x => x%2=r)

def NoEdge (B P : Finset ℕ) : Prop :=
  ∀ x∈P, ∀ y∈P, x≠y → x+y∉B

theorem upper_missing_iff (n : ℕ) (B : Finset ℕ)
    (hd : DoublingFree B) (he : (excessHoles n B).card=0)
    {z : ℕ} (hz : z∈Icc (2*n+1) (4*n)) :
    z∉B ↔ ∃v∈middle n B, 2*v=z := by
  constructor
  · intro hn
    have hhole : z∈holes n B := mem_sdiff.mpr ⟨hz,hn⟩
    have him : z∈(middle n B).image (fun v => 2*v) := by
      by_contra h
      have hex : z∈excessHoles n B := mem_sdiff.mpr ⟨hhole,h⟩
      rw [card_eq_zero.mp he] at hex
      simpa using hex
    exact mem_image.mp him
  · rintro ⟨v,hv,rfl⟩
    exact hd v (mem_inter.mp hv).1

theorem upper_odd (n : ℕ) (B : Finset ℕ)
    (hd : DoublingFree B) (he : (excessHoles n B).card=0)
    {z : ℕ} (hz : z∈Icc (2*n+1) (4*n)) (ho : z%2=1) : z∈B := by
  by_contra hn
  obtain ⟨v,hv,hvz⟩ := (upper_missing_iff n B hd he hz).mp hn
  omega

theorem middle_two_mod_four (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    ((middle n B).filter (fun v => v%4=2)).card ≤ deficit n B := by
  let S := (middle n B).filter (fun v => v%4=2)
  have hs : S.image (fun v=>v/2) ⊆ missingTopOdd n B := by
    intro y hy
    obtain ⟨v,hv,rfl⟩ := mem_image.mp hy
    obtain ⟨hvM,hv4⟩ := mem_filter.mp hv
    obtain ⟨hvB,hvI⟩ := mem_inter.mp hvM
    obtain ⟨hvl,hvu⟩ := mem_Icc.mp hvI
    refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,
      by omega,?_⟩
    intro hh
    have hh' := hd (v/2) hh
    have heq : 2*(v/2)=v := by omega
    rw [heq] at hh'
    exact hh' hvB
  have hi : Set.InjOn (fun v:ℕ=>v/2) S := by
    intro x hx y hy hxy
    have hx4 := (mem_filter.mp hx).2
    have hy4 := (mem_filter.mp hy).2
    dsimp at hxy
    omega
  calc
    S.card = (S.image (fun v=>v/2)).card := (card_image_of_injOn hi).symm
    _ ≤ (missingTopOdd n B).card := card_le_card hs
    _ ≤ deficit n B := missingTopOdd_le_deficit n B hd

theorem four_forbidden (B : Finset ℕ) (hf : FourFree B) {a b c d : ℕ}
    (ha:a∈B) (hb:b∈B) (hc:c∈B) (hd:d∈B)
    (hab:a≠b) (hac:a≠c) (had:a≠d) (hbc:b≠c) (hbd:b≠d) (hcd:c≠d)
    (hsab:a+b∈B) (hsac:a+c∈B) (hsad:a+d∈B)
    (hsbc:b+c∈B) (hsbd:b+d∈B) (hscd:c+d∈B) : False := by
  apply hf
  refine ⟨{a,b,c,d},?_,?_,?_⟩
  · intro x hx
    simp only [mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl|rfl <;> assumption
  · simp [hab,hac,had,hbc,hbd,hcd]
  · intro x hx y hy hxy
    simp only [mem_insert,mem_singleton] at hx hy
    rcases hx with rfl|rfl|rfl|rfl <;>
      rcases hy with rfl|rfl|rfl|rfl <;> simp_all [Nat.add_comm]

theorem middle_cross (n : ℕ) (B : Finset ℕ)
    (hd : DoublingFree B) (he : (excessHoles n B).card=0)
    {x y : ℕ} (hx:x∈middle n B) (hy:y∈middle n B)
    (hp:x%2≠y%2) : x+y∈B := by
  have hxi := mem_Icc.mp (mem_inter.mp hx).2
  have hyi := mem_Icc.mp (mem_inter.mp hy).2
  exact upper_odd n B hd he (mem_Icc.mpr ⟨by omega,by omega⟩) (by omega)

theorem one_middle_side_edgeless (n : ℕ) (B : Finset ℕ)
    (hf : FourFree B) (hd : DoublingFree B) (he : (excessHoles n B).card=0) :
    NoEdge B (parityMiddle n B 0) ∨ NoEdge B (parityMiddle n B 1) := by
  by_contra hh
  simp only [not_or] at hh
  obtain ⟨x,hx,y,hy,hxy,hxs⟩ : ∃x∈parityMiddle n B 0, ∃y∈parityMiddle n B 0,
      x≠y ∧ x+y∈B := by
    simpa [NoEdge,not_forall] using hh.1
  obtain ⟨z,hz,w,hw,hzw,hzs⟩ : ∃z∈parityMiddle n B 1, ∃w∈parityMiddle n B 1,
      z≠w ∧ z+w∈B := by
    simpa [NoEdge,not_forall] using hh.2
  obtain ⟨hxM,hxp⟩ := mem_filter.mp hx
  obtain ⟨hyM,hyp⟩ := mem_filter.mp hy
  obtain ⟨hzM,hzp⟩ := mem_filter.mp hz
  obtain ⟨hwM,hwp⟩ := mem_filter.mp hw
  exact four_forbidden B hf (mem_inter.mp hxM).1 (mem_inter.mp hyM).1
    (mem_inter.mp hzM).1 (mem_inter.mp hwM).1 hxy (by omega) (by omega)
    (by omega) (by omega) hzw hxs
    (middle_cross n B hd he hxM hzM (by omega))
    (middle_cross n B hd he hxM hwM (by omega))
    (middle_cross n B hd he hyM hzM (by omega))
    (middle_cross n B hd he hyM hwM (by omega)) hzs

theorem noedge_midpoint (n : ℕ) (B : Finset ℕ)
    (hd : DoublingFree B) (he : (excessHoles n B).card=0)
    {r x y z : ℕ} (hn : NoEdge B (parityMiddle n B r))
    (hx:x∈parityMiddle n B r) (hy:y∈parityMiddle n B r)
    (hz:x+y=2*z) : z∈middle n B := by
  by_cases hxy:x=y
  · have hzx:z=x := by omega
    subst z
    exact (mem_filter.mp hx).1
  have hxi := mem_Icc.mp (mem_inter.mp (mem_filter.mp hx).1).2
  have hyi := mem_Icc.mp (mem_inter.mp (mem_filter.mp hy).1).2
  obtain ⟨v,hv,hve⟩ := (upper_missing_iff n B hd he
    (mem_Icc.mpr ⟨by omega,by omega⟩)).mp (hn x hx y hy hxy)
  have hvz:v=z := by omega
  simpa [hvz] using hv

/-- The large margin is a consequence of a violation, not a new hypothesis. -/
theorem violation_margin (n : ℕ) (B : Finset ℕ) (hc : ChargeContext n B)
    (he : (excessHoles n B).card=0)
    (hb : n+8*(deficit n B+(excessHoles n B).card)+4096 < 8*(quarterD n B).card) :
    4096<n ∧ 32*deficit n B+16172<n := by
  have hn := hc.1
  have ht := quarter_triple_free n B hc.2.2.1 (by omega)
  have hs : quarterD n B ⊆ Icc 1 (n/4) := filter_subset _ _
  have hq := Erdos865.erdos865_upper_bound (n/4) (quarterD n B) hs ht
  have hcard := card_le_card hs
  rw [Nat.card_Icc] at hcard
  omega

#print axioms upper_missing_iff
#print axioms middle_two_mod_four
#print axioms one_middle_side_edgeless
#print axioms noedge_midpoint
#print axioms violation_margin
end OP02.ZeroExcess

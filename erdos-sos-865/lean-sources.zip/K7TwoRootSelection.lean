import K7TwoRootGeometry
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

theorem top_deficit {n:ℕ} {B:Finset ℕ} (hd:DoublingFree B) :
    (topMissing (n/4) (quarterD n B)).card≤chainDeficit n B:=by
  have hh:=chain_capacity_with_top_loss (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  unfold chainDeficit;omega

theorem choose_outside_four {P A B C D:Finset ℕ}
    (h:A.card+B.card+C.card+D.card<P.card):
    ∃r∈P,r∉A ∧ r∉B ∧ r∉C ∧ r∉D:=by
  by_contra! no
  have sub:P⊆(A∪B∪C∪D):=by
    intro r hr;by_contra bad;simp only [mem_union,not_or] at bad
    exact bad.2 (no r hr bad.1.1.1 bad.1.1.2 bad.1.2)
  have v:=card_le_card sub
  have i:=card_union_le A B;have j:=card_union_le (A∪B) C;have k:=card_union_le (A∪B∪C) D;omega

private theorem four_div_range (n:ℕ):4*(n/4)≤n ∧ n≤4*(n/4)+3:=by omega
private theorem high_span {H n lo A w s:ℕ} (h:4*H≤n ∧ n≤4*H+3) (lohi:2*H+8≤lo)
    (a:lo<w) (b:w≤lo+4*A) (win:lo+4*A+s≤4*H):n/2<w ∧ w+s≤n:=by omega
private theorem pair_up {r d j H:ℕ} (hj:j∈({0,d}:Finset ℕ)) (b:r+d≤H):r+j≤H:=by
  simp only [mem_insert,mem_singleton] at hj;omega
private theorem added_root {r j H:ℕ} (h:H/2<r):1≤r+j ∧ H<2*(r+j):=by omega
private theorem min_y {a b H:ℕ} (h:a+4*b≤H):a≤H:=by omega
private theorem shifts {a c b v:ℕ} (ac:a<c) (cb:c<b) (hv:v∈({0,4*a,4*c,4*b}:Finset ℕ)):
    v%2=0 ∧ v≤4*b:=by simp only [mem_insert,mem_singleton] at hv;omega
private theorem top_test {n y v b:ℕ} {B:Finset ℕ} (lo:n/4/2<y) (hi:y+4*b≤n/4)
    (yp:y%2=1) (vp:v%2=0 ∧ v≤4*b) (miss:y+v∉B):y+v∈absentTop n B:=
  mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,miss⟩
private theorem high_test {n w s p v:ℕ} {B:Finset ℕ} (lo:n/2<w) (hi:w+s≤n)
    (wp:w%2=p%2) (vp:v%2≠p%2 ∧ v≤ s) (miss:w+v∉B):w+v∈missingTopOdd n B:=
  mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega,miss⟩

/-- Two actual canonical roots of one physical addend are qualified simultaneously.
All failures use one fixed set, three translated bands and a single original slot. -/
theorem two_root_select {n s p x x' a c b z:ℕ} {B E:Finset ℕ}
    (hd:DoublingFree B) (sh:s≤n/4) (pp:2*p≤n/4) (ps:p≤ s)
    (xx:x≤x') (xs:x'≤ s) (par:p%2=x%2) (opp:p%4≠x%4) (same:x%4=x'%4)
    (ac:a<c) (cb:c<b) (bnd:b≤3*(n/4/64)+1)
    (zl:43*(n/4)/320<z) (zu:z≤43*(n/4)/320+26*chainDeficit n B+16*logLevels (n/4)+256)
    (pad:384*(chainDeficit n B+totalBudget n B)+10000*logLevels (n/4)+300000≤n/4)
    (num:E.card≤4) (ev:∀v∈E,v%2≠p%2 ∧ v≤ s) :
    ∃y w:ℕ,n/4/2<y ∧ y≤n/4 ∧ y%2=1 ∧ n/2<w ∧ w+s≤n ∧ w%2=p%2 ∧
      w+p=2*(y+4*z) ∧ w+x∈B ∧ w+x'∈B ∧ y+4*z∉emptyPairs n B ∧ 2*(y+4*z)≤n ∧
      (∀v∈({0,4*a,4*c,4*b}:Finset ℕ),y+v∈B) ∧ (∀v∈E,w+v∈B) := by
  classical
  let H:=n/4
  let K:=chainDeficit n B+totalBudget n B
  let J:=logLevels H
  let d:=(x'-x)/4
  let lo:=sourceFloor H z p
  let A:=18*K+4*J+16
  let r₀:=(lo+x)/4
  let u:=r₀+A
  let Q:=(canBand r₀ u).filter (fun r=>canonical (r+d)=true)
  let w (r:ℕ):=4*r-x
  let y (r:ℕ):=(w r+p)/2-4*z
  let E₀:Finset ℕ:={0,4*a,4*c,4*b}
  let tops:=absentTop n B
  let high:=missingTopOdd n B
  let roots:=topMissing H (quarterD n B)
  let slots:=emptyPairs n B
  have wider:z≤43*H/320+26*K+16*J+256:=by dsimp only [H,K,J];omega
  obtain ⟨win₁,win₂⟩:=raised_source_width (H:=H) (K:=K) pad bnd pp sh zl wider
  have start₁:2*H+8≤lo:=le_max_left _ _
  have start₂:H+8*z+8-p≤lo:=le_max_right _ _
  have info {r:ℕ} (hr:r∈Ioc r₀ u) :
      lo<w r ∧ w r≤lo+4*A ∧ H/2<y r ∧ y r+4*b≤H ∧ y r%2=1 ∧
      w r%2=p%2 ∧ 2*(y r+4*z)=w r+p ∧ w r+x=4*r ∧ w r+x'=4*(r+d) ∧
      H/2<r ∧ r+d≤H ∧ 2*((w r+p)/2)≤4*H :=
    pair_source_facts xx xs sh ps par opp same start₁ start₂ win₁ win₂ (mem_Ioc.mp hr).1 (mem_Ioc.mp hr).2
  have endI:u∈Ioc r₀ u:=mem_Ioc.mpr ⟨by dsimp [u,A];omega,le_rfl⟩
  have uc:u+d≤H:=(info endI).2.2.2.2.2.2.2.2.2.2.1
  have count:=canonical_intersection (j:=d) (H:=H) (l:=r₀) (u:=u) (by dsimp [u];omega) uc
  change u-r₀≤3*Q.card+4*J at count
  have sub {r:ℕ} (h:r∈Q):r∈Ioc r₀ u:=(mem_filter.mp (mem_filter.mp h).1).1
  have injW:Set.InjOn w ↑Q:=by
    intro r hr t ht eq
    have er:=(info (sub hr)).2.2.2.2.2.2.2.1
    have et:=(info (sub ht)).2.2.2.2.2.2.2.1;omega
  have injY:Set.InjOn y ↑Q:=by
    intro r hr t ht eq
    have er:=(info (sub hr)).2.2.2.2.2.2.1
    have et:=(info (sub ht)).2.2.2.2.2.2.1
    exact injW hr ht (by omega)
  let B₀:=offsetFailures Q E₀ tops y
  let B₁:=offsetFailures Q E high w
  let B₂:=offsetFailures Q {0,d} roots id
  let B₃:=offsetFailures Q {4*z} slots y
  have c₀:B₀.card≤4*tops.card:=(offset_cost Q E₀ tops y injY).trans (Nat.mul_le_mul_right _ card_le_four)
  have c₁:B₁.card≤4*high.card:=(offset_cost Q E high w injW).trans (Nat.mul_le_mul_right _ num)
  have c₂:B₂.card≤2*roots.card:=(offset_cost Q {0,d} roots id (fun _ _ _ _ eq=>eq)).trans (Nat.mul_le_mul_right _ card_le_two)
  have c₃:B₃.card≤ slots.card:=by simpa [B₃] using offset_cost Q {4*z} slots y injY
  have rt:roots.card≤chainDeficit n B:=top_deficit hd
  have own:=actual_quarter_top_joint n B hd
  have tcap:tops.card≤chainDeficit n B+slots.card:=by
    have :=absent_top_primitive (n:=n) hd;dsimp only [tops,slots];omega
  have sum:high.card+slots.card≤totalBudget n B:=by
    have :=deficit_split n B hd;dsimp only [high,slots];unfold totalBudget;omega
  have size:u-r₀=18*K+4*J+16:=Nat.add_sub_cancel_left _ _
  have enough:B₀.card+B₁.card+B₂.card+B₃.card<Q.card:=by dsimp only [K] at size;omega
  obtain ⟨r,hr,o₀,o₁,o₂,o₃⟩:=choose_outside_four enough
  obtain ⟨wlo,whi,ylo,yhi,yo,wp,half,we₁,we₂,rl,rh,ζh⟩:=info (sub hr)
  have nH:4*H≤n ∧ n≤4*H+3:=four_div_range n
  have nw: n/2<w r ∧ w r+s≤n:=high_span nH start₁ wlo whi win₁
  have rmem (j:ℕ) (hj:j∈({0,d}:Finset ℕ)) (cc:canonical (r+j)=true):
      4*(r+j)∈B:=by
    have upper:r+j≤H:=pair_up hj rh
    have dd:r+j∈quarterD n B:=by
      by_contra absent;apply o₂;apply hit_offset hr hj
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨(added_root (j:=j) rl).1,upper⟩,cc⟩,(added_root rl).2,absent⟩
    exact (mem_filter.mp dd).2
  have first:4*r∈B:=by
    have can:canonical r=true:=(mem_filter.mp (mem_filter.mp hr).1).2
    simpa only [Nat.add_zero] using rmem 0 (by simp) (by simpa using can)
  have second:=rmem d (by simp) (mem_filter.mp hr).2
  have wr:w r+p≤n:=le_trans (Nat.add_le_add_left ps _) nw.2
  refine ⟨y r,w r,ylo,min_y yhi,yo,nw.1,nw.2,wp,half.symm,we₁.symm ▸ first,we₂.symm ▸ second,
    (fun bad=>o₃ (hit_offset hr (mem_singleton_self _) bad)),half.symm ▸ wr,?_,?_⟩
  · intro v hv;have vdata:=shifts ac cb hv
    by_contra absent;apply o₀;apply hit_offset hr hv
    exact top_test ylo yhi yo vdata absent
  · intro v hv;have ve:=ev v hv
    by_contra absent;apply o₁;apply hit_offset hr hv
    exact high_test nw.1 nw.2 wp ve absent

end OP02.SharpK7.LongOddTask

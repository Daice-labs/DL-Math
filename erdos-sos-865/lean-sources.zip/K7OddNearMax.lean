import K7OddPairFinish
import K7OppositeParity
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7.LongOddTask

/-- Use one fixed supply, one fixed set of bad indices, and a tester chosen
only after the base. Each pair is inspected in its own tester family. -/
theorem odd_only_select {β:ℝ} {n start:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (sc:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (pure:¬ActiveEvenSupply n B) (F:Finset ℕ) (p:ℕ→ℕ)
    (budget:F.card≤2*lambdaBudget n B)
    (geometry:∀g∈Icc start (start+2*lambdaBudget n B+1),
      3*(n/4)≤8*p g ∧ p g+4*(n/4/64)≤n/4/2 ∧ p g%2=1)
    (hit:∀g∈Icc start (start+2*lambdaBudget n B+1),
      ∀a≤n/4/64, g+a∉F → p g+4*a∈B) : qualifiedJ0 n B := by
  obtain ⟨g,hgI,gg,small⟩:=opposite_parity_base F _ start budget
  obtain ⟨low,up,po⟩:=geometry g hgI
  obtain ⟨e,he,ep,mx,hc⟩:=actual_reflection_supply β n B hd hg (by omega) hl
  obtain ⟨w,hw,far,alot⟩:=choose_odd_far hd hg sc hl he ep hc low (by omega) po
  let A:=retainedEndpoints n B e (4*w)
  have shapes (a:ℕ) (ha:a∈A):0<a ∧ a<e-a ∧ a%2=1 ∧ (e-a)%2=1 := by
    have refl:=(mem_filter.mp ha).1
    obtain ⟨has,ap,lt,hcs⟩:=mem_filter.mp refl
    have ao:a%2≠0:=fun ao=>pure ⟨e,he,ep,mx,a,refl,ao⟩
    exact ⟨ap,lt,by omega,by omega⟩
  obtain ⟨a,ha,ia,ic⟩:=unspoiled_pair A F e g shapes (small.trans_lt alot)
  have en:e≤n/4/64:=(mem_Icc.mp (mem_inter.mp he).2).2
  have sh:=shapes a ha
  have hbase:p g∈B:=by simpa using hit g hgI 0 (Nat.zero_le _) (by simpa using gg)
  exact finish_odd_pair hd hg sc hl he ep hw ha sh.2.2.1 low up po hbase
    (hit g hgI a (by omega) ia) (hit g hgI (e-a) (by omega) ic) far

/-- The upper window works whenever any chosen odd companion lies close
enough to the maximum companion, including when it attains it. -/
theorem odd_only_near_max {β:ℝ} {n s t t' h k m:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hs:InternalFive (B∩Icc 1 (n/4)) (insert s {t,t',4*h,2*k}))
    (sc:16384≤n/4/64) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (ho:t%2=1) (ho':t'%2=1) (op:t%4≠t'%4) (ko:k%2=1)
    (hm:∀z∈({t,t',4*h,2*k}:Finset ℕ),z≤ m) (upper:3*m<n/4)
    (near:m≤t+4*(n/4/64)+4*lambdaBudget n B) (pure:¬ActiveEvenSupply n B):
    oddReplacement n t t' h k B ∨ qualifiedJ0 n B := by
  classical
  by_cases rep:oddReplacement n t t' h k B
  · exact Or.inl rep
  right
  let H:=n/4
  let N:=H/64
  let L:=lambdaBudget n B
  let r:=(12-t'%8)%8
  let start:=(max (H/2) ((3*H+3)/4-t))/8+1
  let x (i:ℕ):=8*i+r
  let p (i:ℕ):=(x i+t)/2
  let P:=oddBases H m t'
  let bad:=P.filter (fun x=>¬oddTests n t t' h k x B)
  let F:=bad.image (fun x:ℕ=>x/8)
  have sc₀:64≤n/4:=by omega
  have inv:=common_inventory n B
  have signed:=signed_units hd hg sc₀ hl
  have signed' : 6*L+6000<N := by change 6*lambdaBudget n B+6000<n/4/64;omega
  have rem : H=64*N+H%64:=by dsimp [N];omega
  have hm' : 3*m<H:=upper
  have near' : m≤t+4*N+4*L:=near
  have rt : r<8 ∧ (r+t)%4=2:=by dsimp [r];omega
  have mt:=hm t (by simp);have mt':=hm t' (by simp)
  have allowed:=odd_base_failures hd ho ho' op ko (Nat.le_of_lt upper) mt mt' (hm (4*h) (by simp)) (hm (2*k) (by simp))
  have fcap:F.card≤2*L:=by
    have raw:F.card≤bad.card:=card_image_le
    change bad.card ≤ _ at allowed
    dsimp only [L];omega
  have bounds (g:ℕ) (gi:g∈Icc start (start+2*L+1)):
      H/2<x g ∧ 3*H≤4*(x g+t) ∧ x g+m+8*N≤H := by
    have hgi:=mem_Icc.mp gi
    dsimp only [start] at hgi
    dsimp only [x]
    omega
  apply odd_only_select (start:=start) hd hg sc₀ hl pure F p fcap
  · intro g gi; obtain ⟨_,lb,ub⟩:=bounds g gi
    have par:(x g+t)%4=2:=by dsimp only [x];omega
    change 3*H≤8*((x g+t)/2) ∧ (x g+t)/2+4*N≤H/2 ∧ (x g+t)/2%2=1
    omega
  · intro g gi a ha good
    have bo:=bounds g gi
    have an:a≤N:=ha
    let v:=x g+8*a
    have vp:v∈P:=by
      apply mem_filter.mpr; refine ⟨mem_Ioc.mpr ⟨by dsimp [v];omega,by dsimp [v];omega⟩,?_⟩
      change v%8=r;dsimp [v,x];omega
    have tests:oddTests n t t' h k v B:=by
      by_contra no
      apply good
      apply mem_image.mpr
      exact ⟨v,mem_filter.mpr ⟨vp,no⟩,by dsimp [v,x];omega⟩
    rcases odd_base_alternative hs (Nat.le_of_lt upper) hm ho ho' op vp tests with mem|row
    · have res:(v+t)/2=p g+4*a:=by dsimp only [v,p];omega
      rwa [←res]
    · apply False.elim
      apply rep;refine ⟨v,?_,row⟩
      obtain ⟨vI,vr⟩:=mem_filter.mp vp
      have boundsv:=mem_Ioc.mp vI
      exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨boundsv.1,by change v≤H-t;omega⟩,vr⟩
end OP02.SharpK7.LongOddTask

import K8GeometrySpec

open Finset
namespace OP02.SharpK8

/-- Profile roles and a common set of actual upper pivots, before any target fails. -/
structure ProfileWindow (n z κ q : ℕ) (V U T C P : Finset ℕ) : Prop where
  target_sub : T ⊆ U
  control_sub : C ⊆ U
  disjoint : Disjoint T C
  role_count : T.card + C.card ≤ 4
  controls_le : C.card ≤ 3
  supply : max 8 (6*T.card + C.card)*q + C.card*κ < P.card
  pivot : ∀ p ∈ P, 2*n < p ∧ p+12 ≤ 3*n
  odd : ∀ p ∈ P, ∀ u ∈ U, u ∉ T → u ∉ C → (p+u)%2 = 1
  target : ∀ p ∈ P, ∀ u ∈ T, (p+u)%4 = 2 ∧
    ∀ x ∈ insert 0 V, n < 2*((p+u)/2-z+x) ∧ (p+u)/2-z+x ≤ n ∧ ((p+u)/2-z+x)%2 = 1
  control : ∀ p ∈ P, ∀ c ∈ C, (p+c)%8 = 4 ∨ (p+c)%32 = 16

end OP02.SharpK8

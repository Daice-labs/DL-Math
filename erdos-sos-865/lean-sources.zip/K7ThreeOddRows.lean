import K7DoubleProfile
import K7ThreeOddAnchors
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask
set_option maxHeartbeats 1200000

theorem remaining_three_odd_rows (hD:Dousse7) {i:ℕ} (hi:i=15 ∨ i=16) : RowExclusion i:=by
  classical
  intro β hb
  obtain ⟨U,hU⟩:=double_profile_impossible hD hb
  refine ⟨U,?_⟩
  intro n hn B sub hf hd hg S hs row
  have state:(oddOffsets S).card=3 ∧ ¬sameOdd S ∧
      (((twoOffsets S).card=1 ∧ largest (twoOffsets S)=largest S) ∨ 2≤(twoOffsets S).card):=by
    unfold rowNumber at row;dsimp only at row
    split_ifs at row <;> first | omega | exact ⟨by omega,by assumption,by omega⟩
  let s:=largest S
  have bd (v:ℕ) (hv:v∈S):v≤ s:=Finset.le_sup (f:=id) hv
  have sH:s≤n/4:=Finset.sup_le (fun v hv=>(mem_Icc.mp (mem_inter.mp (hs.2.1 hv)).2).2)
  obtain ⟨p,a,b,ab,am,bm,pm,po,ao,bo,op,same,olist,unique⟩:=odd_triple_source state.1 state.2.1
  have ec:(evenOffsets S).card=2:=by have :=parity_partition S;have :=hs.1;omega
  rcases state.2.2 with ⟨one,top⟩|two
  · obtain ⟨f,feq⟩:=card_eq_one.mp one
    have fm:f∈twoOffsets S:=by simp [feq]
    obtain ⟨fs,fr⟩:=mem_filter.mp fm
    have ftop:f=s:=by simpa only [s,largest,feq,sup_singleton,id_eq] using top
    have ne:p≠f:=by omega
    have edge:=(mem_Icc.mp (mem_inter.mp (hs.2.2 p pm f fs ne)).2).2
    have psmall:2*p≤n/4:=by have :=bd p pm;omega
    let E:=insert 0 (evenOffsets S)
    have numer:E.card≤4:=by have :=card_insert_le 0 (evenOffsets S);dsimp only [E];omega
    apply hU n hn B hf hd hg S hs s sH bd
    refine ⟨p,a,b,f,E,psmall,bd p pm,ab.le,bd b bm,po.trans ao.symm,op,same,numer,?_,?_,(bd f fs).trans sH,by omega,?_⟩
    · intro v hv;rcases mem_insert.mp hv with rfl|ev
      · omega
      · obtain ⟨vs,vr⟩:=mem_filter.mp ev;exact ⟨by omega,bd v vs⟩
    · intro v hv;rcases mem_insert.mp hv with rfl|vs
      · exact Or.inr (Or.inr (Or.inr (mem_insert_self _ _)))
      · by_cases vo:v%2=1
        · rcases olist v vs vo with eq|eq|eq
          · exact Or.inl eq
          · exact Or.inr (Or.inl eq)
          · exact Or.inr (Or.inr (Or.inl eq))
        · exact Or.inr (Or.inr (Or.inr (mem_insert_of_mem (mem_filter.mpr ⟨vs,by omega⟩))))
    · intro v hv vr vn;rcases mem_insert.mp hv with rfl|vs
      · omega
      · intro eq;have vv:v∈twoOffsets S:=mem_filter.mpr ⟨vs,eq.trans fr⟩
        exact vn (mem_singleton.mp (feq ▸ vv))
  · have incl:twoOffsets S⊆evenOffsets S:=by
      intro v hv;obtain ⟨vs,vr⟩:=mem_filter.mp hv;exact mem_filter.mpr ⟨vs,by omega⟩
    have eqset:twoOffsets S=evenOffsets S:=eq_of_subset_of_card_le incl (by omega)
    obtain ⟨x,x',xx,evens⟩ : ∃x x':ℕ,x<x' ∧ evenOffsets S={x,x'}:=by
      obtain ⟨r,t,ne,eq⟩:=card_eq_two.mp ec
      rcases lt_or_gt_of_ne ne with h|h
      · exact ⟨r,t,h,eq⟩
      · exact ⟨t,r,h,by rwa [Finset.pair_comm]⟩
    have xa:x∈twoOffsets S:=by rw [eqset,evens];simp
    have xb:x'∈twoOffsets S:=by rw [eqset,evens];simp
    obtain ⟨xm,xr⟩:=mem_filter.mp xa
    obtain ⟨x'm,x'r⟩:=mem_filter.mp xb
    apply hU n hn B hf hd hg S hs s sH bd
    refine ⟨0,x,x',p,oddOffsets S,by omega,Nat.zero_le _,xx.le,bd _ x'm,by omega,by omega,
      xr.trans x'r.symm,state.1.le.trans (by decide),?_,?_,(bd p pm).trans sH,by omega,?_⟩
    · intro v hv;obtain ⟨vs,vo⟩:=mem_filter.mp hv;exact ⟨by omega,bd v vs⟩
    · intro v hv;rcases mem_insert.mp hv with rfl|vs
      · exact Or.inl rfl
      · by_cases vo:v%2=1
        · exact Or.inr (Or.inr (Or.inr (mem_filter.mpr ⟨vs,vo⟩)))
        · have ve:v∈evenOffsets S:=mem_filter.mpr ⟨vs,by omega⟩
          rw [evens] at ve
          rcases mem_insert.mp ve with ex|ex
          · exact Or.inr (Or.inl ex)
          · exact Or.inr (Or.inr (Or.inl (mem_singleton.mp ex)))
    · intro v hv vr vn;rcases mem_insert.mp hv with rfl|vs
      · omega
      · exact unique _ vs vr vn

end OP02.SharpK7.LongOddTask

import K6PairProfiles
import K6PairShape
import K6ThreeShape
import K6FinalProfile
import K6EarlySet
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 3000000

/-- All lower-clique profiles are exhausted. Every capacity and interval bound
used below was proved from physical memberships; none is an added hypothesis. -/
theorem reduced_context_impossible6 (β:ℝ) (n:ℕ) (B:Finset ℕ)
    (hf:SixFree B) (hd:DoublingFree B) (hg:MiddleGap6 n B)
    (hn:65536≤n) (hβ:0<β) (hβu:β≤1/1024) (hmargin:(100:ℝ)≤β*n)
    (hqsharp:(totalBudget n B:ℝ)≤n/512-(β/2)*n)
    (hk:384*(chainDeficit n B+totalBudget n B)≤n)
    (hcanon:6*(canonicalHoles n B).card<n/32)
    (hlow:¬FiveFree (lower n B))
    (hearly:∃U:ℕ,EarlyTriangle (actualRootPrefix n B) U ∧
      (16:ℝ)*U+16*totalBudget n B+16*(β*n)≤11*(n/16:ℕ)+192) : False := by
  classical
  have hq:512*totalBudget n B≤n := by
    have hr:(512:ℝ)*totalBudget n B≤n := by nlinarith
    exact_mod_cast hr
  obtain ⟨U,hU,hUs⟩:=hearly
  obtain ⟨T,hT,hTc,hTs,hTp⟩:=early_triangle_set n U B hU
  have hsmall:∀t∈T,t≤n/16 := fun t ht=>le_trans (hTs t ht) (min_le_right _ _)
  obtain ⟨S,hS,hSc,hpairs⟩:(∃S⊆lower n B,S.card=5 ∧ ∀x∈S,∀y∈S,x≠y → x+y∈lower n B) := by
    simpa only [FiveFree,not_not] using hlow
  have hSI:S⊆Icc 1 n := fun x hx=>(mem_inter.mp (hS hx)).2
  have hpB:∀x∈S,∀y∈S,x≠y → x+y∈B := fun x hx y hy hxy=>(mem_inter.mp (hpairs x hx y hy hxy)).1
  have hpN:∀x∈S,∀y∈S,x≠y → x+y≤n := fun x hx y hy hxy=>(mem_Icc.mp (mem_inter.mp (hpairs x hx y hy hxy)).2).2
  have hdispatch:=canonical_profile_dispatch n B S hf hS hSc hpB hcanon
  have hPair (hcase:((S.filter (fun x=>x%2=1)).card=2 ∧ ∃x∈S,∃y∈S,x%2=1 ∧ y%2=1 ∧ x%4≠y%4) ∨
      ((S.filter (fun x=>x%2=1)).card=4 ∧ ∃v∈S,v%4=2)):False := by
    obtain ⟨u,hu,v,hv,huv,hul,hres,hpar,hload⟩:=pair_shape n S hSI hSc hpN hcase
    exact pair_profile_impossible n u v B S T hn hf hd hg hq hk hcanon hS hSc hpairs hu hv huv hul hres hpar hload hT hTc hTp hsmall
  rcases hdispatch with h2|h4|h3
  · exact hPair (Or.inl h2)
  · exact hPair (Or.inr h4)
  · obtain ⟨w,hw,a,ha,b,hb,ha4,hb4,hwB,hmB,hother,hload⟩:=three_profile_shape n S hSI hSc hpN h3.1 h3.2.1 h3.2.2
    have hsearly:((min U (n/16):ℕ):ℝ)≤11*(n/16:ℕ)/16-totalBudget n B-β*n+12 := by
      have hr:((min U (n/16):ℕ):ℝ)≤U := by exact_mod_cast (min_le_left U (n/16))
      linarith
    exact final_profile_contradiction β n w a b (min U (n/16)) B S T hf hd hg hn (by omega)
      hS hSc hpB hw ha hb ha4 hb4 hother hload hwB hmB (min_le_right _ _) hT hTc hTs hTp hβ hβu hmargin hqsharp hsearly

/-- Complete normalized bound. Dousse6 is retained explicitly and supplies the
already checked k5 dependency; the middle-gap and all profile premises are derived. -/
theorem complete_normalized_k6 (hD:Dousse6) : NormalizedGoal := by
  intro β hβ
  let γ:=min β (1/1024)
  have hγ:0<γ := lt_min hβ (by norm_num)
  have hγu:γ≤1/1024 := min_le_right _ _
  have hγβ:γ≤β := min_le_left _ _
  obtain ⟨N0,h0⟩:=positive_gap_reduction6 hD γ hγ
  obtain ⟨N1,h1⟩:=middle_gap6_uniform γ hγ
  obtain ⟨N2,h2⟩:=actual_early_triangle γ hγ
  obtain ⟨N3,h3⟩:=positive_gap_canonical_margin γ hγ
  obtain ⟨N4,h4⟩:=exists_nat_gt (100/γ)
  refine ⟨max N0 (max N1 (max N2 (max N3 N4))),?_⟩
  intro n hn B hB hf hd
  have hγn:(100:ℝ)≤γ*n := by
    have hNr:(N4:ℝ)≤n := by exact_mod_cast (show N4≤n by omega)
    have hh:100/γ<(n:ℝ):=lt_of_lt_of_le h4 hNr
    have:=(div_lt_iff₀ hγ).mp hh
    nlinarith
  by_contra hbad
  push_neg at hbad
  have hinv:=exact_inventory n B hB hd
  have hinvR:(B.card:ℝ)+totalBudget n B=2*n+((n+1)/2:ℕ)+(quarterD n B).card := by
    have hi:B.card+totalBudget n B=2*n+(n+1)/2+(quarterD n B).card := by unfold totalBudget; omega
    exact_mod_cast hi
  have hhalf:(((n+1)/2:ℕ):ℝ)≤(n:ℝ)/2+1/2 := by
    have hh:2*((n+1)/2)≤n+1 := by omega
    have hr:(2:ℝ)*((n+1)/2:ℕ)≤n+1 := by exact_mod_cast hh
    linarith
  have hgap:PositiveGap6 γ n B := by
    unfold PositiveGap6
    have hmul:γ*(n:ℝ)≤β*n:=mul_le_mul_of_nonneg_right hγβ (by positivity)
    linarith
  obtain ⟨hn65536,hDfree,hlow,hq,hκ⟩:=h0 n (by omega) B hB hf hd hgap
  have hk:384*(chainDeficit n B+totalBudget n B)≤n := by
    have hr:(384:ℝ)*(chainDeficit n B+totalBudget n B:ℕ)≤n := by nlinarith
    exact_mod_cast hr
  have hcanon:6*(canonicalHoles n B).card<n/32 := by
    have:=h3 n (by omega) B hd hgap
    omega
  exact reduced_context_impossible6 γ n B hf hd (h1 n (by omega) B hf hd hgap)
    hn65536 hγ hγu hγn hq hk hcanon hlow (h2 n (by omega) B hd hgap)

/-- Original-N sharp k6 asymptotic endpoint, conditional only on Dousse6. -/
theorem complete_k6_endpoint (hD:Dousse6) : K6Goal :=
  endpoint_of_normalized hD (complete_normalized_k6 hD)
#print axioms reduced_context_impossible6
#print axioms complete_normalized_k6
#print axioms complete_k6_endpoint
end OP02.SharpK6

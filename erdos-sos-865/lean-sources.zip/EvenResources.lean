import EvenSelector
import PivotResources
import ZeroNormal
open Finset
namespace OP02.PositivePivot.EvenProof
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess

def twoPos (n:ℕ):=(Icc (n+1) (2*n)).filter (fun z=>z%4=2)
def twoMiddle (n:ℕ) (B:Finset ℕ):=(middle n B).filter (fun z=>z%4=2)
theorem twoPos_mem {n z:ℕ}:z∈twoPos n ↔ n<z ∧ z≤2*n ∧ z%4=2 := by
  simp only [twoPos,mem_filter,mem_Icc]
  omega
theorem twoPos_lower (n:ℕ):n/4≤(twoPos n).card := residue_interval_lower n 2 (by omega)

theorem critical_geom {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c) :
    Geom n a b c := by
  have ha:=mem_Icc.mp (mem_inter.mp (ht.tri.2.1 (by simp : a∈({a,b,c}:Finset ℕ)))).2
  have hb:=mem_Icc.mp (mem_inter.mp (ht.tri.2.1 (by simp : b∈({a,b,c}:Finset ℕ)))).2
  have hc:=mem_Icc.mp (mem_inter.mp (ht.tri.2.1 (by simp : c∈({a,b,c}:Finset ℕ)))).2
  exact ⟨ha.1,ht.lt,hb.2,hc.2,ht.ao,ht.bo,ht.co,ht.ab⟩

/-- Any even position in a selected support is one of the two actual endpoints. -/
theorem even_support {a b c p z y h:ℕ} (hao:a%2=1) (hbo:b%2=1)
    (hco:c%4=2) (hzo:z%4=2) (hye:y%2=1)
    (hz:2*z∈({p,p+a,p+b,p+c}:Finset ℕ))
    (hy:2*y∈({p,p+a,p+b,p+c}:Finset ℕ))
    (hh:h∈({p,p+a,p+b,p+c}:Finset ℕ)) (he:h%2=0) :
    h=2*z ∨ h=2*y := by
  simp only [mem_insert,mem_singleton] at hz hy hh
  rcases hz with hz|hz|hz|hz <;> rcases hy with hy|hy|hy|hy <;>
    rcases hh with hh|hh|hh|hh <;> omega

/-- The missing upper position is an actual excess hole when both endpoints are absent. -/
theorem selected_excess {n a b c z:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hz:z∈twoPos n) (hzB:z∉B)
    (hyB:(select n a b c z).1∉B) :
    ∃u∈({0,a,b,c}:Finset ℕ), (select n a b c z).2.1+u∈excessHoles n B := by
  have hg:=critical_geom ht
  have hzi:=twoPos_mem.mp hz
  have hv:=even_select_valid hg ⟨hzi.1,hzi.2.1,by omega⟩
  dsimp only at hv
  let p:=(select n a b c z).2.1
  have hm:∀ x ∈ ({a,b,c}:Finset ℕ), x ≤ max b c := by
    intro x hx
    simp only [mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl <;> have := ht.lt <;> omega
  obtain ⟨u,hu,hum⟩:=pivot_missing n (max b c) B {a,b,c} hf ht.tri hm p
    (mem_Icc.mpr ⟨by dsimp [p];omega,by dsimp [p];omega⟩)
  refine ⟨u,hu,mem_sdiff.mpr ⟨hum,?_⟩⟩
  intro him
  obtain ⟨v,hvM,hve⟩:=mem_image.mp him
  have hveven:(p+u)%2=0 := by omega
  have hsupport:p+u∈({p,p+a,p+b,p+c}:Finset ℕ) := by
    simp only [mem_insert,mem_singleton] at hu ⊢
    rcases hu with rfl|rfl|rfl|rfl <;> omega
  have hpair:=even_support ht.ao ht.bo ht.co hzi.2.2 hv.2.2.1
    hv.2.2.2.2.2.2.1 hv.2.2.2.2.2.2.2 hsupport hveven
  have hvB: v∈B := (mem_inter.mp hvM).1
  rcases hpair with hp|hp
  · have heq:v=z := by dsimp [p] at *;omega
    exact hzB (heq ▸ hvB)
  · have heq:v=(select n a b c z).1 := by dsimp [p] at *;omega
    exact hyB (heq ▸ hvB)

theorem count_neighbor {n a b c:ℕ} (hg:Geom n a b c) (S T:Finset ℕ)
    (hS:S⊆twoPos n) (hT:∀z∈S,(select n a b c z).1∈T) :
    S.card≤2*T.card := by
  let f:=fun z:ℕ=>((select n a b c z).1,(select n a b c z).2.2)
  have hinj:Set.InjOn f S := by
    intro z hz t ht he
    apply even_select_lane_injective hg (by have h:=twoPos_mem.mp (hS hz);omega) (by have h:=twoPos_mem.mp (hS ht);omega)
    · simpa only [f] using congrArg Prod.fst he
    · simpa only [f] using congrArg Prod.snd he
  have hsub:S.image f⊆T.product (range 2) := by
    intro x hx
    obtain ⟨z,hz,rfl⟩:=mem_image.mp hx
    have hv:=even_select_valid (z:=z) hg (by have h:=twoPos_mem.mp (hS hz);omega)
    exact mem_product.mpr ⟨hT z hz,mem_range.mpr (by dsimp [f];omega)⟩
  have hc:=card_le_card hsub
  rw [card_image_of_injOn hinj,product_eq_sprod,card_product,card_range] at hc
  omega

theorem count_double_neighbor {n a b c:ℕ} (hg:Geom n a b c) (S T:Finset ℕ)
    (hS:S⊆twoPos n) (hT:∀z∈S,2*(select n a b c z).1∈T) :
    S.card≤2*T.card := by
  let f:=fun z:ℕ=>(2*(select n a b c z).1,(select n a b c z).2.2)
  have hinj:Set.InjOn f S := by
    intro z hz t ht he
    have h1:=congrArg Prod.fst he
    have h2:=congrArg Prod.snd he
    exact even_select_lane_injective hg (by have h:=twoPos_mem.mp (hS hz);omega) (by have h:=twoPos_mem.mp (hS ht);omega)
      (by dsimp [f] at h1;omega) h2
  have hsub:S.image f⊆T.product (range 2) := by
    intro x hx
    obtain ⟨z,hz,rfl⟩:=mem_image.mp hx
    have hv:=even_select_valid (z:=z) hg (by have h:=twoPos_mem.mp (hS hz);omega)
    exact mem_product.mpr ⟨hT z hz,mem_range.mpr (by dsimp [f];omega)⟩
  have hc:=card_le_card hsub
  rw [card_image_of_injOn hinj,product_eq_sprod,card_product,card_range] at hc
  omega

theorem count_double (S T:Finset ℕ) (hT:∀z∈S,2*z∈T) : S.card≤T.card := by
  have hinj:Function.Injective (fun z:ℕ=>2*z) := by intro z t he; dsimp only at he; omega
  have hsub:S.image (fun z=>2*z)⊆T := by
    intro x hx
    obtain ⟨z,hz,rfl⟩:=mem_image.mp hx
    exact hT z hz
  have hc:=card_le_card hsub
  rw [card_image_of_injective _ hinj] at hc
  exact hc

theorem count_offset {n a b c:ℕ} (hg:Geom n a b c) (S T:Finset ℕ) (u:ℕ)
    (hS:S⊆twoPos n) (hT:∀z∈S,(select n a b c z).2.1+u∈T) :
    S.card≤T.card := by
  let f:=fun z:ℕ=>(select n a b c z).2.1+u
  have hinj:Set.InjOn f S := by
    intro z hz t ht he
    exact even_select_pivot_injective hg (by have h:=twoPos_mem.mp (hS hz);omega) (by have h:=twoPos_mem.mp (hS ht);omega)
      (by dsimp [f] at he;omega)
  have hsub:S.image f⊆T := by
    intro x hx
    obtain ⟨z,hz,rfl⟩:=mem_image.mp hx
    exact hT z hz
  have hc:=card_le_card hsub
  rw [card_image_of_injOn hinj] at hc
  exact hc

/-- The load-two count is tied to the actual upper holes and source FourFree predicate. -/
theorem actual_population {n a b c:ℕ} {B:Finset ℕ}
    (ht:Critical n B a b c) (hf:FourFree B) :
    n/4 ≤ (twoMiddle n B).card + 2*(parityMiddle n B 1).card +
      2*(H2 n B).card + 4*(Ho n B).card + (H0 n B).card := by
  let V:=twoPos n \ twoMiddle n B
  let W:Finset ℕ:={0,a,b,c}
  let X0:=V.filter (fun z=>(select n a b c z).1∈parityMiddle n B 1)
  let X1:=V.filter (fun z=>2*(select n a b c z).1∈H2 n B)
  let X2:=V.filter (fun z=>2*z∈H0 n B)
  let X3:=W.biUnion (fun u=>V.filter (fun z=>(select n a b c z).2.1+u∈Ho n B))
  have hV:V⊆twoPos n:=sdiff_subset
  have hg:=critical_geom ht
  have hc0:X0.card≤2*(parityMiddle n B 1).card :=
    count_neighbor hg X0 _ (fun z hz=>hV (mem_filter.mp hz).1)
      (fun z hz=>(mem_filter.mp hz).2)
  have hc1:X1.card≤2*(H2 n B).card :=
    count_double_neighbor hg X1 _ (fun z hz=>hV (mem_filter.mp hz).1)
      (fun z hz=>(mem_filter.mp hz).2)
  have hc2:X2.card≤(H0 n B).card :=
    count_double X2 _ (fun z hz=>(mem_filter.mp hz).2)
  have hcf:∀u∈W,(V.filter (fun z=>(select n a b c z).2.1+u∈Ho n B)).card≤(Ho n B).card := by
    intro u hu
    exact count_offset hg _ _ u (fun z hz=>hV (mem_filter.mp hz).1)
      (fun z hz=>(mem_filter.mp hz).2)
  have hW:W.card≤4 := by
    have h0:=card_insert_le 0 ({a,b,c}:Finset ℕ)
    have h1:=card_insert_le a ({b,c}:Finset ℕ)
    have h2:=card_insert_le b ({c}:Finset ℕ)
    simp only [card_singleton] at h2
    dsimp [W]
    omega
  have hc3:X3.card≤4*(Ho n B).card := by
    have hbi:=card_biUnion_le (s:=W) (t:=fun u=>V.filter (fun z=>(select n a b c z).2.1+u∈Ho n B))
    have hsum:=sum_le_sum hcf
    have hmul:=Nat.mul_le_mul_right (Ho n B).card hW
    simp only [sum_const_nat] at hsum
    dsimp [X3]
    omega
  have hcover:V⊆((X0∪X1)∪X2)∪X3 := by
    intro z hz
    have hzi:=twoPos_mem.mp (hV hz)
    have hv:=even_select_valid hg ⟨hzi.1,hzi.2.1,by omega⟩
    have hzB:z∉B := by
      intro hb
      have hzM:z∈twoMiddle n B :=
        mem_filter.mpr ⟨mem_inter.mpr ⟨hb,mem_Icc.mpr ⟨by omega,hzi.2.1⟩⟩,hzi.2.2⟩
      exact (mem_sdiff.mp hz).2 hzM
    by_cases hyB:(select n a b c z).1∈B
    · have hyM:(select n a b c z).1∈parityMiddle n B 1 :=
        mem_filter.mpr ⟨mem_inter.mpr ⟨hyB,mem_Icc.mpr ⟨by omega,by omega⟩⟩,hv.2.2.1⟩
      exact mem_union_left _ (mem_union_left _ (mem_union_left _ (mem_filter.mpr ⟨hz,hyM⟩)))
    · obtain ⟨u,hu,hH⟩:=selected_excess ht hf (hV hz) hzB hyB
      by_cases ho:((select n a b c z).2.1+u)%2=1
      · exact mem_union_right _ (mem_biUnion.mpr ⟨u,hu,mem_filter.mpr ⟨hz,mem_filter.mpr ⟨hH,ho⟩⟩⟩)
      · have he:((select n a b c z).2.1+u)%2=0 := by omega
        have hsupport:(select n a b c z).2.1+u∈
            ({(select n a b c z).2.1,(select n a b c z).2.1+a,
              (select n a b c z).2.1+b,(select n a b c z).2.1+c}:Finset ℕ) := by
          simp only [mem_insert,mem_singleton] at hu ⊢
          rcases hu with rfl|rfl|rfl|rfl <;> omega
        have hp:=even_support ht.ao ht.bo ht.co hzi.2.2 hv.2.2.1
          hv.2.2.2.2.2.2.1 hv.2.2.2.2.2.2.2 hsupport he
        rcases hp with hp|hp
        · have h2:2*z∈H0 n B:=mem_filter.mpr ⟨hp ▸ hH,by omega⟩
          exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨hz,h2⟩))
        · have h0:2*(select n a b c z).1∈H2 n B:=mem_filter.mpr ⟨hp ▸ hH,by omega⟩
          exact mem_union_left _ (mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨hz,h0⟩)))
  have hu0:=card_union_le X0 X1
  have hu1:=card_union_le (X0∪X1) X2
  have hu2:=card_union_le ((X0∪X1)∪X2) X3
  have hvbound:=card_le_card hcover
  have hsub:twoMiddle n B⊆twoPos n := by
    intro z hz
    obtain ⟨hzM,hzo⟩:=mem_filter.mp hz
    have hzi:=mem_Icc.mp (mem_inter.mp hzM).2
    exact twoPos_mem.mpr ⟨by omega,hzi.2,hzo⟩
  have hsplit:=card_sdiff_add_card_eq_card hsub
  have hlow:=twoPos_lower n
  dsimp [V] at hvbound
  omega

#print axioms actual_population
#print axioms twoPos_mem
#print axioms selected_excess
end OP02.PositivePivot.EvenProof

import FocusedSpec
open Finset
namespace OP02.ZeroExcess

def MidClosed (S : Finset ℤ) : Prop :=
  ∀ x ∈ S, ∀ y ∈ S, ∀ z : ℤ, x+y=2*z → z∈S

def progression (a d : ℤ) (k : ℕ) : Finset ℤ :=
  (range k).image (fun i : ℕ => a+d*(i:ℤ))

theorem progression_upper {a d : ℤ} {k : ℕ} (hd : 0<d) (hk : 0<k)
    {x : ℤ} (hx : x∈progression a d k) : x≤a+d*((k-1:ℕ):ℤ) := by
  obtain ⟨i,hi,rfl⟩ := mem_image.mp hx
  have hi' := mem_range.mp hi
  have hik : (i:ℤ)≤((k-1:ℕ):ℤ) := by omega
  nlinarith

theorem progression_last_gap {a d : ℤ} {k : ℕ} (hd : 0<d) (hk : 2≤k)
    {x : ℤ} (hx : x∈progression a d k)
    (hlt : a+d*((k-2:ℕ):ℤ)<x) : x=a+d*((k-1:ℕ):ℤ) := by
  obtain ⟨i,hi,rfl⟩ := mem_image.mp hx
  have hi' := mem_range.mp hi
  have hik : i=k-1 := by
    by_contra h
    have hi2 : (i:ℤ)≤((k-2:ℕ):ℤ) := by omega
    nlinarith
  rw [hik]

theorem progression_append {a d c : ℤ} {k : ℕ}
    (hd : 0<d) (ho : d%2=1)
    (hc : ∀ x∈progression a d k, x<c)
    (hm : MidClosed (insert c (progression a d k))) :
    ∃ a' d' : ℤ, ∃ k' : ℕ, 0<d' ∧ d'%2=1 ∧
      insert c (progression a d k)=progression a' d' k' := by
  by_cases hk0 : k=0
  · subst k
    refine ⟨c,1,1,by omega,by omega,?_⟩
    simp [progression]
  by_cases hk1 : k=1
  · subst k
    have ha : a∈progression a d 1 := by simp [progression]
    have hac := hc a ha
    have hod : (c-a)%2=1 := by
      by_contra h
      have heven : (a+c)%2=0 := by omega
      have hz := hm a (mem_insert_of_mem ha) c (mem_insert_self ..)
        ((a+c)/2) (by omega)
      have hz' : (a+c)/2=c ∨ (a+c)/2=a := by
        simpa [progression] using hz
      omega
    refine ⟨a,c-a,2,by omega,hod,?_⟩
    ext x
    simp [progression, show range 2=({0,1}:Finset ℕ) by decide]
    constructor
    · rintro (rfl|rfl) <;> omega
    · rintro (h|h) <;> omega
  have hk : 2≤k := by omega
  let t := a+d*((k-2:ℕ):ℤ)
  let p := a+d*((k-1:ℕ):ℤ)
  have hp : p∈progression a d k := by
    exact mem_image.mpr ⟨k-1,mem_range.mpr (by omega),rfl⟩
  have ht : t∈progression a d k := by
    exact mem_image.mpr ⟨k-2,mem_range.mpr (by omega),rfl⟩
  have hpc := hc p hp
  have hpt : p=t+d := by
    have heq : ((k-1:ℕ):ℤ)=((k-2:ℕ):ℤ)+1 := by omega
    dsimp [p,t]
    rw [heq]
    ring
  have hodd : (p+c)%2≠0 := by
    intro heven
    have hz := hm p (mem_insert_of_mem hp) c (mem_insert_self ..)
      ((p+c)/2) (by omega)
    have hzc : (p+c)/2≠c := by omega
    have hzS : (p+c)/2∈progression a d k := (mem_insert.mp hz).resolve_left hzc
    have hub := progression_upper hd (by omega : 0<k) hzS
    change (p+c)/2≤p at hub
    omega
  have heven : (t+c)%2=0 := by omega
  have hz := hm t (mem_insert_of_mem ht) c (mem_insert_self ..)
    ((t+c)/2) (by omega)
  have htc : t<c := by omega
  have hzc : (t+c)/2≠c := by omega
  have hzS : (t+c)/2∈progression a d k := (mem_insert.mp hz).resolve_left hzc
  have hzgt : t<(t+c)/2 := by omega
  have hzp := progression_last_gap hd hk hzS hzgt
  change (t+c)/2=p at hzp
  have hcp : c=p+d := by omega
  have hck : c=a+d*(k:ℤ) := by
    have heq : (k:ℤ)=((k-1:ℕ):ℤ)+1 := by omega
    rw [heq,hcp]
    dsimp [p]
    ring
  refine ⟨a,d,k+1,hd,ho,?_⟩
  unfold progression
  rw [range_add_one,image_insert]
  rw [hck]

theorem midpoint_progression (S : Finset ℤ) (hm : MidClosed S) :
    ∃ a d : ℤ, ∃ k : ℕ, 0<d ∧ d%2=1 ∧ S=progression a d k := by
  induction S using Finset.strongInductionOn with
  | _ S ih =>
    by_cases hn : S.Nonempty
    · let c := S.max' hn
      have hc : c∈S := max'_mem S hn
      have hupper : ∀ x∈S.erase c, x<c := by
        intro x hx
        have hne := (mem_erase.mp hx).1
        have hle := le_max' S x (mem_erase.mp hx).2
        change x≤c at hle
        omega
      have hclosed : MidClosed (S.erase c) := by
        intro x hx y hy z heq
        have hxS := (mem_erase.mp hx).2
        have hyS := (mem_erase.mp hy).2
        have hz := hm x hxS y hyS z heq
        have hxc := hupper x hx
        have hyc := hupper y hy
        exact mem_erase.mpr ⟨by omega,hz⟩
      obtain ⟨a,d,k,hd,ho,hS⟩ := ih (S.erase c) (erase_ssubset hc) hclosed
      have hm' : MidClosed (insert c (progression a d k)) := by
        rw [←hS,insert_erase hc]
        exact hm
      have hu' : ∀ x∈progression a d k, x<c := by
        rw [←hS]
        exact hupper
      obtain ⟨a',d',k',hd',ho',heq⟩ := progression_append hd ho hu' hm'
      refine ⟨a',d',k',hd',ho',?_⟩
      rw [←heq,←hS,insert_erase hc]
    · have hS : S=∅ := not_nonempty_iff_eq_empty.mp hn
      refine ⟨0,1,0,by omega,by omega,?_⟩
      simp [hS,progression]

#print axioms midpoint_progression
end OP02.ZeroExcess

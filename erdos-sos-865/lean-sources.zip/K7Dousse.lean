import K7EndpointSpec
open Finset Filter
namespace OP02.SharpK7

theorem dousse6_of_dousse7 (hD : Dousse7) : OP02.SharpK6.Dousse6 := by
  intro δ hδ
  obtain ⟨N₀,hN₀,h⟩ := hD δ hδ
  refine ⟨N₀,hN₀,?_⟩
  intro N hN T hT hcard
  obtain ⟨S,hST,hSc,hmid⟩ := h N hN T hT hcard
  obtain ⟨U,hUS,hUc⟩ := exists_subset_card_eq (show 6≤S.card by omega)
  refine ⟨U,Subset.trans hUS hST,hUc,?_⟩
  intro x hx y hy hxy
  exact hmid x (hUS hx) y (hUS hy) hxy

theorem dousse5_of_seven (h : Dousse7) : OP02.SharpK5.Dousse5 :=
  OP02.SharpK6.dousse5_of_dousse6 (dousse6_of_dousse7 h)

theorem dousse4_of_seven (h : Dousse7) : OP02.Frontier.Dousse4 :=
  OP02.SharpK5.dousse4_of_dousse5 (dousse5_of_seven h)

theorem fourfree_uniform (h : Dousse7) : ∀ ε : ℝ, 0 < ε → ∃ N₀ : ℕ, ∀ N : ℕ, N₀ ≤ N → ∀ A : Finset ℕ, A ⊆ Icc 1 N → OP02.FewHole.FourFree A → (A.card:ℝ) ≤ (21/32:ℝ)*N+ε*N := OP02.SharpK4.fourfree_uniform (dousse4_of_seven h)
theorem fivefree_uniform (h : Dousse7) : ∀ ε : ℝ, 0 < ε → ∃ N₀ : ℕ, ∀ N : ℕ, N₀ ≤ N → ∀ A : Finset ℕ, A ⊆ Icc 1 N → OP02.SharpK5.FiveFree A → (A.card:ℝ) ≤ (85/128:ℝ)*N+ε*N := OP02.SharpK6.fivefree_uniform (dousse5_of_seven h)

theorem sixfree_uniform (hD : Dousse7) (ε:ℝ) (hε:0<ε) :
    ∃N₀:ℕ,∀N:ℕ,N₀≤N→∀A:Finset ℕ,A⊆Icc 1 N→OP02.SharpK6.SixFree A→
      (A.card:ℝ)≤(341/512:ℝ)*N+ε*N := by
  have hg := OP02.SharpK6.complete_k6_endpoint (dousse6_of_dousse7 hD)
  change Asymptotics.IsLittleO atTop
    (fun N:ℕ=>(Erdos865.f N 6:ℝ)-(341/512:ℝ)*N)
    (fun N:ℕ=>(341/512:ℝ)*N) at hg
  have he := Asymptotics.isLittleO_iff.mp hg (show 0<ε/(341/512) from by positivity)
  obtain ⟨N₀,hN₀⟩ := eventually_atTop.mp he
  refine ⟨N₀,?_⟩
  intro N hN A hs hf
  have hc : A.card<Erdos865.f N 6 := by
    by_contra hh
    exact hf (OP02.SharpK4.threshold_spec N 6 A hs (by omega))
  have hcr : (A.card:ℝ)<(Erdos865.f N 6:ℝ) := by exact_mod_cast hc
  have hh := hN₀ N hN
  have hnn : (0:ℝ)≤(341/512:ℝ)*N := by positivity
  change ‖(Erdos865.f N 6:ℝ)-(341/512:ℝ)*N‖≤(ε/(341/512))*‖(341/512:ℝ)*N‖ at hh
  simp only [Real.norm_eq_abs,abs_of_nonneg hnn] at hh
  have := (abs_le.mp hh).2
  nlinarith



theorem deletion (hD : Dousse7) (δ : ℝ) (hδ : 0 < δ) :
      ∃ N0 : ℕ, 1 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N →
        ∀ A : Finset ℕ, A ⊆ Finset.Icc 1 N →
          SevenFree A →
          ∃ B : Finset ℕ, B ⊆ Finset.Icc 1 N ∧
            SevenFree B ∧
            OP02.FewHole.DoublingFree B ∧
            (A.card : ℝ) ≤ (B.card : ℝ) + δ * (N : ℝ) := by
    classical
    obtain ⟨N0, hN0, hD0⟩ := hD δ hδ
    refine ⟨N0, hN0, ?_⟩
    intro N hN A hsub hfour
    let T : Finset ℕ := A.filter (fun x => 2 * x ∈ A)
    have hTA : T ⊆ A := by
      intro x hx
      exact (Finset.mem_filter.mp hx).1
    have hTI : T ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hTA hx)
    have ht : (T.card : ℝ) < δ * (N : ℝ) := by
      by_contra hn
      have hd : δ * (N : ℝ) ≤ (T.card : ℝ) := le_of_not_gt hn
      obtain ⟨S, hST, hSc, hm⟩ := hD0 N hN T hTI hd
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hTA (hST hx)
      · intro x hx y hy hxy
        obtain ⟨z, hz, hzxy⟩ := hm x hx y hy hxy
        rw [hzxy]
        exact (Finset.mem_filter.mp hz).2
    let B : Finset ℕ := A \ T
    have hBA : B ⊆ A := by
      intro x hx
      exact (Finset.mem_sdiff.mp hx).1
    have hBI : B ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hBA hx)
    have hfB : SevenFree B := by
      rintro ⟨S, hSB, hSc, hpair⟩
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hBA (hSB hx)
      · intro x hx y hy hxy
        exact hBA (hpair x hx y hy hxy)
    have hdB : OP02.FewHole.DoublingFree B := by
      intro x hx h2
      obtain ⟨hxA, hxT⟩ := Finset.mem_sdiff.mp hx
      apply hxT
      exact Finset.mem_filter.mpr ⟨hxA, hBA h2⟩
    have hcard : B.card + T.card = A.card :=
      Finset.card_sdiff_add_card_eq_card hTA
    have hcardR : (B.card : ℝ) + (T.card : ℝ) = (A.card : ℝ) := by
      exact_mod_cast hcard
    refine ⟨B, hBI, hfB, hdB, ?_⟩
    linarith only [hcardR, ht]

end OP02.SharpK7

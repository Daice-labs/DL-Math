import PositiveParity
open Finset
namespace OP02.PositivePivot
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess

theorem partition_card (S A C:Finset ℕ) (hcover:∀x,x∈S ↔ x∈A ∨ x∈C)
    (hdis:∀x,x∈A→x∈C→False) : S.card=A.card+C.card := by
  have he:S=A∪C:=by ext x; simpa only [mem_union] using hcover x
  rw [he,card_union_of_disjoint (disjoint_left.mpr hdis)]

def res8 (S:Finset ℕ) (r:ℕ):=S.filter (fun x=>x%8=r)
def res4 (S:Finset ℕ) (r:ℕ):=S.filter (fun x=>x%4=r)

theorem pair_bound (n:ℕ) (B P S T A H:Finset ℕ) (hd:DoublingFree B)
    (hP:P⊆middle n B) (hn:NoEdge B P) (hS:S⊆P) (hT:T⊆P)
    (hneS:S.Nonempty) (hneT:T.Nonempty)
    (ha:∀x∈S,∀y∈T,∀v∈middle n B,2*v=x+y→v∈A)
    (hh:∀x∈S,∀y∈T,x+y∈excessHoles n B→x+y∈H) :
    S.card+T.card≤A.card+H.card+1 := by
  let F:=(A.image (fun v=>2*v))∪H
  have hs:∀x∈S,∀y∈T,x+y∈F := by
    intro x hx y hy
    have hxM:=hP (hS hx)
    have hyM:=hP (hT hy)
    have hxi:=mem_Icc.mp (mem_inter.mp hxM).2
    have hyi:=mem_Icc.mp (mem_inter.mp hyM).2
    have hnot:x+y∉B := by
      by_cases he:x=y
      · subst y
        simpa [two_mul] using hd x (mem_inter.mp hxM).1
      · exact hn x (hS hx) y (hT hy) he
    rcases missing_split (n:=n) (by omega) hnot with him|hex
    · obtain ⟨v,hv,hve⟩:=him
      exact mem_union_left _ (mem_image.mpr ⟨v,ha x hx y hy v hv hve,hve⟩)
    · exact mem_union_right _ (hh x hx y hy hex)
  have hb:=sum_union_lower S T F hneS hneT hs
  have hu:=card_union_le (A.image (fun v=>2*v)) H
  have hi:=card_image_le (s:=A) (f:=fun v=>2*v)
  dsimp [F] at *
  omega

/-- The finite residue calculation includes empty and singleton residue classes. -/
theorem four_residue_algebra (A B C D X Y Z:ℕ)
    (hAB:A=0 ∨ B=0 ∨ A+B≤X+1) (hCD:C=0 ∨ D=0 ∨ C+D≤X+1)
    (hAC:A=0 ∨ C=0 ∨ A+C≤B+D+Z+1)
    (hBD:B=0 ∨ D=0 ∨ B+D≤A+C+Y+1)
    (hA:A=0 ∨ 2*A≤A+C+Y+1) (hC:C=0 ∨ 2*C≤A+C+Y+1)
    (hB:B=0 ∨ 2*B≤B+D+Z+1) (hD:D=0 ∨ 2*D≤B+D+Z+1) :
    A+B+C+D≤2*X+2*Y+2*Z+2 := by
  omega

/-- Positive-excess odd-side bound, with all omitted members charged once. -/
theorem actual_odd_subset (n:ℕ) (B P:Finset ℕ) (hd:DoublingFree B)
    (hP:P⊆parityMiddle n B 1) (hn:NoEdge B P) :
    P.card≤2*deficit n B+2*((H0 n B).card+(H2 n B).card+
      ((parityMiddle n B 1)\P).card)+2 := by
  let O:=parityMiddle n B 1
  let F:=O\P
  let A:=res8 P 1
  let C:=res8 P 5
  let V:=res8 P 3
  let W:=res8 P 7
  let O1:=res4 P 1
  let O3:=res4 P 3
  let F1:=res4 F 1
  let F3:=res4 F 3
  let H4:=res8 (excessHoles n B) 4
  let Hx:=res8 (excessHoles n B) 2
  let Hy:=res8 (excessHoles n B) 6
  let T2:=(middle n B).filter (fun x=>x%4=2)
  have hpodd:∀x∈P,x%2=1:=fun x hx=>(mem_filter.mp (hP hx)).2
  have hfodd:∀x∈F,x%2=1:=fun x hx=>(mem_filter.mp (mem_sdiff.mp hx).1).2
  have hc1:O1.card=A.card+C.card := by
    apply partition_card
    · intro x
      simp only [O1,A,C,res4,res8,mem_filter]
      constructor
      · rintro ⟨hx,hr⟩
        by_cases h:x%8=1
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨hx,hr⟩|⟨hx,hr⟩) <;> exact ⟨hx,by omega⟩
    · intro x hx hy
      have h1:=(mem_filter.mp hx).2
      have h2:=(mem_filter.mp hy).2
      omega
  have hc3:O3.card=V.card+W.card := by
    apply partition_card
    · intro x
      simp only [O3,V,W,res4,res8,mem_filter]
      constructor
      · rintro ⟨hx,hr⟩
        by_cases h:x%8=3
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨hx,hr⟩|⟨hx,hr⟩) <;> exact ⟨hx,by omega⟩
    · intro x hx hy
      have h1:=(mem_filter.mp hx).2
      have h2:=(mem_filter.mp hy).2
      omega
  have hsplit:∀S:Finset ℕ,(∀x∈S,x%2=1)→S.card=(res4 S 1).card+(res4 S 3).card := by
    intro S hodd
    apply partition_card
    · intro x
      simp only [res4,mem_filter]
      constructor
      · intro hx
        have hp:=hodd x hx
        by_cases h:x%4=1
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨hx,_⟩|⟨hx,_⟩) <;> exact hx
    · intro x hx hy
      have h1:=(mem_filter.mp hx).2
      have h2:=(mem_filter.mp hy).2
      omega
  have hcP:=hsplit P hpodd
  have hcF:=hsplit F hfodd
  change P.card=O1.card+O3.card at hcP
  change F.card=F1.card+F3.card at hcF
  have hpc:∀r:ℕ,r%2=1→(res4 (middle n B) r).card≤
      (res4 P r).card+(res4 F r).card := by
    intro r hro
    have hs:res4 (middle n B) r⊆res4 P r∪res4 F r := by
      intro x hx
      obtain ⟨hxM,hxr⟩:=mem_filter.mp hx
      have hxO:x∈O:=mem_filter.mpr ⟨hxM,by omega⟩
      by_cases hxp:x∈P
      · exact mem_union_left _ (mem_filter.mpr ⟨hxp,hxr⟩)
      · exact mem_union_right _ (mem_filter.mpr ⟨mem_sdiff.mpr ⟨hxO,hxp⟩,hxr⟩)
    exact (card_le_card hs).trans (card_union_le _ _)
  have hp1:=hpc 1 (by omega)
  have hp3:=hpc 3 (by omega)
  have hp2:(res4 (middle n B) 2).card≤deficit n B:=middle_two_mod_four n B hd
  have hrr:∀r s p:ℕ,p<4→(r+s)%8=2*p→
      (res8 P r).card=0 ∨ (res8 P s).card=0 ∨
      (res8 P r).card+(res8 P s).card≤(res4 (middle n B) p).card+
        (res8 (excessHoles n B) (2*p)).card+1 := by
    intro r s p hp hrs
    by_cases hr0:(res8 P r).card=0
    · exact Or.inl hr0
    by_cases hs0:(res8 P s).card=0
    · exact Or.inr (Or.inl hs0)
    apply Or.inr;apply Or.inr
    apply pair_bound n B P (res8 P r) (res8 P s) (res4 (middle n B) p)
      (res8 (excessHoles n B) (2*p)) hd (fun x hx=>(mem_filter.mp (hP hx)).1) hn
      (filter_subset _ _) (filter_subset _ _)
      (card_pos.mp (by omega)) (card_pos.mp (by omega))
    · intro x hx y hy v hv he
      have hxr:=(mem_filter.mp hx).2
      have hys:=(mem_filter.mp hy).2
      exact mem_filter.mpr ⟨hv,by omega⟩
    · intro x hx y hy hhole
      have hxr:=(mem_filter.mp hx).2
      have hys:=(mem_filter.mp hy).2
      exact mem_filter.mpr ⟨hhole,by omega⟩
  have hAB:=hrr 1 3 2 (by omega) (by omega)
  have hCD:=hrr 5 7 2 (by omega) (by omega)
  have hAC:=hrr 1 5 3 (by omega) (by omega)
  have hBD:=hrr 3 7 1 (by omega) (by omega)
  have hAA:=hrr 1 1 1 (by omega) (by omega)
  have hCC:=hrr 5 5 1 (by omega) (by omega)
  have hBB:=hrr 3 3 3 (by omega) (by omega)
  have hDD:=hrr 7 7 3 (by omega) (by omega)
  norm_num only at hAB hCD hAC hBD hAA hCC hBB hDD
  change A.card=0 ∨ V.card=0 ∨ A.card+V.card≤_ at hAB
  change C.card=0 ∨ W.card=0 ∨ C.card+W.card≤_ at hCD
  change A.card=0 ∨ C.card=0 ∨ A.card+C.card≤_ at hAC
  change V.card=0 ∨ W.card=0 ∨ V.card+W.card≤_ at hBD
  change A.card=0 ∨ A.card=0 ∨ A.card+A.card≤_ at hAA
  change C.card=0 ∨ C.card=0 ∨ C.card+C.card≤_ at hCC
  change V.card=0 ∨ V.card=0 ∨ V.card+V.card≤_ at hBB
  change W.card=0 ∨ W.card=0 ∨ W.card+W.card≤_ at hDD
  change (res4 (middle n B) 1).card≤O1.card+F1.card at hp1
  change (res4 (middle n B) 3).card≤O3.card+F3.card at hp3
  have hfour:=four_residue_algebra A.card V.card C.card W.card
    (deficit n B+H4.card) (F1.card+Hx.card) (F3.card+Hy.card)
    (by dsimp [H4];omega) (by dsimp [H4];omega)
    (by dsimp [Hy];omega) (by dsimp [Hx];omega)
    (by dsimp [Hx];omega) (by dsimp [Hx];omega)
    (by dsimp [Hy];omega) (by dsimp [Hy];omega)
  have h4:H4.card≤(H0 n B).card := by
    apply card_le_card
    intro x hx
    obtain ⟨hxH,hx4⟩:=mem_filter.mp hx
    exact mem_filter.mpr ⟨hxH,by omega⟩
  have h26:(H2 n B).card=Hx.card+Hy.card := by
    apply partition_card
    · intro x
      simp only [H2,Hx,Hy,res8,mem_filter]
      constructor
      · rintro ⟨hx,hr⟩
        by_cases h:x%8=2
        · exact Or.inl ⟨hx,h⟩
        · exact Or.inr ⟨hx,by omega⟩
      · rintro (⟨hx,hr⟩|⟨hx,hr⟩) <;> exact ⟨hx,by omega⟩
    · intro x hx hy
      have h1:=(mem_filter.mp hx).2
      have h2:=(mem_filter.mp hy).2
      omega
  change P.card≤2*deficit n B+2*((H0 n B).card+(H2 n B).card+F.card)+2
  omega

theorem actual_odd_edgeless (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B)
    (hn:NoEdge B (parityMiddle n B 1)) :
    (parityMiddle n B 1).card≤2*deficit n B+2*((H0 n B).card+(H2 n B).card)+2 := by
  have h:=actual_odd_subset n B (parityMiddle n B 1) hd Subset.rfl hn
  simpa using h

#print axioms pair_bound
#print axioms four_residue_algebra
#print axioms actual_odd_subset
#print axioms actual_odd_edgeless
end OP02.PositivePivot

import K8CertifiedEndpoint
import Mathlib.Combinatorics.Additive.Corner.Roth

open Finset
namespace OP02.Midpoint

def tripleStarts (A : Finset ℕ) (d : ℕ) : Finset ℕ :=
  A.filter (fun x => x+d∈A ∧ x+2*d∈A)

def PopularBound : Prop :=
  ∀ k : ℕ, 0<k → ∃ K M : ℕ, 0<K ∧ 0<M ∧ ∀ L : ℕ, 0<L → ∃ N0 : ℕ, ∀ N : ℕ, N0≤N →
    ∀ A : Finset ℕ, A⊆Icc 1 N → N≤k*A.card →
      ∃ d : ℕ, L≤d ∧ d≤L*M ∧ N≤K*(tripleStarts A d).card

theorem mem_tripleStarts {s A d} (h : s∈tripleStarts A d) :
    s∈A ∧ s+d∈A ∧ s+2*d∈A := mem_filter.mp h

theorem tripleStarts_subset (A : Finset ℕ) (d : ℕ) : tripleStarts A d ⊆ A :=
  filter_subset _ _

end OP02.Midpoint

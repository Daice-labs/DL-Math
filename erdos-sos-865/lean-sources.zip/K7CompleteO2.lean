import K7SmallQuartetChoice
import K7FittedBounds
import K7DirectT2Rows
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask
set_option maxHeartbeats 1400000

theorem cutoff_q {κ q n:ℕ} (h:384*(κ+q)≤n/4) : 1536*q≤n:=by omega
theorem cutoff_z {b z n:ℕ} (h:z+b≤n/4/4):4*z≤n/4:=by omega
theorem cutoff_tau {w z q τ n:ℕ} (ht:τ≤4*q+8)
    (h:w+8*z+288*q+4*(4*q+8)+102≤n):w+8*z+288*q+4*τ+100≤n:=by omega
theorem cutoff_tau_succ {w z q τ n:ℕ} (ht:τ≤4*q+8)
    (h:w+8*z+288*q+4*(4*q+8)+102≤n):w+1+8*z+288*q+4*τ+100≤n:=by omega
theorem odd_forced_residue {x p y z w:ℕ} (xp:x%4≠p%4) (po:p%2=1)
    (yo:y%2=1) (e:w+p=2*(y+4*z)) : w%4≠x%4:=by omega
theorem even_forced_residue {y z w:ℕ} (yo:y%2=1) (e:w=2*(y+4*z)):w%4≠0:=by omega

/-- The same compact actual quartet both forces and consumes the selected half. -/
theorem exclude_two_odds (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ)→
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→
    ∀p x:ℕ,p<x→p%2=1→x%2=1→p%4≠x%4→ oddOffsets S={p,x}→False:=by
  classical
  obtain ⟨U,hU⟩:=inventory_uniform β hb
  obtain ⟨V,hV⟩:=uniform_window_threshold β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  obtain ⟨G,hG⟩:=padded_inventory hb
  refine ⟨max (4*2^23) (max U (max V (max W G))),?_⟩
  intro n hn B hf hd hg S hs p x px po xo opp oddset
  have sp:p∈S:=(mem_filter.mp (show p∈oddOffsets S by simp [oddset])).1
  have sx:x∈S:=(mem_filter.mp (show x∈oddOffsets S by simp [oddset])).1
  let s:=S.max' ⟨x,sx⟩
  have sm:s∈S:=max'_mem _ _
  have bounds (v:ℕ) (hv:v∈S) : v≤ s ∧ v≤n/4 := ⟨le_max' _ _ hv,(mem_Icc.mp (mem_inter.mp (hs.2.1 hv)).2).2⟩
  have sHi:= (bounds s sm).2
  have xs:=(bounds x sx).1
  have pairCap:=(mem_Icc.mp (mem_inter.mp (hs.2.2 p sp s sm (by omega))).2).2
  let E:=insert 0 (S \ {p,x})
  have sub:({p,x}:Finset ℕ)⊆S:=by intro v hv;simp only [mem_insert,mem_singleton] at hv;rcases hv with rfl|rfl <;> assumption
  have two:({p,x}:Finset ℕ).card=2:=card_pair (by omega)
  have diff:=card_sdiff_add_card_eq_card sub
  have four:E.card≤4:=by have h:=card_insert_le 0 (S\{p,x});have :=hs.1;change (insert 0 (S \ {p,x})).card≤4;omega
  have ev (v:ℕ) (hv:v∈E) : v%2=0 ∧ v≤ s:=by
    rcases mem_insert.mp hv with rfl|hs'
    · omega
    obtain ⟨vs,out⟩:=mem_sdiff.mp hs'
    have ve:v%2=0:=by
      by_contra no
      have hov:v∈oddOffsets S:=mem_filter.mpr ⟨vs,by omega⟩
      exact out (oddset ▸ hov)
    exact ⟨ve,(bounds v vs).1⟩
  obtain ⟨cap,large⟩:=hU n (by omega) B hd hg
  obtain ⟨_,hl⟩:=hV n (by omega)
  have gap:=hW n (by omega) B hf hd hg
  have pad:=hG n (by omega) B hd hg
  let H:=n/4
  let L:=(quarterMissing H (quarterD n B)).card
  let O:=(oddTopMissing H (quarterD n B)).card
  let q:=totalBudget n B
  have own:=actual_quarter_top_joint n B hd
  have joint:384*(L+O+q)+10000*logLevels H+300000≤H:=by dsimp only [L,O,q,H];omega
  obtain ⟨a,c,b,z,ap,ac,cb,bz,bd,zlo,zu,rzH,ra,rc,rb,rz,rac,rba,rbc,rza,rzc,rzb⟩:=compact_actual_quartet hd hg hl pad
  have geom:=fitted_quartet_geometry (n:=n) rfl joint bd sHi (le_of_lt (lt_of_lt_of_le px xs))
    (by omega) zlo zu rzH
  obtain ⟨y,w,ystart,yl,yu,yo,wl,wu,wo,we,wxb,slot,slotHi,direct,high⟩:=
    pair_half_selection_fitted hd (by omega) po xo opp px xs sHi ac cb bz (by omega) four ev geom.1
  have exactFit:=geom.2 y w ystart we
  have τ:favTau n B≤4*q+8:=by
    have h:=missingTopOdd_le_deficit n B hd;dsimp only [favTau,q];unfold totalBudget;omega
  let T:Finset ℕ:={a,c,b,z}
  have nt:T.card=4:=by simp [T,show a≠c by omega,show a≠b by omega,show a≠z by omega,
    show c≠b by omega,show c≠z by omega,show b≠z by omega]
  have inT:internalOn (quarterD n B) T:=by
    constructor
    · intro v hv;simp only [T,mem_insert,mem_singleton] at hv
      rcases hv with rfl|rfl|rfl|rfl <;> assumption
    · intro v hv j hj ne;simp only [T,mem_insert,mem_singleton] at hv hj
      rcases hv with rfl|rfl|rfl|rfl <;> rcases hj with rfl|rfl|rfl|rfl <;>
        first | exact (ne rfl).elim | assumption | rw [Nat.add_comm];assumption
  have Tmax (v:ℕ) (hv:v∈T):v≤z:=by simp only [T,mem_insert,mem_singleton] at hv;omega
  have wB:w∈B:=by simpa using high 0 (mem_insert_self _ _)
  have wS:w∉S:=fun hi=>by have :=(bounds w hi).2;omega
  have old:internalOn B S:=⟨fun _ h=>(mem_inter.mp (hs.2.1 h)).1,
    fun u hu v hv ne=>(mem_inter.mp (hs.2.2 u hu v hv ne)).1⟩
  have bad:2*(y+4*z)∉B:=by
    intro double
    have six:=append_clique old wB (show ∀v∈S,w+v∈B from by
      intro v hv
      by_cases v₁:v=p
      · subst v;rwa [we]
      by_cases v₂:v=x
      · subst v;exact wxb
      exact high v (mem_insert_of_mem (mem_sdiff.mpr ⟨hv,by simp [v₁,v₂]⟩)))
    have sz:(insert w S).card=6:=by simp [card_insert_of_notMem wS,hs.1]
    apply flexible_favorable_six (f:=x) (W:=w) hf hd gap large (cutoff_q cap) nt inT Tmax
      (cutoff_z rzH) six sz _ (bounds x sx).2 _ (cutoff_tau τ exactFit)
    · intro v hv;rcases mem_insert.mp hv with rfl|small
      · omega
      · have :=(bounds v small).2;omega
    · intro v hv ve ne
      rcases mem_insert.mp hv with eq|larger
      · subst v;omega
      · rcases mem_insert.mp larger with eq|small
        · subst v;exact odd_forced_residue opp.symm po yo we
        · have hvOdd:v∈oddOffsets S:=mem_filter.mpr ⟨small,ve.trans xo⟩
          rw [oddset] at hvOdd
          rcases mem_insert.mp hvOdd with eq|eq
          · simpa only [eq] using opp
          · exact (ne (mem_singleton.mp eq)).elim
  have yes:y+4*z∈B:=by
    by_contra absent
    exact slot (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,slotHi,absent,bad⟩)
  apply selected_common_half_impossible hf hd gap large cap ac cb bz (by omega) yu yo
    ra rc rb rz rac rba rbc rza rzc rzb (by simpa using direct 0 (by simp))
  intro v hv;simp only [mem_insert,mem_singleton] at hv
  rcases hv with rfl|rfl|rfl|rfl <;> first | exact yes | exact direct _ (by simp)


theorem balanced_two_rows (hD:Dousse7) {i:ℕ} (hi:i=8 ∨ i=9) : RowExclusion i := by
  classical
  intro β hb
  obtain ⟨U,hU⟩:=exclude_two_odds hD hb
  refine ⟨U,?_⟩;intro n hn B sub hf hd hg S hs row
  have state:(oddOffsets S).card=2 ∧ ¬sameOdd S:=by
    unfold rowNumber at row;dsimp only at row
    split_ifs at row <;> first | omega | exact ⟨by omega,by assumption⟩
  obtain ⟨x,y,ne,oddset⟩:=card_eq_two.mp state.1
  have xy:∀v∈({x,y}:Finset ℕ),v∈S ∧ v%2=1:=by
    intro v hv;exact mem_filter.mp (oddset.symm ▸ hv : v∈oddOffsets S)
  have xx:=xy x (by simp);have yy:=xy y (by simp)
  have op:x%4≠y%4:=by
    intro eq;apply state.2;refine ⟨x%4,by omega,by omega,?_⟩
    intro v hv vo;have hh: v∈oddOffsets S:=mem_filter.mpr ⟨hv,vo⟩
    simp only [oddset,mem_insert,mem_singleton] at hh;omega
  rcases lt_or_gt_of_ne ne with lt|gt
  · exact hU n hn B hf hd hg S hs x y lt xx.2 yy.2 op oddset
  · exact hU n hn B hf hd hg S hs y x gt yy.2 xx.2 op.symm (by rwa [Finset.pair_comm])

theorem complete_remaining_O2_windows (hD:Dousse7) : O2WindowGap :=
  gap_of_row9 (balanced_two_rows hD (Or.inr rfl))

end OP02.SharpK7.LongOddTask

import RootTotal
open Finset
namespace OP02.EdgeBand
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess OP02.PositivePivot

theorem even_middle_partition (n:ℕ) (B:Finset ℕ) :
    (parityMiddle n B 0).card=(middleZero n B).card+
      ((middle n B).filter (fun x=>x%4=2)).card := by
  apply partition_card
  · intro x
    simp only [parityMiddle,middleZero,mem_filter]
    constructor
    · intro hx
      by_cases h:x%4=0
      · exact Or.inl ⟨hx.1,h⟩
      · exact Or.inr ⟨hx.1,by omega⟩
    · rintro (⟨h,hr⟩|⟨h,hr⟩) <;> exact ⟨h,by omega⟩
  · intro x hx hy
    have :=(mem_filter.mp hx).2
    have :=(mem_filter.mp hy).2
    omega

/-- Complete actual odd-middle-edgeless branch; no criticality or supply premise. -/
theorem odd_edgeless_bound (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (ho:NoEdge B (parityMiddle n B 1)) :
    8*(quarterD n B).card≤n+8*(deficit n B+(excessHoles n B).card)+72 := by
  have hn:=hc.1
  have hf:=hc.2.2.1
  have hd:=hc.2.2.2.1
  have hh:=hc.2.2.2.2.1
  have hb:=hc.2.2.2.2.2.1
  have he:=excess_partition n B
  have hsmall:2*(Ho n B).card+1≤n/2 := by omega
  have hroot:=root_total_bound n B hf hsmall
  have hholes:=holes_partition n B hd
  have hmid:=middle_partition n B
  have hpart:=even_middle_partition n B
  have htwo:=middle_two_mod_four n B hd
  have hodd:=actual_odd_edgeless n B hd ho
  omega

/-- The requested actual even-edge branch, with no conditions on its endpoints. -/
theorem even_edge_odd_edgeless_bound (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (hedge:∃x∈parityMiddle n B 0,∃y∈parityMiddle n B 0,x≠y ∧ x+y∈B)
    (ho:NoEdge B (parityMiddle n B 1)) :
    8*(quarterD n B).card≤n+8*(deficit n B+(excessHoles n B).card)+72 :=
  odd_edgeless_bound n B hc ho

#print odd_edgeless_bound
#print axioms odd_edgeless_bound
#print axioms even_edge_odd_edgeless_bound
end OP02.EdgeBand

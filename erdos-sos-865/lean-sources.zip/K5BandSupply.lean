import K5GapNeighborhood
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 1000000

/-- Three shifted membership tests use a single missing-position union. -/
theorem triple_membership_loss (Y F B:Finset ℕ) (r s σ:ℕ)
    (hy:∀y∈Y,y%4=σ)
    (hF:∀y∈Y,y∈F ∧ y+4*r∈F ∧ y+4*s∈F) :
    Y.card≤(Y.filter (fun y=>y∈B ∧ y+4*r∈B ∧ y+4*s∈B)).card+3*(F\B).card := by
  classical
  let G:=Y.filter (fun y=>y∈B ∧ y+4*r∈B ∧ y+4*s∈B)
  let A:=Y\G
  have hA:A.card≤3*(F\B).card := by
    apply affine_cover_bound A {0,4*r,4*s} (F\B) 0 σ 1 3 (by omega)
    · intro y hyA; exact hy y (mem_sdiff.mp hyA).1
    · intro j; exact le_trans (card_le_card (filter_subset _ _)) card_le_three
    · intro y hyA
      obtain ⟨hyY,hyG⟩:=mem_sdiff.mp hyA
      have hf:=hF y hyY
      by_cases h0:y∉B
      · exact ⟨0,by simp,y,mem_sdiff.mpr ⟨hf.1,h0⟩,by omega⟩
      by_cases h1:y+4*r∉B
      · exact ⟨4*r,by simp,y+4*r,mem_sdiff.mpr ⟨hf.2.1,h1⟩,by omega⟩
      have h2:y+4*s∉B := by
        intro h2
        exact hyG (mem_filter.mpr ⟨hyY,by tauto⟩)
      exact ⟨4*s,by simp,y+4*s,mem_sdiff.mpr ⟨hf.2.2,h2⟩,by omega⟩
  have hcard:=card_sdiff_add_card_eq_card (show G⊆Y from filter_subset _ _)
  change A.card+G.card=Y.card at hcard
  change Y.card≤G.card+3*(F\B).card
  omega

def bandNeighbors (n r s σ:ℕ) (B:Finset ℕ) :=
  (middle n B).filter (fun y=>y%4=σ ∧ y+4*r∈B ∧ y+4*s∈B ∧
    n+4*(missingTopOdd n B).card+4<y ∧
    y<2*(n-4*(n/16))-(4*(missingTopOdd n B).card+4))

/-- Supply from the first K positions; two global endpoint losses, never one
loss per component. Every translated membership stays in the actual first band. -/
theorem first_band_supply (n u σ r s:ℕ) (B S:Finset ℕ)
    (hn:1024≤n) (hq:128*totalBudget n B≤n) (hd:DoublingFree B)
    (hu:2*u<n) (hσ:σ=1 ∨ σ=3) (hs:S⊆Icc 1 n)
    (hsmall:r+s≤n/16) :
    n/16≤(bandNeighbors n r s σ B).card+2*(missingTopOdd n B).card+
      3*(forcedBand n S u σ\B).card+3 := by
  classical
  let K:=n/16
  let hi:=(missingTopOdd n B).card
  let τ:=4*hi+4
  let W:=n-4*K
  let f:=4*((n+u/2+4-σ)/4)+σ
  let Y:=(range K).image (fun i=>f+4*i)
  have hf:n+u/2<f ∧ f≤n+u/2+4 ∧ f%4=σ := by dsimp [f]; rcases hσ with rfl|rfl <;> omega
  have hY (y:ℕ) (hy:y∈Y) : ∃i<K,y=f+4*i := by
    obtain ⟨i,hi,he⟩:=mem_image.mp hy
    exact ⟨i,mem_range.mp hi,he.symm⟩
  have hycard:Y.card=K := by
    rw [card_image_of_injective]
    · exact card_range K
    · intro i j he; change f+4*i=f+4*j at he; omega
  have hyres:∀y∈Y,y%4=σ := by intro y hy; obtain ⟨i,hi,rfl⟩:=hY y hy; omega
  have hyrange:∀y∈Y,n<y ∧ y≤2*W ∧ y≤2*n := by
    intro y hy; obtain ⟨i,hi,rfl⟩:=hY y hy
    dsimp only [W,K] at *; omega
  have hF:∀y∈Y,y∈forcedBand n S u σ ∧ y+4*r∈forcedBand n S u σ ∧ y+4*s∈forcedBand n S u σ := by
    intro y hy
    obtain ⟨i,hi,rfl⟩:=hY y hy
    have hband (j:ℕ) (hj:j<2*K) : f+4*j∈forcedBand n S u σ := by
      simp only [forcedBand,mem_filter,mem_Icc]
      dsimp only [K] at hj hi
      refine ⟨⟨by omega,by omega⟩,by omega,?_,by omega⟩
      intro a ha
      rcases mem_insert.mp ha with rfl|ha
      · omega
      · have haI:=mem_Icc.mp (hs ha); omega
    refine ⟨hband i (by omega),?_,?_⟩
    · convert hband (i+r) (by dsimp only [K] at hi ⊢; omega) using 1 <;> omega
    · convert hband (i+s) (by dsimp only [K] at hi ⊢; omega) using 1 <;> omega
  let G:=Y.filter (fun y=>y∈B ∧ y+4*r∈B ∧ y+4*s∈B)
  have hloss:=triple_membership_loss Y (forcedBand n S u σ) B r s σ hyres hF
  change Y.card≤G.card+3*(forcedBand n S u σ\B).card at hloss
  let A:=progression n (n+τ) 4 σ
  let Z:=progression (2*W-τ-1) (2*W) 4 σ
  have hhiq:hi≤totalBudget n B := by
    have hh:=deficit_split n B hd
    dsimp only [hi]; unfold totalBudget; omega
  have hA:A.card≤hi+1 := by
    rw [progression_card n (n+τ) 4 σ (by omega) (by omega)]
    dsimp only [τ]; omega
  have hZ:Z.card≤hi+2 := by
    have hh:=progression_upper (2*W-τ-1) (2*W) 4 σ (by omega) (by omega)
    change Z.card≤(2*W-(2*W-τ-1))/4+1 at hh
    dsimp only [W,K,τ] at hh
    omega
  have hsub:G⊆bandNeighbors n r s σ B∪A∪Z := by
    intro y hy
    obtain ⟨hyY,hyB,hyr,hys⟩:=mem_filter.mp hy
    have hyrng:=hyrange y hyY
    have hyσ:=hyres y hyY
    by_cases hlo:y≤n+τ
    · exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨mem_Ioc.mpr ⟨hyrng.1,hlo⟩,hyσ⟩))
    by_cases hhi:2*W-τ≤y
    · apply mem_union_right
      refine mem_filter.mpr ⟨mem_Ioc.mpr ⟨?_,hyrng.2.1⟩,hyσ⟩
      dsimp only [W,K,τ] at *; omega
    · apply mem_union_left
      apply mem_union_left
      exact mem_filter.mpr ⟨mem_inter.mpr ⟨hyB,mem_Icc.mpr ⟨by omega,hyrng.2.2⟩⟩,
        hyσ,hyr,hys,by change n+τ<y; omega,by change y<2*W-τ; omega⟩
  have hcard:=le_trans (card_le_card hsub) (card_union_le (bandNeighbors n r s σ B∪A) Z)
  have hcard2:=card_union_le (bandNeighbors n r s σ B) A
  rw [hycard] at hloss
  change K≤(bandNeighbors n r s σ B).card+2*hi+3*(forcedBand n S u σ\B).card+3
  omega

#print axioms triple_membership_loss
#print axioms first_band_supply
end OP02.SharpK5

import K7LongOddContract
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

/-- Integer endpoints chosen from the two original cleared inequalities, with open upper test.
The index i represents the positive odd tester 2i+1. -/
def lowerTesters (H t c : ℕ) : Finset ℕ :=
  (Icc (max (H/64) ((16*c+4*t-(H+16)+31)/32))
    (min ((3*(H/64))/2) ((8*t-(H+33))/64))).image (fun i => 2*i+1)

theorem lower_tester_data {H t c b : ℕ} (hb : b ∈ lowerTesters H t c)
    (ht : 17*(H/64) < t) (hscale : 16384 ≤ H/64) :
    2*(H/64) < b ∧ b ≤ 3*(H/64)+1 ∧ b%2=1 ∧
    16*c+4*t ≤ H+16*b ∧ H+32*b < 8*t := by
  obtain ⟨i,hi,rfl⟩ := mem_image.mp hb
  obtain ⟨hi1,hi2⟩ := mem_Icc.mp hi
  have ih := le_trans (le_max_right _ _) hi1
  have iy := hi2.trans (min_le_right _ _)
  have ix := le_trans (le_max_left _ _) hi1
  have iz := hi2.trans (min_le_left _ _)
  omega

theorem lower_tester_count {H t c : ℕ} (hc : c+2 ≤ H/64)
    (ht : 17*(H/64) < t) (htop : 3*t < H) (hscale : 16384 ≤ H/64) :
    4*((H/64:ℕ):ℤ) ≤ 8*((lowerTesters H t c).card:ℤ) +
      abs ((t:ℤ)-20*((H/64:ℕ):ℤ))+32 := by
  unfold lowerTesters
  rw [card_image_of_injective _ (fun i j (he:2*i+1=2*j+1) => by omega),Nat.card_Icc]
  rcases le_total t (20*(H/64)) with hs|hs
  · rw [abs_of_nonpos (by omega)]
    rcases le_total (H/64) ((16*c+4*t-(H+16)+31)/32) with hp|hp <;>
    rcases le_total (3*(H/64)/2) ((8*t-(H+33))/64) with hq|hq <;>
    simp only [max_def,min_def] <;> split_ifs <;> omega
  · rw [abs_of_nonneg (by omega)]
    rcases le_total (H/64) ((16*c+4*t-(H+16)+31)/32) with hp|hp <;>
    rcases le_total (3*(H/64)/2) ((8*t-(H+33))/64) with hq|hq <;>
    simp only [max_def,min_def] <;> split_ifs <;> omega

theorem lower_tester_filter {n t a c : ℕ} {B : Finset ℕ}
    (ht : 17*(n/4/64) < t) (hscale : 16384 ≤ n/4/64)
    (ha : 0<a) (hac : a<c) (hsum : a+c≤n/4/64)
    (hpar : a%2=0 ∧ c%2=0) :
    (lowerTesters (n/4) t c).card ≤
      (passes (lowerTesters (n/4) t c) {0,a,c} (quarterD n B)).card + 3*(midOddLoss n B).card := by
  apply shift_losses _ _ _ _ 1 0 3 (by intro x hx;omega) _ (fun _ _ => (card_filter_le _ _).trans card_le_three)
  intro b hb z hz miss
  have hh := lower_tester_data hb ht hscale
  simp only [mem_insert, mem_singleton] at hz
  rcases hz with rfl|rfl|rfl <;> apply miss_mid_odd _ _ _ miss <;> omega

end OP02.SharpK7.LongOddTask

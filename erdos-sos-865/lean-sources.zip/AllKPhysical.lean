import K9DeepAccounts
import K8Selection

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK8 OP02.SharpK9
namespace OP02.AllOrders

/-- Label a complete positive doubling chain by its unique upper terminal. -/
def chainTerminal (H x : ℕ) : ℕ :=
  if h : 0 < x ∧ 2*x ≤ H then chainTerminal H (2*x) else x
termination_by H-x
decreasing_by omega

theorem chainTerminal_double {H x : ℕ} (pos : 0<x) (upper : 2*x≤H) :
    chainTerminal H x=chainTerminal H (2*x) := by
  rw [chainTerminal]; simp [pos,upper]

theorem chainTerminal_top {H x : ℕ} (lo : H/2<x) : chainTerminal H x=x := by
  rw [chainTerminal]; simp [show ¬2*x≤H by omega]

theorem chainTerminal_compress {H x : ℕ} (pos : 0<x) (up : x≤H) :
    chainTerminal H (chainCompress x)=chainTerminal H x := by
  unfold chainCompress
  split_ifs with hc
  · rfl
  · have hf : canonical x=false := by cases h : canonical x <;> simp_all
    have eq := (canonical_false_parent x pos hf).1
    have lift := chainTerminal_double (H:=H) (x:=x/2) (by omega) (by omega)
    rwa [eq] at lift

/-- All deficient complete chains, labelled by their upper terminal. Multiple
unused slots on a single chain give one physical inventory entry. -/
def deficientChains (H : ℕ) (A : Finset ℕ) : Finset ℕ :=
  (unusedSlots H A).image (chainTerminal H)

theorem deficient_card {H : ℕ} {A : Finset ℕ} (sub : A⊆Icc 1 H) (df : DoublingFree A) :
    (deficientChains H A).card≤chainCapacity H-A.card := by
  have incl : A.image chainCompress⊆canonicalSlots H := by
    rintro x hx
    obtain ⟨y,hy,rfl⟩ := mem_image.mp hx
    exact chain_compression_mem H A sub hy
  have count := card_sdiff_add_card_eq_card incl
  rw [card_image_of_injOn (chain_compression_injective H A sub df)] at count
  change (unusedSlots H A).card+A.card=chainCapacity H at count
  exact (card_image_le : (deficientChains H A).card≤(unusedSlots H A).card).trans (by omega)

theorem deficient_iff {H n : ℕ} {A : Finset ℕ} (sub : A⊆Icc 1 H) (df : DoublingFree A) :
    n∈deficientChains H A ↔
      (A.filter (fun x => chainTerminal H x=n)).card <
        ((canonicalSlots H).filter (fun x=>chainTerminal H x=n)).card := by
  classical
  let C := (canonicalSlots H).filter (fun x=>chainTerminal H x=n)
  let B := A.filter (fun x=>chainTerminal H x=n)
  let I := B.image chainCompress
  have incl : I⊆C := by
    intro v hv
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hv
    obtain ⟨xA,term⟩ := mem_filter.mp hx
    obtain ⟨lo,up⟩ := mem_Icc.mp (sub xA)
    exact mem_filter.mpr ⟨chain_compression_mem H A sub xA,(chainTerminal_compress lo up).trans term⟩
  have same : I.card=B.card := card_image_of_injOn (fun x hx y hy he =>
    chain_compression_injective H A sub df (mem_filter.mp hx).1 (mem_filter.mp hy).1 he)
  have restrict {v : ℕ} (term : chainTerminal H v=n) : v∈A.image chainCompress ↔ v∈I := by
    constructor
    · intro hv
      obtain ⟨x,xA,rfl⟩ := mem_image.mp hv
      obtain ⟨lo,up⟩ := mem_Icc.mp (sub xA)
      exact mem_image.mpr ⟨x,mem_filter.mpr ⟨xA,(chainTerminal_compress lo up).symm.trans term⟩,rfl⟩
    · intro hv
      obtain ⟨x,hx,rfl⟩ := mem_image.mp hv
      exact mem_image_of_mem _ (mem_filter.mp hx).1
  have c := card_sdiff_add_card_eq_card incl
  change n∈deficientChains H A ↔ B.card<C.card
  constructor
  · intro h
    obtain ⟨v,hv,term⟩ := mem_image.mp h
    obtain ⟨slot,absent⟩ := mem_sdiff.mp hv
    have hpos : 0<(C\I).card := card_pos.mpr ⟨v,mem_sdiff.mpr
      ⟨mem_filter.mpr ⟨slot,term⟩,fun h=>absent ((restrict term).mpr h)⟩⟩
    omega
  · intro h
    obtain ⟨v,hv⟩ := card_pos.mp (show 0<(C\I).card by omega)
    obtain ⟨vC,absent⟩ := mem_sdiff.mp hv
    obtain ⟨slot,term⟩ := mem_filter.mp vC
    exact mem_image.mpr ⟨v,mem_sdiff.mpr ⟨slot,fun h=>absent ((restrict term).mp h)⟩,term⟩

theorem missing_top {H x : ℕ} {A : Finset ℕ} (sub : A⊆Icc 1 H)
    (lo : H/2<x) (up : x≤H) (can : canonical x=true) (miss : x∉A) :
    x∈deficientChains H A := by
  have slot := unused_canonical sub (by omega) up can miss (fun h => by
    have := (mem_Icc.mp (sub h)).2; omega)
  exact mem_image.mpr ⟨x,slot,chainTerminal_top lo⟩

theorem missing_pair {H x : ℕ} {A : Finset ℕ} (sub : A⊆Icc 1 H)
    (lo : H/2<x) (up : x≤H) (mod : x%4=2) (miss : x∉A) (half : x/2∉A) :
    x∈deficientChains H A := by
  have eq : 2*(x/2)=x := by omega
  have slot := unused_canonical sub (by omega : 0<x/2) (by omega)
    (canonical_odd _ (by omega)) half (eq.symm ▸ miss)
  have term := chainTerminal_double (H:=H) (x:=x/2) (by omega) (by omega)
  rw [eq,chainTerminal_top lo] at term
  exact mem_image.mpr ⟨_,slot,term⟩

theorem missing_head {H x : ℕ} {A : Finset ℕ} (sub : A⊆Icc 1 H) (df : DoublingFree A)
    (lo : H/4/2+2<x) (up : x≤H/4) (odd : x%2=1) (miss : x∉A) :
    4*x∈deficientChains H A := by
  have upper : 4*x≤H := by omega
  have lower : H/2<4*x := by omega
  by_cases mid : 2*x∈A
  · apply missing_top sub lower upper ((canonical_four x).trans (canonical_odd _ odd))
    simpa only [show 2*(2*x)=4*x by omega] using df (2*x) mid
  · have slot := unused_canonical sub (by omega) (by omega) (canonical_odd _ odd) miss mid
    have term := chainTerminal_double (H:=H) (x:=x) (by omega) (by omega)
    rw [chainTerminal_double (x:=2*x) (by omega) (by omega),
      show 2*(2*x)=4*x by omega,chainTerminal_top lower] at term
    exact mem_image.mpr ⟨_,slot,term⟩

/-- Both lists of failed tests use exactly the same physical inventory. The
same surviving p passes all upper and all lower tests at once. -/
theorem shared_loss {H z : ℕ} {A U targets W P : Finset ℕ}
    (sub : A⊆Icc 1 H) (df : DoublingFree A)
    (bounds : ∀p∈P,∀u∈U,H/2<p+u ∧ p+u≤H)
    (safe : ∀p∈P,∀u∈U,u∉targets → canonical (p+u)=true)
    (target : ∀p∈P,∀t∈targets,(p+t)%4=2 ∧ z≤(p+t)/2 ∧ ∀w∈W,
      H/4/2+2<(p+t)/2-z+w ∧ (p+t)/2-z+w≤H/4 ∧ ((p+t)/2-z+w)%2=1)
    (supply : (U.card+W.card*targets.card)*(chainCapacity H-A.card)<P.card) :
    ∃p∈P,(∀u∈U,p+u∉A → u∈targets ∧ (p+u)/2∈A) ∧
      ∀t∈targets,∀w∈W,(p+t)/2-z+w∈A := by
  classical
  let E := deficientChains H A
  let upper := rejected P U E (fun u p=>p+u)
  let row (t : ℕ) := rejected P W E (fun w p=>4*((p+t)/2-z+w))
  let lower := targets.biUnion row
  have uc : upper.card≤U.card*E.card := rejected_card P U E _ (by
    intro u _ a _ b _ he; change a+u=b+u at he; omega)
  have rc (t : ℕ) (ht : t∈targets) : (row t).card≤W.card*E.card :=
    rejected_card P W E _ (by
      intro w _ a ha b hb he
      obtain ⟨ma,za,_⟩ := target a ha t ht
      obtain ⟨mb,zb,_⟩ := target b hb t ht
      change 4*((a+t)/2-z+w)=4*((b+t)/2-z+w) at he
      omega)
  have lc : lower.card≤targets.card*(W.card*E.card) := by
    calc
      lower.card ≤ ∑t∈targets,(row t).card := card_biUnion_le
      _ ≤ ∑_t∈targets,W.card*E.card := sum_le_sum rc
      _ = _ := by simp
  have bound : (upper∪lower).card ≤ (U.card+W.card*targets.card)*E.card := by
    apply (card_union_le _ _).trans
    calc
      upper.card+lower.card ≤ _ := Nat.add_le_add uc lc
      _ = _ := by ring
  have cost := Nat.mul_le_mul_left (U.card+W.card*targets.card) (deficient_card sub df)
  obtain ⟨p,hp,keep⟩ := exists_mem_notMem_of_card_lt_card ((bound.trans cost).trans_lt supply)
  have noUpper (u : ℕ) (hu : u∈U) : p+u∉E :=
    fun h=>keep (mem_union_left _ (mem_rejected.mpr ⟨u,hu,hp,h⟩))
  refine ⟨p,hp,?_,?_⟩
  · intro u hu miss
    obtain ⟨lo,up⟩ := bounds p hp u hu
    have hit : u∈targets := by
      by_contra no
      exact noUpper u hu (missing_top sub lo up (safe p hp u hu no) miss)
    refine ⟨hit,?_⟩
    by_contra half
    exact noUpper u hu (missing_pair sub lo up (target p hp u hit).1 miss half)
  · intro t ht w hw
    by_contra absent
    obtain ⟨lo,up,odd⟩ := (target p hp t ht).2.2 w hw
    apply keep (mem_union_right _ (mem_biUnion.mpr ⟨t,ht,?_⟩))
    exact mem_rejected.mpr ⟨w,hw,hp,missing_head sub df lo up odd absent⟩

end OP02.AllOrders

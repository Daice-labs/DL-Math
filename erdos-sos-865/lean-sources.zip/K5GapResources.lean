import K5MiddleGap
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 4000000

def fourResources (n:ℕ) (B:Finset ℕ) :=
  ((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x) ∪ H0 n B

theorem four_resource_card (n:ℕ) (B:Finset ℕ) :
    (fourResources n B).card=((middle n B).filter (fun x=>x%4=2)).card+(H0 n B).card := by
  classical
  have hd:Disjoint (((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x)) (H0 n B) := by
    apply disjoint_left.mpr
    intro z hz he
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hz
    have he := (mem_sdiff.mp (mem_filter.mp he).1).2
    exact he (mem_image.mpr ⟨x,(mem_filter.mp hx).1,rfl⟩)
  rw [fourResources,card_union_of_disjoint hd]
  congr 1
  apply card_image_of_injOn
  intro x hx y hy he
  change 2*x=2*y at he
  omega

theorem four_resource_budget (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    (fourResources n B).card+(Ho n B).card≤totalBudget n B := by
  rw [four_resource_card]
  have ht := middle_two_le_singleton n B hd
  have hδ := deficit_split n B hd
  have hE := excess_partition n B
  unfold totalBudget
  omega

/-- Missing multiples of four in the doubled gap are actual resources: a
non-excess hole can only be the double of an M2 member, never an M0 member. -/
theorem missing_in_doubled_gap (n z:ℕ) (B:Finset ℕ)
    (hf:FiveFree B) (hd:DoublingFree B)
    (hbudget:3*(canonicalHoles n B).card<n/32)
    (hdense:5*n+32*totalBudget n B+52<32*(quarterD n B).card)
    (hz4:z%4=0) (hzB:z∉B)
    (hzL:2*n+2*(4*(missingTopOdd n B).card+4)<z)
    (hzU:z<4*(n-4*(n/16))-2*(4*(missingTopOdd n B).card+4)) :
    z∈fourResources n B := by
  classical
  have hhole:z∈holes n B := mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hzB⟩
  by_cases he:z∈excessHoles n B
  · exact mem_union_right _ (mem_filter.mpr ⟨he,hz4⟩)
  have hi:z∈(middle n B).image (fun x=>2*x) := by
    by_contra hh
    exact he (mem_sdiff.mpr ⟨hhole,hh⟩)
  obtain ⟨x,hx,rfl⟩ := mem_image.mp hi
  have hx4:x%4≠0 := by
    intro hh
    exact middle_gap n B hf hd hbudget hdense x hx hh ⟨by omega,by omega⟩
  exact mem_union_left _ (mem_image.mpr ⟨x,mem_filter.mpr ⟨hx,by omega⟩,rfl⟩)

#print axioms four_resource_card
#print axioms four_resource_budget
#print axioms missing_in_doubled_gap
end OP02.SharpK5

import K7Testers
import K7EndpointSpec

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

private theorem partner_load (a c b r z : ℕ) (hpar : a%2=1 ∨ b%2=1) :
    (({0,4*a,4*c,4*b} : Finset ℕ).filter (fun t=>(r+t)%8=z%8)).card≤3 := by
  classical
  by_cases h0 : r%8=z%8
  · rcases hpar with ha | hb
    · apply le_trans (card_le_card (t:={0,4*c,4*b}) _) card_le_three
      intro x hx
      simp only [mem_filter,mem_insert,mem_singleton] at hx ⊢
      rcases hx with ⟨(rfl|rfl|rfl|rfl),hx⟩ <;> first | tauto | omega
    · apply le_trans (card_le_card (t:={0,4*a,4*c}) _) card_le_three
      intro x hx
      simp only [mem_filter,mem_insert,mem_singleton] at hx ⊢
      rcases hx with ⟨(rfl|rfl|rfl|rfl),hx⟩ <;> first | tauto | omega
  · apply le_trans (card_le_card (t:={4*a,4*c,4*b}) _) card_le_three
    intro x hx
    simp only [mem_filter,mem_insert,mem_singleton] at hx ⊢
    rcases hx with ⟨(rfl|rfl|rfl|rfl),hx⟩ <;> first | tauto | omega

theorem select_partner (n a c b p : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hac : a<c) (hcb : c<b) (hbp : 4*b<p) (hpH : 2*p≤n/4) (hop : p%2=1)
    (hpar : a%2=1 ∨ b%2=1)
    (hcount : A_loss n B+3*T_loss n B <
      (progression (n/4/2) (n/4-p) 8 ((12-p%8)%8)).card) :
    ∃ χ, n/4/2<χ ∧ χ+p≤n/4 ∧ χ%2=1 ∧ χ%4≠p%4 ∧
      χ ∈ B ∧ χ+4*a ∈ B ∧ χ+4*c ∈ B ∧ χ+4*b ∈ B ∧ χ+p ∈ B := by
  classical
  let H := n/4; let r := (12-p%8)%8
  let Y := progression (H/2) (H-p) 8 r
  let O : Finset ℕ := {0,4*a,4*c,4*b}
  let G := passes Y O B
  have hy x (hx : x∈Y) : H/2<x ∧ x+p≤H ∧ x%8=r := by
    obtain ⟨hi,hs⟩ := mem_filter.mp hx
    have := mem_Ioc.mp hi;dsimp [H] at *;omega
  have hdpar (x : ℕ) (hx : x∈Y) : (x+p)%8=4 ∧ x%2=1 ∧ x%4≠p%4 := by
    have := (hy x hx).2.2
    dsimp [r] at this;omega
  have htop := shift_losses Y O B (absentTop n B) 8 r 3 (fun x hx=>(hy x hx).2.2)
    (by
      intro x hx t ht hn
      have h := hy x hx; have ho := (hdpar x hx).2.1
      apply mem_filter.mpr
      change t∈({0,4*a,4*c,4*b} : Finset ℕ) at ht
      simp only [mem_insert,mem_singleton] at ht
      rcases ht with rfl|rfl|rfl|rfl <;>
        exact ⟨mem_Ioc.mpr ⟨by change H/2<_;omega,by change _≤H;omega⟩,by omega,hn⟩)
    (fun z _=>partner_load a c b r z hpar)
  have htc := absent_top_cost n B hd
  have hroot : ∃ x∈G,(p+x)/4∈quarterD n B := by
    by_contra hnone
    push Not at hnone
    have hC : G.card ≤ A_loss n B := by
      apply card_le_card_of_injOn (fun x=>(p+x)/4)
      · intro x hx
        have hxY := (mem_filter.mp hx).1
        have h := hy x hxY; have he := (hdpar x hxY).1
        apply absent_quarter_root _ _ _ (hnone x hx)
        all_goals dsimp [H] at *;omega
      · intro x hx y hy' he
        have hx' := (hdpar x (mem_filter.mp hx).1).1
        have hy'' := (hdpar y (mem_filter.mp hy').1).1
        dsimp at he;omega
    change Y.card ≤ G.card+3*(absentTop n B).card at htop
    change A_loss n B+3*T_loss n B < Y.card at hcount
    omega
  obtain ⟨x,hx,hr⟩ := hroot
  have hxY := (mem_filter.mp hx).1
  have hterm := (mem_filter.mp hx).2
  have h := hy x hxY
  have ho := hdpar x hxY
  refine ⟨x,h.1,h.2.1,ho.2.1,ho.2.2,?_,hterm _ (by simp [O]),hterm _ (by simp [O]),
    hterm _ (by simp [O]),?_⟩
  · simpa using hterm 0 (by simp [O])
  · have hs := (mem_filter.mp hr).2
    rwa [show 4*((p+x)/4)=x+p by omega] at hs

/-- Five distinct vertices and their ten physical sums. The three root edges
are obtained from quarterD, and the partner sum from the selected odd root. -/
theorem actual_five (n a c b p χ : ℕ) (B : Finset ℕ)
    (ha : 0<a) (hac : a<c) (hcb : c<b) (hbp : 4*b<p) (hpx : p<χ) (hcap : χ+p≤n/4)
    (hra : a∈quarterD n B) (hrc : c∈quarterD n B) (hrb : b∈quarterD n B)
    (hrac : a+c∈quarterD n B) (hrab : a+b∈quarterD n B) (hrcb : c+b∈quarterD n B)
    (hp : p∈B) (hpa : p+4*a∈B) (hpc : p+4*c∈B) (hpb : p+4*b∈B)
    (hx : χ∈B) (hxa : χ+4*a∈B) (hxc : χ+4*c∈B) (hxb : χ+4*b∈B) (hxp : χ+p∈B) :
    InternalFive (B∩Icc 1 (n/4)) {4*a,4*c,4*b,p,χ} := by
  have sc {x} (hm : x∈quarterD n B) : 4*x∈B := (mem_filter.mp hm).2
  have h₁ : 4*a∈B := sc hra;have h₂ : 4*c∈B := sc hrc;have h₃ : 4*b∈B := sc hrb
  have h₄ : 4*a+4*c∈B := by simpa only [Nat.mul_add] using sc hrac
  have h₅ : 4*a+4*b∈B := by simpa only [Nat.mul_add] using sc hrab
  have h₆ : 4*c+4*b∈B := by simpa only [Nat.mul_add] using sc hrcb
  have hdis₁ : 4*a ∉ ({4*c,4*b,p,χ} : Finset ℕ) := by simp only [mem_insert,mem_singleton];omega
  have hdis₂ : 4*c ∉ ({4*b,p,χ} : Finset ℕ) := by simp only [mem_insert,mem_singleton];omega
  have hdis₃ : 4*b ∉ ({p,χ} : Finset ℕ) := by simp only [mem_insert,mem_singleton];omega
  refine ⟨by simp [card_insert_of_notMem,hdis₁,hdis₂,hdis₃,hpx.ne],?_,?_⟩
  · intro x hx'
    simp only [mem_insert,mem_singleton] at hx'
    rcases hx' with rfl|rfl|rfl|rfl|rfl <;>
      exact mem_inter.mpr ⟨by assumption,mem_Icc.mpr ⟨by omega,by omega⟩⟩
  · intro x hx' y hy' hne
    simp only [mem_insert,mem_singleton] at hx' hy'
    rcases hx' with rfl|rfl|rfl|rfl|rfl <;> rcases hy' with rfl|rfl|rfl|rfl|rfl <;>
      first | exact False.elim (hne rfl) |
        exact mem_inter.mpr ⟨by first | assumption | rw [Nat.add_comm];assumption,
                              mem_Icc.mpr ⟨by omega,by omega⟩⟩

end OP02.SharpK7

import K9Spec
import K8CentralFrame

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK9

open OP02.SharpK8 (internal_insert internal_mono in_top_holes plain_selection)

/-- A common upper translate adds its actual vertex and its four incident sums. -/
theorem inner_five_of_pass_of_small {h R : ℕ} {G T : Finset ℕ}
    (hT : Internal 4 G T) (small : ∀ x∈T, x≤h/4)
    (lo : h<2*R) (hi : 4*R≤3*h) (pass : ∀ s∈insert 0 T,R+s∈G) : InnerFive h G := by
  have newR : R∉T := fun hm => by have := small R hm; omega
  have hR : R∈G := by simpa using pass 0 (mem_insert_self _ _)
  exact ⟨T,R,hT.2.1,newR,internal_insert hT hR newR
    (fun t ht => pass t (mem_insert_of_mem ht)),lo,hi,small⟩

theorem inner_five_of_pass {h R : ℕ} {G T : Finset ℕ}
    (hT : Internal 4 (G∩Icc 1 (h/4)) T)
    (lo : h<2*R) (hi : 4*R≤3*h) (pass : ∀ s∈insert 0 T,R+s∈G) : InnerFive h G :=
  inner_five_of_pass_of_small (internal_mono hT inter_subset_left)
    (fun _ hx => (mem_Icc.mp (mem_inter.mp (hT.1 hx)).2).2) lo hi pass

private theorem five_roles_room {h d : ℕ} (large : 100000≤h) (cap : 384*d<h) :
    5*d < (3*h/4-h/2)/8 := by
  apply Nat.succ_le_iff.mp
  apply (Nat.le_div_iff_mul_le (by decide : 0<8)).2
  by_cases zero : d=0 <;> omega

/-- Only the four vertices are required to be short. Their six mutual sums
may lie anywhere in G. A single odd vertex makes all five translated labels canonical. -/
theorem inner_five_single_odd_of_small {h v : ℕ} {G T : Finset ℕ}
    (sub : G⊆Icc 1 h) (hd : DoublingFree G) (large : 100000≤h)
    (cap : 384*(chainCapacity h-G.card+1)<h)
    (hT : Internal 4 G T) (small : ∀ x∈T, x≤h/4)
    (hv : v∈T) (odd : v%2=1) (evenRest : ∀ x∈T, x≠v → x%2=0) : InnerFive h G := by
  classical
  let r := (12-v%8)%8
  let P := progression (h/2) (3*h/4) 8 r
  let Q := insert 0 T
  let E := topMissing h G
  have bounds (R : ℕ) (hR : R∈P) : h<2*R ∧ 4*R≤3*h := by
    have b := mem_Ioc.mp (mem_filter.mp hR).1
    change h/2<R ∧ R≤3*h/4 at b
    omega
  have cardQ : Q.card=5 := by
    have n0 : 0∉T := fun hz => by have := (mem_Icc.mp (sub (hT.1 hz))).1; omega
    change (insert 0 T).card=5
    rw [card_insert_of_notMem n0,hT.2.1]
  have cardE : E.card≤chainCapacity h-G.card := by
    have b := chain_capacity_with_top_loss h G sub hd
    dsimp [E]
    omega
  have cnt := progression_lower (h/2) (3*h/4) 8 r
    (Or.inr (Or.inl rfl)) (Nat.mod_lt _ (by decide))
  change (3*h/4-h/2)/8≤P.card at cnt
  have room : Q.card*E.card<P.card := by
    rw [cardQ]
    exact (five_roles_room large (by omega : 384*E.card<h)).trans_le cnt
  have fault (R : ℕ) (hR : R∈P) (s : ℕ) (hs : s∈Q) (miss : R+s∉G) : R+s∈E := by
    obtain ⟨rl,ru⟩ := bounds R hR
    have phase := (mem_filter.mp hR).2
    change R%8=(12-v%8)%8 at phase
    have shape : s≤h/4 ∧ canonical (R+s)=true := by
      by_cases special : s=v
      · subst s
        exact ⟨small v hv,canonical_four_residue _ (by omega)⟩
      · rcases mem_insert.mp hs with rfl|t
        · exact ⟨Nat.zero_le _,canonical_odd _ (by omega)⟩
        · have es := evenRest _ t special
          exact ⟨small s t,canonical_odd _ (by omega)⟩
    exact in_top_holes (by omega) (by have := shape.1; omega) shape.2 miss
  obtain ⟨R,hR,pass⟩ := plain_selection fault room
  exact inner_five_of_pass_of_small hT small (bounds R hR).1 (bounds R hR).2 pass

theorem inner_five_single_odd {h v : ℕ} {G T : Finset ℕ}
    (sub : G⊆Icc 1 h) (hd : DoublingFree G) (large : 100000≤h)
    (cap : 384*(chainCapacity h-G.card+1)<h)
    (hT : Internal 4 (G∩Icc 1 (h/4)) T)
    (hv : v∈T) (odd : v%2=1) (evenRest : ∀ x∈T, x≠v → x%2=0) : InnerFive h G :=
  inner_five_single_odd_of_small sub hd large cap (internal_mono hT inter_subset_left)
    (fun _ hx => (mem_Icc.mp (mem_inter.mp (hT.1 hx)).2).2) hv odd evenRest

/-- The reflected quartet interface needs the four members and their six original sum
memberships. Doubling-freeness rules out collisions of the reflected even vertex. -/
theorem inner_five_reflected {h w1 w2 z v : ℕ} {G : Finset ℕ}
    (sub : G⊆Icc 1 h) (hd : DoublingFree G) (large : 100000≤h)
    (cap : 384*(chainCapacity h-G.card+1)<h)
    (order : w1<w2) (s1 : w1≤h/4) (s2 : w2≤h/4) (sz : z≤h/4) (sv : v≤h/4)
    (e1 : w1%2=0) (e2 : w2%2=0) (ez : z%2=0) (ov : v%2=1)
    (g1 : w1∈G) (g2 : w2∈G) (gz : z∈G) (gv : v∈G)
    (g12 : w1+w2∈G) (g1z : w1+z∈G) (g1v : w1+v∈G)
    (g2z : w2+z∈G) (g2v : w2+v∈G) (gzv : z+v∈G) : InnerFive h G := by
  classical
  let T : Finset ℕ := {w1,w2,z,v}
  have ne1 : w1≠z := by
    rintro rfl
    exact hd _ g1 (by simpa only [two_mul] using g1z)
  have ne2 : w2≠z := by
    rintro rfl
    exact hd _ g2 (by simpa only [two_mul] using g2z)
  have hT : Internal 4 G T := by
    refine ⟨?_,?_,?_⟩
    · intro x hx
      simp only [T,mem_insert,mem_singleton] at hx
      rcases hx with rfl|rfl|rfl|rfl <;> assumption
    · simp [T,order.ne,ne1,ne2,show w1≠v by omega,show w2≠v by omega,show z≠v by omega]
    · intro a ha b hb neq
      simp only [T,mem_insert,mem_singleton] at ha hb
      rcases ha with rfl|rfl|rfl|rfl <;> rcases hb with rfl|rfl|rfl|rfl <;>
        first | contradiction | assumption | simpa only [Nat.add_comm] using g12 |
          simpa only [Nat.add_comm] using g1z | simpa only [Nat.add_comm] using g1v |
          simpa only [Nat.add_comm] using g2z | simpa only [Nat.add_comm] using g2v |
          simpa only [Nat.add_comm] using gzv
  refine inner_five_single_odd_of_small sub hd large cap hT ?_ (by simp [T]) ov ?_
  · intro x hx
    simp only [T,mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl|rfl <;> assumption
  · intro x hx ne
    simp only [T,mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl|rfl <;> first | assumption | contradiction

#print axioms inner_five_of_pass
#print axioms inner_five_single_odd
#print axioms inner_five_reflected

end OP02.SharpK9

import AllKBases

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.AllOrders

theorem coeff_nonneg (k : ℕ) : 0 ≤ coeff k := by
  unfold coeff
  have h : (1/4:ℝ)^(k-1) ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  positivity

theorem coeff_rec (k : ℕ) (hk : 2 ≤ k) : coeff k = 1/2 + coeff (k-1)/4 := by
  unfold coeff
  have eq : (1/4:ℝ)^(k-1) = (1/4:ℝ)^(k-1-1)*(1/4) := by
    conv_lhs => rw [show k-1 = (k-1-1)+1 by omega]
    rw [pow_succ]
  rw [eq]
  ring

theorem density_through_quarter {k T D G : ℕ} {η : ℝ} (hk : 2 ≤ k)
    (hη : 0 < η) (margin : 2 ≤ η*(T:ℝ)) (account : D ≤ G+(T+1)/2)
    (dense : (coeff k+η)*(T:ℝ) ≤ (D:ℝ)) :
    (coeff (k-1)+η/2)*(T/4:ℕ) ≤ (G:ℝ) := by
  rw [coeff_rec k hk] at dense
  have count : (D:ℝ) ≤ (G:ℝ) + ((T+1)/2:ℕ) := by exact_mod_cast account
  have floor : 2*(((T+1)/2:ℕ):ℝ) ≤ (T:ℝ)+1 := by
    exact_mod_cast (show 2*((T+1)/2)≤T+1 by omega)
  have scale : 4*((T/4:ℕ):ℝ) ≤ (T:ℝ) := by exact_mod_cast Nat.mul_div_le T 4
  nlinarith only [dense,count,floor,margin,
    mul_nonneg (coeff_nonneg (k-1)) (sub_nonneg.mpr scale),
    mul_nonneg hη.le (sub_nonneg.mpr scale), Nat.cast_nonneg (α:=ℝ) (T/4)]

theorem ShapeAt.mono {k T : ℕ} {A B F : Finset ℕ} {z : ℕ}
    (h : ShapeAt k T A F z) (sub : A⊆B) : ShapeAt k T B F z :=
  { h with clique := ⟨fun _ hx=>sub (h.clique.1 hx),h.clique.2.1,
      fun x hx y hy ne => sub (h.clique.2.2 x hx y hy ne)⟩ }

theorem shape_four {k J : ℕ} {A F : Finset ℕ} {z : ℕ}
    (g : ShapeAt k (J/4) (quarterD J A) F z) :
    ∃ W Z, ShapeAt k J A W Z ∧ (∀ w∈W, w%4=0) := by
  classical
  let W := F.image (fun x=>4*x)
  have hd {a : ℕ} (ha : a ∈ quarterD J A) : 4*a∈A := (mem_filter.mp ha).2
  have cl : OP02.SharpK8.Internal k A W := by
    refine ⟨?_,?_,?_⟩
    · intro x hx
      obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
      exact hd (g.clique.1 ha)
    · rw [show W.card=F.card by apply card_image_of_injective; intro a b h; change 4*a=4*b at h; omega]
      exact g.clique.2.1
    · intro x hx y hy hn
      obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
      obtain ⟨b,hb,rfl⟩ := mem_image.mp hy
      simpa only [Nat.mul_add] using hd (g.clique.2.2 a ha b hb (by rintro rfl; exact hn rfl))
  have all : ∀w∈W,w%4=0 := by
    intro w hw
    obtain ⟨x,_,rfl⟩ := mem_image.mp hw
    omega
  have scaled (v j : ℕ) (h : 256*v≤j*(J/4)) : 256*(4*v)≤j*J := by
    calc 256*(4*v) = 4*(256*v) := by omega
         _ ≤ 4*(j*(J/4)) := Nat.mul_le_mul_left 4 h
         _ = j*(4*(J/4)) := by ring
         _ ≤ j*J := Nat.mul_le_mul_left j (by omega)
  refine ⟨W,4*z,⟨cl,mem_image.mpr ⟨z,g.top,rfl⟩,?_,scaled _ _ g.height,?_,?_⟩,all⟩
  · have := g.above; omega
  · intro x hx hn
    obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
    exact scaled _ _ (g.small a ha (by rintro rfl; exact hn rfl))
  · refine ⟨1,Or.inl rfl,?_⟩
    have emp : W.filter (fun x=>x%4=1) = ∅ := by
      apply eq_empty_iff_forall_notMem.mpr
      intro x hx
      obtain ⟨hx,h⟩ := mem_filter.mp hx
      have := all x hx
      omega
    simp [emp]

theorem projected_inputs {k : ℕ} (hk : 8≤k) (prev2 : Shaped (k-2))
    (prev1 : Shaped (k-1)) (η : ℝ) (hη : 0<η) :
    ∃ M : ℕ, ∀ T : ℕ, M ≤ T → ∀ A : Finset ℕ, A⊆Icc 1 T →
      DoublingFree A → (coeff k+η)*(T:ℝ)≤A.card →
      ((chainCapacity T-A.card:ℕ):ℝ)<(2/3-coeff k)*(T:ℝ) ∧
      ∃ F f W z, ShapeAt (k-1) (T/4) A F f ∧ ShapeAt (k-2) (T/4) A W z ∧
        ∀w∈W,w%4=0 := by
  obtain ⟨N₁,h₁⟩ := prev1 (η/2) (by positivity)
  obtain ⟨N₂,h₂⟩ := prev2 (η/2/2) (by positivity)
  obtain ⟨N₃,h₃⟩ := capacity_uniform_error (η/2) (by positivity)
  obtain ⟨N₄,h₄⟩ := exists_nat_gt (4/η)
  refine ⟨16*(N₁+N₂+N₃+N₄+1),?_⟩
  intro T hT A sub df dense
  let J := T/4
  let A₁ := A ∩ Icc 1 J
  let A₂ := quarterD J A
  have split := OP02.SharpK8.top_band_cancellation T A sub df
  change A₁.card+_=A.card+_ at split
  have split₂ := lower_card_eq J A
  have card₂ := residue_card_le J A df
  change A₁.card=_+A₂.card at split₂
  have sizeT : (N₄:ℝ)≤T := by exact_mod_cast (show N₄≤T by omega)
  have sizeJ : (N₄:ℝ)≤J := by exact_mod_cast (show N₄≤J by dsimp [J];omega)
  have marT := (div_lt_iff₀ hη).mp (lt_of_lt_of_le h₄ sizeT)
  have marJ := (div_lt_iff₀ hη).mp (lt_of_lt_of_le h₄ sizeJ)
  have d₁ := density_through_quarter (show 2≤k by omega) hη (by nlinarith only [marT]) (show A.card≤A₁.card+(T+1)/2 by omega) dense
  have d₂ := density_through_quarter (show 2≤k-1 by omega) (half_pos hη)
    (show 2 ≤ η/2*(J:ℝ) by nlinarith only [marJ]) (show A₁.card≤A₂.card+(J+1)/2 by omega) d₁
  obtain ⟨F,f,g₁⟩ := h₁ J (by dsimp [J];omega) A₁ inter_subset_right
    (fun x hx h2=>df x (mem_inter.mp hx).1 (mem_inter.mp h2).1) d₁
  have ks : k-1-1=k-2 := by omega
  rw [ks] at d₂
  obtain ⟨V,v,g₂⟩ := h₂ (J/4) (by dsimp [J];omega) A₂ (filter_subset _ _)
    (quarter_doubling_free J A df) d₂
  obtain ⟨W,z,gw,div4⟩:=shape_four g₂
  refine ⟨?_,F,f,W,z,g₁.mono inter_subset_left,gw,div4⟩
  have cp := h₃ T (by omega)
  have room := chain_capacity_with_top_loss T A sub df
  have eq : ((chainCapacity T-A.card:ℕ):ℝ)+(A.card:ℝ)=chainCapacity T := by
    exact_mod_cast (show chainCapacity T-A.card+A.card=chainCapacity T by omega)
  nlinarith only [eq,dense,cp,marT]

end OP02.AllOrders

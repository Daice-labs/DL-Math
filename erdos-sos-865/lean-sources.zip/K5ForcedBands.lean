import K5AffineCover
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.PositivePivot
set_option maxHeartbeats 3000000

noncomputable def forcedBand (n:ℕ) (S:Finset ℕ) (u σ:ℕ) : Finset ℕ := by
  classical
  exact (Icc (n+1) (2*n)).filter (fun y=>2*n+u<2*y ∧
    (∀s∈insert 0 S,2*y+s≤4*n+u) ∧ y%4=σ)

theorem odd_missing_upper (n z:ℕ) (B:Finset ℕ)
    (hz:2*n<z ∧ z≤4*n) (ho:z%2=1) (hn:z∉B) : z∈Ho n B := by
  apply mem_filter.mpr
  refine ⟨mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,hz.2⟩,hn⟩,?_⟩,ho⟩
  intro hh
  obtain ⟨x,hx,he⟩ := mem_image.mp hh
  omega

theorem four_missing_upper (n z:ℕ) (B:Finset ℕ)
    (hz:2*n<z ∧ z≤4*n) (h4:z%8=4) (hn:z∉B) :
    z∈((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x) ∪ res8 (excessHoles n B) 4 := by
  classical
  have hhole : z∈holes n B := mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,hz.2⟩,hn⟩
  by_cases he:z∈excessHoles n B
  · exact mem_union_right _ (mem_filter.mpr ⟨he,h4⟩)
  have him : z∈(middle n B).image (fun x=>2*x) := by
    by_contra hi
    exact he (mem_sdiff.mpr ⟨hhole,hi⟩)
  obtain ⟨x,hx,rfl⟩ := mem_image.mp him
  exact mem_union_left _ (mem_image.mpr ⟨x,mem_filter.mpr ⟨hx,by omega⟩,rfl⟩)

/-- A complete actual band count. The other three offsets use the one physical
odd-hole set with aggregate load two; their individual counts are not added. -/
theorem forced_band_bound (n u v σ:ℕ) (B S:Finset ℕ)
    (hf:FiveFree B) (hs:S⊆lower n B) (hc:S.card=4)
    (hp:∀x∈S,∀y∈S,x≠y→x+y∈B)
    (hu:u∈insert 0 S) (hv:v∈insert 0 S) (hσ:σ=1 ∨ σ=3)
    (hres:(2*σ+v)%8=(u+4)%8)
    (hother:∀s∈insert 0 S\{u,v},s%2≠u%2)
    (hload:∀r:ℕ,((insert 0 S\{u,v}).filter (fun s=>s%4=r)).card≤2) :
    (forcedBand n S u σ\B).card≤
      ((middle n B).filter (fun x=>x%4=2)).card+(res8 (excessHoles n B) 4).card+
      (res8 (excessHoles n B) ((2*σ)%8)).card+2*(Ho n B).card := by
  classical
  let Y := forcedBand n S u σ\B
  let U := insert 0 S
  let T := U\{u,v}
  let A := Y.filter (fun y=>2*y∉B)
  let C := Y.filter (fun y=>2*y-u+v∉B)
  let F := Y.filter (fun y=>∃s∈T,2*y-u+s∉B)
  let E4 := (((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x)) ∪ res8 (excessHoles n B) 4
  have hY (y:ℕ) (hy:y∈Y) : n<y ∧ y≤2*n ∧ u<2*y ∧
      (∀s∈U,2*n<2*y-u+s ∧ 2*y-u+s≤4*n) ∧ y%4=σ ∧ y∉B := by
    obtain ⟨hyBand,hyB⟩ := mem_sdiff.mp hy
    have hb : y ∈ Icc (n+1) (2*n) ∧ 2*n+u<2*y ∧
        (∀s∈insert 0 S,2*y+s≤4*n+u) ∧ y%4=σ := by
      simpa only [forcedBand, mem_filter] using hyBand
    obtain ⟨hyI,hyL,hyH,hyr⟩ := hb
    obtain ⟨hy1,hy2⟩ := mem_Icc.mp hyI
    refine ⟨by omega,hy2,by omega,?_,hyr,hyB⟩
    intro s hsU
    have hh := hyH s hsU
    omega
  have hcover:Y⊆A∪C∪F := by
    intro y hy
    have hh := hY y hy
    have hpn : 2*y-u∉S := by
      intro hpS
      have hpn := (mem_Icc.mp (mem_inter.mp (hs hpS)).2).2
      have hupper := hh.2.2.2.1 0 (by simp [U])
      omega
    obtain ⟨s,hsU,hbad⟩ := four_clique_missing_label B S hf
      (fun x hx=>(mem_inter.mp (hs hx)).1) hc hp (2*y-u) hpn
    by_cases heu:s=u
    · subst s
      apply mem_union_left
      apply mem_union_left
      refine mem_filter.mpr ⟨hy,?_⟩
      have he:2*y-u+u=2*y := by omega
      simpa only [he] using hbad
    by_cases hev:s=v
    · subst s
      exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨hy,hbad⟩))
    · apply mem_union_right
      refine mem_filter.mpr ⟨hy,s,mem_sdiff.mpr ⟨hsU,?_⟩,hbad⟩
      simp [heu,hev]
  have hA : A.card≤(res8 (excessHoles n B) ((2*σ)%8)).card := by
    apply card_le_card_of_injOn (fun y=>2*y)
    · intro y hy
      obtain ⟨hyY,hbad⟩ := mem_filter.mp hy
      have hh := hY y hyY
      change 2*y∈res8 (excessHoles n B) ((2*σ)%8)
      apply mem_filter.mpr
      refine ⟨mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hbad⟩,?_⟩,by omega⟩
      intro him
      obtain ⟨z,hz,he⟩ := mem_image.mp him
      have hzB := (mem_inter.mp hz).1
      have hzy:z=y := by omega
      exact hh.2.2.2.2.2 (hzy ▸ hzB)
    · intro x hx y hy he
      change 2*x=2*y at he
      omega
  have hC : C.card≤E4.card := by
    apply card_le_card_of_injOn (fun y=>2*y-u+v)
    · intro y hy
      obtain ⟨hyY,hbad⟩ := mem_filter.mp hy
      have hh := hY y hyY
      change 2*y-u+v∈E4
      apply four_missing_upper n (2*y-u+v) B (hh.2.2.2.1 v hv) ?_ hbad
      omega
    · intro x hx y hy he
      have hx' := hY x (mem_filter.mp hx).1
      have hy' := hY y (mem_filter.mp hy).1
      change 2*x-u+v=2*y-u+v at he
      omega
  have hF : F.card≤2*(Ho n B).card := by
    apply affine_cover_bound F T (Ho n B) u σ 2 2 (by omega) ?_ hload ?_
    · intro y hy
      exact (hY y (mem_filter.mp hy).1).2.2.2.2.1
    · intro y hy
      obtain ⟨hyY,s,hsT,hbad⟩ := mem_filter.mp hy
      have hh := hY y hyY
      have hsU := (mem_sdiff.mp hsT).1
      have hsParity := hother s hsT
      refine ⟨s,hsT,2*y-u+s,odd_missing_upper n _ B (hh.2.2.2.1 s hsU) (by omega) hbad,by omega⟩
  have hE4 := card_union_le (((middle n B).filter (fun x=>x%4=2)).image (fun x=>2*x)) (res8 (excessHoles n B) 4)
  have him := card_image_le (s:=(middle n B).filter (fun x=>x%4=2)) (f:=fun x=>2*x)
  have h1 := card_le_card hcover
  have h2 := card_union_le A C
  have h3 := card_union_le (A∪C) F
  change Y.card≤_
  change E4.card≤_ at hE4
  omega

#print axioms odd_missing_upper
#print axioms four_missing_upper
#print axioms forced_band_bound
end OP02.SharpK5

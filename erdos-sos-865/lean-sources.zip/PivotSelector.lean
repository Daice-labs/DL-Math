import ZeroTriangle
open Finset
namespace OP02.PositivePivot

/-- Actual geometric selector: even endpoint, upper pivot, capacity lane. -/
def select (n a b c z : ℕ) : ℕ × ℕ × ℕ :=
  let u := c/2
  let w := (b-a)/2
  let alpha := (a+1)/2
  let r := 2*n-(b+1)/2
  let L := n+alpha
  if c≥b then
    if z≤2*n-u then (z+u, 2*z, 0) else (z-u, 2*(z-u), 1)
  else if u≥w then
    if z≤r then (z+u, 2*z, 0)
    else if z≤r+u then (z-u, 2*(z-u), 1)
    else (z-w, 2*(z-w-alpha)+1, 1)
  else
    if z<L then (z+u, 2*z, 1)
    else if z<L+w then (z+w, 2*(z-alpha)+1, 1)
    else (z-w, 2*(z-w-alpha)+1, 0)

def Geom (n a b c : ℕ) : Prop :=
  1≤a ∧ a<b ∧ b≤n ∧ c≤n ∧ a%2=1 ∧ b%2=1 ∧ c%4=2 ∧ a%4≠b%4

theorem steps {n a b c : ℕ} (hg:Geom n a b c) :
    (c/2)%2=1 ∧ ((b-a)/2)%2=1 ∧ 2≤c := by
  rcases hg with ⟨ha,hab,hbn,hcn,hao,hbo,hco,hab4⟩
  omega

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
theorem select_valid {n a b c z : ℕ} (hg:Geom n a b c)
    (hz:n<z ∧ z≤2*n ∧ z%2=1) :
    let s:=select n a b c z
    n<s.1 ∧ s.1≤2*n ∧ s.1%2=0 ∧
    2*n<s.2.1 ∧ s.2.1+max b c≤4*n ∧ s.2.2≤1 ∧
    (2*z∈({s.2.1,s.2.1+a,s.2.1+b,s.2.1+c}:Finset ℕ)) ∧
    (2*s.1∈({s.2.1,s.2.1+a,s.2.1+b,s.2.1+c}:Finset ℕ)) := by
  have hs:=steps hg
  rcases hg with ⟨ha,hab,hbn,hcn,hao,hbo,hco,hab4⟩
  have hc2 : 2*(c/2)=c := by omega
  have hw2 : 2*((b-a)/2)+a=b := by omega
  have ha2 : 2*((a+1)/2)=a+1 := by omega
  have hb2 : 2*((b+1)/2)=b+1 := by omega
  dsimp [select]
  split_ifs <;> simp only [mem_insert,mem_singleton] <;>
    (rcases Nat.le_total b c with hbc|hcb)
  all_goals first | rw [max_eq_right hbc] | rw [max_eq_left hcb]
  all_goals try simp only [Nat.mul_add, hc2, true_or, or_true, and_true, true_and]
  all_goals omega

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
theorem select_lane_injective {n a b c z t : ℕ} (hg:Geom n a b c)
    (hz:n<z ∧ z≤2*n ∧ z%2=1) (ht:n<t ∧ t≤2*n ∧ t%2=1)
    (hy:(select n a b c z).1=(select n a b c t).1)
    (hl:(select n a b c z).2.2=(select n a b c t).2.2) : z=t := by
  have hs:=steps hg
  rcases hg with ⟨ha,hab,hbn,hcn,hao,hbo,hco,hab4⟩
  simp only [select] at hy hl
  split_ifs at hy hl <;> simp_all only [Prod.fst,Prod.snd] <;> omega

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
theorem select_pivot_injective {n a b c z t : ℕ} (hg:Geom n a b c)
    (hz:n<z ∧ z≤2*n ∧ z%2=1) (ht:n<t ∧ t≤2*n ∧ t%2=1)
    (hp:(select n a b c z).2.1=(select n a b c t).2.1) : z=t := by
  have hs:=steps hg
  rcases hg with ⟨ha,hab,hbn,hcn,hao,hbo,hco,hab4⟩
  simp only [select] at hp
  split_ifs at hp <;> simp_all only [Prod.fst,Prod.snd] <;> omega

#print axioms select_valid
#print axioms select_lane_injective
#print axioms select_pivot_injective
end OP02.PositivePivot

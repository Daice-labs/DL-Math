import K6GapNeighborhood
import K6BandAccounting
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 4000000

noncomputable def finalBand (n:ℕ) (B S:Finset ℕ) (w a b σ:ℕ) : Finset ℕ := by
  classical
  exact (forcedBand n S w σ).filter (fun y=>∀t∈({a,b}:Finset ℕ),
    2*n+2*(4*(missingTopOdd n B).card+4)<2*y-w+t ∧
    2*y-w+t<4*(n-4*(n/16))-2*(4*(missingTopOdd n B).card+4))

/-- Complete actual missing-band count for the final three-odd profile.
The two even corrections share A4; the three odd labels share Ho with load two. -/
theorem final_band_bound (n w a b σ:ℕ) (B S:Finset ℕ)
    (hf:SixFree B) (hg:MiddleGap6 n B) (hs:S⊆lower n B) (hc:S.card=5)
    (hp:∀x∈S,∀y∈S,x≠y → x+y∈B)
    (hw:w∈insert 0 S) (ha:a∈insert 0 S) (hb:b∈insert 0 S)
    (hσ:σ=1 ∨ σ=3)
    (ha4:(2*σ+a)%4=w%4) (hb4:(2*σ+b)%4=w%4)
    (hother:∀s∈insert 0 S\{w,a,b},s%2≠w%2)
    (hload:∀r:ℕ,((insert 0 S\{w,a,b}).filter (fun s=>s%4=r)).card≤2) :
    (finalBand n B S w a b σ\B).card≤jointBandCost n B := by
  classical
  let Y:=finalBand n B S w a b σ\B
  let U:=insert 0 S
  let T:=U\{w,a,b}
  let A:=Y.filter (fun y=>2*y∉B)
  let C:=Y.filter (fun y=>∃t∈({a,b}:Finset ℕ),2*y-w+t∉B)
  let F:=Y.filter (fun y=>∃t∈T,2*y-w+t∉B)
  have hY (y:ℕ) (hy:y∈Y):n<y ∧ y≤2*n ∧ w<2*y ∧
      (∀s∈U,2*n<2*y-w+s ∧ 2*y-w+s≤4*n) ∧ y%4=σ ∧ y∉B := by
    obtain ⟨hyBand,hyB⟩:=mem_sdiff.mp hy
    have hbnd:y∈forcedBand n S w σ := (mem_filter.mp hyBand).1
    have hh:y∈Icc (n+1) (2*n) ∧ 2*n+w<2*y ∧
      (∀s∈U,2*y+s≤4*n+w) ∧ y%4=σ := by simpa only [forcedBand,mem_filter] using hbnd
    obtain ⟨hyI,hyL,hyH,hyr⟩:=hh
    have hi:=mem_Icc.mp hyI
    refine ⟨by omega,hi.2,by omega,?_,hyr,hyB⟩
    intro s hsU
    have:=hyH s hsU
    omega
  have hGap (y:ℕ) (hy:y∈Y) (t:ℕ) (ht:t∈({a,b}:Finset ℕ)):
      2*n+2*(4*(missingTopOdd n B).card+4)<2*y-w+t ∧
      2*y-w+t<4*(n-4*(n/16))-2*(4*(missingTopOdd n B).card+4) :=
    (mem_filter.mp (mem_sdiff.mp hy).1).2 t ht
  have hcover:Y⊆A∪C∪F := by
    intro y hy
    have hh:=hY y hy
    have hpn:2*y-w∉S := by
      intro hS
      have:=(mem_Icc.mp (mem_inter.mp (hs hS)).2).2
      have:=hh.2.2.2.1 0 (by simp [U])
      omega
    obtain ⟨t,ht,hbad⟩:=five_clique_missing_label B S hf
      (fun x hx=>(mem_inter.mp (hs hx)).1) hc hp (2*y-w) hpn
    by_cases htw:t=w
    · subst t
      have heq:2*y-w+w=2*y:=by omega
      exact mem_union_left _ (mem_union_left _ (mem_filter.mpr ⟨hy,by simpa only [heq] using hbad⟩))
    by_cases htab:t∈({a,b}:Finset ℕ)
    · exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨hy,t,htab,hbad⟩))
    · apply mem_union_right
      refine mem_filter.mpr ⟨hy,t,mem_sdiff.mpr ⟨ht,?_⟩,hbad⟩
      simp only [mem_insert,mem_singleton] at htab ⊢
      tauto
  have hA:A.card≤(H2 n B).card := by
    apply card_le_card_of_injOn (fun y=>2*y)
    · intro y hy
      obtain ⟨hyY,hbad⟩:=mem_filter.mp hy
      have hh:=hY y hyY
      change 2*y∈H2 n B
      apply mem_filter.mpr
      refine ⟨mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hbad⟩,?_⟩,by omega⟩
      intro hi
      obtain ⟨z,hz,he⟩:=mem_image.mp hi
      have hzB:=(mem_inter.mp hz).1
      have hzy:z=y:=by change 2*z=2*y at he; omega
      exact hh.2.2.2.2.2 (hzy ▸ hzB)
    · intro x hx y hy he
      change 2*x=2*y at he
      omega
  have hC:C.card≤2*(fourResources n B).card := by
    apply affine_cover_bound C {a,b} (fourResources n B) w σ 2 2 (by omega)
    · intro y hy; exact (hY y (mem_filter.mp hy).1).2.2.2.2.1
    · intro j; exact le_trans (card_filter_le _ _) card_le_two
    · intro y hy
      obtain ⟨hyY,t,ht,hbad⟩:=mem_filter.mp hy
      have hh:=hY y hyY
      have ht4:(2*y-w+t)%4=0 := by
        simp only [mem_insert,mem_singleton] at ht
        rcases ht with rfl|rfl <;> omega
      have hgap:=hGap y hyY t ht
      exact ⟨t,ht,2*y-w+t,missing_in_doubled_gap6 n _ B hg ht4 hbad hgap.1 hgap.2,by omega⟩
  have hF:F.card≤2*(Ho n B).card := by
    apply affine_cover_bound F T (Ho n B) w σ 2 2 (by omega) ?_ hload ?_
    · intro y hy; exact (hY y (mem_filter.mp hy).1).2.2.2.2.1
    · intro y hy
      obtain ⟨hyY,t,ht,hbad⟩:=mem_filter.mp hy
      have hh:=hY y hyY
      have htU:=(mem_sdiff.mp ht).1
      have htpar:=hother t ht
      exact ⟨t,ht,2*y-w+t,odd_missing_upper n _ B (hh.2.2.2.1 t htU) (by omega) hbad,by omega⟩
  have h1:=card_le_card hcover
  have h2:=card_union_le A C
  have h3:=card_union_le (A∪C) F
  change Y.card≤_
  unfold jointBandCost
  omega

#print axioms final_band_bound
end OP02.SharpK6

import K8Spec

open Finset Filter OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK8

/-- The normalized positive gap supplies an actual internal seven in this word's prefix. -/
theorem seed_from_density (hD : Dousse8) {β : ℝ} (hb : 0 < β) :
    ∃ N₀ : ℕ, ∀ n : ℕ, N₀ ≤ n → ∀ B : Finset ℕ, B ⊆ Icc 1 (4*n) →
    DoublingFree B → (5461 / 2048 + β) * (n : ℝ) + 1/2 ≤ B.card →
    SignedGap β n B ∧ ∃ S, Internal 7 (B ∩ Icc 1 n) S := by
  obtain ⟨U,hU⟩ := OP02.SharpK7.upper_endpoint_of_normalized (dousse7_of_dousse8 hD)
    (OP02.SharpK7.normalizedK7_of_dousse7 (dousse7_of_dousse8 hD)) (β/2) (by positivity)
  refine ⟨max 1 U,?_⟩
  intro n hn B sub hd hlarge
  have hinv := exact_inventory n B sub hd
  have hnat : B.card + totalBudget n B = 2*n+(n+1)/2+(quarterD n B).card := by
    unfold totalBudget; omega
  have hreal : (B.card : ℝ) + totalBudget n B =
      2*(n:ℝ)+((n+1)/2:ℕ)+(quarterD n B).card := by exact_mod_cast hnat
  have hceil : 2*(((n+1)/2:ℕ):ℝ) ≤ (n:ℝ)+1 := by exact_mod_cast (show 2*((n+1)/2)≤n+1 by omega)
  have hcount := counting_identity n B sub hd
  have hc : (B.card:ℝ)+(excessHoles n B).card=2*(n:ℝ)+(B∩Icc 1 n).card := by exact_mod_cast hcount
  have hp : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have h7 := hU n (by omega)
  have hN : (Erdos865.f n 7:ℝ) ≤ ((B ∩ Icc 1 n).card : ℝ) := by
    nlinarith only [hlarge,hc,h7,mul_pos hb hp,(show (0:ℝ) ≤ (excessHoles n B).card by positivity)]
  have hse := OP02.SharpK4.threshold_spec n 7 (B∩Icc 1 n) inter_subset_right (by exact_mod_cast hN)
  exact ⟨by unfold SignedGap; linarith only [hlarge,hreal,hceil], hse⟩

theorem normalized_of_lift (hD : Dousse8) (hL : AllProfileLift) : NormalizedK8Goal := by
  intro β hb
  obtain ⟨P,hP⟩ := seed_from_density hD hb
  obtain ⟨L,hT⟩ := hL β hb
  refine ⟨max P L,?_⟩
  intro n hn B sub hf hd
  by_contra! bad
  obtain ⟨gap,S,hs⟩ := hP n (by omega) B sub hd bad
  exact hf (hT n (by omega) B sub hd gap S hs)

end OP02.SharpK8

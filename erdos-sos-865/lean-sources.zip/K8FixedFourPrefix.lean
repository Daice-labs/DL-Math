import K8GeometrySpec
import K7Dousse

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5

namespace OP02.SharpK8

/-- A top-band hole whose half is absent, including all odd top-band holes. -/
def unmatchedTop (H : ℕ) (D : Finset ℕ) : Finset ℕ :=
  (Ioc (H/2) H).filter (fun y => y ∉ D ∧ ∀ x ∈ D, 2*x ≠ y)

/-- Exact cardinality cancellation for one quarter scale of the original root set. -/
theorem top_band_cancellation (H : ℕ) (D : Finset ℕ)
    (hD : D ⊆ Icc 1 H) (hd : DoublingFree D) :
    (D ∩ Icc 1 (H/4)).card + (H+1)/2 = D.card + (unmatchedTop H D).card := by
  classical
  let X := D ∩ Ioc (H/4) H
  let f (x : ℕ) := if x ≤ H/2 then 2*x else x
  have in_top {x : ℕ} (hx : x ∈ X) : f x ∈ Ioc (H/2) H := by
    have h := mem_Ioc.mp (mem_inter.mp hx).2
    simp only [f, mem_Ioc]
    split_ifs <;> omega
  have hinj : Set.InjOn f (X : Set ℕ) := by
    intro x hx y hy h
    have hxD := (mem_inter.mp hx).1
    have hyD := (mem_inter.mp hy).1
    have nx := hd x hxD
    have ny := hd y hyD
    unfold f at h
    split_ifs at h <;> first | omega | subst x; contradiction | subst y; contradiction
  have him : X.image f ⊆ Ioc (H/2) H := by
    intro y hy
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hy
    exact in_top hx
  have hholes : unmatchedTop H D = Ioc (H/2) H \ X.image f := by
    ext y
    simp only [unmatchedTop, mem_filter, mem_sdiff, mem_image]
    constructor
    · rintro ⟨ht,hy,hn⟩
      refine ⟨ht, ?_⟩
      rintro ⟨x,hx,hxy⟩
      have hxD := (mem_inter.mp hx).1
      dsimp only [f] at hxy
      split_ifs at hxy
      · exact hn x hxD hxy
      · exact hy (hxy ▸ hxD)
    · rintro ⟨ht,hn⟩
      have hy := mem_Ioc.mp ht
      refine ⟨ht,?_,?_⟩
      · intro hyD
        apply hn
        refine ⟨y, mem_inter.mpr ⟨hyD,mem_Ioc.mpr ⟨by omega,hy.2⟩⟩, ?_⟩
        simp [f, Nat.not_le_of_lt hy.1]
      · intro x hx hxy
        apply hn
        refine ⟨x,mem_inter.mpr ⟨hx,mem_Ioc.mpr ⟨by omega,by omega⟩⟩,?_⟩
        simp [f,show x ≤ H/2 by omega,hxy]
  have hdis : Disjoint (D ∩ Icc 1 (H/4)) X := by
    apply disjoint_left.mpr
    intro x hx hx'
    have hp := mem_Icc.mp (mem_inter.mp hx).2
    have hX := mem_Ioc.mp (mem_inter.mp hx').2
    omega
  have hpart : (D ∩ Icc 1 (H/4)) ∪ X = D := by
    ext x
    simp only [X,mem_union,mem_inter,mem_Icc,mem_Ioc]
    constructor
    · rintro (h | h) <;> exact h.1
    · intro hx
      have hi := mem_Icc.mp (hD hx)
      by_cases hp : x ≤ H/4
      · exact Or.inl ⟨hx,hi.1,hp⟩
      · exact Or.inr ⟨hx,by omega,hi.2⟩
  have part := card_union_of_disjoint hdis
  rw [hpart] at part
  have counted := card_sdiff_add_card_eq_card him
  rw [← hholes,card_image_of_injOn hinj,Nat.card_Ioc] at counted
  omega

/-- The signed original set forces a five, including all ten sums in this same prefix. -/
theorem signed_prefix_five (hD5 : Dousse5) {β : ℝ} (hb : 0 < β) :
    ∃ M : ℕ, ∀ n : ℕ, M ≤ n → ∀ B : Finset ℕ, DoublingFree B → SignedGap β n B →
      ∃ F : Finset ℕ, Internal 5 (quarterD n B ∩ Icc 1 ((n/4)/4)) F := by
  obtain ⟨U,hU⟩ := OP02.SharpK6.fivefree_uniform hD5 β hb
  obtain ⟨V,hV⟩ := exists_nat_gt (1/β)
  refine ⟨max (16*(U+1)) V,?_⟩
  intro n hn B hd hg
  let H := n/4
  let J := H/4
  let D := quarterD n B
  let A := D ∩ Icc 1 J
  have hD : D ⊆ Icc 1 H := filter_subset _ _
  have hcap := top_band_cancellation H D hD (quarter_doubling_free n B hd)
  change A.card + (H+1)/2 = D.card + (unmatchedTop H D).card at hcap
  have hr : (D.card:ℝ) ≤ (A.card:ℝ) + ((H+1)/2 : ℕ) := by
    exact_mod_cast (show D.card ≤ A.card + (H+1)/2 by omega)
  have hceil : 2*(((H+1)/2:ℕ):ℝ) ≤ (H:ℝ)+1 := by
    exact_mod_cast (show 2*((H+1)/2)≤H+1 by omega)
  have hnH : 4*(H:ℝ) ≤ n := by exact_mod_cast (show 4*H≤n by dsimp [H];omega)
  have hHJ : 4*(J:ℝ) ≤ H := by exact_mod_cast (show 4*J≤H by dsimp [J];omega)
  have hJn : 2*(J:ℝ) ≤ n := by exact_mod_cast (show 2*J ≤ n by dsimp [J,H];omega)
  have hVn : (V:ℝ) ≤ n := by exact_mod_cast (show V≤n by omega)
  have hβn := (div_lt_iff₀ hb).mp (lt_of_lt_of_le hV hVn)
  have gap : (341/2048+β)*(n:ℝ) ≤ (D.card:ℝ)-totalBudget n B := hg
  have hbudget : (0:ℝ) ≤ totalBudget n B := by positivity
  by_contra no
  have hfree : FiveFree A := by
    rintro ⟨F,hFA,hFc,hFp⟩
    exact no ⟨F,hFA,hFc,hFp⟩
  have hK := hU J (by dsimp [J,H];omega) A inter_subset_right hfree
  nlinarith only [gap,hr,hceil,hnH,hHJ,hK,hbudget,hβn,mul_nonneg hb.le (sub_nonneg.mpr hJn)]

end OP02.SharpK8

import K8Selection
open Finset
namespace OP02.SharpK8

def physicalSums (U V : Finset ℕ) := (U ×ˢ V).image (fun t => t.1 + t.2)

/-- Each of two sorted arms contributes actual pair sums, with a single shared corner. -/
theorem physical_sums_card (U V : Finset ℕ) (hu : U.Nonempty) (hv : V.Nonempty) :
    U.card + V.card ≤ (physicalSums U V).card+1 := by
  classical
  let a := U.min' hu
  let b := V.max' hv
  have ha : a∈U := min'_mem _ _
  have hb : b∈V := max'_mem _ _
  let L := V.image (fun y=>a+y)
  let R := (U.erase a).image (fun x=>x+b)
  have low : L.card=V.card := card_image_of_injective _ (by intro x y e; change a+x=a+y at e;omega)
  have high : R.card=(U.erase a).card := card_image_of_injective _ (by intro x y e; change x+b=y+b at e;omega)
  have di : Disjoint L R := by
    apply disjoint_left.mpr
    intro z hz hz'
    obtain ⟨y,hy,hl⟩ := mem_image.mp hz
    obtain ⟨x,hx,hr⟩ := mem_image.mp hz'
    have yl : y≤b := le_max' _ _ hy
    have xl : a≤x := min'_le _ _ (mem_of_mem_erase hx)
    have xn := (mem_erase.mp hx).1
    change a+y=z at hl;change x+b=z at hr;omega
  have inc : L∪R ⊆ physicalSums U V := by
    intro z hz
    rcases mem_union.mp hz with h|h
    · obtain ⟨y,hy,rfl⟩ := mem_image.mp h
      exact mem_image.mpr ⟨(a,y),mem_product.mpr ⟨ha,hy⟩,rfl⟩
    · obtain ⟨x,hx,rfl⟩ := mem_image.mp h
      exact mem_image.mpr ⟨(x,b),mem_product.mpr ⟨mem_of_mem_erase hx,hb⟩,rfl⟩
  have h := card_le_card inc
  rw [card_union_of_disjoint di,low,high,card_erase_of_mem ha] at h
  have := card_pos.mpr hu
  omega

def eightCell (S : Finset ℕ) (r : ℕ) := S.filter (fun x=>x%8=r)

theorem pair_cell_partition (S : Finset ℕ) (r : ℕ) (hr : r<4)
    (hs : ∀x∈S,x%4=r) :
    (eightCell S r).card+(eightCell S (r+4)).card=S.card := by
  have di : Disjoint (eightCell S r) (eightCell S (r+4)) := by
    apply disjoint_left.mpr; intro x h1 h2
    have p := (mem_filter.mp h1).2;have q := (mem_filter.mp h2).2
    change x%8=r at p;change x%8=r+4 at q;omega
  have eq : eightCell S r ∪ eightCell S (r+4)=S := by
    ext x;simp only [eightCell,mem_union,mem_filter]
    constructor
    · rintro (h|h) <;> exact h.1
    · intro hx; have := hs x hx;by_cases e:x%8=r
      · exact Or.inl ⟨hx,e⟩
      · exact Or.inr ⟨hx,by omega⟩
  rw [←card_union_of_disjoint di,eq]

theorem matching_good_sum {U V Bad : Finset ℕ} {r s M : ℕ}
    (hr : r<4) (hs : s<4) (rs : r+s=4)
    (uc : ∀x∈U,x%4=r) (vc : ∀x∈V,x%4=s)
    (umax : ∀i<8,(eightCell U i).card≤M) (vmax : ∀i<8,(eightCell V i).card≤M)
    (enough : 2*M<U.card+V.card) (loss : Bad.card<M) :
    ∃ a∈U, ∃ b∈V, (a+b)%8=4 ∧ a+b∉Bad := by
  classical
  have u := pair_cell_partition U r hr uc
  have v := pair_cell_partition V s hs vc
  have branch {i j : ℕ} (hi : i<8) (hj : j<8) (ij : (i+j)%8=4)
      (m : M<(eightCell U i).card+(eightCell V j).card) :
      ∃a∈U,∃b∈V,(a+b)%8=4 ∧ a+b∉Bad := by
    have uu := umax i hi;have vv := vmax j hj
    have plus := physical_sums_card (eightCell U i) (eightCell V j)
      (card_pos.mp (by omega)) (card_pos.mp (by omega))
    obtain ⟨z,hz,there⟩ := exists_mem_notMem_of_card_lt_card
      (show Bad.card<(physicalSums (eightCell U i) (eightCell V j)).card by omega)
    obtain ⟨⟨a,b⟩,hab,rfl⟩ := mem_image.mp hz
    obtain ⟨ha,hb⟩ := mem_product.mp hab
    refine ⟨a,(mem_filter.mp ha).1,b,(mem_filter.mp hb).1,?_,there⟩
    have aa := (mem_filter.mp ha).2;have bb := (mem_filter.mp hb).2
    change a%8=i at aa;change b%8=j at bb;omega
  by_cases first : M<(eightCell U r).card+(eightCell V s).card
  · exact branch (by omega) (by omega) (by omega) first
  · exact branch (i:=r+4) (j:=s+4) (by omega) (by omega) (by omega) (by omega)

end OP02.SharpK8

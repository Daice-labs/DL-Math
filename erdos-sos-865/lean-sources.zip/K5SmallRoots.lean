import K5Inventory
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess
set_option maxHeartbeats 3000000

theorem quarter_doubling_free (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B) :
    DoublingFree (quarterD n B) := by
  intro x hx hy
  have hxB := (mem_filter.mp hx).2
  have hyB := (mem_filter.mp hy).2
  apply hd (4*x) hxB
  convert hyB using 1 <;> omega

/-- Reflection counts one union, including diagonal sums. -/
theorem sumfree_card (K : ℕ) (X : Finset ℕ) (hs : X⊆Icc 1 K)
    (hf : ∀x∈X,∀y∈X,x+y∉X) : 2*X.card≤K+1 := by
  classical
  by_cases he : X.Nonempty
  · let m := X.max' he
    let Y := X.image (fun x=>m-x)
    have hm : m∈X := max'_mem X he
    have hxm : ∀x∈X,x ≤ m := fun x hx=>le_max' X x hx
    have hmc : m≤K := (mem_Icc.mp (hs hm)).2
    have hyc : Y.card=X.card := by
      apply card_image_of_injOn
      intro x hx y hy hxy
      have := hxm x hx
      have := hxm y hy
      change m-x=m-y at hxy
      omega
    have hdis : Disjoint X Y := by
      apply disjoint_left.mpr
      intro x hx hy
      obtain ⟨y,hy,heq⟩ := mem_image.mp hy
      have hym := hxm y hy
      have hsum : x+y=m := by omega
      exact hf x hx y hy (hsum ▸ hm)
    have hsub : X∪Y⊆Icc 0 m := by
      intro x hx
      rcases mem_union.mp hx with hx|hx
      · exact mem_Icc.mpr ⟨Nat.zero_le _,hxm x hx⟩
      · obtain ⟨y,hy,rfl⟩ := mem_image.mp hx
        exact mem_Icc.mpr ⟨Nat.zero_le _,Nat.sub_le _ _⟩
    have hc := card_le_card hsub
    rw [card_union_of_disjoint hdis,hyc,Nat.card_Icc] at hc
    omega
  · have : X=∅ := not_nonempty_iff_eq_empty.mp he
    simp [this]

/-- Full roots: no truncation error per component. -/
theorem quarter_root_capacity (H K : ℕ) (D : Finset ℕ) (hHK : 4*K≤H)
    (hs : D⊆Icc 1 H) (hd : DoublingFree D) :
    D.card+2*K≤H+((D.filter (fun x=>x≤K)).card) := by
  classical
  let X := D.filter (fun x=>x≤K)
  let Y := D.filter (fun x=>K<x ∧ x≤2*K)
  let Z := D.filter (fun x=>2*K<x ∧ x≤4*K)
  let T := D.filter (fun x=>4*K<x)
  have hpart : D=X∪Y∪Z∪T := by
    ext x
    simp only [X,Y,Z,T,mem_filter,mem_union]
    constructor
    · intro hx
      by_cases h1:x≤K
      · exact Or.inl (Or.inl (Or.inl ⟨hx,h1⟩))
      by_cases h2:x≤2*K
      · exact Or.inl (Or.inl (Or.inr ⟨hx,by omega,h2⟩))
      by_cases h4:x≤4*K
      · exact Or.inl (Or.inr ⟨hx,by omega,h4⟩)
      · exact Or.inr ⟨hx,by omega⟩
    · tauto
  have h1 : Disjoint X Y := by
    apply disjoint_left.mpr
    intro x hx hy
    have := (mem_filter.mp hx).2
    have := (mem_filter.mp hy).2
    omega
  have h2 : Disjoint (X∪Y) Z := by
    apply disjoint_left.mpr
    intro x hx hz
    simp only [X,Y,Z,mem_union,mem_filter] at hx hz
    omega
  have h3 : Disjoint (X∪Y∪Z) T := by
    apply disjoint_left.mpr
    intro x hx ht
    simp only [X,Y,Z,T,mem_union,mem_filter] at hx ht
    omega
  have hc : D.card=X.card+Y.card+Z.card+T.card := by
    rw [hpart,card_union_of_disjoint h3,card_union_of_disjoint h2,card_union_of_disjoint h1]
  let DY := Y.image (fun x=>2*x)
  have hdy : DY.card=Y.card := by
    apply card_image_of_injOn
    intro x hx y hy hxy
    change 2*x=2*y at hxy
    omega
  have hdz : Disjoint DY Z := by
    apply disjoint_left.mpr
    intro z hz hZ
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hz
    exact hd x (mem_filter.mp hx).1 (mem_filter.mp hZ).1
  have hyzsub : DY∪Z⊆Icc (2*K+1) (4*K) := by
    intro z hz
    rcases mem_union.mp hz with hz|hz
    · obtain ⟨x,hx,rfl⟩ := mem_image.mp hz
      have hx := (mem_filter.mp hx).2
      exact mem_Icc.mpr ⟨by omega,by omega⟩
    · have hz := (mem_filter.mp hz).2
      exact mem_Icc.mpr ⟨by omega,by omega⟩
  have hyz := card_le_card hyzsub
  rw [card_union_of_disjoint hdz,hdy,Nat.card_Icc] at hyz
  have htSub : T⊆Icc (4*K+1) H := by
    intro x hx
    obtain ⟨hxD,hxt⟩ := mem_filter.mp hx
    have hxH := (mem_Icc.mp (hs hxD)).2
    exact mem_Icc.mpr ⟨by omega,hxH⟩
  have ht := card_le_card htSub
  rw [Nat.card_Icc] at ht
  change D.card+2*K≤H+X.card
  omega

/-- The small actual Schur edge is derived from density, never selected as a premise. -/
theorem small_root_edge (n : ℕ) (B : Finset ℕ) (hd : DoublingFree B)
    (hden : 32*(quarterD n B).card>5*n+52) :
    ∃r∈quarterD n B,∃s∈quarterD n B,r≠s ∧ r+s∈quarterD n B ∧ r+s≤n/16 := by
  classical
  let D := quarterD n B
  let K := n/16
  let X := D.filter (fun x=>x≤K)
  have hdf := quarter_doubling_free n B hd
  have hcap := quarter_root_capacity (n/4) K D (by dsimp [K]; omega) (filter_subset _ _) hdf
  by_contra hn
  have hf : ∀x∈X,∀y∈X,x+y∉X := by
    intro x hx y hy hxy
    have hxD := (mem_filter.mp hx).1
    have hyD := (mem_filter.mp hy).1
    obtain ⟨hxyD,hxyK⟩ := mem_filter.mp hxy
    by_cases he:x=y
    · subst y
      apply hdf x hxD
      simpa [two_mul] using hxyD
    · exact hn ⟨x,hxD,y,hyD,he,hxyD,hxyK⟩
  have hs : X⊆Icc 1 K := by
    intro x hx
    obtain ⟨hxD,hxK⟩ := mem_filter.mp hx
    have hx1 := (mem_Icc.mp (mem_filter.mp hxD).1).1
    exact mem_Icc.mpr ⟨hx1,hxK⟩
  have hc := sumfree_card K X hs hf
  change D.card+2*K≤n/4+X.card at hcap
  change 32*D.card>5*n+52 at hden
  dsimp [K] at *
  omega

#print axioms quarter_doubling_free
#print axioms sumfree_card
#print axioms quarter_root_capacity
#print axioms small_root_edge
end OP02.SharpK5

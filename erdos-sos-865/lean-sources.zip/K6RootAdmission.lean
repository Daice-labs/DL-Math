import K6EarlyTriangle
import K5CapacityError
open Finset Erdos865
namespace OP02.SharpK6
open OP02.FewHole OP02.SharpK5
set_option maxHeartbeats 2000000

/-- Admission with an integer density margin g. The selected vertices are early,
but all pair-sum labels remain in the original actual X. Padding adds no members. -/
theorem root_early_cutoff (K q g : ℕ) (X : Finset ℕ)
    (hK : 128≤K) (hg : 20≤g) (hs : X⊆Icc 1 K)
    (hcap : 4*X.card≤3*K) (hdense : 5*K+8*q+8*g≤8*X.card+16) :
    ∃U:ℕ, EarlyTriangle X U ∧ 16*U+16*q+16*g≤11*K+192 := by
  let M := (K+1)/2
  let U := (42*M+127-16*X.card)/16
  have hM : 64≤M := by dsimp [M]; omega
  have hKM : K≤2*M ∧ 2*M≤K+1 := by dsimp [M]; omega
  have hsub : X⊆Icc 1 (2*M) := by
    intro x hx
    have hi:=mem_Icc.mp (hs hx)
    exact mem_Icc.mpr ⟨hi.1,by omega⟩
  have hpos : 16*X.card≤42*M+127 := by omega
  have hUlow : 42*M+112≤16*(X.card+U) := by dsimp [U]; omega
  have hUhigh : 16*(X.card+U)≤42*M+127 := by dsimp [U]; omega
  have htri:=early_triangle M U X hM hsub (by omega) (by omega) (by omega) (by omega)
  exact ⟨U,htri,by omega⟩

/-- The capacity side-condition above is derived for every sufficiently large
actual doubling-free X; it is not a stability or favorable-prefix hypothesis. -/
theorem root_early_uniform : ∃K₀:ℕ,∀K:ℕ,K₀≤K→∀q g:ℕ,20≤g→∀X:Finset ℕ,
    X⊆Icc 1 K→DoublingFree X→5*K+8*q+8*g≤8*X.card+16→
    ∃U:ℕ,EarlyTriangle X U ∧ 16*U+16*q+16*g≤11*K+192 := by
  obtain ⟨K₀,hK₀⟩:=capacity_uniform_error (1/12) (by norm_num)
  refine ⟨max 128 K₀,?_⟩
  intro K hK q g hg X hs hd hden
  have hcap:=hK₀ K (by omega)
  have hc:=chain_capacity_with_top_loss K X hs hd
  have hcr : (X.card:ℝ)≤chainCapacity K := by exact_mod_cast (show X.card≤chainCapacity K by omega)
  have hsmall : 4*X.card≤3*K := by
    have hr : (4:ℝ)*X.card≤3*K := by linarith
    exact_mod_cast hr
  exact root_early_cutoff K q g X (by omega) hg hs hsmall hden

#print axioms root_early_cutoff
#print axioms root_early_uniform

/-- The same cutoff with a real positive-gap margin, preserving the paper's +12. -/
theorem root_early_cutoff_real (K q : ℕ) (g : ℝ) (X : Finset ℕ)
    (hK : 128≤K) (hg : 20≤g) (hs : X⊆Icc 1 K)
    (hcap : 4*X.card≤3*K) (hdense : (5:ℝ)*K+8*q+8*g≤8*X.card+16) :
    ∃U:ℕ, EarlyTriangle X U ∧ (16:ℝ)*U+16*q+16*g≤11*K+192 := by
  let M := (K+1)/2
  let U := (42*M+127-16*X.card)/16
  have hM : 64≤M := by dsimp [M]; omega
  have hKM : K≤2*M ∧ 2*M≤K+1 := by dsimp [M]; omega
  have hsub : X⊆Icc 1 (2*M) := by
    intro x hx
    have hi:=mem_Icc.mp (hs hx)
    exact mem_Icc.mpr ⟨hi.1,by omega⟩
  have hpos : 16*X.card≤42*M+127 := by omega
  have hUlow : 42*M+112≤16*(X.card+U) := by dsimp [U]; omega
  have hUhigh : 16*(X.card+U)≤42*M+127 := by dsimp [U]; omega
  have hden : 5*K+160≤8*X.card+16 := by
    have hq : (0:ℝ)≤q := by positivity
    have hr : (5:ℝ)*K+160≤8*X.card+16 := by linarith
    exact_mod_cast hr
  have htri:=early_triangle M U X hM hsub (by omega) (by omega) (by omega) (by omega)
  have hUr : (16:ℝ)*(X.card+U)≤42*M+127 := by exact_mod_cast hUhigh
  have hMr : (2:ℝ)*M≤K+1 := by exact_mod_cast hKM.2
  refine ⟨U,htri,?_⟩
  push_cast at hUr
  linarith

#print axioms root_early_cutoff_real
end OP02.SharpK6

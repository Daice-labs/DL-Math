import K5GapResources
import K5BandArithmetic
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 200000

/-- Full actual common-neighbor independence inside the global gap. The even
and odd missing labels use distinct physical inventories with loads three and two. -/
theorem gap_neighborhood_independent (n r s y z:ℕ) (B:Finset ℕ)
    (hn:1024≤n) (hf:FiveFree B) (hd:DoublingFree B)
    (hq:128*totalBudget n B≤n)
    (hbudget:3*(canonicalHoles n B).card<n/32)
    (hdense:5*n+32*totalBudget n B+52<32*(quarterD n B).card)
    (hr:r∈quarterD n B) (hs:s∈quarterD n B) (hrs:r≠s)
    (hrsD:r+s∈quarterD n B) (hsmall:r+s≤n/16)
    (hy:y∈middle n B) (hz:z∈middle n B) (hyo:y%2=1) (hzo:z%2=1)
    (hyH:4*y≤7*n) (hzH:4*z≤7*n) (hyz:y≠z)
    (hyr:y+4*r∈B) (hys:y+4*s∈B) (hzr:z+4*r∈B) (hzs:z+4*s∈B) : y+z∉B := by
  classical
  intro hyzB
  let τ:=4*(missingTopOdd n B).card+4
  let W:=n-4*(n/16)
  let J:=(fourResources n B).card
  let h:=(Ho n B).card
  let A:=3*J+2*h
  let Y:=progression (2*n+2*τ) (2*n+2*τ+4*(A+1)) 4 0
  let T0:Finset ℕ:={0,4*r,4*s}
  let T1:Finset ℕ:={y,z}
  let S:Finset ℕ:={4*r,4*s,y,z}
  have hyB:=(mem_inter.mp hy).1
  have hzB:=(mem_inter.mp hz).1
  have hyI:=mem_Icc.mp (mem_inter.mp hy).2
  have hzI:=mem_Icc.mp (mem_inter.mp hz).2
  have hrB:=(mem_filter.mp hr).2
  have hsB:=(mem_filter.mp hs).2
  have hrI:=mem_Icc.mp (mem_filter.mp hr).1
  have hsI:=mem_Icc.mp (mem_filter.mp hs).1
  have hrsB:4*r+4*s∈B := by simpa only [Nat.mul_add] using (mem_filter.mp hrsD).2
  have hSc:S.card=4 := by
    have h1:4*r≠4*s := by omega
    have h2:4*r≠y := by omega
    have h3:4*r≠z := by omega
    have h4:4*s≠y := by omega
    have h5:4*s≠z := by omega
    simp [S,h1,h2,h3,h4,h5,hyz]
  have hSB:S⊆B := by
    intro x hx; simp only [S,mem_insert,mem_singleton] at hx
    rcases hx with rfl|rfl|rfl|rfl <;> assumption
  have hpairs:∀x∈S,∀w∈S,x≠w→x+w∈B := by
    intro x hx w hw hxw
    simp only [S,mem_insert,mem_singleton] at hx hw
    rcases hx with rfl|rfl|rfl|rfl <;> rcases hw with rfl|rfl|rfl|rfl <;>
      first | exact False.elim (hxw rfl) | assumption | simpa only [Nat.add_comm] using hyr | simpa only [Nat.add_comm] using hys | simpa only [Nat.add_comm] using hzr | simpa only [Nat.add_comm] using hzs | simpa only [Nat.add_comm] using hrsB | simpa only [Nat.add_comm] using hyzB
  have hjq:J+h≤totalBudget n B := four_resource_budget n B hd
  have hδ := deficit_split n B hd
  have hhiq:(missingTopOdd n B).card≤totalBudget n B := by unfold totalBudget; omega
  have hY (p:ℕ) (hp:p∈Y) :
      2*n+2*τ<p ∧ p≤2*n+20*totalBudget n B+16 ∧ p%4=0 ∧
      (∀a∈T0,p+a<4*W-2*τ) ∧ (∀a∈T1,p+a≤4*n) := by
    obtain ⟨hpI,hp4⟩ := mem_filter.mp hp
    have hpI:=mem_Ioc.mp hpI
    have hh:=gap_pivot_arithmetic n (totalBudget n B) (missingTopOdd n B).card J h r s p
      hn hq hhiq hjq hsmall hpI.2
    refine ⟨hpI.1,hh.1,hp4,?_,?_⟩
    · intro a ha
      simp only [T0,mem_insert,mem_singleton] at ha
      rcases ha with rfl|rfl|rfl
      · change p+0<4*(n-4*(n/16))-2*(4*(missingTopOdd n B).card+4)
        omega
      · exact hh.2.1
      · exact hh.2.2
    · intro a ha
      simp only [T1,mem_insert,mem_singleton] at ha
      rcases ha with rfl|rfl
      · exact gap_pivot_odd_upper n (totalBudget n B) p _ hn hq hh.1 hyH
      · exact gap_pivot_odd_upper n (totalBudget n B) p _ hn hq hh.1 hzH
  let Y0:=Y.filter (fun p=>∃a∈T0,p+a∈fourResources n B)
  let Y1:=Y.filter (fun p=>∃a∈T1,p+a∈Ho n B)
  have hcover:Y⊆Y0∪Y1 := by
    intro p hp
    have hpI:=hY p hp
    have hpS:p∉S := by
      intro hh
      simp only [S,mem_insert,mem_singleton] at hh
      rcases hh with rfl|rfl|rfl|rfl <;> omega
    obtain ⟨a,ha,hbad⟩ := four_clique_missing_label B S hf hSB hSc hpairs p hpS
    have haS:a∈T0 ∨ a∈T1 := by simpa only [T0,T1,S,mem_insert,mem_singleton,or_assoc] using ha
    rcases haS with ha0|ha1
    · apply mem_union_left
      refine mem_filter.mpr ⟨hp,a,ha0,?_⟩
      apply missing_in_doubled_gap n (p+a) B hf hd hbudget hdense ?_ hbad ?_ (hpI.2.2.2.1 a ha0)
      · simp only [T0,mem_insert,mem_singleton] at ha0
        rcases ha0 with rfl|rfl|rfl <;> omega
      · change 2*n+2*τ<p+a; omega
    · apply mem_union_right
      refine mem_filter.mpr ⟨hp,a,ha1,?_⟩
      apply odd_missing_upper n (p+a) B ⟨by omega,hpI.2.2.2.2 a ha1⟩ ?_ hbad
      simp only [T1,mem_insert,mem_singleton] at ha1
      rcases ha1 with rfl|rfl <;> omega
  have hc0:Y0.card≤3*J := by
    apply affine_cover_bound Y0 T0 (fourResources n B) 0 0 1 3 (by omega)
    · intro p hp; exact (hY p (mem_filter.mp hp).1).2.2.1
    · intro i
      exact le_trans (card_le_card (filter_subset _ _)) (show T0.card≤3 from card_le_three)
    · intro p hp
      obtain ⟨hpY,a,ha,hres⟩:=mem_filter.mp hp
      exact ⟨a,ha,p+a,hres,by omega⟩
  have hc1:Y1.card≤2*h := by
    apply affine_cover_bound Y1 T1 (Ho n B) 0 0 1 2 (by omega)
    · intro p hp; exact (hY p (mem_filter.mp hp).1).2.2.1
    · intro i
      exact le_trans (card_le_card (filter_subset _ _)) (show T1.card≤2 from card_le_two)
    · intro p hp
      obtain ⟨hpY,a,ha,hres⟩:=mem_filter.mp hp
      exact ⟨a,ha,p+a,hres,by omega⟩
  have hu:=le_trans (card_le_card hcover) (card_union_le Y0 Y1)
  have hl:=progression_lower (2*n+2*τ) (2*n+2*τ+4*(A+1)) 4 0 (by omega) (by omega)
  change (2*n+2*τ+4*(A+1)-(2*n+2*τ))/4≤Y.card at hl
  dsimp only [A] at hl
  omega

#print axioms gap_neighborhood_independent
end OP02.SharpK5

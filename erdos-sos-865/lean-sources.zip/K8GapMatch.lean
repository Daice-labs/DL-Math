import K8MatchedSum
import K8FixedFourGapSpec
import K8Shell

open Finset OP02.FewHole OP02.SharpK5
namespace OP02.SharpK8
set_option maxHeartbeats 2200000

def gapLength (H : ℕ) := 27*H/1024
def gapStarts (H a b : ℕ) :=
  progression (gapLo H a) (gapLo H a+gapLength H) 4 (gapResidue a b)

structure GapMember (H : ℕ) (D : Finset ℕ) (A C z g : ℕ) : Prop where
  low : H/4<4*g
  upper : 1024*g≤111*H
  odd : g%2=1
  mem : g∈D
  contactA : g+A∈D
  contactC : g+C∈D
  contactZ : z+g∈D

private theorem gap_ranges {H a b g x : ℕ} (large : 1000000≤H) (small : 128*a<5*H)
    (hg : g∈gapStarts H a b) (off : 64*x≤H) (mult : x%4=0) :
    H/4<4*g ∧ 1024*g≤111*H ∧ g+x∈gapTrials H a b := by
  obtain ⟨gi,gr⟩ := mem_filter.mp hg
  obtain ⟨gl,gu⟩ := mem_Ioc.mp gi
  change g%4=gapResidue a b at gr
  dsimp only [gapLo,gapLength] at gl gu
  refine ⟨by omega,by omega,mem_filter.mpr ⟨mem_Ioc.mpr ⟨?_,?_⟩,by omega⟩⟩
  · dsimp only [gapLo];omega
  · dsimp only [gapHi,gapYHi];omega

/-- A single pair from the two gap intervals survives all translations and its own sum test.
Use z=0 for a deferred fifth vertex. -/
theorem select_gap_pair {H a b A C z : ℕ} {D : Finset ℕ}
    (large : 1000000≤H) (sub : D⊆Icc 1 H) (hd : DoublingFree D)
    (budget : 1536*(chainCapacity H-D.card)<H)
    (sa : 128*a<5*H) (sb : 128*b<5*H) (same : a%2=b%2) (diff : a%4≠b%4)
    (miss : (missingGap H D a b).card+(missingGap H D b a).card≤3*(chainCapacity H-D.card))
    (a0 : A%4=0) (c0 : C%4=0) (ab : 64*A≤H) (cb : 64*C≤H)
    (zok : z=0 ∨ (H/4<2*z ∧ z+(111*H+1023)/1024 ≤ H/4 ∧ z%4=0)) :
    ∃g₁ g₂, GapMember H D A C z g₁ ∧ GapMember H D A C z g₂ ∧
      g₁%4=gapResidue a b ∧ g₂%4=gapResidue b a ∧ (g₁+g₂)%8=4 ∧ g₁+g₂∈D := by
  classical
  let κ := chainCapacity H-D.card
  let L := gapLength H
  let M := L/8+1
  let P := gapStarts H a b
  let V := gapStarts H b a
  let I := missingGap H D a b ∪ missingGap H D b a
  let W : Finset ℕ := {0,A,C}
  let X := rejected (P∪V) W I (fun x g=>g+x)
  let Top := topMissing (H/4) D
  let Y := (P∪V).filter (fun g=>z+g∈Top)
  let Bad := X∪Y
  let U₁ := P\Bad
  let U₂ := V\Bad
  have rr := gap_residue_rules same diff
  have ss := gap_residue_rules same.symm diff.symm
  have pc (g:ℕ) (h:g∈P) : g%4=gapResidue a b := (mem_filter.mp h).2
  have vc (g:ℕ) (h:g∈V) : g%4=gapResidue b a := (mem_filter.mp h).2
  have di : Disjoint P V := by
    apply disjoint_left.mpr; intro g hp hv;have := pc g hp;have := vc g hv;omega
  have pp : L/4≤ P.card := by
    have k := progression_lower (gapLo H a) (gapLo H a+L) 4 (gapResidue a b) (Or.inl rfl) rr.1
    simpa only [P,V,gapStarts,L,Nat.add_sub_cancel_left] using k
  have vv : L/4≤ V.card := by
    have k := progression_lower (gapLo H b) (gapLo H b+L) 4 (gapResidue b a) (Or.inl rfl) ss.1
    simpa only [P,V,gapStarts,L,Nat.add_sub_cancel_left] using k
  have wc : W.card≤3 := by
    have t := card_insert_le 0 ({A,C}:Finset ℕ); have k := card_insert_le A ({C}:Finset ℕ)
    simp only [card_singleton] at k;dsimp only [W];omega
  have badX : X.card≤9*κ := by
    have cardI := (card_union_le (missingGap H D a b) (missingGap H D b a)).trans miss
    have x := rejected_card (P∪V) W I (fun k g=>g+k) (fun k _ g _ i _ eq=>by dsimp at eq;omega)
    exact (x.trans (Nat.mul_le_mul wc cardI)).trans (by omega)
  have top : Top.card≤κ := by simpa [Top,κ] using band_canonical_holes_le H 1 D sub hd
  have badY : Y.card≤κ := by
    apply le_trans _ top
    apply card_le_card_of_injOn (fun g=>z+g) (fun g hg=>(mem_filter.mp hg).2)
    intro g hg i hi eq;dsimp at eq; omega
  have bad := card_union_le X Y
  have count := card_sdiff_add_card_inter (P∪V) Bad
  have atmost := card_le_card (inter_subset_right (s₁:=P∪V) (s₂:=Bad))
  have eq : (P∪V)\Bad=U₁∪U₂ := by ext g;simp only [U₁,U₂,mem_sdiff,mem_union];tauto
  have sep : Disjoint U₁ U₂ := di.mono sdiff_subset sdiff_subset
  rw [eq,card_union_of_disjoint sep,card_union_of_disjoint di] at count
  have numeric (h k : ℕ) (big : 1000000≤h) (cap : 1536*k<h) :
      10*k+2*(27*h/1024/8+1)<2*(27*h/1024/4) ∧ k<27*h/1024/8+1 := by
    clear * - big cap
    omega
  have num : 10*κ+2*M < 2*(L/4) ∧ κ<M := numeric H κ large budget
  have badcost : Bad.card≤10*κ := by change (X∪Y).card≤_;omega
  have enough : 2*M<U₁.card+U₂.card := by
    clear * - num pp vv count atmost badcost
    omega
  have sub8 {A₁ i j : ℕ} {U : Finset ℕ} (ht : U⊆gapStarts H A₁ j) (hi : i<8) :
      (eightCell U i).card≤M := by
    have covered : eightCell U i ⊆ progression (gapLo H A₁) (gapLo H A₁+L) 8 i := by
      intro x hx;obtain ⟨xU,res⟩ := mem_filter.mp hx
      exact mem_filter.mpr ⟨(mem_filter.mp (ht xU)).1,res⟩
    have hh := (card_le_card covered).trans (progression_upper _ _ _ _ (Or.inr (Or.inl rfl)) hi)
    simpa only [Nat.add_sub_cancel_left] using hh
  obtain ⟨g,hg,g',hg',res,nobad⟩ := matching_good_sum rr.1 ss.1 rr.2.2
    (fun x hx=>pc x (mem_sdiff.mp hx).1) (fun x hx=>vc x (mem_sdiff.mp hx).1)
    (fun _ hi => sub8 (U:=U₁) (A₁:=a) (j:=b) sdiff_subset hi)
    (fun _ hi => sub8 (U:=U₂) (A₁:=b) (j:=a) sdiff_subset hi) enough (top.trans_lt num.2)
  have qualifications {x : ℕ} (hpool : x∈P∪V) (k : x∉Bad) :
      GapMember H D A C z x := by
    have q : ∀ e∈W, x+e∈D := by
      intro e he
      have off : 64*e≤H ∧ e%4=0 := by
        simp only [W,mem_insert,mem_singleton] at he
        rcases he with rfl|rfl|rfl <;> omega
      by_contra nmem
      have idx : x+e ∈ I := by
        rcases mem_union.mp hpool with h|h
        · exact mem_union_left _ (mem_filter.mpr ⟨(gap_ranges large sa h off.1 off.2).2.2,nmem⟩)
        · exact mem_union_right _ (mem_filter.mpr ⟨(gap_ranges large sb h off.1 off.2).2.2,nmem⟩)
      exact k (mem_union_left _ (mem_rejected.mpr ⟨e,he,hpool,idx⟩))
    have xm : x∈D := by simpa using q 0 (by simp [W])
    have rg : H/4<4*x ∧ 1024*x≤111*H ∧ x%2=1 := by
      rcases mem_union.mp hpool with h|h
      · have key := gap_ranges (x:=0) large sa h (by omega) (by decide)
        have pmod := pc x h;exact ⟨key.1,key.2.1,by omega⟩
      · have key := gap_ranges (x:=0) large sb h (by omega) (by decide)
        have pmod := vc x h;exact ⟨key.1,key.2.1,by omega⟩
    refine ⟨rg.1,rg.2.1,rg.2.2,xm,by simpa only [Nat.add_comm] using q A (by simp [W]),
      by simpa only [Nat.add_comm] using q C (by simp [W]),?_⟩
    rcases zok with hz|⟨zlow,zhigh,zeven⟩
    · simpa [hz] using xm
    · by_contra missZ
      have inTop : z+x∈Top := mem_filter.mpr ⟨mem_filter.mpr
        ⟨mem_Icc.mpr ⟨by omega,by omega⟩,canonical_odd _ (by omega)⟩,by omega,missZ⟩
      exact k (mem_union_right _ (mem_filter.mpr ⟨hpool,inTop⟩))
  have g1 := qualifications (mem_union_left _ (mem_sdiff.mp hg).1) (mem_sdiff.mp hg).2
  have g2 := qualifications (mem_union_right _ (mem_sdiff.mp hg').1) (mem_sdiff.mp hg').2
  refine ⟨g,g',g1,g2,pc g (mem_sdiff.mp hg).1,vc g' (mem_sdiff.mp hg').1,res,?_⟩
  by_contra ng
  have lo:=g1.low;have lo':=g2.low;have up:=g1.upper;have up':=g2.upper
  exact nobad (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,
    canonical_four_residue _ res⟩,by omega,ng⟩)

end OP02.SharpK8

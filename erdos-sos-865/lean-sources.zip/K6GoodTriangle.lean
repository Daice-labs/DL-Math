import K6TriangleResidues
import K6Affine8
import K6Progression128
import K6ExplicitTriangle
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess
set_option maxHeartbeats 6000000

/-- The actual six physical maps share one canonical-hole budget. -/
theorem canonical_clique_cover (n m r c:ℕ) (B S:Finset ℕ)
    (hf:SixFree B) (hs:S⊆lower n B) (hsc:S.card=5)
    (hpairs:∀x∈S,∀y∈S,x≠y→x+y∈B)
    (hm:m=8 ∨ m=128) (hr : r < m)
    (hload:∀j:ℕ,((insert 0 S).filter (fun s=>s%8=j)).card≤c)
    (hcan:∀p∈progression (2*n) (3*n) m r,∀s∈insert 0 S,canonical (p+s)=true) :
    n/m≤c*(canonicalHoles n B).card := by
  classical
  let Y:=progression (2*n) (3*n) m r
  have hbound (s:ℕ) (h: s∈S):s≤n := (mem_Icc.mp (mem_inter.mp (hs h)).2).2
  have hcover:∀p∈Y,∃s∈insert 0 S,∃h∈canonicalHoles n B,1*p+s=h+0 := by
    intro p hp
    obtain ⟨hpI,hpr⟩:=mem_filter.mp hp
    obtain ⟨hpL,hpU⟩:=mem_Ioc.mp hpI
    have hpS:p∉S := by intro hh; have:=hbound p hh; omega
    obtain ⟨s,hsS,hbad⟩:=five_clique_missing_label B S hf
      (fun x hx=>(mem_inter.mp (hs hx)).1) hsc hpairs p hpS
    refine ⟨s,hsS,p+s,mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,?_⟩,hbad⟩,hcan p hp s hsS⟩,by omega⟩
    rcases mem_insert.mp hsS with rfl|hsS
    · omega
    · have:=hbound s hsS; omega
  have hmod:∀p∈Y,p%8=r%8 := by
    intro p hp
    have:= (mem_filter.mp hp).2
    rcases hm with rfl|rfl <;> omega
  have hc:=affine_cover_bound8 Y (insert 0 S) (canonicalHoles n B) 0 (r%8) 1 c (by omega) hmod hload hcover
  have hl:n/m≤Y.card := by
    rcases hm with rfl|rfl
    · have:=progression_lower (2*n) (3*n) 8 r (by simp) hr
      simpa only [show 3*n-2*n=n by omega] using this
    · have:=progression128_lower (2*n) (3*n) 128 r rfl hr
      simpa only [show 3*n-2*n=n by omega] using this
  exact le_trans hl hc

/-- A good root triangle cannot coexist with the actual qualified odd edge
when the canonical-hole margin is strict. Labels live in ambient D. -/
theorem good_triangle_excluded (n u v:ℕ) (B T:Finset ℕ)
    (hf:SixFree B) (hu:u∈lower n B) (hv:v∈lower n B)
    (huv:u≠v) (huo:u%2=1) (hvo:v%2=1) (hsum:u+v∈B)
    (hT:T⊆quarterD n B) (hTc:T.card=3)
    (hpair:∀x∈T,∀y∈T,x≠y→x+y∈quarterD n B)
    (hqual:∀x∈T,u+4*x∈B ∧ v+4*x∈B)
    (hgood:∃j<4,∀s∈insert 0 T,s%4≠j)
    (hbudget:3*(canonicalHoles n B).card<n/128) : False := by
  classical
  let S:=insert u (insert v (T.image (fun x=>4*x)))
  have hcl:=qualified_triangle_explicit_clique n u v B T
    (mem_inter.mp hu).1 (mem_inter.mp hv).1 huv huo hvo hsum hT hTc hpair hqual
  change S⊆B ∧ S.card=5 ∧ _ at hcl
  have hSl:S⊆lower n B := by
    intro x hx
    refine mem_inter.mpr ⟨hcl.1 hx,?_⟩
    rcases mem_insert.mp hx with rfl|hx
    · exact (mem_inter.mp hu).2
    · rcases mem_insert.mp hx with rfl|hx
      · exact (mem_inter.mp hv).2
      · obtain ⟨r,hr,rfl⟩:=mem_image.mp hx
        obtain ⟨hr1,hrH⟩:=mem_Icc.mp (mem_filter.mp (hT hr)).1
        exact mem_Icc.mpr ⟨by omega,by omega⟩
  have hz:0∉T := by intro h; have:=(mem_Icc.mp (mem_filter.mp (hT h)).1).1; omega
  let Q:=insert 0 T
  have hQc:Q.card=4 := by simp [Q,hz,hTc]
  have hmem (s:ℕ) (hs:s∈insert 0 S): s=u ∨ s=v ∨ ∃t∈Q,s=4*t := by
    rcases mem_insert.mp hs with rfl|hs
    · exact Or.inr (Or.inr ⟨0,by simp [Q],by omega⟩)
    · rcases mem_insert.mp hs with rfl|hs
      · exact Or.inl rfl
      · rcases mem_insert.mp hs with rfl|hs
        · exact Or.inr (Or.inl rfl)
        · obtain ⟨t,ht,rfl⟩:=mem_image.mp hs
          exact Or.inr (Or.inr ⟨t,mem_insert_of_mem ht,rfl⟩)
  have hload4:∀j:ℕ,((insert 0 S).filter (fun s=>s%8=j)).card≤4 := by
    intro j
    by_cases hj:j%2=0
    · have hsub:((insert 0 S).filter (fun s=>s%8=j))⊆Q.image (fun x=>4*x) := by
        intro s hs
        obtain ⟨hs,hjr⟩:=mem_filter.mp hs
        rcases hmem s hs with rfl|rfl|⟨t,ht,rfl⟩
        · omega
        · omega
        · exact mem_image.mpr ⟨t,ht,rfl⟩
      exact le_trans (card_le_card hsub) (le_trans card_image_le (by omega))
    · have hsub:((insert 0 S).filter (fun s=>s%8=j))⊆{u,v} := by
        intro s hs
        obtain ⟨hs,hjr⟩:=mem_filter.mp hs
        rcases hmem s hs with rfl|rfl|⟨t,ht,rfl⟩
        · simp
        · simp
        · omega
      exact le_trans (card_le_card hsub) (le_trans card_le_two (by omega))
  by_cases he:∀t∈Q,t%2=0
  · have hcan:∀p∈progression (2*n) (3*n) 8 4,∀s∈insert 0 S,canonical (p+s)=true := by
      intro p hp s hs
      have hpR:=(mem_filter.mp hp).2
      rcases hmem s hs with rfl|rfl|⟨t,ht,rfl⟩
      · exact canonical_odd _ (by omega)
      · exact canonical_odd _ (by omega)
      · have:=he t ht
        exact canonical_four_residue _ (by omega)
    have:=canonical_clique_cover n 8 4 4 B S hf hSl hcl.2.1 hcl.2.2 (by simp) (by omega) hload4 hcan
    omega
  · push_neg at he
    obtain ⟨t,ht,hto⟩:=he
    have hload3:∀j:ℕ,((insert 0 S).filter (fun s=>s%8=j)).card≤3 := by
      intro j
      by_cases hj:j%2=0
      · let V:=Q.filter (fun x=>(4*x)%8=j)
        have hsub:((insert 0 S).filter (fun s=>s%8=j))⊆V.image (fun x=>4*x) := by
          intro s hs
          obtain ⟨hs,hjr⟩:=mem_filter.mp hs
          rcases hmem s hs with rfl|rfl|⟨r,hr,rfl⟩
          · omega
          · omega
          · exact mem_image.mpr ⟨r,mem_filter.mpr ⟨hr,hjr⟩,rfl⟩
        have hVc:V.card≤3 := by
          by_cases hj0:j=0
          · have hsub:V⊆Q.erase t := by
              intro x hx
              obtain ⟨hx,hxr⟩:=mem_filter.mp hx
              exact mem_erase.mpr ⟨by intro h; subst x; omega,hx⟩
            have:=card_le_card hsub
            rw [card_erase_of_mem ht,hQc] at this
            exact this
          · have hsub:V⊆Q.erase 0 := by
              intro x hx
              obtain ⟨hx,hxr⟩:=mem_filter.mp hx
              exact mem_erase.mpr ⟨by intro h; subst x; omega,hx⟩
            have:=card_le_card hsub
            rw [card_erase_of_mem (show 0∈Q by simp [Q]),hQc] at this
            exact this
        exact le_trans (card_le_card hsub) (le_trans card_image_le hVc)
      · have hsub:((insert 0 S).filter (fun s=>s%8=j))⊆{u,v} := by
          intro s hs
          obtain ⟨hs,hjr⟩:=mem_filter.mp hs
          rcases hmem s hs with rfl|rfl|⟨r,hr,rfl⟩
          · simp
          · simp
          · omega
        exact le_trans (card_le_card hsub) (le_trans card_le_two (by omega))
    obtain ⟨b,hb,havoid,hbe⟩:=triangle_profile_pivot T hTc hz hgood
    obtain ⟨r,hr,hrb,hcanr⟩:=canonical_profile_class Q b hb havoid hbe
    have hcan:∀p∈progression (2*n) (3*n) 128 (4*r),∀s∈insert 0 S,canonical (p+s)=true := by
      intro p hp s hs
      have hpR:=(mem_filter.mp hp).2
      rcases hmem s hs with rfl|rfl|⟨t,ht,rfl⟩
      · exact canonical_odd _ (by omega)
      · exact canonical_odd _ (by omega)
      · have hc:=hcanr (p/4) (by omega) t ht
        have hh:p+4*t=4*(p/4+t) := by omega
        rw [hh,canonical_four]
        exact hc
    have:=canonical_clique_cover n 128 (4*r) 3 B S hf hSl hcl.2.1 hcl.2.2 (by simp) (by omega) hload3 hcan
    omega

#print axioms canonical_clique_cover
#print axioms good_triangle_excluded
end OP02.SharpK6

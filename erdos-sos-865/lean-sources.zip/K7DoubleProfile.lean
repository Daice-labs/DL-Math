import K7TwoRootSelection
import K7CompleteO2
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7.LongOddTask

structure DoubleProfile (S:Finset ℕ) (s H:ℕ) where
  p : ℕ
  x : ℕ
  x' : ℕ
  f : ℕ
  E : Finset ℕ
  ph : 2*p≤H
  ps : p≤ s
  xx : x≤x'
  xs : x'≤ s
  par : p%2=x%2
  opp : p%4≠x%4
  same : x%4=x'%4
  num : E.card≤4
  ev : ∀v∈E,v%2≠p%2 ∧ v≤ s
  allOffsets : ∀v∈insert 0 S,v=p ∨ v=x ∨ v=x' ∨ v∈E
  fH : f≤H
  fo : f%2≠p%2
  special : ∀v∈insert 0 S,v%2=f%2→v≠f→v%4≠f%4

/-- One of the actual shifted roots qualifies simultaneously with its mate.
Failure of the doubled half would give a six with an original singleton pivot. -/
theorem double_profile_impossible (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃U:ℕ,∀n:ℕ,U≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ)→
    ∀S:Finset ℕ,InternalFive (B∩Icc 1 (n/4)) S→∀s:ℕ,s≤n/4→(∀v∈S,v≤ s)→DoubleProfile S s (n/4)→False:=by
  classical
  obtain ⟨U,hU⟩:=inventory_uniform β hb
  obtain ⟨V,hV⟩:=uniform_window_threshold β hb
  obtain ⟨W,hW⟩:=middle_gap7 hD β hb
  obtain ⟨G,hG⟩:=padded_inventory hb
  obtain ⟨A,hA⟩:=uniform_favorable_band hD hb
  refine ⟨max A (max U (max V (max W G))),?_⟩
  intro n hn B hf hd hg S hs s sh bounds D
  obtain ⟨cap,large⟩:=hU n (by omega) B hd hg
  obtain ⟨_,hl⟩:=hV n (by omega)
  have gap:=hW n (by omega) B hf hd hg
  have pad:=hG n (by omega) B hd hg
  obtain ⟨a,c,b,z,ap,ac,cb,bz,bd,zl,zu,rzH,ra,rc,rb,rz,rac,rba,rbc,rza,rzc,rzb⟩:=raised_actual_quartet hd hg hl pad
  have uc:z≤43*(n/4)/320+26*chainDeficit n B+16*logLevels (n/4)+256:=by
    have :=actual_quarter_top_joint n B hd;omega
  obtain ⟨y,w,yl,yu,yo,wl,wu,wp,we,w₁,w₂,slot,slotHi,direct,high⟩:=
    two_root_select hd sh D.ph D.ps D.xx D.xs D.par D.opp D.same ac cb bd zl uc pad D.num D.ev
  have old:internalOn B S:=⟨fun _ h=>(mem_inter.mp (hs.2.1 h)).1,
    fun u hu v hv ne=>(mem_inter.mp (hs.2.2 u hu v hv ne)).1⟩
  have wS:w∉S:=fun hi=>by have :=bounds w hi;omega
  have bad:2*(y+4*z)∉B:=by
    intro double
    have all (v:ℕ) (hv:v∈insert 0 S):w+v∈B:=by
      rcases D.allOffsets v hv with hp|hx|hx'|oth
      · rwa [hp,we]
      · rwa [hx]
      · rwa [hx']
      · exact high _ oth
    have present:w∈B:=by simpa using all 0 (mem_insert_self _ _)
    have six:=append_clique old present (fun v hv=>all v (mem_insert_of_mem hv))
    have sz:(insert w S).card=6:=by simp [card_insert_of_notMem wS,hs.1]
    have bound6:∀v∈insert w S,v≤n:=by
      intro v hv;rcases mem_insert.mp hv with rfl|small
      · omega
      · have :=bounds v small;omega
    apply hA n (by omega) B hf hd hg _ six sz bound6 D.f (by have :=D.fH;omega)
    intro v hv vp vn
    have oldmem:v∈insert 0 S:=by
      rcases mem_insert.mp hv with rfl|rest
      · exact mem_insert_self _ _
      · rcases mem_insert.mp rest with rfl|vS
        · exact (D.fo (vp.symm.trans wp)).elim
        · exact mem_insert_of_mem vS
    refine ⟨D.special _ oldmem vp vn,?_⟩
    rcases mem_insert.mp oldmem with rfl|vs
    · exact Nat.zero_le _
    · exact (bounds v vs).trans sh
  have yes:y+4*z∈B:=by
    by_contra absent
    exact slot (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,slotHi,absent,bad⟩)
  apply selected_common_half_impossible hf hd gap large cap ac cb bz (cutoff_z rzH) yu yo
    ra rc rb rz rac rba rbc rza rzc rzb (by simpa using direct 0 (by simp))
  intro v hv;simp only [mem_insert,mem_singleton] at hv
  rcases hv with rfl|rfl|rfl|rfl <;> first | exact yes | exact direct _ (by simp)

end OP02.SharpK7.LongOddTask

import K5ResidueSelection
import K5AffineCover
open Finset
namespace OP02.SharpK5
set_option maxHeartbeats 8000000

/-- A missing residue yields a pivot class avoiding valuation one, with at most
three even labels. Repeated offset residues retain their full multiplicities. -/
theorem profile_pivot (S:Finset ℕ) (hc:S.card=4) (hz:0∉S)
    (hm:∃j<4,∀s∈insert 0 S,s%4≠j) :
    ∃b<4,(∀s∈insert 0 S,(b+s)%4≠2) ∧
      ((insert 0 S).filter (fun s=>(b+s)%2=0)).card≤3 := by
  classical
  obtain ⟨a,b,c,d,hab,hac,had,hbc,hbd,hcd,hS⟩ := card_eq_four.mp hc
  obtain ⟨j,hj,hmiss⟩ := hm
  have hj0:j≠0 := by have := hmiss 0 (by simp); omega
  have ha:a∈S := by simp [hS]
  have hb:b∈S := by simp [hS]
  have hc:c∈S := by simp [hS]
  have hd:d∈S := by simp [hS]
  have hma:=hmiss a (mem_insert_of_mem ha)
  have hmb:=hmiss b (mem_insert_of_mem hb)
  have hmc:=hmiss c (mem_insert_of_mem hc)
  have hmd:=hmiss d (mem_insert_of_mem hd)
  obtain ⟨p,hp0,hpa,hpb,hpc,hpd,hcount⟩ := missing_residue_pivot
    ⟨a%4,by omega⟩ ⟨b%4,by omega⟩ ⟨c%4,by omega⟩ ⟨d%4,by omega⟩
    ⟨⟨j,hj⟩,hj0,by intro he; have := congrArg Fin.val he; exact hma this,
      by intro he; have := congrArg Fin.val he; exact hmb this,
      by intro he; have := congrArg Fin.val he; exact hmc this,
      by intro he; have := congrArg Fin.val he; exact hmd this⟩
  dsimp only at hpa hpb hpc hpd hcount
  refine ⟨p.val,p.isLt,?_,?_⟩
  · intro s hs
    simp only [hS,mem_insert,mem_singleton] at hs
    rcases hs with rfl|rfl|rfl|rfl|rfl <;> omega
  · have ha0:0≠a := by intro he; exact hz (he ▸ ha)
    have hb0:0≠b := by intro he; exact hz (he ▸ hb)
    have hc0:0≠c := by intro he; exact hz (he ▸ hc)
    have hd0:0≠d := by intro he; exact hz (he ▸ hd)
    have he : ((insert 0 S).filter (fun s=>(p.val+s)%2=0)).card=
        (if p.val%2=0 then 1 else 0)+(if (p.val+a)%2=0 then 1 else 0)+
        (if (p.val+b)%2=0 then 1 else 0)+(if (p.val+c)%2=0 then 1 else 0)+
        (if (p.val+d)%2=0 then 1 else 0) := by
      rw [card_eq_sum_ones,sum_filter]
      simp only [hS,sum_insert,mem_insert,mem_singleton,ha0,hb0,hc0,hd0,hab,hac,had,hbc,hbd,hcd,
        false_or,not_false_eq_true,sum_singleton,Nat.add_zero,Nat.add_assoc]
    rw [he]
    have hma:(p.val+a)%2=(p.val+a%4)%2 := by omega
    have hmb:(p.val+b)%2=(p.val+b%4)%2 := by omega
    have hmc:(p.val+c)%2=(p.val+c%4)%2 := by omega
    have hmd:(p.val+d)%2=(p.val+d%4)%2 := by omega
    simpa only [hma,hmb,hmc,hmd] using hcount

/-- A fixed pivot residue sees no more than the larger parity population of
the actual offset set. This is a physical fibre bound. -/
theorem profile_load (T:Finset ℕ) (b c:ℕ)
    (he:(T.filter (fun s=>(b+s)%2=0)).card≤c)
    (ho:(T.filter (fun s=>(b+s)%2=1)).card≤c) :
    ∀r:ℕ,(T.filter (fun s=>s%4=r)).card≤c := by
  intro r
  by_cases hr:(b+r)%2=0
  · apply le_trans (card_le_card ?_) he
    intro s hs
    obtain ⟨hsT,hsr⟩ := mem_filter.mp hs
    exact mem_filter.mpr ⟨hsT,by omega⟩
  · apply le_trans (card_le_card ?_) ho
    intro s hs
    obtain ⟨hsT,hsr⟩ := mem_filter.mp hs
    exact mem_filter.mpr ⟨hsT,by omega⟩

/-- At most three even offsets can all be made canonical in one modulo-32
pivot class. No claim of periodicity of the avoiding set is made. -/
theorem canonical_profile_class (T:Finset ℕ) (b:ℕ) (hb:b<4)
    (havoid:∀s∈T,(b+s)%4≠2)
    (he:(T.filter (fun s=>(b+s)%2=0)).card≤3) :
    ∃v<32,v%4=b ∧ ∀p:ℕ,p%32=v→∀s∈T,canonical (p+s)=true := by
  classical
  let E:=T.filter (fun s=>(b+s)%2=0)
  let F:E→Fin 8 := fun s=>⟨((b+s.val)/4)%8,by omega⟩
  let Q:Finset (Fin 8):=E.attach.image F
  have hQ:Q.card≤3 := by
    have := card_image_le (s:=E.attach) (f:=F)
    rw [card_attach] at this
    exact le_trans this he
  obtain ⟨r,hr⟩ := three_residue_set_selection Q hQ
  refine ⟨b+4*r.val,by have := r.isLt; omega,by omega,?_⟩
  intro p hp s hs
  by_cases hsE:s∈E
  · have hseven:=(mem_filter.mp hsE).2
    have hsavoid:=havoid s hs
    have hsel:=hr (F ⟨s,hsE⟩) (mem_image.mpr ⟨⟨s,hsE⟩,mem_attach _ _,rfl⟩)
    have heq:((p+s)/4)%8=(r.val+((b+s)/4)%8)%8 := by omega
    apply canonical_selected (p+s) 0 (by omega)
    rw [heq]
    exact hsel
  · have hodd:(b+s)%2=1 := by
      have hh:¬(b+s)%2=0 := by intro hh; exact hsE (mem_filter.mpr ⟨hs,hh⟩)
      omega
    exact canonical_odd (p+s) (by omega)

#print axioms profile_pivot
#print axioms profile_load
#print axioms canonical_profile_class
end OP02.SharpK5

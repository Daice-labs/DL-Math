import K8Spec

open Finset Filter
namespace OP02.SharpK8

theorem deletion (hD : Dousse8) (δ : ℝ) (hδ : 0 < δ) :
      ∃ N0 : ℕ, 1 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N →
        ∀ A : Finset ℕ, A ⊆ Finset.Icc 1 N →
          EightFree A →
          ∃ B : Finset ℕ, B ⊆ Finset.Icc 1 N ∧
            EightFree B ∧
            OP02.FewHole.DoublingFree B ∧
            (A.card : ℝ) ≤ (B.card : ℝ) + δ * (N : ℝ) := by
    classical
    obtain ⟨N0, hN0, hD0⟩ := hD δ hδ
    refine ⟨N0, hN0, ?_⟩
    intro N hN A hsub hfour
    let T : Finset ℕ := A.filter (fun x => 2 * x ∈ A)
    have hTA : T ⊆ A := by
      intro x hx
      exact (Finset.mem_filter.mp hx).1
    have hTI : T ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hTA hx)
    have ht : (T.card : ℝ) < δ * (N : ℝ) := by
      by_contra hn
      have hd : δ * (N : ℝ) ≤ (T.card : ℝ) := le_of_not_gt hn
      obtain ⟨S, hST, hSc, hm⟩ := hD0 N hN T hTI hd
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hTA (hST hx)
      · intro x hx y hy hxy
        obtain ⟨z, hz, hzxy⟩ := hm x hx y hy hxy
        rw [hzxy]
        exact (Finset.mem_filter.mp hz).2
    let B : Finset ℕ := A \ T
    have hBA : B ⊆ A := by
      intro x hx
      exact (Finset.mem_sdiff.mp hx).1
    have hBI : B ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hBA hx)
    have hfB : EightFree B := by
      rintro ⟨S, hSB, hSc, hpair⟩
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hBA (hSB hx)
      · intro x hx y hy hxy
        exact hBA (hpair x hx y hy hxy)
    have hdB : OP02.FewHole.DoublingFree B := by
      intro x hx h2
      obtain ⟨hxA, hxT⟩ := Finset.mem_sdiff.mp hx
      apply hxT
      exact Finset.mem_filter.mpr ⟨hxA, hBA h2⟩
    have hcard : B.card + T.card = A.card :=
      Finset.card_sdiff_add_card_eq_card hTA
    have hcardR : (B.card : ℝ) + (T.card : ℝ) = (A.card : ℝ) := by
      exact_mod_cast hcard
    refine ⟨B, hBI, hfB, hdB, ?_⟩
    linarith only [hcardR, ht]

end OP02.SharpK8

import PositiveWindow
open Finset
namespace OP02.PositivePivot
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess

theorem positive_capacity_endpoints {n A m x p C:ℕ} {B:Finset ℕ}
    (hf:FourFree B)
    (hAo:A%2=1) (hAn:n<A) (hAl:A+2*(m-1)≤2*n)
    (hlarge:C+2*((parityMiddle n B 0).card+(H0 n B).card+2*(Ho n B).card+4*(gaps n A m B).card)+4<2*m) (hCe:C%2=0)
    (hxB:x∈B) (hxn:x≤n) (hx4:x%4=0) (hxp:0<x)
    (hpB:p∈B) (hpxB:p+x∈B) (hpn:2*n<p) (hp4:p%4=0) (hpu:p≤2*n+C) :
    2*m≤x+2*((parityMiddle n B 0).card+(H0 n B).card+2*(Ho n B).card+4*(gaps n A m B).card)+4 ∧
    x+(A+2*(m-1))≤2*n+2*((parityMiddle n B 0).card+(H0 n B).card+2*(Ho n B).card+4*(gaps n A m B).card)+C+2 := by
  let k:=((parityMiddle n B 0).card+(H0 n B).card+2*(Ho n B).card+4*(gaps n A m B).card)
  let Bad:=badWindow n A m x p B
  have hbad:Bad.card≤k:=badWindow_card n A m x p B
  let Z:=A+2*(m-1)
  have hm:0 < m:=by omega
  have hf_inj:Set.InjOn (fun i:ℕ=>A+2*i) (range (Bad.card+1)) := by
    intro i hi j hj hij
    dsimp at hij
    omega
  obtain ⟨i,hi,hnot⟩:=avoid_card Bad (fun i=>A+2*i) hf_inj
  have hi':i≤k:=by have := mem_range.mp hi;omega
  have hfirst:=positive_usable_window hf hm hAo hAn hAl hxB hxn hx4 hxp hpB hpxB hpn hp4
    (z:=A+2*i) (by omega) (by omega) (by omega) (by omega) hnot
  have hl_inj:Set.InjOn (fun j:ℕ=>Z-C-2-2*j) (range (Bad.card+1)) := by
    intro i hi j hj hij
    have hi':=mem_range.mp hi
    have hj':=mem_range.mp hj
    dsimp [Z,k] at *
    omega
  obtain ⟨j,hj,hnot'⟩:=avoid_card Bad (fun j=>Z-C-2-2*j) hl_inj
  have hj':j≤k:=by have := mem_range.mp hj;omega
  have hlast:=positive_usable_window hf hm hAo hAn hAl hxB hxn hx4 hxp hpB hpxB hpn hp4
    (z:=Z-C-2-2*j) (by dsimp [Z];omega) (by dsimp [Z];omega)
    (by dsimp [Z];omega) (by dsimp [Z];omega) hnot'
  dsimp [Z,k] at *
  omega

/-- Global capacity for any subset of quarter-roots with the same pivot bound. -/
theorem positive_capacity_card {n A m C:ℕ} {B D:Finset ℕ}
    (hf:FourFree B)
    (hAo:A%2=1) (hAn:n<A) (hAl:A+2*(m-1)≤2*n)
    (hlarge:C+2*((parityMiddle n B 0).card+(H0 n B).card+2*(Ho n B).card+4*(gaps n A m B).card)+4<2*m) (hCe:C%2=0)
    (hD:D⊆quarterD n B)
    (hp:∀d∈D, ∃p, p∈B ∧ p+4*d∈B ∧ 2*n<p ∧ p%4=0 ∧ p≤2*n+C) :
    D.card=0 ∨ 4*D.card+4*m≤n+4*((parityMiddle n B 0).card+(H0 n B).card+2*(Ho n B).card+4*(gaps n A m B).card)+C+11 := by
  by_cases hne:D.Nonempty
  · let lo:=D.min' hne
    let hi:=D.max' hne
    have hlo:lo∈D:=min'_mem D hne
    have hhi:hi∈D:=max'_mem D hne
    have hDinterval:D⊆Icc lo hi := by
      intro x hx
      exact mem_Icc.mpr ⟨min'_le D x hx,le_max' D x hx⟩
    have hcard:=card_le_card hDinterval
    rw [Nat.card_Icc] at hcard
    have hlh:lo≤hi:=le_max' D lo hlo
    have hends:∀d∈D, 2*m≤4*d+2*((parityMiddle n B 0).card+(H0 n B).card+2*(Ho n B).card+4*(gaps n A m B).card)+4 ∧
        4*d+(A+2*(m-1))≤2*n+2*((parityMiddle n B 0).card+(H0 n B).card+2*(Ho n B).card+4*(gaps n A m B).card)+C+2 := by
      intro d hdD
      have hdq:=hD hdD
      obtain ⟨hdI,hdB⟩:=mem_filter.mp hdq
      have hdi:=mem_Icc.mp hdI
      obtain ⟨p,hpB,hpxB,hpn,hp4,hpu⟩:=hp d hdD
      exact positive_capacity_endpoints hf hAo hAn hAl hlarge hCe hdB
        (by omega) (by omega) (by omega) hpB hpxB hpn hp4 hpu
    have h1:=hends lo hlo
    have h2:=hends hi hhi
    right
    omega
  · left
    exact card_eq_zero.mpr (not_nonempty_iff_eq_empty.mp hne)


#print axioms positive_capacity_card
end OP02.PositivePivot

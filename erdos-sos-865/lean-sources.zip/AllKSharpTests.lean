import AllKLocal
import AllKGeometryWindow

open Finset OP02.FewHole OP02.SharpK5 OP02.SharpK8
namespace OP02.AllOrders

/-- The hardest period at eight has 48 units of supply against at most 44
roles. The uniform scaled cardinality comparison with rounding is in window_supply. -/
theorem eight_period32_comparison : 8 + (8-2)*6 = 44 ∧
    (1/(4*4*32):ℝ) = 48*(2/3-coeff 8) ∧ 44 < (48:ℕ) := by
  norm_num [coeff]

/-- Physical window for the largest seed vertex itself at twelve. -/
theorem twelve_top_window {T f z R w : ℕ} {A F W : Finset ℕ}
    (seed : ShapeAt 11 (T/4) A F f) (core : ShapeAt 10 (T/4) A W z)
    (lo : T/4+2*z+4<R) (hi : R≤T/4+2*z+(T/4)/64)
    (target : (R+f)%4=2)
    (sw : 256*w ≤ alpha256 10*(T/4)) :
    T/4/2+2 < (R+f)/2-z+w ∧ (R+f)/2-z+w≤T/4 ∧
    256*((R+f)/2-z) ≤ alpha256 12*T := by
  have h := physical_window_geometry (k:=12) (T:=T) (J:=T/4) (z:=z) (R:=R) (u:=f) (w:=w)
    (by decide) rfl core.above core.height lo hi (by omega) seed.height sw
  exact h.2.2.2

/-- The half of the failed top translate, obtained for this very R, supplies
the contact with z. All other contacts use the same lower tests. -/
theorem twelve_top_reflection {T R f z : ℕ} {A F W targets : Finset ℕ}
    (seed : ShapeAt 11 (T/4) A F f) (core : ShapeAt 10 (T/4) A W z)
    (sub : A⊆Icc 1 T) (df : DoublingFree A) (div4 : ∀w∈W,w%4=0)
    (lo : T/4+2*z+4<R) (hi : R≤T/4+2*z+(T/4)/64)
    (phase : ∀a∈targets,(R+a)%4=2)
    (admission : ∀u∈insert 0 F,R+u∉A → u∈targets ∧ (R+u)/2∈A)
    (lower : ∀u∈targets,∀w∈insert 0 (W.erase z),(R+u)/2-z+w∈A)
    (missing : R+f∉A) (room : 12*(chainCapacity T-A.card)<(9*T/16-T/2)/8) :
    ∃ S P, ShapeAt 12 T A S P ∧ Nat.choose S.card 2=66 := by
  obtain ⟨ht,half⟩ := admission f (mem_insert_of_mem seed.top) missing
  have ph := phase f ht
  have bound := physical_window_geometry (k:=12) (T:=T) (J:=T/4) (z:=z) (R:=R) (u:=f) (w:=0)
    (by decide) rfl core.above core.height lo hi (by omega) seed.height (by omega)
  obtain ⟨S,P,h⟩ := replacement_shape (k:=12) (p:=R) (u:=f) (z:=z)
    (by decide) sub df core.clique (fun w hw => by have := div4 w hw; omega)
    half bound.2.2.1 (by have := div4 z core.top; omega) (lower f ht)
    (fun w hw => by
      have a := inherited_bounds (k:=12) (T:=T) (J:=T/4) (R:=R) (x:=w)
        (by decide) rfl (Or.inr (vertex_height core hw)) bound.2.1
      exact a.1) bound.2.2.2.2.2 room
  exact ⟨S,P,h,by rw [h.clique.2.1]; decide⟩

end OP02.AllOrders

import K7Partner
import K5CanonicalHoles
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

/-- A uniform slack allowance sufficient for the historical all-even row.
The threshold is chosen before the set or the seed. -/
theorem small_inventory (β : ℝ) (hβ : 0<β) :
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀≤n → ∀ B : Finset ℕ, DoublingFree B →
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    192*(chainDeficit n B+totalBudget n B)≤n/4 ∧ 1024≤n := by
  obtain ⟨U,hU⟩ := capacity_uniform_error (1/384) (by norm_num)
  refine ⟨max 1024 (4*U),?_⟩
  intro n hn B hd hg
  let H:=n/4
  have hu : U≤H := by dsimp [H];omega
  have hc := hU H hu
  have ht := chain_capacity_with_top_loss H (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  have hid : chainDeficit n B + (quarterD n B).card = chainCapacity H := by
    unfold chainDeficit;dsimp [H] at *;omega
  have hir : (chainDeficit n B:ℝ) + (quarterD n B).card = chainCapacity H := by exact_mod_cast hid
  have hH : 4*(H:ℝ)≤n := by exact_mod_cast (show 4*H≤n by dsimp [H];omega)
  have hpos : 0≤β*(n:ℝ) := by positivity
  have hh : (192:ℝ)*((chainDeficit n B:ℝ)+(totalBudget n B:ℝ))≤H := by
    linarith only [hir,hg,hc,hH,hpos]
  exact ⟨by exact_mod_cast hh,by omega⟩

/-- The entire ledger row 1: any actual internal all-even five extends first
by an odd high singleton, then by a canonical upper vertex. -/
theorem row01_all_even (β : ℝ) (hβ : 0<β) :
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀≤n → ∀ B : Finset ℕ, SevenFree B → DoublingFree B →
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀ S : Finset ℕ, InternalFive (B∩Icc 1 (n/4)) S → (∀ x∈S,x%2=0) → False := by
  classical
  obtain ⟨n₀,h₀⟩ := small_inventory β hβ
  refine ⟨n₀,?_⟩
  intro n hn B hf hd hg S hs hall
  obtain ⟨hcap,hnn⟩:=h₀ n hn B hd hg
  obtain ⟨h5,hsub,hedge⟩:=hs
  let O:=insert 0 S
  have hO : O.card≤6 := by
    dsimp [O];have h:=card_insert_le 0 S;omega
  have hdata t (ht:t∈O) : t≤n/4 ∧ t%2=0 := by
    rcases mem_insert.mp ht with rfl|ht
    · exact ⟨Nat.zero_le _, rfl⟩
    · exact ⟨(mem_Icc.mp (mem_inter.mp (hsub ht)).2).2,hall t ht⟩
  let Y:=progression (n/2) (3*n/4) 4 1
  have hy₀ x (hx:x∈Y) : n/2<x ∧ x≤3*n/4 ∧ x%4=1 :=
    ⟨(mem_Ioc.mp (mem_filter.mp hx).1).1,(mem_Ioc.mp (mem_filter.mp hx).1).2,(mem_filter.mp hx).2⟩
  have hi:=missingTopOdd_le_deficit n B hd
  have hsmall : (missingTopOdd n B).card ≤ chainDeficit n B+totalBudget n B := by unfold totalBudget;omega
  have hcnt := progression_lower (n/2) (3*n/4) 4 1 (by decide) (by decide)
  have hy := shift_losses Y O B (missingTopOdd n B) 1 0 6 (by intro;intro;omega)
    (by
      intro x hx t ht hnB
      have hp:=hy₀ x hx; have ht':=hdata t ht
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega,hnB⟩)
    (fun z hz=>(card_filter_le _ _).trans hO)
  change _≤Y.card at hcnt
  obtain ⟨y,hy⟩:=card_pos.mp (show 0<(passes Y O B).card by omega)
  have hy':=hy₀ y (mem_filter.mp hy).1
  have hyl:= (mem_filter.mp hy).2
  have hyB:y∈B:=by simpa using hyl 0 (mem_insert_self _ _)
  let V:=insert y S
  let U:=insert y O
  have hU:U.card≤7:=by dsimp [U];have h:=card_insert_le y O; omega
  let r:=(12-y%8)%8
  let P:=progression (2*n) (3*n) 8 r
  have hp₀ x (hx:x∈P) : 2*n<x ∧ x≤3*n ∧ x%8=r :=
    ⟨(mem_Ioc.mp (mem_filter.mp hx).1).1,(mem_Ioc.mp (mem_filter.mp hx).1).2,(mem_filter.mp hx).2⟩
  have hholes:=canonical_hole_total_budget n B hd
  change (canonicalHoles n B).card ≤ chainDeficit n B + deficit n B + _ at hholes
  have hsmall' : (canonicalHoles n B).card ≤ chainDeficit n B+totalBudget n B := by unfold totalBudget;omega
  have hcnt':=progression_lower (2*n) (3*n) 8 r (by decide) (by dsimp [r];omega)
  change _≤P.card at hcnt'
  have hp:=shift_losses P U B (canonicalHoles n B) 1 0 7 (by intro;intro;omega)
    (by
      intro x hx t ht hnB
      have hh:=hp₀ x hx;dsimp [r] at hh
      have hr : x%2=1 ∧ (x+y)%8=4 := by omega
      have haux : t≤n ∧ canonical (x+t)=true := by
        rcases mem_insert.mp ht with heq|ht
        · subst t
          refine ⟨by omega,?_⟩
          have hc:=canonical_four ((x+y)/4)
          rw [show 4*((x+y)/4)=x+y by omega] at hc
          exact hc.trans (canonical_odd _ (by omega))
        · have hd':=hdata t ht;exact ⟨by omega,canonical_odd _ (by omega)⟩
      exact mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hnB⟩,haux.2⟩)
    (fun z hz=>(card_filter_le _ _).trans hU)
  obtain ⟨p,hp⟩:=card_pos.mp (show 0<(passes P U B).card by omega)
  have pp:=hp₀ p (mem_filter.mp hp).1
  have pl:=(mem_filter.mp hp).2
  have hV:∀t∈V,t≤n:=by
    intro t ht;rcases mem_insert.mp ht with rfl|ht
    · omega
    · have hh:=hdata t (mem_insert_of_mem ht);omega
  have pV:p∉V:=fun ht=>by have hh:=hV p ht;omega
  have yS:y∉S:=fun ht=>by have hh:=hdata y (mem_insert_of_mem ht);omega
  have vc:V.card=6:=by simp [V,card_insert_of_notMem yS,h5]
  have pB:p∈B:=by simpa using pl 0 (mem_insert_of_mem (mem_insert_self _ _))
  apply hf
  refine ⟨insert p V,?_,by rw [card_insert_of_notMem pV,vc],?_⟩
  · intro x hx;rcases mem_insert.mp hx with rfl|hx
    · exact pB
    · rcases mem_insert.mp hx with rfl|hx
      · exact hyB
      · exact (mem_inter.mp (hsub hx)).1
  · have vU:V⊆U:=by
      intro t ht;rcases mem_insert.mp ht with rfl|ht
      · exact mem_insert_self _ _
      · exact mem_insert_of_mem (mem_insert_of_mem ht)
    have vv : ∀x∈V,∀z∈V,x≠z→x+z∈B:=by
      intro x hx z hz hxz
      rcases (mem_insert.mp hx : x=y ∨ x∈S) with heq|hxS <;> rcases (mem_insert.mp hz : z=y ∨ z∈S) with heqz|hzS
      · exact False.elim (hxz (heq.trans heqz.symm))
      · rw [heq];exact hyl z (mem_insert_of_mem hzS)
      · rw [heqz,Nat.add_comm];exact hyl x (mem_insert_of_mem hxS)
      · exact (mem_inter.mp (hedge x hxS z hzS hxz)).1
    intro x hx z hz hxz
    rcases (mem_insert.mp hx : x=p ∨ x∈V) with heq|hxV <;> rcases (mem_insert.mp hz : z=p ∨ z∈V) with heqz|hzV
    · exact False.elim (hxz (heq.trans heqz.symm))
    · rw [heq];exact pl z (vU hzV)
    · rw [heqz,Nat.add_comm];exact pl x (vU hxV)
    · exact vv x hxV z hzV hxz

end OP02.SharpK7

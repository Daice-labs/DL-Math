import FewHoleAudit

open Finset Filter
open scoped Asymptotics
namespace OP02.Frontier

/-- A fixed additive error in the normalized large-hole regime. -/
def LargeHoleGoal : Prop :=
  ∃ C : ℕ, ∀ n : ℕ, 1 ≤ n → ∀ B : Finset ℕ,
    B ⊆ Icc 1 (4 * n) → OP02.FewHole.FourFree B →
    OP02.FewHole.DoublingFree B →
    n ≤ 4 * (OP02.FewHole.holes n B).card → 8 * B.card ≤ 21 * n + C

/-- Explicit positive-density four-point midpoint configuration hypothesis.
This is a hypothesis, not an axiom or a deposited proof of Dousse's theorem. -/
def Dousse4 : Prop :=
  ∀ δ : ℝ, 0 < δ → ∃ N₀ : ℕ, 1 ≤ N₀ ∧ ∀ N : ℕ, N₀ ≤ N →
    ∀ T : Finset ℕ, T ⊆ Icc 1 N → δ * (N : ℝ) ≤ (T.card : ℝ) →
      ∃ S ⊆ T, S.card = 4 ∧ ∀ x ∈ S, ∀ y ∈ S, x ≠ y →
        ∃ z ∈ T, x + y = 2 * z

/-- Exact k=4 asymptotic endpoint, conditional on precisely two visible inputs. -/
def ConditionalK4Goal : Prop := Dousse4 → LargeHoleGoal → OP02.K4Goal

end OP02.Frontier
#print OP02.Frontier.LargeHoleGoal
#print OP02.Frontier.Dousse4
#print OP02.Frontier.ConditionalK4Goal
#print axioms OP02.FewHole.few_holes_explicit

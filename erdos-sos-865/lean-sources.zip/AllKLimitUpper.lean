import AllKMidpoints
import AllKLimitBands
import KnownK3
import K5Complete

open Finset Filter
open scoped Asymptotics
namespace OP02.AllOrders

def Avoids (k : ℕ) (A : Finset ℕ) : Prop := ¬ ∃ S, OP02.SharpK8.Internal k A S

theorem deletion (k : ℕ) (hk : 2≤k) (δ : ℝ) (hδ : 0 < δ) :
      ∃ N0 : ℕ, 1 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N →
        ∀ A : Finset ℕ, A ⊆ Finset.Icc 1 N →
          Avoids k A →
          ∃ B : Finset ℕ, B ⊆ Finset.Icc 1 N ∧
            Avoids k B ∧
            OP02.FewHole.DoublingFree B ∧
            (A.card : ℝ) ≤ (B.card : ℝ) + δ * (N : ℝ) := by
    classical
    obtain ⟨N0, hN0, hD0⟩ := midpoints_all k hk δ hδ
    refine ⟨N0, hN0, ?_⟩
    intro N hN A hsub hfour
    let T : Finset ℕ := A.filter (fun x => 2 * x ∈ A)
    have hTA : T ⊆ A := by
      intro x hx
      exact (Finset.mem_filter.mp hx).1
    have hTI : T ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hTA hx)
    have ht : (T.card : ℝ) < δ * (N : ℝ) := by
      by_contra hn
      have hd : δ * (N : ℝ) ≤ (T.card : ℝ) := le_of_not_gt hn
      obtain ⟨S, hST, hSc, hm⟩ := hD0 N hN T hTI hd
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hTA (hST hx)
      · intro x hx y hy hxy
        obtain ⟨z, hz, hzxy⟩ := hm x hx y hy hxy
        rw [hzxy]
        exact (Finset.mem_filter.mp hz).2
    let B : Finset ℕ := A \ T
    have hBA : B ⊆ A := by
      intro x hx
      exact (Finset.mem_sdiff.mp hx).1
    have hBI : B ⊆ Finset.Icc 1 N := by
      intro x hx
      exact hsub (hBA hx)
    have hfB : Avoids k B := by
      rintro ⟨S, hSB, hSc, hpair⟩
      apply hfour
      refine ⟨S, ?_, hSc, ?_⟩
      · intro x hx
        exact hBA (hSB hx)
      · intro x hx y hy hxy
        exact hBA (hpair x hx y hy hxy)
    have hdB : OP02.FewHole.DoublingFree B := by
      intro x hx h2
      obtain ⟨hxA, hxT⟩ := Finset.mem_sdiff.mp hx
      apply hxT
      exact Finset.mem_filter.mpr ⟨hxA, hBA h2⟩
    have hcard : B.card + T.card = A.card :=
      Finset.card_sdiff_add_card_eq_card hTA
    have hcardR : (B.card : ℝ) + (T.card : ℝ) = (A.card : ℝ) := by
      exact_mod_cast hcard
    refine ⟨B, hBI, hfB, hdB, ?_⟩
    linarith only [hcardR, ht]

theorem extremal (k N : ℕ) (hk : 2≤k) : ∃ A⊆Icc 1 N,
    Avoids k A ∧ Erdos865.f N k ≤ A.card+1 := by
  classical
  have hp := band_lower k N hk
  by_contra hn
  have hle : Erdos865.f N k ≤ Erdos865.f N k - 1 := by
    apply Nat.sInf_le
    intro A hA hc
    by_contra hbad
    exact hn ⟨A,hA,hbad,by omega⟩
  omega

def Upper (k : ℕ) : Prop := ∀ ε : ℝ, 0<ε → ∃ M : ℕ, ∀ N : ℕ, M≤N →
    (Erdos865.f N k : ℝ) ≤ (coeff k+ε)*N

theorem upper_of_shaped (k : ℕ) (hk : 6≤k) (shape : Shaped k) : Upper k := by
  intro ε hε
  obtain ⟨T,_,del⟩ := deletion k (by omega) (ε/3) (by positivity)
  obtain ⟨U,geom⟩ := shape (ε/3) (by positivity)
  obtain ⟨V,hV⟩ := exists_nat_gt (3/ε)
  refine ⟨max T (max U V),?_⟩
  intro N hN
  obtain ⟨A,hA,hfree,hf⟩ := extremal k N (by omega)
  obtain ⟨B,hB,hBF,hBD,hm⟩ := del N (by omega) A hA hfree
  have small : (B.card:ℝ) < (coeff k+ε/3)*N := by
    by_contra! big
    obtain ⟨F,z,hz⟩ := geom N (by omega) B hB hBD big
    exact hBF ⟨F,hz.clique⟩
  have hfr : (Erdos865.f N k:ℝ) ≤ (A.card:ℝ)+1 := by exact_mod_cast hf
  have hVN : (V:ℝ)≤N := by exact_mod_cast (show V≤N by omega)
  have room := (div_lt_iff₀ hε).mp (hV.trans_le hVN)
  nlinarith only [hfr,hm,small,room]

private theorem small_two (N : ℕ) : (Erdos865.f N 2:ℝ) ≤ coeff 2*N+8 := by
  classical
  obtain ⟨A,hA,hf,hcard⟩ := extremal 2 N (by decide)
  let n := (N+1)/2
  have sub : A⊆Icc 1 (2*n) := hA.trans (Icc_subset_Icc_right (by dsimp [n]; omega))
  have h₀ : A.card < n+2 := by
    by_contra! hh
    obtain ⟨a,ha,b,hb,hab,hp⟩ := Erdos865.known_k2 n A sub hh
    apply hf
    refine ⟨{a,b},?_,?_,?_⟩
    · intro x hx
      simp only [mem_insert,mem_singleton] at hx
      rcases hx with rfl|rfl <;> assumption
    · simp [hab]
    · intro x hx y hy ne
      simp only [mem_insert,mem_singleton] at hx hy
      rcases hx with rfl|rfl <;> rcases hy with rfl|rfl <;> first | contradiction | exact hp | simpa [add_comm] using hp
  have bd : 2*Erdos865.f N 2 ≤ N+8 := by dsimp [n] at h₀; omega
  have r : 2*(Erdos865.f N 2:ℝ)≤(N:ℝ)+8 := by exact_mod_cast bd
  norm_num [coeff]
  linarith

private theorem small_three (N : ℕ) : (Erdos865.f N 3:ℝ) ≤ coeff 3*N+8 := by
  classical
  obtain ⟨A,hA,hf,hcard⟩ := extremal 3 N (by decide)
  have ht : Erdos865.IsTripleFree A := by
    rintro ⟨a,ha,b,hb,c,hc,hab,hac,hbc,h1,h2,h3⟩
    apply hf
    refine ⟨{a,b,c},?_,?_,?_⟩
    · intro x hx
      simp only [mem_insert,mem_singleton] at hx
      rcases hx with rfl|rfl|rfl <;> assumption
    · simp [hab,hac,hbc]
    · intro x hx y hy ne
      simp only [mem_insert,mem_singleton] at hx hy
      rcases hx with rfl|rfl|rfl <;> rcases hy with rfl|rfl|rfl <;>
        first | contradiction | assumption | simpa [add_comm] using h1 |
          simpa [add_comm] using h2 | simpa [add_comm] using h3
  have h₀ := Erdos865.erdos865_upper_bound N A hA ht
  have bd : 8*Erdos865.f N 3 ≤ 5*N+61 := by omega
  have r : 8*(Erdos865.f N 3:ℝ) ≤ 5*(N:ℝ)+61 := by exact_mod_cast bd
  norm_num [coeff]
  linarith

private theorem upper_of_add (k : ℕ) (h : ∀ N : ℕ, (Erdos865.f N k:ℝ) ≤ coeff k*N+8) :
    Upper k := by
  intro ε hε
  obtain ⟨V,hV⟩ := exists_nat_gt (8/ε)
  refine ⟨V,?_⟩
  intro N hN
  have hv : (V:ℝ)≤N := by exact_mod_cast hN
  have room := (div_lt_iff₀ hε).mp (hV.trans_le hv)
  nlinarith only [h N,room]

private theorem upper_of_equiv (k : ℕ) (hk : 2≤k)
    (equiv : (fun N : ℕ => (Erdos865.f N k:ℝ)) ~[atTop]
      (fun N : ℕ => coeff k * (N:ℝ))) : Upper k := by
  intro ε hε
  have cp := coeff_pos k hk
  change Asymptotics.IsLittleO atTop
    (fun N : ℕ => (Erdos865.f N k:ℝ)-coeff k*N) (fun N : ℕ => coeff k*N) at equiv
  obtain ⟨M,hm⟩ := eventually_atTop.mp (Asymptotics.isLittleO_iff.mp equiv (show 0<ε/coeff k by positivity))
  refine ⟨M,?_⟩
  intro N hN
  have bd := hm N hN
  change ‖(Erdos865.f N k:ℝ)-coeff k*N‖ ≤ (ε/coeff k)*‖coeff k*(N:ℝ)‖ at bd
  simp only [Real.norm_eq_abs,abs_of_nonneg (show 0≤coeff k*(N:ℝ) by positivity)] at bd
  have hu := (abs_le.mp bd).2
  have can : ε/coeff k * (coeff k*(N:ℝ)) = ε*N := by field_simp
  rw [can] at hu
  linarith

theorem upper_all_of_shaped (shape : ∀ k : ℕ, 6≤k → Shaped k)
    (k : ℕ) (hk : 2≤k) : Upper k := by
  by_cases h6 : 6≤k
  · exact upper_of_shaped k h6 (shape k h6)
  have d5 := OP02.SharpK8.dousse5_of_dousse8 OP02.Midpoint.dousse8
  interval_cases k
  · exact upper_of_add 2 small_two
  · exact upper_of_add 3 small_three
  · apply upper_of_equiv 4 (by decide)
    have h := OP02.SharpK4.complete_k4_endpoint (OP02.SharpK5.dousse4_of_dousse5 d5)
    convert h using 1
    norm_num [OP02.K4Goal,coeff]
  · apply upper_of_equiv 5 (by decide)
    have h := OP02.SharpK5.complete_k5_endpoint d5
    convert h using 1
    norm_num [OP02.SharpK5.K5Goal,coeff]

end OP02.AllOrders

import K7Outer

open Finset
namespace OP02.SharpK7

/-- Each occupied reflection pair is indexed by its smaller endpoint. -/
def reflectionPairs (S : Finset ℕ) (e : ℕ) :=
  S.filter (fun a => 0 < a ∧ a < e-a ∧ e-a ∈ S)

private def foldAt (e x : ℕ) := if e ≤ x then (x+1)/2 else min x (e-x)

/-- Exact supply at an actual largest even member. A missing midpoint follows
from the physical doubling restriction. No triangle profile is needed. -/
theorem reflection_count (N e : ℕ) (S : Finset ℕ) (hS : S ⊆ Icc 1 N)
    (hd : ∀ x∈S, 2*x ∉ S) (he : e∈S) (hee : e%2 = 0)
    (hmax : ∀ x∈S, x%2=0 → x≤e) :
    S.card ≤ (N+1)/2 + (reflectionPairs S e).card := by
  classical
  let A := reflectionPairs S e
  let T := S \ A
  have heI := mem_Icc.mp (hS he)
  have hmid (x : ℕ) (hx : x∈S) : 2*x≠e := fun h => hd x hx (h.symm ▸ he)
  have hmiss {x y : ℕ} (hx : x∈T) (hy : y∈S) (hxy : x<y) (hs : x+y=e) : False := by
    apply (mem_sdiff.mp hx).2
    exact mem_filter.mpr ⟨(mem_sdiff.mp hx).1,(mem_Icc.mp (hS (mem_sdiff.mp hx).1)).1,
      by omega, by simpa [show e-x=y by omega] using hy⟩
  have himg (x : ℕ) (hx : x∈T) : foldAt e x ∈ Icc 1 ((N+1)/2) := by
    obtain ⟨hxp,hxN⟩ := mem_Icc.mp (hS (mem_sdiff.mp hx).1)
    simp only [foldAt,mem_Icc]
    split_ifs <;> omega
  have hinj : Set.InjOn (foldAt e) (T : Set ℕ) := by
    intro x hx y hy hab
    have hxs := (mem_sdiff.mp hx).1; have hys := (mem_sdiff.mp hy).1
    have hxodd := hmax x hxs; have hyodd := hmax y hys
    have hxmid := hmid x hxs; have hymid := hmid y hys
    have h1 := hmiss hx hys; have h2 := hmiss hy hxs
    have hxp := (mem_Icc.mp (hS hxs)).1; have hyp := (mem_Icc.mp (hS hys)).1
    by_cases hsum : x+y=e
    · by_contra hne
      rcases lt_or_gt_of_ne hne with hlt | hgt
      · exact h1 hlt hsum
      · exact h2 hgt (by omega)
    unfold foldAt at hab
    split_ifs at hab <;> omega
  have hcard : T.card ≤ (Icc 1 ((N+1)/2)).card := card_le_card_of_injOn _ himg hinj
  have hdis := card_sdiff_add_card_eq_card (filter_subset _ S : A ⊆ S)
  change (S \ A).card + A.card = S.card at hdis
  rw [Nat.card_Icc] at hcard
  change (S \ A).card ≤ _ at hcard
  change S.card ≤ _ + A.card
  omega

theorem find_reflection_sum (N : ℕ) (S : Finset ℕ) (hS : S ⊆ Icc 1 N)
    (hd : ∀ x∈S, 2*x ∉ S) (hbig : (N+1)/2 < S.card) :
    ∃ e ∈ S, e%2=0 ∧ (∀ x∈S, x%2=0 → x≤e) ∧
      S.card ≤ (N+1)/2 + (reflectionPairs S e).card := by
  classical
  let E := S.filter (fun x => x%2=0)
  have hE : E.Nonempty := by
    by_contra h
    have ho (x : ℕ) (hx : x∈S) : x%2=1 := by
      by_contra h'; exact h ⟨x,mem_filter.mpr ⟨hx,by omega⟩⟩
    have hmap (x : ℕ) (hx : x∈S) : (x+1)/2 ∈ Icc 1 ((N+1)/2) := by
      have := mem_Icc.mp (hS hx); exact mem_Icc.mpr ⟨by omega,by omega⟩
    have hi : Set.InjOn (fun x : ℕ => (x+1)/2) (S : Set ℕ) := by
      intro x hx y hy heq
      have := ho x hx; have := ho y hy; dsimp at heq; omega
    have hc := card_le_card_of_injOn _ hmap hi
    rw [Nat.card_Icc] at hc; omega
  let e := E.max' hE
  have hem := mem_filter.mp (max'_mem E hE)
  have hmax (x : ℕ) (hx : x∈S) (he : x%2=0) : x≤e :=
    le_max' E x (mem_filter.mpr ⟨hx,he⟩)
  exact ⟨e,hem.1,hem.2,hmax,reflection_count N e S hS hd hem.1 hem.2 hmax⟩

end OP02.SharpK7

import ZeroTriangle
open Finset
open scoped BigOperators
namespace OP02.ZeroExcess
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused

theorem critical_ranges {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c) :
    1≤a ∧ b≤n ∧ 2≤c ∧ c≤n := by
  have ha := mem_Icc.mp (mem_inter.mp (ht.tri.2.1 (by simp : a∈({a,b,c}:Finset ℕ)))).2
  have hb := mem_Icc.mp (mem_inter.mp (ht.tri.2.1 (by simp : b∈({a,b,c}:Finset ℕ)))).2
  have hc := mem_Icc.mp (mem_inter.mp (ht.tri.2.1 (by simp : c∈({a,b,c}:Finset ℕ)))).2
  have hcp := ht.co
  omega

theorem critical_even_pair {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    {x:ℕ} (hx:n+1≤x) (hxu:x≤2*n-(max b c+1)/2) :
    x∈middle n B ∨ x+c/2∈middle n B := by
  have hr := critical_ranges ht
  have hab := ht.lt
  have hao := ht.ao
  have hbo := ht.bo
  have hco := ht.co
  have hm:∀z∈({a,b,c}:Finset ℕ), z ≤ max b c := by
    intro z hz
    simp only [mem_insert,mem_singleton] at hz
    rcases hz with rfl|rfl|rfl <;> omega
  obtain ⟨u,hu,hum⟩ := pivot_missing n (max b c) B {a,b,c} hf ht.tri hm (2*x)
    (mem_Icc.mpr ⟨by omega,by omega⟩)
  obtain ⟨v,hv,hve⟩ := (upper_missing_iff n B hd he (mem_sdiff.mp hum).1).mp
    (mem_sdiff.mp hum).2
  simp only [mem_insert,mem_singleton] at hu
  rcases hu with hu|hu|hu|hu
  · left
    have h:v=x := by omega
    exact h ▸ hv
  · omega
  · omega
  · right
    have h:v=x+c/2 := by omega
    exact h ▸ hv

theorem critical_odd_pair {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    {x:ℕ} (hx:n≤x) (hxu:x≤2*n-(max b c)/2-1) :
    x+(a+1)/2∈middle n B ∨ x+(b+1)/2∈middle n B := by
  have hr := critical_ranges ht
  have hab := ht.lt
  have hao := ht.ao
  have hbo := ht.bo
  have hco := ht.co
  have hm:∀z∈({a,b,c}:Finset ℕ), z ≤ max b c := by
    intro z hz
    simp only [mem_insert,mem_singleton] at hz
    rcases hz with rfl|rfl|rfl <;> omega
  obtain ⟨u,hu,hum⟩ := pivot_missing n (max b c) B {a,b,c} hf ht.tri hm (2*x+1)
    (mem_Icc.mpr ⟨by omega,by omega⟩)
  obtain ⟨v,hv,hve⟩ := (upper_missing_iff n B hd he (mem_sdiff.mp hum).1).mp
    (mem_sdiff.mp hum).2
  simp only [mem_insert,mem_singleton] at hu
  rcases hu with hu|hu|hu|hu
  · omega
  · left
    have h:v=x+(a+1)/2 := by omega
    exact h ▸ hv
  · right
    have h:v=x+(b+1)/2 := by omega
    exact h ▸ hv
  · omega

def Step (d x y:ℕ) : Prop := x+d=y ∨ y+d=x

theorem critical_neighbor {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0)
    {z:ℕ} (hz:z∈Icc (n+1) (2*n)) (hzM:z∉middle n B) :
    ∃y∈middle n B, Step (c/2) z y ∨ Step ((b+1)/2-(a+1)/2) z y := by
  have hr := critical_ranges ht
  have hab := ht.lt
  have hao := ht.ao
  have hbo := ht.bo
  have hco := ht.co
  have hzi := mem_Icc.mp hz
  let u:=c/2
  let A:=(a+1)/2
  let Z:=(b+1)/2
  let v:=max b c
  have hcases :
      (n+1≤z ∧ z≤2*n-(v+1)/2) ∨
      (n+1≤z-u ∧ z-u≤2*n-(v+1)/2 ∧ z-u+u=z) ∨
      (n≤z-A ∧ z-A≤2*n-v/2-1 ∧ z-A+A=z) ∨
      (n≤z-Z ∧ z-Z≤2*n-v/2-1 ∧ z-Z+Z=z) := by
    dsimp [u,A,Z,v]
    omega
  rcases hcases with h|h|h|h
  · obtain hM|hM := critical_even_pair ht hf hd he h.1 h.2
    · contradiction
    · exact ⟨z+c/2,hM,Or.inl (Or.inl rfl)⟩
  · obtain hM|hM := critical_even_pair ht hf hd he h.1 h.2.1
    · exact ⟨z-u,hM,Or.inl (Or.inr h.2.2)⟩
    · dsimp [u] at h
      exact False.elim (hzM (h.2.2 ▸ hM))
  · obtain hM|hM := critical_odd_pair ht hf hd he h.1 h.2.1
    · exact False.elim (hzM (h.2.2 ▸ hM))
    · refine ⟨z-A+Z,hM,Or.inr (Or.inl ?_)⟩
      dsimp [A,Z] at *
      omega
  · obtain hM|hM := critical_odd_pair ht hf hd he h.1 h.2.1
    · refine ⟨z-Z+A,hM,Or.inr (Or.inr ?_)⟩
      dsimp [A,Z] at *
      omega
    · exact False.elim (hzM (h.2.2 ▸ hM))

theorem step_residue_unique {d r x y z:ℕ} (hd:d%2=1)
    (hx:Step d x z) (hy:Step d y z) (hxr:x%4=r) (hyr:y%4=r) : x=y := by
  rcases hx with hx|hx <;> rcases hy with hy|hy <;> omega

theorem missing_residue_bound {n a b c:ℕ} {B:Finset ℕ} (ht:Critical n B a b c)
    (hf:FourFree B) (hd:DoublingFree B) (he:(excessHoles n B).card=0) {r:ℕ} (hr:r<4) :
    (((Icc (n+1) (2*n)).filter (fun z=>z%4=r)) \ middle n B).card ≤
      2*(parityMiddle n B (1-r%2)).card := by
  classical
  let W:=((Icc (n+1) (2*n)).filter (fun z=>z%4=r)) \ middle n B
  let P:=parityMiddle n B (1-r%2)
  let F:=fun y=>W.filter (fun z=>Step (c/2) z y ∨ Step ((b+1)/2-(a+1)/2) z y)
  have hco := ht.co
  have hao := ht.ao
  have hbo := ht.bo
  have hab := ht.ab
  have hlt := ht.lt
  have hdu : (c/2)%2=1 := by omega
  have hdw : ((b+1)/2-(a+1)/2)%2=1 := by omega
  have hsub : W⊆P.biUnion F := by
    intro z hz
    obtain ⟨hzR,hzM⟩ := mem_sdiff.mp hz
    obtain ⟨hzI,hzr⟩ := mem_filter.mp hzR
    obtain ⟨y,hy,hstep⟩ := critical_neighbor ht hf hd he hzI hzM
    have hyp : y%2=1-r%2 := by
      rcases hstep with h|h <;> rcases h with h|h <;> omega
    exact mem_biUnion.mpr ⟨y,mem_filter.mpr ⟨hy,hyp⟩,mem_filter.mpr ⟨hz,hstep⟩⟩
  have hF : ∀y∈P, (F y).card≤2 := by
    intro y hy
    have hu : (W.filter (fun z=>Step (c/2) z y)).card≤1 := by
      apply card_le_one.mpr
      intro x hx z hz
      exact step_residue_unique hdu (mem_filter.mp hx).2 (mem_filter.mp hz).2
        (mem_filter.mp (mem_sdiff.mp (mem_filter.mp hx).1).1).2
        (mem_filter.mp (mem_sdiff.mp (mem_filter.mp hz).1).1).2
    have hw : (W.filter (fun z=>Step ((b+1)/2-(a+1)/2) z y)).card≤1 := by
      apply card_le_one.mpr
      intro x hx z hz
      exact step_residue_unique hdw (mem_filter.mp hx).2 (mem_filter.mp hz).2
        (mem_filter.mp (mem_sdiff.mp (mem_filter.mp hx).1).1).2
        (mem_filter.mp (mem_sdiff.mp (mem_filter.mp hz).1).1).2
    have heq : F y=(W.filter (fun z=>Step (c/2) z y)) ∪
      (W.filter (fun z=>Step ((b+1)/2-(a+1)/2) z y)) := by
      ext z
      simp [F]
      tauto
    rw [heq]
    have hc := card_union_le (W.filter (fun z=>Step (c/2) z y))
      (W.filter (fun z=>Step ((b+1)/2-(a+1)/2) z y))
    omega
  calc
    W.card ≤ (P.biUnion F).card := card_le_card hsub
    _ ≤ ∑y∈P, (F y).card := card_biUnion_le
    _ ≤ ∑_y∈P, 2 := sum_le_sum hF
    _ = 2*P.card := by simp [Nat.mul_comm]

#print axioms critical_neighbor
#print axioms missing_residue_bound
end OP02.ZeroExcess

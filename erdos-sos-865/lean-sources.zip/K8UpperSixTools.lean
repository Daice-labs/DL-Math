import K8GeometrySpec
import K7Loss
import K7FiveEighthsLog
import K5Progressions

open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.SharpK7 OP02.PivotAudit
namespace OP02.SharpK8

/-- A central five only needs its edges in D. Its largest early edge can exceed H/4. -/
theorem common_upper_root_six {H R : ℕ} {D F : Finset ℕ}
    (hF : Internal 5 D F) (hsmall : ∀x∈F, 128*x + 5*H ≤ 128*(H/4))
    (hlo : H < 2*R) (hhi : 4*R ≤ 3*H)
    (hpass : ∀x∈insert 0 F, R+x∈D) : RootSix H D := by
  classical
  have hR : R ∈ D := by simpa using hpass 0 (by simp)
  have hnew : R ∉ F := by intro h; have := hsmall R h; omega
  refine ⟨F,R,hF.2.1,hnew,⟨insert_subset hR hF.1,by simp [hnew,hF.2.1],?_⟩,hlo,hhi,hsmall⟩
  intro x hx y hy hne
  rcases mem_insert.mp hx with hxR|hxF
  · subst x
    rcases mem_insert.mp hy with hyR|hyF
    · exact (hne hyR.symm).elim
    · exact hpass y (mem_insert_of_mem hyF)
  · rcases mem_insert.mp hy with hyR|hyF
    · subst y
      simpa [add_comm] using hpass x (mem_insert_of_mem hxF)
    · exact hF.2.2 x hxF y hyF hne

theorem common_short_six {H R : ℕ} {D F : Finset ℕ} (hF : ShortFive H D F)
    (hlo : H < 2*R) (hhi : 4*R ≤ 3*H)
    (passes : ∀x∈insert 0 F, R+x∈D) : RootSix H D :=
  common_upper_root_six
    ⟨fun _ h => (mem_inter.mp (hF.1.1 h)).1, hF.1.2.1,
     fun x hx y hy hxy => (mem_inter.mp (hF.1.2.2 x hx y hy hxy)).1⟩
    hF.2 hlo hhi passes

/-- The only top holes used for the complementary windows are augmentable holes
and canonical tops missed even after augmenting the root set. -/
theorem augmented_top_budget (H : ℕ) (D U : Finset ℕ) (hD : D ⊆ Icc 1 H)
    (hd : DoublingFree D)
    (hU : ∀x∈U, H < 2*x ∧ x≤H ∧ x∉D ∧ ∀v∈D, 2*v≠x) :
    (U ∪ topMissing H (D∪U)).card ≤ chainCapacity H-D.card := by
  classical
  have hadd : DoublingFree (D ∪ U) := by
    intro x hx h2x
    rcases mem_union.mp hx with hx|hx
    · rcases mem_union.mp h2x with hh|hh
      · exact hd x hx hh
      · exact (hU _ hh).2.2.2 x hx rfl
    · have xb := hU x hx
      rcases mem_union.mp h2x with hh|hh
      · have b := (mem_Icc.mp (hD hh)).2; omega
      · have b := (hU _ hh).2.1; omega
  have hs : D ∪ U ⊆ Icc 1 H := by
    intro x hx
    rcases mem_union.mp hx with hx|hx
    · exact hD hx
    · have hh := hU x hx
      exact mem_Icc.mpr ⟨by omega,hh.2.1⟩
  have hj : Disjoint D U := disjoint_left.mpr (fun x hx hxU => (hU x hxU).2.2.1 hx)
  have hcap := chain_capacity_with_top_loss H (D∪U) hs hadd
  rw [card_union_of_disjoint hj] at hcap
  have hu := card_union_le U (topMissing H (D∪U))
  omega

/-- Proposition S yields the three small vertices and their real sum labels,
with a provably absent offset residue. The hypothesis permits previous deletion of any failed indices. -/
theorem short_missing_residue_triangle {m : ℕ} {Z : Finset ℕ} (hm : 0 < m)
    (hs : Z ⊆ Icc 1 m) (hd : DoublingFree Z)
    (hp : (5/8:ℝ)*m+(3/4:ℝ)*(Real.log (m:ℝ)/Real.log 2)+13/8 < Z.card) :
    ∃ a c b : ℕ, 0<a ∧ a<c ∧ c<b ∧ b≤3*(m/4)+1 ∧
      a∈Z ∧ c∈Z ∧ b∈Z ∧ a+c∈Z ∧ b+a∈Z ∧ b+c∈Z ∧
      ∃ j<4, ∀ s∈({0,a,c,b}:Finset ℕ), s%4≠j := by
  classical
  have hfail : ¬RestrictedClear m Z :=
    fun hc => (not_lt_of_ge (restricted_five_eighths_log hm hs hd hc)) hp
  unfold RestrictedClear at hfail
  push_neg at hfail
  obtain ⟨_,a,ha,c,hc,b,hb,apos,ac,cb,_,hac,_,_,bhi,hpat,hba,hbc⟩ := hfail
  refine ⟨a,c,b,apos,ac,cb,bhi,ha,hc,hb,hac,hba,hbc,?_⟩
  have missing {j : ℕ} (hj : j<4) (h0 : 0%4≠j)
      (ha' : a%4≠j) (hc' : c%4≠j) (hb' : b%4≠j) :
      ∃ j<4, ∀ s∈({0,a,c,b}:Finset ℕ), s%4≠j := by
    refine ⟨j,hj,?_⟩
    intro s hs'
    simp only [mem_insert,mem_singleton] at hs'
    rcases hs' with rfl|rfl|rfl|rfl <;> assumption
  rcases hpat with ⟨ae,ce,bo⟩|⟨ao,co,_,hp'⟩
  · by_cases hb1 : b%4=1
    · apply missing (j:=3) <;> omega
    · apply missing (j:=1) <;> omega
  · rcases hp' with ⟨he,be⟩|⟨_,b4⟩
    · by_cases ha1 : a%4=1
      · apply missing (j:=3) <;> omega
      · apply missing (j:=1) <;> omega
    · apply missing (j:=2) <;> omega

end OP02.SharpK8

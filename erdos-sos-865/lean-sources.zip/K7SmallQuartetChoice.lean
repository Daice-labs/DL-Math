import K7CompactQuartet
import K7FittedFavorable
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7.LongOddTask

theorem compact_actual_quartet {β:ℝ} {n:ℕ} {B:Finset ℕ}
    (hd:DoublingFree B) (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (pad:384*(chainDeficit n B+totalBudget n B)+10000*logLevels (n/4)+300000≤n/4):
    ∃a c b z:ℕ, 0<a ∧ a<c ∧ c<b ∧ b<z ∧ b≤3*(n/4/64)+1 ∧ n/4/8<z ∧
      z≤n/4/8+24*(quarterMissing (n/4) (quarterD n B)).card+16*logLevels (n/4)+256 ∧
      z+b≤n/4/4 ∧
      a∈quarterD n B ∧ c∈quarterD n B ∧ b∈quarterD n B ∧ z∈quarterD n B ∧
      a+c∈quarterD n B ∧ b+a∈quarterD n B ∧ b+c∈quarterD n B ∧
      z+a∈quarterD n B ∧ z+c∈quarterD n B ∧ z+b∈quarterD n B := by
  obtain ⟨a,c,b,ap,ac,cb,bs,pat,ra,rc,rb,rac,rba,rbc⟩:=physical_triangle_choice hd hg (by omega) hl
  let H:=n/4
  let L:=(quarterMissing H (quarterD n B)).card
  let j:=logLevels H
  let hi:=H/8+24*L+16*j+256
  have og:=actual_quarter_top_joint n B hd
  have lcap:384*L+10000*j+300000≤H:=by dsimp only [L,j,H];omega
  have bcap:b≤3*(H/64)+1:=bs
  have good:hi+b≤H/4:=by dsimp only [hi];omega
  have choice:∃z,H/8<z ∧ z≤hi ∧∀x∈({0,a,c,b}:Finset ℕ),z+x∈quarterD n B:=by
    rcases pat with ee|oo
    · have hlen:3*L<((hi-H/8)/128)*16:=by dsimp [hi];omega
      exact qualified_lower_star hd ac cb (le_refl _) good (Or.inl ee)
        (by simpa only [if_pos ee.1] using hlen)
    · let l:=H/32
      let u:=l+6*L+4*j+32
      have rhi:4*u≤hi:=by dsimp [u,l,hi];omega
      obtain ⟨z,lb,ub,roots⟩:=short_odd_star (n:=n) (H:=H) (l:=l) (u:=u) rfl hd ac cb oo.1 oo.2.1 oo.2.2
        (by dsimp [u];omega) (by dsimp [l];omega) (by omega) (by change 6*L+4*j<u-l;dsimp [u];omega)
      exact ⟨z,lb,ub.trans rhi,roots⟩
  obtain ⟨z,lb,ub,roots⟩:=choice
  refine ⟨a,c,b,z,ap,ac,cb,by omega,bs,lb,ub,by omega,ra,rc,rb,by simpa using roots 0 (by simp),
    rac,rba,rbc,roots a (by simp),roots c (by simp),roots b (by simp)⟩

end OP02.SharpK7.LongOddTask

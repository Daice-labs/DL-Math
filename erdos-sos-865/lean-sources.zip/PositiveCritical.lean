import PositiveEdges
import EvenResources
open Finset
namespace OP02.PositivePivot
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.Focused OP02.ZeroExcess

/-- Fixed pivot residue: distinct offset residues make excess-hole payments injective. -/
theorem positive_pivot_count (n:ℕ) (B S:Finset ℕ) (hf:FourFree B)
    (ht:LowerTriangle n B S) (hsep:Set.InjOn (fun u:ℕ=>u%8) ((insert 0 S:Finset ℕ):Set ℕ))
    {r α:ℕ} (hr:r<2) (hα:α<8) (T:Finset ℕ) (hT:T.card≤2)
    (hallow:∀u∈insert 0 S,(α+u)%2=0→u∈T ∧ (α+u)%4=2*r) :
    n/8≤2*(parityMiddle n B r).card+(excessHoles n B).card := by
  let Q:=((pivots n n α).product (insert 0 S)).filter
    (fun z:ℕ×ℕ=>z.1+z.2∈excessHoles n B)
  have hQinj:Set.InjOn (fun z:ℕ×ℕ=>z.1+z.2) Q := by
    intro x hx y hy he
    have hxP:=(mem_product.mp (mem_filter.mp hx).1).1
    have hyP:=(mem_product.mp (mem_filter.mp hy).1).1
    have hxU:=(mem_product.mp (mem_filter.mp hx).1).2
    have hyU:=(mem_product.mp (mem_filter.mp hy).1).2
    have hx8:=(mem_filter.mp hxP).2
    have hy8:=(mem_filter.mp hyP).2
    have he8:x.2%8=y.2%8:=by dsimp only at he;omega
    have hu:=hsep hxU hyU he8
    apply Prod.ext <;> dsimp only at * <;> omega
  have hQsub:Q.image (fun z:ℕ×ℕ=>z.1+z.2)⊆excessHoles n B := by
    intro x hx
    obtain ⟨z,hz,rfl⟩:=mem_image.mp hx
    exact (mem_filter.mp hz).2
  have hQ:=card_le_card hQsub
  rw [card_image_of_injOn hQinj] at hQ
  have hm:∀x∈S,x≤n:=fun x hx=>(mem_Icc.mp (mem_inter.mp (ht.2.1 hx)).2).2
  have hs:pivots n n α⊆(T.product (parityMiddle n B r)).image
      (fun z:ℕ×ℕ=>2*z.2-z.1) ∪ Q.image Prod.fst := by
    intro p hp
    have hpα:=(mem_filter.mp hp).2
    obtain ⟨u,hu,hmiss⟩:=pivot_missing n n B S hf ht hm p (mem_filter.mp hp).1
    rcases missing_split (n:=n)
      (by have h:=(mem_Icc.mp (mem_sdiff.mp hmiss).1);omega) (mem_sdiff.mp hmiss).2 with hd|he
    · obtain ⟨v,hv,hve⟩:=hd
      obtain ⟨huT,hu4⟩:=hallow u hu (by omega)
      apply mem_union_left
      exact mem_image.mpr ⟨(u,v),mem_product.mpr ⟨huT,mem_filter.mpr ⟨hv,by omega⟩⟩,by dsimp;omega⟩
    · apply mem_union_right
      exact mem_image.mpr ⟨(p,u),mem_filter.mpr ⟨mem_product.mpr ⟨hp,hu⟩,he⟩,rfl⟩
  have hc:=(card_le_card hs).trans (card_union_le _ _)
  have hi1:=card_image_le (s:=T.product (parityMiddle n B r)) (f:=fun z:ℕ×ℕ=>2*z.2-z.1)
  have hi2:=card_image_le (s:=Q) (f:=Prod.fst)
  simp only [product_eq_sprod] at hc
  rw [product_eq_sprod,card_product] at hi1
  have hmul:=Nat.mul_le_mul_right (parityMiddle n B r).card hT
  have hlow:=pivot_card_lower n n α (by omega) hα
  omega

theorem critical_from_actual_context (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (hmargin:51*(deficit n B+(excessHoles n B).card)+64<n) :
    ∃a b c,Critical n B a b c := by
  have hsides:=one_side_edgeless n B hc (by omega)
  obtain ⟨hn,hsub,hfour,hdbl,hholes,hbudget,htri,hprofile⟩:=hc
  obtain ⟨x,hx,y,hy,z,hz,hxy,hxz,hyz,hxs,hys,hzs⟩:=htri
  have ht:LowerTriangle n B {x,y,z} := by
    refine ⟨by simp [hxy,hxz,hyz],?_,?_⟩
    · intro u hu
      simp only [mem_insert,mem_singleton] at hu
      rcases hu with rfl|rfl|rfl <;> assumption
    · intro u hu v hv huv
      have hxsB:=(mem_inter.mp hxs).1
      have hysB:=(mem_inter.mp hys).1
      have hzsB:=(mem_inter.mp hzs).1
      simp only [mem_insert,mem_singleton] at hu hv
      rcases hu with rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl <;> simp_all [Nat.add_comm]
  obtain ⟨a,b,c,hset,hao,hbo,hce,hab8,hc8⟩:=hprofile _ ht
  rw [hset] at ht
  have hsep:Set.InjOn (fun u:ℕ=>u%8) ((insert 0 ({a,b,c}:Finset ℕ):Finset ℕ):Set ℕ) := by
    intro u hu v hv he
    change u∈(insert 0 ({a,b,c}:Finset ℕ)) at hu
    change v∈(insert 0 ({a,b,c}:Finset ℕ)) at hv
    dsimp only at he
    simp only [mem_insert,mem_singleton] at hu hv
    rcases hu with rfl|rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl|rfl <;> omega
  have hp:=excess_partition n B
  have hcrit:c%4=2 ∧ a%4≠b%4 := by
    by_contra hh
    have hn':c%4≠2 ∨ a%4=b%4:=by omega
    rcases hsides with hs|hs
    · obtain ⟨α,hα,T,hT,ha⟩:=noncritical_translate hao hbo hce (r:=0) (by omega) hn'
      have hcnt:=positive_pivot_count n B {a,b,c} hfour ht hsep (by omega) hα T hT ha
      have hsmall:=actual_even_edgeless n B hdbl hs
      omega
    · obtain ⟨α,hα,T,hT,ha⟩:=noncritical_translate hao hbo hce (r:=1) (by omega) hn'
      have hcnt:=positive_pivot_count n B {a,b,c} hfour ht hsep (by omega) hα T hT ha
      have hsmall:=actual_odd_edgeless n B hdbl hs
      omega
  have hab:a≠b:=by intro h;exact hab8 (h ▸ rfl)
  by_cases hlt:a<b
  · exact ⟨a,b,c,ht,hlt,hao,hbo,hcrit.1,hcrit.2⟩
  · have hswap:({b,a,c}:Finset ℕ)={a,b,c}:=by ext u;simp;tauto
    exact ⟨b,a,c,by rw [hswap];exact ht,by omega,hbo,hao,hcrit.1,Ne.symm hcrit.2⟩

theorem even_edgeless_from_actual_context (n:ℕ) (B:Finset ℕ) (hc:ChargeContext n B)
    (hmargin:51*(deficit n B+(excessHoles n B).card)+64<n) :
    NoEdge B (parityMiddle n B 0) := by
  rcases one_side_edgeless n B hc (by omega) with h|h
  · exact h
  · obtain ⟨a,b,c,ht⟩:=critical_from_actual_context n B hc hmargin
    have hp:=EvenProof.actual_population ht hc.2.2.1
    have hsmall:=actual_odd_edgeless n B hc.2.2.2.1 h
    have htwo:=middle_two_mod_four n B hc.2.2.2.1
    have he:=excess_partition n B
    change ((middle n B).filter (fun v=>v%4=2)).card≤_ at htwo
    dsimp only [EvenProof.twoMiddle] at hp
    omega

#print axioms positive_pivot_count
#print axioms critical_from_actual_context
#print axioms even_edgeless_from_actual_context
end OP02.PositivePivot

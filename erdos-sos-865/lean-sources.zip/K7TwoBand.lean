import K7CommonNeighbors
import K7HalfFaults
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit OP02.PositivePivot
namespace OP02.SharpK7
set_option maxHeartbeats 1200000

theorem quart_offset_counts {n:ℕ} {T:Finset ℕ} (h4:T.card=4) (ht:∀a∈T,a≤n/16) :
    (quartOffsets T).card≤5 ∧ ∀a∈quartOffsets T,a%4=0 ∧ a≤4*(n/16) := by
  refine ⟨?_,?_⟩
  · have :=card_image_le (s:=T) (f:=fun a:ℕ=>4*a)
    have :=card_insert_le 0 (T.image (fun a:ℕ=>4*a));unfold quartOffsets;omega
  · intro a ha;rcases mem_insert.mp ha with rfl|h
    · exact ⟨rfl,Nat.zero_le _⟩
    · obtain ⟨x,hx,rfl⟩:=mem_image.mp h;have :=ht x hx;omega

def twoBandBases (n w σ:ℕ):=progression (n+w/2) (n+w/2+n/4) 8 σ

private theorem band_data {n w σ y:ℕ} (hw:w≤n) (h:y∈twoBandBases n w σ) :
    n<y ∧ 4*y≤7*n ∧ y%8=σ ∧ n+w/2<y ∧ y≤n+w/2+n/4:=by
  obtain ⟨hi,hr⟩:=mem_filter.mp h;have hh:=mem_Ioc.mp hi;omega

theorem many_band_neighbors {n w σ:ℕ} {B T:Finset ℕ}
    (h4:T.card=4) (ht:∀a∈T,a≤n/16) (hw:w≤n) (hσ:σ<8)
    (hn:65536≤n) (hq:2048*totalBudget n B≤n)
    (hbad:(twoBandFaults n w σ B).card≤7*totalBudget n B) :
    totalBudget n B < (passes (twoBandBases n w σ) (quartOffsets T) B).card := by
  obtain ⟨hs,hr⟩:=quart_offset_counts h4 ht
  have hbd:=shift_losses (twoBandBases n w σ) (quartOffsets T) B (twoBandFaults n w σ B)
    1 0 5 (by intro _ _;omega) (by
      intro y hy a ha hab
      have yd:=band_data hw hy;have ad:=hr a ha
      exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,hab⟩)
    (fun _ _=>(card_filter_le _ _).trans hs)
  have hlen:=progression_lower (n+w/2) (n+w/2+n/4) 8 σ (by decide) hσ
  change _≤(twoBandBases n w σ).card at hlen
  omega

/-- Any two large families in distinct residues lead to one physical
cross sum. Inject after the first actual neighbor has been fixed. -/
theorem conflicting_neighbor_families {n:ℕ} {B T U V E:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hg:MiddleGap7 n B)
    (hn:65536≤n) (hq:256*totalBudget n B≤n) (h4:T.card=4)
    (hT:internalOn (quarterD n B) T) (ht:∀a∈T,a≤n/16)
    (hU:U.Nonempty) (hV:E.card<V.card)
    (hu:∀y∈U,n<y ∧ 4*y≤7*n ∧ y%2=1 ∧ ∀a∈quartOffsets T,y+a∈B)
    (hv:∀z∈V,n<z ∧ 4*z≤7*n ∧ z%2=1 ∧ ∀a∈quartOffsets T,z+a∈B)
    (hsep:∀y∈U,∀z∈V,y≠z)
    (hres:∀y∈U,∀z∈V,y+z∉B→y+z∈E) : False := by
  obtain ⟨y,hy⟩:=hU
  obtain ⟨ly,uy,oy,ay⟩:=hu y hy
  have hh:V.card≤E.card:=by
    apply card_le_card_of_injOn (fun z:ℕ=>y+z)
    · intro z hz
      obtain ⟨lz,uz,oz,az⟩:=hv z hz
      exact hres y hy z hz (common_neighbors_independent hf hd hg hn hq h4 hT ht ly lz uy uz oy oz
        (hsep y hy z hz) ay az)
    · intro z hz z' hz' h;change y+z=y+z' at h;omega
  omega

private theorem select_band_residues {w v:ℕ} (hr:w%2=v%2) (hne:w%4≠v%4) :
    ∃σ τ:ℕ,σ<8 ∧ τ<8 ∧ σ%2=1 ∧ τ%2=1 ∧ (2*σ+v)%8=(4+w)%8 ∧
      (2*τ+w)%8=(4+v)%8 ∧ (σ+τ)%8=4 ∧ σ%4≠τ%4 := by
  let σ:=((12+w%8-v%8)%8)/2
  let τ:=(12-σ)%8
  refine ⟨σ,τ,?_⟩
  dsimp [σ,τ];omega

/-- The accepted two-band physical interface. The two offsets may come
from either parity group and zero is retained as a possible offset. -/
theorem two_band_six {n w v:ℕ} {B T S:Finset ℕ}
    (hf:SevenFree B) (hd:DoublingFree B) (hg:MiddleGap7 n B)
    (hn:65536≤n) (hq:2048*totalBudget n B≤n)
    (h4:T.card=4) (hT:internalOn (quarterD n B) T) (ht:∀a∈T,a≤n/16)
    (hs:internalOn B S) (hc:S.card=6) (hsn:∀x∈S,x≤n)
    (hw:w∈insert 0 S) (hv:v∈insert 0 S) (hpar:w%2=v%2) (hr:w%4≠v%4)
    (hclass:∀x∈insert 0 S,x%2=w%2→x=w ∨ x=v) : False := by
  classical
  obtain ⟨σ,τ,hs8,ht8,so,todd,sw,tv,st,hdis⟩:=select_band_residues hpar hr
  let U:=passes (twoBandBases n w σ) (quartOffsets T) B
  let V:=passes (twoBandBases n v τ) (quartOffsets T) B
  have hcap:∀x∈insert 0 S,x≤n:=by
    intro x hx;rcases mem_insert.mp hx with rfl|hx;omega;exact hsn _ hx
  have hVclass:∀x∈insert 0 S,x%2=v%2→x=v ∨ x=w:=by
    intro x hx h;exact (hclass x hx (h.trans hpar.symm)).symm
  have uw:=two_band_faults_le hf hd hs hc hcap hw hv hclass so sw
  have uv:=two_band_faults_le hf hd hs hc hcap hv hw hVclass todd tv
  have ugt:totalBudget n B<U.card:=many_band_neighbors h4 ht (hcap _ hw) hs8 hn hq uw
  have vgt:totalBudget n B<V.card:=many_band_neighbors h4 ht (hcap _ hv) ht8 hn hq uv
  have hE: (fourResources n B).card≤totalBudget n B:=by have :=four_resource_budget n B hd;omega
  have udd {y:ℕ} (hy:y∈U):n<y ∧ 4*y≤7*n ∧ y%8=σ:=by
    have hh:=band_data (hcap _ hw) (mem_filter.mp hy).1;exact ⟨hh.1,hh.2.1,hh.2.2.1⟩
  have vdd {z:ℕ} (hz:z∈V):n<z ∧ 4*z≤7*n ∧ z%8=τ:=by
    have hh:=band_data (hcap _ hv) (mem_filter.mp hz).1;exact ⟨hh.1,hh.2.1,hh.2.2.1⟩
  apply conflicting_neighbor_families hf hd hg hn (by omega) h4 hT ht
    (card_pos.mp (show 0<U.card by omega)) (lt_of_le_of_lt hE vgt)
  · intro y hy;obtain ⟨l,u,r⟩:=udd hy;exact ⟨l,u,by omega,(mem_filter.mp hy).2⟩
  · intro z hz;obtain ⟨l,u,r⟩:=vdd hz;exact ⟨l,u,by omega,(mem_filter.mp hz).2⟩
  · intro y hy z hz;have :=udd hy;have :=vdd hz;omega
  · intro y hy z hz ha;obtain ⟨yl,yu,yr⟩:=udd hy;obtain ⟨zl,zu,zr⟩:=vdd hz
    exact OP02.SharpK6.bootstrap_missing_common n _ B (by omega) (by omega) (by omega) ha

/-- D-2B uniformly in the physical six and all choices of its two offsets. -/
theorem uniform_two_band (hD:Dousse7) {β:ℝ} (hb:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SevenFree B→DoublingFree B →
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    ∀S:Finset ℕ,internalOn B S→S.card=6→(∀x∈S,x≤n)→∀w∈insert 0 S,∀v∈insert 0 S,
    w%2=v%2→w%4≠v%4→(∀x∈insert 0 S,x%2=w%2→x=w ∨ x=v)→False := by
  obtain ⟨U,hU⟩:=small_quartet_uniform hD β hb
  obtain ⟨V,hV⟩:=middle_gap7 hD β hb
  obtain ⟨W,hW⟩:=strong_budget hD β hb
  refine ⟨max 65536 (max U (max V W)),?_⟩
  intro n hn B hf hd hpg S hs hsize hsn w hw v hv hp hr hclass
  obtain ⟨T,h4,hT,ht⟩:=hU n (by omega) B hd hpg
  obtain ⟨_,hqw⟩:=hW n (by omega) B hf hd hpg
  have hb' : (0:ℝ)≤β*n:=by positivity
  have qN:2048*totalBudget n B≤n:=by exact_mod_cast (show (2048:ℝ)*totalBudget n B≤n by linarith)
  exact two_band_six hf hd (hV n (by omega) B hf hd hpg) (by omega) qN h4 hT ht hs hsize hsn hw hv hp hr hclass

end OP02.SharpK7

import K7Partner
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7

/-- An even winning pair may change its tester after interpolation. Remove the
one boundary tester, then inject every absent far label into the same top budget. -/
theorem choose_even_tester {β : ℝ} {n a c p : ℕ} {B : Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (ha:0<a) (hac:a<c) (he:a+c≤n/4/64) (hp₀:3*(n/4)≤8*p) (hp₁:2*p≤n/4)
    (hop:p%2=1) (heven:a%2=0 ∧ c%2=0) :
    ∃ b, c<b ∧ 4*b<p ∧ b%2=1 ∧ b∈quarterD n B ∧ a+b∈quarterD n B ∧
      c+b∈quarterD n B ∧ p+4*b∈B := by
  classical
  let N:=n/4/64;let G:=evenPairTesters n a c B
  let Z:=G.erase (2*N+1)
  have hc:=ee_margin β n a c B hd hg (by omega) ha (by omega) he heven
  have hΓ:=common_inventory n B
  have hΓ':(T_loss n B:ℝ)≤lambdaBudget n B:=by exact_mod_cast (show T_loss n B≤lambdaBudget n B by omega)
  have hlog:(0:ℝ)≤logLevels (n/4):=by positivity
  have hNat : T_loss n B+1<G.card := by
    apply_mod_cast (show (T_loss n B:ℝ)+1<(evenPairTesters n a c B).card by
      have hnn:(0:ℝ)≤lambdaBudget n B:=by positivity
      linarith only [hΓ',hc,hl,hlog,hnn])
  have hsubset : G⊆insert (2*N+1) Z := by
    intro x hx;by_cases heq:x=2*N+1
    · exact mem_insert.mpr (Or.inl heq)
    · exact mem_insert_of_mem (mem_erase.mpr ⟨heq,hx⟩)
  have her:=card_le_card hsubset
  have hbon:=card_insert_le (2*N+1) Z
  have hz: T_loss n B < Z.card := by
    change G.card≤(insert (2*N+1) Z).card at her;omega
  have hh b (hb:b∈Z) : c<b ∧ 4*b<p ∧ b%2=1 ∧ b∈quarterD n B ∧
       a+b∈quarterD n B ∧ c+b∈quarterD n B ∧ n/4/2<p+4*b ∧ p+4*b≤n/4 := by
    obtain ⟨hne,hG⟩:=mem_erase.mp hb
    obtain ⟨hw,ht⟩:=mem_filter.mp hG
    have hw':=oddTestWindow_mem hw
    change 2*N<b ∧ b≤3*N+1 ∧ b%2=1 at hw'
    have hsmall: c≤N:=by dsimp [N];omega
    have hfloor:64*N≤n/4 ∧ n/4≤64*N+63:=by dsimp [N]; omega
    refine ⟨by omega,by omega,hw'.2.2,?_,?_,?_,by omega,by omega⟩
    · simpa using ht 0 (by simp)
    · simpa [Nat.add_comm] using ht a (by simp)
    · simpa [Nat.add_comm] using ht c (by simp)
  have hex:∃ b∈Z,p+4*b∈B:=by
    by_contra! hn
    have hh' : Z.card≤(absentTop n B).card:=by
      apply card_le_card_of_injOn (fun b=>p+4*b)
      · intro b hb;have u:=hh b hb
        change p+4*b∈absentTop n B
        exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨u.2.2.2.2.2.2.1,u.2.2.2.2.2.2.2⟩,by omega,hn b hb⟩
      · intro x hx y hy h;dsimp at h;omega
    have :=absent_top_cost n B hd;omega
  obtain ⟨b,hb,hfar⟩:=hex
  obtain ⟨h1,h2,h3,h4,h5,h6,_⟩:=hh b hb
  exact ⟨b,h1,h2,h3,h4,h5,h6,hfar⟩

theorem standard_partner_width {β : ℝ} {n p : ℕ} {B : Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (hpp:p+4*(n/4/64)≤n/4/2) :
    A_loss n B+3*T_loss n B <
      (progression (n/4/2) (n/4-p) 8 ((12-p%8)%8)).card := by
  have hr:= (signed_supply β n B hd hg (by omega) hl).2.1
  have he: (6:ℝ)*(lambdaBudget n B:ℝ)+6000<(n/4/64:ℕ) := by
    have hnon:(0:ℝ)≤(midOddLoss n B).card:=by positivity
    linarith only [hr,hnon]
  have he':6*lambdaBudget n B+6000<n/4/64:=by exact_mod_cast he
  have hsum:=common_inventory n B
  have hprog:=progression_lower (n/4/2) (n/4-p) 8 ((12-p%8)%8) (by decide) (by omega)
  omega

/-- At a retained pair an odd winner keeps its fixed rigid tester; an even
winner chooses an odd tester from the actual surviving family. Both paths
produce the same five-clique profile with all ten edges. -/
theorem complete_winning_pair {β : ℝ} {n e a w p : ℕ} {B : Finset ℕ}
    (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (hscale:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (he:e∈smallSupport n B) (he₂:e%2=0) (hw:w∈rigidPresent (n/4/64) (quarterD n B))
    (ha:a∈retainedEndpoints n B e (4*w)) (hp₀:3*(n/4)≤8*p) (hp₁:2*p≤n/4)
    (hop:p%2=1) (hpp:p∈B) (hpa:p+4*a∈B) (hpc:p+4*(e-a)∈B) (hfar:p+4*(4*w)∈B)
    (hwidth:A_loss n B+3*T_loss n B <
      (progression (n/4/2) (n/4-p) 8 ((12-p%8)%8)).card) :
    ∃ b χ, p%4≠χ%4 ∧ χ%2=1 ∧
      InternalFive (B∩Icc 1 (n/4)) {4*a,4*(e-a),4*b,p,χ} := by
  obtain ⟨hef,hqual⟩:=mem_filter.mp ha
  obtain ⟨haS,ha₀,hac,hcS⟩:=mem_filter.mp hef
  have heN: e≤n/4/64:=(mem_Icc.mp (mem_inter.mp he).2).2
  have hr:=rigid_bounds (mem_filter.mp hw).1
  have hsum:a+(e-a)=e:=by omega
  have hb:∃ b, e-a<b ∧ 4*b<p ∧ (a%2=1 ∨ b%2=1) ∧ b∈quarterD n B ∧
      a+b∈quarterD n B ∧ (e-a)+b∈quarterD n B ∧ p+4*b∈B:=by
    by_cases heven:a%2=0
    · obtain ⟨b,h₁,h₂,h₃,h₄,h₅,h₆,h₇⟩:=choose_even_tester hd hg hscale hl ha₀ hac
        (by omega) hp₀ hp₁ hop ⟨heven,by omega⟩
      exact ⟨b,h₁,h₂,Or.inr h₃,h₄,h₅,h₆,h₇⟩
    · have hh:=hqual.resolve_left heven
      exact ⟨4*w,by omega,by omega,Or.inl (by omega),(mem_filter.mp hw).2,
        by simpa [Nat.add_comm] using hh.1,by simpa [Nat.add_comm] using hh.2,hfar⟩
  obtain ⟨b,hcb,hbp,hpar,hrb,hrab,hrcb,hpb⟩:=hb
  obtain ⟨χ,hhalf,hcap,hχ,hopp,hχB,hχa,hχc,hχb,hχp⟩ :=
    select_partner n a (e-a) b p B hd hac hcb hbp hp₁ hop hpar hwidth
  exact ⟨b,χ,Ne.symm hopp,hχ,actual_five n a (e-a) b p χ B ha₀ hac hcb hbp (by omega) hcap
     (mem_inter.mp haS).1 (mem_inter.mp hcS).1 hrb (hsum.symm ▸ (mem_inter.mp he).1)
     hrab hrcb hpp hpa hpc hpb hχB hχa hχc hχb hχp⟩

end OP02.SharpK7

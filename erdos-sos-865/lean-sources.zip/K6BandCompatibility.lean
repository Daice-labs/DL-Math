import K6BandSupply
import K6BandBudgets
import K6BandArithmetic
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 1000000

/-- Opposite-residue common neighbors are excluded by injecting the entire
first-band supply into the same doubled-gap resource union. -/
theorem opposite_neighbors_empty (n u σ:ℕ) (B S T:Finset ℕ)
    (hn:65536≤n) (hf:SixFree B) (hd:DoublingFree B) (hq:512*totalBudget n B≤n)
    (hg:MiddleGap6 n B)
    (hu:2*u<n) (hσ:σ=1 ∨ σ=3) (hS:S⊆Icc 1 n)
    (hT:T⊆quarterD n B) (hTc:T.card=3)
    (hTp:∀x∈T,∀y∈T,x≠y → x+y∈quarterD n B)
    (hsmall:∀t∈T,t≤n/16)
    (hband:(forcedBand n S u σ\B).card≤bandCost n σ B) :
    bandNeighbors n (4-σ) B T=∅ := by
  classical
  have hsup:=first_band_supply n u σ B S T (by omega) (by omega) hd hu hσ hS hTc hsmall
  have hb:=band_budget n σ B hd hσ
  have hmany:(fourResources n B).card<(bandNeighbors n σ B T).card := by omega
  apply eq_empty_iff_forall_notMem.mpr
  intro z hz
  obtain ⟨hzM,hzσ,hzall,hzL,hzU⟩:=mem_filter.mp hz
  have hzin:=mem_Icc.mp (mem_inter.mp hzM).2
  have hz7:4*z≤7*n := le_of_lt (gap_domain n z (by omega) (by omega))
  have hc:(bandNeighbors n σ B T).card≤(fourResources n B).card := by
    apply card_le_card_of_injOn (fun y=>y+z)
    · intro y hy
      obtain ⟨hyM,hyσ,hyall,hyL,hyU⟩:=mem_filter.mp hy
      have hyo:y%2=1 := by omega
      have hzo:z%2=1 := by omega
      have hy7:4*y≤7*n := le_of_lt (gap_domain n y (by omega) (by omega))
      have hyz:y≠z := by omega
      have hy0: y∈B := (mem_inter.mp hyM).1
      have hz0: z∈B := (mem_inter.mp hzM).1
      have hbad:y+z∉B := by
        intro hsum
        exact gap_triangle_neighborhood n y z B T hf hd hg hn (by omega) hy0 hz0 hyz hyo hzo hy7 hz7 hsum hT hTc hsmall hTp (fun t ht=>⟨hyall t ht,hzall t ht⟩)
      exact missing_in_doubled_gap6 n (y+z) B hg (by omega) hbad (by omega) (by omega)
    · intro x hx y hy he
      change x+z=y+z at he
      omega
  omega

/-- The second band supplies the quantitative high-vertex conclusion. Every
clipped candidate is either a common neighbor or fails an actual band membership. -/
theorem high_vertex_from_empty (n v σ:ℕ) (B S T:Finset ℕ)
    (hn:65536≤n) (hq:512*totalBudget n B≤n) (hd:DoublingFree B)
    (hv:v≤n) (hσ:σ=1 ∨ σ=3) (hS:S⊆Icc 1 n) (hTc:T.card=3) (hsmall:∀t∈T,t≤n/16)
    (hband:(forcedBand n S v σ\B).card≤bandCost n σ B)
    (hempty:bandNeighbors n σ B T=∅) : n-v≤highThreshold n B := by
  classical
  let τ:=4*(missingTopOdd n B).card+4
  let W:=n-4*(n/16)
  let L:=max (n+v/2) (n+τ)
  let U:=min (n+v/2+n/4) (2*W-τ-1)
  let Y:=progression L U 4 σ
  have hY (y:ℕ) (hy:y∈Y) : n+v/2<y ∧ y≤n+v/2+n/4 ∧ n+τ<y ∧ y<2*W-τ ∧ y%4=σ := by
    obtain ⟨hyI,hyσ⟩:=mem_filter.mp hy
    have hyI:=mem_Ioc.mp hyI
    dsimp only [L,U] at hyI
    have hhiq:(missingTopOdd n B).card≤totalBudget n B := by
      have hh:=deficit_split n B hd
      unfold totalBudget; omega
    dsimp only [W,τ] at *
    omega
  have hF:∀y∈Y,∀t∈insert 0 T,y+4*t∈forcedBand n S v σ := by
    intro y hy t ht
    have hyI:=hY y hy
    have htB:t≤n/16 := by
      rcases mem_insert.mp ht with rfl|ht
      · omega
      · exact hsmall t ht
    simp only [forcedBand,mem_filter,mem_Icc]
    refine ⟨⟨by omega,by omega⟩,by omega,?_,by omega⟩
    intro a ha
    rcases mem_insert.mp ha with rfl|ha
    · omega
    · have haI:=mem_Icc.mp (hS ha); omega
  let G:=Y.filter (fun y=>∀t∈insert 0 T,y+4*t∈B)
  have hG:G=∅ := by
    apply eq_empty_iff_forall_notMem.mpr
    intro y hy
    obtain ⟨hyY,hall⟩:=mem_filter.mp hy
    have hyB:y∈B := by simpa using hall 0 (by simp)
    have hyI:=hY y hyY
    have hh:y∈bandNeighbors n σ B T := by
      refine mem_filter.mpr ⟨mem_inter.mpr ⟨hyB,mem_Icc.mpr ⟨by omega,by omega⟩⟩,
        hyI.2.2.2.2,(fun t ht=>hall t (mem_insert_of_mem ht)),hyI.2.2.1,hyI.2.2.2.1⟩
    rw [hempty] at hh
    simpa using hh
  have hloss:=four_membership_loss Y (forcedBand n S v σ) B T σ hTc
    (fun y hy=>(hY y hy).2.2.2.2) hF
  change Y.card≤G.card+4*(forcedBand n S v σ\B).card at hloss
  rw [hG,card_empty,zero_add] at hloss
  have hl:=progression_lower L U 4 σ (by omega) (by omega)
  change (U-L)/4≤Y.card at hl
  have hb:=band_budget n σ B hd hσ
  have hc:(U-L)/4≤4*bandCost n σ B := by omega
  have hh:=second_band_arithmetic n v (missingTopOdd n B).card (bandCost n σ B) (totalBudget n B)
    hn hv hq hb.2.2.1 hc
  unfold highThreshold
  omega

#print axioms opposite_neighbors_empty
#print axioms high_vertex_from_empty
end OP02.SharpK6

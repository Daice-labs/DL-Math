import K7StrongBudget
import K5Profile
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7

theorem inventory_uniform (β:ℝ) (hb:0<β) : ∃u:ℕ,∀n:ℕ,u≤n→∀B:Finset ℕ,DoublingFree B→
    (85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ) →
    384*(chainDeficit n B+totalBudget n B)≤n/4 ∧ 65536≤n := by
  obtain ⟨u,hu⟩:=capacity_uniform_error β hb
  refine ⟨max 65536 (4*u),?_⟩
  intro n hn B hd hg
  have hcap:=hu (n/4) (by omega)
  have htop:=chain_capacity_with_top_loss (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  have hnat : chainDeficit n B+(quarterD n B).card=chainCapacity (n/4):=by unfold chainDeficit;omega
  have hr:(chainDeficit n B:ℝ)+(quarterD n B).card=chainCapacity (n/4):=by exact_mod_cast hnat
  have hbn : (4:ℝ)*(n/4:ℕ)≤n:=by exact_mod_cast (show 4*(n/4)≤n by omega)
  have hbn':((n/4:ℕ):ℝ)≤n:=by exact_mod_cast (show n/4≤n by omega)
  have h':(384:ℝ)*((chainDeficit n B:ℝ)+totalBudget n B)≤(n/4:ℕ):=by
    nlinarith only [hcap,hr,hg,hbn,mul_nonneg hb.le (sub_nonneg.mpr hbn')]
  exact ⟨by exact_mod_cast h',by omega⟩

def cleanResidue (O:Finset ℕ) (r:ℕ) : Prop := r<4 ∧
  (∀s∈O,(r+s)%4≠2) ∧ (O.filter (fun s=>(r+s)%2=0)).card≤3

/-- An inner high label is an odd singleton or four times an actual
canonical root in the top half. Both loss maps are injective. -/
theorem canonical_lower_losses (n:ℕ) (B:Finset ℕ) (hd:DoublingFree B) :
    ((Ioc (n/2) n).filter (fun v=>canonical v=true ∧ v∉B)).card ≤
      chainDeficit n B+totalBudget n B := by
  classical
  let E:=missingTopOdd n B
  let T:=topMissing (n/4) (quarterD n B)
  have hc:=chain_capacity_with_top_loss (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd)
  have ht:T.card≤chainDeficit n B:=by dsimp [chainDeficit,T];omega
  have he:E.card≤totalBudget n B:=by have := missingTopOdd_le_deficit n B hd;unfold totalBudget E;omega
  have hsub:(Ioc (n/2) n).filter (fun v=>canonical v=true ∧ v∉B)⊆
      E∪T.image (fun r=>4*r):=by
    intro v hv
    obtain ⟨hi,hcan,habs⟩:=mem_filter.mp hv
    obtain ⟨hl,hu⟩:=mem_Ioc.mp hi
    by_cases ho:v%2=1
    · exact mem_union_left _ (mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,hu⟩,ho⟩,by omega,habs⟩)
    · have hc₂:v%4≠2:=by
        intro htwo
        have hp:0<v/2:=by omega
        have hdd:=canonical_double (v/2) hp
        rw [show 2*(v/2)=v by omega,hcan,canonical_odd _ (by omega)] at hdd
        cases hdd
      have h4:4*(v/4)=v:=by omega
      have hcr:=canonical_four (v/4)
      rw [h4,hcan] at hcr
      apply mem_union_right
      apply mem_image.mpr
      refine ⟨v/4,mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hcr.symm⟩,
        by omega,?_⟩,h4⟩
      exact fun hh=>habs (h4 ▸ (mem_filter.mp hh).2)
  exact (card_le_card hsub).trans ((card_union_le _ _).trans (by have := card_image_le (s:=T) (f:=fun r=>4*r);omega))

/-- For either physical band, one canonical residue class controls all
offsets. This conclusion leaves no membership check on the chosen vertex. -/
private theorem shifted_choice (lo hi r L:ℕ) (B O E:Finset ℕ) (hO:cleanResidue O r)
    (hsize:O.card≤L) (hrange:∀x,lo<x→x≤hi→∀s∈O,canonical (x+s)=true→x+s∉B→x+s∈E)
    (hcnt:L*E.card<(hi-lo)/32) :
    ∃x,lo<x ∧ x≤hi ∧ x%4=r ∧ ∀s∈O,x+s∈B := by
  obtain ⟨v,hv,hvr,hcan⟩:=canonical_profile_class O r hO.1 hO.2.1 hO.2.2
  let J:=progression lo hi 32 v
  have hm x (hx:x∈J):lo<x ∧ x≤hi ∧ x%32=v :=⟨(mem_Ioc.mp (mem_filter.mp hx).1).1,
    (mem_Ioc.mp (mem_filter.mp hx).1).2,(mem_filter.mp hx).2⟩
  have hbound:=shift_losses J O B E 1 0 L (by intro _ _;omega)
    (by intro x hx s hs hh;have hx':=hm x hx;exact hrange x hx'.1 hx'.2.1 s hs (hcan x hx'.2.2 s hs) hh)
    (fun _ _=>(card_filter_le _ _).trans hsize)
  have hlen:=progression_lower lo hi 32 v (by decide) hv
  change _≤J.card at hlen
  obtain ⟨x,hx⟩:=card_pos.mp (show 0<(passes J O B).card by omega)
  have hh:=hm x (mem_filter.mp hx).1
  exact ⟨x,hh.1,hh.2.1,by omega,(mem_filter.mp hx).2⟩

theorem two_clean_residues {n r:ℕ} {B S:Finset ℕ} (hf:SevenFree B) (hd:DoublingFree B)
    (hcap:384*(chainDeficit n B+totalBudget n B)≤n/4) (hn:65536≤n)
    (hs:InternalFive (B∩Icc 1 (n/4)) S)
    (hfirst:cleanResidue (insert 0 S) r)
    (hnext:∀y,y%4=r→∃r',cleanResidue (insert y (insert 0 S)) r') : False := by
  classical
  obtain ⟨h5,hsub,hedge⟩:=hs
  let O:=insert 0 S
  have hO:O.card≤6:=by dsimp [O];have :=card_insert_le 0 S;omega
  have hsmall s (hs:s∈O):s≤n/4:=by rcases mem_insert.mp hs with rfl|hs;omega;exact (mem_Icc.mp (mem_inter.mp (hsub hs)).2).2
  let L:=(Ioc (n/2) n).filter (fun v=>canonical v=true ∧ v∉B)
  have hL:=canonical_lower_losses n B hd
  change L.card≤_ at hL
  obtain ⟨y,hy₁,hy₂,hyr,hyl⟩:=shifted_choice (n/2) (3*n/4) r 6 B O L hfirst hO
    (by intro x h1 h2 s hs hc hn;have hh:=hsmall s hs
        exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,hc,hn⟩) (by omega)
  obtain ⟨r',hr'⟩:=hnext y hyr
  let U:=insert y O
  have hU:U.card≤7:=by dsimp [U];have :=card_insert_le y O;omega
  have hmid s (hs:s∈U):s≤n:=by
    rcases mem_insert.mp hs with he|hs
    · omega
    · have :=hsmall s hs;omega
  have hE:=canonical_hole_total_budget n B hd
  have hh:(canonicalHoles n B).card≤chainDeficit n B+totalBudget n B:=by unfold totalBudget;omega
  obtain ⟨p,hp₁,hp₂,_,hpl⟩:=shifted_choice (2*n) (3*n) r' 7 B U (canonicalHoles n B) hr' hU
    (by intro x h1 h2 s hs hc hn;have hh:=hmid s hs
        exact mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,hn⟩,hc⟩) (by omega)
  let V:=insert y S
  have hyB:y∈B:=by simpa using hyl 0 (mem_insert_self _ _)
  have hpB:p∈B:=by simpa using hpl 0 (mem_insert_of_mem (mem_insert_self _ _))
  have hyS:y∉S:=fun hs=>by have :=hsmall y (mem_insert_of_mem hs);omega
  have hpV:p∉V:=by intro hp;have hh:=hmid p (by rcases mem_insert.mp hp with he|hs;exact mem_insert.mpr (Or.inl he);exact mem_insert_of_mem (mem_insert_of_mem hs));omega
  have hhS:S⊆B:=fun _ h=>(mem_inter.mp (hsub h)).1
  have vv:∀x∈V,∀z∈V,x≠z→x+z∈B:=by
    intro x hx z hz hxz
    rcases (mem_insert.mp hx : x=y ∨ x∈S) with he|h1 <;> rcases (mem_insert.mp hz : z=y ∨ z∈S) with he'|h2
    · exact False.elim (hxz (he.trans he'.symm))
    · rw [he];exact hyl z (mem_insert_of_mem h2)
    · rw [he',Nat.add_comm];exact hyl x (mem_insert_of_mem h1)
    · exact (mem_inter.mp (hedge x h1 z h2 hxz)).1
  apply hf;refine ⟨insert p V,insert_subset hpB (insert_subset hyB hhS),by simp [hpV,V,hyS,h5],?_⟩
  intro x hx z hz hxz
  have vU:V⊆U:=by
    intro t ht
    rcases (mem_insert.mp ht : t=y∨t∈S) with he|hS
    · exact mem_insert.mpr (Or.inl he)
    · exact mem_insert_of_mem (mem_insert_of_mem hS)
  rcases (mem_insert.mp hx : x=p ∨ x∈V) with he|h1 <;> rcases (mem_insert.mp hz : z=p ∨ z∈V) with he'|h2
  · exact False.elim (hxz (he.trans he'.symm))
  · rw [he];exact hpl z (vU h2)
  · rw [he',Nat.add_comm];exact hpl x (vU h1)
  · exact vv x h1 z h2 hxz

end OP02.SharpK7

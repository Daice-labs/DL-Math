import K8RothStarts
import K8RothCube

namespace OP02.Midpoint
/-- Finite positive-density midpoint configurations of order eight from Roth's theorem. -/
theorem dousse8 : OP02.SharpK8.Dousse8 :=
  dousse8_of_popular popular_bounded_step
end OP02.Midpoint

namespace OP02.SharpK8
/-- The sharp limit for the original threshold without an external midpoint premise. -/
theorem sharpK8 : SharpK8Limit := sharpK8_of_dousse8 OP02.Midpoint.dousse8
end OP02.SharpK8

import K5CanonicalHoles
open Finset
namespace OP02.SharpK5
set_option maxHeartbeats 3000000

def progression (L U m r:ℕ) := (Ioc L U).filter (fun x=>x%m=r)

/-- Exact physical arithmetic-progression count, retaining both endpoint floors. -/
theorem progression_card (L U m r:ℕ) (hm:m=4 ∨ m=8 ∨ m=32) (hr : r < m) :
    (progression L U m r).card=(U+m-r)/m-(L+m-r)/m := by
  classical
  have he : (progression L U m r).card=(Ioc ((L+m-r)/m) ((U+m-r)/m)).card := by
    apply card_bij (fun x _=>(x+m-r)/m)
    · intro x hx
      obtain ⟨hxI,hxr⟩ := mem_filter.mp hx
      obtain ⟨hxL,hxU⟩ := mem_Ioc.mp hxI
      apply mem_Ioc.mpr
      rcases hm with rfl|rfl|rfl <;> omega
    · intro x hx y hy hxy
      obtain ⟨hxI,hxr⟩ := mem_filter.mp hx
      obtain ⟨hyI,hyr⟩ := mem_filter.mp hy
      rcases hm with rfl|rfl|rfl <;> omega
    · intro j hj
      obtain ⟨hjL,hjU⟩ := mem_Ioc.mp hj
      refine ⟨m*(j-1)+r,?_,?_⟩
      · apply mem_filter.mpr
        refine ⟨mem_Ioc.mpr ⟨?_,?_⟩,?_⟩ <;> rcases hm with rfl|rfl|rfl <;> omega
      · rcases hm with rfl|rfl|rfl <;> omega
  rw [he,Nat.card_Ioc]

theorem progression_lower (L U m r:ℕ) (hm:m=4 ∨ m=8 ∨ m=32) (hr : r < m) :
    (U-L)/m≤(progression L U m r).card := by
  rw [progression_card L U m r hm hr]
  rcases hm with rfl|rfl|rfl <;> omega

theorem progression_upper (L U m r:ℕ) (hm:m=4 ∨ m=8 ∨ m=32) (hr : r < m) :
    (progression L U m r).card≤(U-L)/m+1 := by
  rw [progression_card L U m r hm hr]
  rcases hm with rfl|rfl|rfl <;> omega

/-- The small residue selection used for three even labels is kernel evaluated,
not a numerical witness assumed for arbitrary offsets. -/
theorem three_residue_selection : ∀a b c:Fin 8,∃r:Fin 8,
    (r.val+a.val)%8∈({1,3,4,5,7}:Finset ℕ) ∧
    (r.val+b.val)%8∈({1,3,4,5,7}:Finset ℕ) ∧
    (r.val+c.val)%8∈({1,3,4,5,7}:Finset ℕ) := by decide

theorem canonical_four_residue (x:ℕ) (hx:x%8=4) : canonical x=true := by
  have he:4*(x/4)=x := by omega
  rw [←he,canonical_four]
  exact canonical_odd (x/4) (by omega)

theorem canonical_selected (x r:ℕ) (hx:x%4=0)
    (hr:(x/4)%8∈({1,3,4,5,7}:Finset ℕ)) : canonical x=true := by
  have he:4*(x/4)=x := by omega
  rw [←he,canonical_four]
  simp only [mem_insert,mem_singleton] at hr
  rcases hr with h|h|h|h|h
  · exact canonical_odd _ (by omega)
  · exact canonical_odd _ (by omega)
  · exact canonical_four_residue _ h
  · exact canonical_odd _ (by omega)
  · exact canonical_odd _ (by omega)

#print axioms progression_card
#print axioms progression_lower
#print axioms progression_upper
#print axioms three_residue_selection
#print axioms canonical_selected
end OP02.SharpK5

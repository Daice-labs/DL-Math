import K6GoodTriangle
import K6GapReduction
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 3000000

/-- The strict canonical margin is derived from the actual positive-gap hypothesis. -/
theorem positive_gap_canonical_margin (β:ℝ) (hβ:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,DoublingFree B→PositiveGap6 β n B→
    3*(canonicalHoles n B).card<n/128 := by
  obtain ⟨N,hN⟩:=positive_gap_canonical_budget6 β hβ
  obtain ⟨M,hM⟩:=exists_nat_gt (2/β)
  refine ⟨max N M,?_⟩
  intro n hn B hd hgap
  have hc:=canonical_hole_total_budget n B hd
  have hb:=hN n (by omega) B hd hgap
  have hMr:(M:ℝ)≤n:=by exact_mod_cast (show M≤n by omega)
  have hbn:(2:ℝ)<β*n:=by
    have hh:2/β<(n:ℝ):=lt_of_lt_of_le hM hMr
    have := (div_lt_iff₀ hβ).mp hh
    nlinarith
  have hcr:((canonicalHoles n B).card:ℝ)≤chainDeficit n B+deficit n B+(excessHoles n B).card := by exact_mod_cast hc
  have hfloor:(n:ℝ)<128*(n/128:ℕ)+128 := by exact_mod_cast (show n<128*(n/128)+128 by omega)
  have hr:(3:ℝ)*(canonicalHoles n B).card<(n/128:ℕ) := by
    push_cast at hb
    nlinarith
  exact_mod_cast hr

/-- Actual qualified vertices and ambient D labels, with no free budget premise. -/
theorem positive_gap_excludes_good_triangles (β:ℝ) (hβ:0<β) :
    ∃n₀:ℕ,∀n:ℕ,n₀≤n→∀B:Finset ℕ,SixFree B→DoublingFree B→PositiveGap6 β n B→
    ∀u∈lower n B,∀v∈lower n B,u≠v→u%2=1→v%2=1→u+v∈B→
    ∀T:Finset ℕ,T⊆quarterD n B→T.card=3→
    (∀x∈T,∀y∈T,x≠y→x+y∈quarterD n B)→
    (∀x∈T,u+4*x∈B ∧ v+4*x∈B)→
    ¬(∃j<4,∀s∈insert 0 T,s%4≠j) := by
  obtain ⟨N,hN⟩:=positive_gap_canonical_margin β hβ
  refine ⟨N,?_⟩
  intro n hn B hf hd hgap u hu v hv huv huo hvo hsum T hT hTc hpair hqual hgood
  exact good_triangle_excluded n u v B T hf hu hv huv huo hvo hsum hT hTc hpair hqual hgood (hN n hn B hd hgap)

#print axioms positive_gap_canonical_margin
#print axioms positive_gap_excludes_good_triangles
end OP02.SharpK6

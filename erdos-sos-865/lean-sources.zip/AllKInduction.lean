import AllKProjection

open Finset OP02.FewHole OP02.SharpK5
namespace OP02.AllOrders

/-- Window selections with both cliques in the same physical set A. The threshold
depends on the order alone; the original density tolerance enters at projection. -/
def GeometricStep (k : ℕ) : Prop :=
  ∃ M : ℕ, ∀ T : ℕ, M ≤ T → ∀ A : Finset ℕ, A ⊆ Icc 1 T → DoublingFree A →
    ((chainCapacity T-A.card:ℕ):ℝ) < (2/3-coeff k)*(T:ℝ) →
    ∀ (F : Finset ℕ) (f : ℕ) (W : Finset ℕ) (z : ℕ),
      ShapeAt (k-1) (T/4) A F f → ShapeAt (k-2) (T/4) A W z →
      (∀ w∈W,w%4=0) → ∃ S Z, ShapeAt k T A S Z

theorem shaped_of_geometry {k : ℕ} (hk : 8 ≤ k) (geom : GeometricStep k)
    (prev2 : Shaped (k-2)) (prev1 : Shaped (k-1)) : Shaped k := by
  intro η hη
  obtain ⟨M,hm⟩ := projected_inputs hk prev2 prev1 η hη
  obtain ⟨G,hg⟩ := geom
  refine ⟨max M G,?_⟩
  intro T ht A sub df count
  obtain ⟨budget,F,f,W,z,seed,core,div4⟩ := hm T (by omega) A sub df count
  exact hg T (by omega) A sub df budget F f W z seed core div4

theorem shaped_induction (step : ∀ k, 8 ≤ k → Shaped (k-2) → Shaped (k-1) → Shaped k) :
    ∀ k : ℕ, 6 ≤ k → Shaped k := by
  intro k
  induction k using Nat.strong_induction_on with
  | h k ih =>
    intro hk
    rcases eq_or_lt_of_le hk with rfl|h6
    · exact shaped_six
    rcases eq_or_lt_of_le (show 7≤k by omega) with rfl|h7
    · exact shaped_seven
    exact step k (by omega) (ih (k-2) (by omega) (by omega)) (ih (k-1) (by omega) (by omega))

end OP02.AllOrders

import K6BandCompatibility
import K6CanonicalProfiles
open Finset
namespace OP02.SharpK6
open OP02.SharpK5 OP02.FewHole OP02.SmallExcess OP02.PivotAudit OP02.PositivePivot
set_option maxHeartbeats 1000000

/-- Both bands of the same actual clique force its designated high vertex.
All partner supply and clipping losses have been discharged in the preceding lemmas. -/
theorem designated_high_vertex (n u v:ℕ) (B S T:Finset ℕ)
    (hn:65536≤n) (hf:SixFree B) (hd:DoublingFree B) (hq:512*totalBudget n B≤n)
    (hg:MiddleGap6 n B)
    (hS:S⊆lower n B) (hc:S.card=5)
    (hp:∀x∈S,∀y∈S,x≠y→x+y∈B)
    (hu:u∈insert 0 S) (hv:v∈insert 0 S) (hul:2*u<n)
    (hres:(u+2)%4=v%4)
    (hother:∀x∈insert 0 S\{u,v},x%2≠u%2)
    (hload:∀j:ℕ,((insert 0 S\{u,v}).filter (fun x=>x%4=j)).card≤4)
    (hT:T⊆quarterD n B) (hTc:T.card=3)
    (hTp:∀x∈T,∀y∈T,x≠y → x+y∈quarterD n B)
    (hsmall:∀t∈T,t≤n/16) : n-v≤highThreshold n B := by
  have hSI:S⊆Icc 1 n := fun x hx=>(mem_inter.mp (hS hx)).2
  have hvn:v≤n := by
    rcases mem_insert.mp hv with rfl|hh
    · omega
    · exact (mem_Icc.mp (hSI hh)).2
  obtain ⟨σ,hσ,hσres⟩ : ∃σ:ℕ,(σ=1 ∨ σ=3) ∧ (2*σ+v)%8=(u+4)%8 := by
    by_cases hh:(2+v)%8=(u+4)%8
    · exact ⟨1,Or.inl rfl,by omega⟩
    · exact ⟨3,Or.inr rfl,by omega⟩
  have hband1:=forced_band_bound n u v σ B S hf hS hc hp hu hv hσ hσres hother hload
  change (forcedBand n S u σ\B).card≤bandCost n σ B at hband1
  have hempty:=opposite_neighbors_empty n u σ B S T hn hf hd hq hg hul hσ hSI
    hT hTc hTp hsmall hband1
  have hσ2:4-σ=1 ∨ 4-σ=3 := by omega
  have hres2:(2*(4-σ)+u)%8=(v+4)%8 := by omega
  have hother2:∀x∈insert 0 S\{v,u},x%2≠v%2 := by
    intro x hx
    have hh:=hother x (by simpa only [pair_comm] using hx)
    omega
  have hload2:∀j:ℕ,((insert 0 S\{v,u}).filter (fun x=>x%4=j)).card≤4 := by
    intro j; simpa only [pair_comm] using hload j
  have hband2:=forced_band_bound n v u (4-σ) B S hf hS hc hp hv hu hσ2 hres2 hother2 hload2
  change (forcedBand n S v (4-σ)\B).card≤bandCost n (4-σ) B at hband2
  exact high_vertex_from_empty n v (4-σ) B S T hn hq hd hvn hσ2 hSI hTc hsmall hband2 hempty


#print axioms designated_high_vertex
end OP02.SharpK6

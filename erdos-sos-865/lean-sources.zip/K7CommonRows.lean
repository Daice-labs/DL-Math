import K7BridgeSeed
import K7EndpointLedger
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5 OP02.PivotAudit
namespace OP02.SharpK7
set_option maxHeartbeats 1200000

private theorem list_odd_anchors {S:Finset ℕ}
    (hc:(oddOffsets S).card=2 ∨ (oddOffsets S).card=3) (hn:¬sameOdd S):
    ∃u v w:ℕ,oddOffsets S={u,v,w} ∧ w%2=1 ∧
      ∀x∈S,x%2=1→x≠w→x%4≠w%4 :=by
  classical
  have mono {u:ℕ} (uo:u%2=1) (h:∀x∈oddOffsets S,x%4=u%4):False:=by
    exact hn ⟨u%4,by omega,by omega,fun x hx ho=>h _ (mem_filter.mpr ⟨hx,ho⟩)⟩
  rcases hc with h|h
  · obtain ⟨p,q,ne,eq⟩:=card_eq_two.mp h
    have po:p%2=1:=(mem_filter.mp (show p∈oddOffsets S by simp [eq])).2
    have op:p%4≠q%4:=by
      intro e;apply mono po;intro x hx;simp only [eq,mem_insert,mem_singleton] at hx;omega
    refine ⟨q,q,p,by ext x;simp only [eq,mem_insert,mem_singleton];tauto,po,?_⟩
    intro x hx ho ne;have xo:x∈oddOffsets S:=mem_filter.mpr ⟨hx,ho⟩
    simp only [eq,mem_insert,mem_singleton] at xo;omega
  · obtain ⟨p,q,r,_,_,_,eq⟩:=card_eq_three.mp h
    have po:p%2=1:=(mem_filter.mp (show p∈oddOffsets S by simp [eq])).2
    have qo:q%2=1:=(mem_filter.mp (show q∈oddOffsets S by simp [eq])).2
    have ro:r%2=1:=(mem_filter.mp (show r∈oddOffsets S by simp [eq])).2
    have ex:¬(p%4=q%4 ∧ p%4=r%4):=by
      intro e;apply mono po;intro x hx;simp only [eq,mem_insert,mem_singleton] at hx;omega
    have mem {x:ℕ} (hx:x∈S) (o:x%2=1):x=p ∨ x=q ∨ x=r:=by
      have hh:x∈oddOffsets S:=mem_filter.mpr ⟨hx,o⟩;simpa only [eq,mem_insert,mem_singleton] using hh
    by_cases pq:p%4=q%4
    · exact ⟨p,q,r,eq,ro,by intro x hx o ne;have :=mem hx o;omega⟩
    by_cases pr:p%4=r%4
    · exact ⟨p,r,q,by ext x;simp only [eq,mem_insert,mem_singleton];tauto,qo,
        by intro x hx o ne;have :=mem hx o;omega⟩
    · exact ⟨q,r,p,by ext x;simp only [eq,mem_insert,mem_singleton];tauto,po,
        by intro x hx o ne;have :=mem hx o;omega⟩

theorem bridge_rows_of_dispatch (hD:Dousse7) {i:ℕ} (hi:i=5 ∨ i=14):RowExclusion i :=by
  classical
  intro β hb
  obtain ⟨U,hU⟩:=bridge_seed_exclusion hD hb
  refine ⟨U,?_⟩;intro n hn B _ hf hd hg S hs row
  have facts:((oddOffsets S).card=2 ∨ (oddOffsets S).card=3) ∧ ¬sameOdd S ∧
      (twoOffsets S).card=1 ∧ largest (twoOffsets S)≠largest S:=by
    unfold rowNumber at row;dsimp only at row
    split_ifs at row <;> first | omega | exact ⟨by omega,by assumption,by assumption,by assumption⟩
  obtain ⟨u,v,w,oddset,wo,single⟩:=list_odd_anchors facts.1 facts.2.1
  obtain ⟨t,tset⟩:=card_eq_one.mp facts.2.2.1
  have tT:t∈twoOffsets S:=by simp [tset]
  obtain ⟨ts,tp⟩:=mem_filter.mp tT
  have tne:t≠largest S:=by simpa [tset,largest] using facts.2.2.2
  let k:=t/2
  have te:t=2*k:=by dsimp [k];omega
  have ko:k%2=1:=by dsimp [k];omega
  have sne:S.Nonempty:=⟨t,ts⟩
  let m:=S.max' sne
  have ms:m∈S:=max'_mem S sne
  have top (x:ℕ) (hx:x∈S):x≤ m:=le_max' _ _ hx
  have lm:largest S=m:=by
    apply le_antisymm
    · exact Finset.sup_le fun x hx=>top x hx
    · exact le_sup (f:=id) ms
  have mH:m≤ n/4:=(mem_Icc.mp (mem_inter.mp (hs.2.1 ms)).2).2
  have tk:t≤ m:=top _ ts
  have Hsum:t+m≤ n/4:=(mem_Icc.mp (mem_inter.mp (hs.2.2 t ts m ms (by omega))).2).2
  have Adata (x:ℕ) (hx:x∈({u,v,w}:Finset ℕ)):x≤ m ∧ x%2=1:=by
    have hh:x∈oddOffsets S:=oddset ▸ hx;exact ⟨top _ (mem_filter.mp hh).1,(mem_filter.mp hh).2⟩
  let E:=(oddOffsets S)∪twoOffsets S
  have dis:Disjoint (oddOffsets S) (twoOffsets S):=by
    apply disjoint_left.mpr;intro x h h';have o:=(mem_filter.mp h).2;have t':=(mem_filter.mp h').2;omega
  have Ec:E.card=(oddOffsets S).card+1:=by simp only [E,card_union_of_disjoint dis,facts.2.2.1]
  have sub:E⊆S:=union_subset (filter_subset _ _) (filter_subset _ _)
  let D:=S\E
  have Dsize:D.card=1 ∨ D.card=2:=by have :=card_sdiff_add_card_eq_card sub;change D.card+E.card=S.card at this;have :=hs.1;omega
  have Dz {x:ℕ} (hx:x∈D):x%4=0 ∧ x≤ m:=by
    obtain ⟨hxs,nh⟩:=mem_sdiff.mp hx
    refine ⟨?_,top _ hxs⟩
    by_contra ne;apply nh
    by_cases o:x%2=1
    · exact mem_union_left _ (mem_filter.mpr ⟨hxs,o⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨hxs,by omega⟩)
  have shape:∃x y:ℕ,D={x,y}:=by
    rcases Dsize with d|d
    · obtain ⟨x,hx⟩:=card_eq_one.mp d;exact ⟨x,x,by simp [hx]⟩
    · obtain ⟨x,y,_,he⟩:=card_eq_two.mp d;exact ⟨x,y,he⟩
  obtain ⟨x,y,deq⟩:=shape
  have dx:=Dz (x:=x) (by simp [deq]);have dy:=Dz (x:=y) (by simp [deq])
  apply hU n hn B hf hd hg S hs m k (x/4) (y/4) u v w w mH (by omega) (by omega) ko (by omega) (by omega) Adata _ (Adata w (by simp)).1 wo single
  intro z hz
  by_cases zz:z∈D
  · simp only [deq,mem_insert,mem_singleton] at zz;omega
  have zE:z∈E:=by by_contra h;exact zz (mem_sdiff.mpr ⟨hz,h⟩)
  rcases mem_union.mp zE with zo|zt
  · exact Or.inr (Or.inr (Or.inr (oddset ▸ zo)))
  · have eq:z=t:=by simpa [tset] using zt
    exact Or.inl (by omega)

def remainingAfterBridges : Finset ℕ := outstandingRows \ {5,14}

theorem normalized_after_bridges (hD:Dousse7) (other:∀i∈remainingAfterBridges,RowExclusion i) : NormalizedK7Goal:=by
  apply normalized_of_outstanding_rows hD
  intro i hi;by_cases known:i=5 ∨ i=14
  · exact bridge_rows_of_dispatch hD known
  · exact other i (mem_sdiff.mpr ⟨hi,by simpa using known⟩)

theorem limit_after_bridges (hD:Dousse7) (other:∀i∈remainingAfterBridges,RowExclusion i) : SharpK7Limit:=
  limit_of_normalized hD (normalized_after_bridges hD other)

end OP02.SharpK7

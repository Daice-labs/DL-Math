import SharedHole
open Finset Filter
open scoped Asymptotics
namespace OP02.SharpK4
open OP02.FewHole
set_option maxHeartbeats 1000000

/-- The threshold specification is inhabited independently of any extremal theorem. -/
theorem threshold_spec (N k : ℕ) :
    ∀ A⊆Icc 1 N,Erdos865.f N k≤A.card→
      ∃S⊆A,S.card=k ∧ ∀x∈S,∀y∈S,x≠y→x+y∈A := by
  classical
  let P := fun m=>∀A⊆Icc 1 N,m≤A.card→∃S⊆A,S.card=k ∧ ∀x∈S,∀y∈S,x≠y→x+y∈A
  have hne : ({m:ℕ|P m}:Set ℕ).Nonempty := by
    refine ⟨N+1,?_⟩
    intro A hA hc
    have h := card_le_card hA
    rw [Nat.card_Icc] at h
    omega
  exact Nat.sInf_mem hne

/-- The k4 input to k5 is uniform over every actual FourFree set. -/
theorem fourfree_uniform (hD : OP02.Frontier.Dousse4) (ε:ℝ) (hε:0<ε) :
    ∃N₀:ℕ,∀N:ℕ,N₀≤N→∀A:Finset ℕ,A⊆Icc 1 N→FourFree A→
      (A.card:ℝ)≤(21/32:ℝ)*N+ε*N := by
  have hg := complete_k4_endpoint hD
  change Asymptotics.IsLittleO atTop
    (fun N:ℕ=>(Erdos865.f N 4:ℝ)-(21/32:ℝ)*N)
    (fun N:ℕ=>(21/32:ℝ)*N) at hg
  have he := Asymptotics.isLittleO_iff.mp hg (show 0<ε/(21/32) from by positivity)
  obtain ⟨N₀,hN₀⟩ := eventually_atTop.mp he
  refine ⟨N₀,?_⟩
  intro N hN A hs hf
  have hc : A.card<Erdos865.f N 4 := by
    by_contra hh
    exact hf (threshold_spec N 4 A hs (by omega))
  have hcr : (A.card:ℝ)<(Erdos865.f N 4:ℝ) := by exact_mod_cast hc
  have hh := hN₀ N hN
  have hnn : (0:ℝ)≤(21/32:ℝ)*N := by positivity
  change ‖(Erdos865.f N 4:ℝ)-(21/32:ℝ)*N‖≤(ε/(21/32))*‖(21/32:ℝ)*N‖ at hh
  simp only [Real.norm_eq_abs,abs_of_nonneg hnn] at hh
  have := (abs_le.mp hh).2
  nlinarith

#print axioms threshold_spec
#print axioms fourfree_uniform
end OP02.SharpK4

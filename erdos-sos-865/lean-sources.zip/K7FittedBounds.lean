import K7CompactQuartet
import K7FittedFavorable
namespace OP02.SharpK7.LongOddTask

private theorem upper_cut {H s p2 b z v:ℕ} (u:v+4*b≤H) (w:2*(v+4*z)+s≤4*H+2*p2) :
    v≤halfHi H s p2 b z:=by apply le_min <;> omega

private theorem fit_linear {H L O q j P F m b s z:ℕ}
    (pad:384*(L+O+q)+10000*j+300000≤H) (bb:64*b≤3*H+64)
    (ss:s≤H) (pp:4*P≤H) (hh:2*F≤H)
    (mEq:m+4*z=H+P) (lo:H≤8*z) (up:8*z≤H+192*L+128*j+2048) :
    let A:=20*(O+q)+56
    F+A+4*b≤H ∧ m+A+4*b≤H ∧
    2*(F+A+4*z)+s≤4*H+2*P ∧ 2*(m+A+4*z)+s≤4*H+2*P ∧
    H+16*z+2*A+288*q+4*(4*q+8)+102≤4*H ∧
    2*H+8*z+2*A+288*q+4*(4*q+8)+102≤4*H :=by
  dsimp only
  exact ⟨by omega,by omega,by omega,by omega,by omega,by omega⟩

private theorem final_cut {H n p P F m z y w A q:ℕ}
    (hy:y≤ max F m+A) (we:w+p=2*(y+4*z)) (mEq:m+4*z=H+P) (pp:2*P≤p)
    (hh:2*F≤H) (nn:4*H≤n)
    (l:H+16*z+2*A+288*q+4*(4*q+8)+102≤4*H)
    (r:2*H+8*z+2*A+288*q+4*(4*q+8)+102≤4*H) :
    w+8*z+288*q+4*(4*q+8)+102≤n:=by
  rcases le_total F m with h|h
  · rw [max_eq_right h] at hy;omega
  · rw [max_eq_left h] at hy;omega

private theorem cut_width {H s P b z F m A:ℕ}
    (l:F+A≤halfHi H s P b z) (r:m+A≤halfHi H s P b z) :
    A≤halfHi H s P b z-max F m:=by
  rcases le_total F m with h|h
  · rw [max_eq_right h];exact Nat.le_sub_of_add_le (by simpa [Nat.add_comm] using r)
  · rw [max_eq_left h];exact Nat.le_sub_of_add_le (by simpa [Nat.add_comm] using l)

theorem fitted_quartet_geometry {H n L O q j p s b z:ℕ}
    (eqH:H=n/4) (pad:384*(L+O+q)+10000*j+300000≤H)
    (bd:b≤3*(H/64)+1) (sH:s≤H) (ps:p≤ s) (pH:2*p≤H)
    (lo:H/8<z) (up:z≤H/8+24*L+16*j+256) (zh:z+b≤H/4) :
    20*(O+q)+56≤halfHi H s (p/2) b z-halfLo H (p/2) z ∧
    ∀y w:ℕ,y≤halfLo H (p/2) z+20*(O+q)+56→w+p=2*(y+4*z)→
      w+8*z+288*q+4*(4*q+8)+102≤n := by
  let A:=20*(O+q)+56
  let m:=H+p/2-4*z
  have mEq:m+4*z=H+p/2:=Nat.sub_add_cancel (by omega)
  obtain ⟨g₁,g₂,g₃,g₄,pay₁,pay₂⟩:=fit_linear (P:=p/2) (F:=H/2) (m:=m) (z:=z)
    pad (b:=b) (by omega) sH (by omega) (by omega) mEq (by omega) (by omega)
  refine ⟨cut_width (upper_cut g₁ g₃) (upper_cut g₂ g₄),?_⟩
  intro y w hy he
  exact final_cut hy he mEq (by omega) (by omega) (by omega) pay₁ pay₂

end OP02.SharpK7.LongOddTask

import K5ForcedBands
import K5Progressions
open Finset
namespace OP02.SharpK5
open OP02.FewHole OP02.SmallExcess OP02.PivotAudit
set_option maxHeartbeats 5000000

/-- The actual replacement count, before any global-clique conclusion. One
selected label is a quarter-root; the other three use the same singleton budget. -/
theorem replacement_exists (n V u:ℕ) (B T:Finset ℕ)
    (hn:1024≤n) (hd:DoublingFree B) (hT:T⊆Icc 1 V) (hTc:T.card=3)
    (hu:u∈insert 0 T)
    (hpar:∀s∈insert 0 T\{u},s%2≠u%2)
    (hV:8*V≤3*n+128)
    (hsupply:16*chainDeficit n B+2*V+48*(missingTopOdd n B).card+18<n) :
    ∃p:ℕ,n/2<p ∧ p≤n-V-1 ∧ ∀s∈insert 0 T,p+s∈B := by
  classical
  let U:=insert 0 T
  let P:=n-V-1
  let v:=(12-u%8)%8
  let Y:=progression (n/2) P 8 v
  have hv:v<8 := by dsimp [v]; omega
  have hvu:(v+u)%8=4 := by dsimp [v]; omega
  have huV:u≤V := by
    rcases mem_insert.mp hu with rfl|hu
    · omega
    · exact (mem_Icc.mp (hT hu)).2
  have h0:0∉T := by intro ht; have := (mem_Icc.mp (hT ht)).1; omega
  have hUc:U.card=4 := by simp [U,h0,hTc]
  have huU:u∈U := hu
  have hother:(U\{u}).card=3 := by rw [card_sdiff_of_subset (by simpa using huU)]; simp [hUc]
  have hY (p:ℕ) (hp:p∈Y) : n/2<p ∧ p≤P ∧ p%8=v ∧ (p+u)%8=4 := by
    obtain ⟨hpI,hpr⟩:=mem_filter.mp hp
    have hpI:=mem_Ioc.mp hpI
    exact ⟨hpI.1,hpI.2,hpr,by omega⟩
  by_contra hnex
  push_neg at hnex
  let R:=Y.filter (fun p=>(p+u)/4∉quarterD n B)
  let F:=Y.filter (fun p=>∃s∈U\{u},p+s∉B)
  have hcover:Y⊆R∪F := by
    intro p hp
    have hpI:=hY p hp
    have hbad:∃s∈U,p+s∉B := hnex p hpI.1 hpI.2.1
    obtain ⟨s,hs,hbad⟩:=hbad
    by_cases he:s=u
    · subst s
      apply mem_union_left
      refine mem_filter.mpr ⟨hp,?_⟩
      intro hr
      have hrB:=(mem_filter.mp hr).2
      have hmul:4*((p+u)/4)=p+u := by omega
      exact hbad (hmul ▸ hrB)
    · exact mem_union_right _ (mem_filter.mpr ⟨hp,s,mem_sdiff.mpr ⟨hs,by simpa⟩,hbad⟩)
  have hr:R.card≤chainDeficit n B := by
    have hinj:R.card≤(missingTopOdd (n/4) (quarterD n B)).card := by
      apply card_le_card_of_injOn (fun p=>(p+u)/4)
      · intro p hp
        obtain ⟨hpY,hmiss⟩:=mem_filter.mp hp
        have hpI:=hY p hpY
        dsimp only [P] at hpI
        change (p+u)/4∈missingTopOdd (n/4) (quarterD n B)
        refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega,hmiss⟩
      · intro p hp q hq he
        have hpI:=hY p (mem_filter.mp hp).1
        have hqI:=hY q (mem_filter.mp hq).1
        change (p+u)/4=(q+u)/4 at he
        omega
    exact le_trans hinj (odd_tops_cost_once (n/4) (quarterD n B) (filter_subset _ _) (quarter_doubling_free n B hd))
  have hf:F.card≤3*(missingTopOdd n B).card := by
    apply affine_cover_bound F (U\{u}) (missingTopOdd n B) 0 (v%4) 1 3 (by omega)
    · intro p hp
      have hh:=hY p (mem_filter.mp hp).1
      omega
    · intro j
      exact le_trans (card_le_card (filter_subset _ _)) (le_of_eq hother)
    · intro p hp
      obtain ⟨hpY,s,hs,hmiss⟩:=mem_filter.mp hp
      have hpI:=hY p hpY
      have hspar:=hpar s hs
      have hsU:=(mem_sdiff.mp hs).1
      have hsV:s≤V := by
        rcases mem_insert.mp hsU with rfl|hsT
        · omega
        · exact (mem_Icc.mp (hT hsT)).2
      dsimp only [P] at hpI
      refine ⟨s,hs,p+s,mem_filter.mpr ⟨mem_filter.mpr ⟨mem_Icc.mpr ⟨by omega,by omega⟩,by omega⟩,by omega,hmiss⟩,by omega⟩
  have huCard:=le_trans (card_le_card hcover) (card_union_le R F)
  have hl:=progression_lower (n/2) P 8 v (by omega) hv
  change (P-n/2)/8≤Y.card at hl
  dsimp only [P] at hl
  omega

/-- Numeric supply follows from the same-set budget. This does not replace the
actual replacement maps above. -/
theorem replacement_supply (n V κ q hi:ℕ) (hn:1024≤n)
    (hq:128*q≤n) (hk:96*(κ+q)≤n) (hV:V+24*hi≤56*q+16) :
    16*κ+2*V+48*hi+18<n := by omega

#print axioms replacement_exists
#print axioms replacement_supply
end OP02.SharpK5

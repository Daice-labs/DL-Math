import K7LongLattice
open Finset OP02.FewHole OP02.SmallExcess OP02.SharpK5
namespace OP02.SharpK7.LongOddTask

/-- Choose the far label for this base, then use the actual pairs retained by
that tester. The chosen tester need not work at a different base. -/
theorem choose_odd_far {β:ℝ} {n e p:ℕ} {B:Finset ℕ} (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (sc:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (he:e∈smallSupport n B) (he₂:e%2=0)
    (hc:surplus n B ≤ ((reflectionPairs (smallSupport n B) e).card:ℤ))
    (low:3*(n/4)≤8*p) (up:2*p≤n/4) (po:p%2=1) :
    ∃ w∈rigidPresent (n/4/64) (quarterD n B), p+16*w∈B ∧
      lambdaBudget n B < (retainedEndpoints n B e (4*w)).card := by
  classical
  let W:=rigidPresent (n/4/64) (quarterD n B)
  have supply:=many_rigid β n B hd hg sc hl
  have someW:∃w∈W,p+16*w∈B:=by
    by_contra! hn
    have cnt: W.card≤(absentTop n B).card:=by
      apply card_le_card_of_injOn (fun w=>p+16*w)
      · intro w hw
        obtain ⟨h₁,h₂,_⟩:=rigid_bounds (mem_filter.mp hw).1
        change p+16*w∈absentTop n B
        exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨by omega,by omega⟩,by omega,hn w hw⟩
      · intro i hi j hj eq;dsimp at eq;omega
    have inv:=common_inventory n B
    have :=absent_top_cost n B hd
    change _<W.card at supply
    omega
  obtain ⟨w,hw,hfar⟩:=someW
  refine ⟨w,hw,hfar,?_⟩
  obtain ⟨h₁,h₂,_⟩:=rigid_bounds (mem_filter.mp hw).1
  have hr:=retained_count n B he he₂ (b:=4*w) (by omega) (by omega) (by omega)
  have hα:=surplus_lower β n B hd hg
  have hodd:((midOddLoss n B).card:ℝ)≤(midEmpty n B).card:=by
    exact_mod_cast (card_le_card (filter_subset _ _) : (midOddLoss n B).card≤_)
  have hlog : (0:ℝ)≤logLevels (n/4):=by positivity
  have hpairs:(surplus n B:ℝ)≤(reflectionPairs (smallSupport n B) e).card:=by exact_mod_cast hc
  have rest:((reflectionPairs (smallSupport n B) e).card:ℝ)≤
      (retainedEndpoints n B e (4*w)).card+((midOddLoss n B).card:ℝ):=by exact_mod_cast hr
  exact_mod_cast (show (lambdaBudget n B:ℝ)<(retainedEndpoints n B e (4*w)).card by linarith)

/-- Each later bad index can spoil only one of a fixed tester's disjoint odd reflection pairs. -/
theorem unspoiled_pair (A F:Finset ℕ) (e g:ℕ)
    (disjointPairs:∀a∈A, 0<a ∧ a<e-a ∧ a%2=1 ∧ (e-a)%2=1)
    (many:(F.filter (fun j=>g<j ∧ j%2≠g%2)).card<A.card) :
    ∃a∈A, g+a∉F ∧ g+(e-a)∉F := by
  classical
  by_contra! none
  let f (a:ℕ):=if g+a∈F then g+a else g+(e-a)
  have fn (a:ℕ) (ha:a∈A) : f a∈F.filter (fun j=>g<j ∧ j%2≠g%2) := by
    obtain ⟨_,_,_,_⟩:=disjointPairs a ha
    unfold f
    split_ifs with h
    · exact mem_filter.mpr ⟨h,by omega,by omega⟩
    · exact mem_filter.mpr ⟨none a ha h,by omega,by omega⟩
  have count:=card_le_card_of_injOn f fn (by
    intro a ha b hb eq
    have h₁:=disjointPairs a ha
    have h₂:=disjointPairs b hb
    unfold f at eq
    split_ifs at eq <;> omega)
  omega

theorem finish_odd_pair {β:ℝ} {n e a w p:ℕ} {B:Finset ℕ} (hd:DoublingFree B)
    (hg:(85/512+β)*(n:ℝ)≤((quarterD n B).card:ℝ)-(totalBudget n B:ℝ))
    (sc:64≤n/4) (hl:10*(logLevels (n/4):ℝ)+1000≤β*n)
    (he:e∈smallSupport n B) (he₂:e%2=0) (hw:w∈rigidPresent (n/4/64) (quarterD n B))
    (ha:a∈retainedEndpoints n B e (4*w)) (ao:a%2=1)
    (low:3*(n/4)≤8*p) (up:p+4*(n/4/64)≤n/4/2) (po:p%2=1)
    (hpp:p∈B) (hpa:p+4*a∈B) (hpc:p+4*(e-a)∈B) (hfar:p+16*w∈B) : qualifiedJ0 n B := by
  obtain ⟨hp,qual⟩:=mem_filter.mp ha
  obtain ⟨has,ap,ac,hcs⟩:=mem_filter.mp hp
  have en: e≤n/4/64:=(mem_Icc.mp (mem_inter.mp he).2).2
  obtain ⟨wb,wt,_⟩:=rigid_bounds (mem_filter.mp hw).1
  have q:=qual.resolve_left (by omega)
  have pr:=standard_partner_width hd hg sc hl up
  obtain ⟨x,hx,cap,xo,xp,xb,xa,xc,xt,xpB⟩:= select_partner n a (e-a) (4*w) p B hd ac (by omega)
    (by omega) (by omega) po (Or.inl ao) pr
  have e_sum:a+(e-a)=e:=by omega
  refine ⟨a,e-a,4*w,p,x,ap,ac,by omega,by omega,by omega,po,xo,xp.symm,
    Or.inr ⟨ao,by omega,by omega⟩,?_⟩
  apply actual_five n a (e-a) (4*w) p x B ap ac (by omega) (by omega) (by omega) cap
    (mem_inter.mp has).1 (mem_inter.mp hcs).1 (mem_filter.mp hw).2
    (e_sum.symm ▸ (mem_inter.mp he).1) _ _ hpp hpa hpc (by rwa [show 4*(4*w)=16*w by omega]) xb xa xc xt xpB
  · simpa [Nat.add_comm] using q.1
  · simpa [Nat.add_comm] using q.2

end OP02.SharpK7.LongOddTask

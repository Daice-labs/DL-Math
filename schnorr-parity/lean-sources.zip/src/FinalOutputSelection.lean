import FinalPortSlots
import SelectionWithoutDistinctness
namespace L3Emitter.FinalOutputSelection
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteSelection ConcretePortRows FinalOutputDefinitions
variable {base:List Row}
attribute [local irreducible] FinalOutputDefinitions.construction tabulate FinalOutputDefinitions.out FinalOutputDefinitions.selector FinalOutputDefinitions.port FinalOutputDefinitions.function FinalOutputDefinitions.base initialNet

theorem run_ready (m:Nat) (f:Fin m→List (Bit×Bit)) (z:Net base)
    (hf:∀i,(f i |>.map (fun p=>p.1.val)).Pairwise (fun a b=>clause [-a,-b]∈z.rows)):
    ∀i,Ready (run m f z).2.rows ((run m f z).1 i):=by
  induction m generalizing z with
  | zero=>intro i;exact Fin.elim0 i
  | succ m ih=>
    intro i
    refine Fin.cases ?_ (fun i=>?_) i
    · apply Ready.mono (D:=(select (f 0) z).2.rows)
      · intro e he
        simpa only [select_binding] using SelectionWithoutDistinctness.inputs (f 0) z (hf 0) e he
      · exact ConcretePortRows.retains m (fun i=>f i.succ) (select (f 0) z).2
    · exact ih (fun i=>f i.succ) (select (f 0) z).2
        (fun i=>(hf i.succ).imp (fun h=>select_extends (f 0) z _ h)) i

def inputs (n:Nat) (hn:2≤n) (x:Fin (T n)):List (Bit×Bit):=
  (List.finRange (W n-1)).map (fun i=>(source n hn (coord n i),SourceCoordinateValue.value n hn (coord n i) x.val))
def observed (n:Nat) (hn:2≤n):=run (T n) (inputs n hn) (initialNet n hn)

theorem source_in_base (n:Nat) (hn:2≤n):∀R∈GateOrderSources.fullResult n hn,R∈FinalOutputDefinitions.base n hn:=by
  intro R h
  unfold FinalOutputDefinitions.base
  apply List.mem_append_left
  apply List.mem_append_left
  apply GateEvaluationBindings.selector_keep
  apply LowerSelectorComplete.predecessor_kept
  apply TopologyContext.global_kept
  apply GlobalPortValues.retained
  apply GlobalValueInduction.retained
  apply SharedValueBank.gamma_retained
  apply EarlierPortValues.unary_keep
  apply CofactorValueRows.unary_keep
  apply UnaryRelationBank.retains
  exact List.mem_append_left _ h

theorem initial_rows (n:Nat) (hn:2≤n):(initialNet n hn).rows=FinalOutputDefinitions.base n hn:=by
  simp only [initialNet, initial, Net.rows, List.flatMap_nil, List.append_nil]

theorem pairs (n:Nat) (hn:2≤n) (x:Fin (T n)):
    ((inputs n hn x).map (fun p=>p.1.val)).Pairwise (fun a b=>clause [-a,-b]∈(initialNet n hn).rows):=by
  rw [initial_rows]
  have hs:=GateOrderSources.all_source_rows n hn (n+1+OutputPhaseRows.lastGate n)
    (by unfold OutputPhaseRows.lastGate;omega)
  simp only [inputs,List.map_map,List.finRange,List.map_ofFn,Function.comp_def]
  apply List.pairwise_ofFn.mpr
  intro i j hij
  exact source_in_base n hn _ (hs.2 (coord n i) (coord n j) hij)

theorem stage_binding (n:Nat) (hn:2≤n):
    ((fun x=>((observed n hn).1 x).q),(observed n hn).2)=
      tabulate (T n) (FinalOutputDefinitions.out n hn) (initialNet n hn):=
by
  unfold FinalOutputDefinitions.out
  exact ConcretePortRows.binding (T n) (inputs n hn) (initialNet n hn)

theorem output_projection (n:Nat) (hn:2≤n):
    (FinalOutputDefinitions.built n hn).1.outs=(tabulate (T n) (FinalOutputDefinitions.out n hn) (initialNet n hn)).1:=by
  unfold FinalOutputDefinitions.built FinalOutputDefinitions.construction
  rfl

theorem output_binding (n:Nat) (hn:2≤n) (x:Fin (T n)):
    ((observed n hn).1 x).q=(FinalOutputDefinitions.built n hn).1.outs x:=by
  rw [output_projection]
  exact congrFun (congrArg Prod.fst (stage_binding n hn)) x

def tail (n:Nat) (hn:2≤n) (xs:Fin (T n)→Bit):StateM (Net base) (Data n):=do
  let ss←tabulate 2 (fun p=>tabulate (W n-1) (FinalOutputDefinitions.selector n hn p))
  let ps←tabulate 2 (fun p=>tabulate (T n) (FinalOutputDefinitions.port n hn xs p))
  let fs←tabulate 4 (FinalOutputDefinitions.function n hn)
  pure ⟨xs,ss,ps,fs⟩
theorem tail_extends (n:Nat) (hn:2≤n) (xs:Fin (T n)→Bit):Extends (tail (base:=base) n hn xs):=by
  unfold tail
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>tabulate_extends _ _ (fun _=>by unfold FinalOutputDefinitions.selector;exact mux_extends _ _ _)))
  intro ss
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>tabulate_extends _ _ (fun _=>by unfold FinalOutputDefinitions.port;exact mux_extends _ _ _)))
  intro ps
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>by
    unfold FinalOutputDefinitions.function
    exact bind_extends _ _ (mux_extends _ _ _) (fun _=>bind_extends _ _ (mux_extends _ _ _) (fun _=>mux_extends _ _ _))))
  exact fun _=>pure_extends _
attribute [local irreducible] observed tail

theorem construction_bind (n:Nat) (hn:2≤n):
    FinalOutputDefinitions.construction (base:=base) n hn =
    (tabulate (T n) (FinalOutputDefinitions.out n hn) >>= tail n hn):=by
  unfold FinalOutputDefinitions.construction tail
  rfl

theorem after_bind {A B:Type} (p:StateM (Net base) A) (f:A→StateM (Net base) B)
    (hf:∀a,Extends (f a)) (z:Net base):∀R∈(p z).2.rows,R∈((p >>= f) z).2.rows:=
  hf (p z).1 (p z).2

theorem construction_kept (n:Nat) (hn:2≤n) (z:Net base):
    ∀R∈(tabulate (T n) (FinalOutputDefinitions.out n hn) z).2.rows,
      R∈(FinalOutputDefinitions.construction n hn z).2.rows:=by
  rw [construction_bind]
  exact after_bind _ _ (tail_extends n hn) z

theorem stage_kept (n:Nat) (hn:2≤n):∀R∈(observed n hn).2.rows,R∈FinalOutputDefinitions.result n hn:=by
  rw [show (observed n hn).2=(tabulate (T n) (FinalOutputDefinitions.out n hn) (initialNet n hn)).2 from congrArg Prod.snd (stage_binding n hn)]
  unfold FinalOutputDefinitions.result FinalOutputDefinitions.built
  exact construction_kept n hn (initialNet n hn)

attribute [local semireducible] observed

theorem ready (n:Nat) (hn:2≤n) (x:Fin (T n)):
    Ready (FinalSelectorCardinalities.result n hn) ((observed n hn).1 x):=
  (run_ready (T n) (inputs n hn) (initialNet n hn) (pairs n hn) x).mono
    (fun R h=>FinalSelectorImage.definitions_kept n hn R (stage_kept n hn R h))
#print axioms ready
#print axioms output_binding
end L3Emitter.FinalOutputSelection

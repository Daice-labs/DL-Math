import CategorySourceInputs

namespace L3Emitter.CategoryMixtureProgram
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GateCategories CategoryPrograms SourceMixture

def ranks (n:Nat) :=List.range (RankConstruction.width (n+1))
def rankRows (n:Nat) (hn:2≤n) (g:Nat) (s:Refs) (ts:List Nat) :=
  ts.flatMap (fun t=>MixtureRank.rows s (bit n hn g (.rank t)))
def rankLoop (n:Nat) (hn:2≤n) (g:Nat) (s:Refs) (D:List Row) : List Nat→Program
  | []=>[]
  | t::ts=>MixtureRank.program s (bit n hn g (.rank t)) D++
      rankLoop n hn g s (D++MixtureRank.rows s (bit n hn g (.rank t))) ts

theorem rank_inputs (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (s:Refs) (hb:s.beta=(PrimaryAliasBank.cfg n hn).beta g)
    (hc:s.gamma=(PrimaryAliasBank.cfg n hn).gamma g) (t:Nat) (ht:t∈ranks n)
    (D:List Row) (hd:CategorySourceInputs.Keep n hn D) :
    clause [-(bit n hn g (.rank t)).val,-s.beta.val]∈D ∧
    clause [-(bit n hn g (.rank t)).val,-s.gamma.val]∈D := by
  have hm:Category.rank t∈cats n:=by
    simpa [ranks,cats,categories,RankConstruction.width] using ht
  constructor
  · rw [hb]
    exact hd _ (CategoryBank.exclusion n hn g hg hs (.rank t) .beta hm
      (by simp [cats,categories]) (by simp))
  · rw [hc]
    exact hd _ (CategoryBank.exclusion n hn g hg hs (.rank t) .gamma hm
      (by simp [cats,categories]) (by simp))

theorem rankLoop_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (s:Refs) (hb:s.beta=(PrimaryAliasBank.cfg n hn).beta g)
    (hc:s.gamma=(PrimaryAliasBank.cfg n hn).gamma g) (ts:List Nat) (ht:∀t∈ts,t∈ranks n)
    (D:List Row) (hd:CategorySourceInputs.Keep n hn D) (hr:s.Ready D) :
    check D (rankLoop n hn g s D ts)=some (D++rankRows n hn g s ts) := by
  induction ts generalizing D with
  | nil=>simp [rankLoop,rankRows,check]
  | cons t ts ih=>
    have h:=rank_inputs n hn g hg hs s hb hc t (ht t (by simp)) D hd
    have h1:=MixtureRank.checks s (bit n hn g (.rank t)) D hr h.1 h.2
    have h2:=ih (fun t hh=>ht t (by simp [hh]))
      (D++MixtureRank.rows s (bit n hn g (.rank t))) (fun R hh=>List.mem_append_left _ (hd R hh))
      (MixtureGamma.ready_mono hr (fun R hh=>List.mem_append_left _ hh))
    simpa only [rankLoop,rankRows,List.flatMap_cons,List.append_assoc] using check_append _ _ _ _ _ h1 h2

def afterPrep (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (D:List Row) :=
  D++CategorySourceInputs.rows n hn g i
def afterBeta (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (s:Refs) (D:List Row) :=
  afterPrep n hn g i D++MixtureBeta.rows s
def afterGamma (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (s:Refs) (D:List Row) :=
  afterBeta n hn g i s D++MixtureGamma.rows s
def rows (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (s:Refs) :=
  CategorySourceInputs.rows n hn g i++MixtureBeta.rows s++MixtureGamma.rows s++rankRows n hn g s (ranks n)
def program (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (s:Refs) (D:List Row) :=
  CategorySourceInputs.prepare n hn g i D++MixtureBeta.program s (afterPrep n hn g i D)++
    MixtureGamma.program s (afterBeta n hn g i s D)++rankLoop n hn g s (afterGamma n hn g i s D) (ranks n)

theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1))) (s:Refs) (h:CategorySourceInputs.compatible n hn g i s)
    (D:List Row) (hd:CategorySourceInputs.Keep n hn D) (hr:s.Ready D) :
    check D (program n hn g i s D)=some (D++rows n hn g i s) := by
  have h0:=CategorySourceInputs.prepare_check n hn g hg hs i D hd
  have inputs:=CategorySourceInputs.all_inputs n hn g hg hs i s h D hd
  have keep0:∀R∈D,R∈afterPrep n hn g i D:=fun R hh=>List.mem_append_left _ hh
  have keep1:∀R∈D,R∈afterBeta n hn g i s D:=fun R hh=>List.mem_append_left _ (keep0 R hh)
  have keep2:∀R∈D,R∈afterGamma n hn g i s D:=fun R hh=>List.mem_append_left _ (keep1 R hh)
  have h1:=MixtureBeta.checks s (afterPrep n hn g i D) (MixtureGamma.ready_mono hr keep0)
    inputs.1 inputs.2.2.1
  have h2:=MixtureGamma.checks s (afterBeta n hn g i s D) (MixtureGamma.ready_mono hr keep1)
    (List.mem_append_left _ inputs.2.1) (List.mem_append_left _ inputs.2.2.2)
  have h3:=rankLoop_check n hn g hg hs s h.1 h.2.1 (ranks n) (fun t ht=>ht)
    (afterGamma n hn g i s D) (fun R hh=>keep2 R (hd R hh)) (MixtureGamma.ready_mono hr keep2)
  have h01:=check_append _ _ _ _ _ h0 h1
  have h012:=check_append _ _ _ _ _ h01 h2
  simpa only [program,rows,afterPrep,afterBeta,afterGamma,List.append_assoc] using
    check_append _ _ _ _ _ h012 h3

theorem beta_relations (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (s:Refs) :
    clause [-s.beta.val,-s.u.val,s.q.val]∈rows n hn g i s ∧
    clause [-s.beta.val,-s.q.val,s.u.val]∈rows n hn g i s := by
  have h:=MixtureBeta.relations s
  exact ⟨List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ h.1)),
    List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ h.2))⟩
theorem gamma_relations (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (s:Refs) :
    clause [-s.gamma.val,-s.m.val,s.q.val]∈rows n hn g i s ∧
    clause [-s.gamma.val,-s.q.val,s.m.val]∈rows n hn g i s := by
  have h:=MixtureGamma.relations s
  exact ⟨List.mem_append_left _ (List.mem_append_right _ h.1),List.mem_append_left _ (List.mem_append_right _ h.2)⟩
theorem rank_relations (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (s:Refs)
    (t:Nat) (ht:t∈ranks n) :
    clause [-(bit n hn g (.rank t)).val,-s.rank.val,s.q.val]∈rows n hn g i s ∧
    clause [-(bit n hn g (.rank t)).val,-s.q.val,s.rank.val]∈rows n hn g i s := by
  have h:=MixtureRank.relations s (bit n hn g (.rank t))
  exact ⟨List.mem_append_right _ (List.mem_flatMap.mpr ⟨t,ht,h.1⟩),
    List.mem_append_right _ (List.mem_flatMap.mpr ⟨t,ht,h.2⟩)⟩

#print axioms checks
#print axioms beta_relations
#print axioms gamma_relations
#print axioms rank_relations
end L3Emitter.CategoryMixtureProgram

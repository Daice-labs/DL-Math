import FinalOutputSlots
import FinalLowerEarlier
import MuxConditionalClause
namespace L3Emitter.FinalSelectorSources
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram FinalOutputDefinitions
attribute [local irreducible] construction tabulate
def D (n:Nat) (hn:2≤n):=FinalOutputRecorded.result n hn
def raw (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)):Bit:=
  LowerTransferImage.wire n hn (.sel (lastRank n) p.val i.val)
def target (n:Nat) (hn:2≤n) (p:Fin 2):Fin (W n-1)→Bit:=(built n hn).1.sels p
def alo (n:Nat):List (Fin (W n-1)×Bool):=List.ofFn (fun i:Fin (W n-1)=>(i,true))
theorem width_binding (n:Nat) (hn:2≤n):n+lastRank n=W n-1:=by
  unfold lastRank W AliasAssembly.width RankConstruction.width;omega

theorem raw_alo (n:Nat) (hn:2≤n) (p:Fin 2):
    GuardedVectorTransport.row (raw n hn p) (alo n)∈D n hn:=by
  have h:=LowerGateBank.all_nonoutput_images n hn (InputSwap.oneHot n (lastRank n) p.val true)
    (Or.inl ((OriginalEncoding.selectors_mem ..).mpr ⟨lastRank n,p.val,true,by unfold lastRank RankConstruction.width;omega,p.isLt,rfl⟩))
  have he:GuardedVectorTransport.row (raw n hn p) (alo n)=
      LowerTransferImage.image n hn (InputSwap.oneHot n (lastRank n) p.val true):=by
    rw [LowerSelectorALO.image_eq]
    simp only [GuardedVectorTransport.row,GuardedVectorTransport.literals,alo,List.map_ofFn,
      Function.comp_def,GuardedVectorTransport.signed,↓reduceIte,raw,LowerSelectorAMO.xs,width_binding n hn,Fin.val_cast]
  rw [he]
  exact List.mem_append_left _ (FinalLowerEarlier.original_kept n hn _ h)

theorem source_keep (n:Nat) (hn:2≤n):∀R∈GateOrderSources.fullResult n hn,R∈D n hn:=by
  intro R h
  apply List.mem_append_left
  apply FinalOutputDefinitions.retains
  apply List.mem_append_left
  apply List.mem_append_left
  apply GateEvaluationBindings.selector_keep
  apply LowerSelectorComplete.predecessor_kept
  apply TopologyContext.global_kept
  apply GlobalPortValues.retained
  apply GlobalValueInduction.retained
  apply SharedValueBank.gamma_retained
  apply EarlierPortValues.unary_keep
  apply CofactorValueRows.unary_keep
  apply UnaryRelationBank.retains
  exact List.mem_append_left _ h

theorem terminal_alo (n:Nat) (hn:2≤n):
    clause (List.ofFn (fun i:Fin (W n)=>(source n hn i).val))∈D n hn:=by
  apply source_keep
  exact (GateOrderSources.all_source_rows n hn (n+1+OutputPhaseRows.lastGate n)
    (by unfold OutputPhaseRows.lastGate;omega)).1

theorem source_split (n:Nat) (hn:2≤n):
    List.ofFn (fun i:Fin (W n)=>(source n hn i).val)=
      List.ofFn (fun i:Fin (W n-1)=>(source n hn (coord n i)).val)++[(H n hn).val]:=by
  have hw:0<W n:=by unfold W AliasAssembly.width RankConstruction.width;omega
  apply List.ext_getElem
  · simp;omega
  · intro i hi hj
    by_cases h:i<W n-1
    · rw [List.getElem_append_left (by simpa using h)]
      simp only [List.getElem_ofFn]
      congr 2
    · have he:i=W n-1:=by simp only [List.length_ofFn] at hi;omega
      rw [List.getElem_append_right (by simpa using Nat.le_of_not_gt h)]
      subst i
      simp only [List.length_ofFn,Nat.sub_self,List.getElem_cons_zero,List.getElem_ofFn]
      rfl

theorem terminal_guarded_alo (n:Nat) (hn:2≤n):
    Resolution.branch (GuardedVectorTransport.row (fun i:Fin (W n-1)=>source n hn (coord n i)) (alo n)) (H n hn).val∈D n hn:=by
  have h:=terminal_alo n hn
  rw [source_split] at h
  simp only [GuardedVectorTransport.row,GuardedVectorTransport.literals,alo,List.map_ofFn,Function.comp_def,GuardedVectorTransport.signed,↓reduceIte]
  rw [ProjectionTrace.branch_clause _ (by intro x hx;obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hx;exact (source n hn (coord n i)).property) _ (H n hn).property]
  change clause ([(H n hn).val]++List.ofFn (fun i:Fin (W n-1)=>(source n hn (coord n i)).val))∈D n hn
  rw [ProjectionTrace.clause_perm _ _
    (by intro x hx;rcases List.mem_cons.mp hx with rfl|hx;exact (H n hn).property;obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hx;exact (source n hn (coord n i)).property)
    (by intro x hx;rcases List.mem_append.mp hx with hx|hx;obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hx;exact (source n hn (coord n i)).property;obtain rfl:=List.mem_singleton.mp hx;exact (H n hn).property)
    (List.perm_append_comm)]
  exact h

theorem raw_relations (n:Nat) (hn:2≤n) (p:Fin 2):
    GuardedVectorTransport.Relations (D n hn) (neg (H n hn)) (raw n hn p) (target n hn p):=
  fun i=>⟨(FinalOutputSlots.selector_rows n hn p i).1,(FinalOutputSlots.selector_rows n hn p i).2.1⟩
theorem alternative_relations (n:Nat) (hn:2≤n) (p:Fin 2):
    GuardedVectorTransport.Relations (D n hn) (H n hn) (FinalOutputSlots.alternative n hn p) (target n hn p):=
  fun i=>(FinalOutputSlots.selector_rows n hn p i).2.2
#print axioms raw_alo
#print axioms terminal_guarded_alo
end L3Emitter.FinalSelectorSources

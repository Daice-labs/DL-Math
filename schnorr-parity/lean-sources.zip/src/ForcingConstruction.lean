import ForcingBounds
import ProgramRebase

namespace L3Emitter.ForcingConstruction
open EREF EREF.GeneralRED REDWitness RankProjection AliasProgram
open ForcingBinding ForcingDefinitions ForcingProgram ForcingBounds SelectionBounds

def body (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat) :=
  (input k hk c).rows m++[eligibleRow k hk c,consumerRow k hk c]++coverageRows k hk c m

def step (D : List Row) (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat) := D++body k hk c m

def derivedProgram (D : List Row) (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat) : Program :=
  let d:=D++(input k hk c).rows m
  ProgramRebase.program (FrontendSelection.finalRows k hk) d (prepProgram k hk c) ++
    ForcingProgram.program (d++[eligibleRow k hk c,consumerRow k hk c]) k hk c m

theorem derived_check (D : List Row) (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat)
    (hc : c∈BranchChoices.chosen k hk) (hsub : ∀R∈FrontendSelection.finalRows k hk,R∈D) :
    check (D++(input k hk c).rows m) (derivedProgram D k hk c m)=some (step D k hk c m) := by
  let d:=D++(input k hk c).rows m
  have hs : ∀R∈FrontendSelection.finalRows k hk,R∈d := by intro R hR;exact List.mem_append_left _ (hsub R hR)
  have hp:=ProgramRebase.program_check _ d hs _ _ (prep_check k hk c hc)
  have ho : outputs (prepProgram k hk c)=[eligibleRow k hk c,consumerRow k hk c] := rfl
  rw [ho] at hp
  have hf:=ForcingProgram.program_check (d++[eligibleRow k hk c,consumerRow k hk c]) k hk c m
    (by intro R hR;exact List.mem_append_left _ (hs R hR)) (by simp)
    (by intro R hR;exact List.mem_append_left _ (List.mem_append_right _ hR))
  simpa only [derivedProgram,step,body,d,List.append_assoc] using check_append _ _ _ _ _ hp hf

theorem step_trace (D : List Row) (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat)
    (hc : c∈BranchChoices.chosen k hk) (hm : ceiling k hk≤m)
    (hD : L3.DBBounded D m) (hsub : ∀R∈FrontendSelection.finalRows k hk,R∈D) :
    CheckedTrace D (step D k hk c m) ∧ L3.DBBounded (step D k hk c m) (m+4) := by
  have hb:=actual_bounds k hk c hc
  have hx : L3.Bounded m (input k hk c).lits := by intro l hl;have:=hb.1 l hl;omega
  have hd:=ForcingDefinitions.trace D (input k hk c) m hD hx
  have hp:=derived_check D k hk c m hc hsub
  constructor
  · exact L3.Fam.checkedTrace_trans hd.1 (check_trace _ _ _ hp)
  have hchoice:=choice_bound k hk c hc
  have hb0 : LB (m+4) (port k hk c 0 m).p := by change LB (m+4) (port k hk c 0 0).p;have:=hb.2.2.2.1;exact ⟨this.1,by omega⟩
  have hb1 : LB (m+4) (port k hk c 1 (m+2)).p := by change LB (m+4) (port k hk c 1 0).p;have:=hb.2.2.2.2;exact ⟨this.1,by omega⟩
  have hbc : LB (m+4) c.lit := ⟨hchoice.1,by omega⟩
  have hbe : LB (m+4) (eligible k hk c) := ⟨hb.2.1.1,by have:=hb.2.1.2;omega⟩
  have hbco : LB (m+4) (consumer k hk c) := ⟨hb.2.2.1.1,by have:=hb.2.2.1.2;omega⟩
  have hnew (i : Nat) (hi : 1 ≤ i ∧ i ≤ 4) : LB (m+4) ((m:Int)+i) := by
    rw [←Nat.cast_add];change 1≤m+i ∧ m+i≤m+4;omega
  unfold step body
  rw [←List.append_assoc,←List.append_assoc]
  apply append_cb
  · apply append_cb _ _ _ hd.2
    intro R hR;simp only [List.mem_cons,List.not_mem_nil,or_false] at hR
    rcases hR with rfl|rfl <;> refine ⟨_,rfl,?_⟩ <;>
      intro l hl <;> simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    · rcases hl with rfl|rfl
      · simpa using hbc
      · exact hbe
    · rcases hl with rfl|rfl
      · simpa using hbc
      · exact hbco
  · intro R hR
    simp only [coverageRows,List.mem_cons,List.not_mem_nil,or_false] at hR
    rcases hR with rfl|rfl|rfl <;> refine ⟨_,rfl,?_⟩
    · change L3.Bounded (m+4) [-c.lit,-(port k hk c 0 m).p,(m+1:Int),(m+2:Int)]
      intro l hl;simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
      rcases hl with rfl|rfl|rfl|rfl
      · simpa using hbc
      · simpa using hb0
      · exact hnew 1 (by omega)
      · exact hnew 2 (by omega)
    · change L3.Bounded (m+4) [-c.lit,-(port k hk c 1 (m+2)).p,((m+2:Nat):Int)+1,((m+2:Nat):Int)+2]
      intro l hl;simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
      rcases hl with rfl|rfl|rfl|rfl
      · simpa using hbc
      · simpa using hb1
      · simpa [Nat.cast_add,Nat.cast_ofNat,add_assoc] using hnew 3 (by omega)
      · simpa [Nat.cast_add,Nat.cast_ofNat,add_assoc] using hnew 4 (by omega)
    · change L3.Bounded (m+4) [-c.lit,(m+1:Int),(m+2:Int),(m+3:Int),(m+4:Int)]
      intro l hl;simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
      rcases hl with rfl|rfl|rfl|rfl|rfl
      · simpa using hbc
      · exact hnew 1 (by omega)
      · exact hnew 2 (by omega)
      · exact hnew 3 (by omega)
      · exact hnew 4 (by omega)

theorem body_length (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat) :
    (body k hk c m).length=21 := by
  simp [body,coverageRows,ForcingDefinitions.rows_length]

theorem original_to_branch_forcing (k : Nat) (hk : 3≤k) (c : Choice (3*k-4))
    (hc : c∈BranchChoices.chosen k hk) :
    CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (step (FrontendSelection.finalRows k hk) k hk c (ceiling k hk)) := by
  exact L3.Fam.checkedTrace_trans (FrontendSelection.original_to_selected_branches k hk).1
    (step_trace _ k hk c _ hc (Nat.le_refl _) (front_bounded k hk) (by intros;assumption)).1

#print axioms original_to_branch_forcing
#print axioms step_trace
end L3Emitter.ForcingConstruction

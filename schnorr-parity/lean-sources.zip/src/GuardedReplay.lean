import GuardedFrame
namespace L3Emitter.GuardedReplay
open EREF EREF.GeneralRED REDWitness

/-- A lower trace with an explicit count and the two namespace conditions
required by the actual guarded composer. It is not yet the complete emitter. -/
inductive Scoped (M:Nat) (l:Int):List Row→List Row→Nat→Prop
  | refl (D:List Row):Scoped M l D D 0
  | pol {D E:List Row} {m:Nat} (C:Row) (ts:List Tok)
      (he:polEval (dbOf D) ts []=some C) (tail:Scoped M l (D++[C]) E m):Scoped M l D E (m+1)
  | consequence {D E:List Row} {m:Nat} (C:Row) (hc:Canonical C)
      (cert:Refutation (D++[negate C])) (tail:Scoped M l (D++[C]) E m):Scoped M l D E (m+1)
  | red {D E:List Row} {m:Nat} (C:Row) (ω:Witness) (hc:Canonical C)
      (ho:SequenceObligations D C ω) (hm:REDFrame.FixesBelow ω M)
      (hl:∀α,applyWitness ω α l.natAbs=α l.natAbs)
      (tail:Scoped M l (D++[C]) E m):Scoped M l D E (m+1)

/-- Exact number of main-database additions, independent of local goal work. -/
inductive Counted:List Row→List Row→Nat→Prop
  | refl (D:List Row):Counted D D 0
  | cons {D F E:List Row} {m:Nat} (step:CheckedStep D F) (tail:Counted F E m):Counted D E (m+1)

theorem counted_trace {D E:List Row} {m:Nat} (h:Counted D E m):CheckedTrace D E:=by
  induction h with
  | refl=>exact .refl _
  | cons h t ih=>exact .cons h ih

theorem counted_length {D E:List Row} {m:Nat} (h:Counted D E m):E.length=D.length+m:=by
  induction h with
  | refl=>simp
  | cons h t ih=>cases h <;> simp_all <;> omega

def frame (upper inputs:List Row) (a:Row→Nat) (l:Int):List Row:=
  upper++inputs.map (fun R=>GuardedFrame.weaken R (a R) l)

theorem frame_canonical (upper inputs:List Row) (a:Row→Nat) (l:Int)
    (hu:∀R∈upper,Canonical R):∀R∈frame upper inputs a l,Canonical R:=by
  intro R hr
  rcases List.mem_append.mp hr with hr|hr
  · exact hu R hr
  · obtain ⟨Q,hq,rfl⟩:=List.mem_map.mp hr
    exact GuardedFrame.canonical_weaken _ _ _

/-- One lower step becomes one composed main step. RED local refutations
are rebased and guard goals use the explicit four-token cancellation lemma. -/
theorem one_copy {M:Nat} {l:Int} {D E:List Row} {m:Nat} (h:Scoped M l D E m)
    (upper inputs:List Row) (a:Row→Nat)
    (hu:RowSupport.Bounded M upper) (hi:∀R∈inputs,Canonical R)
    (ha:∀R∈inputs,0<a R) (hl:l≠0) (hin:∀R∈inputs,R∈D):
    Counted (frame upper inputs a l++D) (frame upper inputs a l++E) m:=by
  induction h with
  | refl=>exact .refl _
  | @pol D E m C ts he tail ih=>
    obtain ⟨ts',he',_⟩:=ReferenceTransport.eval_subset D (frame upper inputs a l++D)
      (fun R hr=>List.mem_append_right _ hr) ts C he
    have s:=CheckedStep.pol (frame upper inputs a l++D) C ts' he'
    have t:=ih (fun R hr=>List.mem_append_left _ (hin R hr))
    exact .cons (by simpa only [List.append_assoc] using s) t
  | @consequence D E m C hc cert tail ih=>
    have cert':Refutation ((frame upper inputs a l++D)++[negate C]):=by
      apply ReferenceTransport.refutation_subset _ _ _ cert
      intro R hr
      rcases List.mem_append.mp hr with hr|hr
      · exact List.mem_append_left _ (List.mem_append_right _ hr)
      · exact List.mem_append_right _ hr
    have s:=CheckedStep.consequence (frame upper inputs a l++D) C hc cert'
    exact .cons (by simpa only [List.append_assoc] using s)
      (ih (fun R hr=>List.mem_append_left _ (hin R hr)))
  | @red D E m C ω hc ho hm hguard tail ih=>
    have hclass:=GuardedFrame.guard_class D upper inputs a l ω hi ha hl hin
      (REDFrame.bounded_fixed ω M upper hm hu) hguard
    have s:=GuardedFrame.lift D (frame upper inputs a l) C ω hc ho
      (frame_canonical upper inputs a l (fun R hr=>(hu R hr).1)) hclass
    exact .cons s (ih (fun R hr=>List.mem_append_left _ (hin R hr)))

#print axioms one_copy
#print axioms counted_length
end L3Emitter.GuardedReplay

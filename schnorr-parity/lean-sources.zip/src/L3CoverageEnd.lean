import L3FinalChains
import L3Bits
import L3Split

namespace L3
open EREF EREF.GeneralRED
namespace Fam
variable (F : Fam)

def cbCode (a b : Bool) : Nat :=
  if a then (if b then 12 else 9) else (if b then 6 else 3)
def cbLeaf (c0 c1 : Nat) (a b : Bool) : List Int :=
  [(c0 : Int),(c1 : Int),if a then -(F.fn 0 0 : Int) else (F.fn 0 0 : Int),
    if b then -(F.fn 0 1 : Int) else (F.fn 0 1 : Int)]
def cbEqRow (c i : Nat) (a : Bool) : Row :=
  gateRow [if a then -(F.fn 0 i : Int) else (F.fn 0 i : Int),
    if a then -(F.fn 0 (i+2) : Int) else (F.fn 0 (i+2) : Int)] c true

/-- T5g's four leaves: the two first-gate cofactors cannot both be unequal.
    A fixed POL chain uses exactly the two EQ rows and one forbidden code. -/
theorem cb_leaf (D : List EREF.Row) (hD : ∀ R∈D, Canonical R)
    (c0 c1 : Nat) (hc0 : 1≤c0) (hc1 : 1≤c1) (a b : Bool)
    (hE0 : (F.cbEqRow c0 0 a).toE ∈ D)
    (hE1 : (F.cbEqRow c1 1 b).toE ∈ D)
    (hB : (F.row2 0 (cbCode a b)).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow (F.cbLeaf c0 c1 a b)).toE]) := by
  have h0 := F.fn_pos 0 0
  have h1 := F.fn_pos 0 1
  have h2 := F.fn_pos 0 2
  have h3 := F.fn_pos 0 3
  apply weighted_clause_chain D _ 1
    [F.cbEqRow c0 0 a,F.cbEqRow c1 1 b,F.row2 0 (cbCode a b)] hD
  · cases a <;> cases b <;> simp only [cbLeaf,Bool.false_eq_true,↓reduceIte] <;> nz_lits
  · exact ⟨hE0,hE1,hB,trivial⟩
  · refine ⟨?_,?_,F.row2_0_nz' _ _,trivial⟩
    · intro l hl
      cases a <;> simp [cbEqRow,gateRow,pos,neg] at hl <;>
        rcases hl with rfl | rfl | rfl <;> omega
    · intro l hl
      cases b <;> simp [cbEqRow,gateRow,pos,neg] at hl <;>
        rcases hl with rfl | rfl | rfl <;> omega
  · intro α
    cases a <;> cases b <;>
      simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
        clauseRow,cbLeaf,cbEqRow,cbCode,gateRow,row2_rhs',row2_lits',
        Bool.false_eq_true,↓reduceIte,lsum_cons,lsum_nil,lsum_append,pos,neg]
    all_goals simp only [show codeBit 3 0 = false from by decide,
      show codeBit 3 1 = false from by decide,
      show codeBit 3 2 = true from by decide,
      show codeBit 3 3 = true from by decide,
      show codeBit 6 0 = false from by decide,
      show codeBit 6 1 = true from by decide,
      show codeBit 6 2 = true from by decide,
      show codeBit 6 3 = false from by decide,
      show codeBit 9 0 = true from by decide,
      show codeBit 9 1 = false from by decide,
      show codeBit 9 2 = false from by decide,
      show codeBit 9 3 = true from by decide,
      show codeBit 12 0 = true from by decide,
      show codeBit 12 1 = true from by decide,
      show codeBit 12 2 = false from by decide,
      show codeBit 12 3 = false from by decide, Nat.reduceAdd, Bool.false_eq_true,↓reduceIte] <;> lv_omega

/-- T5f: once gate-order propagation reaches the output, the parity flip
    closes the compared-input branch. The gate-order root is still required. -/
theorem coverage_output (D : List EREF.Row) (hD : ∀ R∈D, Canonical R)
    (a cb live v x y : Nat) (pol : Bool)
    (ha : 1≤a) (hcb : 1≤cb) (hl : 1≤live) (hv : 1≤v)
    (hox : F.b x=pol) (hoy : F.b y= !pol)
    (hL : (clauseRow [(live : Int)]).toE∈D)
    (hR : (clauseRow [(a : Int),-(cb : Int),-(live : Int),(v : Int)]).toE∈D)
    (hX : (F.row5 x).toE∈D) (hY : (F.row5 y).toE∈D)
    (hE : (gateRow [if pol then -(F.val (F.s-1) x : Int) else (F.val (F.s-1) x : Int),
        if pol then (F.val (F.s-1) y : Int) else -(F.val (F.s-1) y : Int)] v false).toE∈D) :
    Refutation (D ++ [negate (clauseRow [(a : Int),-(cb : Int)]).toE]) := by
  have hx := F.val_pos (F.s-1) x
  have hy := F.val_pos (F.s-1) y
  apply clause_chain D _ [clauseRow [(live : Int)],
    clauseRow [(a : Int),-(cb : Int),-(live : Int),(v : Int)],
    F.row5 x,F.row5 y,
    gateRow [if pol then -(F.val (F.s-1) x : Int) else (F.val (F.s-1) x : Int),
      if pol then (F.val (F.s-1) y : Int) else -(F.val (F.s-1) y : Int)] v false] hD
  · nz_lits
  · exact ⟨hL,hR,hX,hY,hE,trivial⟩
  · refine ⟨?_,?_,?_,?_,?_,trivial⟩
    · nz_lits
    · nz_lits
    · intro l hlit
      simp only [row5,hox] at hlit
      cases pol <;> simp [Row.lits,pos,neg] at hlit <;> subst l <;> omega
    · intro l hlit
      simp only [row5,hoy] at hlit
      cases pol <;> simp [Row.lits,pos,neg] at hlit <;> subst l <;> omega
    · cases pol <;> simp only [Bool.false_eq_true,↓reduceIte] <;> nz_lits
  · intro α
    cases pol <;>
      simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
        clauseRow,row5,hox,hoy,gateRow,Bool.false_eq_true,↓reduceIte,
        Bool.not_false,Bool.not_true,lsum_cons,lsum_nil,lsum_append,pos,neg]
    all_goals lv_omega

#print axioms coverage_output
#print axioms cb_leaf
end Fam
end L3

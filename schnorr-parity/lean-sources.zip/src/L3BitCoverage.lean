import L3GateInduction
import L3CoverageEnd

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def bitRoot (t : StI F.V) (cb : Nat) : List Int := [(t.s.A : Int),-(cb : Int)]

theorem bitRoot_bound (t : StI F.V) (ht : F.Good3 t) (cb : Nat)
    (hc : 1≤cb ∧ cb≤t.s.var) : Bounded t.s.var (F.bitRoot t cb) := by
  have hA0 := ht.2.2.2.2.2.1
  have hA1 := ht.2.2.2.2.2.2
  intro l hl
  simp only [bitRoot,List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl | rfl <;> simp <;> omega

/-- The last gate's checked equality contradicts the fixed parity output rows. -/
theorem bitRoot_obl (hk : 2≤F.k) (hs : 2≤F.s) (hpar : F.b=parityBit)
    (t : StI F.V) (ht : F.Good3 t) (bit cb : Nat) (hb : bit<2) (hc : 1≤cb)
    (hr : F.GateRecord bit cb (F.s-1) t) :
    Refutation ((exec F.db5 t.s.cmds) ++ [negate (clauseRow (F.bitRoot t cb)).toE]) := by
  have hD := (exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) (by omega)) t.inv.1).canonical
  have hA := ht.2.2.2.2.2.1
  have hL := ht.1.2.1
  have hV := hr.2.2.1
  have eqs := eqDef_rows F.db5 t.s.cmds _ _ _ hr.1
  apply F.coverage_output _ hD t.s.A cb (t.s.live (F.s-1)) (t.s.veq (F.s-1) bit)
    (F.bitX bit) (F.bitY bit) (parityBit (F.bitX bit)) (by omega) hc (by omega) (by omega)
  · rw [hpar]
  · rw [hpar]; exact F.parity_bitXY hk bit hb
  · exact andDef_row_up F.db5 t.s.cmds _ [] ht.1.1
  · have h := rup_row_mem F.db5 t.s.cmds _ hr.2.1
    simpa only [gateRoot,show ¬F.s-1=0 by omega,↓reduceIte] using h
  · exact exec_mono _ _ _ (F.original_mem_db5 _ (F.row5_mem _ (F.bitX_lt hk bit hb)))
  · exact exec_mono _ _ _ (F.original_mem_db5 _ (F.row5_mem _ (F.bitY_lt hk bit hb)))
  · cases parityBit (F.bitX bit)
    · exact eqs.2.1
    · exact eqs.2.2.1

def cbStart (hm : 1≤F.V) (bit : Nat) (t : StI F.V) : StI F.V :=
  (t.EQ hm (F.fn 0 bit : Int) (F.fn 0 (bit+2) : Int)).2

theorem cbStart_info (hs : 1≤F.s) (hm : 1≤F.V) (bit : Nat) (hb : bit<2) (t : StI F.V) :
    Cmd.eqDef (t.s.var+1) (F.fn 0 bit : Int) (F.fn 0 (bit+2) : Int)∈(F.cbStart hm bit t).s.cmds := by
  have h0 := F.fn_pos 0 bit
  have h1 := F.fn_pos 0 (bit+2)
  have hl0 := F.fn_le 0 bit hs (by omega)
  have hl1 := F.fn_le 0 (bit+2) hs (by omega)
  have hV := t.var_ge
  have hS := F.S4_le_V
  change Cmd.eqDef _ _ _∈t.s.cmds ++ [.eqDef _ (t.s.chk1 _) (t.s.chk1 _)]
  rw [StI.chk1_eq t _ (by simp; omega),StI.chk1_eq t _ (by simp; omega)]
  simp

theorem cbStart_obls (hm : 1≤F.V) (bit : Nat) (t : StI F.V)
    (hc : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.cbStart hm bit t).s.cmds := by
  change ObligationsChecked F.db5 (t.s.cmds ++ [.eqDef _ _ _])
  apply obligations_append _ _ _ hc
  intro o ho; simp [obls] at ho

/-- One complete input-bit case, including the output contradiction. -/
theorem bitStep_obls (hk : 2≤F.k) (hs : 2≤F.s) (hpar : F.b=parityBit) (hm : 1≤F.V)
    (t : StI F.V) (C : List Int) (ht : F.Good3 t) (hf : F.ForceRecord t)
    (bit : Nat) (hb : bit<2) (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.bitStep hm (t,C) bit).1.s.cmds := by
  let u := F.cbStart hm bit t
  let cb := t.s.var+1
  have ku : Keeps2 t u := keeps2_EQ _ hm _ _
  have hu := F.Good3_of_keeps2 ku ht
  have hc : 1≤cb ∧ cb≤u.s.var := by change 1≤t.s.var+1 ∧ t.s.var+1≤t.s.var+1; omega
  have hcb := F.cbStart_info (by omega) hm bit hb t
  let v := (List.range F.s).foldl (F.veqStep hm bit cb) u
  have kv : Keeps2 u v := keeps2_foldl _ _ (F.keeps2_veqStep hm bit cb) u
  have hv := F.Good3_of_keeps2 kv hu
  have hcv : 1≤cb ∧ cb≤v.s.var := ⟨hc.1,Nat.le_trans hc.2 (var_le_of_grows kv.1)⟩
  have hh : ObligationsChecked F.db5 v.s.cmds := F.gateOrder_obls hk (by omega) hm bit cb u hu hb hc
    (F.ForceRecord_keeps ku hf) hcb (F.cbStart_obls hm bit t ho) F.s (by omega)
  have hist := F.gateOrder_history hk hm bit cb u hu hb hc F.s (by omega) (F.s-1) (by omega)
  change ObligationsChecked F.db5 (v.rup (F.bitRoot v cb)).s.cmds
  rw [StI.cmds_rup,StI.chk_eq v _ (F.bitRoot_bound v hv cb hcv)]
  apply obligations_append _ _ _ hh
  intro o ho
  simp only [obls,List.mem_cons,List.not_mem_nil,or_false] at ho
  subst o
  exact F.bitRoot_obl hk hs hpar v hv bit cb hb hc.1 hist

#print axioms bitRoot_obl
#print axioms bitStep_obls
end L3.Fam

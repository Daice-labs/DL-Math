import NativeREDGoalSequence
namespace L3Emitter.NativeRecordedStep
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

/- Executable physical-row-store projection. The semantic database is an
explicit shadow of the surviving physical rows, related by Embeds. This is
not a Rust parser, machine-width, or propagator refinement theorem. -/
inductive Action where
  | pol (tape : List Tok)
  | consequence (row : Row) (proof : NativeScopedLocalGoal.Built)
  | red (row : Row) (witness : FiniteWitness.Data)
      (goals : List (Row × NativeScopedLocalGoal.Built))

structure Built where
  store : Store
  ids : Nat → Nat
  action : Action

def compile (D : List Row) (s : Store) (ids : Nat → Nat) : Step → Built
  | .pol R ts => ⟨push s R,extend ids D.length s.next,
      .pol (ts.map (ReferenceTransport.token ids))⟩
  | .consequence R p =>
    let b := NativeScopedLocalGoal.compile D.length s ids R p
    ⟨push b.closedStore R,extend ids D.length b.closedStore.next,.consequence R b⟩
  | .red R w ps =>
    let b := NativeREDGoalSequence.compile D R w (push s (negate R))
      (extend ids D.length s.next) (R::D) ps
    ⟨push (closeFrom b.store s.next) R,extend ids D.length b.store.next,
      .red R w b.blocks⟩

def execute (D : List Row) (s : Store) : Action → Option Store
  | .pol ts => do
    let R ← polEval s.rows ts []
    return push s R
  | .consequence R p => do
    if !(decide (Canonical R)) then none else do
      let t ← NativeScopedLocalGoal.execute s R p
      return push t R
  | .red R w ps => do
    if !(decide (Canonical R) && FiniteWitness.valid w &&
        decide (ps.map Prod.fst = (R::D).map (fun T => substRow T (FiniteWitness.interpret w))))
      then none else do
      let t ← NativeREDGoalSequence.execute (push s (negate R)) ps
      return push (closeFrom t s.next) R

theorem goal_rows (D : List Row) (C : Row) (w : FiniteWitness.Data)
    (s : Store) (ids : Nat→Nat) (rs : List Row) (ps : List RecordedRefutation.Certificate)
    (hp : checkGoals D C w rs ps=true) :
    (NativeREDGoalSequence.compile D C w s ids rs ps).blocks.map Prod.fst =
      rs.map (fun R => substRow R (FiniteWitness.interpret w)) := by
  induction rs generalizing ps s with
  | nil => cases ps <;> simp_all [checkGoals,NativeREDGoalSequence.compile]
  | cons R rs ih =>
    cases ps with
    | nil => simp [checkGoals] at hp
    | cons p ps =>
      obtain ⟨_,ht⟩ := Bool.and_eq_true_iff.mp hp
      simp only [NativeREDGoalSequence.compile,List.map_cons]
      rw [ih _ ps ht]

theorem correct (M guard : Nat) (D : List Row) (s : Store) (ids : Nat→Nat)
    (c : Step) (hs : 0<s.next) (he : Embeds D s ids)
    (hc : c.accepts M guard D=true) :
    execute D s (compile D s ids c).action=some (compile D s ids c).store ∧
    Embeds (D++[c.row]) (compile D s ids c).store (compile D s ids c).ids ∧
    0<(compile D s ids c).store.next := by
  cases c with
  | pol R ts =>
    have hp := pol_reindex D s ids he ts [] R (of_decide_eq_true hc)
    exact ⟨by simp [compile,execute,hp],push_embeds D s ids he hs R,
      by change 0<s.next+1;omega⟩
  | consequence R p =>
    obtain ⟨hr,hp⟩ := Bool.and_eq_true_iff.mp hc
    have hh := NativeScopedLocalGoal.correct D s ids R hs he p hp
    have hn : 0<(NativeScopedLocalGoal.compile D.length s ids R p).closedStore.next := by
      rw [hh.2.2];omega
    exact ⟨by simp [compile,execute,hr,hh.1],push_embeds D _ ids hh.2.1 hn R,
      by change 0<_+1;omega⟩
  | red R w ps =>
    obtain ⟨hpre,hgoals⟩ := Bool.and_eq_true_iff.mp hc
    obtain ⟨hpre,_⟩ := Bool.and_eq_true_iff.mp hpre
    obtain ⟨hr,hw⟩ := Bool.and_eq_true_iff.mp hpre
    have hs1 : 0<(push s (negate R)).next := by change 0<s.next+1;omega
    have hh := NativeREDGoalSequence.correct D R w (push s (negate R))
      (extend ids D.length s.next) (R::D) ps hs1
      (push_embeds D s ids he hs (negate R)) hgoals
    have hg := goal_rows D R w (push s (negate R)) (extend ids D.length s.next) (R::D) ps hgoals
    refine ⟨?_,NativeREDGoalSequence.finished_embedding D R w s ids ps hs he hgoals,?_⟩
    · simp only [compile,execute,hr,hw,Bool.true_and,hg,decide_true,Bool.not_true,
        Bool.false_eq_true,↓reduceIte,hh.1,bind,Option.bind,pure]
    · change 0<_+1;omega

#print axioms correct
#print axioms goal_rows
end L3Emitter.NativeRecordedStep

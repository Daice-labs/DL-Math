import FirstBaseLeaves
import RetainedBlockFold
namespace L3Emitter.FirstValueBank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram

def pins (n:Nat) (hn:2≤n):=[FirstGatePins.row n hn 0,FirstGatePins.row n hn 1]
def prepared (n:Nat) (hn:2≤n):=SharedValueBank.result n hn++pins n hn++FirstUnaryMux.rows n hn
def prepare (n:Nat) (hn:2≤n):Program:=
  FirstGatePins.program n hn (SharedValueBank.result n hn)++
    FirstUnaryMux.program n hn (SharedValueBank.result n hn++pins n hn)
theorem prepare_checks (n:Nat) (hn:2≤n):check (SharedValueBank.result n hn) (prepare n hn)=some (prepared n hn):=by
  exact check_append _ _ _ _ _ (FirstGatePins.program_checks n hn _ (fun _ h=>h))
    (FirstUnaryMux.checks n hn _ (fun R h=>List.mem_append_left _ h))
theorem shared (n:Nat) (hn:2≤n):∀R∈SharedValueBank.result n hn,R∈prepared n hn:=
  fun R h=>List.mem_append_left _ (List.mem_append_left _ h)
theorem mux (n:Nat) (hn:2≤n):∀R∈FirstUnaryMux.rows n hn,R∈prepared n hn:=
  fun R h=>List.mem_append_right _ h
theorem pin (n:Nat) (hn:2≤n) (p:Nat) (hp:p<2):FirstGatePins.row n hn p∈prepared n hn:=by
  apply List.mem_append_left
  apply List.mem_append_right
  rcases (show p=0∨p=1 by omega) with rfl|rfl <;> simp [pins]

def xRows (n:Nat) (hn:2≤n) (x:Nat):=FirstCofactorRows.rows n hn x++FirstGateValue.rows n hn x false++FirstGateValue.rows n hn x true
def xProgram (n:Nat) (hn:2≤n) (x:Nat) (D:List Row):Program:=
  FirstCofactorRows.program n hn x D++FirstGateValue.program n hn x false (D++FirstCofactorRows.rows n hn x)++
    FirstGateValue.program n hn x true (D++FirstCofactorRows.rows n hn x++FirstGateValue.rows n hn x false)

theorem x_checks (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n) (D:List Row)
    (hd:∀R∈prepared n hn,R∈D):check D (xProgram n hn x D)=some (D++xRows n hn x):=by
  have h0:=FirstCofactorRows.checks n hn x hx D (fun R h=>hd R (shared n hn R h)) (fun p hp=>hd _ (pin n hn p hp))
  have h1:=FirstGateValue.checks n hn x hx false (D++FirstCofactorRows.rows n hn x)
    (fun R h=>List.mem_append_left _ (hd R (shared n hn R h)))
    (fun R h=>List.mem_append_left _ (hd R (mux n hn R h))) (fun R h=>List.mem_append_right _ h)
  have h2:=FirstGateValue.checks n hn x hx true (D++FirstCofactorRows.rows n hn x++FirstGateValue.rows n hn x false)
    (fun R h=>List.mem_append_left _ (List.mem_append_left _ (hd R (shared n hn R h))))
    (fun R h=>List.mem_append_left _ (List.mem_append_left _ (hd R (mux n hn R h))))
    (fun R h=>List.mem_append_left _ (List.mem_append_right _ h))
  simpa only [xProgram,xRows,List.append_assoc] using check_append _ _ _ _ _ (check_append _ _ _ _ _ h0 h1) h2

def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (xProgram n hn) (xRows n hn)
  (List.range (FamilyNamespace.truthRows n)) (prepared n hn)
def result (n:Nat) (hn:2≤n):=prepared n hn++RetainedBlockFold.body (xRows n hn) (List.range (FamilyNamespace.truthRows n))
theorem checks (n:Nat) (hn:2≤n):check (prepared n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks (prepared n hn) _ _ (fun x=>x<FamilyNamespace.truthRows n)
    (x_checks n hn) _ (fun x hx=>List.mem_range.mp hx) _ (fun _ h=>h)
theorem retained (n:Nat) (hn:2≤n):∀R∈SharedValueBank.result n hn,R∈result n hn:=
  fun R h=>List.mem_append_left _ (shared n hn R h)
theorem value_row (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n) (v:Bool):
    FirstGateValue.target n hn x v∈result n hn:=by
  apply List.mem_append_right
  apply RetainedBlockFold.contains _ _ x (List.mem_range.mpr hx)
  cases v
  · exact List.mem_append_left _ (List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _)))
  · exact List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _))
theorem original_to_first_values (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (SharedValueBank.original_to_shared_values n hn)
    (L3.Fam.checkedTrace_trans (check_trace _ _ _ (prepare_checks n hn)) (check_trace _ _ _ (checks n hn)))

#print axioms checks
#print axioms value_row
#print axioms original_to_first_values
end L3Emitter.FirstValueBank

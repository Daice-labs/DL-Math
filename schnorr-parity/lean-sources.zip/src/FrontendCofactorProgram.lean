import FrontendCofactor
import AliasProgram
import NormalizedCofactorBytes

namespace L3Emitter.FrontendCofactorProgram
open EREF EREF.GeneralRED FrontendCofactor CofactorSection PolTapeBytes

def program (n : Nat) (hn : 2 ≤ n) (B : Nat) (js : List Job) : AliasProgram.Program :=
  js.map (fun j => (resultRow n (3*(n+1)-4) (offset n hn) j,
    relocatedTape n hn B j))

/-- Executable checking, including actual row lookup and reference rebasing
    after the entire completed frontend. -/
theorem program_check (n : Nat) (hn : 2 ≤ n) (B : Nat) (hB : 0 < B)
    (js : List Job) (hj : ∀ j ∈ js, j ∈ jobs n (3*(n+1)-4)) (pre : List Row) :
    AliasProgram.check (target n hn B ++ pre) (program n hn B js) =
      some ((target n hn B ++ pre) ++
        js.map (resultRow n (3*(n+1)-4) (offset n hn))) := by
  induction js generalizing pre with
  | nil => simp [program, AliasProgram.check]
  | cons j js ih =>
    have he := relocated_succeeds n hn B hB j (hj j (by simp))
    have hm := polEval_mono _ _ (dbOf_ext_append (target n hn B) pre) _ [] _ he
    simp only [program, List.map_cons, AliasProgram.check, hm, ↓reduceIte]
    have ht := ih (by intro q hq; exact hj q (by simp [hq]))
      (pre ++ [resultRow n (3*(n+1)-4) (offset n hn) j])
    simpa only [program, List.map_cons, List.append_assoc, List.singleton_append] using ht

def width (n : Nat) (hn : 2 ≤ n) (B : Nat) : Nat :=
  CofactorBytes.width n (3*(n+1)-4) (offset n hn) B + (target n hn B).length + 1

theorem relocated_bounded (n : Nat) (hn : 2 ≤ n) (B : Nat)
    (j : Job) (hj : j ∈ jobs n (3*(n+1)-4)) :
    ∀ t ∈ relocatedTape n hn B j, Bounded (width n hn B) t := by
  intro t ht
  obtain ⟨u, hu, rfl⟩ := List.mem_map.mp ht
  have h := NormalizedCofactorBytes.source_tokens_bounded n (3*(n+1)-4)
    (offset n hn) B j hj u hu
  have hm : CofactorBytes.width n (3*(n+1)-4) (offset n hn) B ≤ width n hn B := by
    unfold width; omega
  cases u with
  | ref i =>
    have hr := List.idxOf_le_length (l := target n hn B)
      (a := (dbOf (CofactorSemantics.database n (3*(n+1)-4) (offset n hn) B) i).getD contra)
    change refMap n hn B i ≤ _
    unfold refMap ReferenceTransport.locate width
    omega
  | lit l => exact le_trans h hm
  | mul m => exact le_trans h hm
  | div d => exact le_trans h hm
  | add => trivial
  | sat => trivial

theorem program_document (n : Nat) (hn : 2 ≤ n) (B : Nat) (js : List Job) :
    AliasProgram.document (program n hn B js) =
      js.flatMap (fun j => tapeDoc (relocatedTape n hn B j)) := by
  simp [AliasProgram.document, program, List.flatMap_map]

/-- This bound includes the actual enlarged database's reference widths.
    It is a section bound, not a closed bound in n for the whole emitter. -/
theorem program_bytes (n : Nat) (hn : 2 ≤ n) (B : Nat) :
    (emit (AliasProgram.document (program n hn B (jobs n (3*(n+1)-4))))).length ≤
      8*(3*(n+1)-4)*FamilyNamespace.truthRows n *
        (7 + 70*(3 + digits (width n hn B))) := by
  rw [program_document, emit_length]
  have h := CofactorBytes.document_flatMap_bound (jobs n (3*(n+1)-4))
    (fun j => tapeDoc (relocatedTape n hn B j))
    (7 + 70*(3 + digits (width n hn B))) (by
      intro j hj
      have hb := tape_bound (width n hn B) _ (relocated_bounded n hn B j hj)
      simpa only [emit_length, relocated_token_count] using hb)
  simpa only [NormalizedCofactorBytes.job_count] using h

theorem all_jobs_check (n : Nat) (hn : 2 ≤ n) (B : Nat) (hB : 0 < B) :
    AliasProgram.check (target n hn B) (program n hn B (jobs n (3*(n+1)-4))) =
      some (target n hn B ++ (jobs n (3*(n+1)-4)).map
        (resultRow n (3*(n+1)-4) (offset n hn))) := by
  simpa using program_check n hn B hB (jobs n (3*(n+1)-4)) (by intros; assumption) []

end L3Emitter.FrontendCofactorProgram

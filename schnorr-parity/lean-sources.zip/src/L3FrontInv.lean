/-
The definition rows of frontend stages 0–3 (live, edges, eqrow, force, p0force,
consumer/eligible, A) are recorded in the commands under the names the builder stores,
and those names are never changed by any later stage. `Good3` bundles everything the
stage 5–7 templates need about the database.
-/
import L3Chain

namespace L3
open EREF EREF.GeneralRED

namespace StI
variable {m0 : Nat}

/-- a projection of the state untouched by `rup` is untouched by `split` -/
theorem split_proj {β : Type} (f : St → β) (hf : ∀ s c, f (s.rup c) = f s) (vs : List Int) :
    ∀ (t : StI m0) (c : List Int), f (t.split c vs).s = f t.s := by
  induction vs with
  | nil => intro t c; exact hf _ _
  | cons v vs ih =>
    intro t c
    show f (((t.split (c ++ [v]) vs).split (c ++ [-v]) vs).s.rup c) = _
    rw [hf, ih, ih]

theorem live_split (vs : List Int) (t : StI m0) (c : List Int) : (t.split c vs).s.live = t.s.live :=
  split_proj St.live (fun _ _ => rfl) vs t c
theorem edges_split (vs : List Int) (t : StI m0) (c : List Int) : (t.split c vs).s.edges = t.s.edges :=
  split_proj St.edges (fun _ _ => rfl) vs t c
theorem p0force_split (vs : List Int) (t : StI m0) (c : List Int) : (t.split c vs).s.p0force = t.s.p0force :=
  split_proj St.p0force (fun _ _ => rfl) vs t c
theorem eligible_split (vs : List Int) (t : StI m0) (c : List Int) : (t.split c vs).s.eligible = t.s.eligible :=
  split_proj St.eligible (fun _ _ => rfl) vs t c
theorem A_split (vs : List Int) (t : StI m0) (c : List Int) : (t.split c vs).s.A = t.s.A :=
  split_proj St.A (fun _ _ => rfl) vs t c
theorem veq_split (vs : List Int) (t : StI m0) (c : List Int) : (t.split c vs).s.veq = t.s.veq :=
  split_proj St.veq (fun _ _ => rfl) vs t c
theorem var_split (vs : List Int) (t : StI m0) (c : List Int) : (t.split c vs).s.var = t.s.var :=
  split_proj St.var (fun _ _ => rfl) vs t c

/-- the name maps fixed after stage 1 -/
def Same1 (t t' : StI m0) : Prop := t'.s.live = t.s.live ∧ t'.s.edges = t.s.edges
/-- the name maps fixed after stage 3 -/
def Same2 (t t' : StI m0) : Prop := Same1 t t' ∧ t'.s.eqrow = t.s.eqrow ∧ t'.s.force = t.s.force ∧
  t'.s.p0force = t.s.p0force ∧ t'.s.eligible = t.s.eligible ∧ t'.s.A = t.s.A

def Keeps1 (t t' : StI m0) : Prop := GrowsTo t t' ∧ Same1 t t'
def Keeps2 (t t' : StI m0) : Prop := GrowsTo t t' ∧ Same2 t t'

theorem keeps1_refl (t : StI m0) : Keeps1 t t := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps1_trans {a b c : StI m0} (h1 : Keeps1 a b) (h2 : Keeps1 b c) : Keeps1 a c :=
  ⟨growsTo_trans h1.1 h2.1, h2.2.1.trans h1.2.1, h2.2.2.trans h1.2.2⟩
theorem keeps2_refl (t : StI m0) : Keeps2 t t := ⟨growsTo_refl t, ⟨rfl, rfl⟩, rfl, rfl, rfl, rfl, rfl⟩
theorem keeps2_trans {a b c : StI m0} (h1 : Keeps2 a b) (h2 : Keeps2 b c) : Keeps2 a c :=
  ⟨growsTo_trans h1.1 h2.1, ⟨h2.2.1.1.trans h1.2.1.1, h2.2.1.2.trans h1.2.1.2⟩,
   h2.2.2.1.trans h1.2.2.1, h2.2.2.2.1.trans h1.2.2.2.1, h2.2.2.2.2.1.trans h1.2.2.2.2.1,
   h2.2.2.2.2.2.1.trans h1.2.2.2.2.2.1, h2.2.2.2.2.2.2.trans h1.2.2.2.2.2.2⟩
theorem keeps2_keeps1 {a b : StI m0} (h : Keeps2 a b) : Keeps1 a b := ⟨h.1, h.2.1⟩

theorem keeps2_OR (t : StI m0) (xs) : Keeps2 t (t.OR xs).2 := ⟨growsTo_OR t xs, ⟨rfl, rfl⟩, rfl, rfl, rfl, rfl, rfl⟩
theorem keeps2_AND (t : StI m0) (xs) : Keeps2 t (t.AND xs).2 := ⟨growsTo_AND t xs, ⟨rfl, rfl⟩, rfl, rfl, rfl, rfl, rfl⟩
theorem keeps2_EQ (t : StI m0) (hm : 1 ≤ m0) (a b) : Keeps2 t (t.EQ hm a b).2 :=
  ⟨growsTo_EQ t hm a b, ⟨rfl, rfl⟩, rfl, rfl, rfl, rfl, rfl⟩
theorem keeps2_rup (t : StI m0) (c) : Keeps2 t (t.rup c) := ⟨growsTo_rup t c, ⟨rfl, rfl⟩, rfl, rfl, rfl, rfl, rfl⟩
theorem keeps2_split (t : StI m0) (c vs) : Keeps2 t (t.split c vs) :=
  ⟨growsTo_split t c vs, ⟨live_split vs t c, edges_split vs t c⟩, eqrow_split vs t c, force_split vs t c,
   p0force_split vs t c, eligible_split vs t c, A_split vs t c⟩
theorem keeps2_setVeq (t : StI m0) (f) : Keeps2 t (t.setVeq f) := ⟨growsTo_refl t, ⟨rfl, rfl⟩, rfl, rfl, rfl, rfl, rfl⟩
theorem keeps2_setBranches (t : StI m0) (f) : Keeps2 t (t.setBranches f) := ⟨growsTo_refl t, ⟨rfl, rfl⟩, rfl, rfl, rfl, rfl, rfl⟩
theorem keeps2_setB (t : StI m0) (b) : Keeps2 t (t.setB b) := ⟨growsTo_refl t, ⟨rfl, rfl⟩, rfl, rfl, rfl, rfl, rfl⟩

theorem keeps1_OR (t : StI m0) (xs) : Keeps1 t (t.OR xs).2 := keeps2_keeps1 (keeps2_OR t xs)
theorem keeps1_AND (t : StI m0) (xs) : Keeps1 t (t.AND xs).2 := keeps2_keeps1 (keeps2_AND t xs)
theorem keeps1_EQ (t : StI m0) (hm : 1 ≤ m0) (a b) : Keeps1 t (t.EQ hm a b).2 := keeps2_keeps1 (keeps2_EQ t hm a b)
theorem keeps1_rup (t : StI m0) (c) : Keeps1 t (t.rup c) := keeps2_keeps1 (keeps2_rup t c)
theorem keeps1_setEqrow (t : StI m0) (f) : Keeps1 t (t.setEqrow f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps1_setForce (t : StI m0) (f) : Keeps1 t (t.setForce f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps1_setP0force (t : StI m0) (f) : Keeps1 t (t.setP0force f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps1_setEligible (t : StI m0) (f) : Keeps1 t (t.setEligible f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps1_setA (t : StI m0) (a) : Keeps1 t (t.setA a) := ⟨growsTo_refl t, rfl, rfl⟩

theorem keeps2_foldl {α : Type} (f : StI m0 → α → StI m0) (l : List α) (hf : ∀ t x, Keeps2 t (f t x)) :
    ∀ t, Keeps2 t (l.foldl f t) := by
  intro t
  apply foldl_pres (fun t' => Keeps2 t t') f l
  · intro x _ t' h; exact keeps2_trans h (hf t' x)
  · exact keeps2_refl t

theorem keeps2_foldl_pair {α β : Type} (f : StI m0 × β → α → StI m0 × β) (l : List α)
    (hf : ∀ acc x, Keeps2 acc.1 (f acc x).1) : ∀ acc, Keeps2 acc.1 (l.foldl f acc).1 := by
  intro acc
  apply foldl_pres (fun acc' => Keeps2 acc.1 acc'.1) f l
  · intro x _ acc' h; exact keeps2_trans h (hf acc' x)
  · exact keeps2_refl _

theorem keeps1_foldl {α : Type} (f : StI m0 → α → StI m0) (l : List α) (hf : ∀ t x, Keeps1 t (f t x)) :
    ∀ t, Keeps1 t (l.foldl f t) := by
  intro t
  apply foldl_pres (fun t' => Keeps1 t t') f l
  · intro x _ t' h; exact keeps1_trans h (hf t' x)
  · exact keeps1_refl t

theorem keeps1_foldl_pair {α β : Type} (f : StI m0 × β → α → StI m0 × β) (l : List α)
    (hf : ∀ acc x, Keeps1 acc.1 (f acc x).1) : ∀ acc, Keeps1 acc.1 (l.foldl f acc).1 := by
  intro acc
  apply foldl_pres (fun acc' => Keeps1 acc.1 acc'.1) f l
  · intro x _ acc' h; exact keeps1_trans h (hf acc' x)
  · exact keeps1_refl _

end StI

namespace Fam
variable (F : Fam)
open StI

/-! ### Stages 4–7 keep every stage-0–3 name map -/

theorem keeps2_stage4 (t : StI F.V) : Keeps2 t (F.stage4 t) := by
  apply keeps2_foldl _ _ _ t
  intro t' gp; obtain ⟨g, port⟩ := gp
  apply keeps2_foldl _ _ _ t'
  intro t'' ab; obtain ⟨a, b⟩ := ab
  exact keeps2_trans (keeps2_rup _ _) (keeps2_rup _ _)

theorem keeps2_portEqStep (hm : 1 ≤ F.V) (g bit cb : Nat) (t : StI F.V) (port : Nat) :
    Keeps2 t (F.portEqStep hm g bit cb t port) := by
  unfold portEqStep
  apply keeps2_trans (keeps2_EQ _ hm _ _)
  apply keeps2_trans (keeps2_foldl _ _ (fun t' j => keeps2_split _ _ _) _)
  exact keeps2_trans (keeps2_rup _ _) (keeps2_rup _ _)

theorem keeps2_veqStep (hm : 1 ≤ F.V) (bit cb : Nat) (t : StI F.V) (g : Nat) :
    Keeps2 t (F.veqStep hm bit cb t g) := by
  unfold veqStep
  apply keeps2_trans (keeps2_EQ _ hm _ _)
  apply keeps2_trans (keeps2_setVeq _ _)
  split
  · exact keeps2_split _ _ _
  · exact keeps2_trans (keeps2_foldl _ _ (fun t' port => F.keeps2_portEqStep hm g bit cb t' port) _) (keeps2_split _ _ _)

theorem keeps2_bitStep (hm : 1 ≤ F.V) (acc : StI F.V × List Int) (bit : Nat) :
    Keeps2 acc.1 (F.bitStep hm acc bit).1 := by
  obtain ⟨t, C⟩ := acc
  show Keeps2 t ((((List.range F.s).foldl
    (F.veqStep hm bit (t.EQ hm (F.fn 0 bit : Int) (F.fn 0 (bit + 2) : Int)).1)
    (t.EQ hm (F.fn 0 bit : Int) (F.fn 0 (bit + 2) : Int)).2)).rup _)
  apply keeps2_trans (keeps2_EQ _ hm _ _)
  apply keeps2_trans (keeps2_foldl _ _ (fun t' g => F.keeps2_veqStep hm bit _ t' g) _)
  exact keeps2_rup _ _

theorem keeps2_stage5 (hm : 1 ≤ F.V) (t : StI F.V) : Keeps2 t (F.stage5 hm t) := by
  show Keeps2 t ((([0, 1].foldl (F.bitStep hm) (t, [])).1.split _ _).rup _)
  apply keeps2_trans (keeps2_foldl_pair _ _ (fun acc bit => F.keeps2_bitStep hm acc bit) (t, []))
  exact keeps2_trans (keeps2_split _ _ _) (keeps2_rup _ _)

theorem keeps2_outSplit (t : StI F.V) (pb : Nat × Nat) : Keeps2 t (F.outSplit t pb) := by
  obtain ⟨port, b⟩ := pb; exact keeps2_split _ _ _
theorem keeps2_outRup (t : StI F.V) (port : Nat) : Keeps2 t (F.outRup t port) :=
  keeps2_trans (keeps2_rup _ _) (keeps2_rup _ _)
theorem keeps2_stage6 (t : StI F.V) : Keeps2 t (F.stage6 t) := by
  unfold stage6
  apply keeps2_trans (keeps2_foldl _ _ (fun t' pb => F.keeps2_outSplit t' pb) t)
  apply keeps2_trans (keeps2_foldl _ _ (fun t' port => F.keeps2_outRup t' port) _)
  exact keeps2_rup _ _

theorem keeps2_branchStep (b : Nat) (acc : StI F.V × List Int) (g : Nat) : Keeps2 acc.1 (F.branchStep b acc g).1 := by
  obtain ⟨t, brs⟩ := acc
  exact keeps2_trans (keeps2_OR _ _) (keeps2_trans (keeps2_AND _ _) (keeps2_setBranches _ _))
theorem keeps2_bStep (acc : StI F.V × List Int) (b : Nat) : Keeps2 acc.1 (F.bStep acc b).1 :=
  keeps2_foldl_pair _ _ (fun acc' g => F.keeps2_branchStep b acc' g) acc
theorem keeps2_bRup (t : StI F.V) (b : Nat) : Keeps2 t (F.bRup t b) := keeps2_rup _ _
theorem keeps2_stage7 (t : StI F.V) : Keeps2 t (F.stage7 t) := by
  unfold stage7
  simp only []
  generalize hP : (List.range' 1 (F.s - 2)).foldl F.bStep (t, []) = P
  have k1 : Keeps2 t P.1 := by rw [← hP]; exact keeps2_foldl_pair _ _ (fun acc b => F.keeps2_bStep acc b) (t, [])
  obtain ⟨t', brs⟩ := P
  simp only []
  apply keeps2_trans k1
  apply keeps2_trans (keeps2_OR _ _)
  apply keeps2_trans (keeps2_setB _ _)
  apply keeps2_trans (keeps2_foldl _ _ (fun t' b => F.keeps2_bRup t' b) _)
  exact keeps2_rup _ _

/-! ### Stages 2–3 keep live and edges -/

theorem keeps1_eqStep (hm : 1 ≤ F.V) (g port : Nat) (acc : StI F.V × List Int) (b : Nat) :
    Keeps1 acc.1 (F.eqStep hm g port acc b).1 := by
  obtain ⟨t, eqs⟩ := acc
  exact keeps1_trans (keeps1_EQ _ hm _ _) (keeps1_setEqrow _ _)

theorem keeps1_portStep (hm : 1 ≤ F.V) (g : Nat) (acc : StI F.V × List Int) (port : Nat) :
    Keeps1 acc.1 (F.portStep hm g acc port).1 := by
  obtain ⟨t, ports⟩ := acc
  show Keeps1 t ((((([0, 1].foldl (F.eqStep hm g port) (t, [])).1.OR _).2.setForce _).AND _).2.setP0force _)
  apply keeps1_trans (keeps1_foldl_pair _ _ (fun acc b => F.keeps1_eqStep hm g port acc b) (t, []))
  exact keeps1_trans (keeps1_OR _ _) (keeps1_trans (keeps1_setForce _ _)
    (keeps1_trans (keeps1_AND _ _) (keeps1_setP0force _ _)))

theorem keeps1_eligStep (hm : 1 ≤ F.V) (t : StI F.V) (g : Nat) : Keeps1 t (F.eligStep hm t g) := by
  show Keeps1 t (((([0, 1].foldl (F.portStep hm g) (t, [])).1.OR _).2.AND _).2.setEligible _)
  apply keeps1_trans (keeps1_foldl_pair _ _ (fun acc port => F.keeps1_portStep hm g acc port) (t, []))
  exact keeps1_trans (keeps1_OR _ _) (keeps1_trans (keeps1_AND _ _) (keeps1_setEligible _ _))

theorem keeps1_stage2 (hm : 1 ≤ F.V) (t : StI F.V) : Keeps1 t (F.stage2 hm t) :=
  keeps1_foldl _ _ (fun t' g => F.keeps1_eligStep hm t' g) t

theorem keeps1_stage3 (t : StI F.V) : Keeps1 t (F.stage3 t) :=
  keeps1_trans (keeps1_OR _ _) (keeps1_setA _ _)

/-! ### The definition predicates -/

/-- the edge terms of gate g in loop order -/
def edgeTerms (t : StI F.V) (g : Nat) : List Int := (F.edgePairs g).map fun hp => (t.s.edges g hp.1 hp.2 : Int)

/-- `live[g] = OR(edges of g)` for g ≤ s−2 -/
def PLive (g : Nat) (t : StI F.V) : Prop :=
  Cmd.orDef (t.s.live g) (F.edgeTerms t g) ∈ t.s.cmds ∧ F.V < t.s.live g ∧ t.s.live g ≤ t.s.var
/-- `live[s-1] = AND([])` -/
def PLiveLast (t : StI F.V) : Prop :=
  Cmd.andDef (t.s.live (F.s - 1)) [] ∈ t.s.cmds ∧ F.V < t.s.live (F.s - 1) ∧ t.s.live (F.s - 1) ≤ t.s.var
/-- `edge{g}-{h}-{p} = AND([live[h], sel(h,p,k+g)])` -/
def PEdge (g h p : Nat) (t : StI F.V) : Prop :=
  Cmd.andDef (t.s.edges g h p) [(t.s.live h : Int), (F.sel h p (F.k + g) : Int)] ∈ t.s.cmds ∧
  F.V < t.s.edges g h p ∧ t.s.edges g h p ≤ t.s.var
/-- `p0force{g}-{port} = AND([sel(g,port,0), force])` -/
def PP0 (g port : Nat) (t : StI F.V) : Prop :=
  Cmd.andDef (t.s.p0force g port) [(F.sel g port 0 : Int), (t.s.force g port : Int)] ∈ t.s.cmds ∧
  F.V < t.s.p0force g port ∧ t.s.p0force g port ≤ t.s.var
/-- `consumer = OR(p0force 0, p0force 1)`, `eligible[g] = AND([live[g], consumer])` -/
def PElig (g : Nat) (t : StI F.V) : Prop :=
  ∃ cons, Cmd.orDef cons [(t.s.p0force g 0 : Int), (t.s.p0force g 1 : Int)] ∈ t.s.cmds ∧
    Cmd.andDef (t.s.eligible g) [(t.s.live g : Int), (cons : Int)] ∈ t.s.cmds ∧
    F.V < cons ∧ F.V < t.s.eligible g ∧ t.s.eligible g ≤ t.s.var
/-- `A = OR(eligible[1..s-1])` -/
def PA (t : StI F.V) : Prop :=
  Cmd.orDef t.s.A ((List.range' 1 (F.s - 1)).map fun g => (t.s.eligible g : Int)) ∈ t.s.cmds ∧
  F.V < t.s.A ∧ t.s.A ≤ t.s.var

theorem PLive_of_grows {g : Nat} {t t' : StI F.V} (hg : GrowsTo t t') (hl : t'.s.live g = t.s.live g)
    (he : ∀ hp ∈ F.edgePairs g, t'.s.edges g hp.1 hp.2 = t.s.edges g hp.1 hp.2) (h : F.PLive g t) : F.PLive g t' := by
  obtain ⟨h1, h2, h3⟩ := h
  have hterms : F.edgeTerms t' g = F.edgeTerms t g := by
    unfold edgeTerms; apply List.map_congr_left; intro hp hhp; rw [he hp hhp]
  refine ⟨?_, ?_, ?_⟩
  · rw [hl, hterms]; exact StI.mem_of_grows hg h1
  · rw [hl]; exact h2
  · rw [hl]; exact Nat.le_trans h3 (StI.var_le_of_grows hg)

theorem PLive_of_keeps1 {g : Nat} {t t' : StI F.V} (k : Keeps1 t t') (h : F.PLive g t) : F.PLive g t' :=
  F.PLive_of_grows k.1 (by rw [k.2.1]) (fun hp _ => by rw [k.2.2]) h

theorem PLiveLast_of_grows {t t' : StI F.V} (hg : GrowsTo t t') (hl : t'.s.live (F.s - 1) = t.s.live (F.s - 1))
    (h : F.PLiveLast t) : F.PLiveLast t' := by
  obtain ⟨h1, h2, h3⟩ := h
  refine ⟨?_, ?_, ?_⟩
  · rw [hl]; exact StI.mem_of_grows hg h1
  · rw [hl]; exact h2
  · rw [hl]; exact Nat.le_trans h3 (StI.var_le_of_grows hg)

theorem PLiveLast_of_keeps1 {t t' : StI F.V} (k : Keeps1 t t') (h : F.PLiveLast t) : F.PLiveLast t' :=
  F.PLiveLast_of_grows k.1 (by rw [k.2.1]) h

theorem PEdge_of_grows {g h p : Nat} {t t' : StI F.V} (hg : GrowsTo t t') (hl : t'.s.live h = t.s.live h)
    (he : t'.s.edges g h p = t.s.edges g h p) (hh : F.PEdge g h p t) : F.PEdge g h p t' := by
  obtain ⟨h1, h2, h3⟩ := hh
  refine ⟨?_, ?_, ?_⟩
  · rw [hl, he]; exact StI.mem_of_grows hg h1
  · rw [he]; exact h2
  · rw [he]; exact Nat.le_trans h3 (StI.var_le_of_grows hg)

theorem PEdge_of_keeps1 {g h p : Nat} {t t' : StI F.V} (k : Keeps1 t t') (hh : F.PEdge g h p t) : F.PEdge g h p t' :=
  F.PEdge_of_grows k.1 (by rw [k.2.1]) (by rw [k.2.2]) hh

theorem PP0_of_grows {g port : Nat} {t t' : StI F.V} (hg : GrowsTo t t')
    (hp : t'.s.p0force g port = t.s.p0force g port) (hf : t'.s.force g port = t.s.force g port)
    (h : F.PP0 g port t) : F.PP0 g port t' := by
  obtain ⟨h1, h2, h3⟩ := h
  refine ⟨?_, ?_, ?_⟩
  · rw [hp, hf]; exact StI.mem_of_grows hg h1
  · rw [hp]; exact h2
  · rw [hp]; exact Nat.le_trans h3 (StI.var_le_of_grows hg)

theorem PP0_of_keeps2 {g port : Nat} {t t' : StI F.V} (k : Keeps2 t t') (h : F.PP0 g port t) : F.PP0 g port t' :=
  F.PP0_of_grows k.1 (by rw [k.2.2.2.2.1]) (by rw [k.2.2.2.1]) h

theorem PElig_of_grows {g : Nat} {t t' : StI F.V} (hg : GrowsTo t t')
    (hp : ∀ port, t'.s.p0force g port = t.s.p0force g port) (hl : t'.s.live g = t.s.live g)
    (he : t'.s.eligible g = t.s.eligible g) (h : F.PElig g t) : F.PElig g t' := by
  obtain ⟨cons, h1, h2, h3, h4, h5⟩ := h
  refine ⟨cons, ?_, ?_, h3, ?_, ?_⟩
  · rw [hp 0, hp 1]; exact StI.mem_of_grows hg h1
  · rw [he, hl]; exact StI.mem_of_grows hg h2
  · rw [he]; exact h4
  · rw [he]; exact Nat.le_trans h5 (StI.var_le_of_grows hg)

theorem PElig_of_keeps2 {g : Nat} {t t' : StI F.V} (k : Keeps2 t t') (h : F.PElig g t) : F.PElig g t' :=
  F.PElig_of_grows k.1 (fun port => by rw [k.2.2.2.2.1]) (by rw [k.2.1.1]) (by rw [k.2.2.2.2.2.1]) h

theorem PA_of_grows {t t' : StI F.V} (hg : GrowsTo t t') (ha : t'.s.A = t.s.A)
    (he : ∀ g, 1 ≤ g → g < F.s → t'.s.eligible g = t.s.eligible g) (h : F.PA t) : F.PA t' := by
  obtain ⟨h1, h2, h3⟩ := h
  have hl : ((List.range' 1 (F.s - 1)).map fun g => (t'.s.eligible g : Int))
      = (List.range' 1 (F.s - 1)).map fun g => (t.s.eligible g : Int) := by
    apply List.map_congr_left; intro g hg
    have := List.mem_range'_1.mp hg
    rw [he g this.1 (by omega)]
  refine ⟨?_, ?_, ?_⟩
  · rw [ha, hl]; exact StI.mem_of_grows hg h1
  · rw [ha]; exact h2
  · rw [ha]; exact Nat.le_trans h3 (StI.var_le_of_grows hg)

theorem PA_of_keeps2 {t t' : StI F.V} (k : Keeps2 t t') (h : F.PA t) : F.PA t' :=
  F.PA_of_grows k.1 (by rw [k.2.2.2.2.2.2]) (fun g _ _ => by rw [k.2.2.2.2.2.1]) h

theorem PEq_of_keeps2 {g port b : Nat} {t t' : StI F.V} (k : Keeps2 t t') (h : F.PEq g port b t) : F.PEq g port b t' :=
  F.PEq_of_grows k.1 (by rw [k.2.2.1]) h
theorem PForce_of_keeps2 {g port : Nat} {t t' : StI F.V} (k : Keeps2 t t') (h : F.PForce g port t) : F.PForce g port t' :=
  F.PForce_of_grows k.1 (fun b => by rw [k.2.2.1]) (by rw [k.2.2.2.1]) h

/-- everything the stage 5–7 templates need about the stage 0–3 definitions -/
def Good3 (t : StI F.V) : Prop :=
  F.PLiveLast t ∧
  (∀ g, g < F.s - 1 → F.PLive g t ∧ ∀ hp ∈ F.edgePairs g, F.PEdge g hp.1 hp.2 t) ∧
  (∀ g port, 1 ≤ g → g < F.s → port < 2 →
    F.PEq g port 0 t ∧ F.PEq g port 1 t ∧ F.PForce g port t ∧ F.PP0 g port t) ∧
  (∀ g, 1 ≤ g → g < F.s → F.PElig g t) ∧ F.PA t

theorem Good3_of_keeps2 {t t' : StI F.V} (k : Keeps2 t t') (h : F.Good3 t) : F.Good3 t' := by
  obtain ⟨h1, h2, h3, h4, h5⟩ := h
  refine ⟨F.PLiveLast_of_keeps1 (keeps2_keeps1 k) h1, ?_, ?_, ?_, F.PA_of_keeps2 k h5⟩
  · intro g hg
    obtain ⟨hl, he⟩ := h2 g hg
    exact ⟨F.PLive_of_keeps1 (keeps2_keeps1 k) hl, fun hp hhp => F.PEdge_of_keeps1 (keeps2_keeps1 k) (he hp hhp)⟩
  · intro g port hg1 hg hp
    obtain ⟨a, b, c, d⟩ := h3 g port hg1 hg hp
    exact ⟨F.PEq_of_keeps2 k a, F.PEq_of_keeps2 k b, F.PForce_of_keeps2 k c, F.PP0_of_keeps2 k d⟩
  · intro g hg1 hg; exact F.PElig_of_keeps2 k (h4 g hg1 hg)

/-! ### The bounds needed for `chk` -/

theorem live_bound_of_good3 {t : StI F.V} (h : F.Good3 t) (g : Nat) (hg : g < F.s) :
    F.V < t.s.live g ∧ t.s.live g ≤ t.s.var := by
  by_cases hl : g = F.s - 1
  · subst hl; exact h.1.2
  · exact (h.2.1 g (by omega)).1.2

/-! ### Stage 1 establishes PLive and PEdge -/

theorem mem_edgePairs (g : Nat) (hp : Nat × Nat) :
    hp ∈ F.edgePairs g ↔ g + 1 ≤ hp.1 ∧ hp.1 < F.s ∧ hp.2 < 2 := by
  unfold edgePairs
  simp only [List.mem_flatMap, List.mem_range'_1, List.mem_cons, List.not_mem_nil, or_false]
  constructor
  · rintro ⟨h, ⟨h1, h2⟩, h3⟩
    rcases h3 with rfl | rfl <;> simp <;> omega
  · rintro ⟨h1, h2, h3⟩
    obtain ⟨h, p⟩ := hp
    simp only at h1 h2 h3
    refine ⟨h, ⟨h1, by omega⟩, ?_⟩
    rcases (by omega : p = 0 ∨ p = 1) with rfl | rfl <;> simp

theorem nodup_pairs (l : List Nat) (hl : l.Nodup) : (l.flatMap fun h => [(h, 0), (h, 1)]).Nodup := by
  induction l with
  | nil => simp
  | cons h l ih =>
    simp only [List.flatMap_cons]
    rw [List.nodup_append]
    refine ⟨by simp, ih (List.nodup_cons.mp hl).2, ?_⟩
    intro a ha b hb
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ha
    simp only [List.mem_flatMap, List.mem_cons, List.not_mem_nil, or_false] at hb
    obtain ⟨h', hh', hb⟩ := hb
    have hne : h' ≠ h := fun e => (List.nodup_cons.mp hl).1 (e ▸ hh')
    rcases ha with rfl | rfl <;> rcases hb with rfl | rfl <;> simp [hne.symm]

theorem nodup_edgePairs (g : Nat) : (F.edgePairs g).Nodup :=
  nodup_pairs _ (List.nodup_range' (step := 1))

/-- the edge fold of gate g: grows, keeps live, sets exactly the edges of its list, and
    records every edge definition -/
theorem edgeStep_fold (g : Nat) (l : List (Nat × Nat)) (hnd : l.Nodup)
    (hl : ∀ hp ∈ l, hp.1 < F.s ∧ hp.2 < 2 ∧ g < hp.1) :
    ∀ (t : StI F.V) (terms0 : List Int), (∀ hp ∈ l, F.V < t.s.live hp.1 ∧ t.s.live hp.1 ≤ t.s.var) →
      let r := l.foldl (F.edgeStep g) (t, terms0)
      GrowsTo t r.1 ∧ r.1.s.live = t.s.live ∧
      (∀ g' h' p', ¬ (g' = g ∧ (h', p') ∈ l) → r.1.s.edges g' h' p' = t.s.edges g' h' p') ∧
      r.2 = terms0 ++ l.map (fun hp => (r.1.s.edges g hp.1 hp.2 : Int)) ∧
      (∀ hp ∈ l, F.PEdge g hp.1 hp.2 r.1) := by
  induction l with
  | nil =>
    intro t terms0 _
    exact ⟨growsTo_refl t, rfl, fun _ _ _ _ => rfl, by simp, by simp⟩
  | cons hp l ih =>
    intro t terms0 hlive
    obtain ⟨h, p⟩ := hp
    have hnd' := (List.nodup_cons.mp hnd).2
    have hnot : (h, p) ∉ l := (List.nodup_cons.mp hnd).1
    have hl' : ∀ hp ∈ l, hp.1 < F.s ∧ hp.2 < 2 ∧ g < hp.1 := fun hp hhp => hl hp (by simp [hhp])
    obtain ⟨hhs, hp2, hgh⟩ := hl (h, p) (by simp)
    simp only at hhs hp2 hgh
    obtain ⟨hlV, hlvar⟩ := hlive (h, p) (by simp)
    simp only at hlV hlvar
    -- the step
    simp only [List.foldl_cons]
    have t1live : (F.edgeStep g (t, terms0) (h, p)).1.s.live = t.s.live := rfl
    have t1edges : ∀ g' h' p', (F.edgeStep g (t, terms0) (h, p)).1.s.edges g' h' p' =
        if g' = g ∧ h' = h ∧ p' = p then t.s.var + 1 else t.s.edges g' h' p' := fun _ _ _ => rfl
    have t1var : (F.edgeStep g (t, terms0) (h, p)).1.s.var = t.s.var + 1 := rfl
    have t1cmds0 : (F.edgeStep g (t, terms0) (h, p)).1.s.cmds =
        t.s.cmds ++ [Cmd.andDef (t.s.var + 1) (t.s.chk [(t.s.live h : Int), (F.sel h p (F.k + g) : Int)])] := rfl
    have hstep : F.edgeStep g (t, terms0) (h, p) =
        ((F.edgeStep g (t, terms0) (h, p)).1, terms0 ++ [((t.s.var + 1 : Nat) : Int)]) := rfl
    rw [hstep]
    generalize ht1 : (F.edgeStep g (t, terms0) (h, p)).1 = t1 at t1live t1edges t1var t1cmds0 ⊢
    generalize he : t.s.var + 1 = e at t1edges t1var t1cmds0 ⊢
    have hlive1 : ∀ hp ∈ l, F.V < t1.s.live hp.1 ∧ t1.s.live hp.1 ≤ t1.s.var := by
      intro hp hhp
      have := hlive hp (by simp [hhp])
      rw [t1live, t1var]
      omega
    obtain ⟨i1, i2, i3, i4, i5⟩ := ih hnd' hl' t1 (terms0 ++ [(e : Int)]) hlive1
    have hsel := F.sel_le_S h p (F.k + g) hhs (by omega) (by omega)
    have hSV := F.S_le_V
    have hselpos := F.sel_pos h p (F.k + g)
    have hVt := t.var_ge
    have t1cmds : t1.s.cmds = t.s.cmds ++ [Cmd.andDef e [(t.s.live h : Int), (F.sel h p (F.k + g) : Int)]] := by
      rw [t1cmds0, StI.chk_eq]
      intro l hl
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
      rcases hl with rfl | rfl <;> simp <;> omega
    have hg1 : GrowsTo t t1 := ⟨_, t1cmds⟩
    refine ⟨growsTo_trans hg1 i1, by rw [i2, t1live], ?_, ?_, ?_⟩
    · intro g' h' p' hne
      rw [i3 g' h' p' (fun ⟨e1, e2⟩ => hne ⟨e1, by simp [e2]⟩), t1edges]
      have : ¬ (g' = g ∧ h' = h ∧ p' = p) := fun ⟨e1, e2, e3⟩ => hne ⟨e1, by simp [e2, e3]⟩
      simp [this]
    · rw [i4]
      have hedge : (l.foldl (F.edgeStep g) (t1, terms0 ++ [(e : Int)])).1.s.edges g h p = e := by
        rw [i3 g h p (fun ⟨_, e2⟩ => hnot e2), t1edges]; simp
      simp only [List.map_cons, hedge, List.append_assoc, List.singleton_append]
    · intro hp hhp
      rcases List.mem_cons.mp hhp with rfl | hhp
      · -- established at this step and kept by the rest of the fold
        have hP1 : F.PEdge g h p t1 := by
          refine ⟨?_, ?_, ?_⟩
          · rw [t1edges, t1live, t1cmds]; simp
          · rw [t1edges]; simp; omega
          · rw [t1edges, t1var]; simp
        apply F.PEdge_of_grows i1 (by rw [i2]) (i3 g h p (fun ⟨_, e2⟩ => hnot e2)) hP1
      · exact i5 hp hhp

/-- gate g of stage 1 establishes PLive g and its PEdges, and keeps the other names -/
theorem gateStep_establishes (g : Nat) (hg : g < F.s - 1) (t : StI F.V)
    (hlive : ∀ h, g < h → h < F.s → F.V < t.s.live h ∧ t.s.live h ≤ t.s.var) :
    F.PLive g (F.gateStep t g) ∧ (∀ hp ∈ F.edgePairs g, F.PEdge g hp.1 hp.2 (F.gateStep t g)) ∧
    GrowsTo t (F.gateStep t g) ∧ (∀ h, h ≠ g → (F.gateStep t g).s.live h = t.s.live h) ∧
    (∀ g' h' p', g' ≠ g → (F.gateStep t g).s.edges g' h' p' = t.s.edges g' h' p') := by
  have hl : ∀ hp ∈ F.edgePairs g, hp.1 < F.s ∧ hp.2 < 2 ∧ g < hp.1 := by
    intro hp hhp; have := (F.mem_edgePairs g hp).mp hhp; omega
  have hlive' : ∀ hp ∈ F.edgePairs g, F.V < t.s.live hp.1 ∧ t.s.live hp.1 ≤ t.s.var := by
    intro hp hhp; have := (F.mem_edgePairs g hp).mp hhp; exact hlive hp.1 (by omega) (by omega)
  obtain ⟨i1, i2, i3, i4, i5⟩ := F.edgeStep_fold g (F.edgePairs g) (F.nodup_edgePairs g) hl t [] hlive'
  unfold gateStep
  generalize hr : (F.edgePairs g).foldl (F.edgeStep g) (t, []) = r at i1 i2 i3 i4 i5
  obtain ⟨t', terms⟩ := r
  simp only at i1 i2 i3 i4 i5
  simp only [List.nil_append] at i4
  subst i4
  dsimp only
  -- the OR of the terms: chk is the identity since every edge id is in 1..var
  have hchk : t'.s.chk ((F.edgePairs g).map fun hp => (t'.s.edges g hp.1 hp.2 : Int))
      = (F.edgePairs g).map fun hp => (t'.s.edges g hp.1 hp.2 : Int) := by
    apply StI.chk_eq
    intro l hl
    simp only [List.mem_map] at hl
    obtain ⟨hp, hhp, rfl⟩ := hl
    have := (i5 hp hhp).2
    simp; omega
  have hVt := t'.var_ge
  generalize hxs : ((F.edgePairs g).map fun hp => (t'.s.edges g hp.1 hp.2 : Int)) = xs at hchk ⊢
  have o1 : (t'.OR xs).1 = t'.s.var + 1 := rfl
  have o2 : (t'.OR xs).2.s.cmds = t'.s.cmds ++ [Cmd.orDef (t'.s.var + 1) (t'.s.chk xs)] := rfl
  have o3 : (t'.OR xs).2.s.var = t'.s.var + 1 := rfl
  have o4 : (t'.OR xs).2.s.edges = t'.s.edges := rfl
  have o5 : (t'.OR xs).2.s.live = t'.s.live := rfl
  generalize hO : t'.OR xs = O at o1 o2 o3 o4 o5 ⊢
  obtain ⟨l, t''⟩ := O
  simp only at o1 o2 o3 o4 o5
  subst o1
  dsimp only
  have sl : ∀ h, (t''.setLive fun g' => if g' = g then t'.s.var + 1 else t''.s.live g').s.live h =
      if h = g then t'.s.var + 1 else t''.s.live h := fun _ => rfl
  have se : (t''.setLive fun g' => if g' = g then t'.s.var + 1 else t''.s.live g').s.edges = t''.s.edges := rfl
  have sc : (t''.setLive fun g' => if g' = g then t'.s.var + 1 else t''.s.live g').s.cmds = t''.s.cmds := rfl
  have sv : (t''.setLive fun g' => if g' = g then t'.s.var + 1 else t''.s.live g').s.var = t''.s.var := rfl
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · refine ⟨?_, ?_, ?_⟩
    · rw [sl, sc, o2, if_pos rfl, hchk]
      have : F.edgeTerms (t''.setLive fun g' => if g' = g then t'.s.var + 1 else t''.s.live g') g = xs := by
        unfold edgeTerms; rw [se, o4, hxs]
      rw [this]; simp
    · rw [sl, if_pos rfl]; omega
    · rw [sl, if_pos rfl, sv, o3]; exact Nat.le_refl _
  · intro hp hhp
    have := (F.mem_edgePairs g hp).mp hhp
    apply F.PEdge_of_grows (t := t') _ _ _ (i5 hp hhp)
    · exact ⟨_, by rw [sc, o2]⟩
    · rw [sl, o5]; have : hp.1 ≠ g := by omega
      simp [this]
    · rw [se, o4]
  · exact growsTo_trans i1 ⟨_, by rw [sc, o2]⟩
  · intro h hne
    rw [sl, o5, i2]; simp [hne]
  · intro g' h' p' hne
    rw [se, o4]
    exact i3 g' h' p' (fun ⟨e1, _⟩ => hne e1)

/-- the stage-1 invariant: live[s-1] defined; all gates ≥ n defined with their edges -/
def Inv1 (n : Nat) (t : StI F.V) : Prop :=
  F.PLiveLast t ∧ ∀ g, n ≤ g → g < F.s - 1 → F.PLive g t ∧ ∀ hp ∈ F.edgePairs g, F.PEdge g hp.1 hp.2 t

theorem inv1_live_bound {n : Nat} {t : StI F.V} (h : F.Inv1 n t) (g : Nat) (hn : n ≤ g) (hg : g < F.s) :
    F.V < t.s.live g ∧ t.s.live g ≤ t.s.var := by
  by_cases hl : g = F.s - 1
  · subst hl; exact h.1.2
  · exact (h.2 g hn (by omega)).1.2

theorem inv1_gateStep (n : Nat) (hn : n < F.s - 1) (t : StI F.V) (h : F.Inv1 (n + 1) t) : F.Inv1 n (F.gateStep t n) := by
  obtain ⟨e1, e2, e3, e4, e5⟩ := F.gateStep_establishes n hn t
    (fun h' hnh hhs => F.inv1_live_bound h h' (by omega) hhs)
  refine ⟨?_, ?_⟩
  · exact F.PLiveLast_of_grows e3 (e4 _ (by omega)) h.1
  · intro g hng hg
    by_cases hgn : g = n
    · subst hgn; exact ⟨e1, e2⟩
    · obtain ⟨p1, p2⟩ := h.2 g (by omega) hg
      refine ⟨F.PLive_of_grows e3 (e4 g hgn) (fun hp _ => e5 g hp.1 hp.2 hgn) p1, ?_⟩
      intro hp hhp
      have := (F.mem_edgePairs g hp).mp hhp
      exact F.PEdge_of_grows e3 (e4 hp.1 (by omega)) (e5 g hp.1 hp.2 hgn) (p2 hp hhp)

theorem inv1_fold (t : StI F.V) : ∀ n, n ≤ F.s - 1 → F.Inv1 n t →
    F.Inv1 0 (((List.range n).reverse).foldl F.gateStep t) := by
  intro n
  induction n generalizing t with
  | zero => intro _ h; simpa using h
  | succ n ih =>
    intro hn h
    rw [List.range_succ, List.reverse_append, List.reverse_singleton, List.singleton_append, List.foldl_cons]
    exact ih _ (by omega) (F.inv1_gateStep n (by omega) t h)

theorem stage0_inv1 (hs : 1 ≤ F.s) : F.Inv1 (F.s - 1) F.stage0 := by
  refine ⟨?_, fun g h1 h2 => absurd h2 (by omega)⟩
  refine ⟨?_, ?_, ?_⟩
  · rw [F.stage0_live_last, F.stage0_cmds]; simp
  · rw [F.stage0_live_last]; omega
  · rw [F.stage0_live_last, F.stage0_var]; exact Nat.le_refl _

theorem stage1_inv1 (hs : 1 ≤ F.s) : F.Inv1 0 (F.stage1 F.stage0) :=
  F.inv1_fold F.stage0 (F.s - 1) (Nat.le_refl _) (F.stage0_inv1 hs)

end Fam
end L3

import FinalSelectorSpecs
namespace L3Emitter.FinalSelectorSeed
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram ReferenceTransport Resolution
open FinalOutputDefinitions FinalSelectorSources FinalSelectorSpecs
attribute [local irreducible] D source H PrimaryAliasBank.cfg
abbrev alternative:=FinalOutputSlots.alternative
theorem alternative_zero (n:Nat) (hn:2≤n) (p:Fin 2) (hp:p.val=0):
    alternative n hn p=(fun i=>source n hn (coord n i)):=by
  funext i
  simp only [alternative,FinalOutputSlots.alternative,hp,↓reduceIte]
def seedRow (n:Nat) (hn:2≤n) (p:Fin 2) (ls:List (Lit n)):=
  branch (GuardedVectorTransport.row (alternative n hn p) ls) (H n hn).val
def seedTape (n:Nat) (hn:2≤n) (p:Fin 2) (ls:List (Lit n)) (E:List Row):List Tok:=
  if p.val=0 then
    if ls=alo n then [.ref (locate E (seedRow n hn p ls))]
    else ChoiceProjection.weakenTokens E (GuardedVectorTransport.literals (alternative n hn p) ls) [(H n hn).val]
  else PrimaryAliasRows.unitTape E (PrimaryAliasBank.cfg n hn).T ((H n hn).val::GuardedVectorTransport.literals (alternative n hn p) ls)

theorem append_branch (xs:List Int) (g:Bit) (hx:Valid xs):
    clause (xs++[g.val])=branch (clause xs) g.val:=by
  rw [ProjectionTrace.branch_clause xs hx g.val g.property]
  exact ProjectionTrace.clause_perm _ _ (EvaluationCaseSeeds.valid_join hx (by simp [Valid,g.property]))
    (by intro l hl;rcases List.mem_cons.mp hl with rfl|hl;exact g.property;exact hx l hl)
    (List.perm_append_comm)

theorem checks (n:Nat) (hn:2≤n) (p:Fin 2) (ls:List (Lit n)) (hs:ls∈specs n)
    (E:List Row) (he:∀R∈D n hn,R∈E):
    polEval (dbOf E) (seedTape n hn p ls E) []=some (seedRow n hn p ls):=by
  by_cases hp:p.val=0
  · by_cases hl:ls=alo n
    · subst ls
      have h:seedRow n hn p (alo n)∈E:=by
        apply he
        rw [seedRow,alternative_zero n hn p hp]
        exact terminal_guarded_alo n hn
      simp only [seedTape,hp,↓reduceIte,polEval,locate_correct E _ h]
    · have hrow:GuardedVectorTransport.row (alternative n hn p) ls∈E:=by
        rcases spec_cases n ls hs with h|⟨i,j,hij,rfl⟩
        · exact False.elim (hl h)
        · apply he
          simpa only [GuardedVectorTransport.row,GuardedVectorTransport.literals,pair,List.map_cons,List.map_nil,
            GuardedVectorTransport.signed,alternative,FinalOutputSlots.alternative,hp,↓reduceIte,Bool.false_eq_true] using terminal_pair n hn i j hij
      have h:=ChoiceProjection.weaken_succeeds E (GuardedVectorTransport.literals (alternative n hn p) ls) [(H n hn).val]
        (valid n _ ls) (by simp [Valid,(H n hn).property]) hrow
      rw [append_branch _ (H n hn) (valid n _ ls)] at h
      simpa only [seedTape,hp,if_pos,if_neg hl,seedRow,GuardedVectorTransport.row] using h
  · have hp1:p=(1:Fin 2):=by apply Fin.ext;have:=p.isLt;change p.val=1;omega
    subst p
    have hu:clause [(PrimaryAliasBank.cfg n hn).T.val]∈E:=by
      apply he
      unfold D FinalOutputRecorded.result
      exact List.mem_append_left _ (FinalLowerImage.true_present n hn)
    have h:=PrimaryAliasRows.unit_check E (PrimaryAliasBank.cfg n hn).T
      ((H n hn).val::GuardedVectorTransport.literals (alternative n hn (1:Fin 2)) ls)
      (by intro l hl;rcases List.mem_cons.mp hl with rfl|hl;exact (H n hn).property;exact valid n _ ls l hl)
      (List.mem_cons_of_mem _ (dummy_true n hn ls hs)) hu
    rw [←ProjectionTrace.branch_clause _ (valid n _ ls) _ (H n hn).property] at h
    simpa only [seedTape,show (1:Fin 2).val=1 from rfl,show ¬(1:Nat)=0 by decide,↓reduceIte,seedRow,GuardedVectorTransport.row] using h
#print axioms checks
end L3Emitter.FinalSelectorSeed

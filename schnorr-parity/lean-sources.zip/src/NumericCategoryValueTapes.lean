import NumericGuardTapes
import NumericCategoryValueRows
namespace L3Emitter.NumericCategoryValueTapes
open EREF EREF.GeneralRED RecordedOperandFields NumericProgramFields AliasNetwork NumericNetwork GuardedGatePOL

theorem beta (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (hj:j∈BetaPort.jobs n hn) (b v:Bool) (D:List Row):
 Bounded (NumericValueClosed.bound n) (BetaSelectedValue.program n hn j b v D):=by
 have h:=NumericSelectedCofactors.beta_job n hn j hj
 intro z hz;simp only [BetaSelectedValue.program,List.mem_cons,List.not_mem_nil,or_false] at hz
 rcases hz with rfl|rfl|rfl
 · exact NumericGuardTapes.join _ _ _ _ _ _
 · exact NumericGuardTapes.join _ _ _ _ _ _
 · apply NumericGuardTapes.composition
   · exact NumericTreeRows.sign_bound _ _ v (NumericUnaryValueRows.cofactor n hn _ j.2 h.2.1 h.2.2.2)
   · exact NumericTreeRows.sign_bound _ _ v (NumericUnaryValueRows.unary n hn _ b)
   · exact NumericGuardTapes.value_min n

theorem beta_loop (n:Nat) (hn:2≤n) (D:List Row) (js:List (BetaValueBank.Job n))
 (hj:∀j∈js,j.1∈BetaPort.jobs n hn):
 Bounded (NumericValueClosed.bound n) (BetaValueBank.loop n hn D js):=by
 induction js generalizing D with
 | nil=>simp [BetaValueBank.loop,Bounded]
 | cons j js ih=>
   intro z hz;rcases List.mem_append.mp hz with hz|hz
   · exact beta n hn j.1 (hj j (by simp)) j.2.1 j.2.2 D z hz
   · exact ih _ (by intro j hj';exact hj j (by simp [hj'])) z hz

theorem betas (n:Nat) (hn:2≤n):Bounded (NumericValueClosed.bound n) (BetaValueBank.program n hn):=
 beta_loop n hn _ _ (fun j hj=>(BetaValueBank.job_mem n hn j).mp hj)

theorem rank (n:Nat) (hn:2≤n) (g t:Nat) (b:Bool) (D:List Row):
 Tape (NumericValueClosed.bound n) (RankUnaryValue.tape n hn g t b D):=by
 cases b
 · exact NumericGuardTapes.join _ _ _ _ _ _
 · exact NumericGuardTapes.propagation _ _ _ _ _ (NumericUnaryValueRows.unary n hn g true) (NumericGuardTapes.value_min n)

theorem ranks (n:Nat) (hn:2≤n):Bounded (NumericValueClosed.bound n) (RankValueBank.program n hn):=by
 intro z hz;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hz
 exact rank n hn j.1 j.2.1 j.2.2 _

theorem evaluation (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4)
 (r:RawValueBank.Record) (hr:r∈(RawValueBank.result n hn).2) (hx:r.2.1<FamilyNamespace.truthRows n)
 (b v:Bool) (D:List Row):Tape (NumericValueClosed.bound n) (RankEvaluation.tape n hn g r hr b v D):=by
 have hu:=NumericTreeRows.sign_bound _ _ v (NumericUnaryValueRows.unary n hn g b)
 have hraw:=NumericTreeRows.sign_bound _ _ b (NumericUnaryValueRows.raw n hn r hr)
 have hcf:=NumericTreeRows.sign_bound _ _ v (NumericUnaryValueRows.cofactor n hn g r.2.1 hg hx)
 unfold RankEvaluation.tape;split
 · apply NumericCaseProjection.weaken
   intro l hl;obtain rfl:=List.mem_singleton.mp hl;simpa using hu
 · apply NumericCaseProjection.weaken
   intro l hl;simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
   rcases hl with rfl|rfl
   · simpa using hraw
   · exact hcf

theorem evaluations (n:Nat) (hn:2≤n):Bounded (NumericValueClosed.bound n) (RankEvaluationBank.program n hn):=by
 intro z hz;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hz
 have h:=(RankEvaluationBank.job_mem n hn j).mp hj
 have hr:=RankEvaluationBank.valid_record n hn j.2.1
 exact evaluation n hn j.1 h.2 j.2.1.val j.2.1.property hr.2 j.2.2.1 j.2.2.2 _

theorem shared (n:Nat) (hn:2≤n):Bounded (NumericValueClosed.bound n) (SharedValueBank.program n hn):=by
 intro z hz;rcases List.mem_append.mp hz with hz|hz
 · rcases List.mem_append.mp hz with hz|hz
   · exact NumericProgramFields.rebase (NumericValueClosed.bound n) (UnaryValueBank.result n hn) (GammaComparisonBank.result n hn) (BetaValueBank.program n hn) (betas n hn) z hz
   · exact NumericProgramFields.rebase (NumericValueClosed.bound n) (BetaValueBank.result n hn) (SharedValueBank.betaResult n hn) (RankValueBank.program n hn) (ranks n hn) z hz
 · exact NumericProgramFields.rebase (NumericValueClosed.bound n) (RankValueBank.result n hn) (SharedValueBank.rankResult n hn) (RankEvaluationBank.program n hn) (evaluations n hn) z hz
#print axioms shared
end L3Emitter.NumericCategoryValueTapes

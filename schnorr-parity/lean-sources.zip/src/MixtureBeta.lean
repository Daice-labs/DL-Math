import MixtureGamma

namespace L3Emitter.MixtureBeta
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL SourceMixture

/-- Exchange the two AND arms only; retain the actual OR and output references. -/
def swapped (s:Refs) : Refs := ⟨s.gamma,s.m,s.beta,s.u,s.rank,s.v,s.y,s.t,s.q⟩
theorem ready (s:Refs) (D:List Row) (h:s.Ready D) : (swapped s).Ready D := by
  refine ⟨h.2.1,h.1,⟨?_,h.2.2.1.right,h.2.2.1.left⟩,h.2.2.2⟩
  have hh:=h.2.2.1.up
  change clause [s.y.val,s.v.val,-s.t.val]∈D at hh
  change clause [s.v.val,s.y.val,-s.t.val]∈D
  rwa [ProjectionTrace.clause_perm _ [s.v.val,s.y.val,-s.t.val]
    (by simp [Valid,s.y.property,s.v.property,s.t.property])
    (by simp [Valid,s.y.property,s.v.property,s.t.property]) (List.Perm.swap _ _ _)] at hh

def program (s:Refs) (D:List Row) := MixtureGamma.program (swapped s) D
def rows (s:Refs) := MixtureGamma.rows (swapped s)
theorem checks (s:Refs) (D:List Row) (h:s.Ready D)
    (hg:clause [-s.beta.val,-s.gamma.val]∈D) (hr:clause [-s.beta.val,-s.rank.val]∈D) :
    check D (program s D)=some (D++rows s) :=
  MixtureGamma.checks (swapped s) D (ready s D h) hg hr
theorem relations (s:Refs) : clause [-s.beta.val,-s.u.val,s.q.val]∈rows s ∧
    clause [-s.beta.val,-s.q.val,s.u.val]∈rows s := MixtureGamma.relations (swapped s)

#print axioms checks
#print axioms relations
end L3Emitter.MixtureBeta

import L3FirstGateBinding
import L3ObligationFold

namespace L3
open EREF EREF.GeneralRED
namespace StI
variable {m : Nat}

theorem foldl_proj {α β : Type} (f : StI m → β) (step : StI m → α → StI m)
    (xs : List α) (h : ∀t x,f (step t x)=f t) (t : StI m) :
    f (xs.foldl step t)=f t := by
  induction xs generalizing t with
  | nil => rfl
  | cons x xs ih => exact (ih (step t x)).trans (h t x)

theorem split_root_mem (t : StI m) (c vs : List Int)
    (hc : Bounded t.s.var c) (hv : Bounded t.s.var vs) :
    Cmd.rup c∈(t.split c vs).s.cmds := by
  rw [(StI.split_cmds vs t c hc hv).1]
  exact List.mem_append_right _ (rup_mem_splitCmds c vs)
end StI

namespace Fam
variable (F : Fam)
open StI

def gateRoot (t : StI F.V) (bit cb g : Nat) : List Int :=
  if g=0 then [-(cb : Int),(t.s.veq g bit : Int)]
  else [(t.s.A : Int),-(cb : Int),-(t.s.live g : Int),(t.s.veq g bit : Int)]

def GateRecord (bit cb g : Nat) (t : StI F.V) : Prop :=
  Cmd.eqDef (t.s.veq g bit) (F.val g (F.bitX bit) : Int)
    (F.val g (F.bitY bit) : Int) ∈ t.s.cmds ∧
  Cmd.rup (F.gateRoot t bit cb g)∈t.s.cmds ∧
  F.V<t.s.veq g bit ∧ t.s.veq g bit≤t.s.var

theorem portEqStep_veq (hm : 1≤F.V) (g bit cb : Nat) (t : StI F.V) (p : Nat) :
    (F.portEqStep hm g bit cb t p).s.veq=t.s.veq := by
  unfold portEqStep
  change ((List.range' 1 (F.k+g-1)).foldl (fun (u : StI F.V) j => u.split _ _) _).s.veq=t.s.veq
  rw [StI.foldl_proj (fun (u : StI F.V) => u.s.veq)]
  · rfl
  · intro u j; exact StI.veq_split _ _ _

theorem GateRecord_keeps {t u : StI F.V} (h : Keeps2 t u)
    (bit cb g : Nat) (he : u.s.veq g bit=t.s.veq g bit)
    (hr : F.GateRecord bit cb g t) : F.GateRecord bit cb g u := by
  refine ⟨?_,?_,?_,?_⟩
  · rw [he]; exact mem_of_grows h.1 hr.1
  · have er : F.gateRoot u bit cb g=F.gateRoot t bit cb g := by
      simp only [gateRoot,he,h.2.1.1,h.2.2.2.2.2.2]
    rw [er]; exact mem_of_grows h.1 hr.2.1
  · rw [he]; exact hr.2.2.1
  · rw [he]; exact Nat.le_trans hr.2.2.2 (var_le_of_grows h.1)

def veqStart (hm : 1≤F.V) (bit : Nat) (t : StI F.V) (g : Nat) : StI F.V :=
  let (v,u):=t.EQ hm (F.val g (F.bitX bit) : Int) (F.val g (F.bitY bit) : Int)
  u.setVeq fun g' b' => if g'=g ∧ b'=bit then v else u.s.veq g' b'

def veqFinish (hm : 1≤F.V) (bit cb g : Nat) (u : StI F.V) : StI F.V :=
  if g=0 then u.split (F.gateRoot u bit cb g) [(F.val g (F.bitX bit) : Int)]
  else ([0,1].foldl (F.portEqStep hm g bit cb) u).split
    (F.gateRoot u bit cb g)
    [(F.port g 0 (F.bitX bit) : Int),(F.port g 0 (F.bitY bit) : Int),
     (F.port g 1 (F.bitX bit) : Int),(F.port g 1 (F.bitY bit) : Int),(F.val g (F.bitX bit) : Int)]

theorem veqStep_factor (hm : 1≤F.V) (bit cb : Nat) (t : StI F.V) (g : Nat) :
    F.veqStep hm bit cb t g=F.veqFinish hm bit cb g (F.veqStart hm bit t g) := by
  unfold veqStep veqFinish veqStart gateRoot
  simp only [StI.setVeq]
  split <;> simp_all

theorem veqStart_keeps (hm : 1≤F.V) (bit : Nat) (t : StI F.V) (g : Nat) :
    Keeps2 t (F.veqStart hm bit t g) :=
  keeps2_trans (keeps2_EQ _ hm _ _) (keeps2_setVeq _ _)

theorem veqStart_value (hm : 1≤F.V) (bit : Nat) (t : StI F.V) (g : Nat) :
    (F.veqStart hm bit t g).s.veq g bit=t.s.var+1 := by
  simp [veqStart,StI.setVeq,StI.EQ,St.EQ]

theorem veqFinish_keeps (hm : 1≤F.V) (bit cb g : Nat) (u : StI F.V) :
    Keeps2 u (F.veqFinish hm bit cb g u) := by
  unfold veqFinish
  split
  · exact keeps2_split _ _ _
  · exact keeps2_trans (keeps2_foldl _ _ (fun t p => F.keeps2_portEqStep hm g bit cb t p) u) (keeps2_split _ _ _)

theorem veqFinish_veq (hm : 1≤F.V) (bit cb g : Nat) (u : StI F.V) :
    (F.veqFinish hm bit cb g u).s.veq=u.s.veq := by
  unfold veqFinish
  split
  · exact StI.veq_split _ _ _
  · rw [StI.veq_split]
    exact StI.foldl_proj (fun (t : StI F.V) => t.s.veq) (F.portEqStep hm g bit cb) [0,1] (F.portEqStep_veq hm g bit cb) u


theorem gateRoot_bound (t : StI F.V) (ht : F.Good3 t) (bit cb g : Nat)
    (hg : g<F.s) (hc : 1≤cb ∧ cb≤t.s.var)
    (hv : 1≤t.s.veq g bit ∧ t.s.veq g bit≤t.s.var) :
    Bounded t.s.var (F.gateRoot t bit cb g) := by
  have ha := ht.2.2.2.2
  have haL := ha.2.1
  have haU := ha.2.2
  have hl := F.live_bound_of_good3 ht g hg
  intro l h
  unfold gateRoot at h
  split at h <;> simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  · rcases h with rfl | rfl <;> simp <;> omega
  · rcases h with rfl | rfl | rfl | rfl <;> simp <;> omega

def gateVs (bit g : Nat) : List Int :=
  if g=0 then [(F.val g (F.bitX bit) : Int)]
  else [(F.port g 0 (F.bitX bit) : Int),(F.port g 0 (F.bitY bit) : Int),
    (F.port g 1 (F.bitX bit) : Int),(F.port g 1 (F.bitY bit) : Int),(F.val g (F.bitX bit) : Int)]

theorem gateVs_bound (hk : 2≤F.k) (t : StI F.V) (bit g : Nat) (hb : bit<2) (hg : g<F.s) :
    Bounded t.s.var (F.gateVs bit g) := by
  have hpx := F.bitX_lt hk bit hb
  have hpy := F.bitY_lt hk bit hb
  have h0x := F.port_le g 0 _ hg (by omega) hpx
  have h0y := F.port_le g 0 _ hg (by omega) hpy
  have h1x := F.port_le g 1 _ hg (by omega) hpx
  have h1y := F.port_le g 1 _ hg (by omega) hpy
  have h0xp := F.port_pos g 0 (F.bitX bit)
  have h0yp := F.port_pos g 0 (F.bitY bit)
  have h1xp := F.port_pos g 1 (F.bitX bit)
  have h1yp := F.port_pos g 1 (F.bitY bit)
  have hx := F.val_le g _ hg hpx
  have hxp := F.val_pos g (F.bitX bit)
  have hpV := F.port_bound_le_V
  have hv := t.var_ge
  intro l hl
  unfold gateVs at hl
  split at hl <;> simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
  · rcases hl with rfl; simp; omega
  · rcases hl with rfl | rfl | rfl | rfl | rfl <;> simp <;> omega

theorem veqStart_info (hk : 2≤F.k) (hm : 1≤F.V) (bit : Nat) (t : StI F.V)
    (g : Nat) (hb : bit<2) (hg : g<F.s) :
    Cmd.eqDef ((F.veqStart hm bit t g).s.veq g bit)
      (F.val g (F.bitX bit) : Int) (F.val g (F.bitY bit) : Int)∈(F.veqStart hm bit t g).s.cmds ∧
    F.V<(F.veqStart hm bit t g).s.veq g bit ∧
    (F.veqStart hm bit t g).s.veq g bit≤(F.veqStart hm bit t g).s.var := by
  have hV := t.var_ge
  have hx := F.val_le g _ hg (F.bitX_lt hk bit hb)
  have hy := F.val_le g _ hg (F.bitY_lt hk bit hb)
  have hxp := F.val_pos g (F.bitX bit)
  have hyp := F.val_pos g (F.bitY bit)
  rw [F.veqStart_value]
  refine ⟨?_,by omega,by change t.s.var+1≤t.s.var+1; omega⟩
  change Cmd.eqDef _ _ _ ∈ t.s.cmds ++ [.eqDef _ (t.s.chk1 _) (t.s.chk1 _)]
  rw [StI.chk1_eq t _ (by simp; omega),StI.chk1_eq t _ (by simp; omega)]
  exact List.mem_append_right _ (by simp)

theorem veqFinish_record (hk : 2≤F.k) (hm : 1≤F.V) (bit cb g : Nat)
    (u : StI F.V) (hu : F.Good3 u) (hb : bit<2) (hg : g<F.s)
    (hc : 1≤cb ∧ cb≤u.s.var)
    (hi : Cmd.eqDef (u.s.veq g bit) (F.val g (F.bitX bit) : Int) (F.val g (F.bitY bit) : Int)∈u.s.cmds ∧
      F.V<u.s.veq g bit ∧ u.s.veq g bit≤u.s.var) :
    F.GateRecord bit cb g (F.veqFinish hm bit cb g u) := by
  have keeps := F.veqFinish_keeps hm bit cb g u
  have veqs := F.veqFinish_veq hm bit cb g u
  have hc' := F.gateRoot_bound u hu bit cb g hg hc ⟨by omega,hi.2.2⟩
  have hvs := F.gateVs_bound hk u bit g hb hg
  refine ⟨?_,?_,?_,?_⟩
  · rw [veqs]; exact mem_of_grows keeps.1 hi.1
  · have er : F.gateRoot (F.veqFinish hm bit cb g u) bit cb g=F.gateRoot u bit cb g := by
      simp only [gateRoot,veqs,keeps.2.1.1,keeps.2.2.2.2.2.2]
    rw [er]
    unfold veqFinish
    split
    · apply StI.split_root_mem _ _ _ hc'
      simpa only [gateVs,‹g=0›,↓reduceIte] using hvs
    · have hgr := (keeps2_foldl _ [0,1] (fun t p => F.keeps2_portEqStep hm g bit cb t p) u).1
      have hle := var_le_of_grows hgr
      apply StI.split_root_mem
      · intro l hl; have := hc' l hl; omega
      · have hb' : Bounded u.s.var [(F.port g 0 (F.bitX bit) : Int),(F.port g 0 (F.bitY bit) : Int),
          (F.port g 1 (F.bitX bit) : Int),(F.port g 1 (F.bitY bit) : Int),(F.val g (F.bitX bit) : Int)] := by
          simpa only [gateVs,‹¬g=0›,↓reduceIte] using hvs
        intro l hl; have := hb' l hl; omega
  · rw [veqs]; exact hi.2.1
  · rw [veqs]; exact Nat.le_trans hi.2.2 (var_le_of_grows keeps.1)

theorem veqStep_record (hk : 2≤F.k) (hm : 1≤F.V) (bit cb : Nat)
    (t : StI F.V) (ht : F.Good3 t) (g : Nat) (hb : bit<2) (hg : g<F.s)
    (hc : 1≤cb ∧ cb≤t.s.var) :
    F.GateRecord bit cb g (F.veqStep hm bit cb t g) := by
  rw [F.veqStep_factor]
  have hkeeps := F.veqStart_keeps hm bit t g
  apply F.veqFinish_record hk hm bit cb g _ (F.Good3_of_keeps2 hkeeps ht) hb hg
  · have hle := var_le_of_grows hkeeps.1; exact ⟨hc.1,Nat.le_trans hc.2 hle⟩
  · exact F.veqStart_info hk hm bit t g hb hg


theorem veqStep_other (hm : 1≤F.V) (bit cb g h : Nat) (t : StI F.V) (hne : h≠g) :
    (F.veqStep hm bit cb t g).s.veq h bit=t.s.veq h bit := by
  rw [F.veqStep_factor,F.veqFinish_veq]
  simp [veqStart,StI.setVeq,StI.EQ,St.EQ,hne]

/-- The actual gate-order fold records every predecessor's EQ and root before
    later gates use it. This is a syntax/database invariant, not yet the
    theorem that all recorded roots have been checked. -/
theorem gateOrder_history (hk : 2≤F.k) (hm : 1≤F.V) (bit cb : Nat)
    (t : StI F.V) (ht : F.Good3 t) (hb : bit<2) (hc : 1≤cb ∧ cb≤t.s.var)
    (n : Nat) (hn : n≤F.s) :
    ∀g<n,F.GateRecord bit cb g ((List.range n).foldl (F.veqStep hm bit cb) t) := by
  induction n with
  | zero => intro g hg; omega
  | succ n ih =>
    have hn' : n≤F.s := by omega
    have ih' := ih hn'
    have hkeeps := keeps2_foldl _ (List.range n) (F.keeps2_veqStep hm bit cb) t
    have hu := F.Good3_of_keeps2 hkeeps ht
    have hcu : 1≤cb ∧ cb≤((List.range n).foldl (F.veqStep hm bit cb) t).s.var :=
      ⟨hc.1,Nat.le_trans hc.2 (var_le_of_grows hkeeps.1)⟩
    intro g hg
    rw [List.range_succ,List.foldl_append,List.foldl_cons,List.foldl_nil]
    by_cases he : g=n
    · subst g; exact F.veqStep_record hk hm bit cb _ hu n hb (by omega) hcu
    · exact F.GateRecord_keeps (F.keeps2_veqStep hm bit cb _ n) bit cb g
        (F.veqStep_other hm bit cb n g _ he) (ih' g (by omega))

#print axioms gateOrder_history
#print axioms veqStep_record
#print axioms veqStep_factor
#print axioms GateRecord_keeps
end Fam
end L3

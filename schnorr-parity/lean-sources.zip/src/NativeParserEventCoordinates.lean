import PinnedFileReader
import PinnedInternedFamily
import PinnedLiteralInterning
namespace L3Emitter.NativeParserEventCoordinates
open EREF EREF.GeneralRED CanonicalScopeKernel CanonicalLineParser PinnedCoordinateChange

/-- Encounter order in the emitted field grammar. Witness domains are read
before their images. Scalars and physical references introduce no variables. -/
def rowNames (R : EREF.Row) := R.terms.map (fun t=>t.2.natAbs)
def tokenNames : Tok→List Nat
 | .lit l=>[l.natAbs]
 | _=>[]
def imageNames : L3Emitter.Image→List Nat
 | .bit _=>[]
 | .lit l=>[l.varId]
def witnessNames (w : FiniteWitness.Data) := w.flatMap (fun e=>e.1::imageNames e.2)
def eventNames : Event→List Nat
 | .pol ts=>ts.flatMap tokenNames
 | .pbc R=>rowNames R
 | .red R w=>rowNames R++witnessNames w
 | _=>[]
def event (ρ : Nat→Nat) : Event→Event
 | .pol ts=>.pol (ts.map (token ρ))
 | .pbc R=>.pbc (PinnedCoordinateChange.row ρ R)
 | .red R w=>.red (PinnedCoordinateChange.row ρ R) (PinnedCoordinateChange.witness ρ w)
 | .goal k=>.goal k
 | .close i=>.close i
 | .endRed=>.endRed

theorem row_congr (ρ σ:Nat→Nat) (R:EREF.Row)
 (h:∀v∈rowNames R,ρ v=σ v):PinnedCoordinateChange.row ρ R=PinnedCoordinateChange.row σ R:=by
 unfold PinnedCoordinateChange.row
 congr 1
 apply List.map_congr_left
 intro t ht
 have he:=h t.2.natAbs (List.mem_map.mpr ⟨t,ht,rfl⟩)
 simp only [term,lit,he]

theorem token_congr (ρ σ:Nat→Nat) (t:Tok)
 (h:∀v∈tokenNames t,ρ v=σ v):token ρ t=token σ t:=by
 cases t with
 | lit l=>have he:=h l.natAbs (by simp [tokenNames]);simp [token,lit,he]
 | ref _ | mul _ | div _ | add | sat=>rfl

theorem witness_congr (ρ σ:Nat→Nat) (w:FiniteWitness.Data)
 (h:∀v∈witnessNames w,ρ v=σ v):PinnedCoordinateChange.witness ρ w=PinnedCoordinateChange.witness σ w:=by
 unfold PinnedCoordinateChange.witness
 apply List.map_congr_left
 intro e he
 have hd:=h e.1 (List.mem_flatMap.mpr ⟨e,he,by simp⟩)
 have hi:PinnedCoordinateChange.image ρ e.2=PinnedCoordinateChange.image σ e.2:=by
   cases hx:e.2 with
   | bit b=>rfl
   | lit l=>
     have hh:=h l.varId (List.mem_flatMap.mpr ⟨e,he,by simp [hx,imageNames]⟩)
     simp [PinnedCoordinateChange.image,hh]
 simp only [hd,hi]

theorem event_congr (ρ σ:Nat→Nat) (e:Event)
 (h:∀v∈eventNames e,ρ v=σ v):event ρ e=event σ e:=by
 cases e with
 | pol ts=>
   simp only [event]
   congr 1
   apply List.map_congr_left
   intro t ht
   exact token_congr ρ σ t (fun v hv=>h v (List.mem_flatMap.mpr ⟨t,ht,hv⟩))
 | pbc R=>exact congrArg Event.pbc (row_congr ρ σ R h)
 | red R w=>
   have hr:=row_congr ρ σ R (fun v hv=>h v (List.mem_append_left _ hv))
   have hw:=witness_congr ρ σ w (fun v hv=>h v (List.mem_append_right _ hv))
   simp only [event,hr,hw]
 | goal _ | close _ | endRed=>rfl

theorem sequence_append (names xs ys:List Nat):
 PinnedNameSequence.run names (xs++ys)=PinnedNameSequence.run (PinnedNameSequence.run names xs) ys:=by
 induction xs generalizing names with
 | nil=>rfl
 | cons x xs ih=>exact ih (PinnedNameInterning.intern names x).1

theorem coordinate_stable (names xs:List Nat) (v:Nat) (h:v∈names):
 coordinate (PinnedNameSequence.run names xs) v=coordinate names v:=by
 rw [encountered _ _ (PinnedNameSequence.retained names xs v h),encountered _ _ h,
  PinnedNameSequence.stable names xs v h]

/-- Source-order interning happens at each event, before the parser yields
that event to the scope machine. Later events cannot change its coordinates. -/
def allocate (names:List Nat) : List Event→List Nat×List Event
 | []=>(names,[])
 | e::es=>
   let ns:=PinnedNameSequence.run names (eventNames e)
   let tail:=allocate ns es
   (tail.1,event (coordinate ns) e::tail.2)

theorem final_names (names:List Nat) (es:List Event):
 (allocate names es).1=PinnedNameSequence.run names (es.flatMap eventNames):=by
 induction es generalizing names with
 | nil=>rfl
 | cons e es ih=>simp only [allocate,List.flatMap_cons,sequence_append,ih]

theorem online_global (names:List Nat) (es:List Event):
 (allocate names es).2=es.map (event (coordinate (allocate names es).1)):=by
 induction es generalizing names with
 | nil=>rfl
 | cons e es ih=>
   simp only [allocate,List.map_cons]
   rw [ih]
   congr 1
   apply event_congr
   intro v hv
   rw [final_names]
   exact (coordinate_stable _ _ _ (PinnedNameSequence.inserted names (eventNames e) v hv)).symm

theorem local_events (ρ:Nat→Nat) (p:LocalProof):
 CanonicalFileGrammar.localEvents (localProof ρ p)=
 (CanonicalFileGrammar.localEvents p).map (event ρ):=by
 simp only [CanonicalFileGrammar.localEvents,localProof,List.map_append,List.map_cons,List.map_nil,List.map_map]
 rfl

theorem goal_events (ρ:Nat→Nat) (g:Goal):
 CanonicalFileGrammar.goalEvents (goal ρ g)=
 (CanonicalFileGrammar.goalEvents g).map (event ρ):=by
 simp only [CanonicalFileGrammar.goalEvents,goal,List.map_cons,local_events]
 rfl

theorem command_events (ρ:Nat→Nat) (c:CanonicalScopeKernel.Command):
 CanonicalFileGrammar.commandEvents (PinnedCoordinateChange.command ρ c)=
 (CanonicalFileGrammar.commandEvents c).map (event ρ):=by
 cases c with
 | pol ts=>rfl
 | consequence R p=>simp only [PinnedCoordinateChange.command,CanonicalFileGrammar.commandEvents,List.map_cons,local_events];rfl
 | red R w gs=>
   simp only [PinnedCoordinateChange.command,CanonicalFileGrammar.commandEvents,List.flatMap_map,List.map_append,
    List.map_cons,List.map_nil,List.map_flatMap,Function.comp_def,goal_events]
   rfl

theorem commands_events (ρ:Nat→Nat) (cs:List CanonicalScopeKernel.Command):
 (cs.map (PinnedCoordinateChange.command ρ)).flatMap CanonicalFileGrammar.commandEvents=
 (cs.flatMap CanonicalFileGrammar.commandEvents).map (event ρ):=by
 simp only [List.flatMap_map,List.map_flatMap,Function.comp_def,command_events]

/-- Scope parsing of online-interned emitted events produces precisely the
coordinate-changed commands consumed by the physical execution theorem. -/
theorem parsed (names:List Nat) (cs:List CanonicalScopeKernel.Command):
 CanonicalFileGrammar.parse (allocate names (cs.flatMap CanonicalFileGrammar.commandEvents)).2=
 some (cs.map (PinnedCoordinateChange.command
   (coordinate (allocate names (cs.flatMap CanonicalFileGrammar.commandEvents)).1))):=by
 rw [online_global,←commands_events,CanonicalFileGrammar.commands_roundtrip]
#print axioms online_global
#print axioms parsed
end L3Emitter.NativeParserEventCoordinates

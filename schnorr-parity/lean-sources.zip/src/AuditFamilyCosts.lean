import AuditReplayCosts
import RecordedUniformFamily
namespace L3Emitter.AuditFamilyCosts
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation AuditLocalCosts
open ActualLowerComposition

theorem certs_append (p q : Program) : certCount (p++q)=certCount p+certCount q := by
  simp [certCount,allCertificates]
theorem reds_append (p q : Program) : redCount (p++q)=redCount p+redCount q := by
  simp [redCount]

theorem offset_certs (M : Nat) (p : Program) :
    certCount (RecordedOffsetTrace.program M p)=certCount p := by
  induction p with
  | nil=>rfl
  | cons c p ih=>
    simp only [RecordedOffsetTrace.program,List.map_cons,certs_cons]
    change (certificates (RecordedOffsetTrace.step M c)).length+
      certCount (RecordedOffsetTrace.program M p)=_
    rw [ih]
    cases c <;> simp [RecordedOffsetTrace.step,certificates]

theorem offset_reds (M : Nat) (p : Program) :
    redCount (RecordedOffsetTrace.program M p)=redCount p := by
  unfold RecordedOffsetTrace.program redCount
  simp only [List.map_map]
  congr 2
  funext c
  cases c <;> rfl

/-- All local certificates of the actual successor, including the repeated
lower goal certificates for every guarded input and every retained upper row. -/
theorem successor_certs (n : Nat) (hn : 2≤n) (p : Program) (E : List Row)
    (hp : RecordedCertified.Certified (OriginalEncoding.rows n (3*n-4)) E p) :
    certCount (RecordedRecursiveStep.program n hn p)=
      certCount (RecordedActualActivation.fullProgram n hn (RecordedRecursiveStep.reserve n p))+
      certCount p+((upper n hn).length+(inputs n hn).length+1)*redCount p := by
  obtain ⟨g,hg⟩:=hp
  have hr:=RecordedGuard.rescope 0 g (RecordedRecursiveStep.reserve n p+1) _ E p hg
    (by unfold RecordedRecursiveStep.reserve;omega)
  have hs:=(RecordedOffsetTrace.check (ceiling n hn) (RecordedRecursiveStep.reserve n p+1)
    _ E p (OriginalEncoding.rows_canonical n (3*n-4)) hr).2
  rw [RecordedOffsetOriginal.inputs _ n hn] at hs
  have hh:=AuditReplayCosts.replay_certificates (ceiling n hn)
    (ceiling n hn+(RecordedRecursiveStep.reserve n p+1)) _ _ (upper n hn) (inputs n hn)
    amount (-((ceiling n hn+RecordedRecursiveStep.reserve n p+1:Nat):Int)) _ hs
  rw [RecordedRecursiveStep.program,certs_append]
  unfold ActualRecordedTail.emit RecordedRecursiveStep.shifted
  unfold ActualLowerComposition.inputs at hh ⊢
  rw [hh,offset_certs,offset_reds]
  omega

theorem family_cert_recurrence (m : Nat) :
    certCount (RecordedUniformFamily.family (m+1))=
      certCount (RecordedActualActivation.fullProgram (m+2) (by omega)
        (RecordedRecursiveStep.reserve (m+2) (RecordedUniformFamily.family m)))+
      certCount (RecordedUniformFamily.family m)+
      ((upper (m+2) (by omega)).length+(inputs (m+2) (by omega)).length+1)*
        redCount (RecordedUniformFamily.family m) :=
  successor_certs (m+2) (by omega) _ _ (RecordedUniformFamily.certified m)

theorem family_red_recurrence (m : Nat) :
    redCount (RecordedUniformFamily.family (m+1))=
      redCount (RecordedActualActivation.fullProgram (m+2) (by omega)
        (RecordedRecursiveStep.reserve (m+2) (RecordedUniformFamily.family m)))+
      redCount (RecordedUniformFamily.family m) := by
  rw [RecordedUniformFamily.family,RecordedRecursiveStep.program,reds_append]
  unfold ActualRecordedTail.emit RecordedRecursiveStep.shifted
  rw [AuditReplayCosts.replay_reds,offset_reds]

#print axioms offset_certs
#print axioms offset_reds
#print axioms successor_certs
#print axioms family_cert_recurrence
#print axioms family_red_recurrence
end L3Emitter.AuditFamilyCosts

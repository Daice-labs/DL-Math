import AuditFamilyCosts

namespace L3Emitter.CanonicalReplayEnvelope
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation AuditLocalCosts RecordedReplayCost

def BoundedGoals (B : Nat) (ps : List Certificate) := ∀p∈ps,tokens p≤B

theorem pick_bound (B : Nat) (rs : List Row) (ps : List Certificate) (R : Row)
    (h : BoundedGoals B ps) : tokens (RecordedGoalLookup.pick rs ps R)≤B := by
  unfold RecordedGoalLookup.pick
  cases he:ps[rs.idxOf R]? with
  | none=>simp [Option.getD,tokens]
  | some p=>exact h p (List.mem_of_getElem? he)

theorem replay_goals (B : Nat) (D U I : List Row) (a : Row→Nat) (l : Int)
    (C : Row) (w : FiniteWitness.Data) (ps : List Certificate) (h : BoundedGoals B ps) :
    BoundedGoals (B+4) (RecordedActivatedReplay.goals D U I a l C w ps) := by
  have hp:=fun R=>pick_bound B (C::D) ps R h
  intro p hm
  simp only [RecordedActivatedReplay.goals,List.mem_append,List.mem_cons,List.not_mem_nil,
    or_false,List.mem_map] at hm
  rcases hm with (((rfl|⟨R,hR,rfl⟩)|⟨R,hR,rfl⟩)|rfl)|⟨R,hR,rfl⟩
  · rw [relocated_tokens];exact (hp C).trans (by omega)
  · rw [fixed_tokens];omega
  · rw [guarded_tokens];have hh:=hp R;omega
  · rw [fixed_tokens];omega
  · rw [relocated_tokens];exact (hp R).trans (by omega)

def BoundedProgram (B : Nat) (p : Program) := ∀c∈p,BoundedGoals B (certificates c)

theorem replay_step (B : Nat) (D U I : List Row) (a : Row→Nat) (l : Int) (c : Step)
    (h : BoundedGoals B (certificates c)) :
    BoundedGoals (B+4) (certificates (RecordedActivatedReplay.step D U I a l c)) := by
  cases c with
  | pol R ts=>simp [RecordedActivatedReplay.step,certificates,BoundedGoals]
  | consequence R p=>
    intro q hq
    have hq':q=rebase (D++[negate R]) ((RecordedActivatedReplay.frame U I a l++D)++[negate R]) p:=
      List.mem_singleton.mp hq
    subst q
    rw [show tokens (rebase _ _ p)=tokens p from rebase_tokens ..]
    exact (h p (by simp [certificates])).trans (by omega)
  | red R w ps=>exact replay_goals B D U I a l R w ps h

theorem replay_program (B : Nat) (D U I : List Row) (a : Row→Nat) (l : Int) (p : Program)
    (h : BoundedProgram B p) : BoundedProgram (B+4) (RecordedActivatedReplay.program D U I a l p) := by
  induction p generalizing D with
  | nil=>simp [RecordedActivatedReplay.program,BoundedProgram]
  | cons c cs ih=>
    intro q hq
    rcases List.mem_cons.mp hq with rfl|hq
    · exact replay_step B D U I a l c (h c (by simp))
    · exact ih (D++[c.row]) (by intro x hx;exact h x (by simp [hx])) q hq

theorem offset_tokens (M : Nat) (p : Certificate) :
    tokens (RecordedOffsetPOL.certificate M p)=tokens p := by
  simp [tokens,RecordedOffsetPOL.certificate,RecordedOffsetPOL.program,List.map_map,Function.comp_def]

theorem offset_program (M B : Nat) (p : Program) (h : BoundedProgram B p) :
    BoundedProgram B (RecordedOffsetTrace.program M p) := by
  intro c hc
  obtain ⟨d,hd,rfl⟩:=List.mem_map.mp hc
  have hh:=h d hd
  cases d with
  | pol R ts=>simp [RecordedOffsetTrace.step,certificates,BoundedGoals]
  | consequence R q=>
    intro r hr
    have hr':r=RecordedOffsetPOL.certificate M q:=List.mem_singleton.mp hr
    subst r
    rw [offset_tokens]
    exact hh q (by simp [certificates])
  | red R w ps=>
    intro r hr
    obtain ⟨q,hq,rfl⟩:=List.mem_map.mp hr
    rw [offset_tokens]
    exact hh q hq

theorem tail_bound (n B : Nat) (hn : 2≤n) (p : Program) (h : BoundedProgram B p) :
    BoundedProgram (B+4) (ActualRecordedTail.emit n hn (RecordedRecursiveStep.reserve n p)
      (RecordedRecursiveStep.shifted n hn p)) :=
  replay_program B _ _ _ _ _ _ (offset_program _ B p h)

/-- Per-certificate token ceiling. Replay adds at most FOUR POL TOKENS to
any one certificate, independent of frame size and duplicate lookup
multiplicity. The number of certificates is accounted for separately. -/
theorem successor_bound (n A B : Nat) (hn : 2≤n) (p : Program)
    (hp : BoundedProgram B p)
    (ha : BoundedProgram A (RecordedActualActivation.fullProgram n hn (RecordedRecursiveStep.reserve n p))) :
    BoundedProgram (max A (B+4)) (RecordedRecursiveStep.program n hn p) := by
  intro c hc q hq
  rcases List.mem_append.mp hc with hc|hc
  · exact (ha c hc q hq).trans (Nat.le_max_left _ _)
  · exact (tail_bound n B hn p hp c hc q hq).trans (Nat.le_max_right _ _)

theorem total_tokens (B : Nat) (p : Program) (h : BoundedProgram B p) :
    localTokenCount p≤certCount p*B := by
  have hb:∀q∈allCertificates p,tokens q≤B:=by
    intro q hq
    obtain ⟨c,hc,hq⟩:=List.mem_flatMap.mp hq
    exact h c hc q hq
  change ((allCertificates p).flatMap (fun c=>c.program) |>.map (fun c=>c.2.length)).sum≤_
  rw [flat_tokens]
  change ((allCertificates p).map tokens).sum≤(allCertificates p).length*B
  generalize he:allCertificates p=ps at *
  clear he
  induction ps with
  | nil=>simp
  | cons q ps ih=>
    have hq:=hb q (by simp)
    have ht:=ih (by intro r hr;exact hb r (by simp [hr]))
    simp only [List.map_cons,List.sum_cons,List.length_cons]
    nlinarith

#print axioms pick_bound
#print axioms replay_goals
#print axioms replay_program
#print axioms offset_program
#print axioms tail_bound
#print axioms successor_bound
#print axioms total_tokens
end L3Emitter.CanonicalReplayEnvelope

import NativeLocalProgram
import Serialization
namespace L3Emitter.CompactReferenceWidths
open EREF EREF.GeneralRED NativeSparseStore

theorem referenced_rows (db : Nat→Option Row) (ts : List Tok) (st : List Row) (R : Row)
    (h : polEval db ts st=some R) : ∀ i,Tok.ref i∈ts→∃ Q,db i=some Q := by
  induction ts generalizing st with
  | nil=>simp
  | cons t ts ih=>
    cases t with
    | ref j=>
      simp only [polEval] at h
      split at h
      · rename_i Q hQ
        intro i hi
        rcases List.mem_cons.mp hi with hi|hi
        · cases hi;exact ⟨Q,hQ⟩
        · exact ih _ h i hi
      · contradiction
    | lit l=>
      simp only [polEval] at h
      split at h
      · simpa using ih _ h
      · contradiction
    | add=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        cases st with
        | nil=>simp [polEval] at h
        | cons b st=>simpa using ih _ h
    | mul k=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        simp only [polEval] at h
        split at h
        · simpa using ih _ h
        · contradiction
    | div k=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        simp only [polEval] at h
        split at h
        · simpa using ih _ h
        · contradiction
    | sat=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>simpa using ih _ h

def BoundedRefs (N : Nat) (ts : List Tok) : Prop := ∀i,Tok.ref i∈ts→i≤N

theorem relocated_refs (D : List Row) (s : Store) (ids : Nat→Nat)
    (he : Embeds D s ids) (ts : List Tok) (R : Row) (h : polEval (dbOf D) ts []=some R) :
    BoundedRefs (s.next-1) (ts.map (ReferenceTransport.token ids)) := by
  intro j hj
  obtain ⟨t,ht,heq⟩:=List.mem_map.mp hj
  cases t with
  | ref i=>
    cases heq
    obtain ⟨Q,hQ⟩:=referenced_rows _ ts [] R h i ht
    have hi:=(he i Q hQ).2.1
    omega
  | lit l=>simp [ReferenceTransport.token] at heq
  | add=>simp [ReferenceTransport.token] at heq
  | mul k=>simp [ReferenceTransport.token] at heq
  | div k=>simp [ReferenceTransport.token] at heq
  | sat=>simp [ReferenceTransport.token] at heq

/-- All references of every local tape are bounded by allocated physical IDs,
including the holes left by earlier scopes. The unit is an integer row ID. -/
theorem local_program_refs (D E : List Row) (s : Store) (ids : Nat→Nat)
    (hs : 0<s.next) (he : Embeds D s ids) (p : AliasProgram.Program)
    (hp : AliasProgram.check D p=some E) :
    ∀ts∈(NativeLocalProgram.compile D.length s ids p).tapes,
      BoundedRefs (s.next+p.length-1) ts := by
  induction p generalizing D s ids with
  | nil=>simp [NativeLocalProgram.compile]
  | cons c p ih=>
    rcases c with ⟨R,ts⟩
    simp only [AliasProgram.check] at hp
    split at hp
    · rename_i hc
      have ht:=ih (D++[R]) (push s R) (extend ids D.length s.next)
        (by dsimp [push];omega) (push_embeds D s ids he hs R) hp
      intro tape hm
      simp only [NativeLocalProgram.compile,List.mem_cons] at hm
      rcases hm with rfl|hm
      · intro i hi
        have hb:=relocated_refs D s ids he ts R hc i hi
        simp only [List.length_cons];omega
      · have hb:=ht tape (by simpa using hm)
        simpa only [push,List.length_cons,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hb
    · contradiction

def referenceCount (ts : List Tok) : Nat :=
  (ts.map (fun t=>match t with | .ref _=>1 | _=>0)).sum
def referenceDigitBytes (ts : List Tok) : Nat :=
  (ts.map (fun t=>match t with | .ref i=>digits i | _=>0)).sum

theorem reference_digit_bytes_bound (N : Nat) (ts : List Tok) (h : BoundedRefs N ts) :
    referenceDigitBytes ts≤referenceCount ts*digits N := by
  induction ts with
  | nil=>simp [referenceDigitBytes,referenceCount]
  | cons t ts ih=>
    have ht:=ih (by intro i hi;exact h i (List.mem_cons_of_mem _ hi))
    cases t with
    | ref i=>
      have hi:=digits_mono (h i (by simp))
      simp only [referenceDigitBytes,referenceCount,List.map_cons,List.sum_cons] at *
      nlinarith
    | lit l=>simpa [referenceDigitBytes,referenceCount] using ht
    | add=>simpa [referenceDigitBytes,referenceCount] using ht
    | mul k=>simpa [referenceDigitBytes,referenceCount] using ht
    | div k=>simpa [referenceDigitBytes,referenceCount] using ht
    | sat=>simpa [referenceDigitBytes,referenceCount] using ht

/-- This counts decimal digit BYTES, not references, dollars or elapsed time. -/
theorem local_reference_digit_bytes (D E : List Row) (s : Store) (ids : Nat→Nat)
    (hs : 0<s.next) (he : Embeds D s ids) (p : AliasProgram.Program)
    (hp : AliasProgram.check D p=some E) (ts : List Tok)
    (ht : ts∈(NativeLocalProgram.compile D.length s ids p).tapes) :
    referenceDigitBytes ts≤referenceCount ts*digits (s.next+p.length-1) :=
  reference_digit_bytes_bound _ _ (local_program_refs D E s ids hs he p hp ts ht)

#print axioms referenced_rows
#print axioms relocated_refs
#print axioms local_program_refs
#print axioms reference_digit_bytes_bound
#print axioms local_reference_digit_bytes
end L3Emitter.CompactReferenceWidths

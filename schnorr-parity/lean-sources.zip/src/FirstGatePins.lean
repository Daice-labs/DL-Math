import SelectorPinTape
namespace L3Emitter.FirstGatePins
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram

def F (n:Nat):=FableEncoding.fam (n+1) (3*(n+1)-4)
def sel (n:Nat) (hn:2≤n) (p:Nat):Bit:=(PrimaryAliasBank.cfg n hn).sel 0 p p
def other (n p:Nat):List Int:=if p=0 then (F n).other0 else (F n).other1

theorem normalized_keep (n:Nat) (hn:2≤n):∀R∈(F n).db5,R∈SharedValueBank.result n hn:=by
  intro R hr
  have hfront:R∈FrontendCofactor.frontRows n hn:=L3.exec_mono _ _ R hr
  have hf:R∈FrontendSelection.finalRows (n+1) (by omega):=by
    apply PrioritySourceBinding.selected_retains
    exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hfront))
  have hc:=ConstantConstruction.retains_rank _ _ R
    (L3.exec_mono _ _ _ (RestrictionBounds.retains_front _ _ R hf))
  exact SharedValueBank.gamma_retained n hn R (PrimaryInputLinks.primary_keep n hn R
    (PrimaryBank.constant_retained n hn R hc))

theorem all_pins (n:Nat) (hn:2≤n) (p:Nat) (hp:p<2):
    L3.All (fun r:L3.Row=>r.toE∈SharedValueBank.result n hn)
      (L3.pinRows (sel n hn p).val (other n p)):=by
  have h:=(F n).normalized_pins (by change 2≤n+1;omega) (by change 1≤3*(n+1)-4;omega)
  have hm:∀rs:List L3.Row,L3.All (fun r=>r.toE∈(F n).db5) rs→
      L3.All (fun r=>r.toE∈SharedValueBank.result n hn) rs:=by
    intro rs hrs
    exact L3.All.of_mem rs (fun r hr=>normalized_keep n hn _ (L3.All.mem hrs r hr))
  rcases (show p=0∨p=1 by omega) with rfl|rfl
  · exact hm _ h.1
  · exact hm _ h.2

theorem valid (n p:Nat):Valid (other n p):=by
  unfold other
  split
  · exact (F n).others_nz.1
  · exact (F n).others_nz.2

def tape (n:Nat) (hn:2≤n) (p:Nat) (D:List Row):=SelectorPinTape.tape D (sel n hn p).val (other n p)
def row (n:Nat) (hn:2≤n) (p:Nat):=clause [(sel n hn p).val]

theorem checks (n:Nat) (hn:2≤n) (p:Nat) (hp:p<2) (D:List Row)
    (hd:∀R∈SharedValueBank.result n hn,R∈D):
    polEval (dbOf D) (tape n hn p D) []=some (row n hn p):=by
  have h:=all_pins n hn p hp
  apply SelectorPinTape.checks D _ _ (sel n hn p).property (valid n p)
  · have hh:=hd _ h.1
    change clause ([(sel n hn p).val]++other n p)∈D at hh
    rw [ProjectionTrace.clause_perm _ _
      (by simpa [Valid,(sel n hn p).property] using valid n p)
      (by intro l hl;rcases List.mem_append.mp hl with hl|hl
          · exact valid n p l hl
          · simpa using List.mem_singleton.mp hl ▸ (sel n hn p).property)
      (List.perm_append_comm : ([(sel n hn p).val]++other n p).Perm (other n p++[(sel n hn p).val]))] at hh
    exact hh
  · intro x hx
    exact hd _ (L3.All.mem h.2 (L3.clauseRow [-x]) (List.mem_map.mpr ⟨x,hx,rfl⟩))

def program (n:Nat) (hn:2≤n) (D:List Row):Program:=
  [(row n hn 0,tape n hn 0 D),(row n hn 1,tape n hn 1 D)]
theorem program_checks (n:Nat) (hn:2≤n) (D:List Row) (hd:∀R∈SharedValueBank.result n hn,R∈D):
    check D (program n hn D)=some (D++[row n hn 0,row n hn 1]):=by
  apply IndependentProgram.check_base
  intro cmd hc
  simp only [program,List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl|rfl <;> exact checks n hn _ (by decide) D hd

#print axioms normalized_keep
#print axioms checks
#print axioms program_checks
end L3Emitter.FirstGatePins

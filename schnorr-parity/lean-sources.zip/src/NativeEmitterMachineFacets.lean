import NativeEmittedModel
import PinnedNativeProfileInvariant
import PinnedAliasHeadersMachine
import NativeRuntimeVectorSupport
namespace L3Emitter.NativeEmitterMachineFacets
open EREF CanonicalFileGrammar CanonicalLineParser

/-- The stack-size conjunct of MachineRange discharges the actual UInt64
counter conversions, including the temporary slot used to read a scalar. -/
theorem parser_counters (n:Nat) (hn:2≤n) (hm:NativeEmittedModel.MachineRange n):
 ∀ts,Event.pol ts∈(NativeParserBundle.parsed n).commands.flatMap commandEvents→
 ∀x∈NativeParserDepth.states ts 0,(UInt64.ofNat x).toNat=x:=
 NativeParserDepthFamily.counters n hn hm.2.2

/-- No emitted event prefix enables core-only reference filtering, an
objective, an order, or an explicit native scope. -/
theorem profile_prefix (n:Nat) (front back:List Event)
 (he:(NativeParserBundle.parsed n).commands.flatMap commandEvents=front++back):
 ∃c,PinnedNativeProfile.run (PinnedNativeProfile.profile false []) front=some c ∧
 PinnedNativeProfile.Safe c:=
 PinnedNativeProfile.prefix_safe false (NativeParserBundle.parsed n).commands front back he

theorem allocated_counter (n next:Nat) (hm:NativeEmittedModel.MachineRange n)
 (hnext:next≤(NativeCompatibleFamily.compiled n).store.next):
 (Int64.ofNat next).toInt=(next:Int):=
 PinnedAliasHeadersMachine.cast_next next (lt_of_le_of_lt hnext hm.1)

theorem returned_reference (n next:Nat) (hm:NativeEmittedModel.MachineRange n)
 (hp:0<next) (hnext:next≤(NativeCompatibleFamily.compiled n).store.next):
 (Int64.ofNat next-1).toInt=(next:Int)-1:=
 PinnedAliasHeadersMachine.returned_id next hp (lt_of_le_of_lt hnext hm.1)

/-- All variable-bearing emitted fields use real encountered coordinates;
the range condition separates them from both native truth-value sentinels. -/
theorem literal_fields (n:Nat) (hm:NativeEmittedModel.MachineRange n) (e:Event)
 (he:e∈(NativeCompatibleFamily.commands n).flatMap commandEvents)
 (l:Int) (hl:l∈NativeParserLiteralTraversal.literals e):
 0<(PinnedCoordinateChange.lit (PinnedCoordinateChange.coordinate (NativeParserBundle.names n)) l).natAbs ∧
 (PinnedCoordinateChange.lit (PinnedCoordinateChange.coordinate (NativeParserBundle.names n)) l).natAbs<2^63:=
 NativeParserNameRanges.event_literal_range n e he l hl hm.2.1

/-- Acceptance is coupled with the concrete parser machine-counter facts,
rather than using the range hypothesis only as an unused annotation. -/
theorem accepted_with_counters (choose:PinnedFamilyPending.Selection) (n:Nat) (hn:2≤n)
 (hm:NativeEmittedModel.MachineRange n):
 NativeEmittedModel.check choose
   (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n)))
   (NativeCompatibleFamily.bytes n)=true ∧
 (∀ts,Event.pol ts∈(NativeParserBundle.parsed n).commands.flatMap commandEvents→
   ∀x∈NativeParserDepth.states ts 0,(UInt64.ofNat x).toNat=x):=
 ⟨NativeEmittedModel.accepted choose n hn hm,parser_counters n hn hm⟩

#print axioms accepted_with_counters
#print axioms profile_prefix
#print axioms literal_fields
end L3Emitter.NativeEmitterMachineFacets

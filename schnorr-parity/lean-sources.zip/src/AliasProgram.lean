import AliasBytes

namespace L3Emitter.AliasProgram
open EREF EREF.GeneralRED REDWitness ReferenceTransport Resolution
open AliasClauseTransport SelectedAlias ClauseTransport PolTapeBytes

abbrev Command := Row × List Tok
abbrev Program := List Command

/-- Executable POL-only checker for this component, retaining every row. -/
def check (rows : List Row) : Program → Option (List Row)
  | [] => some rows
  | (R,ts)::rest =>
      if polEval (dbOf rows) ts [] = some R then check (rows++[R]) rest else none

def outputs (p : Program) : List Row := p.map Prod.fst
def document (p : Program) : Doc := p.flatMap (fun cmd => tapeDoc cmd.2)

theorem check_append (rows : List Row) (p q : Program) (mid final : List Row)
    (hp : check rows p=some mid) (hq : check mid q=some final) :
    check rows (p++q)=some final := by
  induction p generalizing rows with
  | nil => simp only [check,Option.some.injEq] at hp; subst mid; exact hq
  | cons cmd p ih =>
    rcases cmd with ⟨R,ts⟩
    simp only [check] at hp
    split at hp
    · rename_i he
      simp only [List.cons_append,check,he,↓reduceIte]
      exact ih _ hp
    · contradiction

theorem check_trace (rows : List Row) (p : Program) (final : List Row)
    (h : check rows p=some final) : CheckedTrace rows final := by
  induction p generalizing rows with
  | nil => simp only [check,Option.some.injEq] at h; subst final; exact .refl _
  | cons cmd p ih =>
    rcases cmd with ⟨R,ts⟩
    simp only [check] at h
    split at h
    · rename_i he; exact .cons (.pol rows R ts he) (ih _ h)
    · contradiction

def bitProgram (rows : List Row) (c : Int) (b : Bit) : Program :=
  [(clause [-c,-b.source,b.target],forwardTokens rows c b.source b.term b.target),
   (clause [-c,-b.target,b.source],
    backTokens (rows++[clause [-c,-b.source,b.target]]) c b.source b.term b.target b.others)]

theorem bit_check (rows : List Row) (c : Int) (b : Bit) (h : BitInputs rows c b) :
    check rows (bitProgram rows c b)=some (rows++bitRows c b) := by
  have hf := forward_succeeds rows c b.source b.term b.target
    h.choice h.source h.term h.target h.and_forward h.or_forward
  let next := rows++[clause [-c,-b.source,b.target]]
  have hn := h.mono (rows:=next) (by intro R hR; exact List.mem_append_left _ hR)
  have hb := back_succeeds next c b.source b.term b.target b.others
    hn.choice hn.source hn.term hn.target hn.others hn.or_backward hn.and_backward hn.other_rows
  simp only [bitProgram,check,hf,↓reduceIte]
  change (if polEval (dbOf next) _ []=_ then _ else _)=_
  rw [if_pos hb]
  simp only [bitRows,List.append_assoc,List.singleton_append]

def bitsProgram (rows : List Row) (c : Int) : List Bit → Program
  | [] => []
  | b::bs => bitProgram rows c b ++ bitsProgram (rows++bitRows c b) c bs

theorem bits_check (rows : List Row) (c : Int) (bs : List Bit)
    (hi : ∀b∈bs,BitInputs rows c b) :
    check rows (bitsProgram rows c bs)=some (rows++bitBody c bs) := by
  induction bs generalizing rows with
  | nil => simp [bitsProgram,bitBody,check]
  | cons b bs ih =>
    have hf := bit_check rows c b (hi b (by simp))
    have ht := ih (rows++bitRows c b) (by
      intro a ha
      exact (hi a (by simp [ha])).mono (by intro R hR; exact List.mem_append_left _ hR))
    have hh := check_append rows _ _ _ _ hf ht
    simpa only [bitsProgram,bitBody,List.flatMap_cons,List.append_assoc] using hh

theorem bits_document (rows : List Row) (c : Int) (bs : List Bit) :
    document (bitsProgram rows c bs)=AliasBytes.bitsDoc rows c bs := by
  induction bs generalizing rows with
  | nil => rfl
  | cons b bs ih =>
    simp only [bitsProgram,document,List.flatMap_append,bitProgram,List.flatMap_cons,
      List.flatMap_nil,List.append_nil,AliasBytes.bitsDoc,AliasBytes.bitDoc]
    rw [←ih]
    simp [document,List.append_assoc]

/-- The final POL line of a clause case is evaluated against the same
    database produced by bitsProgram, with all local row IDs resolved there. -/
theorem case_eval (rows : List Row) (c : Int) (bs : List SignedBit)
    (hc : c≠0) (hne : bs≠[]) (hi : ∀b∈bs,BitInputs rows c b.bit) (hs : source bs∈rows) :
    polEval (dbOf (rows++body c bs)) (caseTokens (rows++body c bs) c bs) []=
      some (branch (target bs) (-c)) := by
  let next := rows++body c bs
  have hsrc : sourceClause (links next c bs)=source bs := by
    simp [sourceClause,links,link,Link.source,source,List.map_map,Function.comp_def]
  have htgt : targetClause (links next c bs)=target bs := by
    simp [targetClause,links,link,Link.target,target,List.map_map,Function.comp_def]
  have hl : ∀p∈links next c bs,p.Available (dbOf next) (-c) := by
    intro p hp; obtain ⟨b,hb,rfl⟩:=List.mem_map.mp hp
    have h := hi b hb
    refine ⟨?_,?_,?_⟩
    · have hz:=h.source; dsimp [link,Link.source,SignedBit.source]; split <;> omega
    · have hz:=h.target; dsimp [link,Link.target,SignedBit.target]; split <;> omega
    · apply locate_correct
      exact link_row_member next c b hc h.source h.target (by
        intro R hR
        exact List.mem_append_right _ (List.mem_flatMap.mpr
          ⟨b.bit,List.mem_map.mpr ⟨b,hb,rfl⟩,hR⟩))
  have he := ClauseTransport.succeeds (dbOf next) (locate next (source bs)) (-c) (by omega)
    (links next c bs) (by simpa [links] using hne)
    (by rw [hsrc]; exact locate_correct _ _ (List.mem_append_left _ hs)) hl
  simpa only [htgt] using he

def caseProgram (rows : List Row) (c : Int) (bs : List SignedBit) : Program :=
  bitsProgram rows c (bs.map SignedBit.bit) ++
    [(branch (target bs) (-c),caseTokens (rows++body c bs) c bs)]

theorem case_check (rows : List Row) (c : Int) (bs : List SignedBit)
    (hc : c≠0) (hne : bs≠[]) (hi : ∀b∈bs,BitInputs rows c b.bit) (hs : source bs∈rows) :
    check rows (caseProgram rows c bs)=some (rows++caseRows c bs) := by
  have hbits := bits_check rows c (bs.map SignedBit.bit) (by
    intro b hb; obtain ⟨sb,hsb,rfl⟩:=List.mem_map.mp hb; exact hi sb hsb)
  have he := case_eval rows c bs hc hne hi hs
  have ht : check (rows++body c bs)
      [(branch (target bs) (-c),caseTokens (rows++body c bs) c bs)] =
      some ((rows++body c bs)++[branch (target bs) (-c)]) := by simp only [check,he,↓reduceIte]
  simpa only [caseProgram,caseRows,List.append_assoc] using check_append rows _ _ _ _ hbits ht

theorem case_document (rows : List Row) (c : Int) (bs : List SignedBit) :
    document (caseProgram rows c bs)=AliasBytes.caseDoc rows c bs := by
  simp only [caseProgram,document,List.flatMap_append,List.flatMap_cons,List.flatMap_nil,List.append_nil]
  rw [show (bitsProgram rows c (bs.map SignedBit.bit)).flatMap (fun cmd=>tapeDoc cmd.2)=
    AliasBytes.bitsDoc rows c (bs.map SignedBit.bit) from bits_document rows c _]
  rfl

theorem checked_case_and_bytes (M P : Nat) (rows : List Row) (c : Int) (bs : List SignedBit)
    (hc : c≠0) (hne : bs≠[]) (hi : ∀b∈bs,BitInputs rows c b.bit) (hs : source bs∈rows)
    (hrows : rows.length+2*bs.length+1≤M) (hcm : c.natAbs≤M) (hn : bs.length≤M)
    (hb : ∀b∈bs,AliasBytes.BitBound M P b.bit) (hp : P+1≤M) :
    check rows (caseProgram rows c bs)=some (rows++caseRows c bs) ∧
    (emit (document (caseProgram rows c bs))).length ≤
      bs.length*(14+(8*P+9)*(3+digits M))+7+(2+2*bs.length^2)*(3+digits M) := by
  refine ⟨case_check rows c bs hc hne hi hs,?_⟩
  rw [case_document]
  exact AliasBytes.case_bytes M P rows c bs hrows hcm hn hb hp

#print axioms case_check
#print axioms checked_case_and_bytes

def casesProgram {ι : Type} (rows : List Row) (is : List ι) (c : ι→Int)
    (bs : ι→List SignedBit) : Program :=
  match is with
  | [] => []
  | i::rest => caseProgram rows (c i) (bs i) ++
      casesProgram (rows++caseRows (c i) (bs i)) rest c bs

theorem cases_check {ι : Type} (rows : List Row) (is : List ι) (c : ι→Int)
    (bs : ι→List SignedBit) (hc : ∀i∈is,c i≠0) (hn : ∀i∈is,bs i≠[])
    (hi : ∀i∈is,∀b∈bs i,BitInputs rows (c i) b.bit)
    (hs : ∀i∈is,source (bs i)∈rows) :
    check rows (casesProgram rows is c bs)=some (rows++familyBody is c bs) := by
  induction is generalizing rows with
  | nil => simp [casesProgram,familyBody,check]
  | cons i rest ih =>
    have hh := case_check rows (c i) (bs i) (hc i (by simp)) (hn i (by simp))
      (hi i (by simp)) (hs i (by simp))
    have ht := ih (rows++caseRows (c i) (bs i))
      (by intro j hj; exact hc j (by simp [hj]))
      (by intro j hj; exact hn j (by simp [hj]))
      (by
        intro j hj b hb
        exact (hi j (by simp [hj]) b hb).mono (by intro R hR; exact List.mem_append_left _ hR))
      (by intro j hj; exact List.mem_append_left _ (hs j (by simp [hj])))
    simpa only [casesProgram,familyBody,List.flatMap_cons,List.append_assoc] using
      check_append rows _ _ _ _ hh ht

def familyProgram {ι : Type} (rows : List Row) (is : List ι) (c : ι→Int)
    (bs : ι→List SignedBit) (C : Row) : Program :=
  casesProgram rows is c bs ++
    [(C,ProjectionTrace.joinCaseTokens (rows++familyBody is c bs) is c C)]

/-- All source cases are constructed and checked, followed by the explicit
    shared POL join. This is executable component success, not only soundness. -/
theorem family_check {ι : Type} (rows : List Row) (is : List ι) (c : ι→Int)
    (bs : ι→List SignedBit) (C : Row)
    (hne : is≠[]) (hc : ∀i∈is,c i≠0) (hn : ∀i∈is,bs i≠[])
    (hi : ∀i∈is,∀b∈bs i,BitInputs rows (c i) b.bit)
    (hs : ∀i∈is,source (bs i)∈rows)
    (htarget : ∀i∈is,target (bs i)=C)
    (ha : clause (is.map c)∈rows) (hC : Canonical C) :
    check rows (familyProgram rows is c bs C)=some (rows++familyBody is c bs++[C]) := by
  have hcases := cases_check rows is c bs hc hn hi hs
  let next := rows++familyBody is c bs
  have hj := ProjectionTrace.join_cases next is c C hC hne hc (List.mem_append_left _ ha) (by
    intro i hii
    exact List.mem_append_right _ (List.mem_flatMap.mpr
      ⟨i,hii,by simp [caseRows,htarget i hii]⟩))
  have he : check next [(C,ProjectionTrace.joinCaseTokens next is c C)]=some (next++[C]) := by
    simp only [check,hj,↓reduceIte]
  exact check_append rows _ _ _ _ hcases he

#print axioms family_check
end L3Emitter.AliasProgram

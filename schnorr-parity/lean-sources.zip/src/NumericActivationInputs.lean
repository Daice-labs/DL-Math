import NumericOriginalFields
import NumericActivationImages
namespace L3Emitter.NumericActivationInputs
open EREF EREF.GeneralRED ByteOperandBounds ActualLowerComposition

def originalCost (n:Nat):Nat:=FamilyNamespace.variableCount n (3*n-4)+NumericOriginalFields.magnitude n (3*n-4)
def inputCost (n:Nat):Nat:=NumericClosedNamespace.envelope n+originalCost n

theorem original (n:Nat) (hn:2≤n):∀R∈OriginalEncoding.rows n (3*n-4),RowBound (originalCost n) R:=
  NumericOriginalFields.row n (3*n-4) _ (by omega) (Nat.le_add_right ..) (Nat.le_add_left ..)

theorem inputs (n:Nat) (hn:2≤n):∀R∈ActualLowerComposition.inputs n hn,RowBound (inputCost n) R:=by
  intro R hr
  change R∈LowerActivationImage.inputs n (ceiling n hn) at hr
  rw [←RecordedOffsetOriginal.inputs (ceiling n hn) n hn] at hr
  obtain ⟨r,hr0,rfl⟩:=List.mem_map.mp hr
  apply RecursiveOperandBounds.row_mono _ _ (RecursiveOperandBounds.row_offset (ceiling n hn) (originalCost n) r (original n hn r hr0))
  unfold inputCost
  exact Nat.add_le_add_right (NumericActualCeiling.ceiling n hn) _

theorem amount (n:Nat) (hn:2≤n) (R:Row) (hr:R∈ActualLowerComposition.inputs n hn):
    ActualLowerComposition.amount R≤ inputCost n+1:=by
  have h:=(inputs n hn R hr).2
  unfold ActualLowerComposition.amount
  omega

#print axioms inputs
#print axioms amount
end L3Emitter.NumericActivationInputs

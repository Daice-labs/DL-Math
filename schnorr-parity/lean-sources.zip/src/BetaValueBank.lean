import BetaSelectedValue
namespace L3Emitter.BetaValueBank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL CofactorValueRows
abbrev Job (n:Nat):=BetaPort.Job n×Bool×Bool

def jobs (n:Nat) (hn:2≤n):List (Job n):=(BetaPort.jobs n hn).flatMap fun j=>
  [(j,false,false),(j,false,true),(j,true,false),(j,true,true)]
def jobRows (n:Nat) (hn:2≤n) (j:Job n):=BetaSelectedValue.rows n hn j.1 j.2.1 j.2.2
def jobProgram (n:Nat) (hn:2≤n) (j:Job n) (D:List Row):=BetaSelectedValue.program n hn j.1 j.2.1 j.2.2 D
def body (n:Nat) (hn:2≤n) (js:List (Job n)):=js.flatMap (jobRows n hn)
def loop (n:Nat) (hn:2≤n) (D:List Row):List (Job n)→Program
  | []=>[]
  | j::js=>jobProgram n hn j D++loop n hn (D++jobRows n hn j) js

theorem job_mem (n:Nat) (hn:2≤n) (j:Job n):j∈jobs n hn ↔ j.1∈BetaPort.jobs n hn:=by
  obtain ⟨j,b,v⟩:=j;cases b <;> cases v <;> simp [jobs]

theorem loop_check (n:Nat) (hn:2≤n) (js:List (Job n)) (hj:∀j∈js,j∈jobs n hn)
    (D:List Row) (hd:∀R∈UnaryValueBank.result n hn,R∈D):
    check D (loop n hn D js)=some (D++body n hn js):=by
  induction js generalizing D with
  | nil=>simp [loop,body,check]
  | cons j js ih=>
    have h0:=BetaSelectedValue.checks n hn j.1 ((job_mem n hn j).mp (hj j (by simp))) j.2.1 j.2.2 D hd
    have h1:=ih (fun j h=>hj j (by simp [h])) (D++jobRows n hn j)
      (fun R h=>List.mem_append_left _ (hd R h))
    simpa only [loop,body,List.flatMap_cons,List.append_assoc] using check_append _ _ _ _ _ h0 h1

def result (n:Nat) (hn:2≤n):=UnaryValueBank.result n hn++body n hn (jobs n hn)
def program (n:Nat) (hn:2≤n):=loop n hn (UnaryValueBank.result n hn) (jobs n hn)
theorem checks (n:Nat) (hn:2≤n):check (UnaryValueBank.result n hn) (program n hn)=some (result n hn):=
  loop_check n hn _ (fun _ h=>h) _ (fun _ h=>h)
theorem original_to_beta_values (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (UnaryValueBank.original_to_value_bank n hn) (check_trace _ _ _ (checks n hn))
theorem retains (n:Nat) (hn:2≤n):∀R∈UnaryValueBank.result n hn,R∈result n hn:=fun R h=>List.mem_append_left _ h

theorem beta_values (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (hj:j∈BetaPort.jobs n hn) (b v:Bool):
    GuardedValueComposition.row (BetaAliasValue.choice j)
      (sign v (cofactor n hn (BetaAliasValue.gate j) j.2))
      (sign v (unary n hn (BetaAliasValue.gate j) b))∈result n hn:=by
  apply List.mem_append_right
  apply List.mem_flatMap.mpr
  refine ⟨(j,b,v),(job_mem n hn _).mpr hj,?_⟩
  simp [jobRows,BetaSelectedValue.rows,BetaSelectedValue.finalRow]

theorem reverse_beta_values (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (hj:j∈BetaPort.jobs n hn) (b v:Bool):
    GuardedValueComposition.row (BetaAliasValue.choice j)
      (sign v (unary n hn (BetaAliasValue.gate j) b))
      (sign v (cofactor n hn (BetaAliasValue.gate j) j.2))∈result n hn:=by
  have h:=beta_values n hn j hj b (!v)
  cases v <;> simp only [Bool.not_false,Bool.not_true,GuardedValueComposition.row,sign,
    Bool.false_eq_true,↓reduceIte,neg_neg] at h ⊢
  all_goals
    rw [ProjectionTrace.clause_perm _ _
      (by simp [Valid,BetaAliasValue.choice_valid n hn j hj,(unary n hn (BetaAliasValue.gate j) b).property,(cofactor n hn (BetaAliasValue.gate j) j.2).property])
      (by simp [Valid,BetaAliasValue.choice_valid n hn j hj,(unary n hn (BetaAliasValue.gate j) b).property,(cofactor n hn (BetaAliasValue.gate j) j.2).property])
      (List.Perm.cons _ (List.Perm.swap ..))]
    exact h

theorem loop_count (n:Nat) (hn:2≤n) (js:List (Job n)) (D:List Row):
    (loop n hn D js).length=3*js.length:=by
  induction js generalizing D with
  | nil=>simp [loop]
  | cons j js ih=>simp only [loop,List.length_append,List.length_cons,ih];rw [jobProgram,BetaSelectedValue.count];omega

theorem program_count (n:Nat) (hn:2≤n):(program n hn).length=12*(BetaPort.jobs n hn).length:=by
  rw [program,loop_count]
  have h:∀js:List (BetaPort.Job n),
      (js.flatMap fun j=>[(j,false,false),(j,false,true),(j,true,false),(j,true,true)]).length=4*js.length:=by
    intro js;induction js with
    | nil=>simp
    | cons j js ih=>simp [List.flatMap_cons,ih];omega
  rw [jobs,h];omega
#print axioms original_to_beta_values
#print axioms beta_values
#print axioms reverse_beta_values
#print axioms program_count
end L3Emitter.BetaValueBank

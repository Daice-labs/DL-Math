import NativeRecordedProgram
namespace L3Emitter.NativeRecordedAllocation
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

def goals (ps : List RecordedRefutation.Certificate) : Nat :=
  (ps.map (fun p=>1+p.program.length)).sum
def step : Step→Nat
  | .pol _ _ => 1
  | .consequence _ p => 2+p.program.length
  | .red _ _ ps => 2+goals ps
def program (p : Program) : Nat := (p.map step).sum

theorem goals_next (D : List Row) (C : Row) (w : FiniteWitness.Data)
    (s : Store) (ids : Nat→Nat) (rs : List Row) (ps : List RecordedRefutation.Certificate)
    (hp : checkGoals D C w rs ps=true) :
    (NativeREDGoalSequence.compile D C w s ids rs ps).store.next=s.next+goals ps := by
  induction rs generalizing ps s with
  | nil => cases ps <;> simp_all [checkGoals,NativeREDGoalSequence.compile,goals]
  | cons R rs ih =>
    cases ps with
    | nil => simp [checkGoals] at hp
    | cons p ps =>
      obtain ⟨_,ht⟩ := Bool.and_eq_true_iff.mp hp
      simp only [NativeREDGoalSequence.compile]
      rw [ih _ ps ht]
      change (NativeLocalProgram.compile (D.length+2)
        (push s (negate (substRow R (FiniteWitness.interpret w))))
        (extend ids (D.length+1) s.next) p.program).store.next+goals ps=_
      rw [NativeScopedLocalGoal.compile_next]
      simp only [push,goals,List.map_cons,List.sum_cons]
      omega

theorem step_next (M guard : Nat) (D : List Row) (s : Store) (ids : Nat→Nat)
    (c : Step) (hc : c.accepts M guard D=true) :
    (NativeRecordedStep.compile D s ids c).store.next=s.next+step c := by
  cases c with
  | pol R ts => rfl
  | consequence R p =>
    change (NativeLocalProgram.compile (D.length+1) (push s (negate R))
      (extend ids D.length s.next) p.program).store.next+1=s.next+(2+p.program.length)
    rw [NativeScopedLocalGoal.compile_next]
    simp only [push];omega
  | red R w ps =>
    have hg := (Bool.and_eq_true_iff.mp hc).2
    change (NativeREDGoalSequence.compile D R w (push s (negate R))
      (extend ids D.length s.next) (R::D) ps).store.next+1=s.next+(2+goals ps)
    rw [goals_next D R w _ _ _ _ hg]
    simp only [push];omega

/-- Counts every local assumption, local POL row, and post-scope candidate,
including deleted IDs. This is an allocation identity, not an n-only bound. -/
theorem program_next (M guard : Nat) (D E : List Row) (s : Store) (ids : Nat→Nat)
    (p : Program) (hp : check M guard D p=some E) :
    (NativeRecordedProgram.compile D s ids p).store.next=s.next+program p := by
  induction p generalizing D s ids with
  | nil => simp [NativeRecordedProgram.compile,program]
  | cons c p ih =>
    simp only [check] at hp
    split at hp
    · rename_i hc
      simp only [NativeRecordedProgram.compile]
      rw [ih _ _ _ hp,step_next M guard D s ids c hc]
      simp [program,Nat.add_assoc]
    · contradiction

#print axioms goals_next
#print axioms step_next
#print axioms program_next
end L3Emitter.NativeRecordedAllocation

import GuardedReplay
import Serialization

namespace L3Emitter.FiniteWitness
open EREF EREF.GeneralRED

abbrev Data := List (Nat × L3Emitter.Image)

def literalId (l : Literal) : Int := if l.negative then -(l.varId : Int) else l.varId

def interpretImage : L3Emitter.Image → EREF.GeneralRED.Image
  | .bit b => .constant b
  | .lit l => if h : literalId l = 0 then .constant false else .literal (literalId l) h

def identity (v : Nat) : EREF.GeneralRED.Image :=
  if h : v = 0 then .constant false else .literal (v : Int) (by omega)

/-- First-match finite simultaneous map; unmapped positive IDs are fixed. -/
def interpret : Data → Witness
  | [], v => identity v
  | (key,img)::rest, v => if key = v then interpretImage img else interpret rest v

def validImage : L3Emitter.Image → Bool
  | .bit _ => true
  | .lit l => decide (0 < l.varId)

def valid (w : Data) : Bool :=
  w.all (fun e => decide (0 < e.1) && validImage e.2) &&
    decide (w.map Prod.fst).Nodup

def checkScope (M guard : Nat) (w : Data) : Bool :=
  w.all (fun e => decide (M < e.1 ∧ e.1 ≠ guard))

theorem interpret_else (w : Data) (v : Nat) (hv : 0 < v)
    (h : ∀ e ∈ w, e.1 ≠ v) (α : Val) : applyWitness (interpret w) α v = α v := by
  induction w with
  | nil => simp [interpret, identity, applyWitness, EREF.GeneralRED.Image.eval, show v ≠ 0 by omega, show (0:Int) < v by omega]
  | cons e w ih =>
    have he := h e (by simp)
    simpa only [applyWitness, interpret, if_neg he] using
      ih (fun e he => h e (List.mem_cons_of_mem _ he))

theorem fixes_below (M guard : Nat) (w : Data) (h : checkScope M guard w = true) :
    REDFrame.FixesBelow (interpret w) M := by
  intro v hv hM α
  apply interpret_else w v hv
  intro e he
  have hh := (List.all_eq_true.mp h) e he
  have hh : M < e.1 ∧ e.1 ≠ guard := of_decide_eq_true hh
  omega

theorem fixes_guard (M guard : Nat) (w : Data) (hg : 0 < guard)
    (h : checkScope M guard w = true) (α : Val) :
    applyWitness (interpret w) α guard = α guard := by
  apply interpret_else w guard hg
  intro e he
  have hh := (List.all_eq_true.mp h) e he
  exact (show M < e.1 ∧ e.1 ≠ guard from of_decide_eq_true hh).2

/-- Syntax emitted from the same finite map interpreted above. -/
def document (w : Data) : Doc := L3Emitter.witness w

#print axioms interpret_else
#print axioms fixes_below
#print axioms fixes_guard
end L3Emitter.FiniteWitness

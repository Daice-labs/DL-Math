import UnaryLookupBank
namespace L3Emitter.GuardedJoin
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL ReferenceTransport

def target (G H:List Int) (q:Int):=guarded (G++H) q
def link (H:List Int) (a q:Int):=clause (H++[-a,q])
def tape (D:List Row) (G H:List Int) (a q:Int):List Tok:=
  [.ref (locate D (guarded G a)),.ref (locate D (link H a q)),.add]
theorem combine (G H:List Int) (a q:Int) (hg:Valid G) (hh:Valid H) (ha:a≠0) (hq:q≠0):
    add (guarded G a) (link H a q)=target G H q:=by
  apply canonical_ext _ _ (canonical_add _ _) (canonical_normalize _ _)
  intro α
  change (add (guarded G a) (link H a q)).val α=(target G H q).val α
  rw [val_add (guarded G a) (link H a q) (canonical_normalize _ _) (canonical_normalize _ _)]
  change (clause (G++[a])).val α+(clause (H++[-a,q])).val α=(clause ((G++H)++[q])).val α
  rw [val_clause (G++[a]) (EvaluationCaseSeeds.valid_join hg (by simp [Valid,ha])),
    val_clause (H++[-a,q]) (EvaluationCaseSeeds.valid_join hh (by simp [Valid,ha,hq])),
    val_clause ((G++H)++[q]) (EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join hg hh) (by simp [Valid,hq]))]
  simp only [target,guarded,link,sum_append,sum_cons,sum_nil,litVal_neg α a ha]
  ring

theorem checks (D:List Row) (G H:List Int) (a q:Int) (hg:Valid G) (hh:Valid H) (ha:a≠0) (hq:q≠0)
    (h1:guarded G a∈D) (h2:link H a q∈D):
    polEval (dbOf D) (tape D G H a q) []=some (target G H q):=by
  simp only [tape,polEval,locate_correct _ _ h1,locate_correct _ _ h2]
  rw [combine G H a q hg hh ha hq]
#print axioms checks
end L3Emitter.GuardedJoin

import CoordinateSnapshots

namespace L3Emitter.GateSnapshots
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases
variable {base:List Row} {w:Nat}

theorem run_split (c:Config Bit) (as:Nat→AliasBits w) (g a b:Nat) (z:Net base) :
    run c as g (a+b) z=
      run c (run c as g a z).1 (g+a) b (run c as g a z).2 := by
  induction a generalizing as g z with
  | zero=>simp only [Nat.zero_add,Nat.add_zero];rfl
  | succ a ih=>
    rw [Nat.succ_add]
    change run c (Function.update as (c.k+g) (step c as g z).1) (g+1) (a+b) (step c as g z).2=_
    rw [ih]
    simp only [run]
    congr 1 <;> omega

def beforeGate (n:Nat) (hn:2≤n) (g:Nat) :=
  run (PrimaryAliasBank.cfg n hn) (FirstPortRelations.initialAliases n hn) 0 g
    (PrimaryAliasBank.context n hn).2

def atGate (n:Nat) (hn:2≤n) (g:Nat) :=
  step (PrimaryAliasBank.cfg n hn) (beforeGate n hn g).1 g (beforeGate n hn g).2

def refs (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) :=
  CoordinateSnapshots.refs (PrimaryAliasBank.cfg n hn) (beforeGate n hn g).1 g
    (beforeGate n hn g).2 (SelectedVectorOneHot.position i)

theorem built_split (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4) :
    (AliasAssembly.built n hn).1.2=
      (run (PrimaryAliasBank.cfg n hn)
        (Function.update (beforeGate n hn g).1 (n+1+g) (atGate n hn g).1)
        (g+1) (3*(n+1)-4-(g+1)) (atGate n hn g).2).1 ∧
    (AliasAssembly.built n hn).2=
      (run (PrimaryAliasBank.cfg n hn)
        (Function.update (beforeGate n hn g).1 (n+1+g) (atGate n hn g).1)
        (g+1) (3*(n+1)-4-(g+1)) (atGate n hn g).2).2 := by
  have he:3*(n+1)-4=g+(3*(n+1)-4-(g+1)+1):=by omega
  have h:=run_split (PrimaryAliasBank.cfg n hn) (FirstPortRelations.initialAliases n hn)
    0 g (3*(n+1)-4-(g+1)+1) (PrimaryAliasBank.context n hn).2
  rw [←he] at h
  simp only [Nat.zero_add] at h
  exact ⟨congrArg Prod.fst h,congrArg Prod.snd h⟩

theorem output (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4) :
    (AliasAssembly.built n hn).1.2 (n+1+g)=(atGate n hn g).1 := by
  rw [(built_split n hn g hg).1]
  rw [FirstGateSource.run_earlier _ _ _ _ _ (n+1+g) (by change n+1+g<n+1+(g+1);omega)]
  simp

theorem rows_retained (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4) :
    ∀R∈(atGate n hn g).2.rows,R∈(AliasAssembly.built n hn).2.rows := by
  rw [(built_split n hn g hg).2]
  exact run_extends _ _ _ _ _

theorem built_to_bank (n:Nat) (hn:2≤n) :
    ∀R∈(AliasAssembly.built n hn).2.rows,R∈CategoryBank.result n hn := by
  intro R hr
  rw [←(RecordedAliasRun.built_binding n hn).2] at hr
  have h:R∈PrimaryAliasBank.result n hn:=
    List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hr)))
  exact CategoryBank.retains n hn R (FirstPortOneHot.block_retains n hn 1 _ R
    (FirstPortOneHot.block_retains n hn 0 _ R h))

theorem refs_ready (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1))) : (refs n hn g i).Ready (CategoryBank.result n hn) := by
  exact MixtureGamma.ready_mono (CoordinateSnapshots.refs_ready _ _ _ _ _ (by omega) i.isLt)
    (fun R hr=>built_to_bank n hn R (rows_retained n hn g hs R hr))

theorem refs_output (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1))) :
    (refs n hn g i).q=(AliasAssembly.built n hn).1.2 (n+1+g) (SelectedVectorOneHot.position i) := by
  rw [output n hn g hs]
  exact CoordinateSnapshots.refs_output _ _ _ _ _ (by omega) i.isLt

theorem refs_compatible (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) :
    CategorySourceInputs.compatible n hn g i (refs n hn g i) := by
  exact ⟨rfl,rfl,rfl⟩

#print axioms run_split
#print axioms refs_ready
#print axioms refs_output
#print axioms refs_compatible
end L3Emitter.GateSnapshots

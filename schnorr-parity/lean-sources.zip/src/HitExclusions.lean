import HitSnapshots
import GuardedOrJoin
namespace L3Emitter.HitExclusions
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
abbrev Choice (n:Nat):=RankProjection.Choice (3*(n+1)-4)
def gates (n:Nat) (c:Choice n):List Nat:=((List.range (c.gamma-1)).map (·+1)).filter (·≠c.beta)
def row (n:Nat) (hn:2≤n) (c:Choice n) (g:Nat):=clause [-c.lit,-((PrimaryAliasBank.cfg n hn).beta g).val]
def rows (n:Nat) (hn:2≤n) (c:Choice n):=(gates n c).map (row n hn c)
def program (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row):Program:=
  (gates n c).map fun g=>(row n hn c g,SelectedCategoryRows.excludeTape n hn c g .beta D)

theorem gate_mem (n:Nat) (c:Choice n) (g:Nat):g∈gates n c ↔ 0<g ∧ g<c.gamma ∧ g≠c.beta:=by
  simp only [gates,List.mem_filter,decide_eq_true_eq,List.mem_map,List.mem_range]
  constructor
  · rintro ⟨⟨i,hi,rfl⟩,hne⟩;omega
  · rintro ⟨hp,hg,hne⟩;exact ⟨⟨g-1,by omega,by omega⟩,hne⟩

theorem checks (n:Nat) (hn:2≤n) (c:Choice n) (hc:c∈CategoryPrograms.choices n hn)
    (D:List Row) (hd:∀R∈UnaryValueBank.result n hn,R∈D):
    check D (program n hn c D)=some (D++rows n hn c):=by
  have h:=IndependentProgram.check_base D (program n hn c D) (by
    intro cmd hm;obtain ⟨g,hg,rfl⟩:=List.mem_map.mp hm
    obtain ⟨hp,hg,hne⟩:=(gate_mem n c g).mp hg
    exact SelectedCategoryRows.exclude_check n hn c hc g hp (by have:=c.gamma_lt;omega) .beta
      (by simp [GateCategories.categories]) (by simpa [GateCategories.Active,eq_comm] using hne) D hd)
  simpa [program,rows,outputs,List.map_map] using h

#print axioms checks
end L3Emitter.HitExclusions

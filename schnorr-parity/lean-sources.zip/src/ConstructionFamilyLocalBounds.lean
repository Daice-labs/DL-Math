import ConstructionTransportBounds
import ConstructionTableBounds
import RecordedCompleteLower

namespace L3Emitter.ConstructionFamilyLocalBounds
open EREF EREF.GeneralRED RecordedScopedTrace CanonicalReplayEnvelope
open ConstructionLocalTools ConstructionFreshBounds ConstructionFoldBounds
open ConstructionTransportBounds

theorem global (n : Nat) (hn : 2≤n) : BoundedProgram (cap (n+1)) (RecordedGlobalValues.program n hn) := by
  unfold RecordedGlobalValues.program RecordedGlobalValues.p25 RecordedGlobalValues.p24 RecordedGlobalValues.p23 RecordedGlobalValues.p22 RecordedGlobalValues.p21 RecordedGlobalValues.p20 RecordedGlobalValues.p19 RecordedGlobalValues.p18 RecordedGlobalValues.p17 RecordedGlobalValues.p16 RecordedGlobalValues.p15 RecordedGlobalValues.p14 RecordedGlobalValues.p13 RecordedGlobalValues.p12 RecordedGlobalValues.p11 RecordedGlobalValues.p10 RecordedGlobalValues.p9 RecordedGlobalValues.p8 RecordedGlobalValues.p7 RecordedGlobalValues.p6 RecordedGlobalValues.p5 RecordedGlobalValues.p4 RecordedGlobalValues.p3 RecordedGlobalValues.p2 RecordedGlobalValues.p1 RecordedGlobalValues.p0
  exact (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (ConstructionTransportBounds.transport n hn) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _))

theorem lower (B n : Nat) (hn : 2≤n) : BoundedProgram B (RecordedLowerRows.program n hn) := by
  unfold RecordedLowerRows.program RecordedLowerRows.p10 RecordedLowerRows.p9 RecordedLowerRows.p8 RecordedLowerRows.p7 RecordedLowerRows.p6 RecordedLowerRows.p5 RecordedLowerRows.p4 RecordedLowerRows.p3 RecordedLowerRows.p2 RecordedLowerRows.p1 RecordedLowerRows.p0
  exact (append B _ _ (append B _ _ (append B _ _ (append B _ _ (append B _ _ (append B _ _ (append B _ _ (append B _ _ (append B _ _ (append B _ _ (polProgram B _) (polProgram B _)) (polProgram B _)) (polProgram B _)) (polProgram B _)) (polProgram B _)) (polProgram B _)) (polProgram B _)) (polProgram B _)) (polProgram B _)) (polProgram B _))

theorem completeLower (n : Nat) (hn : 2≤n) : BoundedProgram (cap (n+1)) (RecordedCompleteLower.program n hn) :=
  append _ _ _ (append _ _ _ (append _ _ _ (global n hn)
    (lift3 (n+1) _ (ConstructionTableBounds.transport n hn))) (lower _ n hn))
    (lift3 (n+1) _ (ConstructionTableBounds.finalRows n hn))

theorem activationProgram (n : Nat) (hn : 2≤n) (N : Nat) :
    BoundedProgram 3 (RecordedActualActivation.program n hn N) :=
  append _ _ _ (append _ _ _ (guardBank _ _ _ _)
    (ConstructionFoldBounds.singleton 3 _ (activation _ _ _ _ _))) (cancel 3 _ _ _ _)

theorem prefixBound (n : Nat) (hn : 2≤n) (N : Nat) :
    BoundedProgram (700*(n+2)) (RecordedActualActivation.fullProgram n hn N) :=
  append _ _ _ (completeLower n hn) (lift3 (n+1) _ (activationProgram n hn N))

/-- No base or per-level token hypotheses: this ceiling is proved from every
constructor of the actual family. Unit: POL TOKENS PER LOCAL CERTIFICATE. -/
theorem family (m : Nat) : BoundedProgram (700*(m+3)+4*m) (RecordedUniformFamily.family m) := by
  have h:=CanonicalFamilyEnvelope.local_tokens m (700*(m+3)) 700
    ConstructionFrontendBounds.base (by
      intro i hi
      exact CanonicalFamilyEnvelope.bounded_mono _ _ _ (by omega)
        (prefixBound (i+2) (by omega) _))
  have he:max (700*(m+3)) 700=700*(m+3):=Nat.max_eq_left (by omega)
  rw [he] at h
  exact h

theorem emitter (n : Nat) (hn : 2≤n) :
    BoundedProgram (704*n+700) (RecordedUniformFamily.emitter n) := by
  have h:=family (n-2)
  have he:700*(n-2+3)+4*(n-2)≤704*n+700:=by omega
  exact CanonicalFamilyEnvelope.bounded_mono _ _ _ he h

#print axioms prefixBound
#print axioms family
#print axioms emitter
end L3Emitter.ConstructionFamilyLocalBounds

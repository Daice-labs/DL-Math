import FinalLowerImage
namespace L3Emitter.FinalLowerEarlier
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL FamilyNamespace FamilyRows

def gateIndex : Wire→Nat
  | .sel t _ _ | .port t _ _ | .fn t _ | .val t _=>t

theorem wire_unchanged (n:Nat) (hn:2≤n) (w:Wire)
    (hw:gateIndex w<FinalOutputDefinitions.lastRank n):
    FinalLowerImage.wire n hn w=LowerTransferImage.wire n hn w:=by
  cases w <;> simp only [gateIndex] at hw <;>
    simp only [FinalLowerImage.wire,if_neg (Nat.ne_of_lt hw)]

theorem image_unchanged (n:Nat) (hn:2≤n) (r:Spec)
    (hr:∀l∈r.literals,gateIndex l.1<FinalOutputDefinitions.lastRank n):
    FinalLowerImage.image n hn r=LowerTransferImage.image n hn r:=by
  unfold FinalLowerImage.image LowerTransferImage.image
  congr 1
  apply List.map_congr_left
  intro l hl
  rw [wire_unchanged n hn l.1 (hr l hl)]

theorem original_kept (n:Nat) (hn:2≤n):∀R∈LowerGateBank.result n hn,R∈FinalOutputDefinitions.result n hn:=
  fun R h=>FinalOutputDefinitions.retains n hn R (List.mem_append_left _ h)

theorem selectors (n:Nat) (hn:2≤n) (t p:Nat) (b:Bool)
    (ht:t<FinalOutputDefinitions.lastRank n) (hp:p<2):
    FinalLowerImage.image n hn (InputSwap.oneHot n t p b)∈FinalOutputDefinitions.result n hn:=by
  rw [image_unchanged n hn _ (by
    intro l hl;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hl;exact ht)]
  apply original_kept
  apply LowerGateBank.all_nonoutput_images
  apply Or.inl
  exact (OriginalEncoding.selectors_mem ..).mpr ⟨t,p,b,by unfold FinalOutputDefinitions.lastRank RankConstruction.width at ht;omega,hp,rfl⟩

theorem forbidden (n:Nat) (hn:2≤n) (t c:Nat)
    (ht:t<FinalOutputDefinitions.lastRank n) (hc:c∈[6,9]):
    FinalLowerImage.image n hn (InputSwap.forbidden t c)∈FinalOutputDefinitions.result n hn:=by
  rw [image_unchanged n hn _ (by
    intro l hl;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hl;exact ht)]
  apply original_kept
  apply LowerGateBank.all_nonoutput_images
  apply Or.inr;apply Or.inl
  exact (OriginalEncoding.forbidden_mem ..).mpr ⟨t,c,by unfold FinalOutputDefinitions.lastRank RankConstruction.width at ht;omega,hc,rfl⟩

theorem input_transfer (n:Nat) (hn:2≤n) (t p j x:Nat)
    (ht:t<FinalOutputDefinitions.lastRank n) (hp:p<2) (hj:j<n) (hx:x<truthRows n):
    FinalLowerImage.image n hn (InputSwap.inputTransfer n t p j x)∈FinalOutputDefinitions.result n hn:=by
  rw [image_unchanged n hn _ (by
    intro l hl;simp only [InputSwap.inputTransfer,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl <;> exact ht)]
  apply original_kept
  apply LowerGateBank.all_nonoutput_images
  apply Or.inr;apply Or.inr;apply Or.inl
  exact (OriginalEncoding.transfers_mem ..).mpr (Or.inl ⟨t,p,j,x,by unfold FinalOutputDefinitions.lastRank RankConstruction.width at ht;omega,hp,hj,hx,rfl⟩)

theorem gate_transfer (n:Nat) (hn:2≤n) (t p g x:Nat) (b:Bool)
    (ht:t<FinalOutputDefinitions.lastRank n) (hp:p<2) (hg:g<t) (hx:x<truthRows n):
    FinalLowerImage.image n hn (InputSwap.gateTransfer n t p g x b)∈FinalOutputDefinitions.result n hn:=by
  rw [image_unchanged n hn _ (by
    intro l hl;simp only [InputSwap.gateTransfer,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl
    · exact ht
    · exact Nat.lt_trans hg ht
    · exact ht)]
  apply original_kept
  apply LowerGateBank.all_nonoutput_images
  apply Or.inr;apply Or.inr;apply Or.inl
  exact (OriginalEncoding.transfers_mem ..).mpr (Or.inr ⟨t,p,g,x,b,by unfold FinalOutputDefinitions.lastRank RankConstruction.width at ht;omega,hp,hg,hx,rfl⟩)

theorem evaluation (n:Nat) (hn:2≤n) (t x:Nat) (a b c:Bool)
    (ht:t<FinalOutputDefinitions.lastRank n) (hx:x<truthRows n):
    FinalLowerImage.image n hn (InputSwap.semantics t x a b c)∈FinalOutputDefinitions.result n hn:=by
  rw [image_unchanged n hn _ (by
    intro l hl;simp only [InputSwap.semantics,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl|rfl <;> exact ht)]
  apply original_kept
  apply LowerGateBank.all_semantics_images
  exact (OriginalEncoding.semantics_mem ..).mpr ⟨t,x,a,b,c,by unfold FinalOutputDefinitions.lastRank RankConstruction.width at ht;omega,hx,rfl⟩
#print axioms evaluation
#print axioms gate_transfer
end L3Emitter.FinalLowerEarlier

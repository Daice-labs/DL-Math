import NumericAllocationLoop
import RecordedCofactorBank
namespace L3Emitter.NumericCofactorFields
open EREF EREF.GeneralRED REDWitness FamilyNamespace CofactorSemantics FieldLengthsFromIDs

theorem cell (M n s offset B g p x:Nat) (D:List Row)
 (hV:variableCount (n+1) s≤offset) (hB:B≤offset)
 (hg:g<s) (hp:p<3) (hx:x<truthRows n)
 (hM:offset+3*s*truthRows n≤M) (hW:10≤M):
 ∀c∈RecordedCofactorBank.cellProgram n s offset B g p x D,Content M c:=by
 have hq:low n offset g p x≤M:=(CofactorBytes.low_bound n s offset g p x hg hp hx).trans hM
 have ha:(high n s g p x true:Int).natAbs≤M:=by
   rw [Int.natAbs_natCast];exact (CofactorBank.high_bound n s g p x hg hp hx true).trans (by omega)
 have hb:(high n s g p x false:Int).natAbs≤M:=by
   rw [Int.natAbs_natCast];exact (CofactorBank.high_bound n s g p x hg hp hx false).trans (by omega)
 have hc:(B:Int).natAbs≤M:=by simp only [Int.natAbs_natCast];omega
 apply NumericRecordedGates.program M D [] _ _ hq
 intro r hr
 apply NumericRecordedGates.gate_row M _ r hq
 · simp only [muxGate,List.mem_cons,List.not_mem_nil,or_false] at hr
   rcases hr with rfl|rfl|rfl|rfl
   all_goals intro l hl;simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
   all_goals rcases hl with rfl|rfl
   all_goals first | exact ha | exact hb | exact hc | simpa using ha | simpa using hb | simpa using hc
 · simp only [muxGate,List.mem_cons,List.not_mem_nil,or_false] at hr
   rcases hr with rfl|rfl|rfl|rfl <;> exact hW

theorem program (M n s offset B:Nat) (D:List Row)
 (hV:variableCount (n+1) s≤offset) (hB:B≤offset)
 (hM:offset+3*s*truthRows n≤M) (hW:10≤M):
 ∀c∈RecordedCofactorBank.program n s offset B D,Content M c:=by
 apply NumericAllocationLoop.program
 intro g hg db
 apply NumericAllocationLoop.program
 intro p hp db'
 apply NumericAllocationLoop.program
 intro x hx db''
 exact cell M n s offset B g p x db'' hV hB hg hp hx hM hW

#print axioms program
end L3Emitter.NumericCofactorFields

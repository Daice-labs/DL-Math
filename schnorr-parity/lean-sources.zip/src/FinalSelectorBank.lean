import FinalSelectorSeed
namespace L3Emitter.FinalSelectorBank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram
open FinalOutputDefinitions FinalSelectorSources FinalSelectorSpecs FinalSelectorSeed
abbrev Job (n:Nat):=Fin 2×List (Lit n)
def jobs (n:Nat):List (Job n):=(List.finRange 2).flatMap (fun p=>(specs n).map (p,·))
def rows (n:Nat) (hn:2≤n) (j:Job n):List Row:=
  [seedRow n hn j.1 j.2]++MuxConditionalClause.caseRows (H n hn) (target n hn j.1) j.2++[GuardedVectorTransport.row (target n hn j.1) j.2]
def leaf (n:Nat) (hn:2≤n) (j:Job n) (E:List Row):Program:=
  [(seedRow n hn j.1 j.2,seedTape n hn j.1 j.2 E)]++
  MuxConditionalClause.program (E++[seedRow n hn j.1 j.2]) (H n hn) (raw n hn j.1) (alternative n hn j.1) (target n hn j.1) j.2

theorem leaf_check (n:Nat) (hn:2≤n) (j:Job n) (hj:j.2∈specs n) (E:List Row)
    (he:∀R∈D n hn,R∈E):
    check E (leaf n hn j E)=some (E++rows n hn j):=by
  have hs:=FinalSelectorSeed.checks n hn j.1 j.2 hj E he
  have h0:check E [(seedRow n hn j.1 j.2,seedTape n hn j.1 j.2 E)]=some (E++[seedRow n hn j.1 j.2]):=by
    simp only [check,hs,↓reduceIte]
  have h1:=MuxConditionalClause.checks (E++[seedRow n hn j.1 j.2]) (H n hn) (raw n hn j.1)
    (alternative n hn j.1) (target n hn j.1) j.2 (nonempty n hn _ hj)
    (List.mem_append_left _ (he _ (raw_rows n hn j.1 j.2 hj)))
    (List.mem_append_right _ (List.mem_singleton_self _))
    (fun i=>⟨List.mem_append_left _ (he _ (raw_relations n hn j.1 i).1),List.mem_append_left _ (he _ (raw_relations n hn j.1 i).2)⟩)
    (fun i=>⟨List.mem_append_left _ (he _ (alternative_relations n hn j.1 i).1),List.mem_append_left _ (he _ (alternative_relations n hn j.1 i).2)⟩)
  simpa only [leaf,rows,MuxConditionalClause.result,List.append_assoc] using check_append _ _ _ _ _ h0 h1

def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n) (D n hn)
def result (n:Nat) (hn:2≤n):=D n hn++RetainedBlockFold.body (rows n hn) (jobs n)
theorem job_mem (n:Nat) (p:Fin 2) (ls:List (Lit n)):(p,ls)∈jobs n ↔ ls∈specs n:=by
  simp [jobs]
theorem checks (n:Nat) (hn:2≤n):check (D n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (fun j=>j.2∈specs n) (leaf_check n hn) _
    (fun j hj=>(job_mem n j.1 j.2).mp hj) _ (fun _ h=>h)
theorem original_to_selector_clauses (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalOutputRecorded.original_to_mux_relations n hn) (check_trace _ _ _ (checks n hn))
theorem contains (n:Nat) (hn:2≤n) (p:Fin 2) (ls:List (Lit n)) (hs:ls∈specs n):
    GuardedVectorTransport.row (target n hn p) ls∈result n hn:=
  List.mem_append_right _ (RetainedBlockFold.contains (rows n hn) (jobs n) (p,ls)
    ((job_mem n p ls).mpr hs) _ (List.mem_append_right _ (List.mem_singleton_self _)))
#print axioms original_to_selector_clauses
#print axioms contains
end L3Emitter.FinalSelectorBank

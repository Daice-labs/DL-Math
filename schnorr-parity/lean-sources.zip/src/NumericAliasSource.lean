import NumericStaticCofactors
import NumericRawBank
namespace L3Emitter.NumericAliasSource
open EREF EREF.GeneralRED REDWitness FamilyNamespace CofactorSemantics
open NumericForcingFields NumericCofactorNamespace NumericSelectedCofactors NumericStaticCofactors

def bound (n:Nat) (hn:2≤n):Nat:=cap n hn+12000*(n+2)^3*(2^(n+1))^2

theorem raw (n:Nat) (hn:2≤n):RowSupport.Bounded (bound n hn) (RawValueBank.result n hn).1:=by
  have h:=NumericRawBank.allocation_growth n hn
  have hcap:=RawBankSize.ceiling_le _ _ (output_rows n hn)
  apply RowSupport.mono _ (show CanonicalTrace.ceiling (RawValueBank.result n hn).1≤bound n hn by unfold bound;omega)
  exact CanonicalTrace.bounded _ (CanonicalTrace.trace (RawValueBank.original_to_raw_bank n hn).1
    (fun R hR=>(RowSupport.original_bounded _ _ (by omega) (by omega) R hR).1))

theorem unary_row (n:Nat) (hn:2≤n) (j:GammaUnary.Job n) (hj:j.1∈GammaConstant.jobs n hn):
    RowSupport.Bounded (cap n hn) [GammaUnary.row n hn j]:=by
  have h:=(GammaConstant.job_mem n hn j.1).mp hj
  have hb:=beta_job n hn j.1.1 h.1
  apply clause_rows _ [-GammaConstant.c j.1,-GammaConstant.e n j.1,BetaValue.C n hn (GammaConstant.betaJob j.1),GammaUnary.otherWire n hn j,GammaUnary.outWire n hn j,GammaUnary.fn n j] ?_
  intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl|rfl|rfl|rfl|rfl|rfl
  · rw[Int.natAbs_neg];exact hb.1.trans (by unfold cap;omega)
  · rw[Int.natAbs_neg];exact selector n hn _ _ _ h.2.1 h.2.2.2 (by omega)
  · change (output _ _).natAbs≤_;rw[output_abs];unfold cap ConstantCofactor.offset;omega
  · exact low_output n hn _ _ _ _ h.2.1 (by omega) hb.2.2.2
  · exact low_output n hn _ _ _ _ h.2.1 (by omega) hb.2.2.2
  · change (fnLiteral _ _ _ _ _ _).natAbs≤_
    unfold fnLiteral;rw[output_abs]
    have hbit (a b:Bool):2*a.toNat+b.toNat<4:=by cases a <;> cases b <;> decide
    have he:=(encode_bounds (n+1) (3*(n+1)-4) (.fn j.1.2.1 (2*(if j.1.2.2.1=0 then GammaUnary.a j else GammaUnary.other j).toNat+(if j.1.2.2.1=0 then GammaUnary.other j else GammaUnary.a j).toNat)) ⟨h.2.1,hbit _ _⟩).2
    exact he.trans ((ConstantCofactor.offset_original n hn).trans (by unfold cap;omega))

theorem unary (n:Nat) (hn:2≤n):RowSupport.Bounded (bound n hn) (GammaUnary.result n hn):=by
  apply RowSupport.append _ _ _ (raw n hn)
  intro R hR;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hR
  have hmem:j.1∈GammaConstant.jobs n hn:=by
    change j∈(GammaConstant.jobs n hn).flatMap (fun a=>[false,true].flatMap (fun b=>[false,true].map (fun v=>(a,b,v)))) at hj
    obtain ⟨a,ha,h⟩:=List.mem_flatMap.mp hj
    obtain ⟨b,hb,h⟩:=List.mem_flatMap.mp h
    obtain ⟨v,hv,he⟩:=List.mem_map.mp h
    cases he
    exact ha
  exact RowSupport.mono _ (show cap n hn≤bound n hn by unfold bound;omega)
    (unary_row n hn j hmem) _ (by simp)

theorem source (n:Nat) (hn:2≤n):RowSupport.Bounded (bound n hn) (AliasAssembly.source n hn):=by
  apply RowSupport.append _ _ _ (unary n hn)
  intro R hR;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hR
  have h:=(SelectorBank.job_mem (n+1) (3*(n+1)-4) j).mp hj
  apply clause_rows _ [-SelectorBank.left (n+1) (3*(n+1)-4) j,-SelectorBank.right (n+1) (3*(n+1)-4) j] ?_ _ (by simp[SelectorBank.row])
  intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl|rfl
  · rw[Int.natAbs_neg];exact (selector n hn _ _ _ h.1 h.2.1 h.2.2.1).trans (by unfold bound;omega)
  · rw[Int.natAbs_neg];exact (selector n hn _ _ _ h.1 h.2.1 h.2.2.2.1).trans (by unfold bound;omega)

theorem ceiling (n:Nat) (hn:2≤n):
    CanonicalTrace.ceiling (AliasAssembly.source n hn)≤14000*(n+2)^3*(2^(n+1))^2:=by
  have h:=RawBankSize.ceiling_le _ _ (source n hn)
  have hc:=cap_bound n hn
  have hp:1≤2^(n+1):=Nat.one_le_pow _ _ (by omega)
  have ht:FrontendNamespaceEnvelope.scale (n+1)≤(n+2)^3*(2^(n+1))^2:=by
    unfold FrontendNamespaceEnvelope.scale
    apply Nat.mul_le_mul
    · change (n+2)^2≤(n+2)^3
      exact Nat.pow_le_pow_right (by omega) (by omega)
    · nlinarith
  unfold bound at h
  nlinarith
#print axioms ceiling
end L3Emitter.NumericAliasSource

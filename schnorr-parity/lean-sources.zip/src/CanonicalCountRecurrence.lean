import AuditFamilyCosts

namespace L3Emitter.CanonicalCountRecurrence
open EREF EREF.GeneralRED RecordedScopedTrace AuditLocalCosts ActualLowerComposition

/-- Counts are numbers of main RED commands, local certificates, and frame rows;
none of these is a byte count. -/
def levelPrefix (m : Nat) := RecordedActualActivation.fullProgram (m+2) (by omega)
  (RecordedRecursiveStep.reserve (m+2) (RecordedUniformFamily.family m))
def frameRows (m : Nat) := (upper (m+2) (by omega)).length+(inputs (m+2) (by omega)).length+1

def redPrefixSum : Nat→Nat
  | 0=>0
  | m+1=>redPrefixSum m+redCount (levelPrefix m)
def certPrefixSum : Nat→Nat
  | 0=>0
  | m+1=>certPrefixSum m+certCount (levelPrefix m)
def replaySum : Nat→Nat
  | 0=>0
  | m+1=>replaySum m+frameRows m*(redCount (RecordedUniformFamily.family 0)+redPrefixSum m)

theorem red_exact (m : Nat) :
    redCount (RecordedUniformFamily.family m)=redCount (RecordedUniformFamily.family 0)+redPrefixSum m := by
  induction m with
  | zero=>simp [redPrefixSum]
  | succ m ih=>rw [AuditFamilyCosts.family_red_recurrence,ih];simp only [redPrefixSum,levelPrefix];omega

/-- Exact triangular recurrence: replay is charged against earlier RED steps,
not against the accumulated local-certificate count. -/
theorem cert_exact (m : Nat) :
    certCount (RecordedUniformFamily.family m)=certCount (RecordedUniformFamily.family 0)+
      certPrefixSum m+replaySum m := by
  induction m with
  | zero=>simp [certPrefixSum,replaySum]
  | succ m ih=>
    rw [AuditFamilyCosts.family_cert_recurrence,ih,red_exact]
    change certCount (levelPrefix m)+(_+_+_)+frameRows m*(_+_)=_
    simp only [certPrefixSum,replaySum]
    omega

theorem red_sum_bound (m A : Nat) (h : ∀ i<m,redCount (levelPrefix i)≤A) : redPrefixSum m≤m*A := by
  induction m with
  | zero=>simp [redPrefixSum]
  | succ m ih=>
    have hi:=ih (by intro i hi;exact h i (by omega))
    have hm:=h m (by omega)
    simp only [redPrefixSum,Nat.succ_mul]
    omega

theorem cert_sum_bound (m A : Nat) (h : ∀ i<m,certCount (levelPrefix i)≤A) : certPrefixSum m≤m*A := by
  induction m with
  | zero=>simp [certPrefixSum]
  | succ m ih=>
    have hi:=ih (by intro i hi;exact h i (by omega))
    have hm:=h m (by omega)
    simp only [certPrefixSum,Nat.succ_mul]
    omega

/-- A deliberately loose closed envelope avoids division: m levels, at most
U retained frame rows and A newly introduced RED steps per level. -/
theorem replay_bound (m U A : Nat)
    (hu : ∀ i<m,frameRows i≤U) (ha : ∀ i<m,redCount (levelPrefix i)≤A) :
    replaySum m≤m*U*(redCount (RecordedUniformFamily.family 0)+m*A) := by
  induction m with
  | zero=>simp [replaySum]
  | succ m ih=>
    have hi:=ih (by intro i hi;exact hu i (by omega)) (by intro i hi;exact ha i (by omega))
    have hs:=red_sum_bound m A (by intro i hi;exact ha i (by omega))
    have hf:=hu m (by omega)
    have hx:=Nat.mul_le_mul hf (Nat.add_le_add_left hs (redCount (RecordedUniformFamily.family 0)))
    simp only [replaySum]
    calc
      _≤m*U*(redCount (RecordedUniformFamily.family 0)+m*A)+
          U*(redCount (RecordedUniformFamily.family 0)+m*A):=Nat.add_le_add hi hx
      _=(m+1)*U*(redCount (RecordedUniformFamily.family 0)+m*A):=by ring
      _≤(m+1)*U*(redCount (RecordedUniformFamily.family 0)+(m+1)*A):=by
        apply Nat.mul_le_mul_left
        exact Nat.add_le_add_left (Nat.mul_le_mul_right A (by omega)) _

/-- Conditional only on explicit levelPrefix/frame envelopes. It does not claim
those envelopes have been discharged for the actual levelPrefix construction. -/
theorem cert_bound (m U A C : Nat)
    (hu : ∀ i<m,frameRows i≤U) (ha : ∀ i<m,redCount (levelPrefix i)≤A)
    (hc : ∀ i<m,certCount (levelPrefix i)≤C) :
    certCount (RecordedUniformFamily.family m)≤certCount (RecordedUniformFamily.family 0)+m*C+
      m*U*(redCount (RecordedUniformFamily.family 0)+m*A) := by
  rw [cert_exact]
  exact Nat.add_le_add (Nat.add_le_add_left (cert_sum_bound m C hc) _) (replay_bound m U A hu ha)

#print axioms red_exact
#print axioms cert_exact
#print axioms cert_bound
end L3Emitter.CanonicalCountRecurrence

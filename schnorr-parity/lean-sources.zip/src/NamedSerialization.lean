import NamedWitness
import NormalizationEmitter

namespace L3Emitter.NamedSerialization
open EREF EREF.GeneralRED FamilyNamespace FamilyRows NamedWitness

/-- The positive-wire/constant image vocabulary used by the actual frontend. -/
def targetImage (k s : Nat) : Target → L3Emitter.Image
  | .wire w => .lit ⟨encode k s w,false⟩
  | .bit b => .bit b

def entries (k s : Nat) (f : Wire → Target) : List (Nat × L3Emitter.Image) :=
  ((WireEnumeration.all k s).filter fun w => f w != Target.wire w).map
    fun w => (encode k s w,targetImage k s (f w))

def lookup : List (Nat × L3Emitter.Image) → Nat → L3Emitter.Image
  | [],v => .lit ⟨v,false⟩
  | p::ps,v => if v=p.1 then p.2 else lookup ps v

theorem lookup_correct (ps : List (Nat × L3Emitter.Image)) (v : Nat) (m : L3Emitter.Image)
    (h : ∀ p∈ps,p.1=v → p.2=m)
    (he : L3Emitter.Image.lit ⟨v,false⟩=m ∨ ∃ p∈ps,p.1=v) : lookup ps v=m := by
  induction ps with
  | nil => simpa [lookup] using he
  | cons p ps ih =>
    by_cases hp : v=p.1
    · simp only [lookup,if_pos hp]; exact h p (by simp) hp.symm
    · simp only [lookup,if_neg hp]
      apply ih (by intro q hq; exact h q (by simp [hq]))
      rcases he with he | ⟨q,hq,hqv⟩
      · exact Or.inl he
      · rcases List.mem_cons.mp hq with rfl | hq
        · exact False.elim (hp hqv.symm)
        · exact Or.inr ⟨q,hq,hqv⟩

theorem lookup_entries (k s : Nat) (f : Wire → Target) (w : Wire) (hw : Valid k s w) :
    lookup (entries k s f) (encode k s w)=targetImage k s (f w) := by
  apply lookup_correct
  · intro p hp he
    obtain ⟨u,hu,rfl⟩ := List.mem_map.mp hp
    have hv := (WireEnumeration.mem_all k s u).mp (List.mem_filter.mp hu).1
    have huw := encode_injective k s u w hv hw he
    subst u; rfl
  · by_cases he : f w=Target.wire w
    · left; rw [he]; rfl
    · right
      refine ⟨(encode k s w,targetImage k s (f w)),?_,rfl⟩
      exact List.mem_map.mpr ⟨w,List.mem_filter.mpr
        ⟨(WireEnumeration.mem_all k s w).mpr hw,by simpa using he⟩,rfl⟩

def decodeImage : L3Emitter.Image → EREF.GeneralRED.Image
  | .bit b => .constant b
  | .lit l => if h : 0<l.varId then
      .literal (if l.negative then -(l.varId:Int) else l.varId) (by split <;> omega)
      else .constant false

def decoded (es : List (Nat × L3Emitter.Image)) : Witness := fun v => decodeImage (lookup es v)

theorem target_eval (k s : Nat) (t : Target) (ht : t.valid k s) (α : Val) :
    (decodeImage (targetImage k s t)).eval α=t.eval (valuation k s α) := by
  cases t with
  | bit b => rfl
  | wire w =>
    have hp := (encode_bounds k s w ht).1
    simp [decodeImage,targetImage,EREF.GeneralRED.Image.eval,Target.eval,valuation,hp,
      show encode k s w≠0 by omega]

theorem decoded_at (k s : Nat) (f : Wire → Target)
    (hf : ∀ w,Valid k s w → (f w).valid k s) (w : Wire) (hw : Valid k s w) (α : Val) :
    applyWitness (decoded (entries k s f)) α (encode k s w)=
      (f w).eval (valuation k s α) := by
  unfold applyWitness decoded
  rw [lookup_entries k s f w hw,target_eval k s (f w) (hf w hw)]

theorem serialized_subst (k s : Nat) (f : Wire → Target)
    (hf : ∀ w,Valid k s w → (f w).valid k s) (r : Spec) (hr : r.valid k s) :
    substRow (r.row k s) (decoded (entries k s f))=
      substRow (r.row k s) (NamedWitness.witness k s f hf) := by
  apply NormalizationEmitter.named_subst_ext _ _ _ hr
  intro w hw α
  rw [decoded_at k s f hf w hw α,NamedWitness.at_wire k s f hf w hw α]

theorem wire_serialized_subst (k s : Nat) (f : Wire → Wire)
    (hf : ∀ w,Valid k s w → Valid k s (f w)) (r : Spec) (hr : r.valid k s) :
    substRow (r.row k s) (decoded (entries k s (fun w => .wire (f w))))=
      substRow (r.row k s) (wireWitness k s f hf) := by
  apply NormalizationEmitter.named_subst_ext _ _ _ hr
  intro w hw α
  rw [decoded_at k s (fun w => .wire (f w)) hf w hw α,witness_at k s f hf w hw α]
  rfl

theorem entries_length (k s : Nat) (f : Wire → Target) :
    (entries k s f).length≤variableCount k s := by
  rw [entries,List.length_map,← WireEnumeration.all_length]
  exact List.length_filter_le _ _

#print axioms serialized_subst
#print axioms wire_serialized_subst
#print axioms entries_length
end L3Emitter.NamedSerialization

import UnaryLeafMainTapes
namespace L3Emitter.FirstGateMainTapes
open EREF EREF.GeneralRED AliasNetwork U2ConstructionSize

theorem pin (n : Nat) (hn : 2≤n) (p : Nat) (D : List Row) :
    (FirstGatePins.tape n hn p D).length≤2*n+3 := by
  rw [FirstGatePins.tape,SelectorPinTape.token_count]
  unfold FirstGatePins.other
  split
  · simp only [L3.Fam.other0,List.length_map,List.length_range']
    change 1+2*(n+1-1)≤_;omega
  · simp only [L3.Fam.other1,List.length_cons,List.length_map,List.length_range']
    change 1+2*(n+1-2+1)≤_;omega

theorem prepare (n : Nat) (hn : 2≤n) : tokens (FirstValueBank.prepare n hn)≤38*(n+1) := by
  have h0:=pin n hn 0 (SharedValueBank.result n hn)
  have h1:=pin n hn 1 (SharedValueBank.result n hn)
  have hm:tokens (FirstUnaryMux.program n hn (SharedValueBank.result n hn++FirstValueBank.pins n hn))=32:=by
    rw [FirstUnaryMux.program,NetworkMainTokens.expressions];rfl
  rw [FirstValueBank.prepare,tokens_append,hm]
  simp only [FirstGatePins.program,tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil];omega

theorem core (B a b q f u : Bit) (D : List Row) : tokens (FirstValueCore.program B a b q f u D)=30 := by
  simp [FirstValueCore.program,tokens,CommonGuardResolve.token_count]

theorem value (n : Nat) (hn : 2≤n) (x : Nat) (v : Bool) (D : List Row) :
    tokens (FirstGateValue.program n hn x v D)=64 := by
  rw [FirstGateValue.program,tokens_append,tokens_append]
  have h0:tokens (FirstGateValue.sideProgram n hn x false v D)=30:=core ..
  have h1:tokens (FirstGateValue.sideProgram n hn x true v (D++FirstGateValue.sideRows n hn x false v))=30:=core ..
  rw [h0,h1]
  simp [tokens,FirstGateValue.joinTape,CommonGuardResolve.token_count]

theorem one_x (n : Nat) (hn : 2≤n) (x : Nat) (D : List Row) :
    tokens (FirstValueBank.xProgram n hn x D)=150 := by
  rw [FirstValueBank.xProgram,tokens_append,tokens_append,value,value]
  simp [FirstCofactorRows.program,tokens,FirstCofactorRows.portTape,FirstCofactorRows.unitTape,
    CommonGuardResolve.token_count]

theorem values (n : Nat) (hn : 2≤n) : tokens (FirstValueBank.program n hn)≤150*2^n := by
  have h:=fold_tokens (FirstValueBank.xProgram n hn) (FirstValueBank.xRows n hn)
    (List.range (FamilyNamespace.truthRows n)) (FirstValueBank.prepared n hn) 150
    (by intro j hj D;exact (one_x n hn j D).le)
  simpa only [FirstValueBank.program,List.length_range,FamilyNamespace.truthRows,Nat.mul_comm] using h

theorem leaf (n : Nat) (hn : 2≤n) (x : Nat) (i : Fin (AliasAssembly.width (n+1))) (b v : Bool) (D : List Row) :
    (FirstBaseLeaves.tape n hn x i b v D).length≤9 := by
  unfold FirstBaseLeaves.tape;split
  · change 5≤9;omega
  · have h:=PortValueBounds.unit_tokens D (PrimaryAliasBank.cfg n hn).T (FirstBaseLeaves.xs n hn x i b v)
    simpa only [FirstBaseLeaves.xs,List.length_cons,List.length_nil,Nat.reduceAdd,Nat.reduceMul] using h

theorem complete (n : Nat) (hn : 2≤n) : tokens (FirstGateBase.program n hn)≤144*(n+1)*2^n := by
  have h:=GlobalFixedMainTapes.map_factor (FirstGateBase.jobs n) (FirstGateBase.row n hn)
    (fun j=>FirstBaseLeaves.tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2 (FirstValueBank.result n hn)) 9
    (by intro j hj;exact leaf ..)
  have hc:=ConstructionFirstValueCount.first_gate n hn
  have he:(FirstGateBase.program n hn).length=(FirstGateBase.jobs n).length:=List.length_map _
  change tokens (FirstGateBase.program n hn)≤_ at h
  rw [he] at hc
  exact h.trans (by nlinarith)
#print axioms prepare
#print axioms values
#print axioms complete
end L3Emitter.FirstGateMainTapes

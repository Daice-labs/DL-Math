import L3BranchRecords

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def branchBank (bs : List Nat) (acc : StI F.V × List Int) : StI F.V × List Int :=
  bs.foldl F.bStep acc

theorem branchBank_keeps (bs : List Nat) (acc : StI F.V × List Int) :
    Keeps2 acc.1 (F.branchBank bs acc).1 :=
  keeps2_foldl_pair _ _ F.keeps2_bStep acc

theorem branchBank_old (bs : List Nat) (acc : StI F.V × List Int) :
    ∀x∈acc.2,x∈(F.branchBank bs acc).2 := by
  induction bs generalizing acc with
  | nil => exact fun _ h => h
  | cons b bs ih =>
    exact fun x hx => ih _ x (F.branchFold_old b _ acc x hx)

theorem branchBank_records (bs : List Nat) (acc : StI F.V × List Int)
    (ht : F.Good3 acc.1) (hbs : ∀b∈bs,1≤b) :
    ∀b∈bs,∀g,b<g → g<F.s →
      F.BranchRecord b g (F.branchBank bs acc).1 (F.branchBank bs acc).2 := by
  induction bs generalizing acc with
  | nil => simp
  | cons j js ih =>
    intro b hb g hbg hg
    let u := F.bStep acc j
    have hu : F.Good3 u.1 := F.Good3_of_keeps2 (F.keeps2_bStep acc j) ht
    rcases List.mem_cons.mp hb with rfl | hb
    · apply F.BranchRecord_keeps (F.branchBank_keeps js u) (F.branchBank_old js u) b g
      exact F.branchFold_records b _ acc ht (hbs b (by simp))
        (fun z hz => by have := List.mem_range'_1.mp hz; omega) g
        (List.mem_range'_1.mpr ⟨by omega,by omega⟩)
    · exact ih u hu (fun z hz => hbs z (by simp [hz])) b hb g hbg hg

theorem branchBank_obls (bs : List Nat) (acc : StI F.V × List Int)
    (ho : ObligationsChecked F.db5 acc.1.s.cmds) :
    ObligationsChecked F.db5 (F.branchBank bs acc).1.s.cmds := by
  induction bs generalizing acc with
  | nil => exact ho
  | cons b bs ih => exact ih _ (F.branchFold_obls b _ acc ho)

theorem branchBank_bounded (bs : List Nat) (acc : StI F.V × List Int)
    (hb : Bounded acc.1.s.var acc.2) :
    Bounded (F.branchBank bs acc).1.s.var (F.branchBank bs acc).2 := by
  have step : ∀(b : Nat) (gs : List Nat) (a : StI F.V × List Int), Bounded a.1.s.var a.2 →
      Bounded (gs.foldl (F.branchStep b) a).1.s.var (gs.foldl (F.branchStep b) a).2 := by
    intro b gs
    induction gs with
    | nil => exact fun _ h => h
    | cons g gs ih =>
      intro a ha
      apply ih
      rw [F.branchStep_list]
      intro l hl
      rcases List.mem_append.mp hl with hl | hl
      · have hh := ha l hl
        have hv := var_le_of_grows (F.keeps2_branchStep b a g).1
        exact ⟨hh.1,Nat.le_trans hh.2 hv⟩
      · simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
        subst l
        change 0 < Int.natAbs ((a.1.s.var+2:Nat):Int) ∧ Int.natAbs ((a.1.s.var+2:Nat):Int) ≤ a.1.s.var+1+1
        simp; omega
  induction bs generalizing acc with
  | nil => exact hb
  | cons b bs ih => exact ih _ (step b _ acc hb)

#print axioms branchBank_records
#print axioms branchBank_bounded
end L3.Fam

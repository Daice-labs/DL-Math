import FirstPortRelations

namespace L3Emitter.FirstPortOneHot
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram
open SelectedVectorOneHot FirstPortRelations

def cs (n:Nat) (hn:2≤n) (p:Nat) :=
  SelectedVectorClauses.choices (n+1) 0 ((PrimaryAliasBank.cfg n hn).sel 0 p)
def inputs (n:Nat) (hn:2≤n) (p:Nat) (c:Bit) := initialAliases n hn
  (SelectedVectorClauses.originalIndex (n+1) (3*(n+1)-4) 0 p c)
def target (n:Nat) (hn:2≤n) (p:Nat) := (portAt n hn p).1.1

theorem selector_bank (n:Nat) (hn:2≤n) :
    ∀R∈SelectorBank.result n hn,R∈PrimaryAliasBank.result n hn := by
  intro R hr
  have h:=AliasAssembly.preserves_predecessor n hn R hr
  rw [←(RecordedAliasRun.built_binding n hn).2] at h
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ h)))

def block (n:Nat) (hn:2≤n) (p:Nat) (D:List Row) :=
  SelectedVectorOneHot.program D (cs n hn p) (inputs n hn p) (target n hn p)
def blockResult (n:Nat) (hn:2≤n) (p:Nat) (D:List Row) :=
  SelectedVectorOneHot.result D (cs n hn p) (target n hn p)

theorem block_check (n:Nat) (hn:2≤n) (p:Nat) (hp:p<2) (D:List Row)
    (hd:∀R∈PrimaryAliasBank.result n hn,R∈D) :
    check D (block n hn p D)=some (blockResult n hn p D) := by
  apply SelectedVectorOneHot.checks
  · unfold AliasAssembly.width RankConstruction.width;omega
  · simp [cs,SelectedVectorClauses.choices]
  · exact hd _ (selector_bank n hn _ (SelectedVectorClauses.original_alo n hn 0 p (by omega) hp))
  · intro c hc
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    have hj':j<n+1:=by simpa using List.mem_range.mp hj
    have h:=PrimaryAliasBank.source_rows n hn j hj'
    change SourceRows D (initialAliases n hn
      (SelectedVectorClauses.originalIndex (n+1) (3*(n+1)-4) 0 p
        (AliasAssembly.selector (n+1) (3*(n+1)-4) 0 p j)))
    rw [SelectedVectorClauses.originalIndex_at]
    exact ⟨hd _ h.1,fun i l hil=>hd _ (h.2 i l hil)⟩
  · intro c hc i
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    have hj':j<n+1:=by simpa using List.mem_range.mp hj
    have h:=FirstPortRelations.relations n hn p hp j hj' i
    change clause [-((PrimaryAliasBank.cfg n hn).sel 0 p j).val,
        -(initialAliases n hn (SelectedVectorClauses.originalIndex (n+1) (3*(n+1)-4) 0 p
          (AliasAssembly.selector (n+1) (3*(n+1)-4) 0 p j)) i).val,(target n hn p i).val]∈D ∧
      clause [-((PrimaryAliasBank.cfg n hn).sel 0 p j).val,-(target n hn p i).val,
        (initialAliases n hn (SelectedVectorClauses.originalIndex (n+1) (3*(n+1)-4) 0 p
          (AliasAssembly.selector (n+1) (3*(n+1)-4) 0 p j)) i).val]∈D
    rw [SelectedVectorClauses.originalIndex_at]
    exact ⟨hd _ h.1,hd _ h.2⟩

theorem block_retains (n:Nat) (hn:2≤n) (p:Nat) (D:List Row) :
    ∀R∈D,R∈blockResult n hn p D := fun R h=>List.mem_append_left _ (List.mem_append_left _ h)

def middle (n:Nat) (hn:2≤n) := blockResult n hn 0 (PrimaryAliasBank.result n hn)
def result (n:Nat) (hn:2≤n) := blockResult n hn 1 (middle n hn)
def emitted (n:Nat) (hn:2≤n) := block n hn 0 (PrimaryAliasBank.result n hn)++block n hn 1 (middle n hn)

theorem checks (n:Nat) (hn:2≤n) :
    check (PrimaryAliasBank.result n hn) (emitted n hn)=some (result n hn) :=
  check_append _ _ _ _ _ (block_check n hn 0 (by omega) _ (fun R h=>h))
    (block_check n hn 1 (by omega) _ (block_retains n hn 0 _))

theorem original_to_first_port_onehot (n:Nat) (hn:2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (PrimaryAliasBank.original_to_primary_sources n hn)
    (check_trace _ _ _ (checks n hn))

theorem full_constraints (n:Nat) (hn:2≤n) (p:Nat) (hp:p<2) :
    clause (sourceLiterals (target n hn p))∈result n hn ∧
    Cardinality.amo (sourceLiterals (target n hn p))∈result n hn := by
  have hw:0<AliasAssembly.width (n+1):=by unfold AliasAssembly.width RankConstruction.width;omega
  by_cases h:p=0
  · subst p
    have h:=SelectedVectorOneHot.final_rows (PrimaryAliasBank.result n hn) (cs n hn 0) (target n hn 0) hw
    exact ⟨block_retains n hn 1 _ _ h.1,block_retains n hn 1 _ _ h.2⟩
  · have he:p=1:=by omega
    subst p
    exact SelectedVectorOneHot.final_rows (middle n hn) (cs n hn 1) (target n hn 1) hw

#print axioms original_to_first_port_onehot
#print axioms full_constraints
end L3Emitter.FirstPortOneHot

import ConstructionSelectionCount
import RecordedCofactorSelection
import SelectedValueSize

namespace L3Emitter.ConstructionCofactorCount
open EREF EREF.GeneralRED ConstructionFrontendCountTools ConstructionSelectionCount

theorem definition_length (D : List Row) (q : Nat) (defs : L3.Defs) :
    (RecordedDefinitions.emit D q defs).length=defs.length := by
  simp only [RecordedDefinitions.emit,gate_length,RecordedDefinitions.data,List.length_map]

theorem bit_lines (D : List Row) (all : List Int) (B : Int) (f : Int→Bool) (todo : List Int) :
    (OneHotBit.program D all B f todo).length=todo.length := by
  induction todo generalizing D with
  | nil=>rfl
  | cons x xs ih=>simp only [OneHotBit.program,List.length_cons,ih]

theorem bit (D : List Row) (m : Nat) (xs : List Int) (f : Int→Bool) :
    (RecordedOneHotBit.program D m xs f).length≤2*xs.length+1 := by
  rw [RecordedOneHotBit.program,List.length_append,definition_length,
    ConstructionCountTools.polProgram_length,bit_lines]
  simp only [L3.orDefs,List.length_append,List.length_map,List.length_cons,List.length_nil]
  have h:(OneHotBit.ones xs f).length≤xs.length:=List.length_filter_le ..
  omega

theorem definition_bank (m a count B : Nat) (f : Nat→List Int)
    (hf : ∀i,(f i).length≤B) :
    list (DefinitionBank.cmds m a f count)≤count*(B+1) := by
  induction count generalizing m a with
  | zero=>simp [DefinitionBank.cmds,list]
  | succ n ih=>
    change (f a).length+1+list (DefinitionBank.cmds (m+1) (a+1) f n)≤(n+1)*(B+1)
    have h:=ih (m+1) (a+1)
    have ha:=hf a
    nlinarith

theorem rank (k : Nat) (hk : 3≤k) :
    (RecordedRankDefinitions.program k hk).length≤90*(k+1)^4 := by
  rw [RecordedRankDefinitions.program,definitions]
  have hh:=definition_bank (RestrictionBit.B k hk) 0 (RankConstruction.count k)
    (9*k^2) (RankConstruction.supportAt k hk) (by
      intro i
      simp only [RankConstruction.supportAt,RankProjection.support,List.length_map]
      exact (List.length_filter_le ..).trans (ForcingSize.chosen_bound k hk))
  have hc:RankConstruction.count k≤9*k^2 := by
    unfold RankConstruction.count RankConstruction.width
    have h1:3*k-4≤3*k:=Nat.sub_le ..
    have h2:(3*k-4)-3≤3*k:=by omega
    nlinarith [Nat.mul_le_mul h1 h2]
  have hm:=Nat.mul_le_mul_right (9*k^2+1) hc
  have hp:(k+1)^2≤(k+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have h2:k^2≤(k+1)^2:=Nat.pow_le_pow_left (by omega) 2
  have h4:k^4≤(k+1)^4:=Nat.pow_le_pow_left (by omega) 4
  change list (DefinitionBank.cmds _ _ _ _)≤_
  nlinarith

theorem value_definitions (m : Nat) (f : Int→Int) (xs : List Int) :
    list (SelectedValue.cmds m f xs)=3*xs.length := by
  induction xs generalizing m with
  | nil=>rfl
  | cons x xs ih=>
    change 3+list (SelectedValue.cmds (m+1) f xs)=3*(xs.length+1)
    rw [ih];omega

theorem value_lines (D : List Row) (es : List SelectedValue.Cell) (C : Nat)
    (todo : List SelectedValue.Cell) :
    (SelectedValueProgram.program D es C todo).length=2*todo.length := by
  induction todo generalizing D with
  | nil=>rfl
  | cons e es ih=>
    simp only [SelectedValueProgram.program,List.length_append,AliasProgram.bitProgram,
      List.length_cons,List.length_nil,ih]
    omega

theorem value (D : List Row) (m : Nat) (xs : List Int) (f : Int→Int) :
    (RecordedSelectedValue.program D m xs f).length=6*xs.length+1 := by
  simp only [RecordedSelectedValue.program,RecordedSelectedValue.definitionProgram,
    List.length_append,definitions,value_definitions,definition_length,
    ConstructionCountTools.polProgram_length,value_lines,L3.orDefs,List.length_map,
    SelectedValue.terms,SelectedValueSize.cells_length,List.length_cons,List.length_nil]
  omega

theorem restriction_choices (k : Nat) (hk : 3≤k) :
    (RestrictionBit.choices k hk).length≤36*k^2 := by
  simpa only [RestrictionBit.choices,PriorityBank.choices,List.length_map,PriorityBank.nodes_length]
    using forcing_inputs k hk

theorem restriction (k : Nat) (hk : 3≤k) :
    (RecordedCofactorSelection.restrictionProgram k hk).length≤3100*(k+1)^4 := by
  have hs:=selected k hk
  have hb:=bit (ForcingFamily.selected k hk) (RestrictionBit.upper k hk)
    (RestrictionBit.choices k hk) (RestrictionBit.predicate k hk)
  have hx:=restriction_choices k hk
  have hp:(k+1)^2≤(k+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have h2:k^2≤(k+1)^2:=Nat.pow_le_pow_left (by omega) 2
  simp only [RecordedCofactorSelection.restrictionProgram,List.length_append]
  nlinarith

/-- Actual cofactor selection prefix including rank and constant definitions.
The unit is main commands; local certificates and printed fields are separate. -/
theorem complete (k : Nat) (hk : 3≤k) :
    (RecordedCofactorSelection.program k hk).length≤3500*(k+1)^4 := by
  have hr:=restriction k hk
  have hk':=rank k hk
  have hc:=SelectedValueSize.choice_count k hk
  have hp:(k+1)^2≤(k+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have h2:k^2≤(k+1)^2:=Nat.pow_le_pow_left (by omega) 2
  simp only [RecordedCofactorSelection.program,List.length_append,value]
  nlinarith

#print axioms rank
#print axioms value
#print axioms complete
end L3Emitter.ConstructionCofactorCount

import GateEvaluationBindings
namespace L3Emitter.ComposedGateEvaluation
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL AliasProgram
abbrev Case:=Bool×Bool
def cases:List Case:=[(false,false),(false,true),(true,false),(true,true)]
def core (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool):List Int:=
  [-(TopologyContext.guard n hn G t).val,-sign a (LowerTransferImage.wire n hn (.port t 0 x)),
    -sign b (LowerTransferImage.wire n hn (.port t 1 x)),-sign w (RankTableBank.table n hn G a b),
    sign w (CofactorValueRows.cofactor n hn G x)]
def vars (n:Nat) (hn:2≤n) (G:Nat) (a b:Bool):List Int:=
  [(ComposedTableBank.unary n hn G 0 a).val,(ComposedTableBank.unary n hn G 1 b).val]
def guards (n:Nat) (hn:2≤n) (G:Nat) (a b:Bool) (c:Case):List Int:=
  [-sign c.1 (ComposedTableBank.unary n hn G 0 a),-sign c.2 (ComposedTableBank.unary n hn G 1 b)]
def caseRow (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool) (c:Case):=
  GateEvaluationPOL.target (GateEvaluationBindings.lits n hn t G x a b w c.1 c.2)
def caseRows (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool):=cases.map (caseRow n hn t G x a b w)
def casesProgram (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool) (D:List Row):Program:=
  cases.map fun c=>(caseRow n hn t G x a b w c,GateEvaluationPOL.tape D (GateEvaluationBindings.lits n hn t G x a b w c.1 c.2))
def rows (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool):=
  caseRows n hn t G x a b w++SplitJoinPOL.rows (core n hn t G x a b w) (vars n hn G a b)
def program (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool) (D:List Row):Program:=
  casesProgram n hn t G x a b w D++
    SplitJoinPOL.program (D++caseRows n hn t G x a b w) (core n hn t G x a b w) (vars n hn G a b)

theorem guards_cover (n:Nat) (hn:2≤n) (G:Nat) (a b:Bool):
    cases.map (guards n hn G a b)=SplitJoinPOL.choices (vars n hn G a b):=by
  simp [cases,guards,vars,SplitJoinPOL.choices,sign]
theorem valid_core (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool):Valid (core n hn t G x a b w):=by
  simp [core,Valid,sign_valid,(TopologyContext.guard n hn G t).property]

theorem checks (n:Nat) (hn:2≤n) (t G x:Nat) (ht:t<RankConstruction.width (n+1))
    (hG:G∈RankZeroTransport.gates n) (hx:x<FamilyNamespace.truthRows n) (a b w:Bool)
    (D:List Row) (hd:∀R∈GateEvaluationBindings.base n hn,R∈D):
    check D (program n hn t G x a b w D)=some (D++rows n hn t G x a b w):=by
  have h0:=IndependentProgram.check_base D (casesProgram n hn t G x a b w D) (by
    intro c hc;obtain ⟨q,hq,rfl⟩:=List.mem_map.mp hc
    exact GateEvaluationBindings.checks n hn t G x ht hG hx a b w q.1 q.2 D hd)
  have he:outputs (casesProgram n hn t G x a b w D)=caseRows n hn t G x a b w:=by
    simp [outputs,casesProgram,caseRows,List.map_map]
  rw [he] at h0
  have hh (gs:List Int) (hgs:gs∈SplitJoinPOL.choices (vars n hn G a b)):
      clause (core n hn t G x a b w++gs)∈D++caseRows n hn t G x a b w:=by
    rw [←guards_cover] at hgs
    obtain ⟨c,hc,rfl⟩:=List.mem_map.mp hgs
    exact List.mem_append_right _ (List.mem_map.mpr ⟨c,hc,rfl⟩)
  have h1:=SplitJoinPOL.checks _ (core n hn t G x a b w) (vars n hn G a b)
    (valid_core n hn t G x a b w)
    (by simp [vars,Valid,(ComposedTableBank.unary n hn G 0 a).property,(ComposedTableBank.unary n hn G 1 b).property]) hh
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h1

theorem final_mem (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool):
    clause (core n hn t G x a b w)∈rows n hn t G x a b w:=
  List.mem_append_right _ (SplitJoinPOL.final_mem _ _)
#print axioms checks
end L3Emitter.ComposedGateEvaluation

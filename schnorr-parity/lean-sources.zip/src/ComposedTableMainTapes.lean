import CoordinateMainTapes
import ConstructionComposedTableCount
namespace L3Emitter.ComposedTableMainTapes
open EREF EREF.GeneralRED AliasNetwork U2ConstructionSize MainTapeRecurrence

theorem lookup {base : List Row} (f : Bool→Bool→Bit) (a b : Bit) (va vb v : Bool)
    (z : Net base) (D : List Row) : tokens (LookupEvaluation.program f a b va vb v z D)≤75 := by
  have h0:=PrunedMuxEvaluation.count (LookupEvaluation.innerJob f b va z) vb (.leaf (f va vb) v)
  have h1:=PrunedMuxEvaluation.count (LookupEvaluation.outerJob f a b z) va (LookupEvaluation.innerTree f b va vb v z)
  change (LookupEvaluation.innerTree f b va vb v z).count≤0+3 at h0
  change (LookupEvaluation.tree f a b va vb v z).count≤_ at h1
  have ht:=GuardedTree.Tree.tokens_bound (LookupEvaluation.tree f a b va vb v z)
    (D++LookupEvaluation.seedRows f a b va vb v) (LookupEvaluation.guards f a b va vb v)
  change tokens _≤_ at ht
  have hs:tokens (EvaluationCaseSeeds.program D [] (LookupEvaluation.guards f a b va vb v))=27:=by
    simp [LookupEvaluation.guards,EvaluationCaseSeeds.program,EvaluationCaseSeeds.one,tokens,
      ComplementChoice.tautTokens,ChoiceProjection.weakenTokens,ClauseTransport.padSteps]
  rw [LookupEvaluation.program,tokens_append,hs]
  omega

theorem complete (n : Nat) (hn : 2≤n) :
    count (RecordedComposedTables.program n hn)≤7200*(n+1) := by
  have h:=fold_tokens (ComposedTableBank.leaf n hn) (ComposedTableBank.rows n hn)
    (ComposedTableBank.cases n hn) (ComposedTableBank.built n hn).1.rows 75
    (by intro c hc D;exact lookup ..)
  change tokens (ComposedTableBank.program n hn)≤_ at h
  rw [ConstructionComposedTableCount.cases_count,ConstructionComposedTableCount.jobs] at h
  simp only [RecordedComposedTables.program,append,CompleteFinalRowTapes.network_zero,pol_program,Nat.zero_add]
  change tokens (ComposedTableBank.program n hn)≤_
  omega
#print axioms lookup
#print axioms complete
end L3Emitter.ComposedTableMainTapes

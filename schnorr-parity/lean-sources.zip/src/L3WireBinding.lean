import L3PredecessorRoot

namespace L3.Fam
open L3 EREF EREF.GeneralRED
variable (F : Fam)

/-- A selected earlier gate gets its liveness rows and equality root from
    the actual builder state, including the special gate-zero root. -/
theorem predecessor_from_database (hk : 2≤F.k) (hs : 1≤F.s)
    (t : StI F.V) (ht : F.Good3 t) (g p h bit cb q : Nat)
    (hg : g<F.s) (hp : p<2) (hh : h<g) (hb : bit<2)
    (hc : 1≤cb) (hq : 1≤q)
    (hr : F.GateRecord bit cb h t)
    (heq : Cmd.eqDef q (F.port g p (F.bitX bit) : Int) (F.port g p (F.bitY bit) : Int)∈t.s.cmds)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hm : ∀R∈exec F.db5 t.s.cmds,R∈D) (pol : Bool) :
    Refutation (D ++ [negate (clauseRow
      (F.wireLeaf g p (F.k+h) (F.bitX bit) t.s.A cb (t.s.live g) q pol)).toE]) := by
  have ep : (g,p)∈F.edgePairs h := (F.mem_edgePairs h (g,p)).mpr ⟨by omega,hg,hp⟩
  have lh := (ht.2.1 h (by omega)).1
  have eh := (ht.2.1 h (by omega)).2 (g,p) ep
  have hlg := F.live_bound_of_good3 ht g hg
  have hlh := F.live_bound_of_good3 ht h (by omega)
  have hA := ht.2.2.2.2.2.1
  have hedge := eh.2.1
  change F.V<t.s.edges h g p at hedge
  have hv := hr.2.2.1
  have vrows := eqDef_rows F.db5 t.s.cmds _ _ _ hr.1
  have qrows := eqDef_rows F.db5 t.s.cmds _ _ _ heq
  have horig : ∀r∈F.rows,r.toE∈D := fun r h => hm _ (exec_mono _ _ _ (F.original_mem_db5 r h))
  apply F.predecessor_actual_leaf g p h (F.bitX bit) (F.bitY bit) t.s.A cb
    (t.s.live g) (t.s.live h) (t.s.edges h g p) (t.s.veq h bit) q pol
    (by omega) hc (by omega) (by omega) (by omega) (by omega) hq D hD
  refine ⟨?_,?_,?_,?_,?_,?_,?_,trivial⟩
  · exact hm _ (andDef_row_up F.db5 t.s.cmds _ _ eh.1)
  · apply hm
    apply orDef_row_up F.db5 t.s.cmds _ _ lh.1
    exact List.mem_map.mpr ⟨(g,p),ep,rfl⟩
  · exact hm _ (rup_row_mem F.db5 t.s.cmds _ hr.2.1)
  · cases pol
    · exact horig _ (F.row3g_mem g p h _ hg hp hh (F.bitX_lt hk bit hb))
    · exact horig _ (F.row3g'_mem g p h _ hg hp hh (F.bitX_lt hk bit hb))
  · cases pol
    · exact hm _ vrows.2.1
    · exact hm _ vrows.2.2.1
  · cases pol
    · exact horig _ (F.row3g'_mem g p h _ hg hp hh (F.bitY_lt hk bit hb))
    · exact horig _ (F.row3g_mem g p h _ hg hp hh (F.bitY_lt hk bit hb))
  · cases pol
    · exact hm _ qrows.1
    · exact hm _ qrows.2.2.2

/-- All selector cases j>0, with the actual finite gate order deciding whether
    j is a primary input or a predecessor. The earlier roots are exposed as
    GateRecord, not arbitrary refutations of the current goal. -/
theorem selected_wire_from_database (hk : 2≤F.k) (hs : 1≤F.s)
    (t : StI F.V) (ht : F.Good3 t) (g p j bit cb q : Nat)
    (hg : g<F.s) (hp : p<2) (hj1 : 1≤j) (hj : j<F.k+g) (hb : bit<2)
    (hc : 1≤cb) (hq : 1≤q)
    (hr : ∀h<g,F.GateRecord bit cb h t)
    (heq : Cmd.eqDef q (F.port g p (F.bitX bit) : Int) (F.port g p (F.bitY bit) : Int)∈t.s.cmds)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hm : ∀R∈exec F.db5 t.s.cmds,R∈D) (pol : Bool) :
    Refutation (D ++ [negate (clauseRow
      (F.wireLeaf g p j (F.bitX bit) t.s.A cb (t.s.live g) q pol)).toE]) := by
  by_cases hjk : j<F.k
  · have hA := ht.2.2.2.2.2.1
    have hl := F.live_bound_of_good3 ht g hg
    have eqs := eqDef_rows F.db5 t.s.cmds _ _ _ heq
    apply F.input_wire_leaf g p j (F.bitX bit) (F.bitY bit) t.s.A cb (t.s.live g) q pol
      (F.inputBit j (F.bitX bit)) (by omega) hc (by omega) hq rfl
      (F.inputBit_bitY_j hk bit j hj1 hjk) D hD
    · exact hm _ (exec_mono _ _ _ (F.original_mem_db5 _
        (F.row3i_mem g p j _ hg hp hjk (F.bitX_lt hk bit hb))))
    · exact hm _ (exec_mono _ _ _ (F.original_mem_db5 _
        (F.row3i_mem g p j _ hg hp hjk (F.bitY_lt hk bit hb))))
    · cases pol
      · exact hm _ eqs.1
      · exact hm _ eqs.2.2.2
  · have he : j=F.k+(j-F.k) := by omega
    rw [he]
    exact F.predecessor_from_database hk hs t ht g p (j-F.k) bit cb q hg hp (by omega) hb hc hq
      (hr _ (by omega)) heq D hD hm pol

#print axioms predecessor_from_database
#print axioms selected_wire_from_database
end L3.Fam

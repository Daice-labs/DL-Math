import FirstGatePins
import FirstValueCore
namespace L3Emitter.FirstCofactorRows
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL CofactorValueRows

def signed (b:Bool) (v:Bit):Bit:=⟨sign b v,sign_valid b v⟩
def port (n:Nat) (hn:2≤n) (p x:Nat):=EarlierPortValues.portValue n hn 0 p x
def B (n:Nat) (hn:2≤n):=(PrimaryAliasBank.cfg n hn).B
def d (n x:Nat):=RemainingInput.value n 1 x
def portRow (n:Nat) (hn:2≤n) (x:Nat) (b:Bool):=clause [-sign b (B n hn),sign b (port n hn 0 x)]
def unitRow (n:Nat) (hn:2≤n) (x:Nat):=clause [sign (d n x) (port n hn 1 x)]
def portTape (n:Nat) (hn:2≤n) (x:Nat) (b:Bool) (D:List Row):=
  CommonGuardResolve.tape D [] [] [-sign b (B n hn),sign b (port n hn 0 x)] (FirstGatePins.sel n hn 0).val
def unitTape (n:Nat) (hn:2≤n) (x:Nat) (D:List Row):=
  CommonGuardResolve.tape D [] [] [sign (d n x) (port n hn 1 x)] (FirstGatePins.sel n hn 1).val

theorem port_check (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n) (b:Bool)
    (D:List Row) (hd:∀R∈SharedValueBank.result n hn,R∈D) (hp:FirstGatePins.row n hn 0∈D):
    polEval (dbOf D) (portTape n hn x b D) []=some (portRow n hn x b):=by
  apply CommonGuardResolve.checks D [] [] _ _ (by simp [Valid]) (by simp [Valid])
    (by simp [Valid,sign_valid]) (FirstGatePins.sel n hn 0).property hp
  exact hd _ (SharedValueBank.gamma_retained n hn _ (PrimaryInputLinks.zero_present n hn 0 0 x (by omega) (by decide) hx b))

theorem unit_check (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n)
    (D:List Row) (hd:∀R∈SharedValueBank.result n hn,R∈D) (hp:FirstGatePins.row n hn 1∈D):
    polEval (dbOf D) (unitTape n hn x D) []=some (unitRow n hn x):=by
  apply CommonGuardResolve.checks D [] [] _ _ (by simp [Valid]) (by simp [Valid])
    (by simp [Valid,sign_valid]) (FirstGatePins.sel n hn 1).property hp
  exact hd _ (SharedValueBank.gamma_retained n hn _
    (PrimaryInputLinks.remaining_present n hn 0 1 1 x (by omega) (by decide) (by decide) (by omega) hx))

def rows (n:Nat) (hn:2≤n) (x:Nat):=[portRow n hn x false,portRow n hn x true,unitRow n hn x]
def program (n:Nat) (hn:2≤n) (x:Nat) (D:List Row):Program:=
  [(portRow n hn x false,portTape n hn x false D),(portRow n hn x true,portTape n hn x true D),
   (unitRow n hn x,unitTape n hn x D)]
theorem checks (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n)
    (D:List Row) (hd:∀R∈SharedValueBank.result n hn,R∈D) (hp:∀p,p<2→FirstGatePins.row n hn p∈D):
    check D (program n hn x D)=some (D++rows n hn x):=by
  apply IndependentProgram.check_base
  intro cmd hc
  simp only [program,List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl|rfl|rfl
  · exact port_check n hn x hx false D hd (hp 0 (by decide))
  · exact port_check n hn x hx true D hd (hp 0 (by decide))
  · exact unit_check n hn x hx D hd (hp 1 (by decide))

theorem semantics (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n) (a b v:Bool):
    clause [-sign a (port n hn 0 x),-sign b (port n hn 1 x),sign v (cofactor n hn 0 x),
      -sign v ((PrimaryAliasBank.cfg n hn).fn 0 a b)]∈SharedValueBank.result n hn:=by
  have hm:CofactorSemantics.goal n (3*(n+1)-4) (ConstantCofactor.offset n hn) 0 x a b (!v)∈ConstantCofactor.result n hn:=by
    apply List.mem_append_right
    apply List.mem_map.mpr
    refine ⟨(0,x,a,b,!v),?_,rfl⟩
    simp [CofactorSection.jobs,hx,show 0<3*(n+1)-4 by omega]
    cases a <;> cases b <;> cases v <;> simp <;> omega
  have hh:=SharedValueBank.gamma_retained n hn _ (PrimaryInputLinks.primary_keep n hn _
    (show _∈PrimaryBank.result n hn from List.mem_append_left _ (List.mem_append_left _ hm)))
  have he:CofactorSemantics.goal n (3*(n+1)-4) (ConstantCofactor.offset n hn) 0 x a b (!v)=
      clause [-sign a (port n hn 0 x),-sign b (port n hn 1 x),sign v (cofactor n hn 0 x),
      -sign v ((PrimaryAliasBank.cfg n hn).fn 0 a b)]:=by
    cases a <;> cases b <;> cases v <;>
      simp only [CofactorSemantics.goal,CofactorSemantics.fnLiteral,REDWitness.output,port,EarlierPortValues.portValue,
        cofactor,sign,Bool.not_false,Bool.not_true,Bool.false_eq_true,↓reduceIte,neg_neg]
    all_goals rfl
  exact he ▸ hh

#print axioms checks
#print axioms semantics
end L3Emitter.FirstCofactorRows

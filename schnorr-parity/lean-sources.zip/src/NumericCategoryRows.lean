import NumericInitialSources
namespace L3Emitter.NumericCategoryRows
open EREF EREF.GeneralRED REDWitness AliasNetwork NumericNetwork GateCategories CategoryPrograms

theorem choices (n:Nat) (hn:2≤n):∀c∈CategoryPrograms.choices n hn,c.lit.natAbs≤NumericValueClosed.bound n:=by
  intro c hc
  have h:=NumericRankRows.choices (n+1) (by omega) c hc
  have hconst:ConstantConstruction.C (n+1) (by omega)≤NumericAliasSource.bound n hn:=by
    unfold NumericAliasSource.bound NumericCofactorNamespace.cap ConstantCofactor.offset;omega
  exact h.trans (hconst.trans (NumericValueClosed.raw_bound n hn))

theorem bit_bound (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4)
    (q:Category) (hq:q∈cats n):BitBound (NumericValueClosed.bound n) (bit n hn g q):=by
  have hc:=NumericValueClosed.config n hn
  cases q with
  | beta=>exact hc.beta g hg
  | gamma=>exact hc.gamma g hg
  | rank t=>
    have ht:t<RankConstruction.width (n+1):=by simpa[cats,categories,RankConstruction.width] using hq
    exact hc.rank g hg t (by unfold AliasAssembly.width;omega)

theorem vars_bound (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4):
    ∀l∈vars n hn g,l.natAbs≤NumericValueClosed.bound n:=by
  intro l hl;obtain ⟨q,hq,rfl⟩:=List.mem_map.mp hl
  exact bit_bound n hn g hg q hq

theorem rows (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4):
    RowSupport.Bounded (NumericValueClosed.bound n) (CategoryPrograms.rows n hn g):=by
  apply RowSupport.append
  · apply RowSupport.append _ _ _ (NumericRankRows.alo _ _ _ _ (choices n hn) (vars_bound n hn g hg))
    exact NumericForcingFields.clause_rows _ _ (vars_bound n hn g hg)
  · intro R hR;obtain ⟨p,hp,hR⟩:=List.mem_flatMap.mp hR
    obtain ⟨q,hq,hp⟩:=List.mem_flatMap.mp hp
    obtain ⟨r,hr,he⟩:=List.mem_filterMap.mp hp
    split at he
    · cases Option.some.inj he
      have hbq:=bit_bound n hn g hg q hq
      have hbr:=bit_bound n hn g hg r hr
      apply RowSupport.append _ _ _ (NumericRankRows.pair _ _ _ _ _ _ (choices n hn) hbq hbr) ?_ R hR
      apply NumericForcingFields.clause_rows
      intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
      rcases hl with rfl|rfl <;> simpa[value] using (by assumption : BitBound (NumericValueClosed.bound n) _)
    · contradiction

theorem result (n:Nat) (hn:2≤n):RowSupport.Bounded (NumericValueClosed.bound n) (CategoryBank.result n hn):=by
  apply RowSupport.append _ _ _ (NumericInitialSources.first n hn)
  intro R hR;obtain ⟨g,hg,hR⟩:=List.mem_flatMap.mp hR
  obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hg
  exact rows n hn (j+1) (by have:=List.mem_range.mp hj;omega) R hR
#print axioms result
end L3Emitter.NumericCategoryRows

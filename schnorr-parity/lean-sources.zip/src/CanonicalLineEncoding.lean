import CanonicalFileGrammar

set_option linter.unusedSimpArgs false
namespace L3Emitter.CanonicalLineEncoding
open EREF EREF.GeneralRED CanonicalByteFraming CanonicalScopedBytes CanonicalScopeKernel
open CanonicalLineParser CanonicalFileGrammar TemplateBytes

/-- The serializer cannot smuggle a line boundary into any operand. -/
theorem token_no_newline (t : Tok) : (10:UInt8)∉emit (polToken (CompactTapeBytes.token t)) := by
  cases t with
  | ref i=>simpa [CompactTapeBytes.token,polToken,integer,emit,number,Piece.emit,show ¬(i:Int)<0 by omega] using
      decimal_avoids i 10 (Or.inl (by decide))
  | lit l=>exact literal_avoids _ 10 (Or.inl (by decide)) (by decide) (by decide)
  | add=>decide
  | sat=>decide
  | mul i=>
    simp only [CompactTapeBytes.token,polToken,emit_append,List.mem_append,not_or]
    exact ⟨by simpa [emit,number,Piece.emit] using decimal_avoids i 10 (Or.inl (by decide)),by decide⟩
  | div i=>
    simp only [CompactTapeBytes.token,polToken,emit_append,List.mem_append,not_or]
    exact ⟨by simpa [emit,number,Piece.emit] using decimal_avoids i 10 (Or.inl (by decide)),by decide⟩

theorem operands_no_newline (ts : List Tok) : (10:UInt8)∉emit (operands ts) := by
  apply separated_avoids
  · decide
  · intro d hd
    obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hd
    exact token_no_newline t

theorem key_no_newline (k : GoalKey) : (10:UInt8)∉emit (CanonicalWireFamily.keyDoc k) := by
  cases k with
  | candidate=>decide
  | database i=>simpa [CanonicalWireFamily.keyDoc,emit,number,Piece.emit] using decimal_avoids i 10 (Or.inl (by decide))

theorem line_no_newline (e : Event) : (10:UInt8)∉line e := by
  cases e with
  | pol ts=>
    simp only [line,List.mem_append,not_or]
    exact ⟨⟨by decide,operands_no_newline ts⟩,by decide⟩
  | pbc R=>
    simp only [line,List.mem_append,not_or]
    exact ⟨⟨by decide,row_avoids (pbRow R) 10 (Or.inl rfl)⟩,by decide⟩
  | red R w=>
    simp only [line,List.mem_append,not_or]
    exact ⟨⟨⟨⟨by decide,row_avoids (pbRow R) 10 (Or.inl rfl)⟩,by decide⟩,
      witness_avoids w 10 (Or.inl rfl)⟩,by decide⟩
  | goal key=>
    simp only [line,List.mem_append,not_or]
    exact ⟨by decide,key_no_newline key⟩
  | close i=>
    simp only [line,List.mem_append,not_or]
    exact ⟨⟨by decide,decimal_avoids i 10 (Or.inl (by decide))⟩,by decide⟩
  | endRed=>decide

def eventBytes (es : List Event) := joinLines (es.map line)

theorem eventBytes_append (a b : List Event) : eventBytes (a++b)=eventBytes a++eventBytes b := by
  simp [eventBytes,joinLines]

theorem eventBytes_cons (e : Event) (es : List Event) :
    eventBytes (e::es)=line e++[10]++eventBytes es := rfl

theorem emit_fixed (s : String) : emit (fixed s)=ascii s := by simp [emit,fixed,Piece.emit]

theorem pol_bytes (ts : List Tok) : emit (CompactTapeBytes.line ts)=line (.pol ts)++[10] := by
  simp only [CompactTapeBytes.line,command,emit_append,emit_fixed,List.map_map,Function.comp_def,line,operands]
  rw [show ascii " ;\n"=ascii " ;"++[10] by decide]
  simp only [List.append_assoc]

theorem tapes_bytes (ts : List (List Tok)) : emit (tapesDoc ts)=eventBytes (ts.map Event.pol) := by
  induction ts with
  | nil=>rfl
  | cons t ts ih=>
    change emit (CompactTapeBytes.line t++tapesDoc ts)=eventBytes (Event.pol t::ts.map Event.pol)
    rw [emit_append,pol_bytes,ih,eventBytes_cons]

theorem close_bytes (i : Nat) : emit (closeDoc i)=line (.close i)++[10] := by
  simp only [closeDoc,emit_append,emit_fixed,line]
  have he:emit (number i)=decimal i:=by simp [emit,number,Piece.emit]
  rw [he,show ascii " ;\n"=ascii " ;"++[10] by decide]
  simp only [List.append_assoc]

theorem local_bytes (p : LocalProof) :
    emit (tapesDoc p.tapes++closeDoc p.conclusion)=eventBytes (localEvents p) := by
  simp only [emit_append,tapes_bytes,close_bytes,localEvents,eventBytes_append,eventBytes_cons]
  simp only [show eventBytes []=[] from rfl,List.append_nil]

theorem goal_bytes (g : Goal) : emit (CanonicalWireFamily.goalDoc g)=eventBytes (goalEvents g) := by
  simp only [CanonicalWireFamily.goalDoc,emit_append,emit_fixed,goalEvents,eventBytes_cons,line]
  rw [show ascii "\n"=([10]:Bytes) by decide]
  rw [←local_bytes]
  simp only [emit_append,List.append_assoc]

theorem goals_bytes (gs : List Goal) :
    emit (gs.flatMap CanonicalWireFamily.goalDoc)=eventBytes (gs.flatMap goalEvents) := by
  induction gs with
  | nil=>rfl
  | cons g gs ih=>simp only [List.flatMap_cons,emit_append,goal_bytes,eventBytes_append,ih]

theorem command_bytes (c : CanonicalScopeKernel.Command) :
    emit (CanonicalWireFamily.commandDoc c)=eventBytes (commandEvents c) := by
  cases c with
  | pol ts=>simpa [commandEvents,eventBytes,joinLines] using pol_bytes ts
  | consequence R p=>
    simp only [CanonicalWireFamily.commandDoc,emit_append,emit_fixed,commandEvents,eventBytes_cons,line]
    rw [show ascii " : subproof\n"=ascii " : subproof"++[10] by decide,←local_bytes]
    simp only [emit_append,List.append_assoc]
  | red R w gs=>
    simp only [CanonicalWireFamily.commandDoc,emit_append,emit_fixed,commandEvents,
      List.cons_append,eventBytes_cons,line,eventBytes_append,goals_bytes]
    rw [show ascii " : subproof\n"=ascii " : subproof"++[10] by decide,
      show ascii "qed ;\n"=ascii "qed ;"++[10] by decide]
    simp only [show eventBytes []=[] from rfl,List.append_nil,List.append_assoc]

theorem commands_bytes (cs : List CanonicalScopeKernel.Command) :
    emit (cs.flatMap CanonicalWireFamily.commandDoc)=eventBytes (cs.flatMap commandEvents) := by
  induction cs with
  | nil=>rfl
  | cons c cs ih=>simp only [List.flatMap_cons,emit_append,command_bytes,eventBytes_append,ih]

#print axioms line_no_newline
#print axioms commands_bytes
end L3Emitter.CanonicalLineEncoding

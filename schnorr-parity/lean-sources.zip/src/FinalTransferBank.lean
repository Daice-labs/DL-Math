import FinalTransferSeed
namespace L3Emitter.FinalTransferBank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram
open FinalOutputDefinitions FinalTransferContext
abbrev Job (n:Nat):=Fin 2×Fin (W n-1)×Fin (T n)×Bool
def jobs (n:Nat):List (Job n):=(List.finRange 2).flatMap fun p=>(List.finRange (W n-1)).flatMap fun i=>(List.finRange (T n)).flatMap fun x=>[false,true].map fun b=>(p,i,x,b)
def finalRow (n:Nat) (hn:2≤n) (j:Job n):=TransferMuxPOL.row (targetSelector n hn j.1 j.2.1) (value n hn j.2.1 j.2.2.1) (targetPort n hn j.1 j.2.2.1) j.2.2.2
def rows (n:Nat) (hn:2≤n) (j:Job n):List Row:=
  FinalTransferSeed.rows n hn j.1 j.2.1 j.2.2.1 j.2.2.2++
  TransferMuxPOL.caseRows (H n hn) (targetSelector n hn j.1 j.2.1) (value n hn j.2.1 j.2.2.1) (targetPort n hn j.1 j.2.2.1) j.2.2.2++[finalRow n hn j]
def leaf (n:Nat) (hn:2≤n) (j:Job n) (E:List Row):Program:=
  FinalTransferSeed.program n hn j.1 j.2.1 j.2.2.1 j.2.2.2 E++
  TransferMuxPOL.program (E++FinalTransferSeed.rows n hn j.1 j.2.1 j.2.2.1 j.2.2.2)
    (H n hn) (rawSelector n hn j.1 j.2.1) (altSelector n hn j.1 j.2.1) (value n hn j.2.1 j.2.2.1)
    (rawPort n hn j.1 j.2.2.1) (altPort n hn j.1 j.2.2.1) (targetSelector n hn j.1 j.2.1) (targetPort n hn j.1 j.2.2.1) j.2.2.2

theorem leaf_check (n:Nat) (hn:2≤n) (j:Job n) (E:List Row) (he:∀R∈D n hn,R∈E):
    check E (leaf n hn j E)=some (E++rows n hn j):=by
  obtain ⟨p,i,x,b⟩:=j
  have h0:=FinalTransferSeed.checks n hn p i x b E he
  have h1:=TransferMuxPOL.program_check (E++FinalTransferSeed.rows n hn p i x b)
    (H n hn) (rawSelector n hn p i) (altSelector n hn p i) (value n hn i x)
    (rawPort n hn p x) (altPort n hn p x) (targetSelector n hn p i) (targetPort n hn p x) b
    (List.mem_append_left _ (he _ (raw_row n hn p i x b)))
    (List.mem_append_right _ (FinalTransferSeed.contains n hn p i x b))
    (fun t=>⟨List.mem_append_left _ (he _ (raw_relations n hn p i x t).1),List.mem_append_left _ (he _ (raw_relations n hn p i x t).2)⟩)
    (fun t=>⟨List.mem_append_left _ (he _ (alt_relations n hn p i x t).1),List.mem_append_left _ (he _ (alt_relations n hn p i x t).2)⟩)
  simpa only [leaf,rows,finalRow,TransferMuxPOL.result,List.append_assoc] using check_append _ _ _ _ _ h0 h1

def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n) (D n hn)
def result (n:Nat) (hn:2≤n):=D n hn++RetainedBlockFold.body (rows n hn) (jobs n)
theorem checks (n:Nat) (hn:2≤n):check (D n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (fun _=>True) (fun j _=>leaf_check n hn j) _ (by simp) _ (fun _ h=>h)
theorem original_to_replacement_transfers (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalOutputLinks.original_to_output_links n hn) (check_trace _ _ _ (checks n hn))
theorem job_mem (n:Nat) (j:Job n):j∈jobs n:=by
  obtain ⟨p,i,x,b⟩:=j
  cases b <;> simp [jobs]
theorem contains (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)) (b:Bool):
    TransferMuxPOL.row (targetSelector n hn p i) (value n hn i x) (targetPort n hn p x) b∈result n hn:=
  List.mem_append_right _ (RetainedBlockFold.contains (rows n hn) (jobs n) (p,i,x,b) (job_mem n _) _ (List.mem_append_right _ (List.mem_singleton_self _)))
theorem retained (n:Nat) (hn:2≤n):∀R∈D n hn,R∈result n hn:=fun _ h=>List.mem_append_left _ h
#print axioms original_to_replacement_transfers
#print axioms contains
end L3Emitter.FinalTransferBank

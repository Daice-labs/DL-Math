import CanonicalReplayEnvelope

namespace L3Emitter.CanonicalAllocationBound
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation AuditLocalCosts RecordedReplayCost

theorem step_certificates (M guard : Nat) (D : List Row) (c : Step)
    (h : c.accepts M guard D=true) : (certificates c).length≤D.length+1 := by
  cases c with
  | pol R ts=>simp [certificates]
  | consequence R p=>simp [certificates]
  | red R w ps=>
    have hg:=goals_length D R w (R::D) ps (Bool.and_eq_true_iff.mp h).2
    simpa only [certificates,List.length_cons] using hg.le

/-- Includes every candidate and retained-frame goal, even with duplicate rows. -/
theorem certificate_count (M guard : Nat) (D E : List Row) (p : Program)
    (h : check M guard D p=some E) : certCount p≤p.length*(D.length+p.length) := by
  induction p generalizing D with
  | nil=>simp [certCount,allCertificates]
  | cons c cs ih=>
    simp only [check] at h
    split at h
    · rename_i hc
      have hh:=step_certificates M guard D c hc
      have ht:=ih (D++[c.row]) h
      rw [certs_cons]
      simp only [List.length_append,List.length_cons,List.length_nil] at *
      nlinarith
    · contradiction

theorem checked_rows_tokens (D E : List Row) (p : AliasProgram.Program)
    (h : AliasProgram.check D p=some E) : p.length≤(p.map (fun c=>c.2.length)).sum := by
  induction p generalizing D with
  | nil=>simp
  | cons c cs ih=>
    simp only [AliasProgram.check] at h
    split at h
    · rename_i hp
      have ht:=ih (D++[c.1]) h
      have hn:0<c.2.length:=by
        by_contra hz
        have he:c.2=[]:=List.length_eq_zero_iff.mp (by omega)
        simp [he,polEval] at hp
      simp only [List.length_cons,List.map_cons,List.sum_cons]
      omega
    · contradiction

theorem certificate_rows_tokens (D : List Row) (p : Certificate)
    (h : accepts D p=true) : p.program.length≤tokens p := by
  unfold accepts at h
  split at h
  · contradiction
  · rename_i E he
    exact checked_rows_tokens D E p.program he

theorem goals_rows_tokens (D : List Row) (C : Row) (w : FiniteWitness.Data)
    (rs : List Row) (ps : List Certificate) (h : checkGoals D C w rs ps=true) :
    (ps.map (fun p=>p.program.length)).sum≤(ps.map tokens).sum := by
  induction rs generalizing ps with
  | nil=>cases ps <;> simp_all [checkGoals]
  | cons R rs ih=>
    cases ps with
    | nil=>simp [checkGoals] at h
    | cons p ps=>
      obtain ⟨hh,ht⟩:=Bool.and_eq_true_iff.mp h
      have hp:=certificate_rows_tokens _ p hh
      have hi:=ih ps ht
      simp only [List.map_cons,List.sum_cons]
      omega

theorem step_rows_tokens (M guard : Nat) (D : List Row) (c : Step)
    (h : c.accepts M guard D=true) : localRows c≤localTokens c := by
  cases c with
  | pol R ts=>rfl
  | consequence R p=>
    simpa [localRows,localTokens,certificates] using certificate_rows_tokens _ p (Bool.and_eq_true_iff.mp h).2
  | red R w ps=>exact goals_rows_tokens D R w (R::D) ps (Bool.and_eq_true_iff.mp h).2

theorem program_rows_tokens (M guard : Nat) (D E : List Row) (p : Program)
    (h : check M guard D p=some E) : localRowCount p≤localTokenCount p := by
  induction p generalizing D with
  | nil=>rfl
  | cons c cs ih=>
    simp only [check] at h
    split at h
    · rename_i hc
      have hh:=step_rows_tokens M guard D c hc
      have ht:=ih (D++[c.row]) h
      rw [rows_cons,tokens_cons]
      omega
    · contradiction

theorem reds_le (p : Program) : redCount p≤p.length := by
  induction p with
  | nil=>rfl
  | cons c cs ih=>cases c <;> simp_all [redCount] <;> omega

/-- Upper bound on physical row ALLOCATIONS, including deleted rows. P is the
main-command count; B bounds POL TOKENS in each local certificate. These
constructor-dependent quantities still need closed bounds in n. -/
theorem allocations_bound (M guard B : Nat) (D E : List Row) (p : Program)
    (h : check M guard D p=some E) (hb : CanonicalReplayEnvelope.BoundedProgram B p) :
    NativeRecordedAllocation.program p≤2*p.length+p.length*(D.length+p.length)*(B+1) := by
  rw [allocations]
  have hc:=certificate_count M guard D E p h
  have hr:=program_rows_tokens M guard D E p h
  have ht:=CanonicalReplayEnvelope.total_tokens B p hb
  have hd:=reds_le p
  nlinarith

theorem family_allocation_bound (n B : Nat) (hn : 2≤n)
    (hb : CanonicalReplayEnvelope.BoundedProgram B (RecordedUniformFamily.emitter n)) :
    NativeRecordedAllocation.program (RecordedUniformFamily.emitter n)≤
      2*(RecordedUniformFamily.emitter n).length+
      (RecordedUniformFamily.emitter n).length*
      ((OriginalEncoding.rows n (3*n-4)).length+(RecordedUniformFamily.emitter n).length)*(B+1) :=
  allocations_bound 0 (RecordedUniformFamily.guard n) B _ _ _
    (RecordedUniformFamily.recorded_refutation n hn).1 hb

#print axioms certificate_count
#print axioms certificate_rows_tokens
#print axioms program_rows_tokens
#print axioms allocations_bound
#print axioms family_allocation_bound
end L3Emitter.CanonicalAllocationBound

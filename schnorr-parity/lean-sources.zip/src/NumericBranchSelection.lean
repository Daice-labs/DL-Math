import NumericPriority
import NumericFrontendComplete
import RecordedBranchSelection
namespace L3Emitter.NumericBranchSelection
open EREF EREF.GeneralRED FieldLengthsFromIDs RecordedOperandFields

def bound (k:Nat):Nat:=NumericFrontendComplete.bound k (3*k-4)+1100*FrontendNamespaceEnvelope.scale k+26

theorem program (k:Nat) (hk:3≤k):
 ∀c∈RecordedBranchSelection.program k hk,Content (bound k) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · rcases List.mem_append.mp hc with hc|hc
   · exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c
       (NumericFrontendComplete.program k (3*k-4) (by omega) (by omega) c hc)
   · obtain rfl:=List.mem_singleton.mp hc
     intro t ht;simp only [FrontendSelection.coverageTokens,PriorityReach.finishTokens,
       List.mem_cons,List.not_mem_nil,or_false] at ht
     rcases ht with rfl|rfl|rfl <;> trivial
 · apply NumericPriority.program (bound k) (FrontendSelection.front k hk).s.var _ _
     ((FableEncoding.fam k (3*k-4)).branchList_bounded (FrontendSelection.prior k hk)) ?_ ?_ c hc
   · have h:=FrontendNamespaceEnvelope.forcing_ceiling k hk
     change (FrontendSelection.front k hk).s.var+1+2*(FrontendSelection.xs k hk).length≤1100*FrontendNamespaceEnvelope.scale k at h
     unfold FrontendSelection.xs at h
     unfold bound;omega
   · unfold bound;omega
#print axioms program
end L3Emitter.NumericBranchSelection

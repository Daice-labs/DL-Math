import CanonicalPOLParser

namespace L3Emitter.CanonicalByteFraming
open EREF CanonicalRowParser TemplateBytes CanonicalScopedBytes

/-- Check fixed byte framing and recover the middle. No expected middle is
supplied by the caller. -/
def strip (head tail bs : Bytes) : Option Bytes :=
  let middle:=(bs.drop head.length).take (bs.length-head.length-tail.length)
  if bs=head++middle++tail then some middle else none

theorem strip_roundtrip (head middle tail : Bytes) :
    strip head tail (head++middle++tail)=some middle := by
  simp [strip,List.append_assoc]

/-- ASCII decimal output contains only bytes 48 through 57. -/
theorem decimal_avoids (n : Nat) (b : UInt8) (hb : b.toNat<48 ∨ 57<b.toNat) :
    b∉decimal n := by
  intro h
  obtain ⟨c,hc,he⟩:=List.mem_map.mp h
  have hd:=Nat.isDigit_of_mem_toDigits (by decide : 0<10) (by decide : 10≤10) hc
  have hr:48≤c.toNat ∧ c.toNat≤57:=by
    simpa only [Char.isDigit,Bool.and_eq_true,decide_eq_true_eq] using hd
  have hh:=congrArg UInt8.toNat he
  rw [UInt8.toNat_ofNat',Nat.mod_eq_of_lt (by omega)] at hh
  omega

theorem literal_avoids (l : Literal) (b : UInt8)
    (hb : b.toNat<48 ∨ 57<b.toNat) (hx : b≠120) (ht : b≠126) :
    b∉emit (literal l) := by
  rw [LiteralParser.encoded]
  cases l.negative <;> simp [hx,ht,decimal_avoids _ _ hb]

theorem integer_avoids (z : Int) (b : UInt8)
    (hb : b.toNat<48 ∨ 57<b.toNat) (hm : b≠45) : b∉emit (integer z) := by
  unfold integer
  split
  · have he:emit (fixed "-")=([45]:Bytes):=rfl
    simp only [emit_append,he,List.mem_append,List.mem_cons,List.not_mem_nil,or_false]
    simpa [emit,number,Piece.emit] using And.intro hm (decimal_avoids z.natAbs b hb)
  · simpa [emit,number,Piece.emit] using decimal_avoids z.natAbs b hb

theorem separated_avoids (sep : Doc) (ds : List Doc) (b : UInt8)
    (hs : b∉emit sep) (hd : ∀ d∈ds,b∉emit d) : b∉emit (separated sep ds) := by
  induction ds with
  | nil=>simp [separated,emit]
  | cons d ds ih=>
    cases ds with
    | nil=>simpa [separated] using hd d (by simp)
    | cons e es=>
      have hi:=ih (by intro x hx;exact hd x (by simp [hx]))
      have hh:=hd d (by simp)
      have he:separated sep (d::e::es)=d++sep++separated sep (e::es):=by
        simp [separated,List.append_assoc]
      rw [he]
      simpa only [emit_append,List.mem_append,not_or] using And.intro (And.intro hh hs) hi

/-- Both delimiters used by the line/file parser are absent from field bytes. -/
def Delimiter (b : UInt8) : Prop := b=10 ∨ b=58

theorem row_avoids (r : PBRow) (b : UInt8) (hb : Delimiter b) : b∉emit (row r) := by
  have hn:b.toNat<48 ∨ 57<b.toNat:=by rcases hb with rfl|rfl <;> decide
  have hx:b≠120 ∧ b≠126 ∧ b≠45:=by rcases hb with rfl|rfl <;> decide
  have hspace:b∉emit (fixed " "):=by rcases hb with rfl|rfl <;> decide
  have hrel:b∉emit (fixed " >= "):=by rcases hb with rfl|rfl <;> decide
  have hs:=separated_avoids (fixed " ")
    (r.terms.map (fun t=>number t.1++fixed " "++literal t.2)) b hspace (by
      intro d hd
      obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hd
      simp only [emit_append,List.mem_append,not_or]
      exact ⟨⟨by simpa [emit,number,Piece.emit] using decimal_avoids t.1 b hn,hspace⟩,
        literal_avoids t.2 b hn hx.1 hx.2.1⟩)
  simpa only [row,emit_append,List.mem_append,not_or] using
    And.intro (And.intro hs hrel) (integer_avoids r.rhs b hn hx.2.2)

theorem witness_avoids (w : FiniteWitness.Data) (b : UInt8) (hb : Delimiter b) :
    b∉emit (witness w) := by
  have hn:b.toNat<48 ∨ 57<b.toNat:=by rcases hb with rfl|rfl <;> decide
  have hx:b≠120 ∧ b≠126:=by rcases hb with rfl|rfl <;> decide
  apply separated_avoids
  · rcases hb with rfl|rfl <;> decide
  · intro d hd
    obtain ⟨e,he,rfl⟩:=List.mem_map.mp hd
    simp only [emit_append,List.mem_append,not_or]
    refine ⟨⟨literal_avoids _ b hn hx.1 hx.2,?_⟩,?_⟩
    · rcases hb with rfl|rfl <;> decide
    · cases e.2 with
      | bit v=>simpa [image,emit,number,Piece.emit] using decimal_avoids (if v then 1 else 0) b hn
      | lit l=>exact literal_avoids l b hn hx.1 hx.2

/-- Remove a single canonical line ending and split all actual bytes into
lines. The final empty split is retained and checked by the file parser. -/
def fileLines (bs : Bytes) := bs.splitOn 10

def joinLines (ls : List Bytes) : Bytes := ls.flatMap (fun l=>l++[10])

theorem split_lines (ls : List Bytes) (hn : ∀ l∈ls,(10:UInt8)∉l) :
    fileLines (joinLines ls)=ls++[[]] := by
  induction ls with
  | nil=>rfl
  | cons l ls ih=>
    have hl:=hn l (by simp)
    have hi:=ih (by intro x hx;exact hn x (by simp [hx]))
    simp only [joinLines,List.flatMap_cons,List.append_assoc,List.singleton_append,fileLines]
    change (l++10::joinLines ls).splitOn 10=_
    rw [List.splitOn_append_cons_self,List.splitOn_eq_singleton hl]
    simpa only [fileLines,List.cons_append,List.nil_append] using congrArg (l::·) hi

#print axioms strip_roundtrip
#print axioms row_avoids
#print axioms witness_avoids
#print axioms split_lines
end L3Emitter.CanonicalByteFraming

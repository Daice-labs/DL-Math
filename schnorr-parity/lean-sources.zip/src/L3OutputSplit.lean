import L3OutputLeaves
import L3FrontendT2

namespace L3
open EREF EREF.GeneralRED
namespace Fam
variable (F : Fam)

def outputC (t : StI F.V) (p b : Nat) : List Int :=
  [-(F.sel (F.s-1) p 0 : Int), -(t.s.eqrow (F.s-1) p b : Int)]
def outputVs (p b : Nat) : List Int :=
  [(F.port (F.s-1) (1-p) (F.outX b) : Int),
   (F.port (F.s-1) (1-p) (F.outY b) : Int)]

theorem original_mem_db5 (r : Row) (hr : r∈F.rows) : r.toE∈F.db5 := by
  exact List.mem_append_left _ (List.mem_append_left _
    (F.db2_sub_db3 _ (F.toE_mem_db2 F.k r hr)))

theorem output_bounds (hk : 2 ≤ F.k) (hs : 2 ≤ F.s) (t : StI F.V)
    (h : F.Good3 t) (p b : Nat) (hp : p<2) (hb : b<2) :
    Bounded t.s.var (F.outputC t p b) ∧ Bounded t.s.var (F.outputVs p b) := by
  have he0 := (h.2.2.1 (F.s-1) p (by omega) (by omega) hp).1
  have he1 := (h.2.2.1 (F.s-1) p (by omega) (by omega) hp).2.1
  have he : F.PEq (F.s-1) p b t := by
    rcases (by omega : b=0 ∨ b=1) with rfl | rfl
    · exact he0
    · exact he1
  have hV := t.var_ge
  have hsel := F.sel_le_S (F.s-1) p 0 (by omega) (by omega) (by omega)
  have hselpos := F.sel_pos (F.s-1) p 0
  have hS := F.S_le_V
  have hpx := F.port_le (F.s-1) (1-p) (F.outX b) (by omega) (by omega) (F.outX_lt hk b hb)
  have hpy := F.port_le (F.s-1) (1-p) (F.outY b) (by omega) (by omega) (F.outY_lt hk b hb)
  have hpxpos := F.port_pos (F.s-1) (1-p) (F.outX b)
  have hpypos := F.port_pos (F.s-1) (1-p) (F.outY b)
  have hP := F.port_bound_le_V
  have heL := he.2.1
  have heU := he.2.2
  constructor
  · intro l hl
    simp only [outputC,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> omega
  · intro l hl
    simp only [outputVs,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> omega

/-- Every T6a leaf is refuted from original rows and the actual EQ definition. -/
theorem output_split_leaves (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (hpar : F.b = parityBit) (t : StI F.V) (h : F.Good3 t)
    (p b : Nat) (hp : p<2) (hb : b<2)
    (D : List EREF.Row) (hD : ∀ R∈D, Canonical R)
    (hmem : ∀ R∈exec F.db5 t.s.cmds, R∈D) :
    ∀ lf∈leaves (F.outputC t p b) (F.outputVs p b),
      Refutation (D ++ [negate (clauseRow lf).toE]) := by
  have he : F.PEq (F.s-1) p b t := by
    have hg := h.2.2.1 (F.s-1) p (by omega) (by omega) hp
    rcases (by omega : b=0 ∨ b=1) with rfl | rfl
    · exact hg.1
    · exact hg.2.1
  have hEq := eqDef_rows F.db5 t.s.cmds _ _ _ he.1
  have core := F.output_leaf (by omega) (by omega)
    (t.s.eqrow (F.s-1) p b) (F.outX b) (F.outY b) p b
  have hepos : 1 ≤ t.s.eqrow (F.s-1) p b := by have := he.2.1; omega
  have hrows : ∀ r∈F.rows, r.toE∈D := by
    intro r hr
    exact hmem _ (exec_mono F.db5 t.s.cmds _ (F.original_mem_db5 r hr))
  have heqs := And.intro (hmem _ hEq.2.1) (hmem _ hEq.2.2.1)
  have hf : ∀ u v, u<2 → v<2 →
      Refutation (D ++ [negate (clauseRow
        (F.outLeaf (t.s.eqrow (F.s-1) p b) (F.outX b) (F.outY b) p u v)).toE]) := by
    intro u v hu hv
    apply core u v (parityBit (F.outX b)) hepos (F.outX_lt hk b hb) (F.outY_lt hk b hb)
      hp hb hu hv (F.inputBit_outX_0 hk b hb) (F.inputBit_outY_0 hk b hb)
    · rw [hpar]
    · rw [hpar]; exact F.parity_outXY hk b hb
    · exact hD
    · exact hrows
    · exact heqs
  intro lf hlf
  simp only [outputC,outputVs,leaves,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hlf
  rcases hlf with (rfl | rfl) | (rfl | rfl)
  · exact hf 0 0 (by decide) (by decide)
  · exact hf 0 1 (by decide) (by decide)
  · exact hf 1 0 (by decide) (by decide)
  · exact hf 1 1 (by decide) (by decide)

/-- Full split tree, including its internal resolution nodes, against the
    actual database preceding the output split. -/
theorem output_split_obls (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (hpar : F.b = parityBit) (t : StI F.V) (h : F.Good3 t)
    (p b : Nat) (hp : p<2) (hb : b<2) :
    ∀ o∈obls (exec F.db5 t.s.cmds)
      (splitCmds (F.outputC t p b) (F.outputVs p b)),
      Refutation (o.1 ++ [negate (clauseRow o.2).toE]) := by
  have hDB := exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) (by omega)) t.inv.1
  rw [t.inv.2] at hDB
  obtain ⟨hc,hv⟩ := F.output_bounds hk hs t h p b hp hb
  apply split_obls _ t.s.var hDB _ _ hc hv
  intro D hm hd
  exact F.output_split_leaves hk hs hpar t h p b hp hb D hd hm

theorem outSplit_commands (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (h : F.Good3 t) (p b : Nat) (hp : p<2) (hb : b<2) :
    (F.outSplit t (p,b)).s.cmds =
      t.s.cmds ++ splitCmds (F.outputC t p b) (F.outputVs p b) := by
  obtain ⟨hc,hv⟩ := F.output_bounds hk hs t h p b hp hb
  exact (StI.split_cmds _ t _ hc hv).1

#print axioms output_split_obls
#print axioms outSplit_commands
end Fam
end L3

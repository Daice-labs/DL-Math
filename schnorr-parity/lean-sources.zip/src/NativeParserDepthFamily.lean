import NativeParserTapeBounds
import NativeParserBundle
namespace L3Emitter.NativeParserDepthFamily
open EREF CanonicalFileGrammar CanonicalLineParser NativeParserEventCoordinates

theorem renamed (B:Nat) (ρ:Nat→Nat) (e:Event) (h:NativeParserTapeBounds.EventBound B e):
 NativeParserTapeBounds.EventBound B (event ρ e):=by
 cases e with
 | pol ts=>simpa only [event,NativeParserTapeBounds.EventBound,List.length_map] using h
 | pbc _ | red _ _ | goal _ | close _ | endRed=>trivial

theorem parsed_tapes (n:Nat) (hn:2≤n):
 ∀e∈(NativeParserBundle.parsed n).commands.flatMap commandEvents,
 NativeParserTapeBounds.EventBound (NativeParserTapeBounds.bound n) e:=by
 change ∀e∈((NativeCompatibleFamily.commands n).map (PinnedCoordinateChange.command
   (PinnedCoordinateChange.coordinate (NativeParserBundle.names n)))).flatMap commandEvents,_
 rw [commands_events]
 intro e he
 obtain ⟨q,hq,rfl⟩:=List.mem_map.mp he
 exact renamed _ _ q (NativeParserTapeBounds.family n hn q hq)

/-- The closed maximum of main-tape and per-local-certificate token bounds
covers the native parser's transient scalar slot as well as normal operands. -/
theorem range (n:Nat) (hn:2≤n) (hm:NativeParserTapeBounds.bound n+1<2^64):
 NativeParserDepth.FileRange (NativeParserBundle.parsed n).commands:=by
 intro e he
 have hb:=parsed_tapes n hn e he
 cases e with
 | pol ts=>change ts.length≤_ at hb;change ts.length+1<_;omega
 | pbc _ | red _ _ | goal _ | close _ | endRed=>trivial

theorem counters (n:Nat) (hn:2≤n) (hm:NativeParserTapeBounds.bound n+1<2^64):
 ∀ts,Event.pol ts∈(NativeParserBundle.parsed n).commands.flatMap commandEvents→
 ∀x∈NativeParserDepth.states ts 0,(UInt64.ofNat x).toNat=x:=
 NativeParserDepth.file_counters _ (range n hn hm)

/-- A numeric inequality on the proved closed bound, not a certificate run. -/
theorem base_in_range:NativeParserTapeBounds.bound 2+1<2^64:=by decide
#print axioms range
#print axioms counters
#print axioms base_in_range
end L3Emitter.NativeParserDepthFamily

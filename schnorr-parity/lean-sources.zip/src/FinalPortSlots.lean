import FinalSelectorImage
namespace L3Emitter.FinalPortSlots
open EREF EREF.GeneralRED REDWitness AliasNetwork RecordedExpressions RecordedExpressionRun FinalOutputDefinitions
variable {base:List Row}
attribute [local irreducible] FinalOutputDefinitions.construction tabulate FinalOutputDefinitions.out FinalOutputDefinitions.selector FinalOutputDefinitions.port FinalOutputDefinitions.function

def beforePorts (n:Nat) (hn:2≤n) (z:Net base):Net base:=
  (tabulate 2 (fun p=>tabulate (W n-1) (FinalOutputDefinitions.selector n hn p)) (FinalOutputSlots.outs n hn z).2).2
def start (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (x:Fin (T n)):Net base:=
  CoordinateSnapshots.before (T n) (FinalOutputDefinitions.port n hn (FinalOutputSlots.outs n hn z).1 p)
    (CoordinateSnapshots.before 2 (fun p=>tabulate (T n) (FinalOutputDefinitions.port n hn (FinalOutputSlots.outs n hn z).1 p)) (beforePorts n hn z) p) x
def alternative (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (x:Fin (T n)):Bit:=
  if p.val=0 then (FinalOutputSlots.outs n hn z).1 x else SourceCoordinateValue.value n hn ⟨0,by unfold AliasAssembly.width;omega⟩ x.val
def job (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (x:Fin (T n)):=
  LookupEvaluation.job (H n hn) (LowerTransferImage.wire n hn (.port (lastRank n) p.val x.val))
    (alternative n hn z p x) (start n hn z p x)

theorem projection (n:Nat) (hn:2≤n) (z:Net base):
    (FinalOutputDefinitions.construction n hn z).1.ports=
      (tabulate 2 (fun p=>tabulate (T n) (FinalOutputDefinitions.port n hn (FinalOutputSlots.outs n hn z).1 p)) (beforePorts n hn z)).1:=by
  unfold FinalOutputDefinitions.construction beforePorts FinalOutputSlots.outs
  rfl

theorem member (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (x:Fin (T n)):
    job n hn z p x∈(FinalOutputRecorded.construction n hn z).1.2:=by
  unfold FinalOutputRecorded.construction
  apply LoggedMembership.bind_right
  apply LoggedMembership.bind_right
  apply LoggedMembership.bind_left
  apply LoggedMembership.tabulate_at 2
  apply LoggedMembership.tabulate_at (T n)
  have hstate:
    CoordinateSnapshots.before (T n) (fun x=>forget (FinalOutputRecorded.port n hn (FinalOutputSlots.outs n hn z).1 p x))
      (CoordinateSnapshots.before 2 (fun p=>forget (tabulateLog (T n) (FinalOutputRecorded.port n hn (FinalOutputSlots.outs n hn z).1 p)))
        (beforePorts n hn z) p) x=start n hn z p x:=by
    simp only [tabulate_binding,FinalOutputRecorded.port_binding,start]
  have hs:(tabulateLog 2 (fun p=>tabulateLog (W n-1) (FinalOutputRecorded.selector n hn p)) (FinalOutputSlots.outs n hn z).2).2=beforePorts n hn z:=by
    change (forget (tabulateLog 2 (fun p=>tabulateLog (W n-1) (FinalOutputRecorded.selector n hn p))) (FinalOutputSlots.outs n hn z).2).2=_
    simp only [tabulate_binding,FinalOutputRecorded.selector_binding,beforePorts]
  change job n hn z p x∈(FinalOutputRecorded.port n hn (FinalOutputSlots.outs n hn z).1 p x
    (CoordinateSnapshots.before (T n) (fun x=>forget (FinalOutputRecorded.port n hn (FinalOutputSlots.outs n hn z).1 p x))
      (CoordinateSnapshots.before 2 (fun p=>forget (tabulateLog (T n) (FinalOutputRecorded.port n hn (FinalOutputSlots.outs n hn z).1 p)))
        ((tabulateLog 2 (fun p=>tabulateLog (W n-1) (FinalOutputRecorded.selector n hn p)) (FinalOutputSlots.outs n hn z).2).2) p) x)).1.2
  rw [hs,hstate]
  exact List.mem_singleton_self _

theorem value (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (x:Fin (T n)):
    (job n hn z p x).q=(FinalOutputDefinitions.construction n hn z).1.ports p x:=by
  have hp:=CoordinateSnapshots.tabulate_at 2 (fun p=>tabulate (T n) (FinalOutputDefinitions.port n hn (FinalOutputSlots.outs n hn z).1 p)) (beforePorts n hn z) p
  have hx:=CoordinateSnapshots.tabulate_at (T n) (FinalOutputDefinitions.port n hn (FinalOutputSlots.outs n hn z).1 p)
    (CoordinateSnapshots.before 2 (fun p=>tabulate (T n) (FinalOutputDefinitions.port n hn (FinalOutputSlots.outs n hn z).1 p)) (beforePorts n hn z) p) x
  rw [projection]
  simpa only [job,start,FinalOutputDefinitions.port,alternative,LookupEvaluation.job] using ((congrFun hp x).trans hx).symm

theorem rows (n:Nat) (hn:2≤n) (p:Fin 2) (x:Fin (T n)):
    let q:=(FinalOutputDefinitions.built n hn).1.ports p x
    let a:=LowerTransferImage.wire n hn (.port (lastRank n) p.val x.val)
    let b:=alternative n hn (initialNet n hn) p x
    clause [-(H n hn).val,-a.val,q.val]∈FinalOutputRecorded.result n hn ∧
    clause [-(H n hn).val,-q.val,a.val]∈FinalOutputRecorded.result n hn ∧
    clause [(H n hn).val,-b.val,q.val]∈FinalOutputRecorded.result n hn ∧
    clause [(H n hn).val,-q.val,b.val]∈FinalOutputRecorded.result n hn:=by
  let j:=job n hn (initialNet n hn) p x
  have hj:j∈FinalOutputRecorded.jobs n hn:=member n hn (initialNet n hn) p x
  have hq:j.q=(FinalOutputDefinitions.built n hn).1.ports p x:=by
    rw [FinalOutputDefinitions.built]
    exact value n hn (initialNet n hn) p x
  have present:∀R∈jobRows j,R∈FinalOutputRecorded.result n hn:=fun R hr=>List.mem_append_right _ (List.mem_flatMap.mpr ⟨j,hj,hr⟩)
  have h0:=present _ (List.mem_cons_self : clause [-j.c.val,-j.a.val,j.q.val]∈jobRows j)
  have h1:=present (clause [-j.c.val,-j.q.val,j.a.val]) (List.mem_cons_of_mem _ List.mem_cons_self)
  have h2:=present (clause [j.c.val,-j.b.val,j.q.val]) (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))
  have h3:=present (clause [j.c.val,-j.q.val,j.b.val]) (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_singleton_self _))))
  rw [hq] at h0 h1 h2 h3
  exact ⟨h0,h1,h2,h3⟩
#print axioms rows
end L3Emitter.FinalPortSlots

import RecordedGateSnapshots

namespace L3Emitter.GatePortOneHot
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot

def cs (n:Nat) (hn:2≤n) (g p:Nat) :=
  SelectedVectorClauses.choices (n+1) g ((PrimaryAliasBank.cfg n hn).sel g p)
def inputs (n:Nat) (hn:2≤n) (g p:Nat) (c:Bit) := (GateSnapshots.beforeGate n hn g).1
  (SelectedVectorClauses.originalIndex (n+1) (3*(n+1)-4) g p c)
def target (n:Nat) (hn:2≤n) (g p:Nat) := (RecordedGateSnapshots.portAt n hn g p).1.1

def program (n:Nat) (hn:2≤n) (g p:Nat) (D:List Row) :=
  SelectedVectorOneHot.program D (cs n hn g p) (inputs n hn g p) (target n hn g p)
def result (n:Nat) (hn:2≤n) (g p:Nat) (D:List Row) :=
  SelectedVectorOneHot.result D (cs n hn g p) (target n hn g p)

theorem selector_rows (n:Nat) (hn:2≤n) :
    ∀R∈SelectorBank.result n hn,R∈CategoryBank.result n hn := by
  intro R h
  exact GateSnapshots.built_to_bank n hn R (AliasAssembly.preserves_predecessor n hn R h)

theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4) (p:Nat) (hp:p<2)
    (D:List Row) (hd:CategorySourceInputs.Keep n hn D)
    (hs:∀j,j<n+1+g→SourceRows D ((GateSnapshots.beforeGate n hn g).1 j)) :
    check D (program n hn g p D)=some (result n hn g p D) := by
  apply SelectedVectorOneHot.checks
  · unfold AliasAssembly.width RankConstruction.width;omega
  · simp [cs,SelectedVectorClauses.choices]
  · exact hd _ (selector_rows n hn _ (SelectedVectorClauses.original_alo n hn g p hg hp))
  · intro c hc
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    have hj':j<n+1+g:=List.mem_range.mp hj
    change SourceRows D ((GateSnapshots.beforeGate n hn g).1
      (SelectedVectorClauses.originalIndex (n+1) (3*(n+1)-4) g p
        (AliasAssembly.selector (n+1) (3*(n+1)-4) g p j)))
    rw [SelectedVectorClauses.originalIndex_at]
    exact hs j hj'
  · intro c hc i
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    have hj':j<n+1+g:=List.mem_range.mp hj
    have h:=RecordedGateSnapshots.relations n hn g hg p hp j hj' i
    change clause [-((PrimaryAliasBank.cfg n hn).sel g p j).val,
        -((GateSnapshots.beforeGate n hn g).1
          (SelectedVectorClauses.originalIndex (n+1) (3*(n+1)-4) g p
            (AliasAssembly.selector (n+1) (3*(n+1)-4) g p j)) i).val,(target n hn g p i).val]∈D ∧
      clause [-((PrimaryAliasBank.cfg n hn).sel g p j).val,-(target n hn g p i).val,
        ((GateSnapshots.beforeGate n hn g).1
          (SelectedVectorClauses.originalIndex (n+1) (3*(n+1)-4) g p
            (AliasAssembly.selector (n+1) (3*(n+1)-4) g p j)) i).val]∈D
    rw [SelectedVectorClauses.originalIndex_at]
    exact ⟨hd _ h.1,hd _ h.2⟩

theorem retains (n:Nat) (hn:2≤n) (g p:Nat) (D:List Row) : ∀R∈D,R∈result n hn g p D :=
  fun R h=>List.mem_append_left _ (List.mem_append_left _ h)
theorem source_rows (n:Nat) (hn:2≤n) (g p:Nat) (D:List Row) :
    SourceRows (result n hn g p D) (target n hn g p) := by
  constructor
  · apply List.mem_append_left
    apply List.mem_append_right
    rw [←alo_binding]
    exact body_member (cs n hn g p) (target n hn g p) _ (by simp [specs])
  · intro i j hij
    apply List.mem_append_left
    apply List.mem_append_right
    rw [←pair_binding]
    exact body_member (cs n hn g p) (target n hn g p) _ (List.mem_cons_of_mem _ (pair_mem i j hij))

#print axioms checks
#print axioms source_rows
end L3Emitter.GatePortOneHot

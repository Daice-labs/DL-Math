import HitExclusions
namespace L3Emitter.HitCellPOL
set_option maxHeartbeats 1000000
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteSelection ReferenceTransport GuardedGatePOL

def row (c e:Int) (d:Cell):=clause [-c,-d.term.val,e]
def tape (D:List Row) (c e:Int) (d:Cell):List Tok:=
  if d.value.val=e then ChoiceProjection.weakenTokens D [-d.term.val,e] [-c]
  else [.ref (locate D (clause [-c,-d.choice.val])),.ref (locate D (clause [-d.term.val,d.choice.val])),.add,.lit e,.add]

theorem checks (D:List Row) (c e:Int) (d:Cell) (hc:c≠0) (he:e≠0)
    (hr:CellRows D d) (hex:d.value.val≠e→clause [-c,-d.choice.val]∈D):
    polEval (dbOf D) (tape D c e d) []=some (row c e d):=by
  by_cases h:d.value.val=e
  · simp only [tape,if_pos h]
    have hp:clause [-d.term.val,e]∈D:=by rw [←h];exact hr.2.2
    have ht:=ChoiceProjection.weaken_succeeds D [-d.term.val,e] [-c]
      (by simp [Valid,d.term.property,he]) (by simp [Valid,hc]) hp
    have heq:clause ([-d.term.val,e]++[-c])=row c e d:=by
      apply ProjectionTrace.clause_perm
      · simp [Valid,d.term.property,he,hc]
      · simp [row,Valid,d.term.property,he,hc]
      · exact List.perm_append_comm
    exact ht.trans (congrArg some heq)
  · simp only [tape,if_neg h,polEval,locate_correct _ _ (hex h),locate_correct _ _ hr.2.1,if_pos he]
    apply congrArg some
    apply canonical_ext _ _ (canonical_add _ _) (canonical_normalize _ _)
    intro α
    change (add (add (clause [-c,-d.choice.val]) (clause [-d.term.val,d.choice.val])) (litAxiom e)).val α=(row c e d).val α
    rw [val_add _ _ (canonical_add _ _) (canonical_litAxiom _),
      val_add (clause [-c,-d.choice.val]) (clause [-d.term.val,d.choice.val]) (canonical_normalize _ _) (canonical_normalize _ _)]
    simp only [row,val_clause [-c,-d.choice.val] (by simp [Valid,hc,d.choice.property]),
      val_clause [-d.term.val,d.choice.val] (by simp [Valid,d.term.property,d.choice.property]),
      val_clause [-c,-d.term.val,e] (by simp [Valid,hc,d.term.property,he]),val_litAxiom e he,
      sum_cons,sum_nil,litVal_neg α d.choice.val d.choice.property]
    ring

def forwardTape (D:List Row) (c e h:Int) (d:Cell):List Tok:=
  [.ref (locate D (clause [-c,d.choice.val])),.ref (locate D (clause [-d.choice.val,-e,d.term.val])),.add,
   .ref (locate D (clause [-d.term.val,h])),.add]

theorem forward_check (D:List Row) (c e h:Int) (d:Cell) (hc:c≠0) (he:e≠0) (hh:h≠0)
    (hv:d.value.val=e) (hr:CellRows D d) (hp:clause [-c,d.choice.val]∈D)
    (ho:clause [-d.term.val,h]∈D):
    polEval (dbOf D) (forwardTape D c e h d) []=some (clause [-c,-e,h]):=by
  have ha:clause [-d.choice.val,-e,d.term.val]∈D:=by rw [←hv];exact hr.1
  simp only [forwardTape,polEval,locate_correct _ _ hp,locate_correct _ _ ha,locate_correct _ _ ho]
  change some (add (add (clause [-c,d.choice.val]) (clause [-d.choice.val,-e,d.term.val])) (clause [-d.term.val,h]))=_
  apply congrArg some
  apply canonical_ext _ _ (canonical_add _ _) (canonical_normalize _ _)
  intro α
  change (add (add (clause [-c,d.choice.val]) (clause [-d.choice.val,-e,d.term.val])) (clause [-d.term.val,h])).val α=(clause [-c,-e,h]).val α
  rw [val_add (add (clause [-c,d.choice.val]) (clause [-d.choice.val,-e,d.term.val])) (clause [-d.term.val,h]) (canonical_add _ _) (canonical_normalize _ _),
    val_add (clause [-c,d.choice.val]) (clause [-d.choice.val,-e,d.term.val]) (canonical_normalize _ _) (canonical_normalize _ _)]
  rw [val_clause [-c,d.choice.val] (by simp [Valid,hc,d.choice.property]),
    val_clause [-d.choice.val,-e,d.term.val] (by simp [Valid,d.choice.property,he,d.term.property]),
    val_clause [-d.term.val,h] (by simp [Valid,d.term.property,hh]),
    val_clause [-c,-e,h] (by simp [Valid,hc,he,hh])]
  simp only [sum_cons,sum_nil,litVal_neg α d.choice.val d.choice.property,litVal_neg α d.term.val d.term.property]
  ring

#print axioms checks
#print axioms forward_check
end L3Emitter.HitCellPOL

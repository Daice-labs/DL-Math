import ConstructionAuxCount
import ConstructionFirstValueCount
import ConstructionPortCount

namespace L3Emitter.ConstructionGlobalCount
open EREF EREF.GeneralRED ConstructionCountTools

def Q (n : Nat) := (n+2)^5*2^n

theorem lift_power (n C a : Nat) (ha : a≤5) : C*(n+1)^a*2^n≤C*Q n := by
  have h: (n+1)^a≤(n+2)^5:=
    (Nat.pow_le_pow_left (by omega) a).trans (Nat.pow_le_pow_right (by omega) ha)
  exact (Nat.mul_le_mul_right (2^n) (Nat.mul_le_mul_left C h)).trans_eq (by unfold Q;ring)

theorem lift_plain (n C a : Nat) (ha : a≤5) : C*(n+1)^a≤C*Q n := by
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  exact (show C*(n+1)^a≤C*(n+1)^a*2^n by simpa only [Nat.mul_one] using Nat.mul_le_mul_left (C*(n+1)^a) ht).trans (lift_power n C a ha)

theorem primary (n : Nat) (hn : 2≤n) :
    (PrimaryAliasBank.emitted n hn).length≤17*(n+1)^3 := by
  have h:=ConstructionSourceCount.primary n hn
  have hw:ConstructionSourceCount.width n≤4*(n+1):=by
    have:=AliasAssembly.width_bound (n+1);unfold ConstructionSourceCount.width;omega
  have hp:=Nat.pow_le_pow_left hw 2
  have hmul:=Nat.mul_le_mul_left (n+1) hp
  exact h.trans (by nlinarith [Nat.pow_le_pow_right (show 1≤n+1 by omega) (show 1≤3 by omega)])

theorem first_ports (n : Nat) (hn : 2≤n) :
    (FirstPortOneHot.emitted n hn).length≤80*(n+1)^3 := by
  have h:=ConstructionSourceCount.first_ports n hn
  have hw:ConstructionSourceCount.width n≤4*(n+1):=by
    have:=AliasAssembly.width_bound (n+1);unfold ConstructionSourceCount.width;omega
  have hp:=Nat.pow_le_pow_left hw 2
  have hmul:=Nat.mul_le_mul_left (n+2) hp
  exact h.trans (by nlinarith [Nat.zero_le (n^3)])

theorem sources (n : Nat) (hn : 2≤n) :
    (GateOrderSources.fullProgram n hn).length≤1000*(n+1)^4 := by
  have h:=ConstructionSourceCount.bank n hn
  have hw:4*n-4≤4*(n+1):=by omega
  have hg:3*(n+1)-5≤3*(n+1):=Nat.sub_le ..
  have hp:=Nat.pow_le_pow_left hw 2
  have hb:(1+(4*n-4)^2)*(11*n+12)+2*(4*n-4)+1≤300*(n+1)^3:=by
    have hm:=Nat.mul_le_mul_right (11*n+12) hp
    nlinarith [Nat.zero_le (n^3)]
  exact h.trans ((Nat.mul_le_mul hg hb).trans (by nlinarith [Nat.zero_le ((n+1)^4)]))

theorem ports (n : Nat) (hn : 2≤n) :
    (GlobalPortValues.program n hn).length≤1248*(n+1)^3*2^n := by
  have h:=ConstructionPortCount.bank n hn
  have h1:3*(n+1)-4≤3*(n+1):=Nat.sub_le ..
  have h2:4*n-4≤4*(n+1):=by omega
  have h3:12*n+1≤13*(n+1):=by omega
  have hm:=Nat.mul_le_mul
    (Nat.mul_le_mul (Nat.mul_le_mul_right 2 h1)
      (Nat.mul_le_mul_right 4 (Nat.mul_le_mul_left (2^n) h2))) h3
  exact h.trans (hm.trans_eq (by ring))

/-- Counts every main command from the original formula through the global
value and port banks. This does not include the subsequent table/lower banks
or the recursive tail; it is not a serialized byte bound. -/
theorem complete (n : Nat) (hn : 2≤n) :
    (RecordedGlobalValues.program n hn).length≤400000*Q n := by
  have h0: (RecordedTransportPrefix.program n hn).length≤110000*Q n:=by
    simpa only [Q,Nat.mul_assoc] using ConstructionAliasPrefixCount.complete n hn
  have h1: (RankColumnOneHot.emitted n hn).length≤9*Q n:=
    (ConstructionRelationCount.columns n hn).trans (lift_plain n 9 2 (by omega))
  have h2:= (primary n hn).trans (lift_plain n 17 3 (by omega))
  have h3:= (first_ports n hn).trans (lift_plain n 80 3 (by omega))
  have h4:= (ConstructionRelationCount.categories n hn).trans (lift_plain n 1200 5 (by omega))
  have h5:= (ConstructionRelationCount.source_relations n hn).trans (lift_plain n 1000 3 (by omega))
  have h6:= (ConstructionAuxCount.units n hn).trans (lift_plain n 500 3 (by omega))
  have h7:= (ConstructionAuxCount.auxiliaries n hn).trans (lift_plain n 1000 3 (by omega))
  have h8:= (sources n hn).trans (lift_plain n 1000 4 (by omega))
  have h9:= (ConstructionAuxCount.cardinalities n hn).trans (lift_plain n 24 2 (by omega))
  have h10:= (ConstructionAuxCount.unary_relations n hn).trans (lift_plain n 360 2 (by omega))
  have h11: (UnaryLookupBank.program n hn).length≤1152*Q n:=by
    have h:=UnaryLookupBank.program_count_n n hn
    exact (show _≤1152*(n+1)^1 by simp only [pow_one];omega).trans (lift_plain n 1152 1 (by omega))
  have h12: (UnaryValueBank.program n hn).length≤576*Q n:=by
    have h:=UnaryValueBank.program_count_n n hn
    exact (show _≤576*(n+1)^1 by simp only [pow_one];omega).trans (lift_plain n 576 1 (by omega))
  have h13:= (ConstructionValueBankCount.beta n hn).trans (lift_power n 15552 4 (by omega))
  have h14:= (ConstructionValueBankCount.rank n hn).trans (lift_plain n 18 2 (by omega))
  have h15:= (ConstructionValueBankCount.rank_eval n hn).trans (lift_power n 36 2 (by omega))
  have h16:= (ConstructionFirstValueCount.hit n hn).trans (lift_plain n 54 3 (by omega))
  have h17:= (ConstructionFirstValueCount.receiving n hn).trans (lift_plain n 18 2 (by omega))
  have h18:= (ConstructionValueBankCount.gamma_choice n hn).trans (lift_plain n 3888 4 (by omega))
  have h19:= (ConstructionValueBankCount.gamma_compare n hn).trans (lift_power n 124416 4 (by omega))
  have h20:= (ConstructionValueBankCount.shared n hn).trans (lift_power n 16000 4 (by omega))
  have h21: (FirstValueBank.prepare n hn).length≤10*Q n:=by
    rw [ConstructionFirstValueCount.prepare]
    simpa only [pow_zero,Nat.mul_one] using lift_plain n 10 0 (by omega)
  have h22: (FirstValueBank.program n hn).length≤17*Q n:=by
    rw [ConstructionFirstValueCount.first]
    simpa only [pow_zero,Nat.mul_one] using lift_power n 17 0 (by omega)
  have h23: (FirstGateBase.program n hn).length≤16*Q n:=
    (ConstructionFirstValueCount.first_gate n hn).trans (by simpa using lift_power n 16 1 (by omega))
  have h24:= (ConstructionFirstValueCount.global n hn).trans (lift_power n 85000 5 (by omega))
  have h25:= (ports n hn).trans (lift_power n 1248 3 (by omega))
  simp only [RecordedGlobalValues.program,RecordedGlobalValues.p25,RecordedGlobalValues.p24,
    RecordedGlobalValues.p23,RecordedGlobalValues.p22,RecordedGlobalValues.p21,RecordedGlobalValues.p20,
    RecordedGlobalValues.p19,RecordedGlobalValues.p18,RecordedGlobalValues.p17,RecordedGlobalValues.p16,
    RecordedGlobalValues.p15,RecordedGlobalValues.p14,RecordedGlobalValues.p13,RecordedGlobalValues.p12,
    RecordedGlobalValues.p11,RecordedGlobalValues.p10,RecordedGlobalValues.p9,RecordedGlobalValues.p8,
    RecordedGlobalValues.p7,RecordedGlobalValues.p6,RecordedGlobalValues.p5,RecordedGlobalValues.p4,
    RecordedGlobalValues.p3,RecordedGlobalValues.p2,RecordedGlobalValues.p1,RecordedGlobalValues.p0,
    List.length_append,polProgram_length]
  omega

#print axioms complete
end L3Emitter.ConstructionGlobalCount

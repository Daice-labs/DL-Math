import L3BranchPrepared
import L3BranchMerge

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def branchRups (bs : List Nat) (t : StI F.V) : StI F.V := bs.foldl F.bRup t

theorem branchRups_keeps (bs : List Nat) (t : StI F.V) : Keeps2 t (F.branchRups bs t) :=
  keeps2_foldl _ _ (fun u b => keeps2_rup u _) t

theorem branchRups_B (bs : List Nat) (t : StI F.V) : (F.branchRups bs t).s.Bv=t.s.Bv :=
  StI.foldl_proj (fun (u : StI F.V) => u.s.Bv) F.bRup bs (fun _ _ => rfl) t

theorem branchRups_obls (hk : 1≤F.k) (hs : 1≤F.s) (bs : List Nat)
    (hbs : ∀b∈bs,b∈F.branchIndices) (t : StI F.V) (brs : List Int)
    (hr : F.BranchReady t brs) (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.branchRups bs t).s.cmds := by
  induction bs generalizing t with
  | nil => exact ho
  | cons b bs ih =>
    apply ih (fun j hj => hbs j (by simp [hj]))
    · exact F.BranchReady_keeps (keeps2_rup _ _) rfl brs hr
    · exact F.bRup_obls hk hs t brs hr b (hbs b (by simp)) ho

theorem branchC_keeps {t u : StI F.V} (hk : Keeps2 t u) (hB : u.s.Bv=t.s.Bv) (b : Nat) :
    F.branchC u b=F.branchC t b := by simp only [branchC,hB,hk.2.2.2.2.2.1]

theorem branchRups_roots (bs : List Nat) (hbs : ∀b∈bs,b∈F.branchIndices)
    (t : StI F.V) (brs : List Int) (hr : F.BranchReady t brs) :
    ∀b∈bs,Cmd.rup (F.branchC (F.branchRups bs t) b)∈(F.branchRups bs t).s.cmds := by
  induction bs generalizing t with
  | nil => simp
  | cons j js ih =>
    intro b hb
    let u := F.bRup t j
    have ku : Keeps2 t u := keeps2_rup _ _
    have hu := F.BranchReady_keeps ku rfl brs hr
    rcases List.mem_cons.mp hb with rfl | hb
    · change Cmd.rup (F.branchC (F.branchRups js u) b)∈(F.branchRups js u).s.cmds
      rw [F.branchC_keeps (F.branchRups_keeps js u) (F.branchRups_B js u)]
      apply mem_of_grows (F.branchRups_keeps js u).1
      change Cmd.rup (F.branchC t b)∈t.s.cmds++[.rup (t.s.chk (F.branchC t b))]
      rw [StI.chk_eq t _ (F.branchC_bound t brs hr b (hbs b (by simp)))]; simp
    · exact ih (fun z hz => hbs z (by simp [hz])) u hu b hb

theorem branch_final_obl (hk : 1≤F.k) (hs : 2≤F.s) (t : StI F.V) (brs : List Int)
    (hr : F.BranchReady t brs)
    (hroots : ∀b∈F.branchIndices,Cmd.rup (F.branchC t b)∈t.s.cmds)
    (ha : Cmd.rup [(t.s.A:Int)]∈t.s.cmds)
    (hl : Cmd.rup [-(t.s.eligible (F.s-1):Int)]∈t.s.cmds) :
    Refutation (exec F.db5 t.s.cmds++[negate (clauseRow [(t.s.Bv:Int)]).toE]) := by
  have hA := hr.1.2.2.2.2
  obtain ⟨cons,hcons,he,hcL,heL,heU⟩ := hr.1.2.2.2.1 (F.s-1) (by omega) (by omega)
  let xs := F.branchIndices.map fun b => (t.s.eligible b:Int)
  apply branch_merge_chain _
    (exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded hk (by omega)) t.inv.1).canonical
    t.s.Bv t.s.A (t.s.eligible (F.s-1)) xs hr.2.2.1 (by have := hA.2.1; omega) (by omega)
  · intro x hx
    obtain ⟨b,hb,rfl⟩ := List.mem_map.mp hx
    have hbi := List.mem_range'_1.mp hb
    obtain ⟨_,_,_,_,hbL,_⟩ := hr.1.2.2.2.1 b hbi.1 (by omega)
    omega
  · intro x hx
    obtain ⟨b,hb,rfl⟩ := List.mem_map.mp hx
    exact rup_row_mem F.db5 t.s.cmds _ (hroots b hb)
  · have h := orDef_row_down F.db5 t.s.cmds _ _ hA.1
    have heq : (List.range' 1 (F.s-1)).map (fun b => (t.s.eligible b:Int))=
        xs++[(t.s.eligible (F.s-1):Int)] := by
      rw [show F.s-1=(F.s-2)+1 by omega,List.range'_1_concat,List.map_append]
      simp only [List.map_cons,List.map_nil]
      change xs++[(t.s.eligible (1+(F.s-2)):Int)]=_
      rw [show 1+(F.s-2)=F.s-1 by omega,show F.s-2+1=F.s-1 by omega]
    rw [heq] at h; exact h
  · exact rup_row_mem F.db5 t.s.cmds _ ha
  · exact rup_row_mem F.db5 t.s.cmds _ hl

/-- The actual three-gate branch selection stage has no unproved RUP
    obligations once coverage A and output exclusion have been recorded. -/
theorem stage7_obls (hk : 1≤F.k) (hs : 2≤F.s) (t : StI F.V) (ht : F.Good3 t)
    (ha : Cmd.rup [(t.s.A:Int)]∈t.s.cmds)
    (hl : Cmd.rup [-(t.s.eligible (F.s-1):Int)]∈t.s.cmds)
    (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.stage7 t).s.cmds := by
  let u := F.preparedBranches t
  let brs := (F.preparedBank t).2
  let v := F.branchRups F.branchIndices u
  have hu : F.BranchReady u brs := F.prepared_ready t ht
  have kv : Keeps2 u v := F.branchRups_keeps _ _
  have hv : F.BranchReady v brs := F.BranchReady_keeps kv (F.branchRups_B _ _) brs hu
  have ktv : Keeps2 t v := keeps2_trans (F.prepared_keeps t) kv
  have hvo : ObligationsChecked F.db5 v.s.cmds :=
    F.branchRups_obls hk (by omega) _ (fun _ h => h) u brs hu (F.prepared_obls t ho)
  have hvr := F.branchRups_roots _ (fun _ h => h) u brs hu
  have hva : Cmd.rup [(v.s.A:Int)]∈v.s.cmds := by
    rw [ktv.2.2.2.2.2.2]; exact mem_of_grows ktv.1 ha
  have hvl : Cmd.rup [-(v.s.eligible (F.s-1):Int)]∈v.s.cmds := by
    rw [ktv.2.2.2.2.2.1]; exact mem_of_grows ktv.1 hl
  have hb : Bounded v.s.var [(v.s.Bv:Int)] := by
    have hL := hv.2.2.1; have hU := hv.2.2.2.1
    intro l hl; simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    subst l; simp; omega
  change ObligationsChecked F.db5 (v.s.cmds++[.rup (v.s.chk [(v.s.Bv:Int)])])
  rw [StI.chk_eq v _ hb]
  apply obligations_append _ _ _ hvo
  intro o ho
  simp only [obls,List.mem_cons,List.not_mem_nil,or_false] at ho
  subst o
  exact F.branch_final_obl hk hs v brs hv hvr hva hvl

#print axioms stage7_obls
end L3.Fam

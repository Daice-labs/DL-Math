import CanonicalFormulaEnvelope
import FableEncoding

namespace L3Emitter.ConstructionFormulaScale
/-- Unit: ROWS in the actual normalized original formula. -/
def rows (n : Nat) := (OriginalEncoding.rows n (3*n-4)).length

theorem truth_table (n : Nat) (hn : 2≤n) : 2^n≤rows n := by
  unfold rows
  rw [FableEncoding.row_count n (3*n-4) (by omega)]
  have h:=Nat.mul_le_mul_right (2^n) (show 1≤2*(3*n-4)*(n+(3*n-4)+3)+1 by omega)
  simp only [one_mul] at h
  omega

theorem arity (n : Nat) (hn : 2≤n) : n+1≤rows n := by
  have h : ∀m:Nat,m+1≤2^m := by
    intro m
    induction m with
    | zero => decide
    | succ n ih => rw [pow_succ];omega
  exact (h n).trans (truth_table n hn)

/-- A closed arity expression with a fixed truth-table exponent gives a
polynomial in the actual formula size. This conversion does not supply an
unproved bound for the emitter itself. -/
theorem monomial (n a b C : Nat) (hn : 2≤n) :
    C*(n+1)^a*2^(b*n)≤C*(rows n)^(a+b) := by
  have ha : (n+1)^a≤(rows n)^a := Nat.pow_le_pow_left (arity n hn) a
  have hb : 2^(b*n)≤(rows n)^b := by
    rw [Nat.mul_comm b n,pow_mul]
    exact Nat.pow_le_pow_left (truth_table n hn) b
  rw [pow_add,←mul_assoc]
  exact Nat.mul_le_mul (Nat.mul_le_mul_left C ha) hb

#print axioms monomial
end L3Emitter.ConstructionFormulaScale

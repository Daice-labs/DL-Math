import L3BranchStage
import L3CoverageOriginal

set_option maxHeartbeats 2000000

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

theorem stage5_A_record (hm : 1≤F.V) (t : StI F.V) (ht : F.Good3 t) :
    Cmd.rup [((F.stage5 hm t).s.A:Int)]∈(F.stage5 hm t).s.cmds := by
  let acc := [0,1].foldl (F.bitStep hm) (t,[])
  have ka : Keeps2 t acc.1 := keeps2_foldl_pair _ _ (F.keeps2_bitStep hm) (t,[])
  let u := acc.1.split acc.2 [(F.fn 0 0:Int),(F.fn 0 1:Int)]
  have ku : Keeps2 acc.1 u := keeps2_split _ _ _
  have hu := F.Good3_of_keeps2 (keeps2_trans ka ku) ht
  have hb : Bounded u.s.var [(u.s.A:Int)] := by
    have hL := hu.2.2.2.2.2.1; have hU := hu.2.2.2.2.2.2
    intro l hl; simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    subst l; simp; omega
  have hA : u.s.A=acc.1.s.A := ku.2.2.2.2.2.2
  change Cmd.rup [(u.s.A:Int)]∈u.s.cmds++[.rup (u.s.chk [(acc.1.s.A:Int)])]
  rw [←hA,StI.chk_eq u _ hb]; simp

theorem stage6_output_record (hs : 2≤F.s) (t : StI F.V) (ht : F.Good3 t) :
    Cmd.rup [-((F.stage6 t).s.eligible (F.s-1):Int)]∈(F.stage6 t).s.cmds := by
  unfold stage6
  generalize h1 : ([0,1].flatMap (fun port => [(port,0),(port,1)])).foldl F.outSplit t = u
  dsimp only
  generalize h2 : [0,1].foldl F.outRup u = v
  have ku : Keeps2 t u := by
    rw [←h1]
    exact keeps2_foldl _ _ F.keeps2_outSplit t
  have kv : Keeps2 u v := by
    rw [←h2]
    exact keeps2_foldl _ _ F.keeps2_outRup u
  have hv := F.Good3_of_keeps2 (keeps2_trans ku kv) ht
  obtain ⟨c,hc,he,hcl,hel,heu⟩ := hv.2.2.2.1 (F.s-1) (by omega) (by omega)
  have hb : Bounded v.s.var [-(v.s.eligible (F.s-1):Int)] := by
    intro l hl; simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    subst l; simp; omega
  change Cmd.rup [-(v.s.eligible (F.s-1):Int)]∈v.s.cmds++[.rup (v.s.chk [-(v.s.eligible (F.s-1):Int)])]
  rw [StI.chk_eq v _ hb]; simp

/-- Complete semantic frontend after normalization, in the actual stage
    order 0--7. All coverage/branch obligations are discharged. This theorem
    does not include the subsequent cofactor/transport emitter. -/
theorem frontendX_obls (hk : 2≤F.k) (hs : 2≤F.s) (hpar : F.b=parityBit) :
    ObligationsChecked F.db5 (F.frontendX (by omega)).s.cmds := by
  let u := F.stage5 (F.V_pos (by omega)) (F.t4 (by omega))
  let v := F.stage6 u
  have ht4 : F.Good3 (F.t4 (by omega)) :=
    F.Good3_of_keeps2 (F.keeps2_stage4 (F.t3 (by omega))) (F.good3_stage3 (by omega))
  have hu : F.Good3 u := F.Good3_of_keeps2 (F.keeps2_stage5 _ _) ht4
  have kv : Keeps2 u v := F.keeps2_stage6 u
  have hv : F.Good3 v := F.Good3_of_keeps2 kv hu
  have ha : Cmd.rup [(v.s.A:Int)]∈v.s.cmds := by
    rw [kv.2.2.2.2.2.2]
    exact mem_of_grows kv.1 (F.stage5_A_record _ _ ht4)
  exact F.stage7_obls (by omega) hs v hv ha (F.stage6_output_record hs u hu)
    (F.t6_obls hk hs hpar)

#print axioms frontendX_obls
end L3.Fam

namespace L3Emitter.FableCoverageIntegration
open EREF.GeneralRED L3Emitter.FableEncoding

/-- Complete normalized frontend semantic trace from the unchanged original
    encoding. No open frontend obligation is assumed. -/
theorem frontend_from_original (k : Nat) (hk : 3≤k) :
    CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (L3.exec (fam k (3*k-4)).db5
        ((fam k (3*k-4)).frontendX (by change 1≤3*k-4; omega)).s.cmds) := by
  apply L3Emitter.SelectorNormalization.trace_trans (fable_prefix_on_v5 k hk)
  apply (fam k (3*k-4)).state_trace (by change 1≤k; omega) (by change 1≤3*k-4; omega)
  exact (fam k (3*k-4)).frontendX_obls (by change 2≤k; omega) (by change 2≤3*k-4; omega) rfl

#print axioms frontend_from_original
end L3Emitter.FableCoverageIntegration

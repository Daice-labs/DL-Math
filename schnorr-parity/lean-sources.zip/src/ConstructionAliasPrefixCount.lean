import ConstructionAliasBankCount
import ConstructionPrefixCount

namespace L3Emitter.ConstructionAliasPrefixCount
open ConstructionCountTools

/-- Actual main commands through the complete recursive alias network. -/
theorem complete (n : Nat) (hn : 2≤n) :
    (RecordedTransportPrefix.program n hn).length≤110000*(n+2)^5*2^n := by
  have hp:=ConstructionPrefixCount.before_aliases n hn
  have ha:=ConstructionAliasBankCount.complete n hn
  have hpow:(n+2)^3≤(n+2)^5:=Nat.pow_le_pow_right (by omega) (by omega)
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  simp only [RecordedTransportPrefix.program,List.length_append]
  nlinarith

#print axioms complete
end L3Emitter.ConstructionAliasPrefixCount

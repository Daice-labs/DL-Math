import ConstructionRelationCount

namespace L3Emitter.ConstructionValueBankCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount

theorem beta (n : Nat) (hn : 2≤n) :
    (BetaValueBank.program n hn).length≤15552*(n+1)^4*2^n := by
  rw [BetaValueBank.program_count]
  have h:=ConstructionConstantCount.beta_jobs n hn
  have hf:=ConstructionConstantCount.field_jobs (n+1) (by omega)
  nlinarith [Nat.mul_le_mul_right (2^n) hf]

theorem rank (n : Nat) (hn : 2≤n) :
    (RankValueBank.program n hn).length≤18*(n+1)^2 := by
  rw [RankValueBank.program_count,gates]
  have hg:3*(n+1)-5≤3*(n+1):=Nat.sub_le ..
  have hr:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  nlinarith [Nat.mul_le_mul hg hr]

theorem raw_records (n : Nat) (hn : 2≤n) :
    (RawValueBank.result n hn).2.length=RankConstruction.width (n+1)*2^n := by
  have h:=congrArg List.length (RawValueBank.records_cover n hn (OutputBank.result n hn) (RawValueBank.jobs n))
  simp only [List.length_map,RawBankSize.jobs_length,FamilyNamespace.truthRows] at h
  exact h

theorem rank_eval (n : Nat) (hn : 2≤n) :
    (RankEvaluationBank.program n hn).length≤36*(n+1)^2*2^n := by
  simp only [RankEvaluationBank.program,List.length_map]
  have h:(RankEvaluationBank.jobs n hn).length=(CategoryBank.gates n).length*((RawValueBank.result n hn).2.length*4):=by
    unfold RankEvaluationBank.jobs
    apply flat_exact
    intro g hg
    rw [flat_exact _ _ 4 (by intro r hr;rfl),List.length_attach]
  rw [h,gates,raw_records]
  have hg:3*(n+1)-5≤3*(n+1):=Nat.sub_le ..
  have hr:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hp:=Nat.mul_le_mul hg hr
  nlinarith [Nat.mul_le_mul_right (4*2^n) hp]

theorem rebase_length (src dst : List Row) (p : Program) :
    (ProgramRebase.program src dst p).length=p.length := by
  induction p generalizing src dst with
  | nil=>rfl
  | cons c cs ih=>cases c;simp only [ProgramRebase.program,List.length_cons,ih]

theorem shared (n : Nat) (hn : 2≤n) :
    (SharedValueBank.program n hn).length≤16000*(n+1)^4*2^n := by
  simp only [SharedValueBank.program,SharedValueBank.betaProgram,SharedValueBank.rankProgram,
    SharedValueBank.evaluationProgram,List.length_append,rebase_length]
  have hb:=beta n hn
  have hr:=rank n hn
  have he:=rank_eval n hn
  have hp:(n+1)^2≤(n+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  nlinarith [Nat.mul_le_mul_right (2^n) hp]

theorem gamma_choice (n : Nat) (hn : 2≤n) :
    (GammaChoiceBank.emitted n hn).length≤3888*(n+1)^4 := by
  unfold GammaChoiceBank.emitted
  rw [flat_exact _ _ 3 (by intro j hj;rfl)]
  have h:=ConstructionConstantCount.field_jobs (n+1) (by omega)
  change (GammaChoiceBank.jobs n hn).length≤1296*(n+1)^4 at h
  nlinarith

theorem gamma_compare (n : Nat) (hn : 2≤n) :
    (GammaComparisonBank.emitted n hn).length≤124416*(n+1)^4*2^n := by
  have hj:(GammaComparisonBank.jobs n hn).length=(BetaPort.jobs n hn).length*32:=by
    unfold GammaComparisonBank.jobs
    exact flat_exact _ _ _ (by intro j hj;rfl)
  have hu:(GammaComparisonBank.unaryJobs n hn).length=(GammaChoiceBank.jobs n hn).length*32:=by
    unfold GammaComparisonBank.unaryJobs
    exact flat_exact _ _ _ (by intro j hj;rfl)
  simp only [GammaComparisonBank.emitted,GammaComparisonBank.first,GammaComparisonBank.last,
    List.length_append,List.length_map,hj,hu]
  have hb:=ConstructionConstantCount.beta_jobs n hn
  have hf:=ConstructionConstantCount.field_jobs (n+1) (by omega)
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  change (GammaChoiceBank.jobs n hn).length≤1296*(n+1)^4 at hf
  change (BetaPort.jobs n hn).length=(GammaChoiceBank.jobs n hn).length*2^n at hb
  nlinarith [Nat.mul_le_mul_left (1296*(n+1)^4) ht,Nat.mul_le_mul_right (2^n) hf]

#print axioms beta
#print axioms rank_eval
#print axioms shared
#print axioms gamma_compare
end L3Emitter.ConstructionValueBankCount

import L3GateRows

namespace L3.Fam
open L3 EREF EREF.GeneralRED
variable (F : Fam)

theorem clause_swap_last (f a b : Int) (hf : f≠0) (ha : a≠0) (hb : b≠0) :
    (clauseRow [f,a,b]).toE=(clauseRow [f,b,a]).toE := by
  apply toE_of_equiv
  · intro l hl; simp only [clauseRow,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl | rfl <;> assumption
  · intro l hl; simp only [clauseRow,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl | rfl <;> assumption
  · exact ⟨rfl,fun α => by simp only [clauseRow,lsum_cons,lsum_nil]; omega⟩


theorem changedPort0_mem (t : StI F.V) (ht : F.Good3 t) (g bit cb q : Nat)
    (hg1 : 1≤g) (hg : g<F.s) (hf : F.ForceRecord t) (hr : F.PortRecord g 0 bit cb q t)
    (D : List EREF.Row) (hm : ∀R∈exec F.db5 t.s.cmds,R∈D)
    (u w b pol : Bool) (hne : u≠w) :
    All (fun r => r.toE∈D) (F.changedPortRows g 0 (F.bitX bit) (F.bitY bit)
      t.s.A cb (t.s.live g) q (t.s.force g 0) (2*u.toNat+b.toNat) (2*w.toNat+b.toNat) u pol) := by
  have he := eqDef_rows F.db5 t.s.cmds _ _ _ hr.1
  refine ⟨?_,hm _ (rup_row_mem _ _ _ hr.2.1),hm _ (rup_row_mem _ _ _ hr.2.2.1),?_,trivial⟩
  · cases u
    · exact hm _ he.2.1
    · exact hm _ he.2.2.1
  · have hF := (ht.2.2.1 g 0 hg1 hg (by decide)).2.2.1.2.1
    have hn0 := F.fn_pos g 0
    have hn1 := F.fn_pos g 1
    have hn2 := F.fn_pos g 2
    have hn3 := F.fn_pos g 3
    cases u <;> cases w <;> cases b <;> cases pol <;> try contradiction
    all_goals simp only [Bool.toNat,Bool.cond_false,Bool.cond_true,Nat.reduceAdd,Nat.reduceMul,Bool.false_eq_true,↓reduceIte]
    all_goals first
      | (solve | apply hm; apply rup_row_mem; apply hf g 0 hg1 hg (by decide); simp [forceClauses])
      | (rw [clause_swap_last _ _ _ (by omega) (by omega) (by omega)]
         apply hm; apply rup_row_mem; apply hf g 0 hg1 hg (by decide); simp [forceClauses])

theorem changedPort1_mem (t : StI F.V) (ht : F.Good3 t) (g bit cb q : Nat)
    (hg1 : 1≤g) (hg : g<F.s) (hf : F.ForceRecord t) (hr : F.PortRecord g 1 bit cb q t)
    (D : List EREF.Row) (hm : ∀R∈exec F.db5 t.s.cmds,R∈D)
    (u w a pol : Bool) (hne : u≠w) :
    All (fun r => r.toE∈D) (F.changedPortRows g 1 (F.bitX bit) (F.bitY bit)
      t.s.A cb (t.s.live g) q (t.s.force g 1) (2*a.toNat+u.toNat) (2*a.toNat+w.toNat) u pol) := by
  have he := eqDef_rows F.db5 t.s.cmds _ _ _ hr.1
  refine ⟨?_,hm _ (rup_row_mem _ _ _ hr.2.1),hm _ (rup_row_mem _ _ _ hr.2.2.1),?_,trivial⟩
  · cases u
    · exact hm _ he.2.1
    · exact hm _ he.2.2.1
  · have hF := (ht.2.2.1 g 1 hg1 hg (by decide)).2.2.1.2.1
    have hn0 := F.fn_pos g 0
    have hn1 := F.fn_pos g 1
    have hn2 := F.fn_pos g 2
    have hn3 := F.fn_pos g 3
    cases u <;> cases w <;> cases a <;> cases pol <;> try contradiction
    all_goals simp only [Bool.toNat,Bool.cond_false,Bool.cond_true,Nat.reduceAdd,Nat.reduceMul,Bool.false_eq_true,↓reduceIte]
    all_goals first
      | (solve | apply hm; apply rup_row_mem; apply hf g 1 hg1 hg (by decide); simp [forceClauses])
      | (rw [clause_swap_last _ _ _ (by omega) (by omega) (by omega)]
         apply hm; apply rup_row_mem; apply hf g 1 hg1 hg (by decide); simp [forceClauses])

/-- T5e uses only original gate rows and definitions/roots produced by the
    actual two port steps and stage 4. -/
theorem gate_leaf_from_database (hk : 2≤F.k) (t : StI F.V) (ht : F.Good3 t)
    (g bit cb v q0 q1 : Nat) (hg1 : 1≤g) (hg : g<F.s) (hb : bit<2)
    (hc : 1≤cb) (hv : 1≤v) (hf : F.ForceRecord t)
    (h0 : F.PortRecord g 0 bit cb q0 t) (h1 : F.PortRecord g 1 bit cb q1 t)
    (heq : Cmd.eqDef v (F.val g (F.bitX bit) : Int) (F.val g (F.bitY bit) : Int)∈t.s.cmds)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hm : ∀R∈exec F.db5 t.s.cmds,R∈D) (u0 u1 w0 w1 pol : Bool) :
    Refutation (D ++ [negate (clauseRow (F.gateStepLeaf g (F.bitX bit) (F.bitY bit)
      t.s.A cb (t.s.live g) v u0 u1 w0 w1 pol)).toE]) := by
  have hA := ht.2.2.2.2.2.1
  have hL := (F.live_bound_of_good3 ht g hg).1
  have hF0 := (ht.2.2.1 g 0 hg1 hg (by decide)).2.2.1.2.1
  have hF1 := (ht.2.2.1 g 1 hg1 hg (by decide)).2.2.1.2.1
  have he := eqDef_rows F.db5 t.s.cmds _ _ _ heq
  have horig : ∀r∈F.rows,r.toE∈D := fun r hr => hm _ (exec_mono _ _ _ (F.original_mem_db5 r hr))
  apply F.gate_propagation_leaf g (F.bitX bit) (F.bitY bit) t.s.A cb (t.s.live g) v q0 q1
    (t.s.force g 0) (t.s.force g 1) u0 u1 w0 w1 pol
    (by omega) hc (by omega) hv h0.2.2.2.1 h1.2.2.2.1 (by omega) (by omega) D hD
  apply All.append
  · apply All.append
    · refine ⟨?_,?_,?_,trivial⟩
      · exact horig _ (F.row4P_mem pol g _ _ _ hg (F.bitX_lt hk bit hb)
          (by cases u0 <;> decide) (by cases u1 <;> decide))
      · exact horig _ (F.row4P_mem (!pol) g _ _ _ hg (F.bitY_lt hk bit hb)
          (by cases w0 <;> decide) (by cases w1 <;> decide))
      · cases pol
        · exact hm _ he.1
        · exact hm _ he.2.2.2
    · split
      · trivial
      · exact F.changedPort0_mem t ht g bit cb q0 hg1 hg hf h0 D hm u0 w0 u1 pol ‹u0≠w0›
  · split
    · trivial
    · exact F.changedPort1_mem t ht g bit cb q1 hg1 hg hf h1 D hm u1 w1 w0 pol ‹u1≠w1›

#print axioms gate_leaf_from_database
end L3.Fam

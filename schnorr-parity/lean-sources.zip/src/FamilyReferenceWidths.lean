import ActionReferenceBounds
import ConstructionClosedReference
namespace L3Emitter.FamilyReferenceWidths
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

def tapeRefs (ts : List Tok) : List Nat := ts.filterMap fun t=>match t with | .ref i=>some i | _=>none
def localRefs (b : NativeScopedLocalGoal.Built) : List Nat := b.conclusion::b.tapes.flatMap tapeRefs

def goalRefs (ids : Nat → Nat) (i : Nat) : List (Row×NativeScopedLocalGoal.Built) → List Nat
  | []=>[]
  | (_,b)::bs=>(if i=0 then [] else [ids i])++localRefs b++goalRefs ids (i+1) bs

def actionRefs (ids : Nat → Nat) : NativeRecordedStep.Action → List Nat
  | .pol ts=>tapeRefs ts
  | .consequence _ b=>localRefs b
  | .red _ _ bs=>goalRefs ids 0 bs

def bodyRefs (D : List Row) (s : Store) (ids : Nat → Nat) : Program → List Nat
  | []=>[]
  | c::cs=>let b:=NativeRecordedStep.compile D s ids c
      actionRefs ids b.action++bodyRefs (D++[c.row]) b.store b.ids cs

theorem tape (N : Nat) (ts : List Tok) (h : LiveTapeReferences.Bounded N ts) :
    ∀i∈tapeRefs ts,0 < i ∧ i < N := by
  intro i hi
  obtain ⟨t,ht,he⟩:=List.mem_filterMap.mp hi
  cases t  <;> simp only [Option.some.injEq] at he
  case ref j => subst i;exact h j ht
  all_goals cases he

theorem local_goal (N : Nat) (b : NativeScopedLocalGoal.Built) (h : ScopedReferenceBounds.Bounded N b) :
    ∀i∈localRefs b,0 < i ∧ i < N := by
  intro i hi
  rcases List.mem_cons.mp hi with rfl|hi
  · exact h.2
  · obtain ⟨ts,ht,hi⟩:=List.mem_flatMap.mp hi
    exact tape N ts (h.1 ts ht) i hi

theorem goals (N : Nat) (ids : Nat → Nat) (j : Nat) (bs : List (Row×NativeScopedLocalGoal.Built))
    (hb : ∀b∈bs,ScopedReferenceBounds.Bounded N b.2)
    (hk : ∀i, j ≤ i → i < j+bs.length → 0 < i → 0 < ids i ∧ ids i < N) :
    ∀i∈goalRefs ids j bs,0 < i ∧ i < N := by
  induction bs generalizing j with
  | nil => simp [goalRefs]
  | cons b bs ih =>
    intro i hi
    simp only [goalRefs,List.mem_append] at hi
    rcases hi with (hi|hi)|hi
    · split at hi
      · simp at hi
      · have he:=List.mem_singleton.mp hi
        subst i
        exact hk j (by omega) (by simp) (by omega)
    · exact local_goal N b.2 (hb b (by simp)) i hi
    · exact ih (j+1) (fun b hb'=>hb b (by simp [hb']))
        (fun a ha hal hp=>hk a (by omega) (by simp only [List.length_cons] at *;omega) hp) i hi

theorem action (N : Nat) (ids : Nat → Nat) (a : NativeRecordedStep.Action)
    (h : ActionReferenceBounds.Bounded N ids a) : ∀i∈actionRefs ids a,0 < i ∧ i < N := by
  cases a with
  | pol ts => exact tape N ts h
  | consequence R b => exact local_goal N b h
  | red R w bs => exact goals N ids 0 bs h.1 (by intro i _ hi hp;exact h.2 i hp (by omega))

theorem body (N : Nat) (D : List Row) (s : Store) (ids : Nat → Nat) (p : Program)
    (h : ActionReferenceBounds.ProgramBound N D s ids p) :
    ∀i∈bodyRefs D s ids p,0 < i ∧ i < N := by
  induction p generalizing D s ids with
  | nil => simp [bodyRefs]
  | cons c cs ih =>
    intro i hi
    rcases List.mem_append.mp hi with hi|hi
    · exact action N ids _ h.1 i hi
    · exact ih _ _ _ h.2 i hi

def familyRefs (n : Nat) := bodyRefs (NativeRecordedFamily.original n)
  (initial (NativeRecordedFamily.original n)) id (RecordedUniformFamily.emitter n)

/-- Construction-specific ceiling for every intermediate reference appearing
in canonical POL lines, RED proofgoal keys, and local qed conclusions. -/
theorem family (n : Nat) (hn : 2 ≤ n) :
    ∀i∈familyRefs n,0 < i ∧ i < ConstructionClosedReference.nextBound n := by
  have hp:=(RecordedUniformFamily.recorded_refutation n hn).1
  have h:=ActionReferenceBounds.program 0 (RecordedUniformFamily.guard n) _ _
    (initial (NativeRecordedFamily.original n)) id _ (by change 0 < _+1;omega)
    (initial_embeds _) hp
  have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
    (initial (NativeRecordedFamily.original n)) id _ hp
  rw [←he] at h
  have hh:=ActionReferenceBounds.program_mono _ _ _ _ _ _ (ConstructionClosedReference.next_bound n hn) h
  exact body _ _ _ _ _ hh

theorem digit_width (n : Nat) (hn : 2 ≤ n) (i : Nat) (hi : i∈familyRefs n) :
    digits i ≤ digits (ConstructionClosedReference.nextBound n) :=
  digits_mono (Nat.le_of_lt (family n hn i hi).2)

/-- Signed-64 casts of ALL intermediate row references, with an explicit
closed size condition. This is not native Rust parser refinement. -/
theorem machine_cast (n : Nat) (hn : 2 ≤ n)
    (hlimit : ConstructionClosedReference.nextBound n ≤ CanonicalMachineReference.referenceLimit)
    (i : Nat) (hi : i∈familyRefs n) : (Int64.ofNat i).toInt=(i:Int) :=
  CanonicalMachineReference.positive_cast i (lt_of_lt_of_le (family n hn i hi).2 hlimit)

#print axioms family
#print axioms digit_width
#print axioms machine_cast
end L3Emitter.FamilyReferenceWidths

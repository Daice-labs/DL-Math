import Cardinality
import ReferenceTransport
import TemplateBinding

/- Explicit local POL certificates for the selector-elimination RED prefix.
   These certificates discharge the candidate's image from the ORIGINAL
   at-most-one row; they do not assume an oracle has proved that image.
   Whole-prefix correctness additionally needs original-row permutation and
   all previously appended rows. Those obligations are deliberately separate. -/
set_option linter.unusedSimpArgs false

namespace L3Emitter.NormalizationPOL
open EREF EREF.GeneralRED L3Emitter.REDWitness L3Emitter.Cardinality

def weakenLiterals (R : Row) : List Int → Row
  | [] => R
  | l :: ls => weakenLiterals (add R (litAxiom l)) ls

def weakenTokens (ls : List Int) : List Tok :=
  ls.flatMap (fun l => [.lit l, .add])

theorem eval_weaken (db : Nat → Option Row) (ls : List Int) (hz : Valid ls)
    (R : Row) (st : List Row) (tail : List Tok) :
    polEval db (weakenTokens ls ++ tail) (R :: st) =
      polEval db tail (weakenLiterals R ls :: st) := by
  induction ls generalizing R with
  | nil => rfl
  | cons l ls ih =>
    have hl : l ≠ 0 := hz l (by simp)
    simp only [weakenTokens, List.flatMap_cons, List.cons_append, List.nil_append,
      polEval, hl, ↓reduceIte, weakenLiterals]
    rw [if_pos hl]
    exact ih (by intro x hx; exact hz x (by simp [hx])) _

theorem weaken_values (R : Row) (hR : Canonical R) (ls : List Int)
    (hz : Valid ls) (α : Val) :
    Canonical (weakenLiterals R ls) ∧
      (weakenLiterals R ls).val α = R.val α + sum α ls := by
  induction ls generalizing R with
  | nil => simp [weakenLiterals, hR]
  | cons l ls ih =>
    have hl : l ≠ 0 := hz l (by simp)
    obtain ⟨hc,hv⟩ := ih (add R (litAxiom l)) (canonical_add _ _)
      (by intro x hx; exact hz x (by simp [hx]))
    refine ⟨hc, ?_⟩
    simp only [weakenLiterals]
    rw [hv, val_add _ _ hR (canonical_litAxiom _), val_litAxiom l hl, sum_cons]
    omega

theorem amo_perm (xs ys : List Int) (h : xs.Perm ys)
    (hx : Valid xs) (hy : Valid ys) : amo xs = amo ys := by
  apply canonical_ext _ _ (canonical_amo _) (canonical_amo _)
  intro α
  rw [val_amo _ hx, val_amo _ hy, h.length_eq]
  have hs := List.Perm.sum_eq ((h.map Neg.neg).map (litVal α))
  unfold sum
  rw [hs]

theorem amo_weaken_pair (x y : Int) (rest : List Int)
    (hx : x ≠ 0) (hy : y ≠ 0) (hr : Valid rest) :
    weakenLiterals (amo (x :: y :: rest)) rest = pair x y := by
  have hall : Valid (x :: y :: rest) := by
    intro l hl
    simp only [List.mem_cons] at hl
    rcases hl with rfl | rfl | hl
    · exact hx
    · exact hy
    · exact hr l hl
  apply canonical_ext _ _ (weaken_values _ (canonical_amo _) rest hr (fun _ => false)).1
    (canonical_pair _ _)
  intro α
  rw [(weaken_values _ (canonical_amo _) rest hr α).2, val_amo _ hall, val_pair _ _ hx hy]
  have hs := CaseJoin.complement_sum α rest hr
  simp only [sum, List.map_map, Function.comp_def] at hs
  simp only [List.map_cons, sum_cons, List.length_cons, Nat.cast_add, Nat.cast_one]
  change litVal α (-x) + (litVal α (-y) + _) - _ + 1 + _ = _
  simp only [sum, List.map_map, Function.comp_def]
  omega

def pairTokens (amoRef : Nat) (rest : List Int) : List Tok :=
  [.ref amoRef] ++ weakenTokens rest

/-- Linear-size recipe for any selected pair in the actual n-ary AMO row. -/
theorem pair_succeeds (db : Nat → Option Row) (amoRef : Nat)
    (xs : List Int) (x y : Int) (rest : List Int)
    (hx : x ≠ 0) (hy : y ≠ 0) (hr : Valid rest) (hxs : Valid xs)
    (hp : xs.Perm (x :: y :: rest)) (ha : db amoRef = some (amo xs)) :
    polEval db (pairTokens amoRef rest) [] = some (pair x y) := by
  have hall : Valid (x :: y :: rest) := by
    intro l hl
    rcases List.mem_cons.mp hl with rfl | hl
    · exact hx
    rcases List.mem_cons.mp hl with rfl | hl
    · exact hy
    · exact hr l hl
  rw [amo_perm _ _ hp hxs hall] at ha
  simp only [pairTokens, List.cons_append, List.nil_append, polEval, ha]
  have he := eval_weaken db rest hr (amo (x :: y :: rest)) [] []
  simp only [List.append_nil] at he
  rw [he, amo_weaken_pair x y rest hx hy hr]
  rfl

def imageTokens (amoRef currentRows : Nat) (rest : List Int) : List Tok :=
  pairTokens amoRef rest ++
    [.ref (currentRows+1), .add, .ref (currentRows+2), .add]

/-- The candidate is not-y, and its transposition image is not-x. Under
    not(candidate), the original AMO forces that image. All reference IDs,
    weakening literals, and contradiction rows are explicit. -/
theorem candidate_image_certificate (rows : List Row) (amoRef : Nat)
    (xs : List Int) (x y : Int) (rest : List Int)
    (hx : x ≠ 0) (hy : y ≠ 0) (hr : Valid rest) (hxs : Valid xs)
    (hp : xs.Perm (x :: y :: rest))
    (ha : dbOf rows amoRef = some (amo xs)) :
    LocalCertificate rows (clause [-y]) (clause [-x]) := by
  let C := clause [-y]
  let G := clause [-x]
  let db := dbOf (rows ++ [negate C, negate G])
  have ha' : db amoRef = some (amo xs) := by
    dsimp only [db]
    rw [dbOf_append_le rows _ amoRef (dbOf_le_length rows _ _ ha)]
    exact ha
  have hall : Valid (x :: y :: rest) := by
    intro l hl
    simp only [List.mem_cons] at hl
    rcases hl with rfl | rfl | hl
    · exact hx
    · exact hy
    · exact hr l hl
  have hw := amo_weaken_pair x y rest hx hy hr
  rw [← amo_perm _ _ hp hxs hall] at hw
  let out := add (add (pair x y) (negate C)) (negate G)
  refine ⟨imageTokens amoRef rows.length rest, out, ?_, ?_⟩
  · change polEval db (imageTokens amoRef rows.length rest) [] = some out
    simp only [imageTokens, pairTokens, List.append_assoc, List.cons_append,
      List.nil_append, polEval, ha']
    rw [eval_weaken _ _ hr, hw]
    simp [polEval, db_neg_left, db_neg_right, db, out, C, G]
  · apply (canonical_contra_iff _ (canonical_add _ _)).mpr
    intro α hs
    have hc : Canonical C := canonical_normalize _ _
    have hg : Canonical G := canonical_normalize _ _
    have hv : out.val α = -1 := by
      dsimp only [out]
      rw [val_add _ _ (canonical_add _ _) (canonical_negate _),
        val_add _ _ (canonical_pair _ _) (canonical_negate _),
        val_pair _ _ hx hy, val_negate C hc, val_negate G hg]
      dsimp only [C, G]
      rw [val_clause _ (by intro l hl; simp at hl; subst l; omega),
        val_clause _ (by intro l hl; simp at hl; subst l; omega)]
      simp
      ring
    unfold Row.sat at hs
    rw [hv] at hs
    omega

theorem image_token_count (r m : Nat) (rest : List Int) :
    (imageTokens r m rest).length = 2*rest.length+5 := by
  simp [imageTokens, pairTokens, weakenTokens, List.length_flatMap,
    List.map_map, Function.comp_def]
  omega

#print axioms pair_succeeds
#print axioms candidate_image_certificate
#print axioms image_token_count
end L3Emitter.NormalizationPOL

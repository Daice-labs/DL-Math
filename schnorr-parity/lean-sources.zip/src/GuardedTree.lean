import GuardedGatePOL

namespace L3Emitter.GuardedTree
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL

/-- A local expression with actual allocated output references. Leaf values
are case assumptions, discharged by explicit rows at the call site. -/
inductive Tree where
  | leaf : Bit→Bool→Tree
  | link : Tree→Bit→Bool→Tree
  | node : Bool→Tree→Tree→Bit→Tree

def Tree.root : Tree→Bit
  | .leaf q _=>q
  | .link _ q _=>q
  | .node _ _ _ q=>q
def Tree.value : Tree→Bool
  | .leaf _ v=>v
  | .link _ _ v=>v
  | .node b l r _=>GuardedGatePOL.value b l.value r.value
def Tree.count : Tree→Nat
  | .leaf _ _=>0
  | .link t _ _=>t.count+1
  | .node _ l r _=>l.count+r.count+1
def Tree.leaves : Tree→List (Bit×Bool)
  | .leaf q v=>[(q,v)]
  | .link t _ _=>t.leaves
  | .node _ l r _=>l.leaves++r.leaves
def Tree.Ready (D:List Row) : Tree→Prop
  | .leaf _ _=>True
  | .link t q v=>t.Ready D ∧ clause [-sign t.value t.root,sign v q]∈D
  | .node b l r q=>l.Ready D ∧ r.Ready D ∧ BinaryRows D b l.root r.root q
def Tree.Assumptions (D:List Row) (G:List Int) (t:Tree) :=
  ∀x∈t.leaves,guarded G (sign x.2 x.1)∈D
def Tree.rows (G:List Int) : Tree→List Row
  | .leaf _ _=>[]
  | .link t q v=>t.rows G++[guarded G (sign v q)]
  | .node b l r q=>l.rows G++r.rows G++[guarded G (sign (GuardedGatePOL.value b l.value r.value) q)]
def Tree.program (G:List Int) (D:List Row) : Tree→Program
  | .leaf _ _=>[]
  | .link t q v=>t.program G D++[(guarded G (sign v q),oneTape (D++t.rows G) G (sign t.value t.root) (sign v q))]
  | .node b l r q=>l.program G D++r.program G (D++l.rows G)++
      [(guarded G (sign (GuardedGatePOL.value b l.value r.value) q),
        tape (D++l.rows G++r.rows G) G b l.value r.value l.root r.root q)]

theorem Tree.Ready.mono {D E:List Row} {t:Tree} (h:t.Ready D)
    (hm:∀R∈D,R∈E) : t.Ready E := by
  induction t with
  | leaf q v=>trivial
  | link t q v ih=>exact ⟨ih h.1,hm _ h.2⟩
  | node b l r q hl hr=>exact ⟨hl h.1,hr h.2.1,h.2.2.mono hm⟩
theorem Tree.Assumptions.mono {D E:List Row} {G:List Int} {t:Tree} (h:t.Assumptions D G)
    (hm:∀R∈D,R∈E) : t.Assumptions E G := fun x hx=>hm _ (h x hx)

theorem Tree.output_mem (t:Tree) (D:List Row) (G:List Int) (ha:t.Assumptions D G) :
    guarded G (sign t.value t.root)∈D++t.rows G := by
  cases t with
  | leaf q v=>exact List.mem_append_left _ (ha (q,v) (by simp [Tree.leaves]))
  | link t q v=>exact List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _))
  | node b l r q=>exact List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _))

theorem Tree.checks (t:Tree) (D:List Row) (G:List Int) (hg:Valid G)
    (hr:t.Ready D) (ha:t.Assumptions D G) :
    check D (t.program G D)=some (D++t.rows G) := by
  induction t generalizing D with
  | leaf q v=>simp [Tree.program,Tree.rows,check]
  | link t q v ih=>
    have h1:=ih D hr.1 ha
    have he:=one_check (D++t.rows G) G (sign t.value t.root) (sign v q) hg
      (sign_valid _ _) (sign_valid _ _) (t.output_mem D G ha) (List.mem_append_left _ hr.2)
    have h2:check (D++t.rows G) [(guarded G (sign v q),oneTape (D++t.rows G) G (sign t.value t.root) (sign v q))]=
        some ((D++t.rows G)++[guarded G (sign v q)]) := by simp only [check,he,↓reduceIte]
    simpa only [Tree.program,Tree.rows,List.append_assoc] using check_append _ _ _ _ _ h1 h2
  | node b l r q hl hright=>
    have al:l.Assumptions D G:=fun x hx=>ha x (List.mem_append_left _ hx)
    have ar:r.Assumptions D G:=fun x hx=>ha x (List.mem_append_right _ hx)
    have keep:∀R∈D,R∈D++l.rows G:=fun R h=>List.mem_append_left _ h
    have kp:∀R∈D,R∈D++l.rows G++r.rows G:=fun R h=>List.mem_append_left _ (keep R h)
    have h1:=hl D hr.1 al
    have h2:=hright (D++l.rows G) (hr.2.1.mono keep) (ar.mono keep)
    have hc:=binary_check (D++l.rows G++r.rows G) G b l.value r.value l.root r.root q hg
      (hr.2.2.mono kp) (List.mem_append_left _ (l.output_mem D G al))
      (r.output_mem (D++l.rows G) G (ar.mono keep))
    have h3:check (D++l.rows G++r.rows G)
        [(guarded G (sign (GuardedGatePOL.value b l.value r.value) q),
          tape (D++l.rows G++r.rows G) G b l.value r.value l.root r.root q)]=
        some ((D++l.rows G++r.rows G)++[guarded G (sign (GuardedGatePOL.value b l.value r.value) q)]) := by
      simp only [check,hc,↓reduceIte]
    have h12:=check_append _ _ _ _ _ h1 h2
    simpa only [Tree.program,Tree.rows,List.append_assoc] using check_append _ _ _ _ _ h12 h3

theorem Tree.rows_count (t:Tree) (G:List Int) : (t.rows G).length=t.count := by
  induction t with
  | leaf q v=>rfl
  | link t q v ih=>simp [Tree.rows,Tree.count,ih]
  | node b l r q hl hr=>simp [Tree.rows,Tree.count,hl,hr,Nat.add_assoc]
theorem Tree.commands_count (t:Tree) (D:List Row) (G:List Int) : (t.program G D).length=t.count := by
  induction t generalizing D with
  | leaf q v=>rfl
  | link t q v ih=>simp [Tree.program,Tree.count,ih]
  | node b l r q hl hr=>simp [Tree.program,Tree.count,hl,hr,Nat.add_assoc]
theorem Tree.tokens_bound (t:Tree) (D:List Row) (G:List Int) :
    PrioritySize.tokensCount (t.program G D)≤8*t.count := by
  induction t generalizing D with
  | leaf q v=>simp [Tree.program,Tree.count,PrioritySize.tokensCount]
  | link t q v ih=>
    have h:=ih D
    simp only [Tree.program]
    rw [PrioritySize.tokens_append]
    change PrioritySize.tokensCount (t.program G D)+(3+0)≤8*(t.count+1)
    omega
  | node b l r q hl hr=>
    have h1:=hl D
    have h2:=hr (D++l.rows G)
    have h3:=tape_length (D++l.rows G++r.rows G) G b l.value r.value l.root r.root q
    simp only [Tree.program]
    rw [PrioritySize.tokens_append,PrioritySize.tokens_append]
    change PrioritySize.tokensCount (l.program G D)+PrioritySize.tokensCount (r.program G (D++l.rows G))+
      ((tape (D++l.rows G++r.rows G) G b l.value r.value l.root r.root q).length+0)≤8*(l.count+r.count+1)
    omega

#print axioms Tree.checks
#print axioms Tree.tokens_bound
end L3Emitter.GuardedTree

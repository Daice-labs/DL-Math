import ConstructionRelationCount
set_option maxHeartbeats 800000

namespace L3Emitter.ConstructionAuxCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount

theorem units (n : Nat) (hn : 2≤n) :
    (UnitAliasBank.program n hn).length≤500*(n+1)^3 := by
  have he:=checked_body _ _ _ (UnitAliasBank.checks n hn)
  rw [he]
  have h:=flat_bound (List.range (AliasAssembly.width (n+1)))
    (fun j=>PrimaryAliasRows.body (PrimaryAliasBank.cfg n hn) (j+1) (AliasAssembly.width (n+1)))
    (1+(AliasAssembly.width (n+1))^2) (by
      intro j hj
      simp only [PrimaryAliasRows.body,List.length_map]
      exact ConstructionOneHotCount.specifications _)
  simp only [List.length_range] at h
  have hw:=AliasAssembly.width_bound (n+1)
  have hs:=Nat.pow_le_pow_left hw 2
  have hp:=Nat.mul_le_mul hw (Nat.add_le_add_left hs 1)
  exact h.trans (by nlinarith [hp,Nat.zero_le (n^3)])

theorem aux_job (n : Nat) (hn : 2≤n) (j : SourceAuxBank.Job n) :
    (SourceAuxBank.jobRows n hn j).length≤10 := by
  cases j with
  | rank g i t=>
    simp only [SourceAuxBank.jobRows,RankCoordinate.rows,RankConstantLinks.rows]
    cases h:RankCoordinate.truth n i t <;>
      norm_num [RankCoordinate.prepRows,RankConstantLinks.localRows,RankConstantLinks.seedRows,
        RankConstantLinks.seed,outputs,SourceMixture.rankTree,GuardedTree.Tree.rows,
        RankConstantLinks.linkRows,h]
  | mux g i=>exact (show (RecordedExpressions.jobRows (SourceMuxSnapshots.actual n hn g i)).length=4 from rfl).le.trans (by omega)

theorem auxiliaries (n : Nat) (hn : 2≤n) :
    (SourceAuxBank.program n hn).length≤1000*(n+1)^3 := by
  have he:=checked_body _ _ _ (SourceAuxBank.checks n hn)
  rw [he]
  have h:=flat_bound (SourceAuxBank.jobs n) (SourceAuxBank.jobRows n hn) 10 (fun j hj=>aux_job n hn j)
  have hj:(SourceAuxBank.jobs n).length=(SourceRelationBank.jobs n).length*(1+RankConstruction.width (n+1)):=by
    unfold SourceAuxBank.jobs
    exact flat_exact _ _ _ (by intro j hj;simp [Nat.add_comm])
  rw [hj,source_jobs] at h
  have hw:=AliasAssembly.width_bound (n+1)
  have hr:1+RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hg:3*(n+1)-5≤3*(n+1):=Nat.sub_le ..
  have hp:=Nat.mul_le_mul (Nat.mul_le_mul hg hw) hr
  exact h.trans (by nlinarith [Nat.mul_le_mul_right 10 hp,Nat.zero_le (n^3)])

theorem card_loop (n : Nat) (hn : 2≤n) (js : List Nat) (D : List Row) :
    (AllSourceCardinalities.loop n hn D js).length≤js.length*AliasAssembly.width (n+1) := by
  induction js generalizing D with
  | nil=>simp [AllSourceCardinalities.loop]
  | cons j js ih=>
    have h:=OneHotSize.commands_bound D (AllSourceCardinalities.xs n hn j)
    simp only [AllSourceCardinalities.xs,SelectedVectorOneHot.sourceLiterals,List.length_ofFn] at h
    simp only [AllSourceCardinalities.loop,List.length_append,List.length_cons]
    exact (Nat.add_le_add h (ih _)).trans_eq (by ring)

theorem cardinalities (n : Nat) (hn : 2≤n) :
    (AllSourceCardinalities.program n hn).length≤24*(n+1)^2 := by
  have h:=card_loop n hn (AllSourceCardinalities.ids n) (GateOrderSources.fullResult n hn)
  simp only [AllSourceCardinalities.ids,List.length_range] at h
  have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  have hg:n+1+(3*(n+1)-4)≤4*(n+1):=by omega
  exact h.trans ((Nat.mul_le_mul hg hw).trans (show 4*(n+1)*(4*(n+1))≤24*(n+1)^2 by nlinarith))

theorem unary_rows (n : Nat) (hn : 2≤n) (g : Nat) (b : Bool) :
    (UnaryCategoryProgram.rows n hn g b).length≤60*(n+1) := by
  have h:=flat_exact (CategoryMixtureProgram.ranks n)
    (fun t=>MixtureRank.rows (UnarySnapshots.actual n hn g b) (GateCategories.bit n hn g (.rank t))) 9
    (by intro t ht;rfl)
  simp only [CategoryMixtureProgram.ranks,List.length_range] at h
  simp only [UnaryCategoryProgram.rows,List.length_append]
  change 2+12+12+_≤60*(n+1)
  unfold CategoryMixtureProgram.rankRows CategoryMixtureProgram.ranks
  rw [h]
  unfold RankConstruction.width
  omega

theorem unary_relations (n : Nat) (hn : 2≤n) :
    (UnaryRelationBank.program n hn).length≤360*(n+1)^2 := by
  have he:=checked_body _ _ _ (UnaryRelationBank.checks n hn)
  rw [he]
  have h:=flat_bound (UnaryRelationBank.jobs n) (UnaryRelationBank.jobRows n hn) (60*(n+1))
    (fun j hj=>unary_rows n hn j.1 j.2)
  have hj:(UnaryRelationBank.jobs n).length=(3*(n+1)-5)*2:=by
    unfold UnaryRelationBank.jobs
    rw [flat_exact _ _ 2 (by intro g hg;rfl),gates]
  rw [hj] at h
  exact h.trans (by
    have hh:=Nat.mul_le_mul_right (2*(60*(n+1))) (Nat.sub_le (3*(n+1)) 5)
    nlinarith)

#print axioms units
#print axioms auxiliaries
#print axioms cardinalities
#print axioms unary_relations
end L3Emitter.ConstructionAuxCount

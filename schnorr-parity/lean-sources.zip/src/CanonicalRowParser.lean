import CanonicalFormulaReadback

namespace L3Emitter.CanonicalRowParser
open EREF TemplateBytes CanonicalScopedBytes

/-- Lexer for the canonical single-space row fragment. Empty fields, including
the leading space on a zero-term row, are ignored. -/
def lex (bs : Bytes) : List Bytes := (bs.splitOn 32).filter (fun x=>!x.isEmpty)

theorem lex_space (a b : Bytes) : lex (a++32::b)=lex a++lex b := by
  simp [lex,List.splitOn_append_cons_self]

theorem lex_word (w : Bytes) (hn : w≠[]) (hs : (32:UInt8)∉w) : lex w=[w] := by
  simp [lex,List.splitOn_eq_singleton hs,hn]

theorem decimal_nonempty (n : Nat) : decimal n≠[] := by
  intro he
  have h:=decimal_length n
  have hp:=digits_pos n
  simp [he] at h
  omega

theorem decimal_no_space (n : Nat) : (32:UInt8)∉decimal n := by
  intro h
  obtain ⟨c,hc,he⟩:=List.mem_map.mp h
  have hd:=Nat.isDigit_of_mem_toDigits (by decide : 0<10) (by decide : 10≤10) hc
  have hr:48≤c.toNat ∧ c.toNat≤57:=by
    simpa only [Char.isDigit,Bool.and_eq_true,decide_eq_true_eq] using hd
  have hh:=congrArg UInt8.toNat he
  rw [UInt8.toNat_ofNat',Nat.mod_eq_of_lt (by omega)] at hh
  change c.toNat=32 at hh
  omega

theorem lex_decimal (n : Nat) : lex (decimal n)=[decimal n] :=
  lex_word _ (decimal_nonempty n) (decimal_no_space n)

theorem literal_nonempty (l : Literal) : emit (literal l)≠[] := by
  rw [LiteralParser.encoded]
  cases l.negative <;> simp

theorem literal_no_space (l : Literal) : (32:UInt8)∉emit (literal l) := by
  rw [LiteralParser.encoded]
  cases l.negative <;> simp [decimal_no_space]

theorem lex_literal (l : Literal) : lex (emit (literal l))=[emit (literal l)] :=
  lex_word _ (literal_nonempty l) (literal_no_space l)

theorem integer_nonempty (z : Int) : emit (integer z)≠[] := by
  unfold integer
  split
  · simp [emit_append,emit,number,Piece.emit,decimal_nonempty]
  · simpa [emit,number,Piece.emit] using decimal_nonempty z.natAbs

theorem integer_no_space (z : Int) : (32:UInt8)∉emit (integer z) := by
  unfold integer
  split
  · have he : emit (fixed "-")=([45]:Bytes) := by
      simp [emit,fixed,Piece.emit,ascii]
      rfl
    simp only [emit_append,he,List.mem_append,List.mem_cons,List.not_mem_nil,or_false]
    simpa [emit,number,Piece.emit] using decimal_no_space z.natAbs
  · simpa [emit,number,Piece.emit] using decimal_no_space z.natAbs

theorem lex_integer (z : Int) : lex (emit (integer z))=[emit (integer z)] :=
  lex_word _ (integer_nonempty z) (integer_no_space z)

def termWords (t : Nat×Literal) : List Bytes := [decimal t.1,emit (literal t.2)]
def rowWords (r : PBRow) : List Bytes :=
  r.terms.flatMap termWords ++ [[62,61],emit (integer r.rhs)]

theorem term_lex (t : Nat×Literal) :
    lex (emit (number t.1++fixed " "++literal t.2))=termWords t := by
  change lex (decimal t.1++32::emit (literal t.2))=_
  rw [lex_space,lex_decimal,lex_literal]
  rfl

theorem separated_lex (ds : List Doc) :
    lex (emit (separated (fixed " ") ds))=ds.flatMap (fun d=>lex (emit d)) := by
  induction ds with
  | nil=>rfl
  | cons d ds ih=>
    cases ds with
    | nil=>simp [separated]
    | cons e es=>
      have he:emit (separated (fixed " ") (d::e::es))=
          emit d++32::emit (separated (fixed " ") (e::es)):=by
        simp [separated,emit,Piece.emit,fixed,ascii,List.append_assoc]
        rfl
      rw [he,lex_space,ih]
      rfl

/-- Actual ASCII bytes, rather than a list of already parsed fields. -/
theorem row_lex (r : PBRow) : lex (emit (row r))=rowWords r := by
  have he:emit (row r)=
      emit (separated (fixed " ") (r.terms.map (fun t=>number t.1++fixed " "++literal t.2)))++
      32::[62,61]++32::emit (integer r.rhs):=by
    simp [row,emit,Piece.emit,fixed,ascii,List.append_assoc]
    rfl
  rw [he]
  rw [show (emit (separated (fixed " ") (r.terms.map (fun t=>number t.1++fixed " "++literal t.2)))++
      32::[62,61]++32::emit (integer r.rhs))=
      emit (separated (fixed " ") (r.terms.map (fun t=>number t.1++fixed " "++literal t.2)))++
      32::([62,61]++32::emit (integer r.rhs)) by simp [List.append_assoc]]
  rw [lex_space,lex_space,separated_lex,lex_integer]
  simp only [List.flatMap_map,Function.comp_def,term_lex]
  rfl

def parseWords : List Bytes→Option PBRow
  | []=>none
  | a::rest=>
    match DecimalParser.parse a with
    | some c=>match rest with
      | []=>none
      | b::tail=>do
        let l←LiteralParser.parse b
        let r←parseWords tail
        return ⟨(c,l)::r.terms,r.rhs⟩
    | none=>if a=[62,61] then match rest with
      | [rhs]=>do return ⟨[],←LiteralParser.integer rhs⟩
      | _=>none
      else none

def parse (bs : Bytes) := parseWords (lex bs)

theorem words_roundtrip (r : PBRow) (hv : ∀ t∈r.terms,0<t.2.varId) :
    parseWords (rowWords r)=some r := by
  rcases r with ⟨ts,rhs⟩
  induction ts with
  | nil=>
    change (LiteralParser.integer (emit (integer rhs))).bind (fun z=>some (PBRow.mk [] z))=some _
    rw [LiteralParser.integer_roundtrip]
    rfl
  | cons t ts ih=>
    have ht:=hv t (by simp)
    have hi:=ih (by intro u hu;exact hv u (by simp [hu]))
    change parseWords (decimal t.1::emit (literal t.2)::rowWords ⟨ts,rhs⟩)=_
    rw [parseWords,DecimalParser.roundtrip]
    · simp only [LiteralParser.roundtrip _ ht,hi]
      rfl
    · simp [rowWords]

theorem row_roundtrip (r : PBRow) (hv : ∀ t∈r.terms,0<t.2.varId) :
    parse (emit (row r))=some r := by
  rw [parse,row_lex]
  exact words_roundtrip r hv

theorem original_row_roundtrip (R : EREF.Row) (hR : Canonical R) :
    parse (emit (rowDoc R))=some (pbRow R) := by
  apply row_roundtrip
  intro t ht
  obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht
  exact Int.natAbs_pos.mpr ((hR.1 u hu).2)

#print axioms row_lex
#print axioms words_roundtrip
#print axioms row_roundtrip
#print axioms original_row_roundtrip
end L3Emitter.CanonicalRowParser

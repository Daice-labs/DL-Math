import ConstructionCoverageBounds
import RecordedBranchCost

namespace L3Emitter.ConstructionFrontendBounds
open EREF EREF.GeneralRED L3 L3.Fam RecordedScopedTrace CanonicalReplayEnvelope RecordedReplayCost
open ConstructionLocalTools ConstructionFoldBounds ConstructionCoverageBounds

theorem outputSplit (F : Fam) (t : StI F.V) (p b : Nat) (D : List EREF.Row) :
    BoundedProgram (cap F F.s) (RecordedOutputSplit.program F t p b D) := by
  apply split
  · unfold cap;omega
  · intro E c
    dsimp only [RecordedOutputSplit.leaf,RecordedOutputSplit.certificate]
    rw [ConstructionCoverageBounds.chain]
    simp only [outLeafRows,List.length_append,List.length_cons,List.length_nil]
    split <;> simp only [List.length_cons,List.length_nil] <;> unfold cap <;> omega

theorem outputUnits (F : Fam) (t : StI F.V) (p : Nat) :
    BoundedProgram (cap F F.s) (RecordedOutputUnits.program F t p) := by
  intro c hc
  rcases List.mem_cons.mp hc with rfl|hc
  · apply consequence
    dsimp only [RecordedOutputUnits.forceCertificate]
    rw [ConstructionCoverageBounds.chain]
    simp only [List.length_cons,List.length_nil]
    unfold cap;omega
  · obtain rfl:=List.mem_singleton.mp hc
    apply consequence
    dsimp only [RecordedOutputUnits.portCertificate]
    rw [ConstructionCoverageBounds.chain]
    simp only [List.length_cons,List.length_nil]
    unfold cap;omega

theorem stage6 (F : Fam) (t : StI F.V) :
    BoundedProgram (cap F F.s) (RecordedStage6.program F t) := by
  apply append
  · apply append
    · exact fold _ _ _ _ _ (fun u pb=>outputSplit F u pb.1 pb.2 _)
    · exact fold _ _ _ _ _ (fun u p=>outputUnits F u p)
  · apply ConstructionFoldBounds.singleton
    apply consequence
    dsimp only [RecordedConsumer.finalCertificate]
    rw [ConstructionCoverageBounds.chain]
    simp only [List.length_cons,List.length_nil]
    unfold cap;omega

theorem branch (F : Fam) (t : StI F.V) (brs : List Int) (b : Nat) :
    BoundedProgram (cap F F.s) (RecordedBranchRups.program F t brs b) := by
  apply ConstructionFoldBounds.singleton
  apply consequence
  calc
    _ = 16*(F.s-1-b)+5 := RecordedBranchCost.branch_tokens F t brs b _
    _ ≤ cap F F.s := by unfold cap;omega

theorem stage7 (F : Fam) (t : StI F.V) :
    BoundedProgram (cap F F.s) (RecordedStage7.program F t) := by
  apply append
  · apply append
    · exact CanonicalFamilyEnvelope.bounded_mono 3 _ _ (by unfold cap;omega) (suffix _ _ _ _)
    · exact fold _ _ _ _ _ (fun u b=>branch F u _ b)
  · apply ConstructionFoldBounds.singleton
    apply consequence
    calc
      _ = 4*(F.s-2)+7 := RecordedBranchCost.merge_tokens F _ _
      _ ≤ cap F F.s := by unfold cap;omega

/-- All local certificates of the ACTUAL complete frontend, including coverage
and every RUP leaf, bounded in input arity k and gate budget s only. -/
theorem frontend (k s : Nat) (hk : 2≤k) (hs : 1≤s) :
    BoundedProgram (100*(k+2*s+1)) (RecordedFrontendComplete.program k s hs) := by
  let F:=FableEncoding.fam k s
  have hcap:cap F F.s=100*(k+2*s+1):=by dsimp [cap,F,FableEncoding.fam,L3.parityFam];omega
  rw [←hcap]
  apply append
  · apply append
    · apply append
      · exact CanonicalFamilyEnvelope.bounded_mono (2*k+13) _ _
          (by rw [hcap];omega) (throughStage4 k s hs)
      · exact stage5 F hk _ _
    · exact stage6 F _
  · exact stage7 F _

theorem base : BoundedProgram 700 RecordedBaseTwo.program :=
  append _ _ _ (frontend 2 2 (by decide) (by decide)) (polProgram 700 _)

#print axioms frontend
#print axioms base
end L3Emitter.ConstructionFrontendBounds

import EREF_Lemma3

/-!
General simultaneous witnesses and RED preservation over the exact EREF row/POL algebra.
This module does not assert that an arbitrary Python execution implements these objects,
or that semantic model preservation supplies polynomial EF proofs.
-/
namespace EREF
namespace GeneralRED

inductive Image where
  | literal (l : Int) (nonzero : l ≠ 0)
  | constant (b : Bool)

def Image.eval (α : Val) : Image → Bool
  | .literal l _ => if 0 < l then α l.natAbs else !(α l.natAbs)
  | .constant b => b

def Image.flip : Image → Image
  | .literal l h => .literal (-l) (by omega)
  | .constant b => .constant (!b)

theorem b2i_not (b : Bool) : b2i (!b) = 1 - b2i b := by cases b <;> decide

theorem eval_literal (α : Val) (l : Int) (h : l ≠ 0) :
    b2i ((Image.literal l h).eval α) = litVal α l := by
  simp only [Image.eval, litVal]; split
  · rfl
  · exact b2i_not _

theorem eval_flip (α : Val) (x : Image) :
    b2i (x.flip.eval α) = 1 - b2i (x.eval α) := by
  cases x with
  | literal l h => simp only [Image.flip]; rw [eval_literal, eval_literal, litVal_neg α l h]
  | constant b => exact b2i_not b

abbrev Witness := Nat → Image

/-- All right-hand sides are evaluated in the old assignment, including cyclic aliases. -/
def applyWitness (ω : Witness) (α : Val) : Val := fun v => (ω v).eval α

def imageOf (ω : Witness) (l : Int) : Image :=
  if 0 < l then ω l.natAbs else (ω l.natAbs).flip

theorem eval_imageOf (ω : Witness) (α : Val) (l : Int) :
    b2i ((imageOf ω l).eval α) = litVal (applyWitness ω α) l := by
  unfold imageOf litVal applyWitness
  split
  · rfl
  · exact eval_flip _ _

def Image.raw (a : Nat) : Image → List (Int × Int)
  | .literal l _ => [(a, l)]
  | .constant _ => []

def Image.offset (a : Nat) : Image → Int
  | .literal _ _ => 0
  | .constant b => (a : Int) * b2i b

theorem raw_nonzero (a : Nat) (x : Image) : ∀ t ∈ x.raw a, t.2 ≠ 0 := by
  cases x with
  | literal l h => intro t ht; simp only [Image.raw, List.mem_singleton] at ht; subst t; exact h
  | constant b => simp [Image.raw]

theorem raw_value (α : Val) (a : Nat) (x : Image) :
    tvalZ α (x.raw a) + x.offset a = (a : Int) * b2i (x.eval α) := by
  cases x with
  | literal l h => simp [Image.raw, Image.offset, tvalZ, eval_literal]
  | constant b => simp [Image.raw, Image.offset, tvalZ, Image.eval]

def rawTerms (ω : Witness) : List (Nat × Int) → List (Int × Int)
  | [] => []
  | (a,l) :: ts => (imageOf ω l).raw a ++ rawTerms ω ts

def offset (ω : Witness) : List (Nat × Int) → Int
  | [] => 0
  | (a,l) :: ts => (imageOf ω l).offset a + offset ω ts

theorem rawTerms_nonzero (ω : Witness) (ts : List (Nat × Int)) :
    ∀ t ∈ rawTerms ω ts, t.2 ≠ 0 := by
  induction ts with
  | nil => simp [rawTerms]
  | cons t ts ih =>
    intro u hu
    rcases List.mem_append.mp hu with h | h
    · exact raw_nonzero t.1 (imageOf ω t.2) u h
    · exact ih u h

theorem tvalZ_append_local (α : Val) (xs ys : List (Int × Int)) :
    tvalZ α (xs ++ ys) = tvalZ α xs + tvalZ α ys := by
  induction xs with
  | nil => simp [tvalZ]
  | cons x xs ih => simp only [List.cons_append, tvalZ, ih]; omega

theorem rawTerms_value (ω : Witness) (α : Val) (ts : List (Nat × Int)) :
    tvalZ α (rawTerms ω ts) + offset ω ts = tval (applyWitness ω α) ts := by
  induction ts with
  | nil => simp [rawTerms, offset, tvalZ, tval]
  | cons t ts ih =>
    obtain ⟨a,l⟩ := t
    simp only [rawTerms, offset, tval, tvalZ_append_local]
    have h := raw_value α a (imageOf ω l)
    rw [eval_imageOf] at h
    omega

def substRow (R : Row) (ω : Witness) : Row :=
  normalize (rawTerms ω R.terms) (R.bound - offset ω R.terms)

theorem canonical_substRow (R : Row) (ω : Witness) : Canonical (substRow R ω) :=
  canonical_normalize _ _

/-- Exact normalized substitution equality, for all assignments and simultaneous maps. -/
theorem val_substRow (R : Row) (ω : Witness) (α : Val) :
    (substRow R ω).val α = R.val (applyWitness ω α) := by
  unfold substRow
  rw [val_normalize α _ _ (rawTerms_nonzero ω R.terms)]
  have h := rawTerms_value ω α R.terms
  unfold Row.val
  omega

theorem sat_substRow (R : Row) (ω : Witness) (α : Val) :
    (substRow R ω).sat α ↔ R.sat (applyWitness ω α) := by
  unfold Row.sat; rw [val_substRow]

/-- A local goal certificate has an arbitrary syntactically contradictory POL output. -/
def LocalCertificate (rows : List Row) (C G : Row) : Prop :=
  ∃ toks out, polEval (dbOf (rows ++ [negate C, negate G])) toks [] = some out ∧ Contra out

/-- Every canonical old row and the candidate must be covered, under the same witness. -/
def Obligations (rows : List Row) (C : Row) (ω : Witness) : Prop :=
  ∀ R ∈ C :: rows, LocalCertificate rows C (substRow R ω)

theorem local_goal_sound (rows : List Row) (C G : Row)
    (hc : ∀ R ∈ rows, Canonical R) (hC : Canonical C) (hG : Canonical G)
    (cert : LocalCertificate rows C G) (α : Val)
    (hs : ∀ R ∈ rows, R.sat α) (hnC : ¬ C.sat α) : G.sat α := by
  classical
  apply Classical.byContradiction
  intro hnG
  obtain ⟨toks, out, heval, hcontra⟩ := cert
  have hdb : GoodDb (dbOf (rows ++ [negate C, negate G])) α := by
    intro i R hi
    have hm := dbOf_mem _ _ _ hi
    simp only [List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with hm | rfl | rfl
    · exact ⟨hc R hm, hs R hm⟩
    · exact ⟨canonical_negate C, (sat_negate_iff C hC α).mpr hnC⟩
    · exact ⟨canonical_negate G, (sat_negate_iff G hG α).mpr hnG⟩
  have hout := polEval_sound _ α hdb toks [] (by simp) out heval
  exact (canonical_contra_iff out hout.1).mp hcontra α hout.2

/-- General RED preserves satisfiability of the entire extended database, with one
    common model. It does not require a fresh or acyclic witness. -/
theorem red_preserves_model (rows : List Row) (C : Row) (ω : Witness)
    (hc : ∀ R ∈ rows, Canonical R) (hC : Canonical C)
    (ho : Obligations rows C ω) (α : Val) (hs : ∀ R ∈ rows, R.sat α) :
    ∃ β : Val, ∀ R ∈ C :: rows, R.sat β := by
  classical
  by_cases h : C.sat α
  · exact ⟨α, by intro R hr; rcases List.mem_cons.mp hr with rfl | hr; exact h; exact hs R hr⟩
  · refine ⟨applyWitness ω α, ?_⟩
    intro R hr
    apply (sat_substRow R ω α).mp
    exact local_goal_sound rows C (substRow R ω) hc hC (canonical_substRow R ω) (ho R hr) α hs h

end GeneralRED
end EREF

#print axioms EREF.GeneralRED.val_substRow
#print axioms EREF.GeneralRED.red_preserves_model

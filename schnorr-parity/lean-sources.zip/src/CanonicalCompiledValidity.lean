import CanonicalFileGrammar
import CanonicalCheckedPOL

namespace L3Emitter.CanonicalCompiledValidity
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace CanonicalScopeKernel
open CanonicalFileGrammar

def LocalValid (p : LocalProof) : Prop := ∀ ts∈p.tapes,∀ t∈ts,CanonicalPOLParser.Valid t

def CommandValid : CanonicalScopeKernel.Command→Prop
  | .pol ts=>∀t∈ts,CanonicalPOLParser.Valid t
  | .consequence R p=>Canonical R ∧ LocalValid p
  | .red R w gs=>Canonical R ∧ FiniteWitness.valid w=true ∧ ∀g∈gs,LocalValid g.proof

theorem scoped_valid (D : List Row) (s : Store) (ids : Nat→Nat) (G : Row)
    (hs : 0<s.next) (he : Embeds D s ids) (p : RecordedRefutation.Certificate)
    (hp : RecordedRefutation.accepts (D++[negate G]) p=true) :
    LocalValid (stripLocal (NativeScopedLocalGoal.compile D.length s ids G p)) := by
  have hp0:=hp
  unfold RecordedRefutation.accepts at hp0
  split at hp0
  · contradiction
  · rename_i E hE
    have hv:=CanonicalCheckedPOL.local_valid (D++[negate G]) E (push s (negate G))
      (extend ids D.length s.next) (by change 0<s.next+1;omega) (push_embeds D s ids he hs _) p.program hE
    have hl:(D++[negate G]).length=D.length+1:=by simp
    rw [hl] at hv
    exact hv

theorem goals_valid (D : List Row) (C : Row) (w : FiniteWitness.Data)
    (s : Store) (ids : Nat→Nat) (rs : List Row) (ps : List RecordedRefutation.Certificate)
    (hs : 0<s.next) (he : Embeds (D++[negate C]) s ids)
    (hp : checkGoals D C w rs ps=true) :
    ∀b∈(NativeREDGoalSequence.compile D C w s ids rs ps).blocks,LocalValid (stripLocal b.2) := by
  induction rs generalizing ps s with
  | nil=>cases ps <;> simp_all [checkGoals,NativeREDGoalSequence.compile]
  | cons R rs ih=>
    cases ps with
    | nil=>simp [checkGoals] at hp
    | cons p ps=>
      obtain ⟨hh,ht⟩:=Bool.and_eq_true_iff.mp hp
      have hcert:RecordedRefutation.accepts ((D++[negate C])++[negate (substRow R (FiniteWitness.interpret w))]) p=true:=by
        simpa only [List.append_assoc,List.singleton_append] using hh
      have hv:=scoped_valid (D++[negate C]) s ids _ hs he p hcert
      have hc:=NativeScopedLocalGoal.correct (D++[negate C]) s ids _ hs he p hcert
      have hl:(D++[negate C]).length=D.length+1:=by simp
      rw [hl] at hv hc
      have hi:=ih (NativeScopedLocalGoal.compile (D.length+1) s ids (substRow R (FiniteWitness.interpret w)) p).closedStore ps
        (by rw [hc.2.2];omega) hc.2.1 ht
      intro b hb
      simp only [NativeREDGoalSequence.compile,List.mem_cons] at hb
      rcases hb with rfl|hb
      · exact hv
      · exact hi b hb

theorem packed_goals_valid (ids : Nat→Nat) (i : Nat) (bs : List (Row×NativeScopedLocalGoal.Built))
    (hv : ∀b∈bs,LocalValid (stripLocal b.2)) :
    ∀g∈packGoals ids i bs,LocalValid g.proof := by
  induction bs generalizing i with
  | nil=>simp [packGoals]
  | cons b bs ih=>
    intro g hg
    simp only [packGoals,List.mem_cons] at hg
    rcases hg with rfl|hg
    · exact hv b (by simp)
    · exact ih (i+1) (by intro b hb;exact hv b (by simp [hb])) g hg

theorem step_valid (M guard : Nat) (D : List Row) (s : Store) (ids : Nat→Nat)
    (c : Step) (hs : 0<s.next) (he : Embeds D s ids) (hc : c.accepts M guard D=true) :
    CommandValid (pack ids (NativeRecordedStep.compile D s ids c).action) := by
  cases c with
  | pol R ts=>exact CanonicalCheckedPOL.relocated_valid D s ids he ts R (of_decide_eq_true hc)
  | consequence R p=>
    obtain ⟨hr,hp⟩:=Bool.and_eq_true_iff.mp hc
    exact ⟨of_decide_eq_true hr,scoped_valid D s ids R hs he p hp⟩
  | red R w ps=>
    obtain ⟨hpre,hgoals⟩:=Bool.and_eq_true_iff.mp hc
    obtain ⟨hpre,_⟩:=Bool.and_eq_true_iff.mp hpre
    obtain ⟨hr,hw⟩:=Bool.and_eq_true_iff.mp hpre
    refine ⟨of_decide_eq_true hr,hw,?_⟩
    exact packed_goals_valid ids 0 _ (goals_valid D R w (push s (negate R))
      (extend ids D.length s.next) (R::D) ps (by change 0<s.next+1;omega)
      (push_embeds D s ids he hs _) hgoals)

theorem compile_valid (M guard : Nat) (D E : List Row) (s : Store) (ids : Nat→Nat)
    (p : Program) (hs : 0<s.next) (he : Embeds D s ids) (hp : check M guard D p=some E) :
    ∀c∈CanonicalScopeKernel.compile D s ids p,CommandValid c := by
  induction p generalizing D s ids with
  | nil=>simp [CanonicalScopeKernel.compile]
  | cons c cs ih=>
    simp only [check] at hp
    split at hp
    · rename_i hc
      have hn:=NativeRecordedStep.correct M guard D s ids c hs he hc
      have ht:=ih (D++[c.row]) _ _ hn.2.2 hn.2.1 hp
      intro x hx
      simp only [CanonicalScopeKernel.compile,List.mem_cons] at hx
      rcases hx with rfl|hx
      · exact step_valid M guard D s ids c hs he hc
      · exact ht x hx
    · contradiction

theorem local_events_valid (p : LocalProof) (hv : LocalValid p) :
    ∀e∈localEvents p,CanonicalLineParser.Valid e := by
  intro e he
  simp only [localEvents,List.mem_append,List.mem_singleton] at he
  rcases he with he|rfl
  · obtain ⟨ts,ht,rfl⟩:=List.mem_map.mp he
    exact hv ts ht
  · trivial

theorem events_valid (c : CanonicalScopeKernel.Command) (hv : CommandValid c) :
    ∀e∈commandEvents c,CanonicalLineParser.Valid e := by
  cases c with
  | pol ts=>simpa [commandEvents,CanonicalLineParser.Valid] using hv
  | consequence R p=>
    intro e he
    simp only [commandEvents,List.mem_cons] at he
    rcases he with rfl|he
    · exact hv.1
    · exact local_events_valid p hv.2 e he
  | red R w gs=>
    intro e he
    simp only [commandEvents,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at he
    rcases he with (rfl|he)|rfl
    · exact ⟨hv.1,hv.2.1⟩
    · obtain ⟨g,hg,he⟩:=List.mem_flatMap.mp he
      simp only [goalEvents,List.mem_cons] at he
      rcases he with rfl|he
      · trivial
      · exact local_events_valid _ (hv.2.2 g hg) e he
    · trivial

/-- Every lexical validity premise is obtained from the accepted recursive
recorded construction, including all local proofs and renamed references. -/
theorem family_valid (n : Nat) (hn : 2≤n) :
    ∀e∈(CanonicalWireFamily.commands n).flatMap commandEvents,CanonicalLineParser.Valid e := by
  have h:=compile_valid 0 (RecordedUniformFamily.guard n)
    (NativeRecordedFamily.original n) (RecordedUniformFamily.finalRows n)
    (initial (NativeRecordedFamily.original n)) id (RecordedUniformFamily.emitter n)
    (by change 0<_+1;omega) (initial_embeds _) (RecordedUniformFamily.recorded_refutation n hn).1
  intro e he
  obtain ⟨c,hc,he⟩:=List.mem_flatMap.mp he
  exact events_valid c (h c hc) e he

#print axioms scoped_valid
#print axioms goals_valid
#print axioms compile_valid
#print axioms family_valid
end L3Emitter.CanonicalCompiledValidity

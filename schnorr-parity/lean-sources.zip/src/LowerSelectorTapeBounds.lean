import LowerEvaluationTapeBounds
namespace L3Emitter.LowerSelectorTapeBounds
open EREF EREF.GeneralRED AliasProgram U2ConstructionSize ConstructionLowerBasicCount

theorem primary (n : Nat) (hn : 2≤n) : tokens (RawPrimaryTransferBank.program n hn)≤18*(n+1)^2*2^n := by
  have h:=fold_tokens (RawPrimaryTransferBank.leaf n hn) (RawPrimaryTransferBank.rows n)
    (RawPrimaryTransferBank.jobs n hn) (RankOrderExclusion.result n hn) 3 (by intros;rfl)
  change tokens (RawPrimaryTransferBank.program n hn)≤_ at h
  rw [RawPrimaryTransferBank.job_count,RawInputSize.raw_record_count] at h
  change _≤2*RankConstruction.width (n+1)*n*2^n*3 at h
  have hm:=Nat.mul_le_mul_right (2^n) (Nat.mul_le_mul (Nat.mul_le_mul_left 2 (width n)) (show n≤n+1 by omega))
  exact h.trans (by nlinarith)

theorem amo (n : Nat) (hn : 2≤n) : tokens (LowerSelectorAMO.program n hn)≤144*(n+1)^3 := by
  have h:=fold_tokens (LowerSelectorAMO.leaf n hn) (LowerSelectorAMO.rows n hn)
    (LowerSelectorAMO.jobs n) (RawPrimaryTransferBank.result n hn) (24*(n+1)^2) (by
      intro j hj D
      have hj':RankPortBank.ValidJob n j:=(RankPortBank.job_mem n j).mp hj
      have hh:=OneHotSize.tokens_bound D (LowerSelectorAMO.xs n hn j.1 j.2)
      change tokens (LowerSelectorAMO.leaf n hn j D)≤_ at hh
      simp only [LowerSelectorAMO.xs,List.length_ofFn] at hh
      have hw:=width n
      have hj0:=hj'.1
      have hs:n+j.1≤4*(n+1):=by omega
      have hm:=Nat.pow_le_pow_left hs 2
      nlinarith)
  change tokens (LowerSelectorAMO.program n hn)≤(RankPortBank.jobs n).length*(24*(n+1)^2) at h
  rw [port_jobs] at h
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 2 (width n))).trans_eq (by ring))

theorem alo (n : Nat) (hn : 2≤n) : tokens (LowerSelectorALO.program n hn)≤54*(n+1)^2 := by
  have h:=fold_tokens (LowerSelectorALO.leaf n hn) (LowerSelectorALO.rows n hn)
    (RankPortBank.jobs n) (LowerTopologyBank.result n hn) (9*(n+1)) (by
      intro j hj D
      have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
      have hs:(LowerSelectorALO.suffix n hn j.1 j.2).length≤AliasAssembly.width (n+1):=by
        simp [LowerSelectorALO.suffix,LowerSelectorALO.full]
      simp [LowerSelectorALO.leaf,tokens,PrefixALO.tape,PrefixALO.units,LocalCombination.steps,
        List.length_flatMap,List.map_map,Function.comp_def,List.sum_replicate,smul_eq_mul]
      omega)
  change tokens (LowerSelectorALO.program n hn)≤(RankPortBank.jobs n).length*(9*(n+1)) at h
  rw [port_jobs] at h
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 2 (width n))).trans_eq (by ring))

theorem zero_leaf (n : Nat) (hn : 2≤n) (r : RankPortBank.Record n)
    (u : Fin (RankConstruction.width (n+1))) (D : List Row) :
    tokens (RankZeroTransport.program n hn r u D)=8*(3*(n+1)-5)+2 := by
  have ht:∀G,(RankZeroTransport.tape n hn r u G D).length=6:=by
    intro G;simp [RankZeroTransport.tape,CommonGuardResolve.token_count]
  have hcase:tokens (RankZeroTransport.casesProgram n hn r u D)=6*(RankZeroTransport.gates n).length:=by
    simp [tokens,RankZeroTransport.casesProgram,List.map_map,Function.comp_def,ht,
      List.map_const',List.sum_replicate,smul_eq_mul,Nat.mul_comm]
  simp only [RankZeroTransport.program,tokens_append,hcase]
  simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
    ProjectionTrace.joinCaseTokens,CaseJoin.join_token_count,List.length_map,
    RankZeroTransport.gates,List.length_range]
  omega

theorem zero (n : Nat) (hn : 2≤n) : tokens (LowerTopologyBank.program n hn)≤468*(n+1)^3 := by
  have h:=fold_tokens (LowerTopologyBank.leaf n hn) (LowerTopologyBank.rows n hn)
    (LowerTopologyBank.jobs n hn) (TopologyBank.result n hn) (26*(n+1)) (by
      intro j hj D;unfold LowerTopologyBank.leaf;rw [zero_leaf];omega)
  change tokens (LowerTopologyBank.program n hn)≤_ at h
  exact h.trans ((Nat.mul_le_mul_right _ (zero_jobs n hn)).trans_eq (by ring))
#print axioms primary
#print axioms amo
#print axioms alo
#print axioms zero
end L3Emitter.LowerSelectorTapeBounds

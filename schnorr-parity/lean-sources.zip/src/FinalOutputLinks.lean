import FinalOutputSelection
namespace L3Emitter.FinalOutputLinks
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteSelection ConcretePortRows FinalOutputDefinitions
attribute [local irreducible] FinalOutputDefinitions.base initialNet FinalOutputSelection.observed

def jobs (n:Nat) (hn:2≤n):List Job:=List.ofFn (FinalOutputSelection.observed n hn).1
def program (n:Nat) (hn:2≤n):=ConcretePortRows.program (FinalSelectorCardinalities.result n hn) (jobs n hn)
def result (n:Nat) (hn:2≤n):=FinalSelectorCardinalities.result n hn++(jobs n hn).flatMap jobRows

theorem checks (n:Nat) (hn:2≤n):AliasProgram.check (FinalSelectorCardinalities.result n hn) (program n hn)=some (result n hn):=by
  apply program_check
  intro j hj
  obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hj
  exact FinalOutputSelection.ready n hn i

theorem original_to_output_links (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalSelectorCardinalities.original_to_final_selector_cardinalities n hn)
    (AliasProgram.check_trace _ _ _ (checks n hn))

theorem relation (n:Nat) (hn:2≤n) (i:Fin (W n-1)) (x:Fin (T n)):
    clause [-(source n hn (coord n i)).val,-(SourceCoordinateValue.value n hn (coord n i) x.val).val,(built n hn).1.outs x |>.val]∈result n hn ∧
    clause [-(source n hn (coord n i)).val,-((built n hn).1.outs x).val,(SourceCoordinateValue.value n hn (coord n i) x.val).val]∈result n hn:=by
  let r:=FinalOutputSelection.observed n hn
  have hp: (r.1 x).es.map (fun e=>(e.choice,e.value))=FinalOutputSelection.inputs n hn x:=by
    unfold r FinalOutputSelection.observed
    exact RecordedPortLinks.cell_pairs (T n) (FinalOutputSelection.inputs n hn) (initialNet n hn) x
  have hm:(source n hn (coord n i),SourceCoordinateValue.value n hn (coord n i) x.val)∈(r.1 x).es.map (fun e=>(e.choice,e.value)):=by
    rw [hp]
    exact List.mem_map.mpr ⟨i,List.mem_finRange i,rfl⟩
  obtain ⟨e,he,heq⟩:=List.mem_map.mp hm
  have hch:e.choice=source n hn (coord n i):=congrArg Prod.fst heq
  have hva:e.value=SourceCoordinateValue.value n hn (coord n i) x.val:=congrArg Prod.snd heq
  have ho:(r.1 x).q=(built n hn).1.outs x:=FinalOutputSelection.output_binding n hn x
  have mem (Q:Row) (hQ:Q∈AliasClauseTransport.bitRows e.choice.val (ConcreteSelection.bit (r.1 x).es (r.1 x).q e)):Q∈result n hn:=by
    apply List.mem_append_right
    apply List.mem_flatMap.mpr
    refine ⟨r.1 x,List.mem_ofFn.mpr ⟨x,rfl⟩,?_⟩
    exact List.mem_flatMap.mpr ⟨e,he,hQ⟩
  constructor <;> apply mem <;> simp [AliasClauseTransport.bitRows,ConcreteSelection.bit,hch,hva,ho]

theorem retained (n:Nat) (hn:2≤n):∀R∈FinalSelectorCardinalities.result n hn,R∈result n hn:=fun _ h=>List.mem_append_left _ h
#print axioms original_to_output_links
#print axioms relation
end L3Emitter.FinalOutputLinks

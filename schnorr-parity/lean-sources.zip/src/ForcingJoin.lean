import ForcingProgram

namespace L3Emitter.ForcingJoin
open EREF EREF.GeneralRED REDWitness LocalCombination WeightedChainCompiler

def choices (ps : List (Int×List Int)) := ps.map Prod.fst
def literals (ps : List (Int×List Int)) := ps.flatMap Prod.snd
def rows (ps : List (Int×List Int)) := ps.map (fun p=>clause (-p.1::p.2))
def valid (ps : List (Int×List Int)) := ∀p∈ps,p.1≠0 ∧ Valid p.2

theorem choices_valid (ps : List (Int×List Int)) (h : valid ps) : Valid (choices ps) := by
  intro l hl;obtain ⟨p,hp,rfl⟩:=List.mem_map.mp hl;exact (h p hp).1

theorem literals_valid (ps : List (Int×List Int)) (h : valid ps) : Valid (literals ps) := by
  intro l hl;obtain ⟨p,hp,hl⟩:=List.mem_flatMap.mp hl;exact (h p hp).2 l hl

theorem value_identity (ps : List (Int×List Int)) (h : valid ps) (α : Val) :
    sum α (choices ps) + ((rows ps).map (fun R=>R.val α)).sum =
      sum α (literals ps) := by
  induction ps with
  | nil => simp [choices,rows,literals,sum]
  | cons p ps ih =>
    have hp:=h p (by simp)
    have ht:=ih (by intro q hq;exact h q (by simp [hq]))
    have hv:=val_clause (-p.1::p.2) (by
      intro l hl;rcases List.mem_cons.mp hl with rfl|hl
      · omega
      · exact hp.2 l hl) α
    simp only [choices,rows,literals,List.map_cons,List.flatMap_cons,List.map_append,
      List.sum_cons,sum_cons,sum_append] at ht ⊢
    rw [hv]
    simp only [List.map_cons,sum_cons,litVal_neg _ _ hp.1]
    omega

theorem identity (ps : List (Int×List Int)) (h : valid ps) :
    chain (clause (choices ps)) (rows ps)=clause (literals ps) := by
  apply canonical_ext _ _ (chain_canonical _ _ (canonical_normalize _ _)) (canonical_normalize _ _)
  intro α
  rw [chain_value _ _ (canonical_normalize _ _) (by
    intro R hR;obtain ⟨p,hp,rfl⟩:=List.mem_map.mp hR;exact canonical_normalize _ _)]
  change (clause (choices ps)).val α + ((rows ps).map (fun R=>R.val α)).sum = (clause (literals ps)).val α
  rw [val_clause _ (choices_valid ps h),val_clause _ (literals_valid ps h)]
  have hv:=value_identity ps h α
  omega

def tokens (D : List Row) (ps : List (Int×List Int)) := sumTape D (clause (choices ps)) (rows ps)

theorem succeeds (D : List Row) (ps : List (Int×List Int)) (h : valid ps)
    (ha : clause (choices ps)∈D) (hr : ∀R∈rows ps,R∈D) :
    polEval (dbOf D) (tokens D ps) []=some (clause (literals ps)) := by
  rw [tokens,sumTape_eval D _ _ ha hr,identity ps h]

theorem bytes (D : List Row) (ps : List (Int×List Int))
    (ha : clause (choices ps)∈D) (hr : ∀R∈rows ps,R∈D) :
    (emit (PolTapeBytes.tapeDoc (tokens D ps))).length≤7+(1+2*ps.length)*(3+digits D.length) := by
  simpa [tokens,rows] using sumTape_bytes D _ _ ha hr

#print axioms succeeds
#print axioms bytes
end L3Emitter.ForcingJoin

import PrimaryBank
import SelectedPort
import IndependentProgram

namespace L3Emitter.BetaPort
open EREF EREF.GeneralRED REDWitness ForcingCandidates PriorityBank CofactorSemantics
abbrev Job (n : Nat) := ForcingFieldBank.Job (n+1) × Nat

def jobs (n : Nat) (hn : 2≤n) : List (Job n) :=
  (ForcingFieldBank.jobs (n+1) (by omega)).flatMap fun j =>
    (List.range (FamilyNamespace.truthRows n)).map (j,·)
def selector (n : Nat) (z : Candidate (3*(n+1)-4)) : Int :=
  (FableEncoding.fam (n+1) (3*(n+1)-4)).sel z.parent.beta z.port 0
def bitLiteral (n : Nat) (hn : 2≤n) (z : Candidate (3*(n+1)-4)) : Int :=
  if z.bit=1 then (ConstantCofactor.B n hn:Int) else -(ConstantCofactor.B n hn:Int)
def portLiteral (n : Nat) (hn : 2≤n) (z : Candidate (3*(n+1)-4)) (x : Nat) : Int :=
  output (low n (ConstantCofactor.offset n hn) z.parent.beta z.port x) (decide (z.bit=1))
def row (n : Nat) (hn : 2≤n) (j : Job n) := clause [-(j.1.1.choice:Int),portLiteral n hn j.1.2 j.2]
def tape (n : Nat) (hn : 2≤n) (j : Job n) := SelectedPort.tape (PrimaryBank.result n hn)
  (j.1.1.choice:Int) (selector n j.1.2) (bitLiteral n hn j.1.2) (portLiteral n hn j.1.2 j.2)

theorem valid_job (n : Nat) (hn : 2≤n) (j : Job n) (hj:j∈jobs n hn) :
    j.1.1∈ConstantLookup.ns (n+1) (by omega) ∧ j.1.2∈candidates (n+1) (by omega) ∧
      j.1.1.input=(j.1.2.var:Int) ∧ j.2<FamilyNamespace.truthRows n := by
  obtain ⟨a,ha,hj⟩:=List.mem_flatMap.mp hj
  obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hj
  have h:=(ForcingFieldBank.job_mem _ _ a.1 a.2).mp ha
  exact ⟨h.1,h.2.1,h.2.2,List.mem_range.mp hx⟩

theorem bit_row (n : Nat) (hn : 2≤n) (node : Node) (z : Candidate (3*(n+1)-4))
    (hnode:node∈ConstantLookup.ns (n+1) (by omega)) (hz:z∈candidates (n+1) (by omega))
    (hid:node.input=(z.var:Int)) :
    clause [-(node.choice:Int),bitLiteral n hn z]∈PrimaryBank.result n hn := by
  obtain ⟨z',hz',he,hr⟩:=RestrictionBit.selected_bit_row (n+1) (by omega) node hnode
  have heq:=ConstantLookup.id_injective _ _ z' z hz' hz (by omega)
  subst z'
  apply PrimaryBank.constant_retained
  apply ConstantConstruction.retains_rank
  exact L3.exec_mono _ _ _ hr

theorem succeeds (n : Nat) (hn : 2≤n) (j : Job n) (hj:j∈jobs n hn) :
    polEval (dbOf (PrimaryBank.result n hn)) (tape n hn j) []=some (row n hn j) := by
  have hj':=valid_job n hn j hj
  have hw:=wellformed _ _ j.1.2 hj'.2.1
  have hg:j.1.2.parent.beta<3*(n+1)-4:=by
    have:=j.1.2.parent.ordered;have:=j.1.2.parent.gamma_lt;omega
  have hchoice:=RestrictionBit.choice_above _ _ j.1.1 hj'.1
  have hs:(j.1.1.choice:Int)≠0:=by omega
  have ha:selector n j.1.2≠0:=by
    have:=(FableEncoding.fam (n+1) (3*(n+1)-4)).sel_pos j.1.2.parent.beta j.1.2.port 0
    unfold selector;omega
  have hb:bitLiteral n hn j.1.2≠0:=by
    unfold bitLiteral ConstantCofactor.B RestrictionBit.B;split <;> omega
  have hp:portLiteral n hn j.1.2 j.2≠0:=output_nonzero _ (low_pos ..) _
  apply SelectedPort.succeeds _ _ _ _ _ hs ha hb hp
  · exact List.mem_append_left _ (ForcingFieldBank.field_present _ _ _ j.1.1 j.1.2
      hj'.1 hj'.2.1 hj'.2.2.1 (selector n j.1.2) (by simp [fields,selector]))
  · have hrow:=PrimaryBank.row_present n hn
      (j.1.2.parent.beta,j.1.2.port,j.2,decide (j.1.2.bit=1))
      ((PrimaryBank.job_mem _ _ _).mpr ⟨hg,hw.2.1,hj'.2.2.2⟩)
    by_cases hh:j.1.2.bit=1 <;> simpa [hh,PrimaryBank.row,PrimaryCofactor.resultRow,PrimaryCofactor.selector,selector,
      bitLiteral,portLiteral,CofactorSemantics.guard] using hrow
  · exact bit_row n hn j.1.1 j.1.2 hj'.1 hj'.2.1 hj'.2.2.1

def program (n : Nat) (hn : 2≤n) : AliasProgram.Program := (jobs n hn).map fun j => (row n hn j,tape n hn j)
def result (n : Nat) (hn : 2≤n) := PrimaryBank.result n hn++(jobs n hn).map (row n hn)

theorem program_check (n : Nat) (hn : 2≤n) :
    AliasProgram.check (PrimaryBank.result n hn) (program n hn)=some (result n hn) := by
  have h:=IndependentProgram.check_base (PrimaryBank.result n hn) (program n hn) (by
    intro c hc;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc;exact succeeds n hn j hj)
  simpa [program,result,AliasProgram.outputs,List.map_map] using h

theorem original_to_beta_port (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (PrimaryBank.original_to_primary n hn)
    (AliasProgram.check_trace _ _ _ (program_check n hn))

#print axioms original_to_beta_port
#print axioms succeeds
end L3Emitter.BetaPort

import NumericBaseFields
import ActualReferenceWidths
import CanonicalCompleteTokenBudget
namespace L3Emitter.CanonicalBaseMachineFields
set_option maxRecDepth 2000
open EREF EREF.GeneralRED NativeSparseStore FieldLengthsFromIDs RecordedOperandFields

def bound:Nat:=ActualReferenceWidths.baseBound+NumericBaseFields.bound+1

theorem numeric:∀c∈RecordedUniformFamily.emitter 2,Content bound c:=by
 intro c hc
 exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c (NumericBaseFields.program c hc)

theorem references:
 ActionReferenceBounds.ProgramBound bound (NativeRecordedFamily.original 2)
  (initial (NativeRecordedFamily.original 2)) id (RecordedUniformFamily.emitter 2):=by
 have hp:=(RecordedUniformFamily.recorded_refutation 2 (by omega)).1
 have h:=ActionReferenceBounds.program 0 (RecordedUniformFamily.guard 2) _ _
  (initial (NativeRecordedFamily.original 2)) id _ (by change 0 < _+1;omega)
  (initial_embeds _) hp
 have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard 2) _ _
  (initial (NativeRecordedFamily.original 2)) id _ hp
 rw [←he] at h
 apply ActionReferenceBounds.program_mono _ _ _ _ _ _ _ h
 have hb:=ActualReferenceWidths.base_counter
 change (NativeRecordedFamily.compiled 2).store.next≤bound
 unfold bound;omega

theorem fields:
 WholeFileByteBudget.Fields bound (bound+1) (bound+1) (NativeRecordedFamily.original 2)
  (initial (NativeRecordedFamily.original 2)) id (RecordedUniformFamily.emitter 2):=
 program_compile bound (bound+1) (bound+1) _ _ _ _
  (program_widths bound 0 (RecordedUniformFamily.guard 2) _ _ _
   (RecordedUniformFamily.recorded_refutation 2 (by omega)).1 numeric) references

/-- Nonvacuous width admission for all serialized fields in the base case.
This is a bound proof, not evaluation or execution of the base certificate. -/
theorem in_range:bound+1<CanonicalMachineReference.referenceLimit:=by decide
#print axioms fields
#print axioms in_range
end L3Emitter.CanonicalBaseMachineFields

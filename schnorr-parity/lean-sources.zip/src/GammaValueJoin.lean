import GammaTapeBytes
namespace L3Emitter.GammaValueJoin
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL

def comparison (G:List Int) (c x y:Bit) (u q:Int) (a b:Bool):=
  clause (G++[-sign a c,-sign b x,-u,-sign b y,q])
def inductionRow (G:List Int) (x y:Bit) (b:Bool):=clause (G++[-sign b x,sign b y])
def leaf (G:List Int) (c x:Bit) (u q:Int) (a b:Bool):=clause (G++[-sign b x,-sign a c,-u,q])
def leafTape (D:List Row) (G:List Int) (c x y:Bit) (u q:Int) (a b:Bool):=
  CommonGuardResolve.tape D (G++[-sign b x]) [] [-sign a c,-u,q] (sign b y)

theorem leaf_check (D:List Row) (G:List Int) (c x y:Bit) (u q:Int) (a b:Bool)
    (hG:Valid G) (hu:u≠0) (hq:q≠0)
    (hi:inductionRow G x y b∈D) (hc:comparison G c x y u q a b∈D):
    polEval (dbOf D) (leafTape D G c x y u q a b) []=some (leaf G c x u q a b):=by
  suffices polEval (dbOf D) (leafTape D G c x y u q a b) []=
      some (CommonGuardResolve.target (G++[-sign b x]) [] [-sign a c,-u,q]) by
    simpa [CommonGuardResolve.target,leaf,List.append_assoc] using this
  apply CommonGuardResolve.checks D (G++[-sign b x]) [] [-sign a c,-u,q] (sign b y)
    (EvaluationCaseSeeds.valid_join hG (by simp [Valid,sign_valid])) (by simp [Valid])
    (by simp [Valid,hu,hq,sign_valid]) (sign_valid _ _)
  · simpa only [CommonGuardResolve.left,inductionRow,List.append_assoc,List.nil_append,List.singleton_append] using hi
  · have he:comparison G c x y u q a b=CommonGuardResolve.right (G++[-sign b x]) [-sign a c,-u,q] (sign b y):=by
      simp only [comparison,CommonGuardResolve.right,List.append_assoc,List.singleton_append]
      apply ProjectionTrace.clause_perm _ _
        (EvaluationCaseSeeds.valid_join hG (by simp [Valid,sign_valid,hu,hq]))
        (EvaluationCaseSeeds.valid_join hG (by simp [Valid,sign_valid,hu,hq]))
      apply List.perm_iff_count.mpr
      intro z;simp only [List.count_append,List.count_cons,List.count_nil];omega
    exact he ▸ hc

def half (G:List Int) (c:Bit) (u q:Int) (a:Bool):=G++[-sign a c,-u,q]
def final (G:List Int) (u q:Int):=G++[-u,q]
def joinTape (D:List Row) (G:List Int) (x:Bit):=CommonGuardResolve.tape D G [] [] x.val

theorem binary (D:List Row) (G:List Int) (x:Bit) (hG:Valid G)
    (hp:clause (G++[x.val])∈D) (hn:clause (G++[-x.val])∈D):
    polEval (dbOf D) (joinTape D G x) []=some (clause G):=by
  simpa only [CommonGuardResolve.left,CommonGuardResolve.right,CommonGuardResolve.target,List.append_nil,joinTape]
    using CommonGuardResolve.checks D G [] [] x.val hG (by simp [Valid]) (by simp [Valid]) x.property (by simpa [CommonGuardResolve.left] using hp) (by simpa [CommonGuardResolve.right] using hn)

def halfRows (G:List Int) (c x:Bit) (u q:Int) (a:Bool):=
  [leaf G c x u q a false,leaf G c x u q a true,clause (half G c u q a)]
def halfProgram (D:List Row) (G:List Int) (c x y:Bit) (u q:Int) (a:Bool):Program:=
  [(leaf G c x u q a false,leafTape D G c x y u q a false),
   (leaf G c x u q a true,leafTape D G c x y u q a true),
   (clause (half G c u q a),joinTape (D++[leaf G c x u q a false,leaf G c x u q a true]) (half G c u q a) x)]

theorem half_check (D:List Row) (G:List Int) (c x y:Bit) (u q:Int) (a:Bool)
    (hG:Valid G) (hu:u≠0) (hq:q≠0)
    (hi:∀b,inductionRow G x y b∈D) (hc:∀b,comparison G c x y u q a b∈D):
    check D (halfProgram D G c x y u q a)=some (D++halfRows G c x u q a):=by
  have hf:=leaf_check D G c x y u q a false hG hu hq (hi _) (hc _)
  have ht:=leaf_check D G c x y u q a true hG hu hq (hi _) (hc _)
  have hp:=IndependentProgram.check_base D
    [(leaf G c x u q a false,leafTape D G c x y u q a false),(leaf G c x u q a true,leafTape D G c x y u q a true)] (by
      intro cmd hm;simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
      rcases hm with rfl|rfl;exact hf;exact ht)
  let E:=D++[leaf G c x u q a false,leaf G c x u q a true]
  have hl:(∀b,clause (half G c u q a++[-sign b x])∈E):=by
    intro b
    have he:clause (half G c u q a++[-sign b x])=leaf G c x u q a b:=by
      apply ProjectionTrace.clause_perm _ _
        (EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join hG (by simp [Valid,hu,hq,sign_valid])) (by simp [Valid,sign_valid]))
        (EvaluationCaseSeeds.valid_join hG (by simp [Valid,hu,hq,sign_valid]))
      apply List.perm_iff_count.mpr
      intro z;simp only [List.count_append,List.count_cons,List.count_nil];omega
    rw [he];apply List.mem_append_right;cases b <;> simp
  have hlast:=binary E (half G c u q a) x
    (EvaluationCaseSeeds.valid_join hG (by simp [Valid,hu,hq,sign_valid]))
    (by simpa [sign] using hl false) (by simpa [sign] using hl true)
  have hs:check E [(clause (half G c u q a),joinTape E (half G c u q a) x)]=some (E++[clause (half G c u q a)]):=by
    simp only [check,hlast,↓reduceIte]
  simpa only [outputs,List.map_cons,List.map_nil,E,halfProgram,halfRows,List.append_assoc,List.cons_append,List.nil_append]
    using check_append _ _ _ _ _ hp hs


def rows (G:List Int) (c x:Bit) (u q:Int):=
  halfRows G c x u q false++halfRows G c x u q true++[clause (final G u q)]
def program (D:List Row) (G:List Int) (c x y:Bit) (u q:Int):Program:=
  halfProgram D G c x y u q false++
  halfProgram (D++halfRows G c x u q false) G c x y u q true++
  [(clause (final G u q),joinTape (D++halfRows G c x u q false++halfRows G c x u q true) (final G u q) c)]

theorem checks (D:List Row) (G:List Int) (c x y:Bit) (u q:Int)
    (hG:Valid G) (hu:u≠0) (hq:q≠0)
    (hi:∀b,inductionRow G x y b∈D) (hc:∀a b,comparison G c x y u q a b∈D):
    check D (program D G c x y u q)=some (D++rows G c x u q):=by
  have h0:=half_check D G c x y u q false hG hu hq hi (hc false)
  have h1:=half_check (D++halfRows G c x u q false) G c x y u q true hG hu hq
    (fun b=>List.mem_append_left _ (hi b)) (fun b=>List.mem_append_left _ (hc true b))
  let E:=D++halfRows G c x u q false++halfRows G c x u q true
  have he:∀a,clause (final G u q++[-sign a c])=clause (half G c u q a):=by
    intro a
    apply ProjectionTrace.clause_perm _ _
      (EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join hG (by simp [Valid,hu,hq])) (by simp [Valid,sign_valid]))
      (EvaluationCaseSeeds.valid_join hG (by simp [Valid,hu,hq,sign_valid]))
    apply List.perm_iff_count.mpr
    intro z;simp only [List.count_append,List.count_cons,List.count_nil];omega
  have hm:∀a,clause (final G u q++[-sign a c])∈E:=by
    intro a;rw [he a];cases a
    · exact List.mem_append_left _ (List.mem_append_right _ (by simp [halfRows]))
    · exact List.mem_append_right _ (by simp [halfRows])
  have ht:=binary E (final G u q) c
    (EvaluationCaseSeeds.valid_join hG (by simp [Valid,hu,hq]))
    (by simpa [sign] using hm false) (by simpa [sign] using hm true)
  have hl:check E [(clause (final G u q),joinTape E (final G u q) c)]=some (E++[clause (final G u q)]):=by
    simp only [check,ht,↓reduceIte]
  have hh:=check_append _ _ _ _ _ h0 h1
  simpa only [E,program,rows,List.append_assoc] using check_append _ _ _ _ _ hh hl

theorem command_count (D:List Row) (G:List Int) (c x y:Bit) (u q:Int):
    (program D G c x y u q).length=7:=by
  simp [program,halfProgram]
theorem token_count (D:List Row) (G:List Int) (c x y:Bit) (u q:Int):
    PrioritySize.tokensCount (program D G c x y u q)=52:=by
  simp [program,halfProgram,leafTape,joinTape,PrioritySize.tokensCount,List.map_append,List.sum_append,CommonGuardResolve.token_count]
#print axioms checks
#print axioms token_count
end L3Emitter.GammaValueJoin

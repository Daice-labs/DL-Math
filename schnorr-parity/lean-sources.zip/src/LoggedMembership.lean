import LoggedConstruction
import CoordinateSnapshots
namespace L3Emitter.LoggedMembership
open EREF EREF.GeneralRED REDWitness AliasNetwork RecordedExpressions RecordedExpressionRun
variable {base:List Row} {A B:Type}

theorem bind_left (p:Logged base A) (f:A→Logged base B) (z:Net base) (j:Job)
    (hj:j∈(p z).1.2):j∈(RecordedExpressions.bind p f z).1.2:=
  List.mem_append_left _ hj

theorem bind_right (p:Logged base A) (f:A→Logged base B) (z:Net base) (j:Job)
    (hj:j∈(f (p z).1.1 (p z).2).1.2):j∈(RecordedExpressions.bind p f z).1.2:=
  List.mem_append_right _ hj

theorem tabulate_at (n:Nat) (f:Fin n→Logged base A) (z:Net base) (i:Fin n) (j:Job)
    (hj:j∈(f i (CoordinateSnapshots.before n (fun i=>forget (f i)) z i)).1.2):
    j∈(tabulateLog n f z).1.2:=by
  induction n generalizing z with
  | zero=>exact Fin.elim0 i
  | succ n ih=>
    revert hj
    refine Fin.cases ?_ (fun i=>?_) i
    · intro hj
      exact List.mem_append_left _ hj
    · intro hj
      apply List.mem_append_right
      apply List.mem_append_left
      exact ih (fun i=>f i.succ) (f 0 z).2 i hj

#print axioms tabulate_at
end L3Emitter.LoggedMembership

import L3CoverageComplete

namespace L3
open EREF EREF.GeneralRED

/-- Six explicit definition rows for one successor. Duplicates are POL
    coefficients, not additional proof commands. -/
def branchPacket (B e x y q r : Nat) : List Row :=
  [gateRow [-(x:Int)] q true, gateRow [-(y:Int)] q true,
   gateRow [-(e:Int),-(q:Int)] r true,
   gateRow [-(e:Int),-(q:Int)] r true,
   gateRow [-(r:Int)] B true, gateRow [-(r:Int)] B true]

theorem branchPacket_sum (α : Val) (B e x y q r : Nat)
    (hB : 1≤B) (he : 1≤e) (hx : 1≤x) (hy : 1≤y) (hq : 1≤q) (hr : 1≤r) :
    ((branchPacket B e x y q r).map fun z => lsum α z.lits - (z.rhs:Int)).sum =
      2*(lv α (B:Int)-lv α (e:Int)+1)-lv α (x:Int)-lv α (y:Int) := by
  simp only [branchPacket,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
    gateRow,lsum_append,lsum_cons,lsum_nil,pos,neg,ite_true]
  lv_omega

def branchPackets (B e : Nat) (xs : List Nat) (edge0 edge1 succ br : Nat→Nat) : List Row :=
  xs.flatMap fun g => branchPacket B e (edge0 g) (edge1 g) (succ g) (br g)

theorem branchPackets_sum (α : Val) (B e : Nat) (xs : List Nat)
    (edge0 edge1 succ br : Nat→Nat) (hB : 1≤B) (he : 1≤e)
    (hp : ∀g∈xs, 1≤edge0 g ∧ 1≤edge1 g ∧ 1≤succ g ∧ 1≤br g) :
    ((branchPackets B e xs edge0 edge1 succ br).map fun z => lsum α z.lits - (z.rhs:Int)).sum =
      2*(xs.length:Int)*(lv α (B:Int)-lv α (e:Int)+1)-
        lsum α (xs.flatMap fun g => [(edge0 g:Int),(edge1 g:Int)]) := by
  induction xs with
  | nil => simp [branchPackets,lsum_nil]
  | cons g xs ih =>
    have pg := hp g (by simp)
    have pt : ∀j∈xs, 1≤edge0 j ∧ 1≤edge1 j ∧ 1≤succ j ∧ 1≤br j := fun j hj => hp j (by simp [hj])
    change ((branchPacket B e (edge0 g) (edge1 g) (succ g) (br g) ++
      branchPackets B e xs edge0 edge1 succ br).map _).sum = _
    rw [List.map_append,List.sum_append,branchPacket_sum α _ _ _ _ _ _ hB he pg.1 pg.2.1 pg.2.2.1 pg.2.2.2,ih pt]
    simp only [List.flatMap_cons,lsum_append,lsum_cons,lsum_nil,List.length_cons]
    rw [show ((xs.length+1:Nat):Int)=(xs.length:Int)+1 by omega]
    simp only [Int.mul_add,Int.add_mul,Int.mul_one]
    omega

/-- A live eligible gate has a successor branch. The fixed chain is linear
    in the successor count and includes the empty-list case. -/
theorem branch_cover_chain (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (B e live : Nat) (xs : List Nat) (edge0 edge1 succ br : Nat→Nat)
    (hB : 1≤B) (he : 1≤e) (hl : 1≤live)
    (hp : ∀g∈xs, 1≤edge0 g ∧ 1≤edge1 g ∧ 1≤succ g ∧ 1≤br g)
    (hrs : All (fun r => r.toE∈D) (branchPackets B e xs edge0 edge1 succ br))
    (hL : (gateRow (xs.flatMap fun g => [(edge0 g:Int),(edge1 g:Int)]) live false).toE∈D)
    (hE : (gateRow [(live:Int)] e false).toE∈D) :
    Refutation (D ++ [negate (clauseRow [(B:Int),-(e:Int)]).toE]) := by
  apply weighted_clause_chain D _ (2*xs.length)
    (branchPackets B e xs edge0 edge1 succ br ++
      [gateRow (xs.flatMap fun g => [(edge0 g:Int),(edge1 g:Int)]) live false,
       gateRow [(live:Int)] e false]) hD
  · nz_lits
  · exact All.append hrs ⟨hL,hE,trivial⟩
  · apply All.append
    · apply All.of_mem
      intro z hz
      obtain ⟨g,hg,hz⟩ := List.mem_flatMap.mp hz
      obtain ⟨hx,hy,hq,hr⟩ := hp g hg
      simp only [branchPacket,List.mem_cons,List.not_mem_nil,or_false] at hz
      rcases hz with rfl | rfl | rfl | rfl | rfl | rfl <;> nz_lits
    · refine ⟨?_,?_,trivial⟩
      · intro l hm
        simp only [gateRow,neg,pos,ite_false] at hm
        rcases List.mem_append.mp hm with hm | hm
        · obtain ⟨g,hg,hm⟩ := List.mem_flatMap.mp hm
          obtain ⟨hx,hy,_,_⟩ := hp g hg
          simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
          rcases hm with rfl | rfl <;> omega
        · simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
          subst l; omega
      · nz_lits
  · intro α
    rw [List.map_append,List.sum_append,branchPackets_sum α _ _ _ _ _ _ _ hB he hp]
    simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      gateRow,clauseRow,lsum_append,lsum_cons,lsum_nil,pos,neg,Bool.false_eq_true,ite_false]
    have hn := lv_neg_lit α (e:Int) (by omega)
    have hnL := lv_neg_lit α (live:Int) (by omega)
    have hb := lv_bounds α (B:Int)
    rw [show ((2*xs.length+1:Nat):Int)=2*(xs.length:Int)+1 by omega]
    rw [show lv α (-(e:Int))=1-lv α (e:Int) by omega,
      show lv α (-(live:Int))=1-lv α (live:Int) by omega]
    simp only [Int.neg_mul,Int.add_mul,Int.mul_add,Int.mul_sub,Int.one_mul]
    omega

#print axioms branch_cover_chain
end L3

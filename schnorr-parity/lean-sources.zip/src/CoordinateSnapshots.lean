import CategoryMixtureProgram

namespace L3Emitter.CoordinateSnapshots
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases SourceMixture
variable {base:List Row} {A:Type} {w:Nat}

/-- The exact intermediate state before an indexed operation, without rerunning a checker. -/
def before : (n:Nat)→(Fin n→StateM (Net base) A)→Net base→Fin n→Net base
  | 0,_,_,i=>Fin.elim0 i
  | n+1,f,z,i=>Fin.cases z (fun j=>before n (fun j=>f j.succ) (f 0 z).2 j) i

theorem tabulate_at (n:Nat) (f:Fin n→StateM (Net base) A) (z:Net base) (i:Fin n) :
    (tabulate n f z).1 i=(f i (before n f z i)).1 := by
  induction n generalizing z with
  | zero=>exact Fin.elim0 i
  | succ n ih=>
    refine Fin.cases ?_ (fun j=>?_) i
    · rfl
    · exact ih (fun j=>f j.succ) (f 0 z).2 j

theorem tabulate_after (n:Nat) (f:Fin n→StateM (Net base) A)
    (he:∀i,Extends (f i)) (z:Net base) (i:Fin n) :
    ∀R∈(f i (before n f z i)).2.rows,R∈(tabulate n f z).2.rows := by
  induction n generalizing z with
  | zero=>exact Fin.elim0 i
  | succ n ih=>
    refine Fin.cases ?_ (fun j=>?_) i
    · exact tabulate_extends n (fun j=>f j.succ) (fun j=>he j.succ) (f 0 z).2
    · exact ih (fun j=>f j.succ) (fun j=>he j.succ) (f 0 z).2 j

def left (c:Config Bit) (as:Nat→AliasBits w) (g:Nat) (z:Net base) :=
  port c.k g (c.sel g 0) as z
def right (c:Config Bit) (as:Nat→AliasBits w) (g:Nat) (z:Net base) :=
  port c.k g (c.sel g 1) as (left c as g z).2
def start (c:Config Bit) (as:Nat→AliasBits w) (g:Nat) (z:Net base) (i:Fin (w+2)) :=
  before (w+2) (fun j=>(coordinate c g (left c as g z).1 (right c as g z).1 j).compile)
    (right c as g z).2 i
def refs (c:Config Bit) (as:Nat→AliasBits w) (g:Nat) (z:Net base) (i:Fin (w+2)) :=
  (build (c.beta g) (if i.val=0 then c.T else c.F) (c.gamma g) (c.hit g)
    ((right c as g z).1 i) ((left c as g z).1 i)
    (if c.k-1 ≤ i.val then c.rank g (i.val-(c.k-1)) else c.F) (start c as g z i)).1

theorem refs_output (c:Config Bit) (as:Nat→AliasBits w) (g:Nat) (z:Net base)
    (i:Fin (w+2)) (hg:g≠0) (hi:i.val<w) :
    (refs c as g z i).q=(step c as g z).1 i := by
  have h:=coordinate_binding c g (left c as g z).1 (right c as g z).1 i hg hi (start c as g z i)
  have hh:=congrArg Prod.fst h
  exact hh.trans (tabulate_at (w+2)
    (fun j=>(coordinate c g (left c as g z).1 (right c as g z).1 j).compile)
    (right c as g z).2 i).symm

theorem refs_ready (c:Config Bit) (as:Nat→AliasBits w) (g:Nat) (z:Net base)
    (i:Fin (w+2)) (hg:g≠0) (hi:i.val<w) :
    (refs c as g z i).Ready (step c as g z).2.rows := by
  have h:=build_ready (c.beta g) (if i.val=0 then c.T else c.F) (c.gamma g) (c.hit g)
    ((right c as g z).1 i) ((left c as g z).1 i)
    (if c.k-1 ≤ i.val then c.rank g (i.val-(c.k-1)) else c.F) (start c as g z i)
  have hb:=congrArg Prod.snd (coordinate_binding c g (left c as g z).1
    (right c as g z).1 i hg hi (start c as g z i))
  rw [hb] at h
  exact MixtureGamma.ready_mono h (tabulate_after _ _ (fun j=>Expr.extends _) _ i)

#print axioms tabulate_at
#print axioms tabulate_after
#print axioms refs_output
#print axioms refs_ready
end L3Emitter.CoordinateSnapshots

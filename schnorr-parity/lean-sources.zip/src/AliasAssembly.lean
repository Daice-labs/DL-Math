import RecursiveAliases

namespace L3Emitter.AliasAssembly
open EREF EREF.GeneralRED REDWitness FamilyNamespace AliasNetwork RecursiveAliases

def selector (k s g p j : Nat) : Bit :=
  ⟨(encode k s (.sel g p j):Int),by simp only [encode];omega⟩

def functionBit (k s g : Nat) (a b : Bool) : Bit :=
  ⟨(encode k s (.fn g (2*a.toNat+b.toNat)):Int),by simp only [encode];omega⟩

def rankBit (k : Nat) (hk : 3≤k) (g t : Nat) : Bit :=
  ⟨RankConstruction.v k hk g t,by unfold RankConstruction.v;omega⟩

def restrictionBit (k : Nat) (hk : 3≤k) : Bit :=
  ⟨(RestrictionBit.B k hk:Int),by unfold RestrictionBit.B;omega⟩

def constantBit (k : Nat) (hk : 3≤k) : Bit :=
  ⟨(ConstantConstruction.C k hk:Int),by unfold ConstantConstruction.C;omega⟩

def choiceSupport (k : Nat) (hk : 3≤k) (beta : Bool) (g : Nat) : List Bit :=
  ((BranchChoices.chosen k hk).filter (fun c=>
    decide ((if beta then c.beta else c.gamma)=g))).map (fun c=>⟨c.lit,c.nonzero⟩)

def refAt {s : Nat} (fallback : Bit) (f : Fin s→Bit) (g : Nat) : Bit :=
  if h:g<s then f ⟨g,h⟩ else fallback

/-- The beta/gamma/kept/receiving-port references are allocated once,
    directly from the proven branch choices and original selectors. -/
def context {base : List Row} (k : Nat) (hk : 3≤k) : StateM (Net base) (Config Bit) := do
  let T ← AND []
  let F := neg T
  let beta ← tabulate (3*k-4) (fun g=>OR (choiceSupport k hk true g.val))
  let gamma ← tabulate (3*k-4) (fun g=>OR (choiceSupport k hk false g.val))
  let kept ← tabulate (3*k-4) (fun g=>
    OR ((List.range (RankConstruction.width k)).map (rankBit k hk g.val)))
  let hit ← tabulate (3*k-4) (fun g=>
    select ((List.range (g.val-1)).map (fun h=>
      (refAt F beta (h+1),selector k (3*k-4) g.val 0 (k+(h+1))))))
  pure ⟨k,T,F,restrictionBit k hk,constantBit k hk,
    refAt F beta,refAt F gamma,refAt F hit,refAt F kept,rankBit k hk,
    selector k (3*k-4),functionBit k (3*k-4)⟩

theorem context_extends {base : List Row} (k : Nat) (hk : 3≤k) :
    Extends (context (base:=base) k hk) := by
  apply bind_extends _ _ (gate_extends true [])
  intro T
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>gate_extends false _))
  intro beta
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>gate_extends false _))
  intro gamma
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>gate_extends false _))
  intro kept
  exact bind_extends _ _ (tabulate_extends _ _ (fun _=>select_extends _))
    (fun hit=>pure_extends _)

def inputAliases (w : Nat) (c : Config Bit) (j : Nat) : AliasBits w :=
  fun i=>if i.val<w then
    if i.val=(if j=0 then 0 else j-1) then c.T else c.F
  else if j=0 then c.B else if i.val=w+1 then c.T else c.F

def width (k : Nat) := (k-1)+RankConstruction.width k

def program {base : List Row} (k : Nat) (hk : 3≤k) :
    StateM (Net base) (Config Bit × (Nat→AliasBits (width k))) := do
  let c ← context k hk
  let as ← RecursiveAliases.run c (inputAliases (width k) c) 0 (3*k-4)
  pure (c,as)

theorem program_extends {base : List Row} (k : Nat) (hk : 3≤k) :
    Extends (program (base:=base) k hk) :=
  bind_extends _ _ (context_extends _ _)
    (fun c=>bind_extends _ _ (run_extends _ _ _ _) (fun as=>pure_extends _))

def source (n : Nat) (hn : 2≤n) := SelectorBank.result n hn

theorem source_canonical (n : Nat) (hn : 2≤n) : ∀R∈source n hn,Canonical R :=
  CanonicalTrace.trace (SelectorBank.original_to_selector_pairs n hn)
    (fun R hR=>(RowSupport.original_bounded (n+1) (3*(n+1)-4)
      (by omega) (by omega) R hR).1)

/-- A symbolic all-n construction. Defining this function does not evaluate
    it at k5 or launch any instance. -/
def built (n : Nat) (hn : 2≤n) :=
  program (n+1) (by omega) (initial (source n hn) (source_canonical n hn))

theorem original_to_alias_definitions (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (built n hn).2.rows :=
  L3.Fam.checkedTrace_trans (SelectorBank.original_to_selector_pairs n hn) (built n hn).2.checked

theorem preserves_predecessor (n : Nat) (hn : 2≤n) :
    ∀R∈source n hn,R∈(built n hn).2.rows :=
  SelectorBank.trace_retains (built n hn).2.checked

/-- The emitted recursive bank computes its specified gate-order algorithm.
    This does not assert the missing lower-formula POL/RUP leaf derivations. -/
theorem recursive_value (n : Nat) (hn : 2≤n) (α : Val)
    (hm : AliasGateSemantics.Models α (built n hn).2.rows) :
    (fun j=>view α ((built n hn).1.2 j)) =
      runValue ((built n hn).1.1.map (eval α))
        (fun j=>view α (inputAliases (width (n+1)) (built n hn).1.1 j))
        0 (3*(n+1)-4) := by
  let z:=initial (source n hn) (source_canonical n hn)
  let c:=(context (n+1) (by omega) z)
  exact run_spec α c.1 (inputAliases (width (n+1)) c.1) 0 (3*(n+1)-4) c.2 hm

#print axioms context_extends
#print axioms original_to_alias_definitions
#print axioms preserves_predecessor
#print axioms recursive_value
end L3Emitter.AliasAssembly

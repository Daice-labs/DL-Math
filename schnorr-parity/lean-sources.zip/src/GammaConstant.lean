import WireBank

namespace L3Emitter.GammaConstant
open EREF EREF.GeneralRED REDWitness ReferenceTransport CofactorSemantics

/-- Resolve the beta constant row with an actual selected circuit edge. The
choice and edge guards are both retained, rather than silently dropping one. -/
theorem resolve (c e v C p : Int) (hc:c≠0) (he:e≠0) (hv:v≠0) (hC:C≠0) (hp:p≠0) :
    add (clause [-c,-v,C]) (clause [-e,v,-p])=clause [-c,-e,-p,C] := by
  apply canonical_ext _ _ (canonical_add _ _) (canonical_normalize _ _)
  intro α
  change (add (clause [-c,-v,C]) (clause [-e,v,-p])).val α=(clause [-c,-e,-p,C]).val α
  rw [val_add (clause [-c,-v,C]) (clause [-e,v,-p]) (canonical_normalize _ _) (canonical_normalize _ _),
    val_clause [-c,-v,C] (by simp [REDWitness.Valid,hc,hv,hC]),
    val_clause [-e,v,-p] (by simp [REDWitness.Valid,he,hv,hp]),
    val_clause [-c,-e,-p,C] (by simp [REDWitness.Valid,hc,he,hp,hC])]
  simp only [sum_cons,sum_nil,litVal_neg α v hv];ring

abbrev Job (n : Nat) := BetaPort.Job n × Nat × Nat × Bool

def jobs (n : Nat) (hn : 2≤n) : List (Job n) :=
  (BetaPort.jobs n hn).flatMap fun j => (List.range (3*(n+1)-4)).flatMap fun g =>
    if j.1.2.parent.beta<g then (List.range 2).flatMap fun p => [(j,g,p,false),(j,g,p,true)] else []

theorem job_mem (n : Nat) (hn : 2≤n) (j : Job n) : j∈jobs n hn ↔
    j.1∈BetaPort.jobs n hn ∧ j.2.1<3*(n+1)-4 ∧ j.1.1.2.parent.beta<j.2.1 ∧ j.2.2.1<2 := by
  obtain ⟨⟨⟨node,z⟩,x⟩,g,p,b⟩:=j;cases b <;> simp [jobs]

def betaJob {n : Nat} (j : Job n) : BetaValue.Job n := (j.1,j.2.2.2)
def edgeJob {n : Nat} (j : Job n) : WireBank.Job :=
  (j.2.1,j.2.2.1,j.1.1.2.parent.beta,j.1.2,!j.2.2.2)
def c {n : Nat} (j : Job n) : Int := j.1.1.1.choice
def e (n : Nat) (j : Job n) := WireCofactor.selector n (3*(n+1)-4) j.2.1 j.2.2.1 j.1.1.2.parent.beta
def p (n : Nat) (hn : 2≤n) (j : Job n) :=
  output (low n (ConstantCofactor.offset n hn) j.2.1 j.2.2.1 j.1.2) j.2.2.2

def row (n : Nat) (hn : 2≤n) (j : Job n) :=
  clause [-c j,-e n j,-p n hn j,BetaValue.C n hn (betaJob j)]
def tape (n : Nat) (hn : 2≤n) (j : Job n) : List Tok :=
  [.ref (locate (WireBank.result n hn) (BetaValue.row n hn (betaJob j))),
   .ref (locate (WireBank.result n hn) (WireBank.row n hn (edgeJob j))),.add]

theorem succeeds (n : Nat) (hn : 2≤n) (j : Job n) (hj:j∈jobs n hn) :
    polEval (dbOf (WireBank.result n hn)) (tape n hn j) []=some (row n hn j) := by
  have h:=(job_mem n hn j).mp hj
  have hb : betaJob j∈BetaValue.jobs n hn := (BetaValue.job_mem n hn _).mpr h.1
  have hv:=BetaPort.valid_job n hn j.1 h.1
  have hw : edgeJob j∈WireBank.jobs n (3*(n+1)-4) := (WireBank.job_mem _ _ _).mpr
    ⟨h.2.1,h.2.2.2,h.2.2.1,hv.2.2.2⟩
  have hrb : BetaValue.row n hn (betaJob j)∈WireBank.result n hn :=
    List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _
      (List.mem_map.mpr ⟨betaJob j,hb,rfl⟩)))
  have hrw:=WireBank.row_present n hn (edgeJob j) hw
  have hz:=BetaValue.nonzero n hn (betaJob j) hb
  have hc : c j≠0 := hz _ (by simp [c,BetaValue.s,betaJob])
  have he : e n j≠0 := by
    have := (FamilyNamespace.encode_bounds (n+1) (3*(n+1)-4)
      (.sel j.2.1 j.2.2.1 (n+1+j.1.1.2.parent.beta)) ⟨h.2.1,h.2.2.2,by omega⟩).1
    unfold e WireCofactor.selector;omega
  have hp : p n hn j≠0 := output_nonzero _ (low_pos ..) _
  have hval : BetaValue.v n hn (betaJob j)≠0 := hz _ (by simp)
  have hC : BetaValue.C n hn (betaJob j)≠0 := hz _ (by simp)
  have hedge : WireBank.row n hn (edgeJob j)=
      clause [-e n j,BetaValue.v n hn (betaJob j),-p n hn j] := by
    cases hs:j.2.2.2 <;> simp [WireBank.row,WireCofactor.goal,edgeJob,e,BetaValue.v,betaJob,p,hs,output]
  simp only [tape,polEval,locate_correct _ _ hrb,locate_correct _ _ hrw]
  rw [hedge]
  exact congrArg some (resolve (c j) (e n j) (BetaValue.v n hn (betaJob j))
    (BetaValue.C n hn (betaJob j)) (p n hn j) hc he hval hC hp)

def program (n : Nat) (hn : 2≤n) : AliasProgram.Program := (jobs n hn).map fun j => (row n hn j,tape n hn j)
def result (n : Nat) (hn : 2≤n) := WireBank.result n hn++(jobs n hn).map (row n hn)

theorem program_check (n : Nat) (hn : 2≤n) :
    AliasProgram.check (WireBank.result n hn) (program n hn)=some (result n hn) := by
  have h:=IndependentProgram.check_base (WireBank.result n hn) (program n hn) (by
    intro c hc;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc;exact succeeds n hn j hj)
  simpa [program,result,AliasProgram.outputs,List.map_map] using h

theorem original_to_gamma_inputs (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (WireBank.original_to_wires n hn)
    (AliasProgram.check_trace _ _ _ (program_check n hn))

theorem tape_length (n : Nat) (hn : 2≤n) (j : Job n) : (tape n hn j).length=3 := rfl

#print axioms succeeds
#print axioms original_to_gamma_inputs
end L3Emitter.GammaConstant

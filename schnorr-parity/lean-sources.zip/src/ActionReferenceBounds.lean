import ScopedReferenceBounds
namespace L3Emitter.ActionReferenceBounds
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

def Bounded (N : Nat) (ids : Nat→Nat) : NativeRecordedStep.Action→Prop
  | .pol ts => LiveTapeReferences.Bounded N ts
  | .consequence _ b => ScopedReferenceBounds.Bounded N b
  | .red _ _ bs => (∀gb∈bs,ScopedReferenceBounds.Bounded N gb.2) ∧
      (∀i,0 < i→i < bs.length→0 < ids i ∧ ids i < N)

theorem mono (a b : Nat) (ids : Nat→Nat) (x : NativeRecordedStep.Action)
    (h : a≤b) (hx : Bounded a ids x) : Bounded b ids x := by
  cases x with
  | pol ts => exact LiveTapeReferences.mono a b ts h hx
  | consequence R p => exact ScopedReferenceBounds.mono a b p h hx
  | red R w bs => exact ⟨fun gb hb=>ScopedReferenceBounds.mono a b gb.2 h (hx.1 gb hb),
      fun i hi hil=>⟨(hx.2 i hi hil).1,lt_of_lt_of_le (hx.2 i hi hil).2 h⟩⟩

theorem index_bound (D : List Row) (s : Store) (ids : Nat→Nat)
    (he : Embeds D s ids) (i : Nat) (hi : 0 < i) (hil : i≤D.length) :
    0 < ids i ∧ ids i < s.next := by
  have hidx : i-1 < D.length:=by omega
  have hr : dbOf D i=some D[i-1] := by simp [dbOf,Nat.ne_of_gt hi,hidx]
  exact ⟨(he i _ hr).1,(he i _ hr).2.1⟩

/-- Every serialized reference in the compiled action, including RED goal
keys and nested qed references, is positive and below its final counter. -/
theorem step (M guard : Nat) (D : List Row) (s : Store) (ids : Nat→Nat)
    (c : Step) (hs : 0 < s.next) (he : Embeds D s ids) (hc : c.accepts M guard D=true) :
    Bounded (s.next+NativeRecordedAllocation.step c) ids (NativeRecordedStep.compile D s ids c).action := by
  cases c with
  | pol R ts =>
    exact LiveTapeReferences.mono s.next (s.next+1) _ (by omega)
      (LiveTapeReferences.reindex D s ids ts R he (of_decide_eq_true hc))
  | consequence R p =>
    have hp:=(Bool.and_eq_true_iff.mp hc).2
    exact ScopedReferenceBounds.mono (s.next+1+p.program.length) (s.next+(2+p.program.length)) _
      (by omega) (ScopedReferenceBounds.local_goal D s ids R hs he p hp)
  | red R w ps =>
    have hp:=(Bool.and_eq_true_iff.mp hc).2
    have hs1 : 0 < (push s (negate R)).next := by change 0 < s.next+1;omega
    have he1:=push_embeds D s ids he hs (negate R)
    have hg:=ScopedReferenceBounds.red_goals D R w (push s (negate R))
      (extend ids D.length s.next) (R::D) ps hs1 he1 hp
    have hl:=(NativeREDGoalSequence.correct D R w (push s (negate R))
      (extend ids D.length s.next) (R::D) ps hs1 he1 hp).2.2.2
    refine ⟨?_,?_⟩
    · intro gb hgb
      exact ScopedReferenceBounds.mono _ _ _ (by change s.next+1+_≤s.next+(2+_);omega) (hg gb hgb)
    · intro i hi hil
      rw [hl] at hil
      have hh:=index_bound D s ids he i hi (by simp only [List.length_cons] at hil;omega)
      exact ⟨hh.1,by change ids i < s.next+(2+_);omega⟩

def ProgramBound (N : Nat) (D : List Row) (s : Store) (ids : Nat→Nat) : Program→Prop
  | [] => True
  | c::cs =>
    let b:=NativeRecordedStep.compile D s ids c
    Bounded N ids b.action ∧ ProgramBound N (D++[c.row]) b.store b.ids cs

theorem program_mono (a b : Nat) (D : List Row) (s : Store) (ids : Nat→Nat) (p : Program)
    (h : a≤b) (hp : ProgramBound a D s ids p) : ProgramBound b D s ids p := by
  induction p generalizing D s ids with
  | nil => trivial
  | cons c cs ih => exact ⟨mono a b ids _ h hp.1,ih _ _ _ hp.2⟩

theorem program (M guard : Nat) (D E : List Row) (s : Store) (ids : Nat→Nat) (p : Program)
    (hs : 0 < s.next) (he : Embeds D s ids) (hp : check M guard D p=some E) :
    ProgramBound (s.next+NativeRecordedAllocation.program p) D s ids p := by
  induction p generalizing D s ids with
  | nil => trivial
  | cons c cs ih =>
    simp only [check] at hp
    split at hp
    · rename_i hc
      have hh:=NativeRecordedStep.correct M guard D s ids c hs he hc
      have hb:=step M guard D s ids c hs he hc
      have ht:=ih (D++[c.row]) (NativeRecordedStep.compile D s ids c).store
        (NativeRecordedStep.compile D s ids c).ids hh.2.2 hh.2.1 hp
      rw [NativeRecordedAllocation.step_next M guard D s ids c hc] at ht
      refine ⟨mono _ _ ids _ ?_ hb,?_⟩
      · simp [NativeRecordedAllocation.program]
      · simpa only [NativeRecordedAllocation.program,List.map_cons,List.sum_cons,Nat.add_assoc] using ht
    · contradiction

#print axioms index_bound
#print axioms step
#print axioms program
end L3Emitter.ActionReferenceBounds

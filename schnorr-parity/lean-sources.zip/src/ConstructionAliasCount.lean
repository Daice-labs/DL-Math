import ConstructionPrefixCount
import AliasProgramCost
import ConcretePortCost
import RecordedExpressionCost

namespace L3Emitter.ConstructionAliasCount
open EREF EREF.GeneralRED AliasNetwork RecursiveAliases
variable {base : List Row} {A B : Type} {w : Nat}

/-- Main definition rows: an AND/OR with r inputs emits r+1 rows. -/
def mass (gs : List Gate) := (gs.map fun g=>g.xs.length+1).sum

def Cost (p : StateM (Net base) A) (c : Nat) :=
  ∀z,mass (p z).2.gates≤mass z.gates+c

theorem cost_mono (p : StateM (Net base) A) (a b : Nat) (h : Cost p a) (hab : a≤b) :
    Cost p b := by intro z;have:=h z;omega

theorem pure_cost (a : A) : Cost (pure a : StateM (Net base) A) 0 := by
  intro z;exact Nat.le_refl _

theorem bind_cost (p : StateM (Net base) A) (f : A→StateM (Net base) B)
    (c d : Nat) (hp : Cost p c) (hf : ∀a,Cost (f a) d) : Cost (p >>= f) (c+d) := by
  intro z;have h1:=hp z;have h2:=hf (p z).1 (p z).2
  change mass (f (p z).1 (p z).2).2.gates≤_
  omega

theorem gate_cost (b : Bool) (xs : List Bit) : Cost (gate (base:=base) b xs) (xs.length+1) := by
  intro z
  simp [gate,push,mass,freshGate]

theorem mux_cost (c a b : Bit) : Cost (MUX (base:=base) c a b) 9 :=
  bind_cost _ _ 3 6 (gate_cost true _) (fun _=>
    bind_cost _ _ 3 3 (gate_cost true _) (fun _=>gate_cost false _))

theorem map_cost (xs : List A) (f : A→StateM (Net base) B) (c : Nat)
    (hf : ∀a∈xs,Cost (f a) c) : Cost (xs.mapM f) (xs.length*c) := by
  induction xs with
  | nil => simpa using pure_cost (base:=base) ([]:List B)
  | cons a as ih =>
    have h:=bind_cost (f a) (fun b=>do let bs ← as.mapM f;pure (b::bs))
      c (as.length*c+0) (hf a (by simp))
      (fun b=>bind_cost _ _ _ 0 (ih (by intro a ha;exact hf a (by simp [ha])))
        (fun bs=>pure_cost _))
    simpa [List.mapM_cons,Nat.add_mul,Nat.add_comm] using h

theorem map_length (xs : List A) (f : A→StateM (Net base) B) (z : Net base) :
    (xs.mapM f z).1.length=xs.length := by
  induction xs generalizing z with
  | nil=>rfl
  | cons x xs ih=>
    rw [List.mapM_cons]
    change (xs.mapM f (f x z).2).1.length+1=xs.length+1
    rw [ih]

theorem select_cost (xs : List (Bit×Bit)) : Cost (select (base:=base) xs) (4*xs.length+1) := by
  intro z
  have h:=map_cost (base:=base) xs (fun p=>AND [p.1,p.2]) 3 (fun _ _=>gate_cost true _) z
  let ts:=xs.mapM (fun p=>AND [p.1,p.2]) z
  have hg:=gate_cost (base:=base) false ts.1 ts.2
  have hl:=map_length xs (fun p=>AND [p.1,p.2]) z
  change mass (gate false ts.1 ts.2).2.gates≤_
  change mass ts.2.gates≤mass z.gates+xs.length*3 at h
  change ts.1.length=xs.length at hl
  rw [hl] at hg
  omega

theorem tabulate_cost (n : Nat) (f : Fin n→StateM (Net base) A) (c : Nat)
    (hf : ∀i,Cost (f i) c) : Cost (tabulate n f) (n*c) := by
  induction n with
  | zero => simpa [tabulate] using pure_cost (base:=base) (fun i:Fin 0=>Fin.elim0 i : Fin 0→A)
  | succ n ih =>
    have h:=bind_cost (f 0) (fun a=>do
      let as ← tabulate n (fun i=>f i.succ)
      pure (Fin.cases a as : Fin (n+1)→A)) c (n*c+0) (hf 0)
      (fun a=>bind_cost _ _ _ 0 (ih _ (fun i=>hf i.succ)) (fun as=>pure_cost _))
    simpa [tabulate,Nat.add_mul,Nat.add_comm] using h

theorem compile_cost (e : Expr) : Cost (e.compile (base:=base)) (3*e.cost) := by
  induction e with
  | lit b=>exact pure_cost _
  | and a b ha hb=>
    have h:=bind_cost a.compile _ (3*a.cost) (3*b.cost+3) ha
      (fun x=>bind_cost b.compile _ (3*b.cost) 3 hb (fun y=>gate_cost true [x,y]))
    convert h using 1 <;> simp [Expr.cost] <;> ring
  | or a b ha hb=>
    have h:=bind_cost a.compile _ (3*a.cost) (3*b.cost+3) ha
      (fun x=>bind_cost b.compile _ (3*b.cost) 3 hb (fun y=>gate_cost false [x,y]))
    convert h using 1 <;> simp [Expr.cost] <;> ring
  | mux c a b hc ha hb=>
    have h:=bind_cost c.compile _ (3*c.cost) (3*a.cost+(3*b.cost+9)) hc (fun x=>
      bind_cost a.compile _ (3*a.cost) (3*b.cost+9) ha (fun y=>
        bind_cost b.compile _ (3*b.cost) 9 hb (fun z=>mux_cost x y z)))
    convert h using 1 <;> simp [Expr.cost] <;> ring

theorem port_cost (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) :
    Cost (port (base:=base) k g sel as) ((w+2)*(4*(k+g)+1)) :=
  tabulate_cost _ _ _ (fun i=>by
    simpa using select_cost (base:=base) ((List.range (k+g)).map (fun j=>(sel j,as j i))))

theorem step_cost (c : Config Bit) (as : Nat→AliasBits w) (g : Nat) :
    Cost (step (base:=base) c as g) ((w+2)*(8*(c.k+g)+77)) := by
  have h:=bind_cost (base:=base) (port c.k g (c.sel g 0) as) _
    ((w+2)*(4*(c.k+g)+1)) ((w+2)*(4*(c.k+g)+1)+(w+2)*75) (port_cost _ _ _ _)
    (fun l=>bind_cost (port c.k g (c.sel g 1) as) _
      ((w+2)*(4*(c.k+g)+1)) ((w+2)*75) (port_cost _ _ _ _) (fun r=>
        tabulate_cost (w+2) _ 75 (fun i=>
          cost_mono _ _ _ (compile_cost (coordinate c g l r i)) (by have:=coordinate_cost c g l r i;omega))))
  convert h using 1 <;> ring

theorem run_cost (c : Config Bit) (as : Nat→AliasBits w) (g m : Nat) :
    Cost (run (base:=base) c as g m) (m*((w+2)*(8*(c.k+g+m)+77))) := by
  induction m generalizing as g with
  | zero=>simpa using pure_cost (base:=base) as
  | succ m ih=>
    have h:=bind_cost (base:=base) (step c as g) (fun a=>run c (Function.update as (c.k+g) a) (g+1) m)
      ((w+2)*(8*(c.k+g)+77)) (m*((w+2)*(8*(c.k+(g+1)+m)+77))) (step_cost c as g) (fun a=>ih _ (g+1))
    apply cost_mono _ _ _ h
    have hm:(w+2)*(8*(c.k+g)+77)≤(w+2)*(8*(c.k+g+(m+1))+77):=
      Nat.mul_le_mul_left _ (by omega)
    nlinarith

#print axioms select_cost
#print axioms run_cost
end L3Emitter.ConstructionAliasCount

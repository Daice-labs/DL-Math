import FinalSelectorBank
namespace L3Emitter.FinalSelectorCardinalities
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram
open FinalOutputDefinitions FinalSelectorSources FinalSelectorSpecs
attribute [local irreducible] FinalOutputDefinitions.construction tabulate

def xs (n:Nat) (hn:2≤n) (p:Fin 2):List Int:=List.ofFn (fun i=>(target n hn p i).val)
theorem valid_xs (n:Nat) (hn:2≤n) (p:Fin 2):Valid (xs n hn p):=by
  intro l hl;obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hl;exact (target n hn p i).property
theorem pairs (n:Nat) (hn:2≤n) (p:Fin 2):
    (xs n hn p).Pairwise (fun a b=>Cardinality.pair a b∈FinalSelectorBank.result n hn):=by
  apply List.pairwise_ofFn.mpr
  intro i j hij
  exact FinalSelectorBank.contains n hn p (pair n i j) (pair_mem n i j hij)
theorem alo_present (n:Nat) (hn:2≤n) (p:Fin 2):
    clause (xs n hn p)∈FinalSelectorBank.result n hn:=by
  have h:=FinalSelectorBank.contains n hn p (alo n) (List.mem_cons_self)
  simpa only [GuardedVectorTransport.row,GuardedVectorTransport.literals,alo,List.map_ofFn,Function.comp_def,
    GuardedVectorTransport.signed,↓reduceIte,xs] using h

def leaf (n:Nat) (hn:2≤n) (p:Fin 2) (E:List Row):=OneHotPOL.program E (xs n hn p)
def rows (n:Nat) (hn:2≤n) (p:Fin 2):=OneHotPOL.rows (xs n hn p)
def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (List.finRange 2) (FinalSelectorBank.result n hn)
def result (n:Nat) (hn:2≤n):=FinalSelectorBank.result n hn++RetainedBlockFold.body (rows n hn) (List.finRange 2)
theorem checks (n:Nat) (hn:2≤n):check (FinalSelectorBank.result n hn) (program n hn)=some (result n hn):=by
  apply RetainedBlockFold.checks _ _ _ (fun _=>True) _ _ (by simp) _ (fun _ h=>h)
  intro p hp E he
  exact OneHotPOL.checks E (xs n hn p) (valid_xs n hn p)
    ((pairs n hn p).imp (fun h=>he _ h))
theorem original_to_final_selector_cardinalities (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalSelectorBank.original_to_selector_clauses n hn) (check_trace _ _ _ (checks n hn))
theorem final_rows (n:Nat) (hn:2≤n) (p:Fin 2):
    clause (xs n hn p)∈result n hn ∧ Cardinality.amo (xs n hn p)∈result n hn:=by
  constructor
  · exact List.mem_append_left _ (alo_present n hn p)
  · apply List.mem_append_right
    apply RetainedBlockFold.contains (rows n hn) (List.finRange 2) p (by simp)
    apply OneHotPOL.final_mem
    intro h
    have hh:=congrArg List.length h
    simp only [xs,List.length_ofFn,List.length_nil] at hh
    unfold W AliasAssembly.width RankConstruction.width at hh;omega
#print axioms original_to_final_selector_cardinalities
#print axioms final_rows
end L3Emitter.FinalSelectorCardinalities

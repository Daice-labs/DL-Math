import CanonicalFieldCosts
namespace L3Emitter.ByteOperandBounds
open EREF TemplateBytes CanonicalScopedBytes CanonicalFieldCosts

/-- Decimal operand ceiling; units are numeric magnitudes, not bytes. -/
def TokenBound (M : Nat) : Tok → Prop
  | .ref i => i ≤ M
  | .lit l => l.natAbs ≤ M
  | .mul a | .div a => a ≤ M
  | .add | .sat => True

def RowBound (M : Nat) (R : EREF.Row) : Prop :=
  (∀t∈R.terms,t.1≤M ∧ t.2.natAbs≤M) ∧ R.bound.natAbs≤M

def WitnessBound (M : Nat) (w : FiniteWitness.Data) : Prop :=
  ∀e∈w,e.1≤M ∧ match e.2 with
  | .bit _ => True
  | .lit l => l.varId≤M

theorem sum_bound {α : Type} (xs : List α) (f : α→Nat) (B : Nat)
    (h : ∀x∈xs,f x≤B) : (xs.map f).sum≤xs.length*B := by
  induction xs with
  | nil => simp
  | cons x xs ih =>
    have hx:=h x (by simp)
    have ht:=ih (fun y hy=>h y (by simp [hy]))
    simp only [List.map_cons,List.sum_cons,List.length_cons]
    calc
      _ ≤ B+xs.length*B := Nat.add_le_add hx ht
      _ = (xs.length+1)*B := by ring

theorem literal_bound (M : Nat) (l : Int) (h : l.natAbs≤M) :
    literalBytes l ≤ 2+digits M := by
  have hd:=digits_mono h
  unfold literalBytes
  split <;> omega

theorem token_bound (M : Nat) (t : Tok) (h : TokenBound M t) :
    CompactTapeBytes.refTokenBytes t+CompactTapeBytes.otherTokenBytes t ≤ 2+digits M := by
  cases t with
  | ref i => exact (by simpa [CompactTapeBytes.refTokenBytes,CompactTapeBytes.otherTokenBytes] using
      (show digits i≤2+digits M from (digits_mono h).trans (by omega)))
  | lit l => simpa [CompactTapeBytes.refTokenBytes,CompactTapeBytes.otherTokenBytes] using literal_bound M l h
  | add => change 0+1≤_;omega
  | sat => change 0+1≤_;omega
  | mul a => have hd:=digits_mono h; change 0+(digits a+2)≤_;omega
  | div a => have hd:=digits_mono h; change 0+(digits a+2)≤_;omega

/-- Every POL operand is counted, including main tapes and local tapes. -/
theorem tape_bytes (M : Nat) (ts : List Tok) (h : ∀t∈ts,TokenBound M t) :
    (emit (CompactTapeBytes.line ts)).length ≤ 7+ts.length*(3+digits M) := by
  rw [CompactTapeBytes.line_exact]
  have hh:=sum_bound ts (fun t=>CompactTapeBytes.refTokenBytes t+CompactTapeBytes.otherTokenBytes t)
    (2+digits M) (fun t ht=>token_bound M t (h t ht))
  simp only [List.sum_map_add] at hh
  change _+CompactReferenceWidths.referenceDigitBytes ts+CompactTapeBytes.otherBytes ts≤_
  have he : (ts.map CompactTapeBytes.refTokenBytes).sum=CompactReferenceWidths.referenceDigitBytes ts:=rfl
  rw [he] at hh
  change _+CompactTapeBytes.otherBytes ts≤_ at hh
  nlinarith [Nat.sub_le ts.length 1]

theorem row_bytes (M : Nat) (R : EREF.Row) (h : RowBound M R) :
    exactBytes (rowDoc R) ≤ R.terms.length*(4+2*digits M)+5+digits M := by
  rw [row_exact]
  have ht:=sum_bound R.terms termBytes (3+2*digits M) (by
    intro t ht
    have ha:=digits_mono (h.1 t ht).1
    have hb:=literal_bound M t.2 (h.1 t ht).2
    unfold termBytes;omega)
  have hb:=digits_mono h.2
  have hi : integerBytes R.bound≤1+digits M:=by
    unfold integerBytes;split <;> omega
  unfold rowBytes
  nlinarith [Nat.sub_le R.terms.length 1]

theorem witness_bytes (M : Nat) (w : FiniteWitness.Data) (h : WitnessBound M w) :
    exactBytes (witness w) ≤ w.length*(8+2*digits M) := by
  rw [witness_exact]
  have ht:=sum_bound w entryCost (7+2*digits M) (by
    intro e he
    have ha:=digits_mono (h e he).1
    have hb : imageCost e.2≤2+digits M:=by
      have hh:=(h e he).2
      cases hx:e.2 with
      | bit b => change 1≤_;omega
      | lit l =>
        rw [hx] at hh
        have hd:=digits_mono hh
        simp only [hx,imageCost,literalCost]
        split <;> omega
    unfold entryCost;omega)
  unfold witnessBytes
  nlinarith [Nat.sub_le w.length 1]

#print axioms tape_bytes
#print axioms row_bytes
#print axioms witness_bytes
end L3Emitter.ByteOperandBounds

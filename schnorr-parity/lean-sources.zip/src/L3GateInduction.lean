import L3GateSplit

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

theorem veqFinish_obls (hk : 2≤F.k) (hs : 1≤F.s) (hm : 1≤F.V)
    (bit cb g : Nat) (u : StI F.V) (hu : F.Good3 u) (hb : bit<2) (hg : g<F.s)
    (hc : 1≤cb ∧ cb≤u.s.var) (hv : 1≤u.s.veq g bit ∧ u.s.veq g bit≤u.s.var)
    (hf : F.ForceRecord u) (hr : ∀h<g,F.GateRecord bit cb h u)
    (hcb : Cmd.eqDef cb (F.fn 0 bit : Int) (F.fn 0 (bit+2) : Int)∈u.s.cmds)
    (heq : Cmd.eqDef (u.s.veq g bit) (F.val g (F.bitX bit) : Int) (F.val g (F.bitY bit) : Int)∈u.s.cmds)
    (ho : ObligationsChecked F.db5 u.s.cmds) :
    ObligationsChecked F.db5 (F.veqFinish hm bit cb g u).s.cmds := by
  by_cases hg0 : g=0
  · subst g
    apply F.checked_split u (F.gateRoot u bit cb 0) (F.gateVs bit 0)
      (F.gateRoot_bound u hu bit cb 0 hg hc hv) (F.gateVs_bound hk u bit 0 hb hg) ho
    exact F.firstFinal_obls hk hs u hu bit cb hb hc hv hcb heq
  · have hg1 : 1≤g := by omega
    let u0 := F.portEqStep hm g bit cb u 0
    let u1 := F.portEqStep hm g bit cb u0 1
    have k0 : Keeps2 u u0 := F.keeps2_portEqStep hm g bit cb u 0
    have k1 : Keeps2 u0 u1 := F.keeps2_portEqStep hm g bit cb u0 1
    have k2 := keeps2_trans k0 k1
    have v0 : u0.s.veq=u.s.veq := F.portEqStep_veq hm g bit cb u 0
    have v1 : u1.s.veq=u0.s.veq := F.portEqStep_veq hm g bit cb u0 1
    have v2 : u1.s.veq=u.s.veq := v1.trans v0
    have hu0 := F.Good3_of_keeps2 k0 hu
    have hu1 := F.Good3_of_keeps2 k2 hu
    have hc0 : 1≤cb ∧ cb≤u0.s.var := ⟨hc.1,Nat.le_trans hc.2 (var_le_of_grows k0.1)⟩
    have hc1 : 1≤cb ∧ cb≤u1.s.var := ⟨hc.1,Nat.le_trans hc.2 (var_le_of_grows k2.1)⟩
    have hr0 : ∀h<g,F.GateRecord bit cb h u0 := fun h hh => F.GateRecord_keeps k0 bit cb h (by rw [v0]) (hr h hh)
    have ho0 : ObligationsChecked F.db5 u0.s.cmds := F.portEqStep_obls hk hs hm g 0 bit cb u hu hg1 hg (by decide) hb hc hr ho
    have ho1 : ObligationsChecked F.db5 u1.s.cmds := F.portEqStep_obls hk hs hm g 1 bit cb u0 hu0 hg1 hg (by decide) hb hc0 hr0 ho0
    have r0 := F.portEqStep_record hk hm g 0 bit cb u hu hg1 hg (by decide) hb hc hr
    have r1 := F.portEqStep_record hk hm g 1 bit cb u0 hu0 hg1 hg (by decide) hb hc0 hr0
    have r0' := F.PortRecord_keeps k1 g 0 bit cb (u.s.var+1) r0
    have hf1 := F.ForceRecord_keeps k2 hf
    have hv1 : 1≤u1.s.veq g bit ∧ u1.s.veq g bit≤u1.s.var := by
      rw [v2]; exact ⟨hv.1,Nat.le_trans hv.2 (var_le_of_grows k2.1)⟩
    have he1 : Cmd.eqDef (u1.s.veq g bit) (F.val g (F.bitX bit) : Int) (F.val g (F.bitY bit) : Int)∈u1.s.cmds := by
      rw [v2]; exact mem_of_grows k2.1 heq
    have root : F.gateRoot u1 bit cb g=F.gateRoot u bit cb g := by
      simp only [gateRoot,v2,k2.2.1.1,k2.2.2.2.2.2]
    unfold veqFinish
    simp only [hg0,↓reduceIte,List.foldl_cons,List.foldl_nil]
    change ObligationsChecked F.db5 (u1.split (F.gateRoot u bit cb g) _).s.cmds
    rw [←root]
    have hh := F.checked_split u1 (F.gateRoot u1 bit cb g) (F.gateVs bit g)
      (F.gateRoot_bound u1 hu1 bit cb g hg hc1 hv1) (F.gateVs_bound hk u1 bit g hb hg) ho1
      (F.gateFinal_obls hk hs u1 hu1 g bit cb (u.s.var+1) (u0.s.var+1) hg1 hg hb hc1 hv1 hf1 r0' r1 he1)
    simpa only [gateVs,hg0,↓reduceIte] using hh

theorem veqStart_obls (hm : 1≤F.V) (bit g : Nat) (t : StI F.V)
    (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.veqStart hm bit t g).s.cmds := by
  change ObligationsChecked F.db5 (t.s.cmds ++ [.eqDef _ _ _])
  apply obligations_append _ _ _ ho
  intro o ho; simp [obls] at ho

/-- One actual gate-order step: every obligation is discharged using the
    earlier records and the proved local chains. -/
theorem veqStep_obls (hk : 2≤F.k) (hs : 1≤F.s) (hm : 1≤F.V)
    (bit cb g : Nat) (t : StI F.V) (ht : F.Good3 t) (hb : bit<2) (hg : g<F.s)
    (hc : 1≤cb ∧ cb≤t.s.var) (hf : F.ForceRecord t) (hr : ∀h<g,F.GateRecord bit cb h t)
    (hcb : Cmd.eqDef cb (F.fn 0 bit : Int) (F.fn 0 (bit+2) : Int)∈t.s.cmds)
    (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.veqStep hm bit cb t g).s.cmds := by
  rw [F.veqStep_factor]
  have kk := F.veqStart_keeps hm bit t g
  have hi := F.veqStart_info hk hm bit t g hb hg
  apply F.veqFinish_obls hk hs hm bit cb g _ (F.Good3_of_keeps2 kk ht) hb hg
    ⟨hc.1,Nat.le_trans hc.2 (var_le_of_grows kk.1)⟩ ⟨by have := hi.2.1; omega,hi.2.2⟩
    (F.ForceRecord_keeps kk hf) _ (mem_of_grows kk.1 hcb) hi.1 (F.veqStart_obls hm bit g t ho)
  intro h hh
  apply F.GateRecord_keeps kk bit cb h _ (hr h hh)
  have hne : h≠g := by omega
  simp [veqStart,StI.setVeq,StI.EQ,St.EQ,hne]

/-- Gate-order coverage induction against the actual state-dependent emitted
    commands. It assumes the already-checked prefix and the actual cb EQ,
    and proves every gate step; no gate-coverage obligation is a premise. -/
theorem gateOrder_obls (hk : 2≤F.k) (hs : 1≤F.s) (hm : 1≤F.V)
    (bit cb : Nat) (t : StI F.V) (ht : F.Good3 t) (hb : bit<2)
    (hc : 1≤cb ∧ cb≤t.s.var) (hf : F.ForceRecord t)
    (hcb : Cmd.eqDef cb (F.fn 0 bit : Int) (F.fn 0 (bit+2) : Int)∈t.s.cmds)
    (ho : ObligationsChecked F.db5 t.s.cmds) (n : Nat) (hn : n≤F.s) :
    ObligationsChecked F.db5 ((List.range n).foldl (F.veqStep hm bit cb) t).s.cmds := by
  induction n with
  | zero => exact ho
  | succ n ih =>
    have kn := keeps2_foldl _ (List.range n) (F.keeps2_veqStep hm bit cb) t
    rw [List.range_succ,List.foldl_append,List.foldl_cons,List.foldl_nil]
    exact F.veqStep_obls hk hs hm bit cb n _ (F.Good3_of_keeps2 kn ht) hb (by omega)
      ⟨hc.1,Nat.le_trans hc.2 (var_le_of_grows kn.1)⟩ (F.ForceRecord_keeps kn hf)
      (F.gateOrder_history hk hm bit cb t ht hb hc n (by omega))
      (mem_of_grows kn.1 hcb) (ih (by omega))

#print axioms veqStep_obls
#print axioms gateOrder_obls
end L3.Fam

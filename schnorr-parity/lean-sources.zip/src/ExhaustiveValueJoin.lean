import ForcingNodeValue
namespace L3Emitter.ExhaustiveValueJoin
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL

def target (n:Nat) (hn:2≤n) (g x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):=
  ValueBranchRows.row n hn g x i (SourceCoordinateValue.value n hn i x) b v
def branchRows (n:Nat) (hn:2≤n) (g x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):=
  RetainedBlockFold.body (fun node=>ForcingNodeValue.rows n hn g x node i b v) (ForcingNodeSource.nodes n hn)
def branches (n:Nat) (hn:2≤n) (g x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):=
  RetainedBlockFold.run (fun node=>ForcingNodeValue.program n hn g x node i b v)
    (fun node=>ForcingNodeValue.rows n hn g x node i b v) (ForcingNodeSource.nodes n hn) D

theorem branches_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (x:Nat) (hx:x<FamilyNamespace.truthRows n)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row) (hd:∀R∈SharedValueBank.result n hn,R∈D)
    (hi:ValueInductionBranches.Before n hn g D):
    check D (branches n hn g x i b v D)=some (D++branchRows n hn g x i b v):=by
  apply RetainedBlockFold.checks D _ _ (fun node=>node∈ForcingNodeSource.nodes n hn) _ _ (fun _ h=>h) D (fun _ h=>h)
  intro node hn' E hE
  exact ForcingNodeValue.checks n hn g hg hs x hx node hn' i b v E
    (fun R h=>hE R (hd R h)) (ValueInductionBranches.before_mono n hn g hi hE)

theorem guarded_present (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (x:Nat) (hx:x<FamilyNamespace.truthRows n)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (c:Int) (hc:c∈ForcingNodeSource.guards n hn):
    Resolution.branch (target n hn g x i b v) (-c)∈branchRows n hn g x i b v:=by
  obtain ⟨node,hnode,rfl⟩:=List.mem_map.mp hc
  change Resolution.branch (clause (RankChoiceLift.lits n hn g x i b v)) (-(node.choice:Int))∈_
  rw [ProjectionTrace.branch_clause _ (by simp [RankChoiceLift.lits,Valid,sign_valid,(ValueBranchRows.q n hn g i).property])
    _ (neg_ne_zero.mpr (ForcingNodeSource.nonzero n hn node hnode))]
  exact RetainedBlockFold.contains _ _ node hnode _ (ForcingNodeValue.conclusion_present n hn g hg hs x hx node hnode i b v)

def rows (n:Nat) (hn:2≤n) (g x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):=
  branchRows n hn g x i b v++[target n hn g x i b v]
def program (n:Nat) (hn:2≤n) (g x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):Program:=
  branches n hn g x i b v D++[(target n hn g x i b v,PortSelectorJoin.tape (D++branchRows n hn g x i b v)
    (target n hn g x i b v) (ForcingNodeSource.guards n hn))]

theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (x:Nat) (hx:x<FamilyNamespace.truthRows n)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row) (hd:∀R∈SharedValueBank.result n hn,R∈D)
    (hi:ValueInductionBranches.Before n hn g D):
    check D (program n hn g x i b v D)=some (D++rows n hn g x i b v):=by
  have h0:=branches_check n hn g hg hs x hx i b v D hd hi
  have h1:=PortSelectorJoin.checks (D++branchRows n hn g x i b v) (target n hn g x i b v) (canonical_normalize _ _)
    (ForcingNodeSource.guards n hn) (ForcingNodeSource.nonempty n hn)
    (by intro c hc;obtain ⟨node,hnode,rfl⟩:=List.mem_map.mp hc;exact ForcingNodeSource.nonzero n hn node hnode)
    (List.mem_append_left _ (hd _ (ForcingNodeSource.alo n hn)))
    (fun c hc=>List.mem_append_right _ (guarded_present n hn g hg hs x hx i b v c hc))
  have h2:check (D++branchRows n hn g x i b v)
      [(target n hn g x i b v,PortSelectorJoin.tape (D++branchRows n hn g x i b v) (target n hn g x i b v) (ForcingNodeSource.guards n hn))]=
        some ((D++branchRows n hn g x i b v)++[target n hn g x i b v]):=by
    simp only [check,h1,ite_true]
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h2

#print axioms guarded_present
#print axioms checks
end L3Emitter.ExhaustiveValueJoin

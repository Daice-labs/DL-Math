import CategoryBank

namespace L3Emitter.GuardedGatePOL
open EREF EREF.GeneralRED REDWitness AliasNetwork Resolution CaseJoin ReferenceTransport

def guarded (gs:List Int) (l:Int) := clause (gs++[l])

theorem guarded_val (gs:List Int) (l:Int) (hg:Valid gs) (hl:l≠0) (α:Val) :
    (guarded gs l).val α=sum α gs+litVal α l-1 := by
  rw [guarded,val_clause _ (by
    intro x hx;rcases List.mem_append.mp hx with hx|hx
    · exact hg x hx
    · simpa using (List.mem_singleton.mp hx ▸ hl)),sum_append]
  simp [sum_cons,sum_nil]

def oneTape (D:List Row) (G:List Int) (a q:Int) : List Tok :=
  [.ref (locate D (guarded G a)),.ref (locate D (clause [-a,q])),.add]

theorem one_sum (G:List Int) (a q:Int) (hg:Valid G) (ha:a≠0) (hq:q≠0) :
    add (guarded G a) (clause [-a,q])=guarded G q := by
  apply canonical_ext _ _ (canonical_add _ _) (canonical_normalize _ _)
  intro α
  change (add (guarded G a) (clause [-a,q])).val α=(guarded G q).val α
  rw [val_add (guarded G a) (clause [-a,q]) (canonical_normalize _ _) (canonical_normalize _ _),
    guarded_val G a hg ha,guarded_val G q hg hq,val_clause _ (by simp [Valid,ha,hq])]
  simp only [sum_cons,sum_nil,litVal_neg α a ha];ring

theorem one_check (D:List Row) (G:List Int) (a q:Int) (hg:Valid G) (ha:a≠0) (hq:q≠0)
    (h1:guarded G a∈D) (h2:clause [-a,q]∈D) :
    polEval (dbOf D) (oneTape D G a q) []=some (guarded G q) := by
  simp only [oneTape,polEval,locate_correct _ _ h1,locate_correct _ _ h2]
  rw [one_sum G a q hg ha hq]

def twoTape (D:List Row) (G:List Int) (a b q:Int) : List Tok :=
  [.ref (locate D (guarded G a)),.ref (locate D (guarded G b)),.add,
    .ref (locate D (clause [-a,-b,q])),.add,.lit q,.add,.div 2]

theorem two_sum (G:List Int) (a b q:Int) (hg:Valid G) (ha:a≠0) (hb:b≠0) (hq:q≠0) :
    add (add (add (guarded G a) (guarded G b)) (clause [-a,-b,q])) (litAxiom q)=
      scaled 2 (guarded G q) := by
  apply canonical_ext _ _ (canonical_add _ _) (canonical_scaled _ (by omega) _ (canonical_normalize _ _))
  intro α
  change (add (add (add (guarded G a) (guarded G b)) (clause [-a,-b,q])) (litAxiom q)).val α=
    (scaled 2 (guarded G q)).val α
  rw [val_add (add (add (guarded G a) (guarded G b)) (clause [-a,-b,q])) (litAxiom q) (canonical_add _ _) (canonical_litAxiom _),
    val_add (add (guarded G a) (guarded G b)) (clause [-a,-b,q]) (canonical_add _ _) (canonical_normalize _ _),
    val_add (guarded G a) (guarded G b) (canonical_normalize _ _) (canonical_normalize _ _),
    guarded_val G a hg ha,guarded_val G b hg hb,val_litAxiom q hq,
    val_clause _ (by simp [Valid,ha,hb,hq]),val_scaled]
  have h:=guarded_val G q hg hq α
  rw [h]
  simp only [sum_cons,sum_nil,litVal_neg α a ha,litVal_neg α b hb]
  ring

theorem two_check (D:List Row) (G:List Int) (a b q:Int) (hg:Valid G) (ha:a≠0) (hb:b≠0) (hq:q≠0)
    (h1:guarded G a∈D) (h2:guarded G b∈D) (h3:clause [-a,-b,q]∈D) :
    polEval (dbOf D) (twoTape D G a b q) []=some (guarded G q) := by
  simp only [twoTape,polEval,locate_correct _ _ h1,locate_correct _ _ h2,locate_correct _ _ h3,
    hq,↓reduceIte]
  rw [two_sum G a b q hg ha hb hq,if_pos hq,if_pos (by omega : 0<2),
    divide_scaled 2 (by omega) (guarded G q) (canonical_normalize _ _)]

def sign (b:Bool) (x:Bit) : Int := if b then x.val else -x.val
theorem sign_valid (b:Bool) (x:Bit) : sign b x≠0 := by cases b <;> simp [sign,x.property]

structure BinaryRows (D:List Row) (isAnd:Bool) (a b q:Bit) : Prop where
  up : clause (if isAnd then [-a.val,-b.val,q.val] else [a.val,b.val,-q.val])∈D
  left : clause (if isAnd then [-q.val,a.val] else [-a.val,q.val])∈D
  right : clause (if isAnd then [-q.val,b.val] else [-b.val,q.val])∈D

theorem BinaryRows.mono {D E:List Row} {isAnd:Bool} {a b q:Bit}
    (h:BinaryRows D isAnd a b q) (hm:∀R∈D,R∈E) : BinaryRows E isAnd a b q :=
  ⟨hm _ h.up,hm _ h.left,hm _ h.right⟩

theorem actual_and {base:List Row} (z:Net base) (a b:Bit) :
    BinaryRows (AND [a,b] z).2.rows true a b (AND [a,b] z).1 := by
  refine ⟨ConcreteGateRows.and_up z a b,ConcreteGateRows.and_down z _ a (by simp),
    ConcreteGateRows.and_down z _ b (by simp)⟩
theorem actual_or {base:List Row} (z:Net base) (a b:Bit) :
    BinaryRows (OR [a,b] z).2.rows false a b (OR [a,b] z).1 := by
  refine ⟨?_,ConcreteGateRows.or_up z _ a (by simp),ConcreteGateRows.or_up z _ b (by simp)⟩
  exact ConcreteGateRows.or_down z [a,b]

def value (isAnd va vb:Bool) := if isAnd then va&&vb else va||vb
def tape (D:List Row) (G:List Int) (isAnd va vb:Bool) (a b q:Bit) : List Tok :=
  if isAnd then
    if va then
      if vb then twoTape D G a.val b.val q.val else oneTape D G (-b.val) (-q.val)
    else oneTape D G (-a.val) (-q.val)
  else if va then oneTape D G a.val q.val
    else if vb then oneTape D G b.val q.val else twoTape D G (-a.val) (-b.val) (-q.val)

theorem binary_check (D:List Row) (G:List Int) (isAnd va vb:Bool) (a b q:Bit)
    (hg:Valid G) (hr:BinaryRows D isAnd a b q)
    (ha:guarded G (sign va a)∈D) (hb:guarded G (sign vb b)∈D) :
    polEval (dbOf D) (tape D G isAnd va vb a b q) []=
      some (guarded G (sign (value isAnd va vb) q)) := by
  have swap (x y:Int) (hx:x≠0) (hy:y≠0) : clause [x,y]=clause [y,x] :=
    PriorityExclusive.clause_swap x y hx hy
  cases isAnd <;> cases va <;> cases vb <;> simp only [tape,value,sign,Bool.false_eq_true,true_and,↓reduceIte,
    Bool.false_and,Bool.true_and,Bool.false_or,Bool.true_or] at *
  · apply two_check D G (-a.val) (-b.val) (-q.val) hg (neg_ne_zero.mpr a.property)
      (neg_ne_zero.mpr b.property) (neg_ne_zero.mpr q.property) ha hb
    simpa only [neg_neg,Bool.false_eq_true,↓reduceIte] using hr.up
  · exact one_check D G b.val q.val hg b.property q.property hb hr.right
  · exact one_check D G a.val q.val hg a.property q.property ha hr.left
  · exact one_check D G a.val q.val hg a.property q.property ha hr.left
  · apply one_check D G (-a.val) (-q.val) hg (neg_ne_zero.mpr a.property) (neg_ne_zero.mpr q.property) ha
    simpa only [neg_neg,↓reduceIte,swap (-q.val) a.val (neg_ne_zero.mpr q.property) a.property] using hr.left
  · apply one_check D G (-a.val) (-q.val) hg (neg_ne_zero.mpr a.property) (neg_ne_zero.mpr q.property) ha
    simpa only [neg_neg,↓reduceIte,swap (-q.val) a.val (neg_ne_zero.mpr q.property) a.property] using hr.left
  · apply one_check D G (-b.val) (-q.val) hg (neg_ne_zero.mpr b.property) (neg_ne_zero.mpr q.property) hb
    simpa only [neg_neg,↓reduceIte,swap (-q.val) b.val (neg_ne_zero.mpr q.property) b.property] using hr.right
  · exact two_check D G a.val b.val q.val hg a.property b.property q.property ha hb hr.up

theorem tape_length (D:List Row) (G:List Int) (isAnd va vb:Bool) (a b q:Bit) :
    (tape D G isAnd va vb a b q).length≤8 := by
  cases isAnd <;> cases va <;> cases vb <;> simp [tape,oneTape,twoTape]

#print axioms binary_check
#print axioms tape_length
end L3Emitter.GuardedGatePOL

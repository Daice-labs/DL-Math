import SelectedAlias

namespace L3Emitter.AliasClauseTransport
open EREF EREF.GeneralRED REDWitness ReferenceTransport Resolution
open ProjectionTrace SelectedAlias ClauseTransport

structure Bit where
  source : Int
  term : Int
  target : Int
  others : List (Int×Int)
  deriving DecidableEq

def bitRows (c : Int) (b : Bit) : List Row :=
  [clause [-c,-b.source,b.target],clause [-c,-b.target,b.source]]

/-- The literal AND/OR rows emitted for one selected alias bit. -/
structure BitInputs (rows : List Row) (c : Int) (b : Bit) : Prop where
  choice : c≠0
  source : b.source≠0
  term : b.term≠0
  target : b.target≠0
  others : ∀p∈b.others,p.1≠0 ∧ p.2≠0
  and_forward : clause [-c,-b.source,b.term]∈rows
  or_forward : clause [-b.term,b.target]∈rows
  or_backward : clause (-b.target::b.term::b.others.map Prod.snd)∈rows
  and_backward : clause [-b.term,b.source]∈rows
  other_rows : ∀p∈b.others,clause [-p.2,p.1]∈rows ∧ clause [-c,-p.1]∈rows

theorem BitInputs.mono {base rows : List Row} {c : Int} {b : Bit}
    (h : BitInputs base c b) (hm : ∀R∈base,R∈rows) : BitInputs rows c b :=
  ⟨h.choice,h.source,h.term,h.target,h.others,hm _ h.and_forward,hm _ h.or_forward,
   hm _ h.or_backward,hm _ h.and_backward,
   fun p hp => ⟨hm _ (h.other_rows p hp).1,hm _ (h.other_rows p hp).2⟩⟩

theorem bit_trace (rows : List Row) (c : Int) (b : Bit) (h : BitInputs rows c b) :
    CheckedTrace rows (rows++bitRows c b) := by
  have hf := forward_succeeds rows c b.source b.term b.target
    h.choice h.source h.term h.target h.and_forward h.or_forward
  let next := rows++[clause [-c,-b.source,b.target]]
  have hn := h.mono (rows:=next) (by intro R hR; exact List.mem_append_left _ hR)
  have hb := back_succeeds next c b.source b.term b.target b.others
    hn.choice hn.source hn.term hn.target hn.others hn.or_backward hn.and_backward hn.other_rows
  have ht : CheckedTrace rows ((rows++[clause [-c,-b.source,b.target]])++[clause [-c,-b.target,b.source]]) :=
    .cons (.pol rows _ _ hf) (.cons (.pol next _ _ hb) (.refl _))
  simpa only [bitRows,List.append_assoc,List.singleton_append] using ht

def bitBody (c : Int) (bs : List Bit) : List Row := bs.flatMap (bitRows c)

theorem bits_trace (rows : List Row) (c : Int) (bs : List Bit)
    (hi : ∀b∈bs,BitInputs rows c b) : CheckedTrace rows (rows++bitBody c bs) :=
  append_blocks bs rows (bitRows c) (by
    intro b hb base hbase
    exact bit_trace base c b ((hi b hb).mono hbase))

structure SignedBit where
  bit : Bit
  positive : Bool
  deriving DecidableEq

def SignedBit.source (b : SignedBit) : Int := if b.positive then b.bit.source else -b.bit.source
def SignedBit.target (b : SignedBit) : Int := if b.positive then b.bit.target else -b.bit.target

def link (rows : List Row) (c : Int) (b : SignedBit) : Link :=
  .mapped b.source b.target (locate rows (clause [-c,-b.source,b.target]))

theorem link_row_member (rows : List Row) (c : Int) (b : SignedBit)
    (hc : c≠0) (ha : b.bit.source≠0) (hq : b.bit.target≠0)
    (hm : ∀R∈bitRows c b.bit,R∈rows) :
    clause [-c,-b.source,b.target]∈rows := by
  cases hp : b.positive with
  | true => exact hm _ (by simp [bitRows,SignedBit.source,SignedBit.target,hp])
  | false =>
    have he : clause [-c,-b.source,b.target]=clause [-c,-b.bit.target,b.bit.source] := by
      simp only [SignedBit.source,SignedBit.target,hp,Bool.false_eq_true,↓reduceIte,neg_neg]
      apply clause_perm _ _ (by simp [Valid,hc,ha,hq]) (by simp [Valid,hc,ha,hq])
      exact ((List.Perm.swap b.bit.source (-b.bit.target) []).symm).cons (-c)
    rw [he]
    exact hm _ (by simp [bitRows])

def links (rows : List Row) (c : Int) (bs : List SignedBit) : List Link := bs.map (link rows c)
def source (bs : List SignedBit) : Row := clause (bs.map SignedBit.source)
def target (bs : List SignedBit) : Row := clause (bs.map SignedBit.target)
def body (c : Int) (bs : List SignedBit) : List Row := bitBody c (bs.map SignedBit.bit)
def caseRows (c : Int) (bs : List SignedBit) : List Row :=
  body c bs ++ [branch (target bs) (-c)]
def caseTokens (rows : List Row) (c : Int) (bs : List SignedBit) : List Tok :=
  ClauseTransport.tokens (locate rows (source bs)) (-c) (links rows c bs)

/-- A complete selected-source clause transport. Each source literal may
    have either polarity; all bit implications are constructed first. -/
theorem clause_trace (rows : List Row) (c : Int) (bs : List SignedBit)
    (hc : c≠0) (hne : bs≠[])
    (hi : ∀b∈bs,BitInputs rows c b.bit) (hs : source bs∈rows) :
    CheckedTrace rows (rows++caseRows c bs) := by
  have ht := bits_trace rows c (bs.map SignedBit.bit) (by
    intro b hb; obtain ⟨sb,hsb,rfl⟩ := List.mem_map.mp hb; exact hi sb hsb)
  let next := rows++body c bs
  have hsrc : sourceClause (links next c bs)=source bs := by
    simp [sourceClause,links,link,Link.source,source,List.map_map,Function.comp_def]
  have htgt : targetClause (links next c bs)=target bs := by
    simp [targetClause,links,link,Link.target,target,List.map_map,Function.comp_def]
  have hlinks : ∀p∈links next c bs,p.Available (dbOf next) (-c) := by
    intro p hp; obtain ⟨b,hb,rfl⟩ := List.mem_map.mp hp
    have h := hi b hb
    refine ⟨?_,?_,?_⟩
    · have hz := h.source
      dsimp [link,Link.source,SignedBit.source]; split <;> omega
    · have hz := h.target
      dsimp [link,Link.target,SignedBit.target]; split <;> omega
    · apply locate_correct
      exact link_row_member next c b hc h.source h.target (by
        intro R hR
        apply List.mem_append_right
        exact List.mem_flatMap.mpr ⟨b.bit,List.mem_map.mpr ⟨b,hb,rfl⟩,hR⟩)
  have he := ClauseTransport.succeeds (dbOf next) (locate next (source bs)) (-c) (by omega)
    (links next c bs) (by simpa [links] using hne)
    (by rw [hsrc]; exact locate_correct _ _ (List.mem_append_left _ hs)) hlinks
  rw [htgt] at he
  have hlast : CheckedTrace next (next++[branch (target bs) (-c)]) :=
    .cons (.pol next _ _ he) (.refl _)
  simpa only [next,caseRows,List.append_assoc] using ProjectionTrace.trans ht hlast

def familyBody {ι : Type} (is : List ι) (c : ι→Int) (bs : ι→List SignedBit) : List Row :=
  is.flatMap (fun i => caseRows (c i) (bs i))

/-- Select one source, transport its entire clause, then merge all source
    cases. This instantiates alias ALO and pairwise AMO by the literal list;
    it does not assume an arbitrary refutation or a successful synth call. -/
theorem selected_clause {ι : Type} (rows : List Row) (is : List ι) (c : ι→Int)
    (bs : ι→List SignedBit) (C : Row)
    (hne : is≠[]) (hc : ∀i∈is,c i≠0) (hn : ∀i∈is,bs i≠[])
    (hi : ∀i∈is,∀b∈bs i,BitInputs rows (c i) b.bit)
    (hs : ∀i∈is,source (bs i)∈rows)
    (htarget : ∀i∈is,target (bs i)=C)
    (ha : clause (is.map c)∈rows) (hC : Canonical C) :
    CheckedTrace rows (rows++familyBody is c bs++[C]) := by
  have ht := append_blocks is rows (fun i => caseRows (c i) (bs i)) (by
    intro i hii base hbase
    exact clause_trace base (c i) (bs i) (hc i hii) (hn i hii)
      (by intro b hb; exact (hi i hii b hb).mono hbase) (hbase _ (hs i hii)))
  let next := rows++familyBody is c bs
  have hj := join_cases next is c C hC hne hc (List.mem_append_left _ ha) (by
    intro i hii
    apply List.mem_append_right
    apply List.mem_flatMap.mpr
    refine ⟨i,hii,?_⟩
    simp [caseRows,htarget i hii])
  exact ProjectionTrace.trans ht (.cons (.pol next _ _ hj) (.refl _))

#print axioms bit_trace
#print axioms clause_trace
#print axioms selected_clause
end L3Emitter.AliasClauseTransport

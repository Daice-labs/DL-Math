import GlobalMainTapeBounds
import LowerEvaluationTapeBounds
namespace L3Emitter.GlobalPortTapeBounds
open EREF EREF.GeneralRED U2ConstructionSize

theorem bank (n : Nat) (hn : 2≤n) :
    tokens (GlobalPortValues.program n hn)≤
      (3*(n+1)-4)*2*(2^n*(4*n-4)*4)*(208*n+2) := by
  have h:=fold_tokens (GlobalPortValues.block n hn) (GlobalPortValues.blockRows n hn)
    (GlobalPortValues.jobs n) (GlobalValueInduction.result n hn) (208*n+2) (by
      intro j hj D
      have hg:=((GlobalPortValues.job_mem n j).mp hj).1
      have ht:=PortValueBounds.port_tokens n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1
        (SourceCoordinateValue.value n hn j.2.2.2.1 j.2.2.1) j.2.2.2.2.1 j.2.2.2.2.2 D
      change tokens (GlobalPortValues.block n hn j D)≤_ at ht
      omega)
  simpa only [GlobalPortValues.program,ConstructionPortCount.jobs n hn] using h

/-- Complete global port-value bank: main POL tokens, not commands or bytes. -/
theorem closed (n : Nat) (hn : 2≤n) :
    tokens (GlobalPortValues.program n hn)≤20160*(n+1)^3*2^n := by
  have h:=bank n hn
  have hm:=Nat.mul_le_mul
    (Nat.mul_le_mul (Nat.mul_le_mul_right 2 (Nat.sub_le (3*(n+1)) 4))
      (Nat.mul_le_mul_right 4 (Nat.mul_le_mul_left (2^n) (show 4*n-4≤4*(n+1) by omega))))
    (show 208*n+2≤210*(n+1) by omega)
  exact h.trans (hm.trans_eq (by ring))

theorem in_formula (n : Nat) (hn : 2≤n) :
    tokens (GlobalPortValues.program n hn)≤20160*(ConstructionFormulaScale.rows n)^4 := by
  have h:=ConstructionFormulaScale.monomial n 3 1 20160 hn
  exact (closed n hn).trans (by simpa using h)
#print axioms closed
#print axioms in_formula
end L3Emitter.GlobalPortTapeBounds

import NumericFrontendComplete
import RecordedBaseTwo
namespace L3Emitter.NumericBaseFields
open EREF EREF.GeneralRED RecordedOperandFields FieldLengthsFromIDs

def bound : Nat := NumericFrontendComplete.bound 2 2

theorem tail (M:Nat) (hM:2≤M):
 ∀c∈RecordedBaseTwo.polProgram BaseTwo.program,Content M c:=by
 intro c hc
 obtain ⟨z,hz,rfl⟩:=List.mem_map.mp hc
 obtain rfl:=List.mem_singleton.mp hz
 change Tape M (CommonGuardResolve.tape BaseTwo.D [] [] [] _)
 intro t ht
 simp only [CommonGuardResolve.tape,ClauseTransport.padSteps,List.nil_append,
   List.flatMap_nil,List.append_nil,List.cons_append,List.mem_cons,List.not_mem_nil,or_false] at ht
 rcases ht with rfl|rfl|rfl|rfl
 · trivial
 · trivial
 · trivial
 · exact hM

theorem program : ∀c∈RecordedBaseTwo.program,Content bound c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · exact NumericFrontendComplete.program 2 2 (by decide) (by decide) c hc
 · exact tail bound (by unfold bound NumericFrontendComplete.bound;omega) c hc
#print axioms program
end L3Emitter.NumericBaseFields

import ConcretePortCost

namespace L3Emitter.ConcretePortTokens
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteSelection ConcretePortRows RecursiveAliases ConcretePortCost
open PrioritySize AliasProgram
variable {base : List Row} {w : Nat}

theorem tabulate_cells (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base)
    (P : Nat) (hf : ∀i,(f i).length≤P) :
    ∀j∈jobs n f z,j.es.length≤P := by
  induction n generalizing z with
  | zero=>simp [jobs,List.ofFn_zero]
  | succ n ih=>
    intro j hj
    change j∈List.ofFn (ConcretePortRows.run (n+1) f z).1 at hj
    rw [List.ofFn_succ] at hj
    rcases List.mem_cons.mp hj with rfl|hj
    · change (cells (f 0) z).length≤P
      rw [cells,cells_length];exact hf 0
    · exact ih (fun i=>f i.succ) (select (f 0) z).2 (fun i=>hf i.succ) j hj

theorem port_cells (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) (z : Net base) :
    ∀j∈(ConcreteOriginalPorts.recorded k g sel as z).1.2,j.es.length≤k+g :=
  tabulate_cells _ _ z _ (fun i=>by simp [ConcreteOriginalPorts.portInputs])

theorem step_cells (c : Config Bit) (as : Nat→AliasBits w) (g : Nat) (z : Net base) :
    ∀j∈(RecordedAliasSteps.step c as g z).1.2,j.es.length≤c.k+g := by
  intro j hj
  change j∈(ConcreteOriginalPorts.recorded c.k g (c.sel g 0) as z).1.2++
    (ConcreteOriginalPorts.recorded c.k g (c.sel g 1) as
      (ConcreteOriginalPorts.recorded c.k g (c.sel g 0) as z).2).1.2 at hj
  rcases List.mem_append.mp hj with hj|hj
  · exact port_cells _ _ _ _ _ j hj
  · exact port_cells _ _ _ _ _ j hj

theorem run_cells (c : Config Bit) (as : Nat→AliasBits w) (g m : Nat) (z : Net base) :
    ∀j∈(RecordedAliasRun.run c as g m z).1.2,j.es.length≤c.k+g+m := by
  induction m generalizing as g z with
  | zero=>intro j hj;exact False.elim (List.not_mem_nil hj)
  | succ m ih=>
    let a:=RecordedAliasSteps.step c as g z
    intro j hj
    change j∈a.1.2++(RecordedAliasRun.run c (Function.update as (c.k+g) a.1.1) (g+1) m a.2).1.2 at hj
    rcases List.mem_append.mp hj with hj|hj
    · have:=step_cells c as g z j hj;omega
    · have:=ih (Function.update as (c.k+g) a.1.1) (g+1) a.2 j hj;omega

theorem cell_tokens (D : List Row) (es : List Cell) (q : AliasNetwork.Bit) (e : Cell) (he:e∈es) :
    tokensCount (bitProgram D e.choice.val (ConcreteSelection.bit es q e))=8*(es.length-1)+9 := by
  have ho : (others es e).length=es.length-1 := by
    simp [ConcreteSelection.others,List.length_erase_of_mem he]
  simp [tokensCount,bitProgram,SelectedAlias.forwardTokens,
    SelectedAlias.back_token_count,ConcreteSelection.bit,ho]
  omega

theorem selection_tokens (D : List Row) (es todo : List Cell) (q : AliasNetwork.Bit)
    (ht:∀e∈todo,e∈es) :
    tokensCount (ConcreteSelectionProgram.program D es q todo)=todo.length*(8*(es.length-1)+9) := by
  induction todo generalizing D with
  | nil=>simp [ConcreteSelectionProgram.program,tokensCount]
  | cons e todo ih=>
    rw [ConcreteSelectionProgram.program,tokens_append,cell_tokens D es q e (ht e (by simp)),
      ih _ (by intro d hd;exact ht d (by simp [hd]))]
    simp only [List.length_cons];ring

theorem program_tokens (D : List Row) (js : List Job) (P : Nat)
    (hj : ∀j∈js,j.es.length≤P) :
    tokensCount (ConcretePortRows.program D js)≤mass js*(8*P+9) := by
  induction js generalizing D with
  | nil=>simp [ConcretePortRows.program,tokensCount,mass]
  | cons j js ih=>
    rw [ConcretePortRows.program,tokens_append,selection_tokens _ _ _ _ (by intros;assumption)]
    have hh : j.es.length*(8*(j.es.length-1)+9)≤j.es.length*(8*P+9):=
      Nat.mul_le_mul_left _ (by have:=hj j (by simp);omega)
    have ht:=ih (D++jobRows j) (fun d hd=>hj d (by simp [hd]))
    change _≤(j.es.length+mass js)*(8*P+9)
    nlinarith

theorem built_tokens (n : Nat) (hn : 2≤n) :
    tokensCount (RecordedAliasRun.program n hn)≤
      3072*(n+1)^4+2400*(n+1)^3+432*(n+1)^2 := by
  let k:=n+1
  let z:=initial (AliasAssembly.source n hn) (AliasAssembly.source_canonical n hn)
  let c:=AliasAssembly.context k (by omega) z
  have hc : c.1.k=k:=rfl
  have hcell:=run_cells c.1 (AliasAssembly.inputAliases (AliasAssembly.width k) c.1) 0 (3*k-4) c.2
  have hm:=run_mass c.1 (AliasAssembly.inputAliases (AliasAssembly.width k) c.1) 0 (3*k-4) c.2
  rw [hc] at hcell hm
  have hb:=ConcretePortCost.built_count n hn
  rw [RecordedAliasRun.program,program_count] at hb
  have ht:=program_tokens (RecordedAliasRun.built n hn).2.rows (RecordedAliasRun.built n hn).1.2
    (4*k) (fun j hj=>by have:=hcell j hj;omega)
  change tokensCount (ConcretePortRows.program _ _)≤_
  change _≤3072*k^4+2400*k^3+432*k^2
  have hmass : mass (RecordedAliasRun.built n hn).1.2≤96*k^3+48*k^2 := by
    change 2*mass (RecordedAliasRun.built n hn).1.2≤192*k^3+96*k^2 at hb
    omega
  have hp:=Nat.mul_le_mul_right (8*(4*k)+9) hmass
  exact ht.trans (hp.trans (by ring_nf;exact Nat.le_refl _))

#print axioms run_cells
#print axioms selection_tokens
#print axioms built_tokens
end L3Emitter.ConcretePortTokens

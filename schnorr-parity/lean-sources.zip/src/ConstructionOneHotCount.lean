import ConstructionCountTools
import MuxVectorOneHot

namespace L3Emitter.ConstructionOneHotCount
open EREF EREF.GeneralRED REDWitness AliasNetwork RecordedPortLinks
open SelectedVectorOneHot
variable {w : Nat}

theorem pairs (w : Nat) : (pairSpecs w).length≤w^2 := by
  have h:=FormulaSize.flatMap_bound (List.finRange w)
    (fun i=>(List.finRange w).filterMap (fun j=>if i<j then some (pairSpec i j) else none)) w
    (by intro i hi;exact (List.length_filterMap_le ..).trans (by simp))
  simpa [pairSpecs,pow_two] using h

theorem specifications (w : Nat) : (specs w).length≤1+w^2 := by
  have h:=pairs w
  simp only [specs,List.length_cons]
  omega

theorem clause (D : List Row) (cs : List Bit) (a : Bit→AliasBits w)
    (q : AliasBits w) (ls : List (Lit w)) :
    (SelectedVectorClauses.program D cs a q ls).length=cs.length+1 := by
  simp [SelectedVectorClauses.program,SelectedVectorClauses.cases]

theorem family (D : List Row) (cs : List Bit) (a : Bit→AliasBits w)
    (q : AliasBits w) (ls : List (List (Lit w))) :
    (SelectedVectorOneHot.family D cs a q ls).length=ls.length*(cs.length+1) := by
  induction ls generalizing D with
  | nil => simp [SelectedVectorOneHot.family]
  | cons l ls ih =>
    simp only [SelectedVectorOneHot.family,List.length_append,clause,ih,List.length_cons]
    ring

/-- Includes every selected-case line, every join and the aggregate AMO tape.
Unit: MAIN POL COMMANDS; no database-length or accumulated-tail premise. -/
theorem selected (D : List Row) (cs : List Bit) (a : Bit→AliasBits w) (q : AliasBits w) :
    (SelectedVectorOneHot.program D cs a q).length≤(1+w^2)*(cs.length+1)+w := by
  have ho:=OneHotSize.commands_bound (intermediate D cs q) (sourceLiterals q)
  simp only [sourceLiterals,List.length_ofFn] at ho
  simp only [SelectedVectorOneHot.program,List.length_append,family]
  exact Nat.add_le_add (Nat.mul_le_mul_right _ (specifications w)) ho

theorem mux (D : List Row) (c : Bit) (a b q : AliasBits w) :
    (MuxVectorOneHot.program D c a b q).length≤3*w^2+w+4 := by
  have h:=selected (MuxVectorOneHot.seeded D c) [c,neg c]
    (MuxVectorOneHot.inputs c a b) q
  simp only [List.length_cons,List.length_nil] at h
  simp only [MuxVectorOneHot.program,List.length_append,MuxVectorOneHot.seedProgram,List.length_cons,List.length_nil]
  nlinarith

#print axioms selected
#print axioms mux
end L3Emitter.ConstructionOneHotCount

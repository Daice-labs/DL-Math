import L3PortCoverage

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def wireCoverC (t : StI F.V) (g p cb q : Nat) : List Int :=
  [(t.s.A : Int),-(cb : Int),-(t.s.live g : Int),(F.sel g p 0 : Int),(q : Int)]
def wireForceC (t : StI F.V) (g p : Nat) : List Int :=
  [(t.s.A : Int),-(t.s.live g : Int),-(F.sel g p 0 : Int),-(t.s.force g p : Int)]

theorem wire_cover_obl (hk : 2≤F.k) (t : StI F.V) (g p bit cb q : Nat)
    (hg : g<F.s) (hp : p<2) (hi : F.WireInv g p bit cb q t)
    (hr : ∀j,1≤j → j<F.k+g → Cmd.rup (F.wireC t g p j cb q)∈t.s.cmds)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R) (hm : ∀R∈exec F.db5 t.s.cmds,R∈D) :
    Refutation (D ++ [negate (clauseRow (F.wireCoverC t g p cb q)).toE]) := by
  let xs := (List.range' 1 (F.k+g-1)).map fun j => (F.sel g p j : Int)
  have hA := hi.1.2.2.2.2.2.1
  have hL := (F.live_bound_of_good3 hi.1 g hg).1
  have hC := hi.2.2.2.1.1
  have hQ := hi.2.2.2.2.1
  have hS := F.sel_pos g p 0
  apply selector_coverage D hD [(t.s.A : Int),-(cb : Int),-(t.s.live g : Int)]
    (F.sel g p 0 : Int) (q : Int) xs
  · intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl | rfl <;> omega
  · omega
  · omega
  · intro l hl
    obtain ⟨j,_,rfl⟩ := List.mem_map.mp hl
    have := F.sel_pos g p j; omega
  · intro l hl
    obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hl
    have hj' := List.mem_range'_1.mp hj
    exact hm _ (rup_row_mem F.db5 t.s.cmds _ (hr j hj'.1 (by omega)))
  · have eq : clauseRow ((F.sel g p 0 : Int)::xs)=F.row1 g p := by
      simp only [clauseRow,row1,xs,List.map_map,range_head (F.k+g) (by omega),List.map_cons,pos,Function.comp_def]
    rw [eq]
    exact hm _ (exec_mono _ _ _ (F.original_mem_db5 _ (F.row1_mem g p hg hp)))

def wireFinish (g p cb q : Nat) (t : StI F.V) : StI F.V :=
  (t.rup (F.wireCoverC t g p cb q)).rup (F.wireForceC t g p)

theorem wireFinish_bounds (hk : 2≤F.k) (t : StI F.V) (g p bit cb q : Nat)
    (hg1 : 1≤g) (hg : g<F.s) (hp : p<2) (hi : F.WireInv g p bit cb q t) :
    Bounded t.s.var (F.wireCoverC t g p cb q) ∧ Bounded t.s.var (F.wireForceC t g p) := by
  have hA0 := hi.1.2.2.2.2.2.1
  have hA1 := hi.1.2.2.2.2.2.2
  have hL := F.live_bound_of_good3 hi.1 g hg
  have hC := hi.2.2.2.1
  have hQ := hi.2.2.2.2
  have hS := F.sel_pos g p 0
  have hSU := F.sel_le_S g p 0 hg (by omega) (by omega)
  have hSV := F.S_le_V
  have hV := t.var_ge
  have hForce := (hi.1.2.2.1 g p hg1 hg hp).2.2.1
  have hF0 := hForce.2.1
  have hF1 := hForce.2.2
  constructor
  · intro l hl
    simp only [wireCoverC,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl | rfl | rfl | rfl <;> simp <;> omega
  · intro l hl
    simp only [wireForceC,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl | rfl | rfl <;> simp <;> omega

theorem wireFinish_commands (hk : 2≤F.k) (t : StI F.V) (g p bit cb q : Nat)
    (hg1 : 1≤g) (hg : g<F.s) (hp : p<2) (hi : F.WireInv g p bit cb q t) :
    (F.wireFinish g p cb q t).s.cmds=t.s.cmds ++
      [.rup (F.wireCoverC t g p cb q),.rup (F.wireForceC t g p)] := by
  obtain ⟨hc,hf⟩ := F.wireFinish_bounds hk t g p bit cb q hg1 hg hp hi
  change (t.s.cmds ++ [.rup (t.s.chk _)]) ++ [.rup (t.s.chk _)] = _
  rw [StI.chk_eq t _ hc,StI.chk_eq t _ hf]
  simp

theorem wireFinish_obls (hk : 2≤F.k) (hs : 1≤F.s) (t : StI F.V) (g p bit cb q : Nat)
    (hg1 : 1≤g) (hg : g<F.s) (hp : p<2) (hi : F.WireInv g p bit cb q t)
    (hr : ∀j,1≤j → j<F.k+g → Cmd.rup (F.wireC t g p j cb q)∈t.s.cmds)
    (hc : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.wireFinish g p cb q t).s.cmds := by
  rw [F.wireFinish_commands hk t g p bit cb q hg1 hg hp hi]
  apply obligations_append F.db5 _ _ hc
  have hD := (exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) hs) t.inv.1).canonical
  have h1 := F.wire_cover_obl hk t g p bit cb q hg hp hi hr _ hD (fun _ h => h)
  have h2 := F.good3_forcing_consumer hi.1 g p hg1 hg hp
    ((exec F.db5 t.s.cmds) ++ [(clauseRow (F.wireCoverC t g p cb q)).toE])
    (by
      intro R h
      rcases List.mem_append.mp h with h | h
      · exact hD R h
      · rw [List.mem_singleton.mp h]; exact canonical_toE _)
    (fun _ h => List.mem_append_left _ h)
  intro o ho
  simp only [obls,List.mem_cons,List.not_mem_nil,or_false] at ho
  rcases ho with rfl | rfl
  · exact h1
  · exact h2

#print axioms wire_cover_obl
#print axioms wireFinish_obls
end L3.Fam

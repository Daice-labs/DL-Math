import ForcingValueCases
import RetainedBlockFold
namespace L3Emitter.ForcingNodeValue
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL

def target (n:Nat) (hn:2≤n) (g x:Nat) (node:PriorityBank.Node)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):=clause (-(node.choice:Int)::RankChoiceLift.lits n hn g x i b v)
def rows (n:Nat) (hn:2≤n) (g x:Nat) (node:PriorityBank.Node)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):List Row:=
  match ForcingNodeSource.lookup n hn node with
  | none=>[]
  | some z=>ForcingValueCases.rows n hn g ((node,z),x) i b v

def program (n:Nat) (hn:2≤n) (g x:Nat) (node:PriorityBank.Node)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):Program:=
  match ForcingNodeSource.lookup n hn node with
  | none=>[]
  | some z=>ForcingValueCases.program n hn g ((node,z),x) i b v D

theorem beta_job (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n)
    (node:PriorityBank.Node) (hnod:node∈ForcingNodeSource.nodes n hn)
    (z:ForcingCandidates.Candidate (3*(n+1)-4)) (he:ForcingNodeSource.lookup n hn node=some z):
    ((node,z),x)∈BetaPort.jobs n hn:=
  List.mem_flatMap.mpr ⟨(node,z),ForcingNodeSource.job_valid n hn node hnod z he,List.mem_map.mpr ⟨x,List.mem_range.mpr hx,rfl⟩⟩

theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (x:Nat) (hx:x<FamilyNamespace.truthRows n)
    (node:PriorityBank.Node) (hnod:node∈ForcingNodeSource.nodes n hn) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row)
    (hd:∀R∈SharedValueBank.result n hn,R∈D) (hi:ValueInductionBranches.Before n hn g D):
    check D (program n hn g x node i b v D)=some (D++rows n hn g x node i b v):=by
  obtain ⟨z,he⟩:=ForcingNodeSource.present n hn node hnod
  simp only [program,rows,he]
  exact ForcingValueCases.checks n hn g hg hs ((node,z),x) (beta_job n hn x hx node hnod z he) i b v D hd hi

theorem conclusion_present (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (x:Nat) (hx:x<FamilyNamespace.truthRows n)
    (node:PriorityBank.Node) (hnod:node∈ForcingNodeSource.nodes n hn) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):
    target n hn g x node i b v∈rows n hn g x node i b v:=by
  obtain ⟨z,he⟩:=ForcingNodeSource.present n hn node hnod
  simp only [rows,he]
  exact ForcingValueCases.conclusion_present n hn g hg hs ((node,z),x) (beta_job n hn x hx node hnod z he) i b v

#print axioms checks
#print axioms conclusion_present
end L3Emitter.ForcingNodeValue

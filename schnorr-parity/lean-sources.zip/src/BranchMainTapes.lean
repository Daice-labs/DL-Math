import SourceAuxMainTapes
import FirstGateMainTapes
namespace L3Emitter.BranchMainTapes
open EREF EREF.GeneralRED AliasNetwork U2ConstructionSize GlobalFixedMainTapes

theorem exclusions (n : Nat) (hn : 2≤n) (c : HitExclusions.Choice n) (D : List Row) :
    tokens (HitExclusions.program n hn c D)≤120*(n+1)^3 := by
  have hc:(CategoryPrograms.choices n hn).length≤9*(n+1)^2:=ForcingSize.chosen_bound _ (by omega)
  have h:=map_factor (HitExclusions.gates n c) (HitExclusions.row n hn c)
    (fun g=>SelectedCategoryRows.excludeTape n hn c g .beta D) (40*(n+1)^2) (by
      intro g hg;dsimp only [SelectedCategoryRows.excludeTape]
      rw [ChoiceProjection.exclude_token_count]
      have hs:(GateCategories.support (CategoryPrograms.choices n hn) g .beta).length≤(CategoryPrograms.choices n hn).length:=by
        simp only [GateCategories.support,List.length_map];exact List.length_filter_le ..
      nlinarith)
  have hg:(HitExclusions.gates n c).length≤3*(n+1):=by
    have h:((List.range (c.gamma-1)).map (·+1)).length=c.gamma-1:=by simp
    have hh:=(List.length_filter_le (l:=((List.range (c.gamma-1)).map (·+1))) (p:=fun x=>decide (x≠c.beta)))
    rw [h] at hh
    change (HitExclusions.gates n c).length≤c.gamma-1 at hh
    have:=c.gamma_lt;omega
  exact h.trans ((Nat.mul_le_mul_left _ hg).trans_eq (by ring))

theorem hit_cells (n : Nat) (hn : 2≤n) (c : HitExclusions.Choice n) (D : List Row) :
    tokens (HitBranchBinding.cellProgram n hn c D)≤5*(HitBranchBinding.es n hn c).length := by
  apply map_factor
  intro d hd;dsimp only [HitCellPOL.tape];split
  · change 3≤5;omega
  · change 5≤5;omega

theorem or_tape (D : List Row) (c e h : Int) (xs : List Int) :
    (GuardedOrJoin.tape D c e h xs).length≤4*xs.length+2 := by
  cases xs with
  | nil=>change 2≤2;omega
  | cons x xs=>rw [GuardedOrJoin.token_count _ _ _ _ _ (by simp)];omega

theorem hit (n : Nat) (hn : 2≤n) (c : HitExclusions.Choice n) (D : List Row) :
    tokens (HitBranchBank.program n hn c D)≤154*(n+1)^3 := by
  have h0:=exclusions n hn c D
  have h1:=hit_cells n hn c (D++HitExclusions.rows n hn c)
  have h2:=or_tape (HitBranchBank.mid n hn c D) c.lit (HitBranchBinding.edge n hn c).val
    (HitBranchBinding.hit n hn c).val ((HitBranchBinding.es n hn c).map (fun d=>d.term.val))
  have he:=congrArg List.length (HitSnapshots.properties n hn c.gamma c.gamma_lt).1
  simp only [List.length_map,HitSnapshots.inputs,HitSelectorRows.inputs,List.length_range] at he
  change (HitBranchBinding.es n hn c).length=c.gamma-1 at he
  rw [List.length_map,he] at h2
  rw [he] at h1
  have ht:tokens (HitBranchBank.tailProgram n hn c (HitBranchBank.mid n hn c D))≤5+4*(c.gamma-1)+2:=by
    simp only [HitBranchBank.tailProgram,tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil]
    change 5+((HitBranchBinding.backTape n hn c (HitBranchBank.mid n hn c D)).length+0)≤_
    exact Nat.add_le_add_left h2 5
  rw [HitBranchBank.program,tokens_append,tokens_append]
  have hg:c.gamma-1≤3*(n+1):=by have:=c.gamma_lt;omega
  have h13:(n+1)≤(n+1)^3:=by simpa only [pow_one] using Nat.pow_le_pow_right (show 0<n+1 by omega) (show 1≤3 by omega)
  have hp:1≤(n+1)^3:=Nat.one_le_pow _ _ (by omega)
  nlinarith

theorem hit_loop (n : Nat) (hn : 2≤n) (cs : List (HitExclusions.Choice n)) (D : List Row) :
    tokens (HitBranchBank.loop n hn D cs)≤cs.length*(154*(n+1)^3) := by
  induction cs generalizing D with
  | nil=>simp [HitBranchBank.loop,tokens]
  | cons c cs ih=>
    have h:=hit n hn c D;have ht:=ih (D++HitBranchBank.rows n hn c)
    rw [HitBranchBank.loop,tokens_append,List.length_cons,Nat.succ_mul];omega

theorem hits (n : Nat) (hn : 2≤n) : tokens (HitBranchBank.emitted n hn)≤1386*(n+1)^5 := by
  have h:=hit_loop n hn (CategoryPrograms.choices n hn) (HitBranchBank.base n hn)
  exact h.trans ((Nat.mul_le_mul_right _ (ForcingSize.chosen_bound (n+1) (by omega))).trans_eq (by ring))

theorem receive_leaf (n : Nat) (hn : 2≤n) (c : HitExclusions.Choice n) (D : List Row) :
    tokens (ReceivingEdgeBank.program n hn c D)=17 := rfl

theorem receive_loop (n : Nat) (hn : 2≤n) (cs : List (HitExclusions.Choice n)) (D : List Row) :
    tokens (ReceivingEdgeBank.loop n hn D cs)=17*cs.length := by
  induction cs generalizing D with
  | nil=>simp [ReceivingEdgeBank.loop,tokens]
  | cons c cs ih=>rw [ReceivingEdgeBank.loop,tokens_append,receive_leaf,ih,List.length_cons];omega

theorem receiving (n : Nat) (hn : 2≤n) : tokens (ReceivingEdgeBank.emitted n hn)≤153*(n+1)^2 := by
  have h:=receive_loop n hn (CategoryPrograms.choices n hn) (HitBranchBank.result n hn)
  have hc:(CategoryPrograms.choices n hn).length≤9*(n+1)^2:=ForcingSize.chosen_bound _ (by omega)
  change tokens (ReceivingEdgeBank.emitted n hn)=_ at h
  omega
#print axioms hits
#print axioms receiving
end L3Emitter.BranchMainTapes

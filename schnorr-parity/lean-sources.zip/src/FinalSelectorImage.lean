import FinalSelectorCardinalities
namespace L3Emitter.FinalSelectorImage
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL
open FinalOutputDefinitions FinalSelectorSources FinalSelectorCardinalities
attribute [local irreducible] FinalOutputDefinitions.construction tabulate

theorem selector_wire (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)):
    FinalLowerImage.wire n hn (.sel (lastRank n) p.val i.val)=target n hn p i:=by
  simp only [FinalLowerImage.wire,↓reduceIte,dif_pos p.isLt,dif_pos i.isLt,target]

theorem literal_list (n:Nat) (hn:2≤n) (p:Fin 2) (b:Bool):
    ((List.range (n+lastRank n)).map (fun j=>((1:Int),sign b (FinalLowerImage.wire n hn (.sel (lastRank n) p.val j)))))=
      (xs n hn p).map (fun l=>((1:Int),if b then l else -l)):=by
  rw [width_binding n hn]
  apply List.ext_getElem
  · simp [xs]
  · intro i hi hj
    have hil:i<W n-1:=by simpa using hi
    simp only [List.getElem_map,List.getElem_range,xs,List.getElem_ofFn]
    rw [selector_wire n hn p ⟨i,hil⟩]
    rfl

theorem alo_image (n:Nat) (hn:2≤n) (p:Fin 2):
    FinalLowerImage.image n hn (InputSwap.oneHot n (lastRank n) p.val true)=clause (xs n hn p):=by
  simp only [FinalLowerImage.image,InputSwap.oneHot,List.map_map,Function.comp_def,↓reduceIte]
  rw [literal_list n hn p]
  rfl

theorem amo_image (n:Nat) (hn:2≤n) (p:Fin 2):
    FinalLowerImage.image n hn (InputSwap.oneHot n (lastRank n) p.val false)=Cardinality.amo (xs n hn p):=by
  simp only [FinalLowerImage.image,InputSwap.oneHot,List.map_map,Function.comp_def,Bool.false_eq_true,↓reduceIte]
  rw [literal_list n hn p]
  simp only [Cardinality.amo,xs,List.length_ofFn,Bool.false_eq_true,↓reduceIte]
  rw [←Nat.cast_add,width_binding n hn]

theorem definitions_kept (n:Nat) (hn:2≤n):∀R∈FinalOutputDefinitions.result n hn,R∈FinalSelectorCardinalities.result n hn:=
  fun _ h=>List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ h))

theorem all_selector_images (n:Nat) (hn:2≤n) (r:FamilyRows.Spec)
    (hr:r∈OriginalEncoding.selectorsBlock n (3*n-4)):
    FinalLowerImage.image n hn r∈FinalSelectorCardinalities.result n hn:=by
  obtain ⟨t,p,b,ht,hp,rfl⟩:=(OriginalEncoding.selectors_mem ..).mp hr
  by_cases h:t<lastRank n
  · exact definitions_kept n hn _ (FinalLowerEarlier.selectors n hn t p b h hp)
  · have he:t=lastRank n:=by unfold lastRank RankConstruction.width at *;omega
    subst t
    cases b
    · rw [amo_image n hn ⟨p,hp⟩];exact (final_rows n hn ⟨p,hp⟩).2
    · rw [alo_image n hn ⟨p,hp⟩];exact (final_rows n hn ⟨p,hp⟩).1
#print axioms all_selector_images
end L3Emitter.FinalSelectorImage

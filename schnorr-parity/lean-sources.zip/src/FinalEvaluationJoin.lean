import FinalSelectedJoin
namespace L3Emitter.FinalEvaluationJoin
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL ReferenceTransport Resolution
open FinalOutputDefinitions FinalEvaluationContext
open FinalKeptEvaluation (port)
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def literals (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool):List Int:=
  [-sign a (port n hn x 0),-sign b (port n hn x 1),qlit n hn x a b]
def row (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool):Row:=clause (literals n hn x a b)
def phaseRow (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):Row:=
  branch (row n hn x a b) (-sign side (OutputPhaseRows.phase n hn))
theorem literal_valid (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool):Valid (literals n hn x a b):=by
  simp [literals,qlit,Valid,sign_valid]
theorem kept_eq (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):
    branch (phaseRow n hn x a b side) (-(H n hn).val)=FinalKeptEvaluation.row n hn x a b side:=by
  rw [phaseRow,row,ProjectionTrace.branch_clause _ (literal_valid n hn x a b) _ (neg_ne_zero.mpr (sign_valid _ _))]
  rw [ProjectionTrace.branch_clause _ (by simp [Valid,literals,qlit,sign_valid]) _ (neg_ne_zero.mpr (H n hn).property)]
  rfl
theorem selected_eq (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):
    branch (phaseRow n hn x a b side) (H n hn).val=FinalSelectedJoin.row n hn x a b side:=by
  rw [phaseRow,row,ProjectionTrace.branch_clause _ (literal_valid n hn x a b) _ (neg_ne_zero.mpr (sign_valid _ _))]
  rw [ProjectionTrace.branch_clause _ (by simp [Valid,literals,qlit,sign_valid]) _ (H n hn).property]
  rfl

def phaseRows (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):=
  FinalKeptEvaluation.rows n hn x a b side++FinalSelectedJoin.rows n hn x a b side++[phaseRow n hn x a b side]
def phaseProgram (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row):Program:=
  let E1:=E++FinalKeptEvaluation.rows n hn x a b side
  let E2:=E1++FinalSelectedJoin.rows n hn x a b side
  FinalKeptEvaluation.program n hn x a b side E++FinalSelectedJoin.program n hn x a b side E1++
    [(phaseRow n hn x a b side,mergeTokens (locate E2 (FinalSelectedJoin.row n hn x a b side)) (locate E2 (FinalKeptEvaluation.row n hn x a b side)))]
theorem phase_check (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row) (he:∀R∈D n hn,R∈E):
    check E (phaseProgram n hn x a b side E)=some (E++phaseRows n hn x a b side):=by
  let E1:=E++FinalKeptEvaluation.rows n hn x a b side
  let E2:=E1++FinalSelectedJoin.rows n hn x a b side
  have h0:=FinalKeptEvaluation.checks n hn x a b side E he
  have h1:=FinalSelectedJoin.checks n hn x a b side E1 (fun R h=>List.mem_append_left _ (he R h))
  have hp:FinalSelectedJoin.row n hn x a b side∈E2:=List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _))
  have hm:FinalKeptEvaluation.row n hn x a b side∈E2:=List.mem_append_left _ (List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _)))
  have hj:=merge_succeeds (dbOf E2) (phaseRow n hn x a b side) (canonical_normalize _ _) (H n hn).val (H n hn).property
    (locate E2 (FinalSelectedJoin.row n hn x a b side)) (locate E2 (FinalKeptEvaluation.row n hn x a b side))
    (by rw [selected_eq];exact locate_correct _ _ hp) (by rw [kept_eq];exact locate_correct _ _ hm)
  have h2:check E2 [(phaseRow n hn x a b side,mergeTokens (locate E2 (FinalSelectedJoin.row n hn x a b side)) (locate E2 (FinalKeptEvaluation.row n hn x a b side)))]=
      some (E2++[phaseRow n hn x a b side]):=by simp only [check,hj,↓reduceIte]
  simpa only [phaseProgram,phaseRows,E1,E2,List.append_assoc] using check_append _ _ _ _ _ (check_append _ _ _ _ _ h0 h1) h2

def rows (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool):=
  phaseRows n hn x a b false++phaseRows n hn x a b true++[row n hn x a b]
def program (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool) (E:List Row):Program:=
  let E1:=E++phaseRows n hn x a b false
  let E2:=E1++phaseRows n hn x a b true
  phaseProgram n hn x a b false E++phaseProgram n hn x a b true E1++
    [(row n hn x a b,mergeTokens (locate E2 (phaseRow n hn x a b false)) (locate E2 (phaseRow n hn x a b true)))]
theorem checks (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool) (E:List Row) (he:∀R∈D n hn,R∈E):
    check E (program n hn x a b E)=some (E++rows n hn x a b):=by
  let E1:=E++phaseRows n hn x a b false
  let E2:=E1++phaseRows n hn x a b true
  have h0:=phase_check n hn x a b false E he
  have h1:=phase_check n hn x a b true E1 (fun R h=>List.mem_append_left _ (he R h))
  have hp:phaseRow n hn x a b false∈E2:=List.mem_append_left _ (List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _)))
  have hm:phaseRow n hn x a b true∈E2:=List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _))
  have hj:=merge_succeeds (dbOf E2) (row n hn x a b) (canonical_normalize _ _) (OutputPhaseRows.phase n hn).val (OutputPhaseRows.phase n hn).property
    (locate E2 (phaseRow n hn x a b false)) (locate E2 (phaseRow n hn x a b true))
    (by simpa only [phaseRow,sign,Bool.false_eq_true,↓reduceIte,neg_neg] using locate_correct _ _ hp)
    (by simpa only [phaseRow,sign,↓reduceIte] using locate_correct _ _ hm)
  have h2:check E2 [(row n hn x a b,mergeTokens (locate E2 (phaseRow n hn x a b false)) (locate E2 (phaseRow n hn x a b true)))]=some (E2++[row n hn x a b]):=by
    simp only [check,hj,↓reduceIte]
  simpa only [program,rows,E1,E2,List.append_assoc] using check_append _ _ _ _ _ (check_append _ _ _ _ _ h0 h1) h2
#print axioms checks
end L3Emitter.FinalEvaluationJoin

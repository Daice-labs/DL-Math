import OneHotSerialized

namespace L3Emitter.ComplementChoice
open EREF REDWitness

def tautTokens (l : Int) : List Tok := [.lit l,.lit (-l),.add,.div 2]

theorem taut_pair_succeeds (db : Nat → Option Row) (l : Int) (hl : l ≠ 0) :
    polEval db (tautTokens l) [] = some (clause [l,-l]) := by
  have hA : add (litAxiom l) (litAxiom (-l)) = (⟨[],-1⟩ : Row) := by
    apply canonical_ext _ _ (canonical_add _ _) (by simp [Canonical])
    intro α
    rw [val_add _ _ (canonical_litAxiom _) (canonical_litAxiom _),
      val_litAxiom l hl, val_litAxiom (-l) (by omega), litVal_neg α l hl]
    simp [Row.val, tval]
  have hB : clause [l,-l] = (⟨[],0⟩ : Row) := by
    apply canonical_ext _ _ (canonical_normalize _ _) (by simp [Canonical])
    intro α
    change (clause [l,-l]).val α = (⟨[],0⟩ : Row).val α
    rw [val_clause]
    · simp [Row.val, tval, litVal_neg α l hl]
    · intro t ht; simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
      rcases ht with rfl | rfl <;> omega
  simp [tautTokens, polEval, hl, hA, hB, divide, ceilTerms, ceilDiv,
    ceilTerms.ceilDiv', EREF.normalize, signFix, varsOf, cancelSum]


#print axioms taut_pair_succeeds
end L3Emitter.ComplementChoice

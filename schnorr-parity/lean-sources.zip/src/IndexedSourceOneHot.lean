import SourceOnlyTransport

namespace L3Emitter.IndexedSourceOneHot
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot RecordedPortLinks
variable {w:Nat} {C:Type}

def caseRows (cs:List C) (v:C→Bit) (q:AliasBits w) (ls:List (Lit w)) :=
  cs.map (fun c=>Resolution.branch (RecordedPortLinks.row q ls) (-(v c).val))
def casesProgram (D:List Row) (cs:List C) (v:C→Bit) (a:C→AliasBits w) (q:AliasBits w) (ls:List (Lit w)) :=
  cs.map (fun c=>(Resolution.branch (RecordedPortLinks.row q ls) (-(v c).val),tape D (v c) (a c) q ls))
def block (D:List Row) (cs:List C) (v:C→Bit) (a:C→AliasBits w) (q:AliasBits w) (ls:List (Lit w)) :=
  casesProgram D cs v a q ls++[(RecordedPortLinks.row q ls,
    ProjectionTrace.joinCaseTokens (D++caseRows cs v q ls) cs (fun c=>(v c).val) (RecordedPortLinks.row q ls))]
def blockRows (cs:List C) (v:C→Bit) (q:AliasBits w) (ls:List (Lit w)) :=
  caseRows cs v q ls++[RecordedPortLinks.row q ls]

theorem block_check (D:List Row) (cs:List C) (v:C→Bit) (a:C→AliasBits w) (q:AliasBits w) (ls:List (Lit w))
    (hw:0<w) (hl:ls∈specs w) (hc:cs≠[]) (ha:clause (cs.map (fun c=>(v c).val))∈D)
    (hs:∀c∈cs,SourceRows D (a c)) (hr:∀c∈cs,SourceOnlyTransport.Links D (v c) (a c) q) :
    check D (block D cs v a q ls)=some (D++blockRows cs v q ls) := by
  have h0:check D (casesProgram D cs v a q ls)=some (D++caseRows cs v q ls):=by
    have h:=IndependentProgram.check_base D (casesProgram D cs v a q ls) (by
      intro cmd hm;obtain ⟨c,hc,rfl⟩:=List.mem_map.mp hm
      exact SourceOnlyTransport.tape_check D (v c) (a c) q ls (spec_nonempty hw ls hl)
        ((hs c hc).specs ls hl) (SourceOnlyTransport.spec_source ls hl) (hr c hc))
    simpa [casesProgram,caseRows,outputs,List.map_map] using h
  have he:=ProjectionTrace.join_cases (D++caseRows cs v q ls) cs (fun c=>(v c).val) (RecordedPortLinks.row q ls)
    (canonical_normalize _ _) hc (fun c _=>(v c).property) (List.mem_append_left _ ha)
    (fun c hc=>List.mem_append_right _ (List.mem_map.mpr ⟨c,hc,rfl⟩))
  have h1:check (D++caseRows cs v q ls) [(RecordedPortLinks.row q ls,
      ProjectionTrace.joinCaseTokens (D++caseRows cs v q ls) cs (fun c=>(v c).val) (RecordedPortLinks.row q ls))]=
      some ((D++caseRows cs v q ls)++[RecordedPortLinks.row q ls]):=by simp only [check,he,↓reduceIte]
  simpa only [block,blockRows,List.append_assoc] using check_append _ _ _ _ _ h0 h1

def body (cs:List C) (v:C→Bit) (q:AliasBits w) (ls:List (List (Lit w))) :=ls.flatMap (blockRows cs v q)
def loop (D:List Row) (cs:List C) (v:C→Bit) (a:C→AliasBits w) (q:AliasBits w) : List (List (Lit w))→Program
  | []=>[]
  | ls::rest=>block D cs v a q ls++loop (D++blockRows cs v q ls) cs v a q rest

theorem loop_check (D:List Row) (cs:List C) (v:C→Bit) (a:C→AliasBits w) (q:AliasBits w)
    (todo:List (List (Lit w))) (ht:∀ls∈todo,ls∈specs w) (hw:0<w) (hc:cs≠[])
    (ha:clause (cs.map (fun c=>(v c).val))∈D) (hs:∀c∈cs,SourceRows D (a c))
    (hr:∀c∈cs,SourceOnlyTransport.Links D (v c) (a c) q) :
    check D (loop D cs v a q todo)=some (D++body cs v q todo) := by
  induction todo generalizing D with
  | nil=>simp [loop,body,check]
  | cons ls rest ih=>
    have h0:=block_check D cs v a q ls hw (ht ls (by simp)) hc ha hs hr
    have h1:=ih (D++blockRows cs v q ls) (fun t h=>ht t (by simp [h]))
      (List.mem_append_left _ ha)
      (fun c h=>⟨List.mem_append_left _ (hs c h).1,fun i j hij=>List.mem_append_left _ ((hs c h).2 i j hij)⟩)
      (fun c h i=>⟨List.mem_append_left _ (hr c h i).1,List.mem_append_left _ (hr c h i).2⟩)
    simpa only [loop,body,List.flatMap_cons,List.append_assoc] using check_append _ _ _ _ _ h0 h1

def program (D:List Row) (cs:List C) (v:C→Bit) (a:C→AliasBits w) (q:AliasBits w) :=loop D cs v a q (specs w)
def result (D:List Row) (cs:List C) (v:C→Bit) (q:AliasBits w) :=D++body cs v q (specs w)
theorem checks (D:List Row) (cs:List C) (v:C→Bit) (a:C→AliasBits w) (q:AliasBits w)
    (hw:0<w) (hc:cs≠[]) (ha:clause (cs.map (fun c=>(v c).val))∈D) (hs:∀c∈cs,SourceRows D (a c))
    (hr:∀c∈cs,SourceOnlyTransport.Links D (v c) (a c) q) :
    check D (program D cs v a q)=some (result D cs v q) :=loop_check D cs v a q _ (fun t h=>h) hw hc ha hs hr

theorem source_rows (D:List Row) (cs:List C) (v:C→Bit) (q:AliasBits w) :SourceRows (result D cs v q) q := by
  have mem (ls:List (Lit w)) (h:ls∈specs w) : RecordedPortLinks.row q ls∈result D cs v q:=
    List.mem_append_right _ (List.mem_flatMap.mpr ⟨ls,h,List.mem_append_right _ (by simp)⟩)
  exact ⟨by rw [←alo_binding];exact mem _ (by simp [specs]),
    fun i j hij=>by rw [←pair_binding];exact mem _ (List.mem_cons_of_mem _ (pair_mem i j hij))⟩

#print axioms checks
#print axioms source_rows
end L3Emitter.IndexedSourceOneHot

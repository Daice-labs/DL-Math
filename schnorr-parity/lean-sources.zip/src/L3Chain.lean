/-
Weighted POL chains over the L3 rows, as the uniform tool for every `rup` template of the
frontend: a list of rows of the database (with repetitions) whose literal sums are
negative under every assignment evaluates, by `ref/add` tokens, to a syntactically
contradictory row (`refutation_of_rowlist`). The arithmetic is discharged by `lv_omega`,
which collects the literal values of the goal, adds their 0/1 bounds and the
complement identities, and calls `omega`.
-/
import Lean
import L3FrontendLemmas

namespace L3
open EREF EREF.GeneralRED

theorem lv_bounds (α : Val) (l : Int) : 0 ≤ lv α l ∧ lv α l ≤ 1 := by
  unfold lv b2i; split <;> split <;> omega

/-- conjunction of a predicate over a list, as nested `∧` (for explicit lists) -/
def All {β : Type} (p : β → Prop) : List β → Prop
  | [] => True
  | b :: bs => p b ∧ All p bs

theorem All.mem {β : Type} {p : β → Prop} : ∀ {l : List β}, All p l → ∀ b ∈ l, p b
  | [], _, _, h => by simp at h
  | _ :: _, ⟨h1, h2⟩, b, hb => by
    rcases List.mem_cons.mp hb with rfl | hb
    · exact h1
    · exact All.mem h2 b hb

/-- **chain refutation over L3 rows**: rows of the database whose literal sums (minus the
    right-hand sides) are always negative in total -/
theorem refutation_of_rowlist (D' : List EREF.Row) (hD' : ∀ R ∈ D', Canonical R)
    (rs : List Row) (hne : rs ≠ []) (hmem : All (fun r => r.toE ∈ D') rs) (hnz : All Row.nz rs)
    (hneg : ∀ α, (rs.map fun r => lsum α r.lits - (r.rhs : Int)).sum < 0) : Refutation D' := by
  let f : Nat → EREF.Row := fun j => (dbOf D' j).getD ⟨[], 0⟩
  have hf : ∀ j R, dbOf D' j = some R → f j = R := by intro j R h; simp [f, h]
  have hidx : ∀ (rs : List Row), All (fun r => r.toE ∈ D') rs →
      ∃ is : List Nat, is.map f = rs.map Row.toE ∧ ∀ i ∈ is, dbOf D' i = some (f i) := by
    intro rs
    induction rs with
    | nil => intro _; exact ⟨[], rfl, by simp⟩
    | cons r rs ih =>
      intro h
      obtain ⟨i, hi⟩ := Fam.dbOf_of_mem D' r.toE h.1
      obtain ⟨is, h1, h2⟩ := ih h.2
      refine ⟨i :: is, ?_, ?_⟩
      · simp only [List.map_cons, h1, hf _ _ hi]
      · intro j hj
        rcases List.mem_cons.mp hj with rfl | hj
        · rw [hf _ _ hi]; exact hi
        · exact h2 j hj
  obtain ⟨is, h1, h2⟩ := hidx rs hmem
  cases is with
  | nil => cases rs with
    | nil => exact absurd rfl hne
    | cons r rs => simp at h1
  | cons i0 is' =>
    apply refutation_of_chain D' hD' f i0 is' (h2 i0 (by simp)) (fun i hi => h2 i (by simp [hi]))
    intro α
    have hsum : (f i0).val α + (is'.map fun i => (f i).val α).sum
        = ((rs.map Row.toE).map fun R => R.val α).sum := by
      rw [← h1]; simp only [List.map_cons, List.sum_cons, List.map_map]; rfl
    rw [hsum, List.map_map]
    have := hneg α
    have hmap : (rs.map ((fun R => R.val α) ∘ Row.toE)) = rs.map fun r => lsum α r.lits - (r.rhs : Int) := by
      apply List.map_congr_left
      intro r hr
      simp only [Function.comp]
      exact val_toE r (hnz.mem r hr) α
    rw [hmap]; exact this

/-- the negated clause row's value -/
theorem val_negate_clause (c : List Int) (hc : ∀ l ∈ c, l ≠ 0) (α : Val) :
    (negate (clauseRow c).toE).val α = -lsum α c := by
  rw [val_negate _ (canonical_toE _), val_toE _ (show (clauseRow c).nz from hc)]
  simp only [clauseRow]; omega

/-- the negated clause, as an L3 row: `Σ ¬l ≥ |c|` has the same value -/
def negClause (c : List Int) : Row := { lits := c.map (-·), rhs := c.length }

theorem lsum_map_neg (α : Val) (c : List Int) (hc : ∀ l ∈ c, l ≠ 0) :
    lsum α (c.map (-·)) = c.length - lsum α c := by
  induction c with
  | nil => simp
  | cons l ls ih =>
    simp only [List.map_cons, lsum_cons, List.length_cons]
    rw [ih (fun l' hl' => hc l' (by simp [hl']))]
    have := lv_neg_lit α l (hc l (by simp))
    push_cast; omega

theorem negClause_nz (c : List Int) (hc : ∀ l ∈ c, l ≠ 0) : (negClause c).nz := by
  intro l hl
  unfold negClause at hl
  simp only [List.mem_map] at hl
  obtain ⟨l', hl', rfl⟩ := hl
  have := hc l' hl'; omega

theorem negClause_toE (c : List Int) (hc : ∀ l ∈ c, l ≠ 0) : (negClause c).toE = negate (clauseRow c).toE := by
  apply canonical_ext _ _ (canonical_toE _) (canonical_negate _)
  intro α
  rw [val_toE _ (negClause_nz c hc), val_negate_clause c hc]
  unfold negClause
  simp only
  rw [lsum_map_neg α c hc]; omega

/-- a bounded clause has no zero literal -/
theorem bounded_nz {m : Nat} {c : List Int} (h : Bounded m c) : ∀ l ∈ c, l ≠ 0 :=
  fun l hl => by have := (h l hl).1; omega

/-- the rows of a definition command are in every database that executed it -/
theorem def_row_mem (D : List EREF.Row) (cs : List Cmd) (c : Cmd) (hc : c ∈ cs) (R : EREF.Row) (hR : R ∈ c.rows) :
    R ∈ exec D cs := mem_exec_of_cmd D cs c hc R hR

theorem orDef_row_up (D : List EREF.Row) (cs : List Cmd) (q : Nat) (xs : List Int) (h : Cmd.orDef q xs ∈ cs)
    (x : Int) (hx : x ∈ xs) : (gateRow [-x] q true).toE ∈ exec D cs := by
  apply mem_exec_of_cmd D cs _ h
  simp only [Cmd.rows, orDefs, Defs.rows, List.map_append, List.map_map, List.mem_append, List.mem_map]
  left; exact ⟨x, hx, rfl⟩

theorem orDef_row_down (D : List EREF.Row) (cs : List Cmd) (q : Nat) (xs : List Int) (h : Cmd.orDef q xs ∈ cs) :
    (gateRow xs q false).toE ∈ exec D cs := by
  apply mem_exec_of_cmd D cs _ h
  simp [Cmd.rows, orDefs, Defs.rows]

theorem andDef_row_down (D : List EREF.Row) (cs : List Cmd) (q : Nat) (xs : List Int) (h : Cmd.andDef q xs ∈ cs)
    (x : Int) (hx : x ∈ xs) : (gateRow [x] q false).toE ∈ exec D cs := by
  apply mem_exec_of_cmd D cs _ h
  simp only [Cmd.rows, andDefs, Defs.rows, List.map_append, List.map_map, List.mem_append, List.mem_map]
  left; exact ⟨x, hx, rfl⟩

theorem andDef_row_up (D : List EREF.Row) (cs : List Cmd) (q : Nat) (xs : List Int) (h : Cmd.andDef q xs ∈ cs) :
    (gateRow (xs.map (-·)) q true).toE ∈ exec D cs := by
  apply mem_exec_of_cmd D cs _ h
  simp [Cmd.rows, andDefs, Defs.rows]

theorem eqDef_rows (D : List EREF.Row) (cs : List Cmd) (q : Nat) (a b : Int) (h : Cmd.eqDef q a b ∈ cs) :
    (gateRow [a, b] q true).toE ∈ exec D cs ∧ (gateRow [a, -b] q false).toE ∈ exec D cs ∧
    (gateRow [-a, b] q false).toE ∈ exec D cs ∧ (gateRow [-a, -b] q true).toE ∈ exec D cs := by
  refine ⟨?_, ?_, ?_, ?_⟩ <;> apply mem_exec_of_cmd D cs _ h <;> simp [Cmd.rows, eqDefs, Defs.rows]

theorem rup_row_mem (D : List EREF.Row) (cs : List Cmd) (c : List Int) (h : Cmd.rup c ∈ cs) :
    (clauseRow c).toE ∈ exec D cs := by
  apply mem_exec_of_cmd D cs _ h; simp [Cmd.rows]

/-! ### The `lv_omega` tactic -/

open Lean Elab Tactic Meta in
/-- all subterms `lv α l` of an expression (closed ones only) -/
partial def collectLv (e : Expr) (acc : Array (Expr × Expr)) : Array (Expr × Expr) :=
  let acc := if e.isAppOfArity ``L3.lv 2 && !e.hasLooseBVars then
      acc.push (e.appFn!.appArg!, e.appArg!) else acc
  match e with
  | .app f a => collectLv a (collectLv f acc)
  | .lam _ t b _ => collectLv b (collectLv t acc)
  | .forallE _ t b _ => collectLv b (collectLv t acc)
  | .letE _ t v b _ => collectLv b (collectLv v (collectLv t acc))
  | .mdata _ b => collectLv b acc
  | .proj _ _ b => collectLv b acc
  | _ => acc

open Lean Elab Tactic Meta in
/-- `lv_omega`: for every literal value `lv α l` in the goal add `0 ≤ lv α l ≤ 1`, for every
    `lv α (-x)` add `lv α (-x) + lv α x = 1` (its side condition `x ≠ 0` by `omega` after
    unfolding the index functions), then `omega` -/
elab "lv_omega" : tactic => do
  let g0 ← getMainGoal
  let tgt ← g0.withContext do instantiateMVars (← g0.getType)
  let pairs := collectLv tgt #[]
  let mut seen : Array Expr := #[]
  let mut g := g0
  let mut sides : Array MVarId := #[]
  for (α, l) in pairs do
    if seen.contains l then continue
    seen := seen.push l
    let (g2, s2) ← g.withContext do
      let hb ← mkAppM ``L3.lv_bounds #[α, l]
      let g1 ← g.assert `hlv (← inferType hb) hb
      let (_, g2) ← g1.intro1P
      if l.isAppOfArity ``Neg.neg 3 then
        let x := l.appArg!
        let zero ← Lean.Elab.Tactic.elabTerm (← `((0 : Int))) none
        let pf ← mkFreshExprMVar (← mkAppM ``Ne #[x, zero])
        let hn ← mkAppM ``L3.lv_neg_lit #[α, x, pf]
        let g3 ← g2.withContext do
          let g3 ← g2.assert `hlvn (← inferType hn) hn
          let (_, g4) ← g3.intro1P
          pure g4
        pure (g3, some pf.mvarId!)
      else
        pure (g2, none)
    g := g2
    if let some s := s2 then sides := sides.push s
  for s in sides do
    setGoals [s]
    evalTactic (← `(tactic| first
      | omega
      | (simp only [L3.Fam.sel, L3.Fam.fn, L3.Fam.port, L3.Fam.val, L3.pos, L3.neg]; omega)
      | (simp only [L3.Fam.sel, L3.Fam.fn, L3.Fam.port, L3.Fam.val, L3.pos, L3.neg, ne_eq,
          Int.natCast_eq_zero, Int.neg_eq_zero]; omega)))
  setGoals [g]
  evalTactic (← `(tactic| omega))

/-- the nonzero-literal side condition for an explicit literal list -/
macro "nz_lits" : tactic =>
  `(tactic| (
      intro l hl
      simp only [clauseRow, gateRow, negClause, List.mem_cons, List.mem_singleton, List.not_mem_nil,
        or_false, List.mem_append, List.cons_append, List.nil_append, List.mem_map, pos, neg,
        Bool.false_eq_true, ↓reduceIte] at hl
      rcases hl with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
      first
        | omega
        | (simp only [L3.Fam.sel, L3.Fam.fn, L3.Fam.port, L3.Fam.val]; omega)))


end L3

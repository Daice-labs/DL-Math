import RankEvaluationBank

namespace L3Emitter.HitSelectorRows
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases ConcreteSelection ContextRows
variable {base:List Row}

/-- Actual selector allocations and their defining rows, retained after tabulation. -/
def Rows (D:List Row) (xs:List (Bit×Bit)) (q:Bit):Prop:=
  ∃es:List Cell, es.map (fun e=>(e.choice,e.value))=xs ∧
    (∀e∈es,CellRows D e) ∧ OrRows D (es.map Cell.term) q

theorem Rows.mono {D E:List Row} {xs:List (Bit×Bit)} {q:Bit} (h:Rows D xs q)
    (hm:∀R∈D,R∈E):Rows E xs q:=by
  obtain ⟨es,he,hr,ho⟩:=h
  exact ⟨es,he,fun e h=> (hr e h).mono hm,ho.mono hm⟩

theorem select_rows (xs:List (Bit×Bit)) (z:Net base):Rows (select xs z).2.rows xs (select xs z).1:=by
  rw [←select_binding]
  refine ⟨cells xs z,pairs xs z,?_,actual_or _ _⟩
  intro e he
  exact (ands_rows xs z e he).mono (push_retains _ false _)

def inputs (n:Nat) (hn:2≤n) (g:Nat):List (Bit×Bit):=
  (List.range (g-1)).map fun h=>((PrimaryAliasBank.cfg n hn).beta (h+1),
    (PrimaryAliasBank.cfg n hn).sel g 0 (n+1+(h+1)))

theorem actual (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4):
    Rows (UnaryValueBank.result n hn) (inputs n hn g) ((PrimaryAliasBank.cfg n hn).hit g):=by
  have h:=tabulate_post (3*(n+1)-4)
    (fun g=>select ((List.range (g.val-1)).map (fun h=>
      (AliasAssembly.refAt (neg (truth n hn).1) (betaRun n hn).1 (h+1),
       AliasAssembly.selector (n+1) (3*(n+1)-4) g.val 0 (n+1+(h+1))))))
    (fun g q D=>Rows D ((List.range (g.val-1)).map (fun h=>
      (AliasAssembly.refAt (neg (truth n hn).1) (betaRun n hn).1 (h+1),
       AliasAssembly.selector (n+1) (3*(n+1)-4) g.val 0 (n+1+(h+1))))) q)
    (fun _=>select_extends _) (fun _=>select_rows _)
    (fun _ _ _ _ h hm=>h.mono hm) (keptRun n hn).2 ⟨g,hg⟩
  have he:(PrimaryAliasBank.cfg n hn).hit g=(hitRun n hn).1 ⟨g,hg⟩:=by
    change AliasAssembly.refAt _ (hitRun n hn).1 g=_
    simp only [AliasAssembly.refAt,dif_pos hg]
  rw [he]
  exact h.mono (fun R hr=>UnaryPortTransport.category_keep n hn R
    (CategoryBank.retains n hn R (context_to_endpoint n hn R hr)))

#print axioms actual
end L3Emitter.HitSelectorRows

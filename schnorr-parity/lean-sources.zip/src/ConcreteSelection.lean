import ConcreteGateRows

namespace L3Emitter.ConcreteSelection
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteGateRows
variable {base : List Row}

structure Cell where
  choice : Bit
  value : Bit
  term : Bit
  deriving DecidableEq

/-- Records the exact allocations of the already defined selector compiler. -/
def ands : List (Bit×Bit)→StateM (Net base) (List Cell)
  | [] => pure []
  | (c,v)::xs => fun z=>
      let t:=AND [c,v] z
      let tail:=ands xs t.2
      (⟨c,v,t.1⟩::tail.1,tail.2)

theorem ands_binding (xs : List (Bit×Bit)) (z : Net base) :
    ((ands xs z).1.map Cell.term,(ands xs z).2)=
      (xs.mapM (fun p=>AND [p.1,p.2])) z := by
  induction xs generalizing z with
  | nil => rfl
  | cons p xs ih =>
    rcases p with ⟨c,v⟩
    have h:=ih (AND [c,v] z).2
    change ((AND [c,v] z).1::(ands xs (AND [c,v] z).2).1.map Cell.term,
      (ands xs (AND [c,v] z).2).2)=_
    rw [show (ands xs (AND [c,v] z).2).1.map Cell.term=
      (xs.mapM (fun p=>AND [p.1,p.2]) (AND [c,v] z).2).1 from congrArg Prod.fst h,
      show (ands xs (AND [c,v] z).2).2=
      (xs.mapM (fun p=>AND [p.1,p.2]) (AND [c,v] z).2).2 from congrArg Prod.snd h]
    simp only [List.mapM_cons]
    rfl

theorem choices (xs : List (Bit×Bit)) (z : Net base) :
    (ands xs z).1.map (fun e=>e.choice.val)=xs.map (fun p=>p.1.val) := by
  induction xs generalizing z with
  | nil => rfl
  | cons p xs ih => simp [ands,ih]

theorem pairs (xs : List (Bit×Bit)) (z : Net base) :
    (ands xs z).1.map (fun e=>(e.choice,e.value))=xs := by
  induction xs generalizing z with
  | nil => rfl
  | cons p xs ih => simp [ands,ih]

theorem cells_length (xs : List (Bit×Bit)) (z : Net base) :
    (ands xs z).1.length=xs.length := by
  simpa using congrArg List.length (pairs xs z)

theorem ands_retains (xs : List (Bit×Bit)) (z : Net base) :
    ∀R∈z.rows,R∈(ands xs z).2.rows := by
  induction xs generalizing z with
  | nil => exact fun R hr=>hr
  | cons p xs ih => exact fun R hr=>ih (AND [p.1,p.2] z).2 R (push_retains z true _ R hr)

def CellRows (D : List Row) (e : Cell) : Prop :=
  clause [-e.choice.val,-e.value.val,e.term.val]∈D ∧
  clause [-e.term.val,e.choice.val]∈D ∧ clause [-e.term.val,e.value.val]∈D

theorem CellRows.mono {D E : List Row} {e : Cell} (h : CellRows D e)
    (hm : ∀R∈D,R∈E) : CellRows E e := ⟨hm _ h.1,hm _ h.2.1,hm _ h.2.2⟩

theorem ands_rows (xs : List (Bit×Bit)) (z : Net base) :
    ∀e∈(ands xs z).1,CellRows (ands xs z).2.rows e := by
  induction xs generalizing z with
  | nil => intro e he;exact False.elim (List.not_mem_nil he)
  | cons p xs ih =>
    rcases p with ⟨c,v⟩
    intro e he
    change e∈⟨c,v,(AND [c,v] z).1⟩::(ands xs (AND [c,v] z).2).1 at he
    rcases List.mem_cons.mp he with rfl|he
    · exact CellRows.mono ⟨and_up z c v,and_down z _ c (by simp),and_down z _ v (by simp)⟩
        (ands_retains xs (AND [c,v] z).2)
    · exact ih (AND [c,v] z).2 e he

def cells (xs : List (Bit×Bit)) (z : Net base) := (ands xs z).1
def middle (xs : List (Bit×Bit)) (z : Net base) := (ands xs z).2
def selected (xs : List (Bit×Bit)) (z : Net base) :=
  OR ((cells xs z).map Cell.term) (middle xs z)

theorem select_binding (xs : List (Bit×Bit)) (z : Net base) :
    selected xs z=select xs z := by
  have h:=ands_binding xs z
  unfold selected cells middle
  rw [show (ands xs z).1.map Cell.term=
    (xs.mapM (fun p=>AND [p.1,p.2]) z).1 from congrArg Prod.fst h,
    show (ands xs z).2=(xs.mapM (fun p=>AND [p.1,p.2]) z).2 from congrArg Prod.snd h]
  rfl

def others (es : List Cell) (e : Cell) := (es.erase e).map (fun d=>(d.choice.val,d.term.val))
def bit (es : List Cell) (q : Bit) (e : Cell) : AliasClauseTransport.Bit :=
  ⟨e.value.val,e.term.val,q.val,others es e⟩

/-- All hypotheses of the old POL constructor now follow from the actual
    selector network's rows and the original choice pair clauses. -/
theorem inputs (xs : List (Bit×Bit)) (z : Net base)
    (hn : (xs.map (fun p=>p.1.val)).Nodup)
    (ham : ∀a∈xs,∀b∈xs,a.1.val≠b.1.val→clause [-a.1.val,-b.1.val]∈z.rows)
    (e : Cell) (he : e∈cells xs z) :
    AliasClauseTransport.BitInputs (selected xs z).2.rows e.choice.val
      (bit (cells xs z) (selected xs z).1 e) := by
  let es:=cells xs z
  let q:=(selected xs z).1
  let D:=(selected xs z).2.rows
  have hc : (es.map (fun e=>e.choice.val)).Nodup := by simpa [es,cells,choices] using hn
  have hd : es.Nodup:=List.Nodup.of_map _ hc
  have hor : ∀R∈(middle xs z).rows,R∈D:=push_retains _ false _
  have hrows : ∀d∈es,CellRows D d:=fun d h=>CellRows.mono (ands_rows xs z d h) hor
  have old : ∀R∈z.rows,R∈D:=fun R hr=>hor R (ands_retains xs z R hr)
  have inchoices (d : Cell) (hm : d∈es) : ∃p∈xs,p.1.val=d.choice.val := by
    have hh : d.choice.val∈es.map (fun e=>e.choice.val):=List.mem_map.mpr ⟨d,hm,rfl⟩
    rw [show es.map (fun e=>e.choice.val)=xs.map (fun p=>p.1.val) from choices xs z] at hh
    exact List.mem_map.mp hh
  refine ⟨e.choice.property,e.value.property,e.term.property,q.property,?_,
    (hrows e he).1,?_,?_,(hrows e he).2.2,?_⟩
  · intro p hp;obtain ⟨d,hd,rfl⟩:=List.mem_map.mp hp
    exact ⟨d.choice.property,d.term.property⟩
  · exact or_up (middle xs z) _ e.term (List.mem_map.mpr ⟨e,he,rfl⟩)
  · have hr:=or_down (middle xs z) (es.map Cell.term)
    change clause ((es.map Cell.term).map Subtype.val++[-q.val])∈D at hr
    have hp : ((es.map Cell.term).map Subtype.val++[-q.val]).Perm
        (-q.val::e.term.val::(others es e).map Prod.snd) := by
      have ht:=(List.perm_cons_erase he).map (fun d : Cell=>d.term.val)
      simpa [others,List.map_map] using
        (List.perm_append_comm : ((es.map (fun d=>d.term.val))++[-q.val]).Perm
          ([-q.val]++(es.map (fun d=>d.term.val)))).trans (ht.cons (-q.val))
    have hv : Valid ((es.map Cell.term).map Subtype.val++[-q.val]) := by
      intro l hl;rcases List.mem_append.mp hl with hl|hl
      · obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hl;exact t.property
      · obtain rfl:=List.mem_singleton.mp hl;exact neg_ne_zero.mpr q.property
    rw [ProjectionTrace.clause_perm _ _ hv
      (by intro l hl;exact hv l (hp.mem_iff.mpr hl)) hp] at hr
    exact hr
  · intro p hp;obtain ⟨d,hde,rfl⟩:=List.mem_map.mp hp
    have hdes:=List.mem_of_mem_erase hde
    refine ⟨(hrows d hdes).2.1,?_⟩
    have hne : e.choice.val≠d.choice.val := by
      intro hh
      have hed:=List.inj_on_of_nodup_map hc he hdes hh
      subst d
      exact hd.not_mem_erase hde
    obtain ⟨a,ha,hea⟩:=inchoices e he
    obtain ⟨b,hb,heb⟩:=inchoices d hdes
    rw [←hea,←heb]
    exact old _ (ham a ha b hb (by simpa [hea,heb] using hne))

#print axioms ands_binding
#print axioms select_binding
#print axioms inputs
end L3Emitter.ConcreteSelection

import SourceAuxBank
import IndexedSourceOneHot

namespace L3Emitter.MuxSourceStep
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot

def vector (n:Nat) (hn:2≤n) (g:Nat) : AliasBits (AliasAssembly.width (n+1)) := fun i=>
  if h:i.val<AliasAssembly.width (n+1) then (SourceMuxSnapshots.actual n hn g ⟨i.val,h⟩).q
  else (PrimaryAliasBank.cfg n hn).T

def choices (n:Nat) (hn:2≤n) (g:Nat) (b:Bool) :=
  if b then (PrimaryAliasBank.cfg n hn).hit g else neg ((PrimaryAliasBank.cfg n hn).hit g)
def inputs (n:Nat) (hn:2≤n) (g:Nat) (b:Bool) :=GatePortOneHot.target n hn g (if b then 1 else 0)

theorem left_binding (n:Nat) (hn:2≤n) (g:Nat) :
    (RecordedGateSnapshots.left n hn g).1.1=(CoordinateSnapshots.left (PrimaryAliasBank.cfg n hn)
      (GateSnapshots.beforeGate n hn g).1 g (GateSnapshots.beforeGate n hn g).2).1 ∧
    (RecordedGateSnapshots.left n hn g).2=(CoordinateSnapshots.left (PrimaryAliasBank.cfg n hn)
      (GateSnapshots.beforeGate n hn g).1 g (GateSnapshots.beforeGate n hn g).2).2 := by
  have h:=ConcreteOriginalPorts.binding (n+1) g ((PrimaryAliasBank.cfg n hn).sel g 0)
    (GateSnapshots.beforeGate n hn g).1 (GateSnapshots.beforeGate n hn g).2
  exact ⟨congrArg Prod.fst h,congrArg Prod.snd h⟩
theorem right_binding (n:Nat) (hn:2≤n) (g:Nat) :
    (RecordedGateSnapshots.right n hn g).1.1=(CoordinateSnapshots.right (PrimaryAliasBank.cfg n hn)
      (GateSnapshots.beforeGate n hn g).1 g (GateSnapshots.beforeGate n hn g).2).1 := by
  have h:=congrArg Prod.fst (ConcreteOriginalPorts.binding (n+1) g ((PrimaryAliasBank.cfg n hn).sel g 1)
    (GateSnapshots.beforeGate n hn g).1 (RecordedGateSnapshots.left n hn g).2)
  rw [(left_binding n hn g).2] at h
  simpa only [RecordedGateSnapshots.right,(left_binding n hn g).2] using h

theorem actual_ports (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) :
    (SourceMuxSnapshots.actual n hn g i).a=GatePortOneHot.target n hn g 1 (position i) ∧
    (SourceMuxSnapshots.actual n hn g i).b=GatePortOneHot.target n hn g 0 (position i) := by
  change _=(RecordedGateSnapshots.right n hn g).1.1 (position i) ∧
    _=(RecordedGateSnapshots.left n hn g).1.1 (position i)
  rw [right_binding n hn g,(left_binding n hn g).1]
  exact ⟨rfl,rfl⟩

theorem links (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (b:Bool) :
    SourceOnlyTransport.Links (SourceAuxBank.result n hn) (choices n hn g b) (inputs n hn g b) (vector n hn g) := by
  intro i
  have keep:=SourceAuxBank.contains_job n hn (.mux g i) (SourceAuxBank.mux_mem n g hg hs i)
  have h1:clause [-(SourceMuxSnapshots.actual n hn g i).c.val,-(SourceMuxSnapshots.actual n hn g i).a.val,
      (SourceMuxSnapshots.actual n hn g i).q.val]∈SourceAuxBank.result n hn:=keep _ (by simp [SourceAuxBank.jobRows,RecordedExpressions.jobRows])
  have h2:clause [-(SourceMuxSnapshots.actual n hn g i).c.val,-(SourceMuxSnapshots.actual n hn g i).q.val,
      (SourceMuxSnapshots.actual n hn g i).a.val]∈SourceAuxBank.result n hn:=keep _ (by simp [SourceAuxBank.jobRows,RecordedExpressions.jobRows])
  have h3:clause [(SourceMuxSnapshots.actual n hn g i).c.val,-(SourceMuxSnapshots.actual n hn g i).b.val,
      (SourceMuxSnapshots.actual n hn g i).q.val]∈SourceAuxBank.result n hn:=keep _ (by simp [SourceAuxBank.jobRows,RecordedExpressions.jobRows])
  have h4:clause [(SourceMuxSnapshots.actual n hn g i).c.val,-(SourceMuxSnapshots.actual n hn g i).q.val,
      (SourceMuxSnapshots.actual n hn g i).b.val]∈SourceAuxBank.result n hn:=keep _ (by simp [SourceAuxBank.jobRows,RecordedExpressions.jobRows])
  have hc:(SourceMuxSnapshots.actual n hn g i).c=(PrimaryAliasBank.cfg n hn).hit g:=rfl
  have hq:vector n hn g (position i)=(SourceMuxSnapshots.actual n hn g i).q:=by simp [vector,position,i.isLt]
  rw [hc,(actual_ports n hn g i).1] at h1 h2
  rw [hc,(actual_ports n hn g i).2] at h3 h4
  cases b
  · simpa [choices,inputs,hq,neg] using And.intro h3 h4
  · simpa [choices,inputs,hq] using And.intro h1 h2

def seed (n:Nat) (hn:2≤n) (g:Nat) : Program:=
  [(clause [((PrimaryAliasBank.cfg n hn).hit g).val,-((PrimaryAliasBank.cfg n hn).hit g).val],
    ComplementChoice.tautTokens ((PrimaryAliasBank.cfg n hn).hit g).val)]
def seeded (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=D++outputs (seed n hn g)
def program (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=seed n hn g++
  IndexedSourceOneHot.program (seeded n hn g D) [true,false] (choices n hn g) (inputs n hn g) (vector n hn g)
def result (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=
  IndexedSourceOneHot.result (seeded n hn g D) [true,false] (choices n hn g) (vector n hn g)

theorem retains (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :∀R∈D,R∈result n hn g D:=
  fun R h=>List.mem_append_left _ (List.mem_append_left _ h)
theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (D:List Row) (hd:∀R∈SourceAuxBank.result n hn,R∈D)
    (hl:SourceRows D (GatePortOneHot.target n hn g 0)) (hr:SourceRows D (GatePortOneHot.target n hn g 1)) :
    check D (program n hn g D)=some (result n hn g D) := by
  have h0:check D (seed n hn g)=some (seeded n hn g D):=by
    simp only [seed,check,ComplementChoice.taut_pair_succeeds _ _ ((PrimaryAliasBank.cfg n hn).hit g).property,
      ↓reduceIte,seeded,outputs,List.map_cons,List.map_nil]
  have h1:=IndexedSourceOneHot.checks (seeded n hn g D) [true,false] (choices n hn g) (inputs n hn g) (vector n hn g)
    (by unfold AliasAssembly.width RankConstruction.width;omega) (by simp)
    (by apply List.mem_append_right;simp [seed,outputs,choices,neg])
    (by
      intro b hb
      cases b
      · exact ⟨List.mem_append_left _ hl.1,fun i j hij=>List.mem_append_left _ (hl.2 i j hij)⟩
      · exact ⟨List.mem_append_left _ hr.1,fun i j hij=>List.mem_append_left _ (hr.2 i j hij)⟩)
    (by intro b hb i;exact ⟨List.mem_append_left _ (hd _ (links n hn g hg hs b i).1),
      List.mem_append_left _ (hd _ (links n hn g hg hs b i).2)⟩)
  exact check_append _ _ _ _ _ h0 h1

theorem source_rows (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) : SourceRows (result n hn g D) (vector n hn g) :=
  IndexedSourceOneHot.source_rows _ _ _ _

#print axioms checks
#print axioms source_rows
end L3Emitter.MuxSourceStep

import NumericAliasClosed
namespace L3Emitter.NumericAliasValues
open EREF EREF.GeneralRED AliasNetwork NumericNetwork

def initialCap (n:Nat) (hn:2≤n):Nat:=CanonicalTrace.ceiling (AliasAssembly.source n hn)+externalCeiling (n+1)
def runCap (n:Nat) (hn:2≤n):Nat:=initialCap n hn+aliasGrowth (n+1)
def portCost (n:Nat):Nat:=(AliasAssembly.width (n+1)+2)*((n+1)+(3*(n+1)-4)+1)
def fullCap (n:Nat) (hn:2≤n):Nat:=runCap n hn+2*portCost n

theorem context (n:Nat) (hn:2≤n):
    ConfigBound (initialCap n hn+contextCost (n+1)) (3*(n+1)-4) (AliasAssembly.width (n+1)) (PrimaryAliasBank.cfg n hn) ∧
    CanonicalTrace.ceiling (PrimaryAliasBank.context n hn).2.rows≤ initialCap n hn+contextCost (n+1):=by
  apply NumericNetwork.context
  · exact external_mono (by unfold initialCap;omega) (external_bound (n+1) (by omega))
  · simp only[PrimaryAliasBank.seed,AliasNetwork.Net.rows,AliasNetwork.initial,List.flatMap_nil,List.append_nil]
    unfold initialCap;omega

theorem config (n:Nat) (hn:2≤n):
    ConfigBound (runCap n hn) (3*(n+1)-4) (AliasAssembly.width (n+1)) (PrimaryAliasBank.cfg n hn):=by
  exact config_mono (by unfold runCap aliasGrowth;omega) (context n hn).1

theorem before (n:Nat) (hn:2≤n) (g:Nat) (hg:g≤3*(n+1)-4):
    SourceBound (runCap n hn) (GateSnapshots.beforeGate n hn g).1 ∧
    CanonicalTrace.ceiling (GateSnapshots.beforeGate n hn g).2.rows≤runCap n hn:=by
  have hc:=context n hn
  have h:=NumericNetwork.run (initialCap n hn+contextCost (n+1)) (3*(n+1)-4) (AliasAssembly.width (n+1))
    (PrimaryAliasBank.cfg n hn) 0 g (by omega) hc.1
    (FirstPortRelations.initialAliases n hn) (input_bound _ _ _ _ hc.1)
    (PrimaryAliasBank.context n hn).2 hc.2
  have hk:(PrimaryAliasBank.cfg n hn).k=n+1:=rfl
  rw[hk] at h;simp only[Nat.add_zero] at h
  have hb:g*((AliasAssembly.width (n+1)+2)*(2*(n+1+g)+25))≤
    (3*(n+1)-4)*((AliasAssembly.width (n+1)+2)*(2*(n+1+(3*(n+1)-4))+25)):=
    Nat.mul_le_mul hg (Nat.mul_le_mul_left _ (by omega))
  have he:initialCap n hn+contextCost (n+1)+g*((AliasAssembly.width (n+1)+2)*(2*(n+1+g)+25))≤runCap n hn:=by
    unfold runCap aliasGrowth;omega
  exact ⟨source_mono he _ h.1,h.2.trans he⟩

theorem left (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4):
    VectorBound (runCap n hn+portCost n) (RecordedGateSnapshots.left n hn g).1.1 ∧
    CanonicalTrace.ceiling (RecordedGateSnapshots.left n hn g).2.rows≤runCap n hn+portCost n:=by
  have hc:=config n hn
  have hb:=before n hn g (by omega)
  have h:=NumericNetwork.port (runCap n hn) (n+1) g (AliasAssembly.width (n+1))
    ((PrimaryAliasBank.cfg n hn).sel g 0) (GateSnapshots.beforeGate n hn g).1
    (hc.sel g hg 0 (by omega)) hb.1 (GateSnapshots.beforeGate n hn g).2 hb.2
  have he:(AliasAssembly.width (n+1)+2)*(n+1+g+1)≤portCost n:=Nat.mul_le_mul_left _ (by omega)
  have hv:=congrArg Prod.fst (ConcreteOriginalPorts.binding (n+1) g ((PrimaryAliasBank.cfg n hn).sel g 0)
    (GateSnapshots.beforeGate n hn g).1 (GateSnapshots.beforeGate n hn g).2)
  have hz:=congrArg Prod.snd (ConcreteOriginalPorts.binding (n+1) g ((PrimaryAliasBank.cfg n hn).sel g 0)
    (GateSnapshots.beforeGate n hn g).1 (GateSnapshots.beforeGate n hn g).2)
  change (RecordedGateSnapshots.left n hn g).1.1=_ at hv
  change (RecordedGateSnapshots.left n hn g).2=_ at hz
  rw[hv,hz]
  exact ⟨vector_mono (by omega) _ h.1,h.2.trans (by omega)⟩

theorem ports (n:Nat) (hn:2≤n) (g p:Nat) (hg:g<3*(n+1)-4):
    VectorBound (fullCap n hn) (EarlierPortValues.portAlias n hn g p):=by
  have hl:=left n hn g hg
  by_cases hp:p=0
  · simpa only[EarlierPortValues.portAlias,RecordedGateSnapshots.portAt,hp,if_true] using
      vector_mono (show runCap n hn+portCost n≤fullCap n hn by unfold fullCap;omega) _ hl.1
  · have hc:=config n hn
    have hb:=before n hn g (by omega)
    have h:=NumericNetwork.port (runCap n hn+portCost n) (n+1) g (AliasAssembly.width (n+1))
      ((PrimaryAliasBank.cfg n hn).sel g 1) (GateSnapshots.beforeGate n hn g).1
      (fun j hj=>(hc.sel g hg 1 (by omega) j hj).trans (by omega))
      (source_mono (by omega) _ hb.1) (RecordedGateSnapshots.left n hn g).2 hl.2
    have he:(AliasAssembly.width (n+1)+2)*(n+1+g+1)≤portCost n:=Nat.mul_le_mul_left _ (by omega)
    have hv:=congrArg Prod.fst (ConcreteOriginalPorts.binding (n+1) g ((PrimaryAliasBank.cfg n hn).sel g 1)
      (GateSnapshots.beforeGate n hn g).1 (RecordedGateSnapshots.left n hn g).2)
    change (RecordedGateSnapshots.right n hn g).1.1=_ at hv
    simp only[EarlierPortValues.portAlias,RecordedGateSnapshots.portAt,hp,if_false,hv]
    exact vector_mono (by unfold fullCap;omega) _ h.1

#print axioms ports
end L3Emitter.NumericAliasValues

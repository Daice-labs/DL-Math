import BranchLayout
import RankProjection
import PrioritySourceBinding

namespace L3Emitter.BranchChoices
open EREF REDWitness PriorityBank PrioritySelection RankProjection

def ValidPairs (s : Nat) (ps : List (Nat×Nat)) : Prop :=
  ∀p∈ps,0<p.1 ∧ p.1<p.2 ∧ p.2<s

/-- Executable deleted-gate labels in exactly the frontend's loop order.
    The literal is the choice output allocated by the explicit selector. -/
def entries (s m : Nat) (ps : List (Nat×Nat)) (hp : ValidPairs s ps) :
    List (Choice s) :=
  match ps with
  | [] => []
  | p::ps =>
    let h := hp p (by simp)
    ⟨p.1,p.2,(m+1:Int),h.1,h.2.1,h.2.2,by omega⟩ ::
      entries s (m+2) ps (by intro q hq; exact hp q (by simp [hq]))

theorem literals (s m r : Nat) (ps : List (Nat×Nat)) (hp : ValidPairs s ps) :
    (entries s m ps hp).map Choice.lit =
      choices (nodes m (L3.Fam.branchLits r ps.length)) := by
  induction ps generalizing m r with
  | nil => rfl
  | cons p ps ih =>
    simp only [entries,List.length_cons,L3.Fam.branchLits,nodes,choices,List.map_cons]
    congr 1
    exact ih _ _ _

theorem labels (s m : Nat) (ps : List (Nat×Nat)) (hp : ValidPairs s ps) :
    (entries s m ps hp).map (fun c => (c.beta,c.gamma))=ps := by
  induction ps generalizing m with
  | nil => rfl
  | cons p ps ih => simp only [entries,List.map_cons]; rw [ih]

theorem above (s m : Nat) (ps : List (Nat×Nat)) (hp : ValidPairs s ps)
    (c : Choice s) (hc : c∈entries s m ps hp) : (m:Int)<c.lit := by
  induction ps generalizing m with
  | nil => simp [entries] at hc
  | cons p ps ih =>
    simp only [entries,List.mem_cons] at hc
    rcases hc with rfl|hc
    · simp
    · have h := ih (m+2) _ hc; omega

theorem literal_injective (s m : Nat) (ps : List (Nat×Nat)) (hp : ValidPairs s ps)
    (c d : Choice s) (hc : c∈entries s m ps hp) (hd : d∈entries s m ps hp)
    (he : c.lit=d.lit) : c=d := by
  induction ps generalizing m with
  | nil => simp [entries] at hc
  | cons p ps ih =>
    simp only [entries,List.mem_cons] at hc hd
    rcases hc with rfl|hc
    · rcases hd with rfl|hd
      · rfl
      · have h := above s (m+2) ps _ d hd
        simp only at he
        omega
    · rcases hd with rfl|hd
      · have h := above s (m+2) ps _ c hc
        simp only at he
        omega
      · exact ih (m+2) _ hc hd

def pairs (k : Nat) := (FableEncoding.fam k (3*k-4)).branchPairs
  (FableEncoding.fam k (3*k-4)).branchIndices

theorem pairs_valid (k : Nat) : ValidPairs (3*k-4) (pairs k) := by
  intro p hp
  exact (FableEncoding.fam k (3*k-4)).branchPairs_valid p.1 p.2 hp

def chosen (k : Nat) (hk : 3≤k) :=
  entries (3*k-4) ((FrontendSelection.front k hk).s.var+1) (pairs k) (pairs_valid k)

theorem chosen_literals (k : Nat) (hk : 3≤k) :
    (chosen k hk).map Choice.lit =
      choices (nodes ((FrontendSelection.front k hk).s.var+1) (FrontendSelection.xs k hk)) := by
  unfold chosen FrontendSelection.xs
  rw [L3.Fam.frontend_branch_layout]
  exact literals _ _ _ _ _

/-- The all-size selector supplies the actual ALO and AMO premises of rank
    projection, for the actual beta/gamma labels, not arbitrary choices. -/
theorem chosen_onehot (k : Nat) (hk : 3≤k) :
    clause ((chosen k hk).map Choice.lit)∈FrontendSelection.finalRows k hk ∧
    (∀c∈chosen k hk,∀d∈chosen k hk,c≠d →
      clause [-c.lit,-d.lit]∈FrontendSelection.finalRows k hk) := by
  have h := (FrontendSelection.original_to_selected_branches k hk).2
  constructor
  · rw [chosen_literals]; exact h.1
  · intro c hc d hd hcd
    have hc' : c.lit∈(chosen k hk).map Choice.lit := List.mem_map.mpr ⟨c,hc,rfl⟩
    have hd' : d.lit∈(chosen k hk).map Choice.lit := List.mem_map.mpr ⟨d,hd,rfl⟩
    rw [chosen_literals] at hc' hd'
    exact h.2 _ hc' _ hd' (by
      intro he
      exact hcd (literal_injective _ _ _ _ c d hc hd he))

#print axioms chosen_onehot
#print axioms labels
end L3Emitter.BranchChoices

import ConstructionCoordinateCount

namespace L3Emitter.ConstructionTableValueCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount ConstructionCoordinateCount

theorem value_leaf (n : Nat) (hn : 2≤n) (r : RankPortBank.Record n)
    (D E : List Row) (j : RankPortValueBank.Job n) :
    (RankPortValueBank.rebased n hn r D j E).length=3*(n+1)-5+1 := by
  simp only [RankPortValueBank.rebased,ConstructionValueBankCount.rebase_length,
    RankPortValueBank.leaf,RankPortValue.program,RankPortValue.cases,List.length_append,List.length_map,
    List.length_cons,List.length_nil,RankPortValue.choices,RankPortSelection.choices,List.length_attach,choices]

theorem value_block (n : Nat) (hn : 2≤n) (r : RankPortBank.Record n) (D : List Row) :
    (RecordedRankPortValues.blockProgram n hn r D).length≤220*(n+1)^2*2^n := by
  have h:=retained_fold (RankPortValueBank.rebased n hn r D) (RankPortValueBank.leafRows n hn r D)
    (RankPortValueBank.jobs n) (RankPortValue.built n hn r D).1 (3*(n+1)-5+1)
    (fun j hj E=>(value_leaf n hn r D E j).le)
  change (RankPortValueBank.program n hn r D).length≤_ at h
  change _≤(FirstGateBase.jobs n).length*(3*(n+1)-5+1) at h
  rw [GlobalValueSize.jobs_count] at h
  have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  have hc:3*(n+1)-5+1≤3*(n+1):=by omega
  have hp:=Nat.mul_le_mul hw hc
  have ht:=Nat.mul_le_mul_right (4*2^n) hp
  have hd:6*(3*(n+1)-5)+1≤19*(n+1):=by omega
  simp only [RecordedRankPortValues.blockProgram,List.length_append,polProgram_length,
    RecordedRankPortValues.definitionProgram,coordinate,choices,FamilyNamespace.truthRows] at *
  nlinarith [Nat.mul_le_mul_left (2^n) hd,Nat.mul_le_mul_right (2^n)
    (Nat.pow_le_pow_right (show 1≤n+1 by omega) (show 1≤2 by omega))]

theorem value_run (n : Nat) (hn : 2≤n) (rs : List (RankPortBank.Record n)) (D : List Row) :
    (RecordedRankPortValues.runProgram n hn D rs).length≤rs.length*(220*(n+1)^2*2^n) := by
  induction rs generalizing D with
  | nil=>simp [RecordedRankPortValues.runProgram]
  | cons r rs ih=>
    simp only [RecordedRankPortValues.runProgram,List.length_append,List.length_cons]
    exact (Nat.add_le_add (value_block n hn r D) (ih _)).trans_eq (by ring)

theorem values (n : Nat) (hn : 2≤n) :
    (RecordedRankPortValues.program n hn).length≤1320*(n+1)^3*2^n := by
  have h:=value_run n hn (RankPortBank.result n hn).2 (RankPortBank.result n hn).1
  rw [RawInputSize.rank_port_count] at h
  have hr:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  exact h.trans (by nlinarith [Nat.mul_le_mul_right (440*(n+1)^2*2^n) hr])

theorem raw_unary_jobs (n : Nat) (hn : 2≤n) :
    (RawUnaryBank.jobs n hn).length=(RawLowerInputBank.result n hn).2.length*(2^n*4) := by
  unfold RawUnaryBank.jobs
  apply flat_exact
  intro r hr
  rw [flat_exact _ _ 4 (by intro x hx;rfl),List.length_range]
  rfl

theorem raw_unary (n : Nat) (hn : 2≤n) :
    (RawUnaryBank.program n hn).length≤120*(n+1)^2*2^n := by
  have h:=retained_fold (RawUnaryBank.leaf n hn) (RawUnaryBank.rows n) (RawUnaryBank.jobs n hn)
    (RawLowerInputBank.result n hn).1 (AliasAssembly.width (n+1)+1)
    (by intro j hj D;exact (RawUnaryTransport.command_count ..).le)
  rw [raw_unary_jobs,RawInputSize.raw_record_count] at h
  have hr:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hw:AliasAssembly.width (n+1)+1≤5*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  have hp:=Nat.mul_le_mul hr hw
  exact h.trans (by nlinarith [Nat.mul_le_mul_right (8*2^n) hp])

#print axioms values
#print axioms raw_unary
end L3Emitter.ConstructionTableValueCount

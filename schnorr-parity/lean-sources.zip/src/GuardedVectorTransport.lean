import GuardedTransport
import RecordedPortLinks
namespace L3Emitter.GuardedVectorTransport
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram ReferenceTransport Resolution
variable {ι:Type}
def signed (b:Bool) (x:Bit):Int:=if b then x.val else -x.val
def literals (a:ι→Bit) (ls:List (ι×Bool)):=ls.map (fun l=>signed l.2 (a l.1))
def row (a:ι→Bit) (ls:List (ι×Bool)):=clause (literals a ls)
def link (D:List Row) (g:Bit) (a q:ι→Bit) (l:ι×Bool):ClauseTransport.Link:=
  let s:=signed l.2 (a l.1);let t:=signed l.2 (q l.1)
  .mapped s t (locate D (clause [g.val,-s,t]))
def Relations (D:List Row) (g:Bit) (a q:ι→Bit):=∀i,
  clause [g.val,-(a i).val,(q i).val]∈D ∧ clause [g.val,-(q i).val,(a i).val]∈D

theorem nonzero (b:Bool) (x:Bit):signed b x≠0:=by cases b <;> simp [signed,x.property]
theorem available (D:List Row) (g:Bit) (a q:ι→Bit) (l:ι×Bool) (hr:Relations D g a q):
    (link D g a q l).Available (dbOf D) g.val:=by
  refine ⟨nonzero _ _,nonzero _ _,?_⟩
  apply locate_correct
  change clause [g.val,-signed l.2 (a l.1),signed l.2 (q l.1)]∈D
  cases hb:l.2
  · simp only [signed,hb,Bool.false_eq_true,↓reduceIte,neg_neg]
    have h:=(hr l.1).2
    rw [ProjectionTrace.clause_perm _ [g.val,(a l.1).val,-(q l.1).val]
      (by simp [Valid,g.property,(a l.1).property,(q l.1).property])
      (by simp [Valid,g.property,(a l.1).property,(q l.1).property])
      (List.Perm.cons _ (List.Perm.swap _ _ []))] at h
    exact h
  · simpa [signed,hb] using (hr l.1).1

def tape (D:List Row) (g:Bit) (a q:ι→Bit) (ls:List (ι×Bool)):=
  GuardedTransport.tokens (locate D (branch (row a ls) g.val)) g.val (ls.map (link D g a q))
theorem checks (D:List Row) (g:Bit) (a q:ι→Bit) (ls:List (ι×Bool))
    (hs:branch (row a ls) g.val∈D) (hr:Relations D g a q):
    polEval (dbOf D) (tape D g a q ls) []=some (branch (row q ls) g.val):=by
  have h:=GuardedTransport.succeeds (dbOf D) (locate D (branch (row a ls) g.val)) g.val
    (ls.map (link D g a q)) g.property
    (by simpa [ClauseTransport.sourceClause,link,ClauseTransport.Link.source,List.map_map,literals,row] using locate_correct D _ hs)
    (by intro l hl;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hl;exact available D g a q l hr)
  simpa [tape,ClauseTransport.targetClause,link,ClauseTransport.Link.target,List.map_map,literals,row] using h

def unguardedTape (D:List Row) (g:Bit) (a q:ι→Bit) (ls:List (ι×Bool)):=
  ClauseTransport.tokens (locate D (row a ls)) g.val (ls.map (link D g a q))
theorem unguarded_checks (D:List Row) (g:Bit) (a q:ι→Bit) (ls:List (ι×Bool))
    (hne:ls≠[]) (hs:row a ls∈D) (hr:Relations D g a q):
    polEval (dbOf D) (unguardedTape D g a q ls) []=some (branch (row q ls) g.val):=by
  have h:=ClauseTransport.succeeds (dbOf D) (locate D (row a ls)) g.val g.property
    (ls.map (link D g a q)) (by simpa using hne)
    (by simpa [ClauseTransport.sourceClause,link,ClauseTransport.Link.source,List.map_map,literals,row] using locate_correct D _ hs)
    (by intro l hl;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hl;exact available D g a q l hr)
  simpa [unguardedTape,ClauseTransport.targetClause,link,ClauseTransport.Link.target,List.map_map,literals,row] using h
#print axioms checks
#print axioms unguarded_checks
end L3Emitter.GuardedVectorTransport

/-
Images of the original rows under the input-wire swap σ = swapId a b (ports=False).

Main result `image_rows`: for every original row r, the literal-wise image of r under σ
is semantically identical (same right-hand side, same literal sum under every
assignment) to some original row r'. Blocks 2–5 map row-to-row syntactically; block 1
rows map to themselves up to a permutation of their literal list (the swap of the two
entries a and b), which is handled by the finite-sum lemma `sumR_swap`.
Block 5 needs the target table to be invariant under xm, a hypothesis here and proved
for the parity table in `L3Parity.lean`.
-/
import L3Swap

namespace L3

/-! ### Literal-level semantics (unit coefficients) -/

/-- value of a literal under α: x for a positive id, 1 − x for a negated one -/
def lv (α : EREF.Val) (l : Int) : Int :=
  if 0 < l then EREF.b2i (α l.natAbs) else 1 - EREF.b2i (α l.natAbs)

theorem lv_eq_litVal (α : EREF.Val) (l : Int) : lv α l = EREF.litVal α l := rfl

def lsum (α : EREF.Val) (xs : List Int) : Int := (xs.map (lv α)).sum

@[simp] theorem lsum_nil (α : EREF.Val) : lsum α [] = 0 := rfl
@[simp] theorem lsum_cons (α : EREF.Val) (x : Int) (xs : List Int) :
    lsum α (x :: xs) = lv α x + lsum α xs := by simp [lsum]
@[simp] theorem lsum_append (α : EREF.Val) (xs ys : List Int) :
    lsum α (xs ++ ys) = lsum α xs + lsum α ys := by simp [lsum]

/-- literal-wise image under an id map -/
def mapLit (σ : Nat → Nat) (l : Int) : Int :=
  if 0 < l then (σ l.natAbs : Int) else -(σ l.natAbs : Int)

theorem mapLit_pos (σ : Nat → Nat) (v : Nat) (hv : 1 ≤ v) : mapLit σ (pos v) = pos (σ v) := by
  unfold mapLit pos; simp; omega
theorem mapLit_neg (σ : Nat → Nat) (v : Nat) (hv : 1 ≤ v) : mapLit σ (neg v) = neg (σ v) := by
  unfold mapLit neg; simp; omega

def imageRow (σ : Nat → Nat) (r : Row) : Row := { lits := r.lits.map (mapLit σ), rhs := r.rhs }

/-- semantic identity of two unit-coefficient rows -/
def Row.equiv (r r' : Row) : Prop := r.rhs = r'.rhs ∧ ∀ α, lsum α r.lits = lsum α r'.lits

theorem Row.equiv_refl (r : Row) : r.equiv r := ⟨rfl, fun _ => rfl⟩
theorem Row.equiv_of_eq {r r' : Row} (h : r = r') : r.equiv r' := h ▸ Row.equiv_refl r

/-! ### Finite sums over `range n` and the two-point swap -/

def sumR (n : Nat) (g : Nat → Int) : Int := ((List.range n).map g).sum

theorem sumR_zero (g : Nat → Int) : sumR 0 g = 0 := rfl
theorem sumR_succ (n : Nat) (g : Nat → Int) : sumR (n + 1) g = sumR n g + g n := by
  simp [sumR, List.range_succ]

theorem sumR_sub (n : Nat) (g h : Nat → Int) :
    sumR n (fun j => g j - h j) = sumR n g - sumR n h := by
  induction n with
  | zero => simp [sumR_zero]
  | succ n ih => simp only [sumR_succ, ih]; omega

theorem sumR_zero_of (n : Nat) (g : Nat → Int) (hz : ∀ j, j < n → g j = 0) : sumR n g = 0 := by
  induction n with
  | zero => rfl
  | succ n ih => rw [sumR_succ, ih (fun j hj => hz j (by omega)), hz n (by omega)]; rfl

theorem sumR_single (n c : Nat) (g : Nat → Int) (hc : c < n)
    (hz : ∀ j, j < n → j ≠ c → g j = 0) : sumR n g = g c := by
  induction n with
  | zero => omega
  | succ n ih =>
    rw [sumR_succ]
    by_cases h : n = c
    · subst h
      rw [sumR_zero_of n g (fun j hj => hz j (by omega) (by omega))]; simp
    · rw [ih (by omega) (fun j hj hjc => hz j (by omega) hjc), hz n (by omega) h]; simp

theorem sumR_two (n a b : Nat) (g : Nat → Int) (ha : a < n) (hb : b < n) (hab : a ≠ b)
    (hz : ∀ j, j < n → j ≠ a → j ≠ b → g j = 0) : sumR n g = g a + g b := by
  induction n with
  | zero => omega
  | succ n ih =>
    rw [sumR_succ]
    by_cases hna : n = a
    · subst hna
      rw [sumR_single n b g (by omega) (fun j hj hjb => hz j (by omega) (by omega) hjb)]
      omega
    · by_cases hnb : n = b
      · subst hnb
        rw [sumR_single n a g (by omega) (fun j hj hja => hz j (by omega) hja (by omega))]
      · rw [ih (by omega) (by omega) (fun j hj hja hjb => hz j (by omega) hja hjb),
          hz n (by omega) hna hnb]; simp

/-- exchanging two sample points does not change a finite sum -/
theorem sumR_swap (n a b : Nat) (g : Nat → Int) (ha : a < n) (hb : b < n) (hab : a ≠ b) :
    sumR n (fun j => g (Fam.jmap a b j)) = sumR n g := by
  have hd : sumR n (fun j => g (Fam.jmap a b j) - g j) = 0 := by
    rw [sumR_two n a b _ ha hb hab]
    · simp [Fam.jmap_a, Fam.jmap_b]; omega
    · intro j _ hja hjb; rw [Fam.jmap_other a b j hja hjb]; omega
  rw [sumR_sub] at hd; omega

theorem lsum_map_range (α : EREF.Val) (n : Nat) (f : Nat → Int) :
    lsum α ((List.range n).map f) = sumR n (fun j => lv α (f j)) := by
  simp [lsum, sumR, List.map_map, Function.comp_def]

namespace Fam

/-! ### Named rows and their membership in `rows` -/

def row1 (F : Fam) (t p : Nat) : Row :=
  { lits := ((List.range (F.k + t)).map fun j => F.sel t p j).map pos, rhs := 1 }
def row1' (F : Fam) (t p : Nat) : Row :=
  { lits := ((List.range (F.k + t)).map fun j => F.sel t p j).map neg, rhs := F.k + t - 1 }
def row2 (F : Fam) (t c : Nat) : Row :=
  { lits := (List.range 4).map fun ab =>
      if codeBit c ab then neg (F.fn t ab) else pos (F.fn t ab), rhs := 1 }
def row3i (F : Fam) (t p j x : Nat) : Row :=
  { lits := [neg (F.sel t p j), if F.inputBit j x then pos (F.port t p x) else neg (F.port t p x)],
    rhs := 1 }
def row3g (F : Fam) (t p i x : Nat) : Row :=
  { lits := [neg (F.sel t p (F.k + i)), neg (F.val i x), pos (F.port t p x)], rhs := 1 }
def row3g' (F : Fam) (t p i x : Nat) : Row :=
  { lits := [neg (F.sel t p (F.k + i)), pos (F.val i x), neg (F.port t p x)], rhs := 1 }
def m1 (F : Fam) (t x a : Nat) : Int := if a = 1 then neg (F.port t 0 x) else pos (F.port t 0 x)
def m2 (F : Fam) (t x b : Nat) : Int := if b = 1 then neg (F.port t 1 x) else pos (F.port t 1 x)
def row4 (F : Fam) (t x a b : Nat) : Row :=
  { lits := [F.m1 t x a, F.m2 t x b, neg (F.val t x), pos (F.fn t (2 * a + b))], rhs := 1 }
def row4' (F : Fam) (t x a b : Nat) : Row :=
  { lits := [F.m1 t x a, F.m2 t x b, pos (F.val t x), neg (F.fn t (2 * a + b))], rhs := 1 }
def row5 (F : Fam) (x : Nat) : Row :=
  { lits := [if F.b x then pos (F.val (F.s - 1) x) else neg (F.val (F.s - 1) x)], rhs := 1 }

theorem block1_eq (F : Fam) : F.block1 = (List.range F.s).flatMap fun t =>
    (List.range 2).flatMap fun p => [F.row1 t p, F.row1' t p] := rfl
theorem block2_eq (F : Fam) : F.block2 = (List.range F.s).flatMap fun t =>
    [6, 9].map fun c => F.row2 t c := rfl
theorem inputRows_eq (F : Fam) (t p j : Nat) :
    F.inputRows t p j = (List.range F.T).map fun x => F.row3i t p j x := rfl
theorem gateRows_eq (F : Fam) (t p i : Nat) :
    F.gateRows t p i = (List.range F.T).flatMap fun x => [F.row3g t p i x, F.row3g' t p i x] := rfl
theorem block4_eq (F : Fam) : F.block4 = (List.range F.s).flatMap fun t =>
    (List.range F.T).flatMap fun x => (List.range 2).flatMap fun a =>
      (List.range 2).flatMap fun b => [F.row4 t x a b, F.row4' t x a b] := rfl
theorem block5_eq (F : Fam) : F.block5 = (List.range F.T).map fun x => F.row5 x := rfl

theorem row1_mem (F : Fam) (t p : Nat) (ht : t < F.s) (hp : p < 2) : F.row1 t p ∈ F.rows := by
  unfold rows; rw [block1_eq]; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  exact Or.inl (Or.inl (Or.inl (Or.inl ⟨t, ht, p, hp, by simp⟩)))
theorem row1'_mem (F : Fam) (t p : Nat) (ht : t < F.s) (hp : p < 2) : F.row1' t p ∈ F.rows := by
  unfold rows; rw [block1_eq]; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  exact Or.inl (Or.inl (Or.inl (Or.inl ⟨t, ht, p, hp, by simp⟩)))
theorem row2_mem (F : Fam) (t c : Nat) (ht : t < F.s) (hc : c = 6 ∨ c = 9) : F.row2 t c ∈ F.rows := by
  unfold rows; rw [block2_eq]; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  refine Or.inl (Or.inl (Or.inl (Or.inr ⟨t, ht, List.mem_map.mpr ⟨c, ?_, rfl⟩⟩)))
  rcases hc with rfl | rfl <;> simp
theorem row3i_mem (F : Fam) (t p j x : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k) (hx : x < F.T) :
    F.row3i t p j x ∈ F.rows := by
  unfold rows block3; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  refine Or.inl (Or.inl (Or.inr ⟨t, ht, p, hp, Or.inl ⟨j, hj, ?_⟩⟩))
  rw [inputRows_eq]; exact List.mem_map.mpr ⟨x, List.mem_range.mpr hx, rfl⟩
theorem row3g_mem (F : Fam) (t p i x : Nat) (ht : t < F.s) (hp : p < 2) (hi : i < t) (hx : x < F.T) :
    F.row3g t p i x ∈ F.rows := by
  unfold rows block3; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  refine Or.inl (Or.inl (Or.inr ⟨t, ht, p, hp, Or.inr ⟨i, hi, ?_⟩⟩))
  rw [gateRows_eq]; exact List.mem_flatMap.mpr ⟨x, List.mem_range.mpr hx, by simp⟩
theorem row3g'_mem (F : Fam) (t p i x : Nat) (ht : t < F.s) (hp : p < 2) (hi : i < t) (hx : x < F.T) :
    F.row3g' t p i x ∈ F.rows := by
  unfold rows block3; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  refine Or.inl (Or.inl (Or.inr ⟨t, ht, p, hp, Or.inr ⟨i, hi, ?_⟩⟩))
  rw [gateRows_eq]; exact List.mem_flatMap.mpr ⟨x, List.mem_range.mpr hx, by simp⟩
theorem row4_mem (F : Fam) (t x a b : Nat) (ht : t < F.s) (hx : x < F.T) (ha : a < 2) (hb : b < 2) :
    F.row4 t x a b ∈ F.rows := by
  unfold rows; rw [block4_eq]; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  exact Or.inl (Or.inr ⟨t, ht, x, hx, a, ha, b, hb, by simp⟩)
theorem row4'_mem (F : Fam) (t x a b : Nat) (ht : t < F.s) (hx : x < F.T) (ha : a < 2) (hb : b < 2) :
    F.row4' t x a b ∈ F.rows := by
  unfold rows; rw [block4_eq]; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  exact Or.inl (Or.inr ⟨t, ht, x, hx, a, ha, b, hb, by simp⟩)
theorem row5_mem (F : Fam) (x : Nat) (hx : x < F.T) : F.row5 x ∈ F.rows := by
  unfold rows; rw [block5_eq]; simp only [List.mem_append, List.mem_flatMap, List.mem_range]
  exact Or.inr (List.mem_map.mpr ⟨x, List.mem_range.mpr hx, rfl⟩)

/-- every original row is one of the named rows with in-range indices -/
theorem mem_rows (F : Fam) (r : Row) (hr : r ∈ F.rows) :
    (∃ t p, t < F.s ∧ p < 2 ∧ (r = F.row1 t p ∨ r = F.row1' t p)) ∨
    (∃ t c, t < F.s ∧ (c = 6 ∨ c = 9) ∧ r = F.row2 t c) ∨
    (∃ t p j x, t < F.s ∧ p < 2 ∧ j < F.k ∧ x < F.T ∧ r = F.row3i t p j x) ∨
    (∃ t p i x, t < F.s ∧ p < 2 ∧ i < t ∧ x < F.T ∧ (r = F.row3g t p i x ∨ r = F.row3g' t p i x)) ∨
    (∃ t x a b, t < F.s ∧ x < F.T ∧ a < 2 ∧ b < 2 ∧ (r = F.row4 t x a b ∨ r = F.row4' t x a b)) ∨
    (∃ x, x < F.T ∧ r = F.row5 x) := by
  unfold rows at hr
  rw [block1_eq, block2_eq, block4_eq, block5_eq] at hr
  unfold block3 at hr
  simp only [List.mem_append, List.mem_flatMap, List.mem_range, List.mem_map, List.mem_cons,
    List.not_mem_nil, or_false] at hr
  rcases hr with ((((⟨t, ht, p, hp, hr⟩ | ⟨t, ht, c, hc, rfl⟩) | ⟨t, ht, p, hp, hr⟩) |
    ⟨t, ht, x, hx, a, ha, b, hb, hr⟩) | ⟨x, hx, rfl⟩)
  · exact Or.inl ⟨t, p, ht, hp, hr⟩
  · exact Or.inr (Or.inl ⟨t, c, ht, hc, rfl⟩)
  · rcases hr with ⟨j, hj, hr⟩ | ⟨i, hi, hr⟩
    · rw [inputRows_eq] at hr
      obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hr
      exact Or.inr (Or.inr (Or.inl ⟨t, p, j, x, ht, hp, hj, List.mem_range.mp hx, rfl⟩))
    · rw [gateRows_eq] at hr
      obtain ⟨x, hx, hr⟩ := List.mem_flatMap.mp hr
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hr
      exact Or.inr (Or.inr (Or.inr (Or.inl ⟨t, p, i, x, ht, hp, hi, List.mem_range.mp hx, hr⟩)))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨t, x, a, b, ht, hx, ha, hb, hr⟩))))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨x, hx, rfl⟩))))

/-! ### Images under σ = swapId a b -/

section Images
variable (F : Fam) (a b : Nat) (ha : a < F.k) (hb : b < F.k)
include ha hb

theorem image_row1 (hab : a ≠ b) (t p : Nat) (ht : t < F.s) (hp : p < 2) :
    (imageRow (F.swapId a b) (F.row1 t p)).equiv (F.row1 t p) := by
  refine ⟨rfl, fun α => ?_⟩
  unfold imageRow row1
  simp only [List.map_map]
  have hmap : ∀ j ∈ List.range (F.k + t),
      (mapLit (F.swapId a b) ∘ pos ∘ fun j => F.sel t p j) j = (pos ∘ fun j => F.sel t p (jmap a b j)) j := by
    intro j hj
    simp only [Function.comp]
    rw [mapLit_pos _ _ (F.sel_pos t p j), F.swapId_sel a b t p j ht hp (List.mem_range.mp hj)]
  rw [List.map_congr_left hmap]
  show lsum α ((List.range (F.k + t)).map (pos ∘ fun j => F.sel t p (jmap a b j)))
    = lsum α ((List.range (F.k + t)).map (pos ∘ fun j => F.sel t p j))
  rw [lsum_map_range, lsum_map_range]
  exact sumR_swap (F.k + t) a b (fun j => lv α (pos (F.sel t p j))) (by omega) (by omega) hab

theorem image_row1' (hab : a ≠ b) (t p : Nat) (ht : t < F.s) (hp : p < 2) :
    (imageRow (F.swapId a b) (F.row1' t p)).equiv (F.row1' t p) := by
  refine ⟨rfl, fun α => ?_⟩
  unfold imageRow row1'
  simp only [List.map_map]
  have hmap : ∀ j ∈ List.range (F.k + t),
      (mapLit (F.swapId a b) ∘ neg ∘ fun j => F.sel t p j) j = (neg ∘ fun j => F.sel t p (jmap a b j)) j := by
    intro j hj
    simp only [Function.comp]
    rw [mapLit_neg _ _ (F.sel_pos t p j), F.swapId_sel a b t p j ht hp (List.mem_range.mp hj)]
  rw [List.map_congr_left hmap]
  show lsum α ((List.range (F.k + t)).map (neg ∘ fun j => F.sel t p (jmap a b j)))
    = lsum α ((List.range (F.k + t)).map (neg ∘ fun j => F.sel t p j))
  rw [lsum_map_range, lsum_map_range]
  exact sumR_swap (F.k + t) a b (fun j => lv α (neg (F.sel t p j))) (by omega) (by omega) hab

omit ha hb in
theorem image_row2 (t c : Nat) (ht : t < F.s) :
    imageRow (F.swapId a b) (F.row2 t c) = F.row2 t c := by
  unfold imageRow row2
  simp only [Row.mk.injEq, List.map_map, and_true]
  apply List.map_congr_left
  intro ab hab'
  have hab4 := List.mem_range.mp hab'
  simp only [Function.comp]
  split
  · rw [mapLit_neg _ _ (F.fn_pos t ab), F.swapId_fn a b t ab ht hab4]
  · rw [mapLit_pos _ _ (F.fn_pos t ab), F.swapId_fn a b t ab ht hab4]

theorem image_row3i (t p j x : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k) (hx : x < F.T) :
    imageRow (F.swapId a b) (F.row3i t p j x) = F.row3i t p (jmap a b j) (F.xm a b x) := by
  unfold imageRow row3i
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [mapLit_neg _ _ (F.sel_pos t p j), F.swapId_sel a b t p j ht hp (by omega)]
  rw [F.inputBit_xm a b (jmap a b j) x ha hb (Fam.jmap_lt a b j F.k ha hb hj), Fam.jmap_jmap]
  split
  · rw [mapLit_pos _ _ (F.port_pos t p x), F.swapId_port a b t p x ht hp hx]
  · rw [mapLit_neg _ _ (F.port_pos t p x), F.swapId_port a b t p x ht hp hx]

theorem image_row3g (t p i x : Nat) (ht : t < F.s) (hp : p < 2) (hi : i < t) (hx : x < F.T) :
    imageRow (F.swapId a b) (F.row3g t p i x) = F.row3g t p i (F.xm a b x) := by
  unfold imageRow row3g
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [mapLit_neg _ _ (F.sel_pos t p _), F.swapId_sel a b t p (F.k + i) ht hp (by omega),
    Fam.jmap_other a b _ (by omega) (by omega),
    mapLit_neg _ _ (F.val_pos i x), F.swapId_val a b i x (by omega) hx,
    mapLit_pos _ _ (F.port_pos t p x), F.swapId_port a b t p x ht hp hx]

theorem image_row3g' (t p i x : Nat) (ht : t < F.s) (hp : p < 2) (hi : i < t) (hx : x < F.T) :
    imageRow (F.swapId a b) (F.row3g' t p i x) = F.row3g' t p i (F.xm a b x) := by
  unfold imageRow row3g'
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [mapLit_neg _ _ (F.sel_pos t p _), F.swapId_sel a b t p (F.k + i) ht hp (by omega),
    Fam.jmap_other a b _ (by omega) (by omega),
    mapLit_pos _ _ (F.val_pos i x), F.swapId_val a b i x (by omega) hx,
    mapLit_neg _ _ (F.port_pos t p x), F.swapId_port a b t p x ht hp hx]

omit ha hb in
theorem image_m1 (t x a' : Nat) (ht : t < F.s) (hx : x < F.T) :
    mapLit (F.swapId a b) (F.m1 t x a') = F.m1 t (F.xm a b x) a' := by
  unfold m1; split
  · rw [mapLit_neg _ _ (F.port_pos t 0 x), F.swapId_port a b t 0 x ht (by omega) hx]
  · rw [mapLit_pos _ _ (F.port_pos t 0 x), F.swapId_port a b t 0 x ht (by omega) hx]

omit ha hb in
theorem image_m2 (t x b' : Nat) (ht : t < F.s) (hx : x < F.T) :
    mapLit (F.swapId a b) (F.m2 t x b') = F.m2 t (F.xm a b x) b' := by
  unfold m2; split
  · rw [mapLit_neg _ _ (F.port_pos t 1 x), F.swapId_port a b t 1 x ht (by omega) hx]
  · rw [mapLit_pos _ _ (F.port_pos t 1 x), F.swapId_port a b t 1 x ht (by omega) hx]

omit ha hb in
theorem image_row4 (t x a' b' : Nat) (ht : t < F.s) (hx : x < F.T) (ha' : a' < 2) (hb' : b' < 2) :
    imageRow (F.swapId a b) (F.row4 t x a' b') = F.row4 t (F.xm a b x) a' b' := by
  unfold imageRow row4
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [F.image_m1 a b t x a' ht hx, F.image_m2 a b t x b' ht hx,
    mapLit_neg _ _ (F.val_pos t x), F.swapId_val a b t x ht hx,
    mapLit_pos _ _ (F.fn_pos t _), F.swapId_fn a b t _ ht (by omega)]

omit ha hb in
theorem image_row4' (t x a' b' : Nat) (ht : t < F.s) (hx : x < F.T) (ha' : a' < 2) (hb' : b' < 2) :
    imageRow (F.swapId a b) (F.row4' t x a' b') = F.row4' t (F.xm a b x) a' b' := by
  unfold imageRow row4'
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [F.image_m1 a b t x a' ht hx, F.image_m2 a b t x b' ht hx,
    mapLit_pos _ _ (F.val_pos t x), F.swapId_val a b t x ht hx,
    mapLit_neg _ _ (F.fn_pos t _), F.swapId_fn a b t _ ht (by omega)]

omit ha hb in
theorem image_row5 (x : Nat) (hs : 1 ≤ F.s) (hx : x < F.T) (hinv : F.b (F.xm a b x) = F.b x) :
    imageRow (F.swapId a b) (F.row5 x) = F.row5 (F.xm a b x) := by
  unfold imageRow row5
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true, hinv]
  split
  · rw [mapLit_pos _ _ (F.val_pos _ x), F.swapId_val a b _ x (by omega) hx]
  · rw [mapLit_neg _ _ (F.val_pos _ x), F.swapId_val a b _ x (by omega) hx]

/-- **Images of the original rows are original rows** (semantically), for every k, s ≥ 1,
    every pair of distinct input wires a ≠ b, and every xm-invariant target table. -/
theorem image_rows (hab : a ≠ b) (hs : 1 ≤ F.s) (hinv : ∀ x, x < F.T → F.b (F.xm a b x) = F.b x) :
    ∀ r ∈ F.rows, ∃ r' ∈ F.rows, (imageRow (F.swapId a b) r).equiv r' := by
  intro r hr
  rcases F.mem_rows r hr with ⟨t, p, ht, hp, rfl | rfl⟩ | ⟨t, c, ht, hc, rfl⟩ |
    ⟨t, p, j, x, ht, hp, hj, hx, rfl⟩ | ⟨t, p, i, x, ht, hp, hi, hx, rfl | rfl⟩ |
    ⟨t, x, a', b', ht, hx, ha', hb', rfl | rfl⟩ | ⟨x, hx, rfl⟩
  · exact ⟨_, F.row1_mem t p ht hp, F.image_row1 a b ha hb hab t p ht hp⟩
  · exact ⟨_, F.row1'_mem t p ht hp, F.image_row1' a b ha hb hab t p ht hp⟩
  · exact ⟨_, F.row2_mem t c ht hc, Row.equiv_of_eq (F.image_row2 a b t c ht)⟩
  · exact ⟨_, F.row3i_mem t p (jmap a b j) (F.xm a b x) ht hp (Fam.jmap_lt a b j F.k ha hb hj)
      (F.xm_lt a b x ha hb hx), Row.equiv_of_eq (F.image_row3i a b ha hb t p j x ht hp hj hx)⟩
  · exact ⟨_, F.row3g_mem t p i (F.xm a b x) ht hp hi (F.xm_lt a b x ha hb hx),
      Row.equiv_of_eq (F.image_row3g a b ha hb t p i x ht hp hi hx)⟩
  · exact ⟨_, F.row3g'_mem t p i (F.xm a b x) ht hp hi (F.xm_lt a b x ha hb hx),
      Row.equiv_of_eq (F.image_row3g' a b ha hb t p i x ht hp hi hx)⟩
  · exact ⟨_, F.row4_mem t (F.xm a b x) a' b' ht (F.xm_lt a b x ha hb hx) ha' hb',
      Row.equiv_of_eq (F.image_row4 a b t x a' b' ht hx ha' hb')⟩
  · exact ⟨_, F.row4'_mem t (F.xm a b x) a' b' ht (F.xm_lt a b x ha hb hx) ha' hb',
      Row.equiv_of_eq (F.image_row4' a b t x a' b' ht hx ha' hb')⟩
  · exact ⟨_, F.row5_mem (F.xm a b x) (F.xm_lt a b x ha hb hx),
      Row.equiv_of_eq (F.image_row5 a b x hs hx (hinv x hx))⟩

end Images

/-- the unit row `¬sel(0,p,j) ≥ 1` emitted by `p.red([-F.sel(0,p,j)], …)` -/
def unitNegSel (F : Fam) (p j : Nat) : Row := { lits := [neg (F.sel 0 p j)], rhs := 1 }

theorem image_unitNegSel (F : Fam) (a b p j : Nat) (hs : 1 ≤ F.s) (hp : p < 2) (hj : j < F.k) :
    imageRow (F.swapId a b) (F.unitNegSel p j) = F.unitNegSel p (jmap a b j) := by
  unfold imageRow unitNegSel
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [mapLit_neg _ _ (F.sel_pos 0 p j), F.swapId_sel a b 0 p j (by omega) hp (by omega)]

end Fam
end L3

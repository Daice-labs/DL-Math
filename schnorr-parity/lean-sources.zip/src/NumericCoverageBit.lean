import NumericCoverageOrder
namespace L3Emitter.NumericCoverageBit
open EREF EREF.GeneralRED L3 L3.Fam StI RecordedScopedTrace RecordedOperandFields FieldLengthsFromIDs

theorem program (M:Nat) (F:Fam) (hk:2≤F.k) (hs:1≤F.s) (hm:1≤F.V)
 (t:StI F.V) (C:List Int) (ht:F.Good3 t) (bit:Nat) (hb:bit<2)
 (hbudget:NumericFrontendBudget.Bound M (F.bitStep hm (t,C) bit).1):
 ∀c∈RecordedBitStep.program F hm t bit,Content M c:=by
 let u:=F.cbStart hm bit t
 let cb:=t.s.var+1
 let v:=(List.range F.s).foldl (F.veqStep hm bit cb) u
 have ku:Keeps2 t u:=keeps2_EQ _ hm _ _
 have kv:Keeps2 u v:=keeps2_foldl _ _ (F.keeps2_veqStep hm bit cb) u
 have hu:=F.Good3_of_keeps2 ku ht
 have hv:=F.Good3_of_keeps2 kv hu
 have hc:1≤cb ∧ cb≤u.s.var:=by change 1≤t.s.var+1 ∧ t.s.var+1≤t.s.var+1;omega
 have hcv:1≤cb ∧ cb≤v.s.var:=⟨hc.1,hc.2.trans (var_le_of_grows kv.1)⟩
 have hend:NumericFrontendBudget.Bound M (v.rup (F.bitRoot v cb)):=hbudget
 have hV:=NumericFrontendBudget.mono (keeps2_rup v (F.bitRoot v cb)).1 hend
 have hU:=NumericFrontendBudget.mono kv.1 hV
 have hfields:=NumericCoverageOrder.program M F hk hs hm bit cb u hu hb hc F.s (by omega) hV
 intro c hcs;rcases List.mem_append.mp hcs with hcs|hcs
 · rcases List.mem_append.mp hcs with hcs|hcs
   · exact NumericFrontendBudget.suffix F.db5 t u ku.1 hU c hcs
   · exact hfields c hcs
 · obtain rfl:=List.mem_singleton.mp hcs
   refine ⟨NumericStateFold.clause M 2 _ ?_ (by simp[bitRoot]) (by have:=hV.2;omega),
     NumericFrontendChains.clause_chain M _ _ _ _⟩
   intro l hl;exact ((F.bitRoot_bound v hv cb hcv) l hl).2.trans hV.1

#print axioms program
end L3Emitter.NumericCoverageBit

import L3FrontendComplete
import NormalizedCofactor

/- The proved frontend and the cofactor bank now share the same evolving
database. B is the bank's restriction-control variable; selecting B from the
priority choices is a separate remaining obligation. -/
namespace L3Emitter.FrontendCofactor
open EREF EREF.GeneralRED FableEncoding FamilyNamespace ReferenceTransport
open CofactorSemantics CofactorSection

def state (n : Nat) (hn : 2 ≤ n) : L3.StI (fam (n+1) (3*(n+1)-4)).V :=
  (fam (n+1) (3*(n+1)-4)).frontendX
    (by change 1 ≤ 3*(n+1)-4; omega)

def frontRows (n : Nat) (hn : 2 ≤ n) : List Row :=
  L3.exec (fam (n+1) (3*(n+1)-4)).db5 (state n hn).s.cmds

def offset (n : Nat) (hn : 2 ≤ n) : Nat := (state n hn).s.var

theorem bounded_bridge (D : List Row) (m : Nat) (hD : L3.DBBounded D m) :
    RowSupport.Bounded m D := by
  intro R hR
  obtain ⟨r, rfl, hr⟩ := hD R hR
  refine ⟨L3.canonical_toE r, ?_⟩
  apply RowSupport.normalize_bound
  intro t ht
  obtain ⟨l, hl, rfl⟩ := List.mem_map.mp ht
  exact (hr l hl).2

theorem prefix_bounded (n : Nat) (hn : 2 ≤ n) :
    RowSupport.Bounded (offset n hn) (frontRows n hn) := by
  have h := L3.exec_bounded (fam (n+1) (3*(n+1)-4)).db5
    (fam (n+1) (3*(n+1)-4)).V (state n hn).s.cmds
    ((fam (n+1) (3*(n+1)-4)).db5_bounded (by change 1≤n+1; omega)
      (by change 1≤3*(n+1)-4; omega)) (state n hn).inv.1
  rw [(state n hn).inv.2] at h
  exact bounded_bridge _ _ h

theorem offset_original (n : Nat) (hn : 2 ≤ n) :
    variableCount (n+1) (3*(n+1)-4) ≤ offset n hn := by
  have h := L3.varAfter_mono (fam (n+1) (3*(n+1)-4)).V (state n hn).s.cmds
  rw [(state n hn).inv.2] at h
  exact h

theorem prefix_original (n : Nat) (hn : 2 ≤ n) (R : Row)
    (hR : R ∈ OriginalEncoding.rows (n+1) (3*(n+1)-4)) :
    R ∈ frontRows n hn := by
  rw [← original_rows (n+1) (3*(n+1)-4) (by omega)] at hR
  obtain ⟨r, hr, rfl⟩ := List.mem_map.mp hR
  exact L3.exec_mono _ _ _
    ((fam (n+1) (3*(n+1)-4)).original_mem_db5 r hr)

def target (n : Nat) (hn : 2 ≤ n) (B : Nat) : List Row :=
  frontRows n hn ++ bank n (3*(n+1)-4) (offset n hn) B

theorem database_subset (n : Nat) (hn : 2 ≤ n) (B : Nat) (R : Row)
    (hR : R ∈ database n (3*(n+1)-4) (offset n hn) B) :
    R ∈ target n hn B := by
  rcases List.mem_append.mp hR with hR | hR
  · exact List.mem_append_left _ (prefix_original n hn R hR)
  · exact List.mem_append_right _ hR

def refMap (n : Nat) (hn : 2 ≤ n) (B i : Nat) : Nat :=
  locate (target n hn B)
    ((dbOf (database n (3*(n+1)-4) (offset n hn) B) i).getD contra)

def relocatedTape (n : Nat) (hn : 2 ≤ n) (B : Nat) (j : Job) : List Tok :=
  (resultTape n (3*(n+1)-4) (offset n hn) B j).map (token (refMap n hn B))

theorem relocated_succeeds (n : Nat) (hn : 2 ≤ n) (B : Nat) (hB : 0 < B)
    (j : Job) (hj : j ∈ jobs n (3*(n+1)-4)) :
    polEval (dbOf (target n hn B)) (relocatedTape n hn B j) [] =
      some (resultRow n (3*(n+1)-4) (offset n hn) j) := by
  have h := job_bounds n (3*(n+1)-4) j hj
  apply reindex (dbOf (database n (3*(n+1)-4) (offset n hn) B)) _ (refMap n hn B)
  · intro i R hi
    simp only [refMap, hi, Option.getD_some]
    exact locate_correct _ _ (database_subset n hn B R (dbOf_mem _ _ _ hi))
  · exact all_gate_semantics n (3*(n+1)-4) (offset n hn) B j.1 j.2.1
      hB h.1 h.2 j.2.2.1 j.2.2.2.1 j.2.2.2.2

theorem relocated_trace (n : Nat) (hn : 2 ≤ n) (B : Nat) (hB : 0 < B)
    (js : List Job) (hj : ∀ j ∈ js, j ∈ jobs n (3*(n+1)-4)) (pre : List Row) :
    CheckedTrace (target n hn B ++ pre)
      ((target n hn B ++ pre) ++ js.map (resultRow n (3*(n+1)-4) (offset n hn))) := by
  induction js generalizing pre with
  | nil => simpa using CheckedTrace.refl (target n hn B ++ pre)
  | cons j js ih =>
    have he := relocated_succeeds n hn B hB j (hj j (by simp))
    have hm := polEval_mono _ _ (dbOf_ext_append (target n hn B) pre)
      _ [] _ he
    have ht := ih (by intro q hq; exact hj q (by simp [hq]))
      (pre ++ [resultRow n (3*(n+1)-4) (offset n hn) j])
    have hc := CheckedTrace.cons (CheckedStep.pol _ _ _ hm)
      (by simpa only [List.append_assoc] using ht)
    simpa only [List.map_cons, List.append_assoc, List.singleton_append] using hc

/-- Complete frontend -> freshly allocated cofactor bank -> all gate-semantic
    POL leaves, starting at the exact original formula. No frontend coverage
    oracle remains. Priority/rank/alias/output/tail are not asserted here. -/
theorem frontend_through_cofactor (n : Nat) (hn : 2 ≤ n)
    (B : Nat) (hB : 0 < B) (hBm : B ≤ offset n hn) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4))
      (target n hn B ++ (jobs n (3*(n+1)-4)).map
        (resultRow n (3*(n+1)-4) (offset n hn))) := by
  have hf := FableCoverageIntegration.frontend_from_original (n+1) (by omega)
  have hb := (CofactorBank.bank_trace n (3*(n+1)-4) (offset n hn) B
    (offset_original n hn) hB hBm _ (prefix_bounded n hn)).1
  have hl := relocated_trace n hn B hB (jobs n (3*(n+1)-4))
    (by intros; assumption) []
  exact L3.Fam.checkedTrace_trans hf
    (L3.Fam.checkedTrace_trans hb (by simpa [target] using hl))

theorem relocated_token_count (n : Nat) (hn : 2 ≤ n) (B : Nat) (j : Job) :
    (relocatedTape n hn B j).length = 70 := by
  simp only [relocatedTape, List.length_map, resultTape]
  exact CofactorSemantics.tape_length ..

end L3Emitter.FrontendCofactor

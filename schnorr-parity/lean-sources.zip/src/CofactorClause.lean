import ClauseTransport

namespace L3Emitter.CofactorClause
open EREF REDWitness Resolution CaseJoin ClauseTransport

theorem transport_tail (db : Nat → Option Row) (sourceId : Nat) (g : Int)
    (hg : g≠0) (ls : List Link) (hne : ls≠[])
    (hsource : db sourceId=some (sourceClause ls))
    (hlinks : ∀ p∈ls,p.Available db g) (st : List Row) (tail : List Tok) :
    polEval db (tokens sourceId g ls++tail) st =
      polEval db tail (branch (targetClause ls) g::st) := by
  have hm : 0<ls.length := List.length_pos_iff.mpr hne
  simp only [tokens,List.append_assoc,List.cons_append,List.nil_append,polEval,hsource]
  rw [linkSteps_eval db g hg ls hlinks,
    padSteps_eval db _ (padding_valid ls (by intro p hp; exact (hlinks p hp).2.1))]
  change polEval db (.div ls.length::tail) (combined g ls::st) = _
  rw [combined_scaled ls hne g hg (by intro p hp; exact ⟨(hlinks p hp).1,(hlinks p hp).2.1⟩)]
  simp only [polEval,hm,↓reduceIte]
  rw [divide_scaled ls.length hm (branch (targetClause ls) g) (canonical_normalize _ _)]

/-- Both restrictions share the target clause. This tape transports each
    original row once and merges the two branches by one POL resolution. -/
def tokensBoth (source0 source1 : Nat) (B : Int) (lo hi : List Link) : List Tok :=
  tokens source0 B lo ++ tokens source1 (-B) hi ++ [.add,.div 2]

theorem both_succeed (db : Nat → Option Row) (source0 source1 : Nat) (B : Int)
    (hB : B≠0) (lo hi : List Link) (hlo : lo≠[]) (hhi : hi≠[])
    (hs0 : db source0=some (sourceClause lo))
    (hs1 : db source1=some (sourceClause hi))
    (hl : ∀ p∈lo,p.Available db B)
    (hh : ∀ p∈hi,p.Available db (-B))
    (ht : lo.map Link.target=hi.map Link.target) :
    polEval db (tokensBoth source0 source1 B lo hi) [] = some (targetClause lo) := by
  unfold tokensBoth
  rw [List.append_assoc,transport_tail db source0 B hB lo hlo hs0 hl,
    transport_tail db source1 (-B) (by omega) hi hhi hs1 hh]
  have he : targetClause hi=targetClause lo := by simp only [targetClause,ht]
  rw [he]
  simp only [polEval]
  rw [branch_add (targetClause lo) (canonical_normalize _ _) B hB,
    divide_double (targetClause lo) (canonical_normalize _ _)]
  rfl

theorem both_token_count (s0 s1 : Nat) (B : Int) (lo hi : List Link) :
    (tokensBoth s0 s1 B lo hi).length = 6+2*lo.length+2*hi.length+
      2*((lo.length-1)*lo.length)+2*((hi.length-1)*hi.length) := by
  simp only [tokensBoth,List.length_append,List.length_cons,List.length_nil,token_count]
  omega

theorem four_literal_bound (s0 s1 : Nat) (B : Int) (lo hi : List Link)
    (hl : lo.length≤4) (hh : hi.length≤4) :
    (tokensBoth s0 s1 B lo hi).length≤70 := by
  rw [both_token_count]
  have h0 : (lo.length-1)*lo.length≤12 := Nat.mul_le_mul
    (show lo.length-1≤3 by omega) hl
  have h1 : (hi.length-1)*hi.length≤12 := Nat.mul_le_mul
    (show hi.length-1≤3 by omega) hh
  omega

#print axioms both_succeed
#print axioms four_literal_bound
end L3Emitter.CofactorClause

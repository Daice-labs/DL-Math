import NativeParserBundle
namespace L3Emitter.NativeParserLiteralTraversal
open EREF TemplateBytes CanonicalLineParser NativeParserEventCoordinates PinnedCoordinateChange

def imageLiterals : L3Emitter.Image→List Int
 | .bit _=>[]
 | .lit l=>[SignedNative.litId l]
def witnessLiterals (w:FiniteWitness.Data):List Int:=w.flatMap (fun e=>(e.1:Int)::imageLiterals e.2)
def tokenLiterals : Tok→List Int
 | .lit l=>[l]
 | _=>[]
def literals : Event→List Int
 | .pol ts=>ts.flatMap tokenLiterals
 | .pbc R=>R.terms.map Prod.snd
 | .red R w=>R.terms.map Prod.snd++witnessLiterals w
 | _=>[]

theorem signed_abs (l:Literal):(SignedNative.litId l).natAbs=l.varId:=by
 rcases l with ⟨v,b⟩
 cases b <;> simp [SignedNative.litId]

theorem image_names (i:L3Emitter.Image):(imageLiterals i).map Int.natAbs=imageNames i:=by
 cases i <;> simp only [imageLiterals,imageNames,List.map_nil,List.map_cons,signed_abs]

theorem witness_names (w:FiniteWitness.Data):(witnessLiterals w).map Int.natAbs=witnessNames w:=by
 simp only [witnessLiterals,witnessNames,List.map_flatMap,List.map_cons,Int.natAbs_natCast,image_names]

theorem token_names (t:Tok):(tokenLiterals t).map Int.natAbs=tokenNames t:=by
 cases t <;> rfl

theorem names (e:Event):(literals e).map Int.natAbs=eventNames e:=by
 cases e <;> simp only [literals,eventNames,rowNames,List.map_append,List.map_map,List.map_flatMap,
  witness_names,token_names,Function.comp_def,List.map_nil]

theorem image_nonzero (i:L3Emitter.Image) (h:FiniteWitness.validImage i=true):
 ∀l∈imageLiterals i,l≠0:=by
 cases i with
 | bit b=>simp [imageLiterals]
 | lit q=>
   intro l hl
   obtain rfl:=List.mem_singleton.mp hl
   have hp:0<q.varId:=of_decide_eq_true h
   apply Int.natAbs_pos.mp
   rw [signed_abs]
   exact hp

theorem witness_nonzero (w:FiniteWitness.Data) (h:FiniteWitness.valid w=true):
 ∀l∈witnessLiterals w,l≠0:=by
 have hall:=Bool.and_eq_true_iff.mp h
 intro l hl
 obtain ⟨e,he,hl⟩:=List.mem_flatMap.mp hl
 have hv:=List.all_eq_true.mp hall.1 e he
 obtain ⟨hp,hi⟩:=Bool.and_eq_true_iff.mp hv
 rcases List.mem_cons.mp hl with rfl|hl
 · have hp':0<e.1:=of_decide_eq_true hp;omega
 · exact image_nonzero e.2 hi l hl

theorem nonzero (e:Event) (hv:CanonicalLineParser.Valid e):∀l∈literals e,l≠0:=by
 cases e with
 | pol ts=>
   intro l hl
   obtain ⟨t,ht,hl⟩:=List.mem_flatMap.mp hl
   cases t with
   | lit q=>obtain rfl:=List.mem_singleton.mp hl;exact hv _ ht
   | ref _ | mul _ | div _ | add | sat=>simp [tokenLiterals] at hl
 | pbc R=>
   intro l hl
   obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hl
   exact (hv.1 t ht).2
 | red R w=>
   intro l hl
   rcases List.mem_append.mp hl with hl|hl
   · obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hl;exact (hv.1.1 t ht).2
   · exact witness_nonzero w hv.2 l hl
 | goal _ | close _ | endRed=>simp [literals]

/-- Each variable-bearing byte field is fed to the actual literal-byte
reader in the native encounter order; the resulting IDs agree with the
coordinate map used for the parsed event. -/
theorem fields (initial:List Nat) (e:Event) (hv:CanonicalLineParser.Valid e):
 PinnedLiteralInterning.readAll initial
  ((literals e).map (fun l=>emit (L3Emitter.literal (signedLiteral l))))=
 some (PinnedNameSequence.run initial (eventNames e),
   (literals e).map (lit (coordinate (PinnedNameSequence.run initial (eventNames e))))):=by
 have h:=PinnedLiteralInterning.bytes_global_coordinates initial (literals e) (nonzero e hv)
 rw [PinnedLiteralInterning.names,names] at h
 exact h
#print axioms fields
end L3Emitter.NativeParserLiteralTraversal

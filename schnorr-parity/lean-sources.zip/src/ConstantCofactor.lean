import ConstantConstruction
import FrontendCofactorProgram

namespace L3Emitter.ConstantCofactor
open EREF EREF.GeneralRED REDWitness FamilyNamespace CofactorSemantics CofactorSection

def base (n : Nat) (hn : 2≤n) := ConstantConstruction.result (n+1) (by omega)
def offset (n : Nat) (hn : 2≤n) := ConstantConstruction.C (n+1) (by omega)
def B (n : Nat) (hn : 2≤n) := RestrictionBit.B (n+1) (by omega)
def target (n : Nat) (hn : 2≤n) := base n hn++bank n (3*(n+1)-4) (offset n hn) (B n hn)
def source (n : Nat) (hn : 2≤n) := database n (3*(n+1)-4) (offset n hn) (B n hn)

theorem original_present (n : Nat) (hn : 2≤n) (R : Row)
    (hR : R∈OriginalEncoding.rows (n+1) (3*(n+1)-4)) : R∈base n hn := by
  have hr:=FrontendCofactor.prefix_original n hn R hR
  have hf : R∈FrontendSelection.finalRows (n+1) (by omega) := by
    apply PrioritySourceBinding.selected_retains
    exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hr))
  exact ConstantConstruction.retains_rank _ _ R
    (L3.exec_mono _ _ _ (RestrictionBounds.retains_front _ _ R hf))

theorem offset_original (n : Nat) (hn : 2≤n) :
    variableCount (n+1) (3*(n+1)-4)≤offset n hn := by
  have h:=FrontendCofactor.offset_original n hn
  change variableCount (n+1) (3*(n+1)-4)≤(FrontendSelection.front (n+1) (by omega)).s.var at h
  unfold offset ConstantConstruction.C ConstantConstruction.m RestrictionBit.B RestrictionBit.upper ForcingFamily.upper ForcingBounds.ceiling
  omega

theorem base_bounded (n : Nat) (hn : 2≤n) : RowSupport.Bounded (offset n hn) (base n hn) :=
  FrontendCofactor.bounded_bridge _ _ (ConstantConstruction.original_to_constant (n+1) (by omega)).2

theorem original_to_bank (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (target n hn) := by
  have hf:=(ConstantConstruction.original_to_constant (n+1) (by omega)).1
  have hb:=(CofactorBank.bank_trace n (3*(n+1)-4) (offset n hn) (B n hn)
    (offset_original n hn) (by unfold B RestrictionBit.B;omega)
    (by unfold B offset ConstantConstruction.C ConstantConstruction.m;omega) _ (base_bounded n hn)).1
  exact L3.Fam.checkedTrace_trans hf hb

theorem source_subset (n : Nat) (hn : 2≤n) (R : Row) (hR : R∈source n hn) : R∈target n hn := by
  rcases List.mem_append.mp hR with hR|hR
  · exact List.mem_append_left _ (original_present n hn R hR)
  · exact List.mem_append_right _ hR

def sourceProgram (n : Nat) (hn : 2≤n) (js : List Job) : AliasProgram.Program :=
  js.map (fun j=>(resultRow n (3*(n+1)-4) (offset n hn) j,
    resultTape n (3*(n+1)-4) (offset n hn) (B n hn) j))

theorem source_check (n : Nat) (hn : 2≤n) (js : List Job)
    (hj : ∀j∈js,j∈jobs n (3*(n+1)-4)) (pre : List Row) :
    AliasProgram.check (source n hn++pre) (sourceProgram n hn js)=
      some ((source n hn++pre)++js.map (resultRow n (3*(n+1)-4) (offset n hn))) := by
  induction js generalizing pre with
  | nil => simp [sourceProgram,AliasProgram.check]
  | cons j js ih =>
    have h:=job_bounds _ _ j (hj j (by simp))
    have he:=all_gate_semantics n (3*(n+1)-4) (offset n hn) (B n hn) j.1 j.2.1
      (by unfold B RestrictionBit.B;omega) h.1 h.2 j.2.2.1 j.2.2.2.1 j.2.2.2.2
    have hm:=polEval_mono _ _ (dbOf_ext_append (source n hn) pre) _ [] _ he
    change polEval (dbOf (source n hn++pre)) (resultTape n (3*(n+1)-4) (offset n hn) (B n hn) j) []=
      some (resultRow n (3*(n+1)-4) (offset n hn) j) at hm
    have ht:=ih (by intro q hq;exact hj q (by simp [hq]))
      (pre++[resultRow n (3*(n+1)-4) (offset n hn) j])
    simpa [sourceProgram,AliasProgram.check,hm,List.append_assoc] using ht

def program (n : Nat) (hn : 2≤n) := ProgramRebase.program (source n hn) (target n hn)
  (sourceProgram n hn (jobs n (3*(n+1)-4)))
def result (n : Nat) (hn : 2≤n) := target n hn++(jobs n (3*(n+1)-4)).map
  (resultRow n (3*(n+1)-4) (offset n hn))

theorem program_check (n : Nat) (hn : 2≤n) :
    AliasProgram.check (target n hn) (program n hn)=some (result n hn) := by
  have hs:=source_check n hn (jobs n (3*(n+1)-4)) (by intros;assumption) []
  simp only [List.append_nil] at hs
  have h:=ProgramRebase.program_check _ _ (source_subset n hn) _ _ hs
  simpa [program,result,AliasProgram.outputs,sourceProgram,List.map_map] using h

theorem original_to_selected_cofactor (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (original_to_bank n hn)
    (AliasProgram.check_trace _ _ _ (program_check n hn))

#print axioms original_to_selected_cofactor
#print axioms program_check
end L3Emitter.ConstantCofactor

import LowerGateBank
import U2ConstructionSize
namespace L3Emitter.GateEvaluationSize
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram U2ConstructionSize

theorem composed_commands (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool) (D:List Row):
    (ComposedGateEvaluation.program n hn t G x a b w D).length=11:=by
  have h:=split_commands (D++ComposedGateEvaluation.caseRows n hn t G x a b w)
    (ComposedGateEvaluation.core n hn t G x a b w) (ComposedGateEvaluation.vars n hn G a b)
  change _+1=2^(2+1) at h
  simp only [ComposedGateEvaluation.program,List.length_append,ComposedGateEvaluation.casesProgram,List.length_map]
  change 4+_=11;omega

theorem composed_tokens (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool) (D:List Row):
    tokens (ComposedGateEvaluation.program n hn t G x a b w D)=80:=by
  have h:=split_tokens (D++ComposedGateEvaluation.caseRows n hn t G x a b w)
    (ComposedGateEvaluation.core n hn t G x a b w) (ComposedGateEvaluation.vars n hn G a b)
  change _+4=5*2^2 at h
  have h0:tokens (ComposedGateEvaluation.casesProgram n hn t G x a b w D)=64:=by
    simp [tokens,ComposedGateEvaluation.casesProgram,ComposedGateEvaluation.cases,GateEvaluationPOL.token_count]
  simp only [ComposedGateEvaluation.program,tokens_append,h0];omega

theorem transport_tokens (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool) (D:List Row):
    (RankGateEvaluation.tape n hn t G x a b w D).length=42:=by
  simp [RankGateEvaluation.tape,GuardedTransport.tokens,ClauseTransport.linkSteps,GuardedTransport.padding,
    ClauseTransport.padSteps,RankGateEvaluation.links,ClauseTransport.Link.tokens,LowerPortEvaluation.mapped]

theorem rank_commands (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool) (D:List Row):
    (RankGateEvaluation.program n hn t G x a b w D).length=12:=by
  simp [RankGateEvaluation.program,composed_commands]
theorem rank_tokens (n:Nat) (hn:2≤n) (t G x:Nat) (a b w:Bool) (D:List Row):
    tokens (RankGateEvaluation.program n hn t G x a b w D)=122:=by
  simp only [RankGateEvaluation.program,tokens_append,composed_tokens]
  simp [tokens,transport_tokens]

theorem lower_commands (n:Nat) (hn:2≤n) (t x:Nat) (a b w:Bool) (D:List Row):
    (LowerGateEvaluation.program n hn t x a b w D).length≤12*(3*(n+1)-5)+1:=by
  have h:=fold_commands (fun G E=>RankGateEvaluation.program n hn t G x a b w E)
    (fun G=>RankGateEvaluation.rows n hn t G x a b w) (RankZeroTransport.gates n) D 12
    (fun G _ E=>le_of_eq (rank_commands n hn t G x a b w E))
  simp only [RankZeroTransport.gates,List.length_map,List.length_range] at h
  simp only [LowerGateEvaluation.program,List.length_append,List.length_cons,List.length_nil,RankZeroTransport.gates];nlinarith

theorem lower_tokens (n:Nat) (hn:2≤n) (t x:Nat) (a b w:Bool) (D:List Row):
    tokens (LowerGateEvaluation.program n hn t x a b w D)≤124*(3*(n+1)-5)+2:=by
  have h:=fold_tokens (fun G E=>RankGateEvaluation.program n hn t G x a b w E)
    (fun G=>RankGateEvaluation.rows n hn t G x a b w) (RankZeroTransport.gates n) D 122
    (fun G _ E=>le_of_eq (rank_tokens n hn t G x a b w E))
  simp only [RankZeroTransport.gates,List.length_map,List.length_range] at h
  simp only [LowerGateEvaluation.program,tokens_append]
  simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,ProjectionTrace.joinCaseTokens,CaseJoin.join_token_count,
    List.length_map,RankZeroTransport.gates,List.length_range]
  change tokens (RetainedBlockFold.run _ _ _ D)+(2*(3*(n+1)-5)+2+0)≤_
  nlinarith

theorem jobs_count (n:Nat):(LowerGateBank.jobs n).length=RankConstruction.width (n+1)*FamilyNamespace.truthRows n*8:=by
  simp [LowerGateBank.jobs,List.length_flatMap,List.map_map,Function.comp_def,List.sum_replicate]
  ring

theorem bank_commands (n:Nat) (hn:2≤n):
    (LowerGateBank.program n hn).length≤RankConstruction.width (n+1)*FamilyNamespace.truthRows n*8*(12*(3*(n+1)-5)+1):=by
  have h:=fold_commands (LowerGateBank.leaf n hn) (LowerGateBank.rows n hn) (LowerGateBank.jobs n)
    (GateEvaluationBindings.base n hn) (12*(3*(n+1)-5)+1)
    (fun j _ E=>lower_commands n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2 E)
  simpa only [LowerGateBank.program,jobs_count] using h

theorem bank_tokens (n:Nat) (hn:2≤n):
    tokens (LowerGateBank.program n hn)≤RankConstruction.width (n+1)*FamilyNamespace.truthRows n*8*(124*(3*(n+1)-5)+2):=by
  have h:=fold_tokens (LowerGateBank.leaf n hn) (LowerGateBank.rows n hn) (LowerGateBank.jobs n)
    (GateEvaluationBindings.base n hn) (124*(3*(n+1)-5)+2)
    (fun j _ E=>lower_tokens n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2 E)
  simpa only [LowerGateBank.program,jobs_count] using h

-- Counts only this gate-evaluation bank. The predecessor, output construction,
-- recursive tail and proof of an all-n operand bound are not included.
theorem bank_bytes (n:Nat) (hn:2≤n) (M:Nat)
    (hb:∀c∈LowerGateBank.program n hn,∀t∈c.2,PolTapeBytes.Bounded M t):
    (emit (document (LowerGateBank.program n hn))).length≤
      (3*n-4)*2^n*8*(7*(12*(3*n-2)+1)+(124*(3*n-2)+2)*(3+digits M)):=by
  have h:=program_bytes _ M hb
  have hc:=bank_commands n hn
  have ht:=bank_tokens n hn
  have hL:RankConstruction.width (n+1)=3*n-4:=by unfold RankConstruction.width;omega
  have hG:3*(n+1)-5=3*n-2:=by omega
  rw [hL,hG] at hc ht
  change _≤(3*n-4)*2^n*8*(12*(3*n-2)+1) at hc
  change _≤(3*n-4)*2^n*8*(124*(3*n-2)+2) at ht
  nlinarith
#print axioms bank_bytes
end L3Emitter.GateEvaluationSize

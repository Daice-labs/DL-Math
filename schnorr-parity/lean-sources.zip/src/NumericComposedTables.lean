import NumericRawUnaryRows
import NumericLookupAllocation
namespace L3Emitter.NumericComposedTables
open EREF EREF.GeneralRED AliasNetwork NumericNetwork

def bound (n:Nat):Nat:=NumericRawLowerRows.bound n+108*(n+2)

theorem value_le (n:Nat):NumericValueClosed.bound n≤NumericRawLowerRows.bound n:=
  (NumericRawLowerRows.value_le n).trans (Nat.le_add_right _ _)

theorem entry {base:List Row} (n:Nat) (hn:2≤n) (M:Nat) (z:Net base) (j:ComposedTableBank.Job)
    (hj:j.1<3*(n+1)-4) (hM:NumericValueClosed.bound n≤M) (hz:CanonicalTrace.ceiling z.rows≤M):
    ResultBound (M+9) (ComposedTableBank.entry n hn j z):=by
  apply NumericLookupAllocation.result
  · intro a b;exact ((NumericValueClosed.config n hn).fn j.1 hj a b).trans hM
  · exact (NumericValueClosed.ports n hn j.1 0 hj _).trans hM
  · exact (NumericValueClosed.ports n hn j.1 1 hj _).trans hM
  · exact hz

theorem run {base:List Row} (n:Nat) (hn:2≤n) (M:Nat) (z:Net base) (js:List ComposedTableBank.Job)
    (hj:∀j∈js,j.1<3*(n+1)-4) (hM:NumericValueClosed.bound n≤M) (hz:CanonicalTrace.ceiling z.rows≤M):
    CanonicalTrace.ceiling (ComposedTableBank.run n hn z js).1.rows≤M+9*js.length ∧
    ∀r∈(ComposedTableBank.run n hn z js).2,BitBound (M+9*js.length) (ComposedTableBank.entry n hn r.1 r.2).1:=by
  induction js generalizing M z with
  | nil=>simpa[ComposedTableBank.run] using hz
  | cons j js ih=>
    have hb:=entry n hn M z j (hj j (by simp)) hM hz
    have ht:=ih (M+9) (ComposedTableBank.entry n hn j z).2 (fun j h=>hj j (by simp[h])) (by omega) hb.2
    have he:M+9+9*js.length=M+9*(j::js).length:=by simp only[List.length_cons];ring
    refine ⟨by simpa only[ComposedTableBank.run,he] using ht.1,?_⟩
    intro r hr;rcases List.mem_cons.mp hr with rfl|hr
    · exact hb.1.trans (by simp only[List.length_cons];omega)
    · exact (ht.2 r hr).trans (by omega)

theorem job_length (n:Nat):(ComposedTableBank.jobs n).length≤12*(n+2):=by
  simp[ComposedTableBank.jobs,CategoryBank.gates,List.length_flatMap,Function.comp_def];omega

theorem built (n:Nat) (hn:2≤n):
    CanonicalTrace.ceiling (ComposedTableBank.built n hn).1.rows≤bound n ∧
    ∀r∈(ComposedTableBank.built n hn).2,BitBound (bound n) (ComposedTableBank.value n hn r):=by
  have h:=run n hn (NumericRawLowerRows.bound n) (initial (ComposedTableBank.base n hn) (ComposedTableBank.base_canonical n hn)) (ComposedTableBank.jobs n)
    (fun j hj=>((ComposedTableBank.job_mem n j).mp hj).2) (value_le n)
    (by simpa[Net.rows,initial] using RawBankSize.ceiling_le _ _ (NumericRawUnaryRows.result n hn))
  have he:NumericRawLowerRows.bound n+9*(ComposedTableBank.jobs n).length≤bound n:=by
    have:=Nat.mul_le_mul_left 9 (job_length n);unfold bound;nlinarith
  exact ⟨h.1.trans he,fun r hr=>(h.2 r hr).trans he⟩

theorem result (n:Nat) (hn:2≤n):RowSupport.Bounded (bound n) (ComposedTableBank.result n hn):=by
  apply RowSupport.append
  · exact RowSupport.mono _ (built n hn).1 (CanonicalTrace.bounded _ (ComposedTableBank.built n hn).1.canonical)
  · intro R hR;obtain ⟨c,hc,hR⟩:=List.mem_flatMap.mp hR
    obtain ⟨r,hr,hc⟩:=List.mem_flatMap.mp hc
    obtain ⟨a,ha,hc⟩:=List.mem_flatMap.mp hc
    obtain ⟨b,hb,hc⟩:=List.mem_flatMap.mp hc
    obtain ⟨v,hv,rfl⟩:=List.mem_map.mp hc
    exact NumericLookupRows.rows_of_output _ _ _ _ a b v _ ((built n hn).2 r hr) R hR
#print axioms result
end L3Emitter.NumericComposedTables

import CanonicalWitnessParser

namespace L3Emitter.CanonicalPOLParser
open EREF CanonicalRowParser TemplateBytes

def tokenWords : Tok→List Bytes
  | .ref i=>[decimal i]
  | .lit l=>[emit (literal (signedLiteral l))]
  | .add=>[[43]]
  | .mul n=>[decimal n,[42]]
  | .div n=>[decimal n,[100]]
  | .sat=>[[115]]

def Valid : Tok→Prop
  | .ref i => 0 < i
  | .lit l => l ≠ 0
  | .mul n => 0 < n
  | .div n => 0 < n
  | _ => True

def words (ts : List Tok) := ts.flatMap tokenWords

def parseWords : List Bytes→Option (List Tok)
  | []=>some []
  | a::rest=>
    if a=[43] then (parseWords rest).map (Tok.add::·)
    else if a=[115] then (parseWords rest).map (Tok.sat::·)
    else match DecimalParser.parse a with
    | some n=>if n=0 then none else match rest with
      | []=>some [.ref n]
      | b::tail=>
        if b=[42] then (parseWords tail).map (Tok.mul n::·)
        else if b=[100] then (parseWords tail).map (Tok.div n::·)
        else (parseWords (b::tail)).map (Tok.ref n::·)
    | none=>do
      let l←LiteralParser.parse a
      let ts←parseWords rest
      return Tok.lit (SignedNative.litId l)::ts

def parse (bs : Bytes) := parseWords (lex bs)

theorem decimal_ne_opcode (n : Nat) (b : UInt8) (hb : DecimalParser.parse [b]=none) :
    decimal n≠[b] := by
  intro he
  have hh:=congrArg DecimalParser.parse he
  rw [DecimalParser.roundtrip,hb] at hh
  contradiction

theorem literal_ne_opcode (l : Literal) (b : UInt8) (hb : b≠120 ∧ b≠126) :
    emit (literal l)≠[b] := by
  rw [LiteralParser.encoded]
  cases l.negative <;> simp [Ne.symm hb.1,Ne.symm hb.2]

theorem literal_not_number (l : Literal) : DecimalParser.parse (emit (literal l))=none := by
  rw [LiteralParser.encoded]
  cases l.negative <;> rfl

theorem first_not_operator (ts : List Tok) (a : Bytes) (rest : List Bytes)
    (he : words ts=a::rest) : a≠[42] ∧ a≠[100] := by
  cases ts with
  | nil=>simp [words] at he
  | cons t ts=>
    cases t <;> simp only [words,List.flatMap_cons,tokenWords,List.cons_append,List.nil_append,
      List.cons.injEq] at he
    all_goals rcases he with ⟨rfl,_⟩
    all_goals first
      | exact ⟨decimal_ne_opcode _ _ rfl,decimal_ne_opcode _ _ rfl⟩
      | exact ⟨literal_ne_opcode _ _ (by decide),literal_ne_opcode _ _ (by decide)⟩
      | decide

theorem words_roundtrip (ts : List Tok) (hv : ∀ t∈ts,Valid t) :
    parseWords (words ts)=some ts := by
  induction ts with
  | nil=>rfl
  | cons t ts ih=>
    have ht:=hv t (by simp)
    have hi:=ih (by intro u hu;exact hv u (by simp [hu]))
    cases t with
    | ref i=>
      have hn:i≠0:=by exact Nat.ne_of_gt ht
      have ha:=decimal_ne_opcode i 43 (by rfl)
      have hs:=decimal_ne_opcode i 115 (by rfl)
      change parseWords (decimal i::words ts)=_
      cases he:words ts with
      | nil=>
        have ht0:ts=[]:=by
          cases ts with
          | nil=>rfl
          | cons t ts=>cases t <;> simp [words,tokenWords] at he
        subst ts
        simp [parseWords,ha,hs,DecimalParser.roundtrip,hn]
      | cons a rest=>
        obtain ⟨hstar,hdiv⟩:=first_not_operator ts a rest he
        rw [he] at hi
        simp [parseWords,ha,hs,DecimalParser.roundtrip,hn,hstar,hdiv,hi]
    | lit l=>
      have ha:=literal_ne_opcode (signedLiteral l) 43 (by decide)
      have hs:=literal_ne_opcode (signedLiteral l) 115 (by decide)
      have hl:0<(signedLiteral l).varId:=Int.natAbs_pos.mpr ht
      change parseWords (emit (literal (signedLiteral l))::words ts)=_
      simp [parseWords,ha,hs,literal_not_number,LiteralParser.roundtrip _ hl,hi,
        CanonicalFormulaReadback.signed_id]
    | add=>
      change parseWords ([43]::words ts)=_
      simp [parseWords,hi]
    | sat=>
      change parseWords ([115]::words ts)=_
      simp [parseWords,hi]
    | mul n=>
      have hn:n≠0:=Nat.ne_of_gt ht
      change parseWords (decimal n::[42]::words ts)=_
      simp [parseWords,decimal_ne_opcode n 43 (by rfl),decimal_ne_opcode n 115 (by rfl),
        DecimalParser.roundtrip,hn,hi]
    | div n=>
      have hn:n≠0:=Nat.ne_of_gt ht
      change parseWords (decimal n::[100]::words ts)=_
      simp [parseWords,decimal_ne_opcode n 43 (by rfl),decimal_ne_opcode n 115 (by rfl),
        DecimalParser.roundtrip,hn,hi]

theorem token_lex (t : Tok) : lex (emit (polToken (CompactTapeBytes.token t)))=tokenWords t := by
  cases t with
  | ref i=>simpa [CompactTapeBytes.token,polToken,integer,emit,number,Piece.emit,
      show ¬(i:Int)<0 by omega,tokenWords] using lex_decimal i
  | lit l=>exact lex_literal _
  | add=>rfl
  | sat=>rfl
  | mul n=>
    have he:emit (polToken (CompactTapeBytes.token (.mul n)))=decimal n++32::[42]:=by
      simp [CompactTapeBytes.token,polToken,emit,Piece.emit,number,fixed,ascii]
      rfl
    rw [he,lex_space,lex_decimal]
    rfl
  | div n=>
    have he:emit (polToken (CompactTapeBytes.token (.div n)))=decimal n++32::[100]:=by
      simp [CompactTapeBytes.token,polToken,emit,Piece.emit,number,fixed,ascii]
      rfl
    rw [he,lex_space,lex_decimal]
    rfl

/-- Roundtrip of all actual ASCII POL operand/operator bytes. Command/scope
delimiters and the native stack/arithmetic refinement remain separate. -/
theorem tape_roundtrip (ts : List Tok) (hv : ∀ t∈ts,Valid t) :
    parse (emit (separated (fixed " ") (ts.map (fun t=>polToken (CompactTapeBytes.token t)))))=
      some ts := by
  rw [parse,separated_lex]
  simp only [List.flatMap_map,token_lex]
  exact words_roundtrip ts hv

#print axioms words_roundtrip
#print axioms token_lex
#print axioms tape_roundtrip
end L3Emitter.CanonicalPOLParser

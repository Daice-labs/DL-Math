import NumericCollections
namespace L3Emitter.NumericNetwork
open EREF EREF.GeneralRED AliasNetwork RecursiveAliases

structure ConfigBound (M G w:Nat) (c:Config Bit):Prop where
  T : BitBound M c.T
  F : BitBound M c.F
  B : BitBound M c.B
  C : BitBound M c.C
  beta : ∀g,G>g → BitBound M (c.beta g)
  gamma : ∀g,G>g → BitBound M (c.gamma g)
  hit : ∀g,G>g → BitBound M (c.hit g)
  kept : ∀g,G>g → BitBound M (c.kept g)
  rank : ∀g,G>g → ∀t,t<w → BitBound M (c.rank g t)
  sel : ∀g,G>g → ∀p,p<2 → ∀j,j<c.k+g → BitBound M (c.sel g p j)
  fn : ∀g,G>g → ∀a b,BitBound M (c.fn g a b)

theorem config_mono {M N G w:Nat} {c:Config Bit} (h:M≤N) (hc:ConfigBound M G w c):
    ConfigBound N G w c:=
  ⟨hc.T.trans h,hc.F.trans h,hc.B.trans h,hc.C.trans h,
   fun g hg=>(hc.beta g hg).trans h,fun g hg=>(hc.gamma g hg).trans h,
   fun g hg=>(hc.hit g hg).trans h,fun g hg=>(hc.kept g hg).trans h,
   fun g hg t ht=>(hc.rank g hg t ht).trans h,
   fun g hg p hp j hj=>(hc.sel g hg p hp j hj).trans h,
   fun g hg a b=>(hc.fn g hg a b).trans h⟩

theorem lookup_bound (M:Nat) (f:Bool→Bool→Bit) (a b:Expr)
    (hf:∀x y,BitBound M (f x y)) (ha:ExprBound M a) (hb:ExprBound M b):
    ExprBound M (lookup f a b):=
  ⟨ha,⟨hb,hf true true,hf true false⟩,⟨hb,hf false true,hf false false⟩⟩

theorem coordinate_bound (M G w:Nat) (c:Config Bit) (g:Nat) (hg:g<G)
    (hc:ConfigBound M G w c) (l r:AliasBits w)
    (hl:∀i,BitBound M (l i)) (hr:∀i,BitBound M (r i)) (i:Fin (w+2)):
    ExprBound M (coordinate c g l r i):=by
  unfold coordinate
  split_ifs with h0 hi hj hi hj ht
  all_goals simp only [ExprBound]
  all_goals try exact hc.T
  all_goals try exact hc.F
  all_goals try exact ⟨hc.B,hc.fn 0 (by omega) true _,hc.fn 0 (by omega) false _⟩
  all_goals try exact ⟨⟨⟨hc.beta g hg,hc.T⟩,⟨hc.gamma g hg,⟨hc.hit g hg,hr i,hl i⟩⟩⟩,hc.rank g hg _ (by omega)⟩
  all_goals try exact ⟨⟨⟨hc.beta g hg,hc.T⟩,⟨hc.gamma g hg,⟨hc.hit g hg,hr i,hl i⟩⟩⟩,hc.F⟩
  all_goals try exact ⟨⟨⟨hc.beta g hg,hc.F⟩,⟨hc.gamma g hg,⟨hc.hit g hg,hr i,hl i⟩⟩⟩,hc.rank g hg _ (by omega)⟩
  all_goals try exact ⟨⟨⟨hc.beta g hg,hc.F⟩,⟨hc.gamma g hg,⟨hc.hit g hg,hr i,hl i⟩⟩⟩,hc.F⟩
  all_goals try exact ⟨⟨⟨hc.beta g hg,hc.C⟩,⟨hc.gamma g hg,⟨hc.hit g hg,lookup_bound M _ _ _ (hc.fn g hg) hc.C (hr i),lookup_bound M _ _ _ (hc.fn g hg) (hl i) hc.C⟩⟩⟩,hc.kept g hg⟩
  all_goals try exact ⟨⟨⟨hc.beta g hg,hc.C⟩,⟨hc.gamma g hg,⟨hc.hit g hg,lookup_bound M _ _ _ (hc.fn g hg) hc.C (hr i),lookup_bound M _ _ _ (hc.fn g hg) (hl i) hc.C⟩⟩⟩,hc.F⟩

#print axioms coordinate_bound
end L3Emitter.NumericNetwork

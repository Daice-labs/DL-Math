import NumericAliasProgram
namespace L3Emitter.NumericCofactorNamespace
open EREF EREF.GeneralRED REDWitness FamilyNamespace CofactorSemantics
open FrontendNamespaceEnvelope

def cap (n:Nat) (hn:2≤n):Nat:=ConstantCofactor.offset n hn+3*(3*(n+1)-4)*truthRows n

theorem output_abs (q:Nat) (b:Bool):(output q b).natAbs=q:=by
  cases b <;> simp[output]

theorem fn_bound (n s g:Nat) (hg:g<s) (a b c:Bool):
    (fnLiteral n s g a b c).natAbs≤variableCount (n+1) s:=by
  rw[fnLiteral,output_abs]
  exact (encode_bounds (n+1) s (.fn g (2*a.toNat+b.toNat)) ⟨hg,by cases a <;> cases b <;> decide⟩).2

theorem goal_bounded (n s offset g x:Nat) (hg:g<s) (hx:x<truthRows n)
    (hV:variableCount (n+1) s≤offset) (a b c:Bool):
    RowSupport.Bounded (offset+3*s*truthRows n) [goal n s offset g x a b c]:=by
  intro R hR;obtain rfl:=List.mem_singleton.mp hR
  refine ⟨canonical_normalize _ _,RowSupport.clause_bound _ _ ?_⟩
  intro l hl
  simp only[goal,List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl|rfl|rfl|rfl
  · rw[output_abs];exact CofactorBytes.low_bound n s offset g 0 x hg (by omega) hx
  · rw[output_abs];exact CofactorBytes.low_bound n s offset g 1 x hg (by omega) hx
  · rw[output_abs];exact CofactorBytes.low_bound n s offset g 2 x hg (by omega) hx
  · exact (fn_bound n s g hg a b c).trans (by omega)

theorem actual_target (n:Nat) (hn:2≤n):RowSupport.Bounded (cap n hn) (ConstantCofactor.target n hn):=by
  exact (CofactorBank.bank_trace n (3*(n+1)-4) (ConstantCofactor.offset n hn)
    (ConstantCofactor.B n hn) (ConstantCofactor.offset_original n hn)
    (by unfold ConstantCofactor.B RestrictionBit.B;omega)
    (by unfold ConstantCofactor.B ConstantCofactor.offset ConstantConstruction.C ConstantConstruction.m;omega)
    _ (ConstantCofactor.base_bounded n hn)).2

theorem actual_result (n:Nat) (hn:2≤n):RowSupport.Bounded (cap n hn) (ConstantCofactor.result n hn):=by
  apply RowSupport.append _ _ _ (actual_target n hn)
  intro R hR;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hR
  have h:=CofactorSection.job_bounds n (3*(n+1)-4) j hj
  exact goal_bounded n (3*(n+1)-4) (ConstantCofactor.offset n hn) j.1 j.2.1 h.1 h.2
    (ConstantCofactor.offset_original n hn) j.2.2.1 j.2.2.2.1 j.2.2.2.2 _ (by simp[CofactorSection.resultRow])

theorem cap_bound (n:Nat) (hn:2≤n):cap n hn≤1600*scale (n+1):=by
  have h:=FrontendNamespaceEnvelope.constant (n+1) (by omega)
  have hs:3*(n+1)-4≤3*(n+1):=by omega
  have ht:2^n≤2^(n+1):=Nat.pow_le_pow_right (by omega) (by omega)
  have hk:n+1≤(n+1+1)^2:=by nlinarith
  have hmul:=Nat.mul_le_mul (show 3*(3*(n+1)-4)≤9*(n+1+1)^2 by nlinarith) ht
  change ConstantCofactor.offset n hn≤1500*scale (n+1) at h
  unfold cap truthRows scale at *
  nlinarith

#print axioms actual_result
#print axioms cap_bound
end L3Emitter.NumericCofactorNamespace

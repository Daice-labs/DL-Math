import ConstructionFamilyLocalBounds
import FormulaSize
import GlobalValueSize

namespace L3Emitter.ConstructionCountTools
open EREF EREF.GeneralRED

/-- A successful POL-only program adds exactly one row per command. -/
theorem checked_length (D E : List Row) (p : AliasProgram.Program)
    (h : AliasProgram.check D p=some E) : E.length=D.length+p.length := by
  induction p generalizing D with
  | nil => simp only [AliasProgram.check,Option.some.injEq] at h; subst E; simp
  | cons c cs ih =>
    rcases c with ⟨R,ts⟩
    simp only [AliasProgram.check] at h
    split at h
    · have hh:=ih (D++[R]) h
      simpa only [List.length_append,List.length_singleton,List.length_cons,List.length_nil,Nat.add_assoc,Nat.add_comm 1] using hh
    · contradiction

theorem checked_body (D rs : List Row) (p : AliasProgram.Program)
    (h : AliasProgram.check D p=some (D++rs)) : p.length=rs.length := by
  have hh:=checked_length D (D++rs) p h
  simp only [List.length_append] at hh
  omega

theorem polProgram_length (p : AliasProgram.Program) :
    (RecordedBaseTwo.polProgram p).length=p.length := by simp [RecordedBaseTwo.polProgram]

/-- Generic state-dependent fold: the cost bound is independent of the
accumulated database, and counts actual commands rather than semantic rows. -/
theorem state_fold {S A : Type} (next : S→A→S)
    (step : S→A→RecordedScopedTrace.Program) (xs : List A) (s : S) (B : Nat)
    (h : ∀s a, (step s a).length≤B) :
    (RecordedStateFold.run next step s xs).length≤xs.length*B := by
  induction xs generalizing s with
  | nil => simp [RecordedStateFold.run]
  | cons a xs ih =>
    simp only [RecordedStateFold.run,List.length_append,List.length_cons]
    calc
      _ ≤ B+xs.length*B := Nat.add_le_add (h s a) (ih _)
      _ = (xs.length+1)*B := by ring

theorem split_count (leaf : List Row→List Int→RecordedRefutation.Certificate)
    (D : List Row) (c vs : List Int) :
    (RecordedSplit.run leaf D c vs).length+1=2^(vs.length+1) := by
  induction vs generalizing D c with
  | nil => simp [RecordedSplit.run]
  | cons v vs ih =>
    simp only [RecordedSplit.run,List.length_append,List.length_singleton,List.length_cons,List.length_nil]
    have h1:=ih D (c++[v])
    have h2:=ih (D++RecordedSplit.rows (c++[v]) vs) (c++[-v])
    rw [pow_succ]
    omega

/-- The retained POL-bank fold also admits a bound that uses job membership. -/
theorem retained_fold {A : Type} (step : A→List Row→AliasProgram.Program)
    (rows : A→List Row) (xs : List A) (D : List Row) (B : Nat)
    (h : ∀a∈xs,∀D,(step a D).length≤B) :
    (RetainedBlockFold.run step rows xs D).length≤xs.length*B := by
  induction xs generalizing D with
  | nil => simp [RetainedBlockFold.run]
  | cons a xs ih =>
    simp only [RetainedBlockFold.run,List.length_append,List.length_cons]
    calc
      _ ≤ B+xs.length*B := Nat.add_le_add (h a (by simp) D)
        (ih _ (fun j hj E=>h j (by simp [hj]) E))
      _ = (xs.length+1)*B := by ring

#print axioms checked_body
#print axioms state_fold
#print axioms split_count
end L3Emitter.ConstructionCountTools

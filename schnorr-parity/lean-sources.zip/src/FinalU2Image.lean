import FinalU2Bank
namespace L3Emitter.FinalU2Image
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL FamilyNamespace FamilyRows U2SourcePOL
open FinalOutputDefinitions

theorem image_eq (n:Nat) (hn:2≤n) (p:Bool):
    FinalLowerImage.image n hn (InputSwap.forbidden (lastRank n) (if p then 6 else 9))=original (FinalU2Bank.q n hn) p:=by
  cases p <;> simp [FinalLowerImage.image,InputSwap.forbidden,FinalLowerImage.wire,original,literals,identity,
    FinalU2Bank.q,FinalFunctionFullLinks.q,FinalU2Bank.code,RankTableBank.code,sign,clause,List.range_succ] <;> rfl
theorem retained (n:Nat) (hn:2≤n):∀R∈FinalU2Bank.base n hn,R∈FinalU2Bank.result n hn:=
  fun R h=>List.mem_append_left _ (List.mem_append_left _ h)
theorem all_U2_images (n:Nat) (hn:2≤n) (r:Spec) (hr:r∈OriginalEncoding.forbiddenBlock (3*n-4)):
    FinalLowerImage.image n hn r∈FinalU2Bank.result n hn:=by
  obtain ⟨t,c,ht,hc,rfl⟩:=(OriginalEncoding.forbidden_mem _ r).mp hr
  by_cases he:t=lastRank n
  · subst t
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hc
    rcases hc with rfl|rfl
    · rw [show (6:Nat)=(if true then 6 else 9) from rfl,image_eq];exact FinalU2Bank.all_rows n hn true
    · rw [show (9:Nat)=(if false then 6 else 9) from rfl,image_eq];exact FinalU2Bank.all_rows n hn false
  · apply retained
    apply FinalU2Bank.definitions_kept
    exact FinalLowerEarlier.forbidden n hn t c (by unfold lastRank RankConstruction.width at he ⊢;omega) hc
#print axioms all_U2_images
end L3Emitter.FinalU2Image

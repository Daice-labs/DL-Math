import NumericTableTapes
import NumericAliasRecorded
namespace L3Emitter.NumericComposedFields
open EREF EREF.GeneralRED FieldLengthsFromIDs AliasNetwork NumericNetwork NumericNetworkWidths

theorem entry_width {B:List Row} (n:Nat) (hn:2≤n) (j:ComposedTableBank.Job) (z:Net B)
 (hz:Width 2 z.gates):Width 2 (ComposedTableBank.entry n hn j z).2.gates:=by
 unfold ComposedTableBank.entry;rw [LookupEvaluation.compiled]
 exact expr_keeps 2 (by decide) _ z hz

theorem run_width {B:List Row} (n:Nat) (hn:2≤n) (z:Net B) (js:List ComposedTableBank.Job)
 (hz:Width 2 z.gates):Width 2 (ComposedTableBank.run n hn z js).1.gates:=by
 induction js generalizing z with
 | nil=>exact hz
 | cons j js ih=>exact ih _ (entry_width n hn j z hz)

def bound (n:Nat):Nat:=NumericComposedTables.bound n+10

theorem definitions (n:Nat) (hn:2≤n):
 ∀c∈RecordedNetwork.program (ComposedTableBank.base n hn) (ComposedTableBank.built n hn).1.gates,Content (bound n) c:=by
 have hf:=NumericGateSupport.built_fields _ _ (RecordedComposedTables.built_history n hn)
 have hc:=(NumericComposedTables.built n hn).1
 have hw:=run_width n hn (initial (ComposedTableBank.base n hn) (ComposedTableBank.base_canonical n hn)) (ComposedTableBank.jobs n) (by simp [Width,initial])
 apply NumericRecordedGates.network
 · intro g hg;have h:=(hf g hg).1
   change g.q≤CanonicalTrace.ceiling (ComposedTableBank.built n hn).1.rows at h
   unfold bound;omega
 · intro g hg x hx;have h:=(hf g hg).2 x hx
   change x.val.natAbs≤CanonicalTrace.ceiling (ComposedTableBank.built n hn).1.rows at h
   unfold bound;omega
 · intro g hg;have h:=hw g hg
   unfold bound;nlinarith

theorem program (n:Nat) (hn:2≤n):∀c∈RecordedComposedTables.program n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · exact definitions n hn c hc
 · exact NumericProgramFields.pol _ _ (NumericGuardTapes.mono (by unfold bound;omega) _ (NumericTableTapes.composed n hn)) c hc
#print axioms program
end L3Emitter.NumericComposedFields

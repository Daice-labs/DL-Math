import GateSourceOneHot

namespace L3Emitter.GateOrderSources
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot RecursiveAliases

def Invariant (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=
  ∀j,j<n+1+g→SourceRows D ((AliasAssembly.built n hn).1.2 j)
def Keep (n:Nat) (hn:2≤n) (D:List Row) :=∀R∈SourceAuxBank.result n hn,R∈D

theorem before_final (n:Nat) (hn:2≤n) (g:Nat) (hg:g≤3*(n+1)-4) (j:Nat) (hj:j<n+1+g) :
    (GateSnapshots.beforeGate n hn g).1 j=(AliasAssembly.built n hn).1.2 j := by
  have he:3*(n+1)-4=g+(3*(n+1)-4-g):=by omega
  have h:=GateSnapshots.run_split (PrimaryAliasBank.cfg n hn) (FirstPortRelations.initialAliases n hn)
    0 g (3*(n+1)-4-g) (PrimaryAliasBank.context n hn).2
  rw [←he] at h
  simp only [Nat.zero_add] at h
  have hh:=congrArg (fun a=>a.1 j) h
  change (AliasAssembly.built n hn).1.2 j=_ at hh
  dsimp only at hh
  rw [FirstGateSource.run_earlier _ _ _ _ _ j (by exact hj)] at hh
  exact hh.symm

theorem earlier_sources (n:Nat) (hn:2≤n) (g:Nat) (hg:g≤3*(n+1)-4) (D:List Row)
    (h:Invariant n hn g D) :∀j,j<n+1+g→SourceRows D ((GateSnapshots.beforeGate n hn g).1 j) := by
  intro j hj
  rw [before_final n hn g hg j hj]
  exact h j hj

def afterLeft (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=GatePortOneHot.result n hn g 0 D
def afterRight (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=GatePortOneHot.result n hn g 1 (afterLeft n hn g D)
def afterMux (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=MuxSourceStep.result n hn g (afterRight n hn g D)
def stepResult (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=GateSourceOneHot.result n hn g (afterMux n hn g D)
def stepProgram (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=
  GatePortOneHot.program n hn g 0 D++GatePortOneHot.program n hn g 1 (afterLeft n hn g D)++
  MuxSourceStep.program n hn g (afterRight n hn g D)++GateSourceOneHot.program n hn g (afterMux n hn g D)

theorem step_retains (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :∀R∈D,R∈stepResult n hn g D :=
  fun R h=>GateSourceOneHot.retains n hn g _ R (MuxSourceStep.retains n hn g _ R
    (GatePortOneHot.retains n hn g 1 _ R (GatePortOneHot.retains n hn g 0 _ R h)))

theorem step_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (D:List Row) (hd:Keep n hn D) (hi:Invariant n hn g D) :
    check D (stepProgram n hn g D)=some (stepResult n hn g D) := by
  have cat:CategorySourceInputs.Keep n hn D:=fun R h=>hd R (SourceAuxBank.contains_category n hn R h)
  have sources:=earlier_sources n hn g (by omega) D hi
  have h0:=GatePortOneHot.checks n hn g hs 0 (by omega) D cat sources
  have keep0:=GatePortOneHot.retains n hn g 0 D
  have keep1:=GatePortOneHot.retains n hn g 1 (afterLeft n hn g D)
  have keep2:=MuxSourceStep.retains n hn g (afterRight n hn g D)
  have h1:=GatePortOneHot.checks n hn g hs 1 (by omega) (afterLeft n hn g D)
    (fun R h=>keep0 R (cat R h)) (fun j hj=>⟨keep0 _ (sources j hj).1,fun i l hil=>keep0 _ ((sources j hj).2 i l hil)⟩)
  have hl:=GatePortOneHot.source_rows n hn g 0 D
  have hr:=GatePortOneHot.source_rows n hn g 1 (afterLeft n hn g D)
  have h2:=MuxSourceStep.checks n hn g hg hs (afterRight n hn g D)
    (fun R h=>keep1 R (keep0 R (hd R h))) ⟨keep1 _ hl.1,fun i j hij=>keep1 _ (hl.2 i j hij)⟩ hr
  have h3:=GateSourceOneHot.checks n hn g hg hs (afterMux n hn g D)
    (fun R h=>keep2 R (keep1 R (keep0 R (hd R h)))) (MuxSourceStep.source_rows n hn g (afterRight n hn g D))
  exact check_append _ _ _ _ _ (check_append _ _ _ _ _ (check_append _ _ _ _ _ h0 h1) h2) h3

theorem step_invariant (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) (hi:Invariant n hn g D) :
    Invariant n hn (g+1) (stepResult n hn g D) := by
  intro j hj
  by_cases h:j<n+1+g
  · exact ⟨step_retains n hn g D _ (hi j h).1,fun i l hil=>step_retains n hn g D _ ((hi j h).2 i l hil)⟩
  · have he:j=n+1+g:=by omega
    subst j
    exact GateSourceOneHot.source_rows n hn g (afterMux n hn g D)

def result (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :Nat→List Row
  | 0=>D
  | m+1=>result n hn (g+1) (stepResult n hn g D) m
def program (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :Nat→Program
  | 0=>[]
  | m+1=>stepProgram n hn g D++program n hn (g+1) (stepResult n hn g D) m

theorem induction_checks (n:Nat) (hn:2≤n) (m g:Nat) (hg:0<g) (hs:g+m≤3*(n+1)-4)
    (D:List Row) (hd:Keep n hn D) (hi:Invariant n hn g D) :
    check D (program n hn g D m)=some (result n hn g D m) ∧ Invariant n hn (g+m) (result n hn g D m) := by
  induction m generalizing g D with
  | zero=>exact ⟨rfl,hi⟩
  | succ m ih=>
    have h0:=step_check n hn g hg (by omega) D hd hi
    have h1:=ih (g+1) (by omega) (by omega) (stepResult n hn g D)
      (fun R h=>step_retains n hn g D R (hd R h)) (step_invariant n hn g D hi)
    exact ⟨check_append _ _ _ _ _ h0 h1.1,by simpa only [Nat.add_assoc,Nat.add_comm 1 m] using h1.2⟩


theorem initial_invariant (n:Nat) (hn:2≤n) :Invariant n hn 1 (SourceAuxBank.result n hn) := by
  intro j hj
  have keep:∀R∈FirstPortOneHot.result n hn,R∈SourceAuxBank.result n hn:=
    fun R h=>SourceAuxBank.contains_category n hn R (CategoryBank.retains n hn R h)
  by_cases h:j<n+1
  · have he:(AliasAssembly.built n hn).1.2 j=FirstPortRelations.initialAliases n hn j:=
      FirstGateSource.run_earlier (PrimaryAliasBank.cfg n hn) (FirstPortRelations.initialAliases n hn)
        0 (3*(n+1)-4) (PrimaryAliasBank.context n hn).2 j h
    rw [he]
    have hh:=PrimaryAliasBank.source_rows n hn j h
    have hk:∀R∈PrimaryAliasBank.result n hn,R∈SourceAuxBank.result n hn:=
      fun R h=>keep R (FirstPortOneHot.block_retains n hn 1 _ R (FirstPortOneHot.block_retains n hn 0 _ R h))
    exact ⟨hk _ hh.1,fun i l hil=>hk _ (hh.2 i l hil)⟩
  · have he:j=n+1:=by omega
    subst j
    have hh:=FirstGateSource.actual_first_gate_source_rows n hn
    exact ⟨keep _ hh.1,fun i l hil=>keep _ (hh.2 i l hil)⟩

def fullResult (n:Nat) (hn:2≤n) :=result n hn 1 (SourceAuxBank.result n hn) (3*(n+1)-5)
def fullProgram (n:Nat) (hn:2≤n) :=program n hn 1 (SourceAuxBank.result n hn) (3*(n+1)-5)
theorem full_check (n:Nat) (hn:2≤n) :
    check (SourceAuxBank.result n hn) (fullProgram n hn)=some (fullResult n hn) :=
  (induction_checks n hn (3*(n+1)-5) 1 (by omega) (by omega) _ (fun R h=>h) (initial_invariant n hn)).1

theorem all_source_rows (n:Nat) (hn:2≤n) (j:Nat) (hj:j<n+1+(3*(n+1)-4)) :
    SourceRows (fullResult n hn) ((AliasAssembly.built n hn).1.2 j) := by
  have h:=(induction_checks n hn (3*(n+1)-5) 1 (by omega) (by omega) _ (fun R h=>h) (initial_invariant n hn)).2
  exact h j (by omega)

theorem original_to_all_sources (n:Nat) (hn:2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (fullResult n hn) :=
  L3.Fam.checkedTrace_trans (SourceAuxBank.original_to_aux n hn) (check_trace _ _ _ (full_check n hn))

#print axioms step_check
#print axioms induction_checks
#print axioms full_check
#print axioms all_source_rows
#print axioms original_to_all_sources
end L3Emitter.GateOrderSources

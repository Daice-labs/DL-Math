import GlobalValueSize
import U2ConstructionSize
import MainTapeRecurrence
namespace L3Emitter.GlobalMainTapeBounds
open EREF AliasNetwork AliasProgram U2ConstructionSize

theorem branch (n : Nat) (hn : 2≤n) (g : Nat) (j : BetaPort.Job n)
    (i : Fin (AliasAssembly.width (n+1))) (b v : Bool) (D : List Row) :
    tokens (ForcingValueCases.program n hn g j i b v D)≤832*n+254 := by
  unfold ForcingValueCases.program
  split
  · simp [tokens,ValueBranchRows.betaTape,ChoiceProjection.weakenTokens,ClauseTransport.padSteps]
  · split
    · exact GammaInductiveBounds.tokens ..
    · split
      · simp [tokens]
      · rename_i r hr
        have ht:=RankValueBranch.token_count n hn g r i (SourceCoordinateValue.value n hn i r.val.2.1) b v D
        change tokens _≤15 at ht
        simp only [ForcingRankBranch.program,tokens_append]
        have he : tokens [(RankChoiceLift.row n hn g j r,RankChoiceLift.tape n hn g j r (D++ForcingRankBranch.prior n hn g r i b v)),
          (ForcingRankBranch.target n hn g j i b v,RankChoiceLift.liftTape n hn g j r i b v
            (D++ForcingRankBranch.prior n hn g r i b v++[RankChoiceLift.row n hn g j r]))]=22 := by
          simp [tokens,RankChoiceLift.tape,RankChoiceLift.liftTape,RankChoiceLift.lits,CommonGuardResolve.token_count]
        rw [he];omega

theorem node (n : Nat) (hn : 2≤n) (g x : Nat) (node : PriorityBank.Node)
    (i : Fin (AliasAssembly.width (n+1))) (b v : Bool) (D : List Row) :
    tokens (ForcingNodeValue.program n hn g x node i b v D)≤832*n+254 := by
  unfold ForcingNodeValue.program
  split
  · simp [tokens]
  · exact branch ..

def joinBound (n : Nat) := (832*n+256)*(36*(n+1)^2)+2

theorem join_tokens (n : Nat) (hn : 2≤n) (g x : Nat)
    (i : Fin (AliasAssembly.width (n+1))) (b v : Bool) (D : List Row) :
    tokens (ExhaustiveValueJoin.program n hn g x i b v D)≤joinBound n := by
  have h:=fold_tokens (fun node=>ForcingNodeValue.program n hn g x node i b v)
    (fun node=>ForcingNodeValue.rows n hn g x node i b v) (ForcingNodeSource.nodes n hn) D
    (832*n+254) (fun _ _ _=>node ..)
  have hc:=GlobalValueSize.nodes_count n hn
  have ht : (PortSelectorJoin.tape (D++ExhaustiveValueJoin.branchRows n hn g x i b v)
      (ExhaustiveValueJoin.target n hn g x i b v) (ForcingNodeSource.guards n hn)).length=
      2*(ForcingNodeSource.nodes n hn).length+2 := by
    simp [PortSelectorJoin.tape,CaseJoin.join_token_count,ForcingNodeSource.guards]
  change tokens (ExhaustiveValueJoin.branches n hn g x i b v D)≤_ at h
  rw [ExhaustiveValueJoin.program,tokens_append]
  change tokens (ExhaustiveValueJoin.branches n hn g x i b v D)+(_+0)≤_
  simp only [ht,Nat.add_zero]
  unfold joinBound
  have hh:=Nat.mul_le_mul_left (832*n+256) hc
  nlinarith

theorem step_tokens (n : Nat) (hn : 2≤n) (g : Nat) (D : List Row) :
    tokens (GlobalValueInduction.step n hn g D)≤
      (FamilyNamespace.truthRows n*AliasAssembly.width (n+1)*4)*joinBound n := by
  have h:=fold_tokens
    (fun j:FirstGateBase.Job n=>ExhaustiveValueJoin.program n hn g j.1 j.2.1 j.2.2.1 j.2.2.2)
    (fun j:FirstGateBase.Job n=>ExhaustiveValueJoin.rows n hn g j.1 j.2.1 j.2.2.1 j.2.2.2)
    (FirstGateBase.jobs n) D (joinBound n) (fun _ _ _=>join_tokens ..)
  simpa only [GlobalValueSize.jobs_count] using h

theorem run_tokens (n : Nat) (hn : 2≤n) (g m : Nat) (D : List Row) :
    tokens (GlobalValueInduction.run n hn g m D)≤
      m*((FamilyNamespace.truthRows n*AliasAssembly.width (n+1)*4)*joinBound n) := by
  induction m generalizing g D with
  | zero => simp [GlobalValueInduction.run,tokens]
  | succ m ih =>
    have hh:=step_tokens n hn g D
    have ht:=ih (g+1) (D++GlobalValueInduction.stepRows n hn g)
    simp only [GlobalValueInduction.run,tokens_append,Nat.succ_mul]
    omega

/-- Actual all-gate induction POL bank; units are POL TOKENS. Predecessor
banks, other lower rows, local certificates and bytes are separate. -/
theorem all_gate_tokens (n : Nat) (hn : 2≤n) :
    tokens (GlobalValueInduction.program n hn)≤
      (3*(n+1)-5)*((2^n*(4*n-4)*4)*((832*n+256)*(36*(n+1)^2)+2)) := by
  have h:=run_tokens n hn 1 (3*(n+1)-5) (FirstGateBase.result n hn)
  have hw : AliasAssembly.width (n+1)=4*n-4 := by unfold AliasAssembly.width RankConstruction.width;omega
  simpa only [GlobalValueInduction.program,joinBound,FamilyNamespace.truthRows,hw] using h

#print axioms branch
#print axioms join_tokens
#print axioms all_gate_tokens
end L3Emitter.GlobalMainTapeBounds

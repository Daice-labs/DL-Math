/-
The command language of frontend.py's `Proof` (definitions `OR/AND/EQ` and `rup` lines),
its execution into the exact-checker database, the theorem that any well-formed command
list is a checked trace modulo its `rup` obligations, and the transcription of
`make(F)` after the 2k-command prefix (lines 57–127 of frontend.py) as a Lean builder.

The builder keeps every definition well formed by construction (an input outside
`1..var` would be dropped by `chk`; the finite fidelity check shows that never happens
for k = 3..6, and the structural argument that it never happens for any k is the
remaining bookkeeping of this stage). The `rup` lines are collected as explicit
obligations `(database, clause)`; proving them is the content of obligation 2.
-/
import L3Gates

namespace L3
open EREF EREF.GeneralRED

/-! ### Commands -/

inductive Cmd where
  | orDef (q : Nat) (xs : List Int)
  | andDef (q : Nat) (xs : List Int)
  | eqDef (q : Nat) (a b : Int)
  | rup (c : List Int)
  deriving Repr, DecidableEq

/-- the clause row `c ≥ 1` -/
def clauseRow (c : List Int) : Row := { lits := c, rhs := 1 }

def Cmd.rows : Cmd → List EREF.Row
  | .orDef q xs => (orDefs xs).rows q
  | .andDef q xs => (andDefs xs).rows q
  | .eqDef q a b => (eqDefs a b).rows q
  | .rup c => [(clauseRow c).toE]

/-- the database after executing the commands -/
def exec (D : List EREF.Row) : List Cmd → List EREF.Row
  | [] => D
  | c :: cs => exec (D ++ c.rows) cs

/-- the variable counter after the commands -/
def varAfter (m : Nat) : List Cmd → Nat
  | [] => m
  | .rup _ :: cs => varAfter m cs
  | .orDef _ _ :: cs => varAfter (m + 1) cs
  | .andDef _ _ :: cs => varAfter (m + 1) cs
  | .eqDef _ _ _ :: cs => varAfter (m + 1) cs

/-- well-formedness: a definition takes the next fresh id and bounded inputs;
    a rup clause is bounded -/
def WF (m : Nat) : List Cmd → Prop
  | [] => True
  | .orDef q xs :: cs => q = m + 1 ∧ Bounded m xs ∧ WF (m + 1) cs
  | .andDef q xs :: cs => q = m + 1 ∧ Bounded m xs ∧ WF (m + 1) cs
  | .eqDef q a b :: cs => q = m + 1 ∧ Bounded m [a, b] ∧ WF (m + 1) cs
  | .rup c :: cs => Bounded m c ∧ WF m cs

/-- the rup obligations: (database at that moment, clause) -/
def obls (D : List EREF.Row) : List Cmd → List (List EREF.Row × List Int)
  | [] => []
  | .rup c :: cs => (D, c) :: obls (D ++ [(clauseRow c).toE]) cs
  | c :: cs => obls (D ++ c.rows) cs

theorem clauseRow_bounded_nz (c : List Int) (m : Nat) (h : Bounded m c) : (clauseRow c).nz :=
  fun l hl => by have := (h l hl).1; unfold clauseRow at hl; omega

theorem exec_append (D : List EREF.Row) (cs cs' : List Cmd) :
    exec D (cs ++ cs') = exec (exec D cs) cs' := by
  induction cs generalizing D with
  | nil => rfl
  | cons c cs ih => simp [exec, ih]

theorem varAfter_append (m : Nat) (cs cs' : List Cmd) :
    varAfter m (cs ++ cs') = varAfter (varAfter m cs) cs' := by
  induction cs generalizing m with
  | nil => rfl
  | cons c cs ih => cases c <;> simp [varAfter, ih]

theorem varAfter_mono (m : Nat) (cs : List Cmd) : m ≤ varAfter m cs := by
  induction cs generalizing m with
  | nil => exact Nat.le_refl _
  | cons c cs ih => cases c <;> simp only [varAfter] <;> (have := ih (m + 1); have := ih m; omega)

theorem WF_append (m : Nat) (cs cs' : List Cmd) (h : WF m cs) (h' : WF (varAfter m cs) cs') :
    WF m (cs ++ cs') := by
  induction cs generalizing m with
  | nil => exact h'
  | cons c cs ih =>
    cases c with
    | orDef q xs => exact ⟨h.1, h.2.1, ih (m + 1) h.2.2 h'⟩
    | andDef q xs => exact ⟨h.1, h.2.1, ih (m + 1) h.2.2 h'⟩
    | eqDef q a b => exact ⟨h.1, h.2.1, ih (m + 1) h.2.2 h'⟩
    | rup c => exact ⟨h.1, ih m h.2 h'⟩

theorem obls_append (D : List EREF.Row) (cs cs' : List Cmd) :
    obls D (cs ++ cs') = obls D cs ++ obls (exec D cs) cs' := by
  induction cs generalizing D with
  | nil => rfl
  | cons c cs ih => cases c <;> simp [obls, exec, Cmd.rows, ih]

/-- executing bounded commands keeps the database bounded by the final counter -/
theorem exec_bounded (D : List EREF.Row) (m : Nat) (cs : List Cmd) (hD : DBBounded D m) (hwf : WF m cs) :
    DBBounded (exec D cs) (varAfter m cs) := by
  induction cs generalizing D m with
  | nil => exact hD
  | cons c cs ih =>
    cases c with
    | orDef q xs =>
      obtain ⟨rfl, hxs, hwf⟩ := hwf
      apply ih _ _ _ hwf
      apply DBBounded_defs D m (m + 1) rfl hD
      intro p hp l hl
      unfold orDefs at hp
      simp only [List.mem_append, List.mem_map, List.mem_singleton] at hp
      rcases hp with ⟨x, hx, rfl⟩ | rfl
      · simp at hl; subst hl; simpa [Int.natAbs_neg] using hxs x hx
      · exact hxs l hl
    | andDef q xs =>
      obtain ⟨rfl, hxs, hwf⟩ := hwf
      apply ih _ _ _ hwf
      apply DBBounded_defs D m (m + 1) rfl hD
      intro p hp l hl
      unfold andDefs at hp
      simp only [List.mem_append, List.mem_map, List.mem_singleton] at hp
      rcases hp with ⟨x, hx, rfl⟩ | rfl
      · simp at hl; rw [hl]; exact hxs x hx
      · exact hxs.neg l hl
    | eqDef q a b =>
      obtain ⟨rfl, hab, hwf⟩ := hwf
      apply ih _ _ _ hwf
      apply DBBounded_defs D m (m + 1) rfl hD
      intro p hp l hl
      unfold eqDefs at hp
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hp
      have ha := hab a (by simp); have hb := hab b (by simp)
      rcases hp with rfl | rfl | rfl | rfl <;> simp only [List.mem_cons, List.not_mem_nil, or_false] at hl <;>
        rcases hl with rfl | rfl <;> (try simp only [Int.natAbs_neg]) <;> omega
    | rup c =>
      obtain ⟨hc, hwf⟩ := hwf
      exact ih _ _ (hD.append _ hc) hwf

/-- **execution is a checked trace** given the rup obligations -/
theorem exec_trace (D : List EREF.Row) (m : Nat) (cs : List Cmd) (hD : DBBounded D m) (hwf : WF m cs)
    (hobl : ∀ o ∈ obls D cs, Refutation (o.1 ++ [negate (clauseRow o.2).toE])) :
    CheckedTrace D (exec D cs) := by
  induction cs generalizing D m with
  | nil => exact CheckedTrace.refl _
  | cons c cs ih =>
    cases c with
    | orDef q xs =>
      obtain ⟨rfl, hxs, hwf⟩ := hwf
      have h1 := or_trace D m hD xs hxs
      have hD' := exec_bounded D m [.orDef (m + 1) xs] hD ⟨rfl, hxs, trivial⟩
      simp only [exec, Cmd.rows, varAfter] at hD'
      exact Fam.checkedTrace_trans h1 (ih _ _ hD' hwf (by simpa [obls] using hobl))
    | andDef q xs =>
      obtain ⟨rfl, hxs, hwf⟩ := hwf
      have h1 := and_trace D m hD xs hxs
      have hD' := exec_bounded D m [.andDef (m + 1) xs] hD ⟨rfl, hxs, trivial⟩
      simp only [exec, Cmd.rows, varAfter] at hD'
      exact Fam.checkedTrace_trans h1 (ih _ _ hD' hwf (by simpa [obls] using hobl))
    | eqDef q a b =>
      obtain ⟨rfl, hab, hwf⟩ := hwf
      have h1 := eq_trace D m hD a b (hab a (by simp)) (hab b (by simp))
      have hD' := exec_bounded D m [.eqDef (m + 1) a b] hD ⟨rfl, hab, trivial⟩
      simp only [exec, Cmd.rows, varAfter] at hD'
      exact Fam.checkedTrace_trans h1 (ih _ _ hD' hwf (by simpa [obls] using hobl))
    | rup c =>
      obtain ⟨hc, hwf⟩ := hwf
      have hob := hobl (D, c) (by simp [obls])
      have step : CheckedStep D (D ++ [(clauseRow c).toE]) :=
        CheckedStep.consequence D _ (canonical_toE _) hob
      refine CheckedTrace.cons step (ih _ _ (hD.append _ hc) hwf ?_)
      intro o ho; exact hobl o (by simp [obls, ho])

/-! ### The builder (frontend.py `Proof`) -/

structure St where
  cmds : List Cmd
  var : Nat
  live : Nat → Nat
  edges : Nat → Nat → Nat → Nat
  eqrow : Nat → Nat → Nat → Nat
  force : Nat → Nat → Nat
  p0force : Nat → Nat → Nat
  eligible : Nat → Nat
  veq : Nat → Nat → Nat
  branches : Nat → Nat → Nat
  A : Nat
  Bv : Nat

namespace St

def init (m0 : Nat) : St :=
  { cmds := [], var := m0, live := fun _ => 0, edges := fun _ _ _ => 0, eqrow := fun _ _ _ => 0,
    force := fun _ _ => 0, p0force := fun _ _ => 0, eligible := fun _ => 0, veq := fun _ _ => 0,
    branches := fun _ _ => 0, A := 0, Bv := 0 }

/-- inputs are kept only when in `1..var` (never triggers for the transcribed frontend; see
    the fidelity check) -/
def chk (s : St) (xs : List Int) : List Int := xs.filter fun l => decide (1 ≤ l.natAbs ∧ l.natAbs ≤ s.var)
def chk1 (s : St) (a : Int) : Int := if 1 ≤ a.natAbs ∧ a.natAbs ≤ s.var then a else 1

def OR (s : St) (xs : List Int) : Nat × St :=
  (s.var + 1, { s with cmds := s.cmds ++ [.orDef (s.var + 1) (s.chk xs)], var := s.var + 1 })
def AND (s : St) (xs : List Int) : Nat × St :=
  (s.var + 1, { s with cmds := s.cmds ++ [.andDef (s.var + 1) (s.chk xs)], var := s.var + 1 })
def EQ (s : St) (a b : Int) : Nat × St :=
  (s.var + 1, { s with cmds := s.cmds ++ [.eqDef (s.var + 1) (s.chk1 a) (s.chk1 b)], var := s.var + 1 })
def rup (s : St) (c : List Int) : St := { s with cmds := s.cmds ++ [.rup (s.chk c)] }
def split (s : St) (c : List Int) : List Int → St
  | [] => s.rup c
  | v :: vs => ((s.split (c ++ [v]) vs).split (c ++ [-v]) vs).rup c

/-- the builder invariant -/
def Inv (m0 : Nat) (s : St) : Prop := WF m0 s.cmds ∧ varAfter m0 s.cmds = s.var

theorem chk_bounded (s : St) (xs : List Int) : Bounded s.var (s.chk xs) := by
  intro l hl
  unfold chk at hl
  have := (List.mem_filter.mp hl).2
  simpa using this

theorem chk1_bounded (s : St) (a : Int) (h1 : 1 ≤ s.var) : 1 ≤ (s.chk1 a).natAbs ∧ (s.chk1 a).natAbs ≤ s.var := by
  unfold chk1; split
  · assumption
  · simp; omega

theorem inv_init (m0 : Nat) : Inv m0 (init m0) := ⟨trivial, rfl⟩

theorem inv_OR {m0 : Nat} {s : St} (h : Inv m0 s) (xs : List Int) : Inv m0 (s.OR xs).2 := by
  refine ⟨?_, ?_⟩
  · exact WF_append _ _ _ h.1 (by rw [h.2]; exact ⟨rfl, s.chk_bounded xs, trivial⟩)
  · simp [OR, varAfter_append, h.2, varAfter]

theorem inv_AND {m0 : Nat} {s : St} (h : Inv m0 s) (xs : List Int) : Inv m0 (s.AND xs).2 := by
  refine ⟨?_, ?_⟩
  · exact WF_append _ _ _ h.1 (by rw [h.2]; exact ⟨rfl, s.chk_bounded xs, trivial⟩)
  · simp [AND, varAfter_append, h.2, varAfter]

theorem inv_EQ {m0 : Nat} {s : St} (h : Inv m0 s) (hm : 1 ≤ m0) (a b : Int) : Inv m0 (s.EQ a b).2 := by
  have hv : 1 ≤ s.var := by have := varAfter_mono m0 s.cmds; rw [h.2] at this; omega
  refine ⟨?_, ?_⟩
  · apply WF_append _ _ _ h.1
    rw [h.2]
    refine ⟨rfl, ?_, trivial⟩
    intro l hl
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
    rcases hl with rfl | rfl <;> exact s.chk1_bounded _ hv
  · simp [EQ, varAfter_append, h.2, varAfter]

theorem inv_rup {m0 : Nat} {s : St} (h : Inv m0 s) (c : List Int) : Inv m0 (s.rup c) := by
  refine ⟨?_, ?_⟩
  · exact WF_append _ _ _ h.1 (by rw [h.2]; exact ⟨s.chk_bounded c, trivial⟩)
  · simp [rup, varAfter_append, h.2, varAfter]

theorem inv_split {m0 : Nat} (vs : List Int) : ∀ (s : St) (c : List Int), Inv m0 s → Inv m0 (s.split c vs) := by
  induction vs with
  | nil => intro s c h; exact inv_rup h c
  | cons v vs ih => intro s c h; exact inv_rup (ih _ _ (ih _ _ h)) c

end St

/-! ### The invariant-carrying builder -/

/-- a builder state together with its invariant; every operation preserves it by typing -/
structure StI (m0 : Nat) where
  s : St
  inv : St.Inv m0 s

namespace StI
variable {m0 : Nat}

def init (m0 : Nat) : StI m0 := ⟨St.init m0, St.inv_init m0⟩
def OR (t : StI m0) (xs : List Int) : Nat × StI m0 := ((t.s.OR xs).1, ⟨(t.s.OR xs).2, St.inv_OR t.inv xs⟩)
def AND (t : StI m0) (xs : List Int) : Nat × StI m0 := ((t.s.AND xs).1, ⟨(t.s.AND xs).2, St.inv_AND t.inv xs⟩)
def EQ (t : StI m0) (hm : 1 ≤ m0) (a b : Int) : Nat × StI m0 :=
  ((t.s.EQ a b).1, ⟨(t.s.EQ a b).2, St.inv_EQ t.inv hm a b⟩)
def rup (t : StI m0) (c : List Int) : StI m0 := ⟨t.s.rup c, St.inv_rup t.inv c⟩
def split (t : StI m0) (c : List Int) (vs : List Int) : StI m0 := ⟨t.s.split c vs, St.inv_split vs t.s c t.inv⟩
/-- update the name maps (cmds and var unchanged, so the invariant is untouched) -/
def setLive (t : StI m0) (f : Nat → Nat) : StI m0 := ⟨{ t.s with live := f }, t.inv⟩
def setEdges (t : StI m0) (f : Nat → Nat → Nat → Nat) : StI m0 := ⟨{ t.s with edges := f }, t.inv⟩
def setEqrow (t : StI m0) (f : Nat → Nat → Nat → Nat) : StI m0 := ⟨{ t.s with eqrow := f }, t.inv⟩
def setForce (t : StI m0) (f : Nat → Nat → Nat) : StI m0 := ⟨{ t.s with force := f }, t.inv⟩
def setP0force (t : StI m0) (f : Nat → Nat → Nat) : StI m0 := ⟨{ t.s with p0force := f }, t.inv⟩
def setEligible (t : StI m0) (f : Nat → Nat) : StI m0 := ⟨{ t.s with eligible := f }, t.inv⟩
def setVeq (t : StI m0) (f : Nat → Nat → Nat) : StI m0 := ⟨{ t.s with veq := f }, t.inv⟩
def setBranches (t : StI m0) (f : Nat → Nat → Nat) : StI m0 := ⟨{ t.s with branches := f }, t.inv⟩
def setA (t : StI m0) (a : Nat) : StI m0 := ⟨{ t.s with A := a }, t.inv⟩
def setB (t : StI m0) (b : Nat) : StI m0 := ⟨{ t.s with Bv := b }, t.inv⟩

end StI

/-! ### make(F) after the prefix (frontend.py lines 57–127) -/

namespace Fam

/-- the frontend needs V ≥ 1 for the EQ fallback; V ≥ 1 whenever s ≥ 1 -/
theorem V_pos (F : Fam) (hs : 1 ≤ F.s) : 1 ≤ F.V := by unfold V; omega

def frontend (F : Fam) (hs : 1 ≤ F.s) : StI F.V := Id.run do
  let hm : 1 ≤ F.V := F.V_pos hs
  let mut s := StI.init F.V
  -- line 57: live[s-1] = OR([]) ; rup([-live[s-1]]) ; live[s-1] = AND([])
  let (q0, s0) := s.OR []; s := s0
  s := s.rup [-(q0 : Int)]
  let (qL, s1) := s.AND []; s := s1
  s := s.setLive fun g => if g = F.s - 1 then qL else s.s.live g
  -- lines 59–65: edges and live, g = s-2 down to 0
  for g in (List.range (F.s - 1)).reverse do
    let mut terms : List Int := []
    for h in List.range' (g + 1) (F.s - 1 - g) do
      for port in [0, 1] do
        let (e, s') := s.AND [(s.s.live h : Int), (F.sel h port (F.k + g) : Int)]
        s := s'.setEdges fun g' h' p' => if g' = g ∧ h' = h ∧ p' = port then e else s'.s.edges g' h' p'
        terms := terms ++ [(e : Int)]
    let (l, s') := s.OR terms
    s := s'.setLive fun g' => if g' = g then l else s'.s.live g'
  -- lines 66–77: eqrow, force, p0force, consumer, eligible for g = 1..s-1
  for g in List.range' 1 (F.s - 1) do
    let mut ports : List Int := []
    for port in [0, 1] do
      let mut eqs : List Int := []
      for b in [0, 1] do
        let (a, d) := if port = 0 then (2 * b, 2 * b + 1) else (b, b + 2)
        let (e, s') := s.EQ hm (F.fn g a : Int) (F.fn g d : Int)
        s := s'.setEqrow fun g' p' b' => if g' = g ∧ p' = port ∧ b' = b then e else s'.s.eqrow g' p' b'
        eqs := eqs ++ [(e : Int)]
      let (f, s') := s.OR eqs
      s := s'.setForce fun g' p' => if g' = g ∧ p' = port then f else s'.s.force g' p'
      let (pf, s'') := s.AND [(F.sel g port 0 : Int), (f : Int)]
      s := s''.setP0force fun g' p' => if g' = g ∧ p' = port then pf else s''.s.p0force g' p'
      ports := ports ++ [(pf : Int)]
    let (cons, s') := s.OR ports; s := s'
    let (el, s'') := s.AND [(s.s.live g : Int), (cons : Int)]
    s := s''.setEligible fun g' => if g' = g then el else s''.s.eligible g'
  -- line 78: A = OR(eligible[1..s-1])
  let (a, sA) := s.OR ((List.range' 1 (F.s - 1)).map fun g => (s.s.eligible g : Int))
  s := sA.setA a
  -- lines 81–87: non-forcing ports are ignored
  for g in List.range' 1 (F.s - 1) do
    for port in [0, 1] do
      let f := (s.s.force g port : Int)
      let pairs : List (Nat × Nat) := if port = 0 then [(0, 2), (1, 3)] else [(0, 1), (2, 3)]
      for (a, b) in pairs do
        s := s.rup [f, -(F.fn g a : Int), (F.fn g b : Int)]
        s := s.rup [f, (F.fn g a : Int), -(F.fn g b : Int)]
  -- lines 89–108: x0 = 0 vs x0 = 1 at each value of x1
  let mut C : List Int := []
  for bit in [0, 1] do
    let x := (F.T / 4) * bit
    let y := x + F.T / 2
    let (cb, s') := s.EQ hm (F.fn 0 bit : Int) (F.fn 0 (bit + 2) : Int); s := s'
    C := C ++ [(cb : Int)]
    for g in List.range F.s do
      let (v, s') := s.EQ hm (F.val g x : Int) (F.val g y : Int)
      s := s'.setVeq fun g' b' => if g' = g ∧ b' = bit then v else s'.s.veq g' b'
      if g = 0 then
        s := s.split [-(cb : Int), (v : Int)] [(F.val g x : Int)]
      else
        let guard : List Int := [(s.s.A : Int), -(cb : Int), -(s.s.live g : Int)]
        for port in [0, 1] do
          let (q, s') := s.EQ hm (F.port g port x : Int) (F.port g port y : Int); s := s'
          for j in List.range' 1 (F.k + g - 1) do
            s := s.split (guard ++ [-(F.sel g port j : Int), (q : Int)]) [(F.port g port x : Int)]
          s := s.rup (guard ++ [(F.sel g port 0 : Int), (q : Int)])
          s := s.rup [(s.s.A : Int), -(s.s.live g : Int), -(F.sel g port 0 : Int), -(s.s.force g port : Int)]
        s := s.split (guard ++ [(v : Int)])
          [(F.port g 0 x : Int), (F.port g 0 y : Int), (F.port g 1 x : Int), (F.port g 1 y : Int), (F.val g x : Int)]
    s := s.rup [(s.s.A : Int), -(cb : Int)]
  s := s.split C [(F.fn 0 0 : Int), (F.fn 0 1 : Int)]
  s := s.rup [(s.s.A : Int)]
  -- lines 111–119: the output gate is not eligible
  for port in [0, 1] do
    for b in [0, 1] do
      let x := (F.T / 2) * b
      let y := x + F.T / 4
      s := s.split [-(F.sel (F.s - 1) port 0 : Int), -(s.s.eqrow (F.s - 1) port b : Int)]
        [(F.port (F.s - 1) (1 - port) x : Int), (F.port (F.s - 1) (1 - port) y : Int)]
  for port in [0, 1] do
    s := s.rup [-(F.sel (F.s - 1) port 0 : Int), -(s.s.force (F.s - 1) port : Int)]
    s := s.rup [-(s.s.p0force (F.s - 1) port : Int)]
  s := s.rup [-(s.s.eligible (F.s - 1) : Int)]
  -- lines 120–127: three-gate reductions
  let mut brs : List Int := []
  for b in List.range' 1 (F.s - 2) do
    for g in List.range' (b + 1) (F.s - 1 - b) do
      let (succ, s') := s.OR [(s.s.edges b g 0 : Int), (s.s.edges b g 1 : Int)]; s := s'
      let (br, s'') := s.AND [(s.s.eligible b : Int), (succ : Int)]
      s := s''.setBranches fun b' g' => if b' = b ∧ g' = g then br else s''.s.branches b' g'
      brs := brs ++ [(br : Int)]
  let (bB, sB) := s.OR brs
  s := sB.setB bB
  for b in List.range' 1 (F.s - 2) do
    s := s.rup [(s.s.Bv : Int), -(s.s.eligible b : Int)]
  s := s.rup [(s.s.Bv : Int)]
  return s

/-- the frontend's command list and its invariant, for free -/
theorem frontend_inv (F : Fam) (hs : 1 ≤ F.s) : St.Inv F.V (F.frontend hs).s := (F.frontend hs).inv

/-- `db5` (the database after the 2k prefix commands) is bounded by V -/
theorem row2_0_bounded (F : Fam) (hs : 1 ≤ F.s) (c : Nat) :
    ∀ l ∈ (F.row2 0 c).lits, 1 ≤ l.natAbs ∧ l.natAbs ≤ F.V := by
  intro l hl
  rw [row2_lits] at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  have h0 := F.fn_range 0 0 hs (by omega); have h1 := F.fn_range 0 1 hs (by omega)
  have h2 := F.fn_range 0 2 hs (by omega); have h3 := F.fn_range 0 3 hs (by omega)
  have hV := F.S4_le_V
  rcases hl with rfl | rfl | rfl | rfl <;> split <;> simp only [natAbs_pos, natAbs_neg] <;> omega

theorem db5_bounded (F : Fam) (hk : 1 ≤ F.k) (hs : 1 ≤ F.s) : DBBounded F.db5 F.V := by
  intro R hR
  unfold db5 db4 db3 at hR
  simp only [List.mem_append, List.mem_singleton] at hR
  rcases hR with ((hR | rfl) | rfl) | rfl
  · unfold db2 at hR
    simp only [List.mem_append, List.mem_map, List.mem_range'_1] at hR
    rcases hR with (⟨r, hr, rfl⟩ | ⟨j, hj, rfl⟩) | ⟨j, hj, rfl⟩
    · exact ⟨r, rfl, F.rows_wf hs r hr⟩
    · refine ⟨_, rfl, ?_⟩
      intro l hl; simp [unitNegSel] at hl; subst hl
      rw [natAbs_neg]; exact ⟨F.sel_pos _ _ _, Nat.le_trans (F.sel_le_S 0 0 j hs (by omega) (by omega)) F.S_le_V⟩
    · refine ⟨_, rfl, ?_⟩
      intro l hl; simp [unitNegSel] at hl; subst hl
      rw [natAbs_neg]; exact ⟨F.sel_pos _ _ _, Nat.le_trans (F.sel_le_S 0 1 j hs (by omega) (by omega)) F.S_le_V⟩
  · refine ⟨_, rfl, ?_⟩
    intro l hl; simp [unitNegSel] at hl; subst hl
    rw [natAbs_neg]; exact ⟨F.sel_pos _ _ _, Nat.le_trans (F.sel_le_S 0 1 0 hs (by omega) (by omega)) F.S_le_V⟩
  · exact ⟨_, rfl, F.row2_0_bounded hs 3⟩
  · exact ⟨_, rfl, F.row2_0_bounded hs 12⟩

/-- **the frontend is a checked trace modulo its rup obligations**, for every k, s ≥ 1 -/
theorem frontend_trace (F : Fam) (hk : 1 ≤ F.k) (hs : 1 ≤ F.s)
    (hobl : ∀ o ∈ obls F.db5 (F.frontend hs).s.cmds, Refutation (o.1 ++ [negate (clauseRow o.2).toE])) :
    CheckedTrace F.db5 (exec F.db5 (F.frontend hs).s.cmds) :=
  exec_trace F.db5 F.V _ (F.db5_bounded hk hs) (F.frontend_inv hs).1 hobl

end Fam
end L3

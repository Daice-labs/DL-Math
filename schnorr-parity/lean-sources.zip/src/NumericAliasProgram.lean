import NumericAliasExternal
namespace L3Emitter.NumericNetwork
open EREF EREF.GeneralRED AliasNetwork RecursiveAliases AliasAssembly
variable {base:List Row}

theorem input_bound (M w G:Nat) (c:Config Bit) (hc:ConfigBound M G w c):
    SourceBound M (inputAliases w c):=by
  intro j i
  unfold inputAliases
  split_ifs <;> first | exact hc.T | exact hc.F | exact hc.B

def aliasGrowth (k:Nat):Nat:=contextCost k+(3*k-4)*((width k+2)*(2*(k+(3*k-4))+25))

theorem program (M k:Nat) (hk:3≤k) (he:externalCeiling k≤M)
    (z:Net base) (hz:CanonicalTrace.ceiling z.rows≤M):
    ConfigBound (M+aliasGrowth k) (3*k-4) (width k) (AliasAssembly.program k hk z).1.1 ∧
    SourceBound (M+aliasGrowth k) (AliasAssembly.program k hk z).1.2 ∧
    CanonicalTrace.ceiling (AliasAssembly.program k hk z).2.rows≤M+aliasGrowth k:=by
  let c:=AliasAssembly.context k hk z
  have h:=context M k hk (external_mono he (external_bound k hk)) z hz
  have hrun:=run (M+contextCost k) (3*k-4) (width k) c.1 0 (3*k-4) (by omega)
    h.1 (inputAliases (width k) c.1) (input_bound _ _ _ c.1 h.1) c.2 h.2
  have hc:c.1.k=k:=rfl
  rw [hc] at hrun
  simp only [Nat.add_zero] at hrun
  have heq:M+contextCost k+(3*k-4)*((width k+2)*(2*(k+(3*k-4))+25))=M+aliasGrowth k:=by unfold aliasGrowth;omega
  rw [heq] at hrun
  exact ⟨config_mono (by unfold aliasGrowth;omega) h.1,hrun⟩

theorem alias_growth_bound (k:Nat):aliasGrowth k≤1000*(k+1)^3:=by
  have hs:3*k-4≤3*(k+1):=by omega
  have hw:width k+2≤6*(k+1):=by unfold width RankConstruction.width;omega
  have hi:2*(k+(3*k-4))+25≤33*(k+1):=by omega
  have hbody:(3*k-4)*((width k+2)*(2*(k+(3*k-4))+25))≤594*(k+1)^3:=by
    have h:=Nat.mul_le_mul hs (Nat.mul_le_mul hw hi)
    nlinarith
  have hsq:(3*k-4)*(3*k-4)≤9*(k+1)^2:=by nlinarith [Nat.mul_le_mul hs hs]
  have hctx:contextCost k≤20*(k+1)^2:=by unfold contextCost;nlinarith
  have hpow:(k+1)^2≤(k+1)^3:=by nlinarith [Nat.le_mul_of_pos_right ((k+1)^2) (show 0<k+1 by omega)]
  unfold aliasGrowth;omega

/-- The actual alias allocator has a closed polynomial increment over the
incoming row-store ceiling. No external-input bound remains as a premise. -/
theorem actual_program (k:Nat) (hk:3≤k) (z:Net base):
    ConfigBound (CanonicalTrace.ceiling z.rows+externalCeiling k+1000*(k+1)^3)
      (3*k-4) (width k) (AliasAssembly.program k hk z).1.1 ∧
    SourceBound (CanonicalTrace.ceiling z.rows+externalCeiling k+1000*(k+1)^3)
      (AliasAssembly.program k hk z).1.2 ∧
    CanonicalTrace.ceiling (AliasAssembly.program k hk z).2.rows≤
      CanonicalTrace.ceiling z.rows+externalCeiling k+1000*(k+1)^3:=by
  have h:=program (CanonicalTrace.ceiling z.rows+externalCeiling k) k hk (by omega) z (by omega)
  have hg:=alias_growth_bound k
  exact ⟨config_mono (by omega) h.1,source_mono (by omega) _ h.2.1,h.2.2.trans (by omega)⟩

#print axioms program
#print axioms alias_growth_bound
#print axioms actual_program
end L3Emitter.NumericNetwork

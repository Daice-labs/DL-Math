import RestrictionBit

namespace L3Emitter.DefinitionBank
open EREF EREF.GeneralRED

def cmds (m a : Nat) (f : Nat→List Int) : Nat→List L3.Cmd
  | 0 => []
  | n+1 => .orDef (m+1) (f a)::cmds (m+1) (a+1) f n

theorem member (m a n i : Nat) (f : Nat→List Int) (hi : i<n) :
    L3.Cmd.orDef (m+1+i) (f (a+i))∈cmds m a f n := by
  induction n generalizing m a i with
  | zero => omega
  | succ n ih =>
    cases i with
    | zero => simp [cmds]
    | succ i =>
      have h:=ih (m+1) (a+1) i (by omega)
      apply List.mem_cons_of_mem
      simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using h

theorem wf (m a n : Nat) (f : Nat→List Int)
    (hf : ∀i,i<n→L3.Bounded m (f (a+i))) : L3.WF m (cmds m a f n) := by
  induction n generalizing m a with
  | zero => trivial
  | succ n ih =>
    refine ⟨rfl,by simpa using hf 0 (by omega),?_⟩
    apply ih (m+1) (a+1)
    intro i hi l hl
    have h:=hf (i+1) (by omega) l (by simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hl)
    exact ⟨h.1,by omega⟩

theorem varAfter (m a n : Nat) (f : Nat→List Int) :
    L3.varAfter m (cmds m a f n)=m+n := by
  induction n generalizing m a with
  | zero => rfl
  | succ n ih => simp only [cmds,L3.varAfter,ih];omega

theorem obls (D : List Row) (m a n : Nat) (f : Nat→List Int) :
    L3.obls D (cmds m a f n)=[] := by
  induction n generalizing D m a with
  | zero => rfl
  | succ n ih => simp only [cmds,L3.obls];exact ih _ _ _

theorem checked (D : List Row) (m a n : Nat) (f : Nat→List Int)
    (hD : L3.DBBounded D m) (hf : ∀i,i<n→L3.Bounded m (f (a+i))) :
    CheckedTrace D (L3.exec D (cmds m a f n)) ∧
      L3.DBBounded (L3.exec D (cmds m a f n)) (m+n) := by
  have hw:=wf m a n f hf
  constructor
  · apply L3.exec_trace D m _ hD hw
    simp [obls]
  · rw [←varAfter m a n f]
    exact L3.exec_bounded D m _ hD hw

theorem retains (D : List Row) (m a n : Nat) (f : Nat→List Int) (R : Row) (h : R∈D) :
    R∈L3.exec D (cmds m a f n) := by
  induction n generalizing D m a with
  | zero => exact h
  | succ n ih => exact ih _ _ _ (List.mem_append_left _ h)

#print axioms checked
end L3Emitter.DefinitionBank

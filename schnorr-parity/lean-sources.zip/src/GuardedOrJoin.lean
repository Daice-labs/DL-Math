import SelectedCategoryRows
namespace L3Emitter.GuardedOrJoin
open EREF EREF.GeneralRED REDWitness ReferenceTransport LocalCombination ClauseTransport CaseJoin

def rows (c e:Int) (xs:List Int):List Row:=xs.map fun x=>clause [-c,-x,e]
def pad (h:Int) (xs:List Int):List Int:=List.replicate (xs.length-1) (-h)
def combined (c e h:Int) (xs:List Int):Row:=chain (chain (clause (-h::xs)) (rows c e xs)) ((pad h xs).map litAxiom)

theorem rows_value (c e:Int) (xs:List Int) (hc:c≠0) (he:e≠0) (hx:Valid xs) (α:Val):
    ((rows c e xs).map (fun R=>R.val α)).sum = xs.length*(litVal α (-c)+litVal α e)-sum α xs:=by
  induction xs with
  | nil=>simp [rows]
  | cons x xs ih=>
    have hz:=hx x (by simp)
    have ht:=ih (by intro l hl;exact hx l (by simp [hl]))
    simp only [rows,List.map_cons,List.sum_cons,List.length_cons,Nat.cast_add,Nat.cast_one]
    rw [val_clause _ (by simp [Valid,hc,he,hz])]
    change _+((rows c e xs).map (fun R=>R.val α)).sum=_
    rw [ht]
    simp only [sum_cons,sum_nil,litVal_neg α x hz]
    ring

theorem scaled_sum (c e h:Int) (xs:List Int) (hc:c≠0) (he:e≠0) (hh:h≠0)
    (hx:Valid xs) (hn:xs≠[]):combined c e h xs=scaled xs.length (clause [-c,-h,e]):=by
  have hm:0<xs.length:=List.length_pos_iff.mpr hn
  have hp:Valid (pad h xs):=by intro l hl;have := (List.mem_replicate.mp hl).2;subst l;exact neg_ne_zero.mpr hh
  apply canonical_ext _ _ (chain_canonical _ _ (chain_canonical _ _ (canonical_normalize _ _)))
    (canonical_scaled _ hm _ (canonical_normalize _ _))
  intro α
  change (combined c e h xs).val α=(scaled xs.length (clause [-c,-h,e])).val α
  rw [combined,chain_value (chain (clause (-h::xs)) (rows c e xs)) ((pad h xs).map litAxiom) (chain_canonical _ _ (canonical_normalize _ _))
    (by intro R hr;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hr;exact canonical_litAxiom _),
    chain_value (clause (-h::xs)) (rows c e xs) (canonical_normalize _ _)
    (by intro R hr;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hr;exact canonical_normalize _ _),
    ChoiceProjection.literal_sum _ hp,rows_value c e xs hc he hx,
    val_clause (-h::xs) (by intro l hl;rcases List.mem_cons.mp hl with rfl|hl;exact neg_ne_zero.mpr hh;exact hx l hl),val_scaled,
    val_clause [-c,-h,e] (by simp [Valid,hc,he,hh])]
  have hv:sum α (pad h xs)=(xs.length-1:Nat)*litVal α (-h):=by simp [pad,sum,List.map_replicate,List.sum_replicate]
  rw [hv]
  have hn':((xs.length-1:Nat):Int)=(xs.length:Int)-1:=by omega
  simp only [sum_cons,sum_nil]
  rw [hn'];ring

def tape (D:List Row) (c e h:Int) (xs:List Int):List Tok:=
  [.ref (locate D (clause (-h::xs)))]++steps D (rows c e xs)++padSteps (pad h xs)++[.div xs.length]

theorem checks (D:List Row) (c e h:Int) (xs:List Int) (hc:c≠0) (he:e≠0) (hh:h≠0)
    (hx:Valid xs) (hn:xs≠[]) (hor:clause (-h::xs)∈D)
    (hr:∀x∈xs,clause [-c,-x,e]∈D):
    polEval (dbOf D) (tape D c e h xs) []=some (clause [-c,-h,e]):=by
  have hp:Valid (pad h xs):=by intro l hl;have := (List.mem_replicate.mp hl).2;subst l;exact neg_ne_zero.mpr hh
  simp only [tape,List.append_assoc,List.cons_append,List.nil_append,polEval,locate_correct D _ hor]
  rw [steps_eval _ _ (by intro R hR;obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hR;exact hr x hx),padSteps_eval _ _ hp]
  simp only [polEval,if_pos (List.length_pos_iff.mpr hn)]
  change some (divide (combined c e h xs) xs.length)=_
  rw [scaled_sum c e h xs hc he hh hx hn,divide_scaled xs.length (List.length_pos_iff.mpr hn) (clause [-c,-h,e]) (canonical_normalize _ _)]

theorem token_count (D:List Row) (c e h:Int) (xs:List Int) (hn:xs≠[]):
    (tape D c e h xs).length=4*xs.length:=by
  have hm:0<xs.length:=List.length_pos_iff.mpr hn
  simp [tape,steps,rows,padSteps,pad,List.length_flatMap,List.map_map,Function.comp_def]
  omega
#print axioms checks
end L3Emitter.GuardedOrJoin

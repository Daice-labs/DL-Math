import PortValueTransfer
namespace L3Emitter.EarlierPortValues
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL

def portValue (n:Nat) (hn:2≤n) (g p x:Nat):Bit:=
  ⟨(CofactorSemantics.low n (ConstantCofactor.offset n hn) g p x:Int),by
    have:=CofactorSemantics.low_pos n (ConstantCofactor.offset n hn) g p x;omega⟩
def wireAlias (n:Nat) (hn:2≤n) (h:Nat):=(AliasAssembly.built n hn).1.2 (n+1+h)
def portAlias (n:Nat) (hn:2≤n) (g p:Nat):=(RecordedGateSnapshots.portAt n hn g p).1.1

theorem unary_keep (n:Nat) (hn:2≤n):∀R∈UnaryValueBank.result n hn,R∈GammaComparisonBank.result n hn:=by
  intro R h
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ (GammaCofactorValue.keeps_unary n hn R h)))
theorem wire_keep (n:Nat) (hn:2≤n):∀R∈WireBank.result n hn,R∈GammaComparisonBank.result n hn:=by
  intro R h
  apply unary_keep n hn
  apply CofactorValueRows.raw_keep n hn
  apply RawValueBank.run_retains
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ h))

theorem aliases (n:Nat) (hn:2≤n) (g p h:Nat) (hg:g<3*(n+1)-4) (hp:p<2) (hh:h<g)
    (i:Fin (AliasAssembly.width (n+1)+2)):
    clause [-((PrimaryAliasBank.cfg n hn).sel g p (n+1+h)).val,-(wireAlias n hn h i).val,(portAlias n hn g p i).val]∈GammaComparisonBank.result n hn ∧
    clause [-((PrimaryAliasBank.cfg n hn).sel g p (n+1+h)).val,-(portAlias n hn g p i).val,(wireAlias n hn h i).val]∈GammaComparisonBank.result n hn:=by
  unfold wireAlias
  rw [UnaryPortTransport.earlier n hn g hg (n+1+h) (by omega)]
  have hr:=RecordedGateSnapshots.relations n hn g hg p hp (n+1+h) (by omega) i
  exact ⟨unary_keep n hn _ (UnaryPortTransport.category_keep n hn _ hr.1),
    unary_keep n hn _ (UnaryPortTransport.category_keep n hn _ hr.2)⟩

theorem cofactor_link (n:Nat) (hn:2≤n) (g p h x:Nat) (hg:g<3*(n+1)-4) (hp:p<2) (hh:h<g) (hx:x<FamilyNamespace.truthRows n) (v:Bool):
    clause [-((PrimaryAliasBank.cfg n hn).sel g p (n+1+h)).val,
      -sign v (CofactorValueRows.cofactor n hn h x),sign v (portValue n hn g p x)]∈GammaComparisonBank.result n hn:=by
  have hm:=WireBank.row_present n hn (g,p,h,x,v) ((WireBank.job_mem _ _ _).mpr ⟨hg,hp,hh,hx⟩)
  have he:WireBank.row n hn (g,p,h,x,v)=clause [-((PrimaryAliasBank.cfg n hn).sel g p (n+1+h)).val,
      -sign v (CofactorValueRows.cofactor n hn h x),sign v (portValue n hn g p x)]:=by
    cases v <;> simp only [WireBank.row,WireCofactor.goal,WireCofactor.selector,
      REDWitness.output,CofactorValueRows.cofactor,portValue,sign,Bool.not_false,Bool.not_true,
      Bool.false_eq_true,↓reduceIte,neg_neg]
    all_goals rfl
  exact he ▸ wire_keep n hn _ hm

def tape (n:Nat) (hn:2≤n) (g p h x:Nat) (i:Fin (AliasAssembly.width (n+1)+2)) (t:Bit) (b v:Bool) (D:List Row):=
  PortValueTransfer.tape D ((PrimaryAliasBank.cfg n hn).sel g p (n+1+h))
    (wireAlias n hn h) (portAlias n hn g p) i (UnarySnapshots.position (AliasAssembly.width (n+1)) b)
    t (CofactorValueRows.cofactor n hn h x) (portValue n hn g p x) b v

theorem checks (n:Nat) (hn:2≤n) (g p h x:Nat) (hg:g<3*(n+1)-4) (hp:p<2) (hh:h<g) (hx:x<FamilyNamespace.truthRows n)
    (i:Fin (AliasAssembly.width (n+1)+2)) (t:Bit) (b v:Bool) (D:List Row)
    (hd:∀R∈GammaComparisonBank.result n hn,R∈D)
    (hi:PortValueTransfer.invariant (wireAlias n hn h) i (UnarySnapshots.position (AliasAssembly.width (n+1)) b)
      t (CofactorValueRows.cofactor n hn h x) b v∈D):
    polEval (dbOf D) (tape n hn g p h x i t b v D) []=some
      (Resolution.branch (PortValueTransfer.invariant (portAlias n hn g p) i (UnarySnapshots.position (AliasAssembly.width (n+1)) b)
        t (portValue n hn g p x) b v) (-((PrimaryAliasBank.cfg n hn).sel g p (n+1+h)).val)):=by
  apply PortValueTransfer.checks _ _ _ _ _ _ _ _ _ _ _ hi
  · intro l;have hr:=aliases n hn g p h hg hp hh l;exact ⟨hd _ hr.1,hd _ hr.2⟩
  · exact hd _ (cofactor_link n hn g p h x hg hp hh hx v)
#print axioms aliases
#print axioms cofactor_link
#print axioms checks
end L3Emitter.EarlierPortValues

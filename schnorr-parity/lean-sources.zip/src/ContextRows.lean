import FirstGateSource

namespace L3Emitter.ContextRows
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases
variable {base:List Row} {A:Type}

def OrRows (D:List Row) (xs:List Bit) (q:Bit) :=
  (∀x∈xs,clause [-x.val,q.val]∈D) ∧ clause (-q.val::xs.map Subtype.val)∈D

theorem OrRows.mono {D E:List Row} {xs:List Bit} {q:Bit} (h:OrRows D xs q)
    (hm:∀R∈D,R∈E) : OrRows E xs q := ⟨fun x hx=>hm _ (h.1 x hx),hm _ h.2⟩

theorem actual_or (xs:List Bit) (z:Net base) : OrRows (OR xs z).2.rows xs (OR xs z).1 := by
  constructor
  · exact ConcreteGateRows.or_up z xs
  · have h:=ConcreteGateRows.or_down z xs
    rw [FrontendSelection.rotate_clause _ _ (neg_ne_zero.mpr (OR xs z).1.property)
      (by intro l hl;obtain ⟨b,hb,rfl⟩:=List.mem_map.mp hl;exact b.property)] at h
    exact h

theorem tabulate_post (n:Nat) (f:Fin n→StateM (Net base) A)
    (P:Fin n→A→List Row→Prop)
    (he:∀i,Extends (f i)) (hf:∀i z,P i (f i z).1 (f i z).2.rows)
    (hm:∀i a D E,P i a D→(∀R∈D,R∈E)→P i a E) :
    ∀z i,P i ((tabulate n f z).1 i) (tabulate n f z).2.rows := by
  induction n with
  | zero=>intro z i;exact Fin.elim0 i
  | succ n ih=>
    intro z i
    refine Fin.cases ?_ (fun j=>?_) i
    · exact hm 0 _ _ _ (hf 0 z)
        (tabulate_extends n (fun j=>f j.succ) (fun j=>he j.succ) (f 0 z).2)
    · exact ih (fun j=>f j.succ) (fun j=>P j.succ) (fun j=>he j.succ)
        (fun j=>hf j.succ) (fun j=>hm j.succ) (f 0 z).2 j

theorem tabulate_or (n:Nat) (f:Fin n→List Bit) (z:Net base) (i:Fin n) :
    OrRows (tabulate n (fun j=>OR (f j)) z).2.rows (f i)
      ((tabulate n (fun j=>OR (f j)) z).1 i) :=
  tabulate_post n (fun j=>OR (f j)) (fun j q D=>OrRows D (f j) q)
    (fun j=>gate_extends false _) (fun j=>actual_or _)
    (fun j q D E h hm=>h.mono hm) z i

def truth (n:Nat) (hn:2≤n) := AND [] (PrimaryAliasBank.seed n hn)
def betaRun (n:Nat) (hn:2≤n) := tabulate (3*(n+1)-4)
  (fun g=>OR (AliasAssembly.choiceSupport (n+1) (by omega) true g.val)) (truth n hn).2
def gammaRun (n:Nat) (hn:2≤n) := tabulate (3*(n+1)-4)
  (fun g=>OR (AliasAssembly.choiceSupport (n+1) (by omega) false g.val)) (betaRun n hn).2
def keptRun (n:Nat) (hn:2≤n) := tabulate (3*(n+1)-4)
  (fun g=>OR ((List.range (RankConstruction.width (n+1))).map (AliasAssembly.rankBit (n+1) (by omega) g.val)))
    (gammaRun n hn).2
def hitRun (n:Nat) (hn:2≤n) := tabulate (3*(n+1)-4)
  (fun g=>select ((List.range (g.val-1)).map (fun h=>
    (AliasAssembly.refAt (neg (truth n hn).1) (betaRun n hn).1 (h+1),
      AliasAssembly.selector (n+1) (3*(n+1)-4) g.val 0 (n+1+(h+1)))))) (keptRun n hn).2

theorem context_state (n:Nat) (hn:2≤n) : (hitRun n hn).2=(PrimaryAliasBank.context n hn).2 := rfl

theorem context_to_endpoint (n:Nat) (hn:2≤n) :
    ∀R∈(PrimaryAliasBank.context n hn).2.rows,R∈FirstPortOneHot.result n hn := by
  intro R hr
  have h:=RecursiveAliases.run_extends (PrimaryAliasBank.cfg n hn)
    (FirstPortRelations.initialAliases n hn) 0 (3*(n+1)-4) (PrimaryAliasBank.context n hn).2 R hr
  have hb:R∈(AliasAssembly.built n hn).2.rows:=h
  have ht:=SelectorBank.trace_retains
    (RecordedExpressionRun.original_to_selection_relations n hn)
  rw [←(RecordedAliasRun.built_binding n hn).2] at hb
  have h1:R∈PrimaryAliasBank.result n hn:=
    List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hb)))
  exact FirstPortOneHot.block_retains n hn 1 _ R (FirstPortOneHot.block_retains n hn 0 _ R h1)

theorem kept_to_context (n:Nat) (hn:2≤n) :
    ∀R∈(keptRun n hn).2.rows,R∈(PrimaryAliasBank.context n hn).2.rows :=
  tabulate_extends _ _ (fun i=>select_extends _) _

theorem gamma_to_context (n:Nat) (hn:2≤n) :
    ∀R∈(gammaRun n hn).2.rows,R∈(PrimaryAliasBank.context n hn).2.rows := by
  intro R hr
  apply kept_to_context n hn R
  exact tabulate_extends _ _ (fun i=>gate_extends false _) (gammaRun n hn).2 R hr

theorem beta_to_context (n:Nat) (hn:2≤n) :
    ∀R∈(betaRun n hn).2.rows,R∈(PrimaryAliasBank.context n hn).2.rows := by
  intro R hr
  apply gamma_to_context n hn R
  exact tabulate_extends _ _ (fun i=>gate_extends false _) (betaRun n hn).2 R hr

theorem beta_rows (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4) :
    OrRows (FirstPortOneHot.result n hn) (AliasAssembly.choiceSupport (n+1) (by omega) true g)
      ((PrimaryAliasBank.cfg n hn).beta g) := by
  have h:=tabulate_or (3*(n+1)-4) (fun g=>AliasAssembly.choiceSupport (n+1) (by omega) true g.val)
    (truth n hn).2 ⟨g,hg⟩
  have he:(PrimaryAliasBank.cfg n hn).beta g=(betaRun n hn).1 ⟨g,hg⟩ := by
    change AliasAssembly.refAt _ (betaRun n hn).1 g=_
    simp only [AliasAssembly.refAt,dif_pos hg]
  rw [he]
  exact h.mono (fun R hr=>context_to_endpoint n hn R (beta_to_context n hn R hr))

theorem gamma_rows (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4) :
    OrRows (FirstPortOneHot.result n hn) (AliasAssembly.choiceSupport (n+1) (by omega) false g)
      ((PrimaryAliasBank.cfg n hn).gamma g) := by
  have h:=tabulate_or (3*(n+1)-4) (fun g=>AliasAssembly.choiceSupport (n+1) (by omega) false g.val)
    (betaRun n hn).2 ⟨g,hg⟩
  have he:(PrimaryAliasBank.cfg n hn).gamma g=(gammaRun n hn).1 ⟨g,hg⟩ := by
    change AliasAssembly.refAt _ (gammaRun n hn).1 g=_
    simp only [AliasAssembly.refAt,dif_pos hg]
  rw [he]
  exact h.mono (fun R hr=>context_to_endpoint n hn R (gamma_to_context n hn R hr))

#print axioms beta_rows
#print axioms gamma_rows
end L3Emitter.ContextRows

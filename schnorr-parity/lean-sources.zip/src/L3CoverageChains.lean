import L3FrontInv

namespace L3
open EREF EREF.GeneralRED

/-- A concrete addition chain including the negated candidate. -/
theorem clause_chain (D : List EREF.Row) (c : List Int) (rs : List Row)
    (hD : ∀ R ∈ D, Canonical R) (hc : ∀ l ∈ c, l ≠ 0)
    (hr : All (fun r => r.toE ∈ D) rs) (hn : All Row.nz rs)
    (hv : ∀ α, -lsum α c + (rs.map fun r => lsum α r.lits - (r.rhs : Int)).sum < 0) :
    Refutation (D ++ [negate (clauseRow c).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow c).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]
      exact canonical_negate _
  have hr' : All (fun r => r.toE ∈ D ++ [negate (clauseRow c).toE]) rs := by
    clear hv hn
    induction rs with
    | nil => trivial
    | cons r rs ih => exact ⟨List.mem_append_left _ hr.1, ih hr.2⟩
  apply refutation_of_rowlist _ hDc (negClause c :: rs) (by simp)
  · constructor
    · change (negClause c).toE ∈ D ++ [negate (clauseRow c).toE]
      rw [negClause_toE c hc]; simp
    · exact hr'
  · exact ⟨negClause_nz c hc, hn⟩
  · intro α
    simp only [List.map_cons, List.sum_cons, negClause]
    rw [lsum_map_neg α c hc]
    have := hv α
    omega

/-- T5d: the four definition rows imply that a live forcing consumer is
    covered by A. This is a fixed POL chain, with no propagation search. -/
theorem forcing_consumer_chain (D : List EREF.Row)
    (a live sel force pf cons eligible : Nat)
    (ha : 1 ≤ a) (hl : 1 ≤ live) (hs : 1 ≤ sel) (hf : 1 ≤ force)
    (hp : 1 ≤ pf) (hc : 1 ≤ cons) (he : 1 ≤ eligible)
    (hD : ∀ R ∈ D, Canonical R)
    (h1 : (gateRow [-(sel : Int), -(force : Int)] pf true).toE ∈ D)
    (h2 : (gateRow [-(pf : Int)] cons true).toE ∈ D)
    (h3 : (gateRow [-(live : Int), -(cons : Int)] eligible true).toE ∈ D)
    (h4 : (gateRow [-(eligible : Int)] a true).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow
      [(a : Int), -(live : Int), -(sel : Int), -(force : Int)]).toE]) := by
  apply clause_chain D _ [
    gateRow [-(sel : Int), -(force : Int)] pf true,
    gateRow [-(pf : Int)] cons true,
    gateRow [-(live : Int), -(cons : Int)] eligible true,
    gateRow [-(eligible : Int)] a true] hD
  · nz_lits
  · exact ⟨h1,h2,h3,h4,trivial⟩
  · simp only [All]
    refine ⟨?_,?_,?_,?_,trivial⟩ <;> nz_lits
  · intro α
    simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      gateRow,lsum_cons,lsum_nil,lsum_append,pos,neg,ite_true]
    lv_omega

namespace Fam
variable (F : Fam)

/-- The actual Good3 definition rows supply every premise of T5d. -/
theorem good3_forcing_consumer {t : StI F.V} (h : F.Good3 t)
    (g port : Nat) (hg1 : 1 ≤ g) (hg : g < F.s) (hp : port < 2)
    (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R)
    (hmem : ∀ R ∈ exec F.db5 t.s.cmds, R ∈ D) :
    Refutation (D ++ [negate (clauseRow [(t.s.A : Int),
      -(t.s.live g : Int), -(F.sel g port 0 : Int), -(t.s.force g port : Int)]).toE]) := by
  obtain ⟨cons,hcons,helig,hconspos,heligpos,_⟩ := h.2.2.2.1 g hg1 hg
  have hport := h.2.2.1 g port hg1 hg hp
  have hp0 := hport.2.2.2
  have hforce := hport.2.2.1
  have hlive := F.live_bound_of_good3 h g hg
  have hA := h.2.2.2.2
  apply forcing_consumer_chain D _ _ _ _ (t.s.p0force g port) cons (t.s.eligible g)
  · have := hA.2.1; omega
  · omega
  · exact F.sel_pos g port 0
  · have := hforce.2.1; omega
  · have := hp0.2.1; omega
  · omega
  · omega
  · exact hD
  · apply hmem
    exact andDef_row_up F.db5 t.s.cmds _ _ hp0.1
  · apply hmem
    apply orDef_row_up F.db5 t.s.cmds _ _ hcons
    have : port = 0 ∨ port = 1 := by omega
    rcases this with rfl | rfl <;> simp
  · apply hmem
    exact andDef_row_up F.db5 t.s.cmds _ _ helig
  · apply hmem
    apply orDef_row_up F.db5 t.s.cmds _ _ hA.1
    apply List.mem_map.mpr
    exact ⟨g,List.mem_range'_1.mpr ⟨hg1,by omega⟩,rfl⟩

end Fam
#print axioms forcing_consumer_chain
#print axioms Fam.good3_forcing_consumer
end L3

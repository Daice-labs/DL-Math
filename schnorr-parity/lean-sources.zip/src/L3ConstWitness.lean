/-
Obligation 1(c): the constant-witness RED of frontend.py (lines 52–55):

    w = {sel(0,1,j) ↦ [j==1] (j<k)}  ∪ {fn(0,1) ↦ fn(0,0), fn(0,2) ↦ fn(0,3)}
      ∪ {port(0,1,x) ↦ bit(x, k−2)}
    p.red([-sel(0,1,0)], w)

against the exact database `db2 k` (all originals, then the 2k−3 units of the two swap
loops). Every obligation is discharged:
* rows mentioning none of the rewritten ids: substituted row = the row itself (old-row
  certificate);
* `row1 0 1`, `row1' 0 1`, `row2 0 6/9`, every `row3i 0 1 j x`, the units `¬sel(0,1,j)`, the
  candidate, and the gate-0 block-4 rows whose port-1 literal becomes true: the substituted
  row is a tautology (one-reference certificate);
* the gate-0 block-4 rows whose port-1 literal becomes false: an explicit POL chain
  ALO(0,0) + units ¬sel(0,0,j) + row3i(0,0,0,x) [+ ¬C + row3i(0,1,0,x) + row4(0,x,a',a')] + ¬G
  whose value is negative under every assignment.
-/
import L3Parity

namespace L3
open EREF EREF.GeneralRED

/-! ### Generic certificates -/

/-- A tautological substituted row needs exactly one reference (transcribed from REDWitness). -/
theorem taut_certificate (rows : List EREF.Row) (C G : EREF.Row) (hG : Canonical G)
    (ht : ∀ α, G.sat α) : LocalCertificate rows C G := by
  refine ⟨[.ref (rows.length+2)], negate G, ?_, ?_⟩
  · simp [polEval, db_neg_right]
  · apply (canonical_contra_iff _ (canonical_negate G)).mpr
    intro α h
    exact (sat_negate_iff G hG α).mp h (ht α)

theorem refutation_of_taut (D : List EREF.Row) (C G : EREF.Row) (hG : Canonical G)
    (ht : ∀ α, 0 ≤ G.val α) : Refutation (D ++ [negate C, negate G]) :=
  single_to_refutation D C G (taut_certificate D C G hG ht)

theorem lsum_congr (α β : Val) (xs : List Int) (h : ∀ l ∈ xs, β l.natAbs = α l.natAbs) :
    lsum β xs = lsum α xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    simp only [lsum_cons]
    rw [ih (fun l hl => h l (by simp [hl]))]
    unfold lv; rw [h x (by simp)]

/-- a row none of whose ids the witness moves substitutes to itself -/
theorem substRow_eq_of_fixed (ω : Witness) (r : Row) (hz : r.nz)
    (hfix : ∀ α, ∀ l ∈ r.lits, applyWitness ω α l.natAbs = α l.natAbs) :
    substRow r.toE ω = r.toE := by
  apply canonical_ext _ _ (canonical_substRow _ _) (canonical_toE _)
  intro α
  rw [val_substRow, val_toE r hz, val_toE r hz, lsum_congr α _ r.lits (hfix α)]

/-- the substituted row of an L3 row is a tautology when its literal sum under the
    witnessed assignment always reaches the right-hand side -/
theorem refutation_of_subst_taut (D : List EREF.Row) (C : EREF.Row) (ω : Witness) (r : Row) (hz : r.nz)
    (ht : ∀ α, (r.rhs : Int) ≤ lsum (applyWitness ω α) r.lits) :
    Refutation (D ++ [negate C, negate (substRow r.toE ω)]) := by
  apply refutation_of_taut D C _ (canonical_substRow _ _)
  intro α
  rw [val_substRow, val_toE r hz]
  have := ht α; omega

/-! ### POL chains: ref i0, then (ref i, add)* -/

def chain (i0 : Nat) (is : List Nat) : List Tok := .ref i0 :: is.flatMap fun i => [.ref i, .add]

theorem polEval_chain_aux (db : Nat → Option EREF.Row) (f : Nat → EREF.Row) (is : List Nat)
    (hf : ∀ i ∈ is, db i = some (f i)) (acc : EREF.Row) :
    polEval db (is.flatMap fun i => [.ref i, .add]) [acc]
      = some (is.foldl (fun acc i => add acc (f i)) acc) := by
  induction is generalizing acc with
  | nil => rfl
  | cons i is ih =>
    simp only [List.flatMap_cons, List.cons_append, List.nil_append, List.foldl_cons]
    rw [polEval, hf i (by simp)]
    simp only
    rw [polEval]
    exact ih (fun i' hi' => hf i' (by simp [hi'])) _

theorem polEval_chain (db : Nat → Option EREF.Row) (f : Nat → EREF.Row) (i0 : Nat) (is : List Nat)
    (h0 : db i0 = some (f i0)) (hf : ∀ i ∈ is, db i = some (f i)) :
    polEval db (chain i0 is) [] = some (is.foldl (fun acc i => add acc (f i)) (f i0)) := by
  unfold chain
  rw [polEval, h0]
  exact polEval_chain_aux db f is hf (f i0)

theorem canonical_foldl_add (f : Nat → EREF.Row) (is : List Nat) (acc : EREF.Row) (hacc : Canonical acc) :
    Canonical (is.foldl (fun acc i => add acc (f i)) acc) := by
  induction is generalizing acc with
  | nil => exact hacc
  | cons i is ih => exact ih _ (canonical_add _ _)

theorem val_foldl_add (f : Nat → EREF.Row) (is : List Nat) (hf : ∀ i ∈ is, Canonical (f i))
    (acc : EREF.Row) (hacc : Canonical acc) (α : Val) :
    (is.foldl (fun acc i => add acc (f i)) acc).val α = acc.val α + (is.map fun i => (f i).val α).sum := by
  induction is generalizing acc with
  | nil => simp
  | cons i is ih =>
    simp only [List.foldl_cons, List.map_cons, List.sum_cons]
    rw [ih (fun i' hi' => hf i' (by simp [hi'])) _ (canonical_add _ _), val_add _ _ hacc (hf i (by simp))]
    omega

/-- **chain refutation**: if the referenced rows exist and their values always sum to a
    negative number, the chain evaluates to a syntactically contradictory row -/
theorem refutation_of_chain (D' : List EREF.Row) (hD' : ∀ R ∈ D', Canonical R)
    (f : Nat → EREF.Row) (i0 : Nat) (is : List Nat)
    (h0 : dbOf D' i0 = some (f i0)) (hf : ∀ i ∈ is, dbOf D' i = some (f i))
    (hneg : ∀ α, (f i0).val α + (is.map fun i => (f i).val α).sum < 0) :
    Refutation D' := by
  refine ⟨[is.foldl (fun acc i => add acc (f i)) (f i0)], ?_, is.foldl (fun acc i => add acc (f i)) (f i0),
    List.mem_append_right _ (List.mem_singleton.mpr rfl), ?_⟩
  · apply derived_append _ _ (by intro k hk hklt; omega) _ (Nat.le_refl _) (chain i0 is)
    exact polEval_chain (dbOf D') f i0 is h0 hf
  · have hc0 : Canonical (f i0) := hD' _ (dbOf_mem _ _ _ h0)
    have hci : ∀ i ∈ is, Canonical (f i) := fun i hi => hD' _ (dbOf_mem _ _ _ (hf i hi))
    apply (canonical_contra_iff _ (canonical_foldl_add f is _ hc0)).mpr
    intro α hs
    unfold Row.sat at hs
    rw [val_foldl_add f is hci _ hc0] at hs
    have := hneg α
    omega

/-! ### Literal values -/

theorem lv_pos (α : Val) (v : Nat) (hv : 1 ≤ v) : lv α (pos v) = b2i (α v) := by
  unfold lv pos; simp; omega
theorem lv_neg (α : Val) (v : Nat) (hv : 1 ≤ v) : lv α (neg v) = 1 - b2i (α v) := by
  unfold lv neg
  have : ¬ (0 : Int) < -(v : Int) := by omega
  have h1 : ¬ (v : Int) < 0 := by omega
  simp [this, h1]
theorem b2i_bounds (b : Bool) : 0 ≤ b2i b ∧ b2i b ≤ 1 := by cases b <;> simp [b2i]
theorem b2i_true : b2i true = 1 := rfl
theorem b2i_false : b2i false = 0 := rfl

namespace Fam

/-! ### The constant witness -/

/-- the identity image of an id -/
def litImage (v : Nat) : Image := if h : ((v : Nat) : Int) ≠ 0 then .literal v h else .constant false

theorem eval_litImage (α : Val) (v : Nat) (hv : 1 ≤ v) : (litImage v).eval α = α v := by
  unfold litImage
  split
  · simp only [Image.eval]
    have : (0 : Int) < (v : Nat) := by omega
    have h0 : ¬ v = 0 := by omega
    simp [this, h0]
  · rename_i h; exact absurd (by omega) h

def constWitness (F : Fam) : Witness := fun v =>
  match F.decodeSel v with
  | some (t, p, j) => if t = 0 ∧ p = 1 then .constant (j == 1) else litImage v
  | none =>
    if v = F.fn 0 1 then litImage (F.fn 0 0)
    else if v = F.fn 0 2 then litImage (F.fn 0 3)
    else match F.decodePort v with
      | some (t, p, x) => if t = 0 ∧ p = 1 then .constant (F.inputBit 1 x) else litImage v
      | none => litImage v

/-- β := the witnessed assignment -/
abbrev cw (F : Fam) (α : Val) : Val := applyWitness F.constWitness α

theorem cw_sel01 (F : Fam) (α : Val) (hs : 1 ≤ F.s) (j : Nat) (hj : j < F.k) :
    F.cw α (F.sel 0 1 j) = (j == 1) := by
  unfold cw applyWitness constWitness
  rw [F.decodeSel_sel 0 1 j hs (by omega) (by omega)]
  simp [Image.eval]

theorem cw_sel_other (F : Fam) (α : Val) (t p j : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k + t)
    (hne : ¬ (t = 0 ∧ p = 1)) : F.cw α (F.sel t p j) = α (F.sel t p j) := by
  unfold cw applyWitness constWitness
  rw [F.decodeSel_sel t p j ht hp hj]
  simp only [hne, ↓reduceIte]
  exact eval_litImage α _ (F.sel_pos t p j)

theorem fn_eq_iff (F : Fam) (t ab t' ab' : Nat) (hab : ab < 4) (hab' : ab' < 4) :
    F.fn t ab = F.fn t' ab' ↔ t = t' ∧ ab = ab' := by
  unfold fn; constructor
  · intro h; omega
  · rintro ⟨rfl, rfl⟩; rfl

theorem cw_fn01 (F : Fam) (α : Val) : F.cw α (F.fn 0 1) = α (F.fn 0 0) := by
  unfold cw applyWitness constWitness
  rw [F.decodeSel_none _ (by unfold fn; omega)]
  simp only [↓reduceIte]
  exact eval_litImage α _ (F.fn_pos 0 0)

theorem cw_fn02 (F : Fam) (α : Val) : F.cw α (F.fn 0 2) = α (F.fn 0 3) := by
  unfold cw applyWitness constWitness
  rw [F.decodeSel_none _ (by unfold fn; omega)]
  have h1 : ¬ F.fn 0 2 = F.fn 0 1 := by unfold fn; omega
  simp only [h1, ↓reduceIte]
  exact eval_litImage α _ (F.fn_pos 0 3)

theorem cw_fn_other (F : Fam) (α : Val) (t ab : Nat) (ht : t < F.s) (hab : ab < 4)
    (hne : ¬ (t = 0 ∧ (ab = 1 ∨ ab = 2))) : F.cw α (F.fn t ab) = α (F.fn t ab) := by
  unfold cw applyWitness constWitness
  rw [F.decodeSel_none _ (by unfold fn; omega)]
  have h1 : ¬ F.fn t ab = F.fn 0 1 := by unfold fn; omega
  have h2 : ¬ F.fn t ab = F.fn 0 2 := by unfold fn; omega
  simp only [h1, h2, ↓reduceIte]
  have hr := F.fn_range t ab ht hab
  rw [F.decodePort_none _ (Or.inl (by omega))]
  exact eval_litImage α _ (F.fn_pos t ab)

theorem cw_port01 (F : Fam) (α : Val) (hs : 1 ≤ F.s) (x : Nat) (hx : x < F.T) :
    F.cw α (F.port 0 1 x) = F.inputBit 1 x := by
  unfold cw applyWitness constWitness
  have hr := F.port_range 0 1 x hs (by omega) hx
  rw [F.decodeSel_none _ (by omega)]
  have h1 : ¬ F.port 0 1 x = F.fn 0 1 := by unfold fn; omega
  have h2 : ¬ F.port 0 1 x = F.fn 0 2 := by unfold fn; omega
  simp only [h1, h2, ↓reduceIte]
  rw [F.decodePort_port 0 1 x hs (by omega) hx]
  simp [Image.eval]

theorem cw_port_other (F : Fam) (α : Val) (t p x : Nat) (ht : t < F.s) (hp : p < 2) (hx : x < F.T)
    (hne : ¬ (t = 0 ∧ p = 1)) : F.cw α (F.port t p x) = α (F.port t p x) := by
  unfold cw applyWitness constWitness
  have hr := F.port_range t p x ht hp hx
  rw [F.decodeSel_none _ (by omega)]
  have h1 : ¬ F.port t p x = F.fn 0 1 := by unfold fn; omega
  have h2 : ¬ F.port t p x = F.fn 0 2 := by unfold fn; omega
  simp only [h1, h2, ↓reduceIte]
  rw [F.decodePort_port t p x ht hp hx]
  simp only [hne, ↓reduceIte]
  exact eval_litImage α _ (F.port_pos t p x)

theorem cw_val (F : Fam) (α : Val) (t x : Nat) (ht : t < F.s) (hx : x < F.T) :
    F.cw α (F.val t x) = α (F.val t x) := by
  unfold cw applyWitness constWitness
  have hr := F.val_range t x ht hx
  rw [F.decodeSel_none _ (by omega)]
  have h1 : ¬ F.val t x = F.fn 0 1 := by unfold fn; omega
  have h2 : ¬ F.val t x = F.fn 0 2 := by unfold fn; omega
  simp only [h1, h2, ↓reduceIte]
  rw [F.decodePort_none _ (Or.inr (by omega))]
  exact eval_litImage α _ (F.val_pos t x)

/-! ### Rows fixed by the witness -/

theorem natAbs_pos' (v : Nat) : (pos v).natAbs = v := natAbs_pos v
theorem natAbs_neg' (v : Nat) : (neg v).natAbs = v := natAbs_neg v

/-- membership helper: `substRow R ω ∈ D` from `R ∈ D` when R is fixed -/
theorem fixed_mem (D : List EREF.Row) (ω : Witness) (r : Row) (hz : r.nz) (hmem : r.toE ∈ D)
    (hfix : ∀ α, ∀ l ∈ r.lits, applyWitness ω α l.natAbs = α l.natAbs) : substRow r.toE ω ∈ D := by
  rw [substRow_eq_of_fixed ω r hz hfix]; exact hmem

theorem row1_fixed (F : Fam) (t p : Nat) (ht : t < F.s) (hp : p < 2) (hne : ¬ (t = 0 ∧ p = 1)) :
    ∀ α, ∀ l ∈ (F.row1 t p).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row1 at hl
  simp only [List.map_map, List.mem_map, List.mem_range, Function.comp] at hl
  obtain ⟨j, hj, rfl⟩ := hl
  rw [natAbs_pos']; exact F.cw_sel_other α t p j ht hp hj hne

theorem row1'_fixed (F : Fam) (t p : Nat) (ht : t < F.s) (hp : p < 2) (hne : ¬ (t = 0 ∧ p = 1)) :
    ∀ α, ∀ l ∈ (F.row1' t p).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row1' at hl
  simp only [List.map_map, List.mem_map, List.mem_range, Function.comp] at hl
  obtain ⟨j, hj, rfl⟩ := hl
  rw [natAbs_neg']; exact F.cw_sel_other α t p j ht hp hj hne

theorem row2_fixed (F : Fam) (t c : Nat) (ht : t < F.s) (hne : t ≠ 0) :
    ∀ α, ∀ l ∈ (F.row2 t c).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row2 at hl
  simp only [List.mem_map, List.mem_range] at hl
  obtain ⟨ab, hab, rfl⟩ := hl
  have := F.cw_fn_other α t ab ht hab (by omega)
  split <;> simp only [natAbs_pos', natAbs_neg'] <;> exact this

theorem row3i_fixed (F : Fam) (t p j x : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k) (hx : x < F.T)
    (hne : ¬ (t = 0 ∧ p = 1)) :
    ∀ α, ∀ l ∈ (F.row3i t p j x).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row3i at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl
  · rw [natAbs_neg']; exact F.cw_sel_other α t p j ht hp (by omega) hne
  · split <;> simp only [natAbs_pos', natAbs_neg'] <;> exact F.cw_port_other α t p x ht hp hx hne

theorem row3g_fixed (F : Fam) (t p i x : Nat) (ht : t < F.s) (hp : p < 2) (hi : i < t) (hx : x < F.T) :
    ∀ α, ∀ l ∈ (F.row3g t p i x).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row3g at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl | rfl
  · rw [natAbs_neg']; exact F.cw_sel_other α t p _ ht hp (by omega) (by omega)
  · rw [natAbs_neg']; exact F.cw_val α i x (by omega) hx
  · rw [natAbs_pos']; exact F.cw_port_other α t p x ht hp hx (by omega)

theorem row3g'_fixed (F : Fam) (t p i x : Nat) (ht : t < F.s) (hp : p < 2) (hi : i < t) (hx : x < F.T) :
    ∀ α, ∀ l ∈ (F.row3g' t p i x).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row3g' at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl | rfl
  · rw [natAbs_neg']; exact F.cw_sel_other α t p _ ht hp (by omega) (by omega)
  · rw [natAbs_pos']; exact F.cw_val α i x (by omega) hx
  · rw [natAbs_neg']; exact F.cw_port_other α t p x ht hp hx (by omega)

theorem m1_fixed (F : Fam) (α : Val) (t x a : Nat) (ht : t < F.s) (hx : x < F.T) :
    F.cw α (F.m1 t x a).natAbs = α (F.m1 t x a).natAbs := by
  unfold m1; split <;> simp only [natAbs_pos', natAbs_neg'] <;> exact F.cw_port_other α t 0 x ht (by omega) hx (by omega)

theorem row4_fixed (F : Fam) (t x a b : Nat) (ht : t < F.s) (hx : x < F.T) (ha : a < 2) (hb : b < 2) (hne : t ≠ 0) :
    ∀ α, ∀ l ∈ (F.row4 t x a b).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row4 at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl | rfl | rfl
  · exact F.m1_fixed α t x a ht hx
  · unfold m2; split <;> simp only [natAbs_pos', natAbs_neg'] <;>
      exact F.cw_port_other α t 1 x ht (by omega) hx (by omega)
  · rw [natAbs_neg']; exact F.cw_val α t x ht hx
  · rw [natAbs_pos']; exact F.cw_fn_other α t _ ht (by omega) (by omega)

theorem row4'_fixed (F : Fam) (t x a b : Nat) (ht : t < F.s) (hx : x < F.T) (ha : a < 2) (hb : b < 2) (hne : t ≠ 0) :
    ∀ α, ∀ l ∈ (F.row4' t x a b).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row4' at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl | rfl | rfl
  · exact F.m1_fixed α t x a ht hx
  · unfold m2; split <;> simp only [natAbs_pos', natAbs_neg'] <;>
      exact F.cw_port_other α t 1 x ht (by omega) hx (by omega)
  · rw [natAbs_pos']; exact F.cw_val α t x ht hx
  · rw [natAbs_neg']; exact F.cw_fn_other α t _ ht (by omega) (by omega)

theorem row5_fixed (F : Fam) (x : Nat) (hs : 1 ≤ F.s) (hx : x < F.T) :
    ∀ α, ∀ l ∈ (F.row5 x).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold row5 at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  subst hl
  split <;> simp only [natAbs_pos', natAbs_neg'] <;> exact F.cw_val α _ x (by omega) hx

theorem unit0_fixed (F : Fam) (j : Nat) (hs : 1 ≤ F.s) (hj : j < F.k) :
    ∀ α, ∀ l ∈ (F.unitNegSel 0 j).lits, F.cw α l.natAbs = α l.natAbs := by
  intro α l hl
  unfold unitNegSel at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  subst hl
  rw [natAbs_neg']; exact F.cw_sel_other α 0 0 j hs (by omega) (by omega) (by omega)

/-! ### Tautological images -/

theorem lsum_row1_01 (F : Fam) (hs : 1 ≤ F.s) (hk : 2 ≤ F.k) (α : Val) :
    lsum (F.cw α) (F.row1 0 1).lits = 1 := by
  unfold row1
  simp only [List.map_map, Nat.add_zero]
  rw [lsum_map_range]
  have : ∀ j, j < F.k → lv (F.cw α) ((pos ∘ fun j => F.sel 0 1 j) j) = if j = 1 then 1 else 0 := by
    intro j hj
    simp only [Function.comp]
    rw [lv_pos _ _ (F.sel_pos 0 1 j), F.cw_sel01 α hs j hj]
    by_cases h : j = 1 <;> simp [h, b2i]
  calc sumR F.k (fun j => lv (F.cw α) ((pos ∘ fun j => F.sel 0 1 j) j))
      = sumR F.k (fun j => if j = 1 then 1 else 0) := by
        unfold sumR; congr 1; apply List.map_congr_left; intro j hj; exact this j (List.mem_range.mp hj)
    _ = 1 := by
        rw [sumR_single F.k 1 _ (by omega)]
        · simp
        · intro j _ hj; simp [hj]

theorem lsum_row1'_01 (F : Fam) (hs : 1 ≤ F.s) (hk : 2 ≤ F.k) (α : Val) :
    lsum (F.cw α) (F.row1' 0 1).lits = F.k - 1 := by
  unfold row1'
  simp only [List.map_map, Nat.add_zero]
  rw [lsum_map_range]
  have : ∀ j, j < F.k → lv (F.cw α) ((neg ∘ fun j => F.sel 0 1 j) j) = 1 - (if j = 1 then 1 else 0) := by
    intro j hj
    simp only [Function.comp]
    rw [lv_neg _ _ (F.sel_pos 0 1 j), F.cw_sel01 α hs j hj]
    by_cases h : j = 1 <;> simp [h, b2i]
  calc sumR F.k (fun j => lv (F.cw α) ((neg ∘ fun j => F.sel 0 1 j) j))
      = sumR F.k (fun j => 1 - (if j = 1 then 1 else 0)) := by
        unfold sumR; congr 1; apply List.map_congr_left; intro j hj; exact this j (List.mem_range.mp hj)
    _ = sumR F.k (fun _ => 1) - sumR F.k (fun j => if j = 1 then 1 else 0) := sumR_sub _ _ _
    _ = F.k - 1 := by
        rw [sumR_single F.k 1 (fun j => if j = 1 then 1 else 0) (by omega)]
        · have h1 : ∀ n, sumR n (fun _ => (1 : Int)) = n := by
            intro n; induction n with
            | zero => rfl
            | succ n ih => rw [sumR_succ, ih]; push_cast; omega
          rw [h1]; simp
        · intro j _ hj; simp [hj]

theorem lsum_row2_0 (F : Fam) (α : Val) (hs : 1 ≤ F.s) (c : Nat) (hc : c = 6 ∨ c = 9) :
    lsum (F.cw α) (F.row2 0 c).lits = 2 := by
  unfold row2
  have hr : List.range 4 = [0, 1, 2, 3] := by decide
  rw [hr]
  simp only [List.map_cons, List.map_nil, lsum_cons, lsum_nil]
  have f0 := F.cw_fn_other α 0 0 hs (by omega) (by omega)
  have f3 := F.cw_fn_other α 0 3 hs (by omega) (by omega)
  have f1 := F.cw_fn01 α
  have f2 := F.cw_fn02 α
  have b0 := b2i_bounds (α (F.fn 0 0))
  have b3 := b2i_bounds (α (F.fn 0 3))
  rcases hc with rfl | rfl
  · have c0 : codeBit 6 0 = false := by decide
    have c1 : codeBit 6 1 = true := by decide
    have c2 : codeBit 6 2 = true := by decide
    have c3 : codeBit 6 3 = false := by decide
    simp only [c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte]
    rw [lv_pos _ _ (F.fn_pos 0 0), lv_neg _ _ (F.fn_pos 0 1), lv_neg _ _ (F.fn_pos 0 2),
      lv_pos _ _ (F.fn_pos 0 3), f0, f1, f2, f3]
    omega
  · have c0 : codeBit 9 0 = true := by decide
    have c1 : codeBit 9 1 = false := by decide
    have c2 : codeBit 9 2 = false := by decide
    have c3 : codeBit 9 3 = true := by decide
    simp only [c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte]
    rw [lv_neg _ _ (F.fn_pos 0 0), lv_pos _ _ (F.fn_pos 0 1), lv_pos _ _ (F.fn_pos 0 2),
      lv_neg _ _ (F.fn_pos 0 3), f0, f1, f2, f3]
    omega

/-- `row3i 0 1 j x` substitutes to a tautology: either ¬[j==1] is true, or (j = 1) the
    port literal `±port(0,1,x)` with sign inputBit 1 x becomes the true constant -/
theorem lsum_row3i_01 (F : Fam) (α : Val) (hs : 1 ≤ F.s) (j x : Nat) (hj : j < F.k) (hx : x < F.T) :
    1 ≤ lsum (F.cw α) (F.row3i 0 1 j x).lits := by
  unfold row3i
  simp only [lsum_cons, lsum_nil]
  rw [lv_neg _ _ (F.sel_pos 0 1 j), F.cw_sel01 α hs j hj]
  by_cases hj1 : j = 1
  · subst hj1
    simp only [beq_self_eq_true, b2i_true]
    cases hb : F.inputBit 1 x
    · simp only [Bool.false_eq_true, ↓reduceIte]
      rw [lv_neg _ _ (F.port_pos 0 1 x), F.cw_port01 α hs x hx, hb]; simp [b2i]
    · simp only [↓reduceIte]
      rw [lv_pos _ _ (F.port_pos 0 1 x), F.cw_port01 α hs x hx, hb]; simp [b2i]
  · have : (j == 1) = false := by simp [hj1]
    rw [this, b2i_false]
    have := lv_nonneg (F.cw α) (if F.inputBit j x = true then pos (F.port 0 1 x) else neg (F.port 0 1 x))
    omega

theorem lsum_unit1 (F : Fam) (α : Val) (hs : 1 ≤ F.s) (j : Nat) (hj : j < F.k) (hj1 : j ≠ 1) :
    1 ≤ lsum (F.cw α) (F.unitNegSel 1 j).lits := by
  unfold unitNegSel
  simp only [lsum_cons, lsum_nil]
  rw [lv_neg _ _ (F.sel_pos 0 1 j), F.cw_sel01 α hs j hj]
  have : (j == 1) = false := by simp [hj1]
  rw [this, b2i_false]; omega

/-! ### The gate-0 block-4 rows -/

/-- value of the port-1 literal of `row4 0 x a b` under the witness: a constant -/
theorem lv_m2_cw (F : Fam) (α : Val) (hs : 1 ≤ F.s) (x b : Nat) (hx : x < F.T) :
    lv (F.cw α) (F.m2 0 x b) = if ((b = 1) ↔ (F.inputBit 1 x = true)) then 0 else 1 := by
  unfold m2
  by_cases hb : b = 1
  · subst hb
    simp only [↓reduceIte]
    rw [lv_neg _ _ (F.port_pos 0 1 x), F.cw_port01 α hs x hx]
    cases F.inputBit 1 x <;> simp [b2i]
  · simp only [hb, ↓reduceIte]
    rw [lv_pos _ _ (F.port_pos 0 1 x), F.cw_port01 α hs x hx]
    cases F.inputBit 1 x <;> simp [b2i, hb]

/-- the fn literal of `row4 0 x a b` is mapped to fn(0, 3a) -/
theorem cw_fn_row4 (F : Fam) (α : Val) (hs : 1 ≤ F.s) (a b : Nat) (ha : a < 2) (hb : b < 2) :
    F.cw α (F.fn 0 (2 * a + b)) = α (F.fn 0 (3 * a)) := by
  have ha' : a = 0 ∨ a = 1 := by omega
  have hb' : b = 0 ∨ b = 1 := by omega
  rcases ha' with rfl | rfl <;> rcases hb' with rfl | rfl
  · show F.cw α (F.fn 0 0) = α (F.fn 0 0); exact F.cw_fn_other α 0 0 hs (by omega) (by omega)
  · show F.cw α (F.fn 0 1) = α (F.fn 0 0); exact F.cw_fn01 α
  · show F.cw α (F.fn 0 2) = α (F.fn 0 3); exact F.cw_fn02 α
  · show F.cw α (F.fn 0 3) = α (F.fn 0 3); exact F.cw_fn_other α 0 3 hs (by omega) (by omega)

/-! ### The chain certificate for the gate-0 block-4 rows -/

theorem lv_congr (α β : Val) (l : Int) (h : β l.natAbs = α l.natAbs) : lv β l = lv α l := by
  unfold lv; rw [h]

theorem sumR_add (n : Nat) (g h : Nat → Int) :
    sumR n (fun j => g j + h j) = sumR n g + sumR n h := by
  induction n with
  | zero => simp [sumR_zero]
  | succ n ih => simp only [sumR_succ, ih]; omega

theorem sumR_one (n : Nat) : sumR n (fun _ => (1 : Int)) = n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [sumR_succ, ih]; push_cast; omega

/-- ALO(0,0) + the k−1 units ¬sel(0,0,j): the sums collapse to sel(0,0,0) + (k−1) -/
theorem alo_units_sum (F : Fam) (α : Val) (hk : 1 ≤ F.k) :
    sumR F.k (fun j => lv α (pos (F.sel 0 0 j)))
      + ((List.range' 1 (F.k - 1)).map fun j => lv α (neg (F.sel 0 0 j))).sum
      = lv α (pos (F.sel 0 0 0)) + ((F.k : Int) - 1) := by
  have e : F.k = (F.k - 1) + 1 := by omega
  rw [List.range'_eq_map_range, List.map_map]
  have h2 : ((List.range (F.k - 1)).map ((fun j => lv α (neg (F.sel 0 0 j))) ∘ (1 + ·))).sum
      = sumR (F.k - 1) (fun i => lv α (neg (F.sel 0 0 (i + 1)))) := by
    unfold sumR; congr 1; apply List.map_congr_left; intro i _; simp [Function.comp, Nat.add_comm]
  rw [h2]
  conv => lhs; rw [e, sumR_succ_left]
  rw [Nat.add_sub_cancel, Int.add_assoc, ← sumR_add]
  have h3 : sumR (F.k - 1) (fun j => lv α (pos (F.sel 0 0 (j + 1))) + lv α (neg (F.sel 0 0 (j + 1))))
      = sumR (F.k - 1) (fun _ => 1) := by
    unfold sumR; congr 1; apply List.map_congr_left; intro i _
    rw [lv_pos _ _ (F.sel_pos _ _ _), lv_neg _ _ (F.sel_pos _ _ _)]; omega
  rw [h3, sumR_one]; push_cast; omega

theorem dbOf_of_mem (D : List EREF.Row) (R : EREF.Row) (h : R ∈ D) : ∃ i, dbOf D i = some R := by
  obtain ⟨i, hi, rfl⟩ := List.mem_iff_getElem.mp h
  exact ⟨i + 1, by simp [dbOf, hi]⟩

/-- the loop-1 unit ¬sel(0,0,j) sits at database id F + j in `db2 m` -/
theorem dbOf_db2_unit0 (F : Fam) (j : Nat) (hj1 : 1 ≤ j) (hjk : j < F.k) (m : Nat) :
    dbOf (F.db2 m) (F.F + j) = some (F.unitNegSel 0 j).toE := by
  unfold dbOf db2
  have h0 : ¬ F.F + j = 0 := by omega
  simp only [h0, ↓reduceIte]
  rw [List.append_assoc, List.getElem?_append_right (by simp [F.length_rows]; omega)]
  simp only [List.length_map, F.length_rows]
  rw [List.getElem?_append_left (by simp; omega), List.getElem?_map,
    List.getElem?_range' (by omega)]
  have e : 1 + 1 * (F.F + j - 1 - F.F) = j := by omega
  rw [e]; rfl

/-- block-4 row of gate 0 with polarity: `pol = true` is row4, `false` is row4' -/
def row4P (F : Fam) (pol : Bool) (t x a b : Nat) : Row :=
  if pol then F.row4 t x a b else F.row4' t x a b

theorem row4P_mem (F : Fam) (pol : Bool) (t x a b : Nat) (ht : t < F.s) (hx : x < F.T) (ha : a < 2) (hb : b < 2) :
    F.row4P pol t x a b ∈ F.rows := by
  unfold row4P; cases pol
  · exact F.row4'_mem t x a b ht hx ha hb
  · exact F.row4_mem t x a b ht hx ha hb

theorem row4P_nz (F : Fam) (pol : Bool) (t x a b : Nat) (ht : t < F.s) (hs : 1 ≤ F.s) (hx : x < F.T) (ha : a < 2) (hb : b < 2) :
    (F.row4P pol t x a b).nz :=
  nz_of_wf _ F.V (F.rows_wf hs _ (F.row4P_mem pol t x a b ht hx ha hb))

/-- the literal sum of a gate-0 block-4 row under any assignment γ, written with the
    four literal values -/
theorem lsum_row4P (F : Fam) (pol : Bool) (γ : Val) (x a b : Nat) :
    lsum γ (F.row4P pol 0 x a b).lits
      = lv γ (F.m1 0 x a) + lv γ (F.m2 0 x b)
        + (if pol then lv γ (neg (F.val 0 x)) else lv γ (pos (F.val 0 x)))
        + (if pol then lv γ (pos (F.fn 0 (2 * a + b))) else lv γ (neg (F.fn 0 (2 * a + b)))) := by
  unfold row4P; cases pol <;> simp [row4, row4', lsum_cons, lsum_nil] <;> omega

/-- the two chain shapes, abstracted over the referenced rows' values -/
theorem chain_values (D' : List EREF.Row) (hD' : ∀ R ∈ D', Canonical R)
    (iALO iR1 iR2 iR4 inC inG : Nat) (units : List Nat)
    (RALO R1 R2 R4 nC nG : EREF.Row) (urow : Nat → EREF.Row)
    (hALO : dbOf D' iALO = some RALO) (hR1 : dbOf D' iR1 = some R1) (hR2 : dbOf D' iR2 = some R2)
    (hR4 : dbOf D' iR4 = some R4) (hnC : dbOf D' inC = some nC) (hnG : dbOf D' inG = some nG)
    (hunits : ∀ i ∈ units, dbOf D' i = some (urow i))
    (hA : ∀ α, RALO.val α + (units.map fun i => (urow i).val α).sum + R1.val α + nC.val α
      + R2.val α + R4.val α + nG.val α < 0) :
    Refutation D' := by
  let f : Nat → EREF.Row := fun i => (dbOf D' i).getD ⟨[], 0⟩
  have hf : ∀ i R, dbOf D' i = some R → f i = R := by intro i R h; simp [f, h]
  apply refutation_of_chain D' hD' f iALO (units ++ [iR1, inC, iR2, iR4, inG])
  · rw [hf _ _ hALO]; exact hALO
  · intro i hi
    simp only [List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at hi
    rcases hi with hi | rfl | rfl | rfl | rfl | rfl
    · rw [hf _ _ (hunits i hi)]; exact hunits i hi
    · rw [hf _ _ hR1]; exact hR1
    · rw [hf _ _ hnC]; exact hnC
    · rw [hf _ _ hR2]; exact hR2
    · rw [hf _ _ hR4]; exact hR4
    · rw [hf _ _ hnG]; exact hnG
  · intro α
    rw [hf _ _ hALO]
    simp only [List.map_append, List.sum_append, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
    rw [hf _ _ hR1, hf _ _ hnC, hf _ _ hR2, hf _ _ hR4, hf _ _ hnG]
    have : (units.map fun i => (f i).val α).sum = (units.map fun i => (urow i).val α).sum := by
      congr 1; apply List.map_congr_left; intro i hi; rw [hf _ _ (hunits i hi)]
    rw [this]
    have := hA α; omega

theorem chain_values_short (D' : List EREF.Row) (hD' : ∀ R ∈ D', Canonical R)
    (iALO iR1 inG : Nat) (units : List Nat)
    (RALO R1 nG : EREF.Row) (urow : Nat → EREF.Row)
    (hALO : dbOf D' iALO = some RALO) (hR1 : dbOf D' iR1 = some R1) (hnG : dbOf D' inG = some nG)
    (hunits : ∀ i ∈ units, dbOf D' i = some (urow i))
    (hA : ∀ α, RALO.val α + (units.map fun i => (urow i).val α).sum + R1.val α + nG.val α < 0) :
    Refutation D' := by
  let f : Nat → EREF.Row := fun i => (dbOf D' i).getD ⟨[], 0⟩
  have hf : ∀ i R, dbOf D' i = some R → f i = R := by intro i R h; simp [f, h]
  apply refutation_of_chain D' hD' f iALO (units ++ [iR1, inG])
  · rw [hf _ _ hALO]; exact hALO
  · intro i hi
    simp only [List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at hi
    rcases hi with hi | rfl | rfl
    · rw [hf _ _ (hunits i hi)]; exact hunits i hi
    · rw [hf _ _ hR1]; exact hR1
    · rw [hf _ _ hnG]; exact hnG
  · intro α
    rw [hf _ _ hALO]
    simp only [List.map_append, List.sum_append, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
    rw [hf _ _ hR1, hf _ _ hnG]
    have : (units.map fun i => (f i).val α).sum = (units.map fun i => (urow i).val α).sum := by
      congr 1; apply List.map_congr_left; intro i hi; rw [hf _ _ (hunits i hi)]
    rw [this]
    have := hA α; omega

/-- the k−1 unit ids F+1 .. F+k−1 -/
theorem units_sum (F : Fam) (α : Val) (hk : 1 ≤ F.k) :
    (((List.range' 1 (F.k - 1)).map fun j => F.F + j).map fun i =>
        (F.unitNegSel 0 (i - F.F)).toE.val α).sum
      = ((List.range' 1 (F.k - 1)).map fun j => lv α (neg (F.sel 0 0 j))).sum - ((F.k : Int) - 1) := by
  rw [List.map_map]
  have : ∀ j ∈ List.range' 1 (F.k - 1),
      ((fun i => (F.unitNegSel 0 (i - F.F)).toE.val α) ∘ fun j => F.F + j) j = lv α (neg (F.sel 0 0 j)) - 1 := by
    intro j _
    simp only [Function.comp, Nat.add_sub_cancel_left]
    rw [val_toE _ (F.unit_nz 0 j)]
    simp [unitNegSel]
  rw [List.map_congr_left this]
  have hsub : ∀ (l : List Nat) (g : Nat → Int),
      (l.map fun j => g j - 1).sum = (l.map g).sum - l.length := by
    intro l g; induction l with
    | nil => simp
    | cons a l ih => simp only [List.map_cons, List.sum_cons, List.length_cons, ih]; push_cast; omega
  rw [hsub]; simp; omega

/-- **the explicit certificate** for `row4P pol 0 x a' b'` whose port-1 literal becomes the
    false constant under the witness -/
theorem row4_certificate (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s) (pol : Bool) (x a' b' : Nat)
    (hx : x < F.T) (ha' : a' < 2) (hb' : b' < 2)
    (hfalse : (b' = 1) ↔ (F.inputBit 1 x = true)) :
    Refutation (F.db2 F.k ++ [negate (F.unitNegSel 1 0).toE,
      negate (substRow (F.row4P pol 0 x a' b').toE F.constWitness)]) := by
  have hDcan : ∀ R ∈ F.db2 F.k, Canonical R := canonical_db _ (F.db2_shape F.k)
  -- the referenced rows are in the database
  have hALO : (F.row1 0 0).toE ∈ F.db2 F.k := by
    unfold db2; exact List.mem_append_left _ (List.mem_append_left _
      (List.mem_map.mpr ⟨_, F.row1_mem 0 0 hs (by omega), rfl⟩))
  have hR1 : (F.row3i 0 0 0 x).toE ∈ F.db2 F.k := by
    unfold db2; exact List.mem_append_left _ (List.mem_append_left _
      (List.mem_map.mpr ⟨_, F.row3i_mem 0 0 0 x hs (by omega) (by omega) hx, rfl⟩))
  have hR2 : (F.row3i 0 1 0 x).toE ∈ F.db2 F.k := by
    unfold db2; exact List.mem_append_left _ (List.mem_append_left _
      (List.mem_map.mpr ⟨_, F.row3i_mem 0 1 0 x hs (by omega) (by omega) hx, rfl⟩))
  have hR4 : (F.row4P pol 0 x a' a').toE ∈ F.db2 F.k := by
    unfold db2; exact List.mem_append_left _ (List.mem_append_left _
      (List.mem_map.mpr ⟨_, F.row4P_mem pol 0 x a' a' hs hx ha' ha', rfl⟩))
  have hunits0 : ∀ j, 1 ≤ j → j < F.k → dbOf (F.db2 F.k) (F.F + j) = some (F.unitNegSel 0 j).toE :=
    fun j hj1 hjk => F.dbOf_db2_unit0 j hj1 hjk F.k
  -- nonzero literals
  have nzALO : (F.row1 0 0).nz := nz_of_wf _ F.V (F.rows_wf hs _ (F.row1_mem 0 0 hs (by omega)))
  have nzR1 : (F.row3i 0 0 0 x).nz := nz_of_wf _ F.V (F.rows_wf hs _ (F.row3i_mem 0 0 0 x hs (by omega) (by omega) hx))
  have nzR2 : (F.row3i 0 1 0 x).nz := nz_of_wf _ F.V (F.rows_wf hs _ (F.row3i_mem 0 1 0 x hs (by omega) (by omega) hx))
  have nzR4 : (F.row4P pol 0 x a' a').nz := F.row4P_nz pol 0 x a' a' hs hs hx ha' ha'
  have nzRb : (F.row4P pol 0 x a' b').nz := F.row4P_nz pol 0 x a' b' hs hs hx ha' hb'
  have nzC : (F.unitNegSel 1 0).nz := F.unit_nz 1 0
  -- values
  have vALO : ∀ α, (F.row1 0 0).toE.val α = sumR F.k (fun j => lv α (pos (F.sel 0 0 j))) - 1 := by
    intro α; rw [val_toE _ nzALO]; unfold row1
    simp only [List.map_map, Nat.add_zero]; rw [lsum_map_range]; rfl
  have vR1 : ∀ α, (F.row3i 0 0 0 x).toE.val α
      = lv α (neg (F.sel 0 0 0)) + lv α (if F.inputBit 0 x then pos (F.port 0 0 x) else neg (F.port 0 0 x)) - 1 := by
    intro α; rw [val_toE _ nzR1]; simp only [row3i, lsum_cons, lsum_nil]; omega
  have vR2 : ∀ α, (F.row3i 0 1 0 x).toE.val α
      = lv α (neg (F.sel 0 1 0)) + lv α (if F.inputBit 0 x then pos (F.port 0 1 x) else neg (F.port 0 1 x)) - 1 := by
    intro α; rw [val_toE _ nzR2]; simp only [row3i, lsum_cons, lsum_nil]; omega
  have vnC : ∀ α, (negate (F.unitNegSel 1 0).toE).val α = -lv α (neg (F.sel 0 1 0)) := by
    intro α; rw [val_negate _ (canonical_toE _), val_toE _ nzC]; simp only [unitNegSel, lsum_cons, lsum_nil]; omega
  have vR4 : ∀ α, (F.row4P pol 0 x a' a').toE.val α
      = lv α (F.m1 0 x a') + lv α (F.m2 0 x a')
        + (if pol then lv α (neg (F.val 0 x)) else lv α (pos (F.val 0 x)))
        + (if pol then lv α (pos (F.fn 0 (3 * a'))) else lv α (neg (F.fn 0 (3 * a')))) - 1 := by
    intro α; rw [val_toE _ nzR4, lsum_row4P]
    have e : 2 * a' + a' = 3 * a' := by omega
    have hr : ((F.row4P pol 0 x a' a').rhs : Int) = 1 := by unfold row4P; cases pol <;> rfl
    rw [e, hr]
  have vnG : ∀ α, (negate (substRow (F.row4P pol 0 x a' b').toE F.constWitness)).val α
      = -(lv α (F.m1 0 x a')
        + (if pol then lv α (neg (F.val 0 x)) else lv α (pos (F.val 0 x)))
        + (if pol then lv α (pos (F.fn 0 (3 * a'))) else lv α (neg (F.fn 0 (3 * a'))))) := by
    intro α
    rw [val_negate _ (canonical_substRow _ _), val_substRow, val_toE _ nzRb, lsum_row4P]
    have hr : ((F.row4P pol 0 x a' b').rhs : Int) = 1 := by unfold row4P; cases pol <;> rfl
    rw [hr, lv_congr α _ _ (F.m1_fixed α 0 x a' hs hx), F.lv_m2_cw α hs x b' hx]
    simp only [hfalse, iff_self, ↓reduceIte]
    have hv1 : lv (F.cw α) (neg (F.val 0 x)) = lv α (neg (F.val 0 x)) :=
      lv_congr α _ _ (by rw [natAbs_neg']; exact F.cw_val α 0 x hs hx)
    have hv2 : lv (F.cw α) (pos (F.val 0 x)) = lv α (pos (F.val 0 x)) :=
      lv_congr α _ _ (by rw [natAbs_pos']; exact F.cw_val α 0 x hs hx)
    have hf1 : lv (F.cw α) (pos (F.fn 0 (2 * a' + b'))) = lv α (pos (F.fn 0 (3 * a'))) := by
      rw [lv_pos _ _ (F.fn_pos _ _), lv_pos _ _ (F.fn_pos _ _), F.cw_fn_row4 α hs a' b' ha' hb']
    have hf2 : lv (F.cw α) (neg (F.fn 0 (2 * a' + b'))) = lv α (neg (F.fn 0 (3 * a'))) := by
      rw [lv_neg _ _ (F.fn_pos _ _), lv_neg _ _ (F.fn_pos _ _), F.cw_fn_row4 α hs a' b' ha' hb']
    rw [hv1, hv2, hf1, hf2]
    cases pol <;> simp only [Bool.false_eq_true, ↓reduceIte] <;> omega
  -- abstract the database and the substituted row
  have hGcan : Canonical (substRow (F.row4P pol 0 x a' b').toE F.constWitness) := canonical_substRow _ _
  generalize hG : substRow (F.row4P pol 0 x a' b').toE F.constWitness = G at *
  generalize hD : F.db2 F.k = D at *
  have hD'can : ∀ R ∈ D ++ [negate (F.unitNegSel 1 0).toE, negate G], Canonical R := by
    intro R hR
    simp only [List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at hR
    rcases hR with hR | rfl | rfl
    · exact hDcan R hR
    · exact canonical_negate _
    · exact canonical_negate _
  obtain ⟨iALO, hiALO⟩ := dbOf_of_mem D _ hALO
  obtain ⟨iR1, hiR1⟩ := dbOf_of_mem D _ hR1
  obtain ⟨iR2, hiR2⟩ := dbOf_of_mem D _ hR2
  obtain ⟨iR4, hiR4⟩ := dbOf_of_mem D _ hR4
  have ext := dbOf_ext_append D [negate (F.unitNegSel 1 0).toE, negate G]
  have hunits : ∀ i ∈ (List.range' 1 (F.k - 1)).map (fun j => F.F + j),
      dbOf (D ++ [negate (F.unitNegSel 1 0).toE, negate G]) i = some (F.unitNegSel 0 (i - F.F)).toE := by
    intro i hi
    obtain ⟨j, hj, rfl⟩ := List.mem_map.mp hi
    rw [List.mem_range'_1] at hj
    rw [Nat.add_sub_cancel_left]
    exact ext _ _ (hunits0 j hj.1 (by omega))
  have hsumU := F.units_sum (hk := by omega)
  have hnC : dbOf (D ++ [negate (F.unitNegSel 1 0).toE, negate G]) (D.length + 1)
      = some (negate (F.unitNegSel 1 0).toE) := db_neg_left D _ G
  have hnG : dbOf (D ++ [negate (F.unitNegSel 1 0).toE, negate G]) (D.length + 2)
      = some (negate G) := db_neg_right D _ G
  -- the two chain shapes, each under its key inequality
  have caseA : (∀ α, lv α (if F.inputBit 0 x = true then pos (F.port 0 0 x) else neg (F.port 0 0 x))
        + lv α (if F.inputBit 0 x = true then pos (F.port 0 1 x) else neg (F.port 0 1 x))
        + lv α (F.m2 0 x a') ≤ 2) →
      Refutation (D ++ [negate (F.unitNegSel 1 0).toE, negate G]) := by
    intro hkey
    apply chain_values _ hD'can iALO iR1 iR2 iR4 (D.length + 1) (D.length + 2)
      ((List.range' 1 (F.k - 1)).map (fun j => F.F + j)) _ _ _ _ _ _
      (fun i => (F.unitNegSel 0 (i - F.F)).toE)
      (ext _ _ hiALO) (ext _ _ hiR1) (ext _ _ hiR2) (ext _ _ hiR4) hnC hnG hunits
    intro α
    rw [vALO, hsumU α, vR1, vnC, vR2, vR4, vnG]
    have hsum := F.alo_units_sum α (by omega)
    have l1 := lv_pos α _ (F.sel_pos 0 0 0)
    have l2 := lv_neg α _ (F.sel_pos 0 0 0)
    have b1 := b2i_bounds (α (F.sel 0 0 0))
    have := hkey α
    have n1 := lv_nonneg α (neg (F.val 0 x)); have n2 := lv_nonneg α (pos (F.val 0 x))
    have n3 := lv_nonneg α (pos (F.fn 0 (3 * a'))); have n4 := lv_nonneg α (neg (F.fn 0 (3 * a')))
    have n5 := lv_nonneg α (F.m1 0 x a')
    cases pol <;> simp only [Bool.false_eq_true, ↓reduceIte] <;> omega
  have caseB : (∀ α, lv α (if F.inputBit 0 x = true then pos (F.port 0 0 x) else neg (F.port 0 0 x))
        ≤ lv α (F.m1 0 x a')) →
      Refutation (D ++ [negate (F.unitNegSel 1 0).toE, negate G]) := by
    intro hkey
    apply chain_values_short _ hD'can iALO iR1 (D.length + 2)
      ((List.range' 1 (F.k - 1)).map (fun j => F.F + j)) _ _ _
      (fun i => (F.unitNegSel 0 (i - F.F)).toE)
      (ext _ _ hiALO) (ext _ _ hiR1) hnG hunits
    intro α
    rw [vALO, hsumU α, vR1, vnG]
    have hsum := F.alo_units_sum α (by omega)
    have l1 := lv_pos α _ (F.sel_pos 0 0 0)
    have l2 := lv_neg α _ (F.sel_pos 0 0 0)
    have b1 := b2i_bounds (α (F.sel 0 0 0))
    have := hkey α
    have n1 := lv_nonneg α (neg (F.val 0 x)); have n2 := lv_nonneg α (pos (F.val 0 x))
    have n3 := lv_nonneg α (pos (F.fn 0 (3 * a'))); have n4 := lv_nonneg α (neg (F.fn 0 (3 * a')))
    cases pol <;> simp only [Bool.false_eq_true, ↓reduceIte] <;> omega
  -- the four bit cases
  have ha2 : a' = 0 ∨ a' = 1 := by omega
  rcases ha2 with rfl | rfl <;> cases hd : F.inputBit 0 x
  · -- a' = 0, bit = 0: port literals "port = 0" agree with m2 0 = pos port01
    apply caseA; intro α
    simp only [hd, Bool.false_eq_true, ↓reduceIte, m2, Nat.zero_ne_one]
    have := lv_neg α _ (F.port_pos 0 0 x); have := lv_neg α _ (F.port_pos 0 1 x)
    have := lv_pos α _ (F.port_pos 0 1 x)
    have := b2i_bounds (α (F.port 0 0 x)); have := b2i_bounds (α (F.port 0 1 x)); omega
  · -- a' = 0, bit = 1: short chain
    apply caseB; intro α
    simp only [hd, ↓reduceIte, m1, Nat.zero_ne_one]
    exact Int.le_refl _
  · -- a' = 1, bit = 0: short chain
    apply caseB; intro α
    simp only [hd, Bool.false_eq_true, ↓reduceIte, m1]
    exact Int.le_refl _
  · -- a' = 1, bit = 1
    apply caseA; intro α
    simp only [hd, ↓reduceIte, m2]
    have := lv_pos α _ (F.port_pos 0 0 x); have := lv_pos α _ (F.port_pos 0 1 x)
    have := lv_neg α _ (F.port_pos 0 1 x)
    have := b2i_bounds (α (F.port 0 0 x)); have := b2i_bounds (α (F.port 0 1 x)); omega


/-! ### The RED step -/

theorem row4P_true (F : Fam) (t x a b : Nat) : F.row4P true t x a b = F.row4 t x a b := rfl
theorem row4P_false (F : Fam) (t x a b : Nat) : F.row4P false t x a b = F.row4' t x a b := rfl

/-- obligation of a gate-0 block-4 row: explicit chain when the port-1 literal becomes
    false, tautology otherwise -/
theorem obligation_row4P (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s) (pol : Bool) (x a b : Nat)
    (hx : x < F.T) (ha : a < 2) (hb : b < 2) :
    Refutation (F.db2 F.k ++ [negate (F.unitNegSel 1 0).toE,
      negate (substRow (F.row4P pol 0 x a b).toE F.constWitness)]) := by
  by_cases hfalse : (b = 1) ↔ (F.inputBit 1 x = true)
  · exact F.row4_certificate hk hs pol x a b hx ha hb hfalse
  · apply refutation_of_subst_taut _ _ _ _ (F.row4P_nz pol 0 x a b hs hs hx ha hb)
    intro α
    show ((F.row4P pol 0 x a b).rhs : Int) ≤ lsum (F.cw α) (F.row4P pol 0 x a b).lits
    rw [lsum_row4P, F.lv_m2_cw α hs x b hx]
    simp only [hfalse, ↓reduceIte]
    have hr : ((F.row4P pol 0 x a b).rhs : Int) = 1 := by unfold row4P; cases pol <;> rfl
    rw [hr]
    have := lv_nonneg (F.cw α) (F.m1 0 x a)
    have := lv_nonneg (F.cw α) (neg (F.val 0 x)); have := lv_nonneg (F.cw α) (pos (F.val 0 x))
    have := lv_nonneg (F.cw α) (pos (F.fn 0 (2 * a + b))); have := lv_nonneg (F.cw α) (neg (F.fn 0 (2 * a + b)))
    cases pol <;> simp only [Bool.false_eq_true, ↓reduceIte] <;> omega

theorem toE_mem_db2 (F : Fam) (m : Nat) (r : Row) (hr : r ∈ F.rows) : r.toE ∈ F.db2 m := by
  unfold db2
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_map.mpr ⟨r, hr, rfl⟩))

/-- **Obligation 1(c)**: `p.red([-F.sel(0,1,0)], w)` with the constant witness is a checked
    RED step against the exact database after the two swap loops, for every k ≥ 2, s ≥ 1. -/
theorem stepC (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s) :
    CheckedStep (F.db2 F.k) (F.db2 F.k ++ [(F.unitNegSel 1 0).toE]) := by
  have hDcan : ∀ R ∈ F.db2 F.k, Canonical R := canonical_db _ (F.db2_shape F.k)
  apply CheckedStep.red _ _ F.constWitness (canonical_toE _)
  intro R hR
  rcases List.mem_cons.mp hR with rfl | hR
  · -- the candidate itself: ¬[0 == 1] is the true constant
    exact refutation_of_subst_taut _ _ _ _ (F.unit_nz 1 0)
      (fun α => by have := F.lsum_unit1 α hs 0 (by omega) (by omega); simpa using this)
  · have hR' := hR
    unfold db2 at hR
    simp only [List.mem_append, List.mem_map, List.mem_range'_1] at hR
    rcases hR with (⟨r, hr, rfl⟩ | ⟨j, hj, rfl⟩) | ⟨j, hj, rfl⟩
    · -- an original row
      have hnz : r.nz := nz_of_wf r F.V (F.rows_wf hs r hr)
      have hmem : r.toE ∈ F.db2 F.k := F.toE_mem_db2 F.k r hr
      rcases F.mem_rows r hr with ⟨t, p, ht, hp, rfl | rfl⟩ | ⟨t, c, ht, hc, rfl⟩ |
        ⟨t, p, j, x, ht, hp, hj, hx, rfl⟩ | ⟨t, p, i, x, ht, hp, hi, hx, rfl | rfl⟩ |
        ⟨t, x, a, b, ht, hx, ha, hb, rfl | rfl⟩ | ⟨x, hx, rfl⟩
      · by_cases h01 : t = 0 ∧ p = 1
        · obtain ⟨rfl, rfl⟩ := h01
          exact refutation_of_subst_taut _ _ _ _ hnz (fun α => by rw [F.lsum_row1_01 hs hk α]; exact Int.le_refl _)
        · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row1_fixed t p ht hp h01))
      · by_cases h01 : t = 0 ∧ p = 1
        · obtain ⟨rfl, rfl⟩ := h01
          exact refutation_of_subst_taut _ _ _ _ hnz (fun α => by
            rw [F.lsum_row1'_01 hs hk α]; simp [row1']; omega)
        · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row1'_fixed t p ht hp h01))
      · by_cases h0 : t = 0
        · subst h0
          exact refutation_of_subst_taut _ _ _ _ hnz (fun α => by rw [F.lsum_row2_0 α hs c hc]; simp [row2])
        · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row2_fixed t c ht h0))
      · by_cases h01 : t = 0 ∧ p = 1
        · obtain ⟨rfl, rfl⟩ := h01
          exact refutation_of_subst_taut _ _ _ _ hnz (fun α => by
            have := F.lsum_row3i_01 α hs j x hj hx; simpa [row3i] using this)
        · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row3i_fixed t p j x ht hp hj hx h01))
      · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row3g_fixed t p i x ht hp hi hx))
      · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row3g'_fixed t p i x ht hp hi hx))
      · by_cases h0 : t = 0
        · subst h0
          rw [← F.row4P_true]
          exact F.obligation_row4P hk hs true x a b hx ha hb
        · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row4_fixed t x a b ht hx ha hb h0))
      · by_cases h0 : t = 0
        · subst h0
          rw [← F.row4P_false]
          exact F.obligation_row4P hk hs false x a b hx ha hb
        · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row4'_fixed t x a b ht hx ha hb h0))
      · exact refutation_of_mem _ _ _ hDcan (fixed_mem _ _ _ hnz hmem (F.row5_fixed x hs hx))
    · -- loop-1 unit ¬sel(0,0,j): fixed
      exact refutation_of_mem _ _ _ hDcan
        (fixed_mem _ _ _ (F.unit_nz 0 j) hR' (F.unit0_fixed j hs (by omega)))
    · -- loop-2 unit ¬sel(0,1,j), j ≥ 2: tautology
      exact refutation_of_subst_taut _ _ _ _ (F.unit_nz 1 j)
        (fun α => by have := F.lsum_unit1 α hs j (by omega) (by omega); simpa using this)

/-- database after the constant-witness step -/
def db3 (F : Fam) : List EREF.Row := F.db2 F.k ++ [(F.unitNegSel 1 0).toE]

/-- **the first 2k−2 commands of frontend.py (loops 1, 2 and the constant witness) form a
    checked trace**, for every k ≥ 2, s ≥ 1 and swap-invariant target -/
theorem prefix_trace_with_const (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s)
    (hinv : ∀ a j, a < F.k → j < F.k → a ≠ j → ∀ x, x < F.T → F.b (F.xm a j x) = F.b x) :
    CheckedTrace (F.rows.map Row.toE) F.db3 :=
  checkedTrace_trans (F.normalization_prefix_trace hk hs hinv)
    (CheckedTrace.cons (F.stepC hk hs) (CheckedTrace.refl _))

end Fam

/-- the emitted family: parity, s = 3k − 4, k ≥ 3 -/
theorem parity_prefix_trace_with_const (k : Nat) (hk : 3 ≤ k) :
    EREF.GeneralRED.CheckedTrace ((parityFam k (3 * k - 4)).rows.map Row.toE) (parityFam k (3 * k - 4)).db3 :=
  Fam.prefix_trace_with_const _ (by show 2 ≤ k; omega) (by show 1 ≤ 3 * k - 4; omega)
    (fun a j ha hj haj x hx => parityBit_xm (parityFam k (3 * k - 4)) a j x ha hj haj hx)

end L3

#print axioms L3.Fam.stepC
#print axioms L3.parity_prefix_trace_with_const

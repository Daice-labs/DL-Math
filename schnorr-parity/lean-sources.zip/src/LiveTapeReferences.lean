import NativeRecordedAllocation
namespace L3Emitter.LiveTapeReferences
open EREF EREF.GeneralRED NativeSparseStore

/-- References that occur anywhere in a successful POL tape are live. -/
theorem reads (db : Nat→Option Row) (ts : List Tok) (st : List Row) (out : Row)
    (h : polEval db ts st=some out) :
    ∀i,Tok.ref i∈ts→∃R,db i=some R := by
  induction ts generalizing st with
  | nil => simp
  | cons t ts ih =>
    intro i hi
    rcases List.mem_cons.mp hi with hhead|htail
    · subst t
      simp only [polEval] at h
      split at h
      · rename_i R hr;exact ⟨R,hr⟩
      · simp at h
    · cases t with
      | ref j =>
        simp only [polEval] at h
        split at h
        · exact ih _ h i htail
        · simp at h
      | lit l =>
        simp only [polEval] at h
        split at h
        · exact ih _ h i htail
        · simp at h
      | add =>
        match st with
        | b::a::st => exact ih _ h i htail
        | [] => simp [polEval] at h
        | [_] => simp [polEval] at h
      | mul a =>
        match st with
        | r::st =>
          simp only [polEval] at h
          split at h
          · exact ih _ h i htail
          · simp at h
        | [] => simp [polEval] at h
      | div a =>
        match st with
        | r::st =>
          simp only [polEval] at h
          split at h
          · exact ih _ h i htail
          · simp at h
        | [] => simp [polEval] at h
      | sat =>
        match st with
        | r::st => exact ih _ h i htail
        | [] => simp [polEval] at h

def Bounded (N : Nat) (ts : List Tok) : Prop :=
  ∀i,Tok.ref i∈ts→ 0 < i ∧ i < N

theorem mono (a b : Nat) (ts : List Tok) (h : a≤b) (ht : Bounded a ts) : Bounded b ts := by
  intro i hi;have hh:=ht i hi;exact ⟨hh.1,lt_of_lt_of_le hh.2 h⟩

theorem reindex (D : List Row) (s : Store) (ids : Nat→Nat) (ts : List Tok) (out : Row)
    (he : Embeds D s ids) (ht : polEval (dbOf D) ts []=some out) :
    Bounded s.next (ts.map (ReferenceTransport.token ids)) := by
  intro i hi
  obtain ⟨t,hm,heq⟩:=List.mem_map.mp hi
  cases t <;> simp only [ReferenceTransport.token,Tok.ref.injEq] at heq
  case ref j =>
    subst i
    obtain ⟨R,hR⟩:=reads (dbOf D) ts [] out ht j hm
    exact ⟨(he j R hR).1,(he j R hR).2.1⟩
  all_goals cases heq

/-- Bounds every local tape against the end counter, even if earlier rows
will later be deleted. No parser or machine implementation is assumed. -/
theorem local_tapes (D E : List Row) (s : Store) (ids : Nat→Nat)
    (hs : 0<s.next) (he : Embeds D s ids) (p : AliasProgram.Program)
    (hp : AliasProgram.check D p=some E) :
    ∀ts∈(NativeLocalProgram.compile D.length s ids p).tapes,
      Bounded (s.next+p.length) ts := by
  induction p generalizing D s ids with
  | nil => simp [NativeLocalProgram.compile]
  | cons c p ih =>
    rcases c with ⟨R,ts⟩
    simp only [AliasProgram.check] at hp
    split at hp
    · rename_i ht
      have hi:=ih (D++[R]) (push s R) (extend ids D.length s.next)
        (by change 0<s.next+1;omega) (push_embeds D s ids he hs R) hp
      simp only [List.length_append,List.length_singleton] at hi
      intro tt hmem
      rcases List.mem_cons.mp hmem with rfl|hmem
      · exact mono s.next _ _ (by simp) (reindex D s ids ts R he ht)
      · have hh:=hi tt hmem
        simpa only [push,List.length_cons,Nat.add_assoc,Nat.add_comm 1] using hh
    · contradiction

#print axioms reads
#print axioms reindex
#print axioms local_tapes
end L3Emitter.LiveTapeReferences

import CompleteFinalRowTapes
import ConstructionCoordinateCount
import SelectedValueSize
namespace L3Emitter.CoordinateMainTapes
open EREF EREF.GeneralRED MainTapeRecurrence

theorem gate (D : List Row) (m : Nat) (b : Bool) (xs : List Int) :
    count (RecordedSupportSelection.gate D m b xs)=0 :=
  CompleteFinalRowTapes.gate_zero ..

theorem ands (D : List Row) (m : Nat) (f : Int→Int) (xs : List Int) :
    count (RecordedSupportSelection.ands D m f xs)=0 := by
  induction xs generalizing D m with
  | nil=>rfl
  | cons x xs ih=>simp only [RecordedSupportSelection.ands,append,gate,ih,Nat.add_zero]

theorem selection (D : List Row) (m : Nat) (xs : List Int) (f : Int→Int) :
    count (RecordedSupportSelection.program D m xs f)=8*xs.length^2+xs.length := by
  simp only [RecordedSupportSelection.program,RecordedSupportSelection.definitions,append,ands,gate,
    pol_program,Nat.zero_add]
  exact SelectedValueSize.selected_tokens D m xs f

theorem coordinates (cs : List Int) (f : Int→Nat→Int) (D : List Row) (i m : Nat) :
    count (RecordedCoordinateBank.program cs f D i m)=m*(8*cs.length^2+cs.length) := by
  induction m generalizing D i with
  | zero=>simp [RecordedCoordinateBank.program,count]
  | succ m ih=>
    simp only [RecordedCoordinateBank.program,append,RecordedCoordinateBank.blockProgram,selection,ih]
    ring

theorem raw_run (n : Nat) (hn : 2≤n) (rs : List (RawLowerInputBank.Port n)) (D : List Row) :
    count (RecordedRawLowerInputs.runProgram n hn D rs)=
      rs.length*2^n*(8*(AliasAssembly.width (n+1))^2+AliasAssembly.width (n+1)) := by
  induction rs generalizing D with
  | nil=>simp [RecordedRawLowerInputs.runProgram,count]
  | cons r rs ih=>
    simp only [RecordedRawLowerInputs.runProgram,append,RecordedRawLowerInputs.blockProgram,
      coordinates,SelectedVectorOneHot.sourceLiterals,List.length_ofFn,FamilyNamespace.truthRows,ih,List.length_cons]
    ring

theorem raw (n : Nat) (hn : 2≤n) :
    count (RecordedRawLowerInputs.program n hn)≤792*(n+1)^3*2^n := by
  rw [RecordedRawLowerInputs.program,raw_run,RawInputSize.evaluated_port_count]
  have hr:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  have hsq:=Nat.pow_le_pow_left hw 2
  have hb:8*(AliasAssembly.width (n+1))^2+AliasAssembly.width (n+1)≤132*(n+1)^2:=by nlinarith
  have hp:=Nat.mul_le_mul (Nat.mul_le_mul_left 2 hr) hb
  nlinarith [Nat.mul_le_mul_right (2^n) hp]

theorem tables_run (n : Nat) (hn : 2≤n) (ts : List Nat) (D : List Row) :
    count (RecordedRankTables.runProgram n hn D ts)=ts.length*4*(8*(3*(n+1)-5)^2+(3*(n+1)-5)) := by
  induction ts generalizing D with
  | nil=>simp [RecordedRankTables.runProgram,count]
  | cons t ts ih=>
    simp only [RecordedRankTables.runProgram,append,RecordedRankTables.blockProgram,
      coordinates,ConstructionCoordinateCount.choices,ih,List.length_cons]
    ring

theorem tables (n : Nat) (hn : 2≤n) :
    count (RecordedRankTables.program n hn)≤900*(n+1)^3 := by
  rw [RecordedRankTables.program,tables_run,List.length_range]
  have hr:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hs:3*(n+1)-5≤3*(n+1):=Nat.sub_le ..
  have hsq:=Nat.pow_le_pow_left hs 2
  have hb:8*(3*(n+1)-5)^2+(3*(n+1)-5)≤75*(n+1)^2:=by nlinarith
  nlinarith [Nat.mul_le_mul (Nat.mul_le_mul_right 4 hr) hb]
#print axioms coordinates
#print axioms raw
#print axioms tables
end L3Emitter.CoordinateMainTapes

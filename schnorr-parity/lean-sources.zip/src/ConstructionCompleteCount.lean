import ConstructionFinalCount
namespace L3Emitter.ConstructionCompleteCount
set_option maxRecDepth 2000
set_option maxHeartbeats 800000
open EREF EREF.GeneralRED ConstructionCountTools ConstructionLowerCount

theorem reduction (n : Nat) (hn : 2≤n) : (RecordedCompleteLower.program n hn).length≤420000*Q n := by
  have hq:ConstructionGlobalCount.Q n≤Q n:=Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by omega) (show 5≤6 by omega))
  have h0:= (ConstructionGlobalCount.complete n hn).trans (Nat.mul_le_mul_left 400000 hq)
  have h1:= (ConstructionTableCount.complete n hn).trans (Nat.mul_le_mul_left 6000 hq)
  have h2:=ConstructionLowerCount.complete n hn
  have h3:=ConstructionFinalCount.complete n hn
  simp only [RecordedCompleteLower.program,List.length_append];omega

theorem input_length (n : Nat) (hn : 2≤n) :
    (ActualLowerComposition.inputs n hn).length=(OriginalEncoding.rows n (3*n-4)).length := by
  simp only [ActualLowerComposition.inputs,LowerActivationImage.inputs,OriginalEncoding.rows,List.length_map]

theorem level_prefix (i : Nat) : (CanonicalCountRecurrence.levelPrefix i).length≤421000*(i+4)^6*2^(i+2) := by
  rw [CanonicalFamilyEnvelope.prefix_main,input_length]
  have h:=reduction (i+2) (by omega)
  have hf:=CanonicalFormulaEnvelope.original_rows (i+2)
  have hp:(i+2+1)^2≤(i+4)^6:=(Nat.pow_le_pow_left (by omega) 2).trans (Nat.pow_le_pow_right (by omega) (by omega))
  have hm:=Nat.mul_le_mul_right (2^(i+2)) (Nat.mul_le_mul_left 128 hp)
  have ht:1≤(i+4)^6*2^(i+2):=Nat.mul_pos (Nat.pow_pos (by omega)) (Nat.pow_pos (by omega))
  unfold Q at h
  have he:i+2+2=i+4:=by omega
  rw [he] at h
  nlinarith

theorem base : (RecordedUniformFamily.family 0).length≤1000 := by
  have h:=ConstructionFrontendCount.state_frontend 2 2 (by omega)
  simp only [RecordedUniformFamily.family,RecordedBaseTwo.program,List.length_append,
    ConstructionFrontendCount.recorded_length 2 2 (by omega) (by omega),polProgram_length]
  change 2*2+_+1≤1000
  omega

def mainBound (n : Nat) := 422000*(n+2)^7*2^n

/-- Main commands in the actual canonical recursive emitter. No assumed
level_prefix bound or tail-size parameter remains. Not a byte bound. -/
theorem main (n : Nat) (hn : 2≤n) : (RecordedUniformFamily.emitter n).length≤mainBound n := by
  have hp:∀i<n-2,(CanonicalCountRecurrence.levelPrefix i).length≤421000*(n+2)^6*2^n:=by
    intro i hi
    have h1:(i+4)^6≤(n+2)^6:=Nat.pow_le_pow_left (by omega) 6
    have h2:2^(i+2)≤2^n:=Nat.pow_le_pow_right (by omega) (by omega)
    exact (level_prefix i).trans (Nat.mul_le_mul (Nat.mul_le_mul_left 421000 h1) h2)
  have h:=CanonicalFamilyEnvelope.main_bound (n-2) (421000*(n+2)^6*2^n) hp
  unfold CanonicalFamilyEnvelope.mainBound at h
  have hm:=Nat.mul_le_mul_right (421000*(n+2)^6*2^n) (show n-2≤n+2 by omega)
  have ht:1≤(n+2)^7*2^n:=Nat.mul_pos (Nat.pow_pos (by omega)) (Nat.pow_pos (by omega))
  change (RecordedUniformFamily.family (n-2)).length≤_
  unfold mainBound
  have hb:=base
  calc
    _ ≤ 1000+(n+2)*(421000*(n+2)^6*2^n) := by omega
    _ = 1000+421000*((n+2)^7*2^n) := by ring
    _ ≤ _ := by nlinarith
#print axioms reduction
#print axioms level_prefix
#print axioms main
end L3Emitter.ConstructionCompleteCount

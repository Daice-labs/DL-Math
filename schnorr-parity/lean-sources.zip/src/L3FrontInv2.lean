/-
Stage 2 establishes PP0 and PElig, stage 3 establishes PA; `good3_stage3` bundles the
whole stage-0–3 database description.
-/
import L3FrontInv

set_option maxHeartbeats 400000

namespace L3
open EREF EREF.GeneralRED

namespace Fam
variable (F : Fam)
open StI

/-! ### Stage 2 establishes PP0 and PElig -/

theorem eqStep_p0force (hm : 1 ≤ F.V) (g port : Nat) (acc : StI F.V × List Int) (b : Nat) :
    (F.eqStep hm g port acc b).1.s.p0force = acc.1.s.p0force := by
  obtain ⟨t, eqs⟩ := acc; rfl
theorem eqStep_eligible (hm : 1 ≤ F.V) (g port : Nat) (acc : StI F.V × List Int) (b : Nat) :
    (F.eqStep hm g port acc b).1.s.eligible = acc.1.s.eligible := by
  obtain ⟨t, eqs⟩ := acc; rfl

theorem portStep_p0force_other (hm : 1 ≤ F.V) (g' : Nat) (acc : StI F.V × List Int) (port' : Nat)
    (g port : Nat) (hne : ¬ (g' = g ∧ port' = port)) :
    (F.portStep hm g' acc port').1.s.p0force g port = acc.1.s.p0force g port := by
  obtain ⟨t, ports⟩ := acc
  have hne' : ¬ (g = g' ∧ port = port') := fun h => hne ⟨h.1.symm, h.2.symm⟩
  simp only [portStep, StI.setP0force, StI.AND, StI.setForce, StI.OR, St.AND, St.OR, List.foldl_cons,
    List.foldl_nil, hne', ↓reduceIte]
  rw [F.eqStep_p0force, F.eqStep_p0force]

theorem portStep_eligible (hm : 1 ≤ F.V) (g' : Nat) (acc : StI F.V × List Int) (port' : Nat) :
    (F.portStep hm g' acc port').1.s.eligible = acc.1.s.eligible := by
  obtain ⟨t, ports⟩ := acc
  simp only [portStep, StI.setP0force, StI.AND, StI.setForce, StI.OR, St.AND, St.OR, List.foldl_cons,
    List.foldl_nil]
  rw [F.eqStep_eligible, F.eqStep_eligible]

/-- the port step returns its p0force name at the end of the accumulator -/
theorem portStep_snd (hm : 1 ≤ F.V) (g : Nat) (acc : StI F.V × List Int) (port : Nat) :
    (F.portStep hm g acc port).2 = acc.2 ++ [((F.portStep hm g acc port).1.s.p0force g port : Int)] := by
  obtain ⟨t, ports⟩ := acc
  simp [portStep, StI.setP0force, StI.AND, StI.setForce, StI.OR, St.AND, St.OR]

theorem eligStep_p0force_other (hm : 1 ≤ F.V) (t : StI F.V) (g' : Nat) (g port : Nat) (hne : g' ≠ g) :
    (F.eligStep hm t g').s.p0force g port = t.s.p0force g port := by
  show (([0, 1].foldl (F.portStep hm g') (t, [])).1).s.p0force g port = _
  simp only [List.foldl_cons, List.foldl_nil]
  rw [F.portStep_p0force_other hm g' _ 1 g port (by omega), F.portStep_p0force_other hm g' _ 0 g port (by omega)]

theorem eligStep_eligible_other (hm : 1 ≤ F.V) (t : StI F.V) (g' : Nat) (g : Nat) (hne : g' ≠ g) :
    (F.eligStep hm t g').s.eligible g = t.s.eligible g := by
  show (if g = g' then _ else (([0, 1].foldl (F.portStep hm g') (t, [])).1).s.eligible g) = _
  have : g ≠ g' := fun e => hne e.symm
  simp only [this, ↓reduceIte, List.foldl_cons, List.foldl_nil]
  rw [F.portStep_eligible, F.portStep_eligible]

/-- the port step of (g, port) establishes PP0 (g, port) -/
theorem portStep_establishes_p0 (hm : 1 ≤ F.V) (g port : Nat) (hg1 : 1 ≤ g) (hg : g < F.s) (hp : port < 2)
    (acc : StI F.V × List Int) : F.PP0 g port (F.portStep hm g acc port).1 := by
  obtain ⟨t, ports⟩ := acc
  have hV := t.var_ge
  have hS := F.S_le_V
  have hsel := F.sel_le_S g port 0 hg (by omega) (by omega)
  have hselpos := F.sel_pos g port 0
  have c1 : 1 ≤ ((F.sel g port 0 : Nat) : Int).natAbs ∧ ((F.sel g port 0 : Nat) : Int).natAbs ≤ t.s.var + 1 + 1 + 1 := by
    simp; omega
  have c2 : 1 ≤ ((t.s.var + 1 + 1 + 1 : Nat) : Int).natAbs ∧ ((t.s.var + 1 + 1 + 1 : Nat) : Int).natAbs ≤ t.s.var + 1 + 1 + 1 := by
    omega
  simp only [PP0, portStep, eqStep, StI.setP0force, StI.AND, StI.setForce, StI.OR, StI.setEqrow, StI.EQ,
    St.AND, St.OR, St.EQ, List.foldl_cons, List.foldl_nil, List.nil_append, List.singleton_append,
    List.cons_append, List.append_assoc, and_self, ↓reduceIte]
  refine ⟨?_, ?_, ?_⟩
  · simp only [St.chk, List.filter, c1, c2, and_self, decide_true, List.mem_append, List.mem_cons]
    simp
  · omega
  · omega

theorem eligStep_establishes_p0 (hm : 1 ≤ F.V) (g port : Nat) (hg1 : 1 ≤ g) (hg : g < F.s) (hp : port < 2)
    (t : StI F.V) : F.PP0 g port (F.eligStep hm t g) := by
  have hfold : F.PP0 g port (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1 := by
    have hp' : port = 0 ∨ port = 1 := by omega
    rcases hp' with rfl | rfl
    · exact F.PP0_of_grows (F.portStep_grows hm g _ 1)
        (F.portStep_p0force_other hm g _ 1 g 0 (by omega)) (F.portStep_force_other hm g _ 1 g 0 (by omega))
        (F.portStep_establishes_p0 hm g 0 hg1 hg (by omega) _)
    · exact F.portStep_establishes_p0 hm g 1 hg1 hg (by omega) _
  show F.PP0 g port (((([0, 1].foldl (F.portStep hm g) (t, [])).1.OR _).2.AND _).2.setEligible _)
  simp only [List.foldl_cons, List.foldl_nil]
  apply F.PP0_of_grows _ _ _ hfold
  · exact StI.growsTo_trans (StI.growsTo_OR _ _) (StI.growsTo_trans (StI.growsTo_AND _ _) (StI.growsTo_setEligible _ _))
  · rfl
  · rfl

/-- The final two definitions, isolated from the port-building folds. -/
def eligFinish (g : Nat) (t : StI F.V) : StI F.V :=
  let (cons,t') := t.OR [(t.s.p0force g 0 : Int),(t.s.p0force g 1 : Int)]
  let (el,t'') := t'.AND [(t'.s.live g : Int),(cons : Int)]
  t''.setEligible fun g' => if g'=g then el else t''.s.eligible g'

theorem eligFinish_establishes (g : Nat) (t' : StI F.V)
    (hP0 : F.PP0 g 0 t') (hP1 : F.PP0 g 1 t')
    (hlive' : F.V < t'.s.live g ∧ t'.s.live g ≤ t'.s.var) :
    F.PElig g (F.eligFinish g t') := by
  have hVt := t'.var_ge
  have hchk1 : t'.s.chk [(t'.s.p0force g 0 : Int), (t'.s.p0force g 1 : Int)] = [(t'.s.p0force g 0 : Int), (t'.s.p0force g 1 : Int)] := by
    apply StI.chk_eq
    intro l hl
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
    have := hP0.2; have := hP1.2
    rcases hl with rfl | rfl <;> simp <;> omega
  have hchk2 : (t'.OR [(t'.s.p0force g 0 : Int), (t'.s.p0force g 1 : Int)]).2.s.chk [(t'.s.live g : Int), ((t'.s.var + 1 : Nat) : Int)] = [(t'.s.live g : Int), ((t'.s.var + 1 : Nat) : Int)] := by
    apply StI.chk_eq
    intro l hl
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
    show _ ∧ _ ≤ t'.s.var + 1
    rcases hl with rfl | rfl <;> simp <;> omega
  simp only [PElig, eligFinish, StI.setEligible, StI.OR, StI.AND, St.OR, St.AND, ↓reduceIte]
  refine ⟨t'.s.var + 1, ?_, ?_, by omega, ?_, ?_⟩
  · show Cmd.orDef (t'.s.var + 1) _ ∈ t'.s.cmds ++ [Cmd.orDef (t'.s.var + 1) (t'.s.chk _)] ++ [_]
    rw [hchk1]; simp
  · show Cmd.andDef (t'.s.var + 1 + 1) _ ∈ t'.s.cmds ++ [Cmd.orDef (t'.s.var + 1) (t'.s.chk _)] ++
      [Cmd.andDef (t'.s.var + 1 + 1) ((t'.OR [(t'.s.p0force g 0 : Int), (t'.s.p0force g 1 : Int)]).2.s.chk [(t'.s.live g : Int), ((t'.s.var + 1 : Nat) : Int)])]
    rw [hchk2]; simp
  · omega
  · omega

theorem eligStep_establishes_elig (hm : 1 ≤ F.V) (g : Nat) (hg1 : 1 ≤ g) (hg : g < F.s) (t : StI F.V)
    (hlive : F.V < t.s.live g ∧ t.s.live g ≤ t.s.var) : F.PElig g (F.eligStep hm t g) := by
  -- the two port steps
  have hP0 : F.PP0 g 0 (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1 :=
    F.PP0_of_grows (F.portStep_grows hm g _ 1)
      (F.portStep_p0force_other hm g _ 1 g 0 (by omega)) (F.portStep_force_other hm g _ 1 g 0 (by omega))
      (F.portStep_establishes_p0 hm g 0 hg1 hg (by omega) _)
  have hP1 : F.PP0 g 1 (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1 :=
    F.portStep_establishes_p0 hm g 1 hg1 hg (by omega) _
  have hports : (F.portStep hm g (F.portStep hm g (t, []) 0) 1).2 =
      [((F.portStep hm g (F.portStep hm g (t, []) 0) 1).1.s.p0force g 0 : Int),
       ((F.portStep hm g (F.portStep hm g (t, []) 0) 1).1.s.p0force g 1 : Int)] := by
    rw [F.portStep_snd hm g _ 1, F.portStep_snd hm g _ 0, F.portStep_p0force_other hm g _ 1 g 0 (by omega)]
    rfl
  have hlive' : F.V < (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1.s.live g ∧
      (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1.s.live g ≤ (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1.s.var := by
    have k := keeps1_trans (F.keeps1_portStep hm g (t, []) 0) (F.keeps1_portStep hm g _ 1)
    rw [k.2.1]
    exact ⟨hlive.1, Nat.le_trans hlive.2 (StI.var_le_of_grows k.1)⟩
  have hfinish := F.eligFinish_establishes g
    (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1 hP0 hP1 hlive'
  simpa only [eligStep, List.foldl_cons, List.foldl_nil, hports, eligFinish] using hfinish

/-- **stage 2 establishes every PP0 and PElig** -/
theorem stage2_PP0 (hm : 1 ≤ F.V) (t : StI F.V) (g port : Nat) (hg1 : 1 ≤ g) (hg : g < F.s)
    (hp : port < 2) : F.PP0 g port (F.stage2 hm t) := by
  unfold stage2
  have hmem : g ∈ List.range' 1 (F.s - 1) := List.mem_range'_1.mpr ⟨hg1, by omega⟩
  obtain ⟨l1, l2, hl, hfold⟩ := foldl_split (F.eligStep hm) _ g hmem
  rw [hfold t]
  have hnd : (List.range' 1 (F.s - 1)).Nodup := List.nodup_range' (step := 1)
  rw [hl] at hnd
  have hg_not : g ∉ l2 := (List.nodup_cons.mp (List.nodup_append.mp hnd).2.1).1
  apply foldl_pres (F.PP0 g port) (F.eligStep hm) l2
  · intro g' hg' t' h
    have hne : g' ≠ g := fun e => hg_not (e ▸ hg')
    exact F.PP0_of_grows (F.eligStep_grows hm t' g') (F.eligStep_p0force_other hm t' g' g port hne)
      (F.eligStep_force_other hm t' g' g port hne) h
  · exact F.eligStep_establishes_p0 hm g port hg1 hg hp _

theorem stage2_PElig (hm : 1 ≤ F.V) (t : StI F.V) (g : Nat) (hg1 : 1 ≤ g) (hg : g < F.s)
    (hlive : F.V < t.s.live g ∧ t.s.live g ≤ t.s.var) : F.PElig g (F.stage2 hm t) := by
  unfold stage2
  have hmem : g ∈ List.range' 1 (F.s - 1) := List.mem_range'_1.mpr ⟨hg1, by omega⟩
  obtain ⟨l1, l2, hl, hfold⟩ := foldl_split (F.eligStep hm) _ g hmem
  rw [hfold t]
  have hnd : (List.range' 1 (F.s - 1)).Nodup := List.nodup_range' (step := 1)
  rw [hl] at hnd
  have hg_not : g ∉ l2 := (List.nodup_cons.mp (List.nodup_append.mp hnd).2.1).1
  apply foldl_pres (F.PElig g) (F.eligStep hm) l2
  · intro g' hg' t' h
    have hne : g' ≠ g := fun e => hg_not (e ▸ hg')
    exact F.PElig_of_grows (F.eligStep_grows hm t' g') (fun port => F.eligStep_p0force_other hm t' g' g port hne)
      (by rw [(F.keeps1_eligStep hm t' g').2.1]) (F.eligStep_eligible_other hm t' g' g hne) h
  · apply F.eligStep_establishes_elig hm g hg1 hg
    have k := StI.keeps1_foldl (F.eligStep hm) l1 (fun t' g' => F.keeps1_eligStep hm t' g') t
    rw [k.2.1]
    exact ⟨hlive.1, Nat.le_trans hlive.2 (StI.var_le_of_grows k.1)⟩

/-! ### Stage 3 establishes PA -/

theorem stage3_PA (t : StI F.V) (helig : ∀ g, 1 ≤ g → g < F.s → F.V < t.s.eligible g ∧ t.s.eligible g ≤ t.s.var) :
    F.PA (F.stage3 t) := by
  have hVt := t.var_ge
  have hchk : t.s.chk ((List.range' 1 (F.s - 1)).map fun g => (t.s.eligible g : Int))
      = (List.range' 1 (F.s - 1)).map fun g => (t.s.eligible g : Int) := by
    apply StI.chk_eq
    intro l hl
    simp only [List.mem_map, List.mem_range'_1] at hl
    obtain ⟨g, hg, rfl⟩ := hl
    have := helig g hg.1 (by omega)
    simp; omega
  refine ⟨?_, ?_, ?_⟩
  · show Cmd.orDef (t.s.var + 1) _ ∈ t.s.cmds ++ [Cmd.orDef (t.s.var + 1) (t.s.chk _)]
    rw [hchk]
    apply List.mem_append_right
    apply List.mem_singleton.mpr
    rfl
  · show F.V < t.s.var + 1; omega
  · show t.s.var + 1 ≤ t.s.var + 1; exact Nat.le_refl _

/-- **after stage 3 every definition of stages 0–3 is recorded** -/
theorem good3_stage3 (hs : 1 ≤ F.s) : F.Good3 (F.stage3 (F.stage2 (F.V_pos hs) (F.stage1 F.stage0))) := by
  have hm := F.V_pos hs
  have h1 := F.stage1_inv1 hs
  have k2 := F.keeps1_stage2 hm (F.stage1 F.stage0)
  have k3 := F.keeps1_stage3 (F.stage2 hm (F.stage1 F.stage0))
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · exact F.PLiveLast_of_keeps1 k3 (F.PLiveLast_of_keeps1 k2 h1.1)
  · intro g hg
    obtain ⟨p1, p2⟩ := h1.2 g (by omega) hg
    exact ⟨F.PLive_of_keeps1 k3 (F.PLive_of_keeps1 k2 p1),
      fun hp hhp => F.PEdge_of_keeps1 k3 (F.PEdge_of_keeps1 k2 (p2 hp hhp))⟩
  · intro g port hg1 hg hp
    have k3' := F.keeps_stage3 (F.stage2 hm (F.stage1 F.stage0))
    refine ⟨?_, ?_, ?_, ?_⟩
    · exact F.PEq_of_grows k3'.1 (by rw [k3'.2.1]) (F.stage2_PEq hm _ g port 0 hg1 hg hp (by omega))
    · exact F.PEq_of_grows k3'.1 (by rw [k3'.2.1]) (F.stage2_PEq hm _ g port 1 hg1 hg hp (by omega))
    · exact F.PForce_of_grows k3'.1 (fun b => by rw [k3'.2.1]) (by rw [k3'.2.2]) (F.stage2_PForce hm _ g port hg1 hg hp)
    · exact F.PP0_of_grows k3'.1 rfl (by rw [k3'.2.2]) (F.stage2_PP0 hm _ g port hg1 hg hp)
  · intro g hg1 hg
    have hl := F.inv1_live_bound h1 g (by omega) hg
    have hE := F.stage2_PElig hm _ g hg1 hg hl
    exact F.PElig_of_grows k3.1 (fun port => rfl) (by rw [k3.2.1]) rfl hE
  · apply F.stage3_PA
    intro g hg1 hg
    have hl := F.inv1_live_bound h1 g (by omega) hg
    obtain ⟨cons, _, _, _, h4, h5⟩ := F.stage2_PElig hm _ g hg1 hg hl
    exact ⟨h4, h5⟩

end Fam
end L3

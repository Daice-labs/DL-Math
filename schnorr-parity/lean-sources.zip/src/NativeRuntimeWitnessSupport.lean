import NativeRuntimeSupport
namespace L3Emitter.NativeRuntimeSupport
open EREF EREF.GeneralRED

def SemanticImageVars (K:Nat):EREF.GeneralRED.Image→Prop
 | .literal l _=>l.natAbs≤K
 | .constant _=>True
 theorem flip_vars (K:Nat) (i:EREF.GeneralRED.Image) (hi:SemanticImageVars K i):SemanticImageVars K i.flip:=by
 cases i <;> simpa [SemanticImageVars,EREF.GeneralRED.Image.flip] using hi
 theorem interpret_image_vars (K:Nat) (i:L3Emitter.Image) (hi:ImageVars K i):
 SemanticImageVars K (FiniteWitness.interpretImage i):=by
 cases i with
 | bit b=>trivial
 | lit l=>
   simp only [FiniteWitness.interpretImage]
   split
   · trivial
   · change (FiniteWitness.literalId l).natAbs≤K
     unfold FiniteWitness.literalId
     split <;> simpa using hi
 theorem interpret_vars (K:Nat) (w:FiniteWitness.Data) (hw:WitnessVars K w) (v:Nat) (hv:v≤K):
 SemanticImageVars K (FiniteWitness.interpret w v):=by
 induction w with
 | nil=>unfold FiniteWitness.interpret FiniteWitness.identity;split
        · trivial
        · simpa [SemanticImageVars] using hv
 | cons p w ih=>
   unfold FiniteWitness.interpret
   split
   · exact interpret_image_vars K p.2 (hw p (by simp))
   · exact ih (fun p hp=>hw p (by simp [hp]))
 theorem image_of_vars (K:Nat) (w:FiniteWitness.Data) (hw:WitnessVars K w) (l:Int) (hl:l.natAbs≤K):
 SemanticImageVars K (imageOf (FiniteWitness.interpret w) l):=by
 unfold imageOf;split
 · exact interpret_vars K w hw l.natAbs hl
 · exact flip_vars K _ (interpret_vars K w hw l.natAbs hl)
 theorem raw_vars (K:Nat) (i:EREF.GeneralRED.Image) (a:Nat) (hi:SemanticImageVars K i):
 ∀t∈i.raw a,t.2.natAbs≤K:=by
 cases i with
 | constant b=>simp [EREF.GeneralRED.Image.raw]
 | literal l hz=>intro t ht;obtain rfl:=List.mem_singleton.mp ht;exact hi
 theorem raw_terms_vars (K:Nat) (w:FiniteWitness.Data) (hw:WitnessVars K w)
 (ts:List (Nat×Int)) (ht:∀t∈ts,t.2.natAbs≤K):
 ∀t∈rawTerms (FiniteWitness.interpret w) ts,t.2.natAbs≤K:=by
 induction ts with
 | nil=>simp [rawTerms]
 | cons p ts ih=>
   intro t ht'
   rcases List.mem_append.mp ht' with h|h
   · exact raw_vars K _ p.1 (image_of_vars K w hw p.2 (ht p (by simp))) t h
   · exact ih (fun p hp=>ht p (by simp [hp])) t h
 theorem substitution_vars (K:Nat) (w:FiniteWitness.Data) (hw:WitnessVars K w) (R:Row) (hr:RowVars K R):
 RowVars K (substRow R (FiniteWitness.interpret w)):=
 normalize_vars K _ _ (raw_terms_vars K w hw R.terms hr)
 theorem residual_vars (K:Nat) (w:FiniteWitness.Data) (hw:WitnessVars K w) (ls:List Int)
 (hl:∀l∈ls,l.natAbs≤K):∀t∈PinnedClauseSubstitution.residual (FiniteWitness.interpret w) ls,t.2.natAbs≤K:=by
 induction ls with
 | nil=>simp [PinnedClauseSubstitution.residual]
 | cons l ls ih=>
   have h:=image_of_vars K w hw l (hl l (by simp))
   simp only [PinnedClauseSubstitution.residual]
   cases he:imageOf (FiniteWitness.interpret w) l with
   | literal v hv=>
     rw [he] at h
     intro t ht;rcases List.mem_cons.mp ht with rfl|ht
     · exact h
     · exact ih (fun l hl'=>hl l (by simp [hl'])) t ht
   | constant b=>exact ih (fun l hl'=>hl l (by simp [hl']))
 theorem native_substitution_vars (K:Nat) (w:FiniteWitness.Data) (hw:WitnessVars K w) (R:Row) (hr:RowVars K R):
 RowVars K (PinnedSubstitution.substitute R (FiniteWitness.interpret w)):=by
 unfold PinnedSubstitution.substitute
 split
 · unfold PinnedClauseSubstitution.native
   rw [PinnedNormalization.exact _ _ (PinnedClauseSubstitution.residual_nonzero (FiniteWitness.interpret w) (R.terms.map Prod.snd))]
   apply normalize_vars
   intro t ht;obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht
   exact residual_vars K w hw _ (by intro l hl;obtain ⟨v,hv,rfl⟩:=List.mem_map.mp hl;exact hr v hv) u hu
 · rw [PinnedSubstitution.general_exact]
   exact substitution_vars K w hw R hr
 theorem native_substitution_canonical (R:Row) (w:FiniteWitness.Data):
 Canonical (PinnedSubstitution.substitute R (FiniteWitness.interpret w)):=by
 unfold PinnedSubstitution.substitute
 split
 · exact PinnedStashVector.canonical _ _ (PinnedClauseSubstitution.residual_nonzero _ _)
 · rw [PinnedSubstitution.general_exact];exact canonical_substRow _ _
#print axioms native_substitution_vars
end L3Emitter.NativeRuntimeSupport

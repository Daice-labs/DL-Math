/-
The input bits of the truth-table rows compared by frontend.py: stage 5 compares
`x = (T/4)·bit` with `y = x + T/2` (x₀ = 0 vs 1, x₁ = bit, other inputs 0) and stage 6
compares `x = (T/2)·b` with `y = x + T/4` (x₀ = b, x₁ = 0 vs 1). Also: the popcount
parity differs on each pair.
-/
import L3FrontendX
import L3Parity

namespace L3
namespace Fam
variable (F : Fam)

theorem T_eq_pow2 : F.T = 2 ^ F.k := rfl

theorem T_div4 (hk : 2 ≤ F.k) : F.T / 4 = 2 ^ (F.k - 2) := by
  unfold T
  have : (4 : Nat) = 2 ^ 2 := by decide
  rw [this, Nat.pow_div hk (by omega)]

theorem T_div2 (hk : 1 ≤ F.k) : F.T / 2 = 2 ^ (F.k - 1) := by
  unfold T
  have : (2 : Nat) = 2 ^ 1 := by decide
  conv => lhs; rw [this]
  rw [Nat.pow_div hk (by omega)]

theorem two_pow_pred_lt (k : Nat) (hk : 1 ≤ k) : 2 ^ (k - 1) < 2 ^ k := by
  apply Nat.pow_lt_pow_right (by omega) (by omega)

theorem two_pow_sub2_lt_sub1 (k : Nat) (hk : 2 ≤ k) : 2 ^ (k - 2) < 2 ^ (k - 1) := by
  apply Nat.pow_lt_pow_right (by omega) (by omega)

theorem two_pow_sub2_double (k : Nat) (hk : 2 ≤ k) : 2 ^ (k - 2) + 2 ^ (k - 2) = 2 ^ (k - 1) := by
  have : k - 1 = (k - 2) + 1 := by omega
  rw [this, Nat.pow_succ]; omega

theorem two_pow_sub1_double (k : Nat) (hk : 1 ≤ k) : 2 ^ (k - 1) + 2 ^ (k - 1) = 2 ^ k := by
  have : k = (k - 1) + 1 := by omega
  conv => rhs; rw [this]
  rw [Nat.pow_succ]; omega

/-! ### Stage 5 rows -/

theorem bitX_eq (hk : 2 ≤ F.k) (bit : Nat) : F.bitX bit = 2 ^ (F.k - 2) * bit := by
  unfold bitX; rw [F.T_div4 hk]

theorem bitY_eq (hk : 2 ≤ F.k) (bit : Nat) : F.bitY bit = 2 ^ (F.k - 1) + 2 ^ (F.k - 2) * bit := by
  unfold bitY; rw [F.bitX_eq hk, F.T_div2 (by omega)]; omega

theorem bitX_lt_half (hk : 2 ≤ F.k) (bit : Nat) (hb : bit < 2) : F.bitX bit < 2 ^ (F.k - 1) := by
  rw [F.bitX_eq hk]
  have := two_pow_sub2_lt_sub1 F.k hk
  have := two_pow_sub2_double F.k hk
  rcases (by omega : bit = 0 ∨ bit = 1) with rfl | rfl <;> omega

theorem bitX_lt (hk : 2 ≤ F.k) (bit : Nat) (hb : bit < 2) : F.bitX bit < F.T := by
  have := F.bitX_lt_half hk bit hb
  have := two_pow_pred_lt F.k (by omega)
  unfold T; omega

theorem bitY_lt (hk : 2 ≤ F.k) (bit : Nat) (hb : bit < 2) : F.bitY bit < F.T := by
  have := F.bitX_lt_half hk bit hb
  have := two_pow_sub1_double F.k (by omega)
  unfold bitY; rw [F.T_div2 (by omega)]; unfold T; omega

theorem bitY_eq_add (hk : 2 ≤ F.k) (bit : Nat) : F.bitY bit = 2 ^ (F.k - 1) + F.bitX bit := by
  unfold bitY; rw [F.T_div2 (by omega)]; omega

/-- input 0 (the top bit) of x is 0 -/
theorem inputBit_bitX_0 (hk : 2 ≤ F.k) (bit : Nat) (hb : bit < 2) : F.inputBit 0 (F.bitX bit) = false := by
  unfold inputBit
  simp only [Nat.sub_zero]
  exact Nat.testBit_lt_two_pow (F.bitX_lt_half hk bit hb)

/-- input 0 of y is 1 -/
theorem inputBit_bitY_0 (hk : 2 ≤ F.k) (bit : Nat) (hb : bit < 2) : F.inputBit 0 (F.bitY bit) = true := by
  unfold inputBit
  simp only [Nat.sub_zero]
  rw [F.bitY_eq_add hk, Nat.testBit_two_pow_add_eq, Nat.testBit_lt_two_pow (F.bitX_lt_half hk bit hb)]
  rfl

/-- every other input agrees on x and y -/
theorem inputBit_bitY_j (hk : 2 ≤ F.k) (bit j : Nat) (hj1 : 1 ≤ j) (hj : j < F.k) :
    F.inputBit j (F.bitY bit) = F.inputBit j (F.bitX bit) := by
  unfold inputBit
  rw [F.bitY_eq_add hk, Nat.testBit_two_pow_add_gt (by omega)]

/-- input 1 of x is `bit` -/
theorem inputBit_bitX_1 (hk : 2 ≤ F.k) (bit : Nat) (hb : bit < 2) : F.inputBit 1 (F.bitX bit) = decide (bit = 1) := by
  unfold inputBit
  rw [F.bitX_eq hk, Nat.testBit_two_pow_mul]
  have : F.k - 1 - 1 = F.k - 2 := by omega
  rw [this]
  simp only [ge_iff_le, Nat.le_refl, decide_true, Bool.true_and, Nat.sub_self, Nat.testBit_zero]
  rcases (by omega : bit = 0 ∨ bit = 1) with rfl | rfl <;> simp

theorem inputBit_bitY_1 (hk : 2 ≤ F.k) (bit : Nat) (hb : bit < 2) : F.inputBit 1 (F.bitY bit) = decide (bit = 1) := by
  rw [F.inputBit_bitY_j hk bit 1 (by omega) (by omega), F.inputBit_bitX_1 hk bit hb]

/-! ### Stage 6 rows -/

theorem outX_eq (hk : 2 ≤ F.k) (b : Nat) : F.outX b = 2 ^ (F.k - 1) * b := by
  unfold outX; rw [F.T_div2 (by omega)]

theorem outY_eq (hk : 2 ≤ F.k) (b : Nat) : F.outY b = 2 ^ (F.k - 1) * b + 2 ^ (F.k - 2) := by
  unfold outY; rw [F.outX_eq hk, F.T_div4 hk]

theorem outX_lt (hk : 2 ≤ F.k) (b : Nat) (hb : b < 2) : F.outX b < F.T := by
  rw [F.outX_eq hk]
  have := two_pow_pred_lt F.k (by omega)
  have := Nat.two_pow_pos F.k
  unfold T; rcases (by omega : b = 0 ∨ b = 1) with rfl | rfl <;> omega

theorem outY_lt (hk : 2 ≤ F.k) (b : Nat) (hb : b < 2) : F.outY b < F.T := by
  rw [F.outY_eq hk]
  have := two_pow_sub2_lt_sub1 F.k hk
  have := two_pow_sub1_double F.k (by omega)
  have := two_pow_sub2_double F.k hk
  unfold T; rcases (by omega : b = 0 ∨ b = 1) with rfl | rfl <;> omega

theorem inputBit_outX_0 (hk : 2 ≤ F.k) (b : Nat) (hb : b < 2) : F.inputBit 0 (F.outX b) = decide (b = 1) := by
  unfold inputBit
  rw [F.outX_eq hk, Nat.testBit_two_pow_mul]
  simp only [Nat.sub_zero, ge_iff_le, Nat.le_refl, decide_true, Bool.true_and, Nat.sub_self, Nat.testBit_zero]
  rcases (by omega : b = 0 ∨ b = 1) with rfl | rfl <;> simp

theorem inputBit_outY_0 (hk : 2 ≤ F.k) (b : Nat) (hb : b < 2) : F.inputBit 0 (F.outY b) = decide (b = 1) := by
  unfold inputBit
  rw [F.outY_eq hk]
  simp only [Nat.sub_zero]
  have hlt := two_pow_sub2_lt_sub1 F.k hk
  rcases (by omega : b = 0 ∨ b = 1) with rfl | rfl
  · simp only [Nat.mul_zero, Nat.zero_add, decide_eq_false, Nat.zero_ne_one, not_false_eq_true]
    exact Nat.testBit_lt_two_pow hlt
  · simp only [Nat.mul_one, decide_eq_true]
    rw [Nat.testBit_two_pow_add_eq, Nat.testBit_lt_two_pow hlt]; rfl

theorem inputBit_outX_1 (hk : 2 ≤ F.k) (b : Nat) (hb : b < 2) : F.inputBit 1 (F.outX b) = false := by
  unfold inputBit
  rw [F.outX_eq hk, Nat.testBit_two_pow_mul]
  have : ¬ (F.k - 1 - 1 ≥ F.k - 1) := by omega
  simp [this]

theorem inputBit_outY_1 (hk : 2 ≤ F.k) (b : Nat) (hb : b < 2) : F.inputBit 1 (F.outY b) = true := by
  unfold inputBit
  rw [F.outY_eq hk]
  have e : F.k - 1 - 1 = F.k - 2 := by omega
  rw [e]
  rcases (by omega : b = 0 ∨ b = 1) with rfl | rfl
  · simp only [Nat.mul_zero, Nat.zero_add]; exact Nat.testBit_two_pow_self
  · simp only [Nat.mul_one]
    rw [Nat.testBit_two_pow_add_gt (by omega)]; exact Nat.testBit_two_pow_self

end Fam

/-! ### Parity flips under a single-bit increment -/

theorem parityBit_unfold (x : Nat) (hx : x ≠ 0) : parityBit x = ((x % 2 == 1) != parityBit (x / 2)) := by
  rw [parityBit]; simp [hx]

theorem parityBit_zero : parityBit 0 = false := by rw [parityBit]; simp

theorem parityBit_two_pow_add (i : Nat) : ∀ x, x < 2 ^ i → parityBit (2 ^ i + x) = !parityBit x := by
  induction i with
  | zero =>
    intro x hx
    have : x = 0 := by simp at hx; omega
    subst this
    rw [parityBit_zero, parityBit_unfold 1 (by omega)]; simp [parityBit_zero]
  | succ i ih =>
    intro x hx
    have hne : 2 ^ (i + 1) + x ≠ 0 := by have := Nat.two_pow_pos (i + 1); omega
    rw [parityBit_unfold _ hne]
    have h1 : (2 ^ (i + 1) + x) % 2 = x % 2 := by rw [Nat.pow_succ]; omega
    have h2 : (2 ^ (i + 1) + x) / 2 = 2 ^ i + x / 2 := by rw [Nat.pow_succ]; omega
    rw [h1, h2, ih (x / 2) (by rw [Nat.pow_succ] at hx; omega)]
    by_cases hx0 : x = 0
    · subst hx0; simp [parityBit_zero]
    · rw [parityBit_unfold x hx0]
      cases parityBit (x / 2) <;> cases (x % 2 == 1) <;> rfl

namespace Fam
variable (F : Fam)

theorem parity_bitXY (hk : 2 ≤ F.k) (bit : Nat) (hb : bit < 2) :
    parityBit (F.bitY bit) = !parityBit (F.bitX bit) := by
  rw [F.bitY_eq_add hk]
  exact parityBit_two_pow_add _ _ (F.bitX_lt_half hk bit hb)

theorem parity_outXY (hk : 2 ≤ F.k) (b : Nat) (hb : b < 2) :
    parityBit (F.outY b) = !parityBit (F.outX b) := by
  rw [F.outY_eq hk, F.outX_eq hk]
  have hlt := two_pow_sub2_lt_sub1 F.k hk
  have h0 : 0 < 2 ^ (F.k - 2) := Nat.two_pow_pos _
  rcases (by omega : b = 0 ∨ b = 1) with rfl | rfl
  · simp only [Nat.mul_zero, Nat.zero_add]
    have := parityBit_two_pow_add (F.k - 2) 0 h0
    rw [Nat.add_zero] at this; rw [this]
  · simp only [Nat.mul_one]
    rw [parityBit_two_pow_add _ _ hlt]
    have := parityBit_two_pow_add (F.k - 2) 0 h0
    rw [Nat.add_zero] at this; rw [this]
    have := parityBit_two_pow_add (F.k - 1) 0 (Nat.two_pow_pos _)
    rw [Nat.add_zero] at this; rw [this]

end Fam
end L3

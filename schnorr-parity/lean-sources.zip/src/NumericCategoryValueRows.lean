import NumericUnaryValueRows
namespace L3Emitter.NumericCategoryValueRows
open EREF EREF.GeneralRED REDWitness AliasNetwork NumericNetwork GuardedGatePOL CofactorValueRows

theorem constant_cap (n:Nat) (hn:2≤n):ConstantCofactor.offset n hn≤NumericValueClosed.bound n:=by
  have h:ConstantCofactor.offset n hn≤NumericAliasSource.bound n hn:=by
    unfold NumericAliasSource.bound NumericCofactorNamespace.cap;omega
  exact h.trans (NumericValueClosed.raw_bound n hn)

theorem beta_rows (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (hj:j∈BetaPort.jobs n hn) (b v:Bool):
    RowSupport.Bounded (NumericValueClosed.bound n) (BetaSelectedValue.rows n hn j b v):=by
  have hjb:=NumericSelectedCofactors.beta_job n hn j hj
  have hchoice:(BetaAliasValue.choice j).natAbs≤NumericValueClosed.bound n:=hjb.1.trans (constant_cap n hn)
  have hbeta:BitBound (NumericValueClosed.bound n) (BetaSelectedValue.beta n hn j):=
    (NumericValueClosed.config n hn).beta _ hjb.2.1
  have hC:=NumericTreeRows.sign_bound _ _ v (NumericValueClosed.config n hn).C
  have hu:=NumericTreeRows.sign_bound _ _ v (NumericUnaryValueRows.unary n hn (BetaAliasValue.gate j) b)
  have hcf:=NumericTreeRows.sign_bound _ _ v (NumericUnaryValueRows.cofactor n hn (BetaAliasValue.gate j) j.2 hjb.2.1 hjb.2.2.2)
  intro R hR;simp only[BetaSelectedValue.rows,List.mem_cons,List.not_mem_nil,or_false] at hR
  rcases hR with rfl|rfl|rfl
  · refine ⟨canonical_normalize _ _,RowSupport.clause_bound _ _ ?_⟩
    intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl
    · simpa using hchoice
    · exact hbeta
  · refine ⟨canonical_normalize _ _,RowSupport.clause_bound _ _ ?_⟩
    intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl
    · simpa using hchoice
    · simpa using hC
    · exact hu
  · refine ⟨canonical_normalize _ _,RowSupport.clause_bound _ _ ?_⟩
    intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl
    · simpa using hchoice
    · simpa using hcf
    · exact hu

theorem beta_result (n:Nat) (hn:2≤n):RowSupport.Bounded (NumericValueClosed.bound n) (BetaValueBank.result n hn):=by
  apply RowSupport.append _ _ _ (NumericUnaryValueRows.result n hn)
  intro R hR;obtain ⟨j,hj,hR⟩:=List.mem_flatMap.mp hR
  exact beta_rows n hn j.1 ((BetaValueBank.job_mem n hn j).mp hj) j.2.1 j.2.2 R hR

theorem rank_id (n:Nat) (hn:2≤n) (g t:Nat) (hs:g<3*(n+1)-4) (ht:t<RankConstruction.width (n+1)):
    BitBound (NumericValueClosed.bound n) (RankUnaryValue.rank n hn g t):=
  NumericCategoryRows.bit_bound n hn g hs (.rank t) (by simpa[CategoryPrograms.cats,GateCategories.categories,RankConstruction.width] using ht)

theorem rank_result (n:Nat) (hn:2≤n):RowSupport.Bounded (NumericValueClosed.bound n) (RankValueBank.result n hn):=by
  apply RowSupport.append _ _ _ (beta_result n hn)
  intro R hR;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hR
  have h:=(RankValueBank.job_mem n j).mp hj
  apply NumericTreeRows.guarded_bound _ [-(RankUnaryValue.rank n hn j.1 j.2.1).val] _ j.2.2 ?_ (NumericUnaryValueRows.unary n hn j.1 j.2.2) _ (by simp[RankValueBank.jobRow,RankUnaryValue.row])
  intro l hl;obtain rfl:=List.mem_singleton.mp hl;simpa using rank_id n hn j.1 j.2.1 h.2.1 h.2.2

theorem evaluation_result (n:Nat) (hn:2≤n):RowSupport.Bounded (NumericValueClosed.bound n) (RankEvaluationBank.result n hn):=by
  apply RowSupport.append _ _ _ (rank_result n hn)
  intro R hR;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hR
  have h:=(RankEvaluationBank.job_mem n hn j).mp hj
  have hr:=RankEvaluationBank.valid_record n hn j.2.1
  have hri:=rank_id n hn j.1 j.2.1.val.1 h.2 hr.1
  have hraw:=NumericTreeRows.sign_bound _ _ j.2.2.1 (NumericUnaryValueRows.raw n hn j.2.1.val j.2.1.property)
  have hu:=NumericTreeRows.sign_bound _ _ j.2.2.2 (NumericUnaryValueRows.unary n hn j.1 j.2.2.1)
  have hcf:=NumericTreeRows.sign_bound _ _ j.2.2.2 (NumericUnaryValueRows.cofactor n hn j.1 j.2.1.val.2.1 h.2 hr.2)
  refine ⟨canonical_normalize _ _,RowSupport.clause_bound _ _ ?_⟩
  intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl|rfl|rfl|rfl
  · simpa using hri
  · simpa using hraw
  · simpa using hu
  · exact hcf
#print axioms evaluation_result
end L3Emitter.NumericCategoryValueRows

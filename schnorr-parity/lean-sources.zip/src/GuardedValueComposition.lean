import CofactorValueRows
namespace L3Emitter.GuardedValueComposition
open EREF EREF.GeneralRED REDWitness ReferenceTransport CaseJoin

def row (s a b:Int):=clause [-s,-a,b]
def tape (D:List Row) (s a b c:Int):List Tok:=
  [.ref (locate D (row s a b)),.ref (locate D (row s b c)),.add,.lit (-a),.add,.lit c,.add,.div 2]

theorem sum_scaled (s a b c:Int) (hs:s≠0) (ha:a≠0) (hb:b≠0) (hc:c≠0):
    add (add (add (row s a b) (row s b c)) (litAxiom (-a))) (litAxiom c)=
      scaled 2 (row s a c):=by
  apply canonical_ext _ _ (canonical_add _ _) (canonical_scaled 2 (by decide) _ (canonical_normalize _ _))
  intro α
  change (add (add (add (row s a b) (row s b c)) (litAxiom (-a))) (litAxiom c)).val α=(scaled 2 (row s a c)).val α
  rw [val_add _ _ (canonical_add _ _) (canonical_litAxiom _),
    val_add _ _ (canonical_add _ _) (canonical_litAxiom _),
    val_add (row s a b) (row s b c) (canonical_normalize _ _) (canonical_normalize _ _),val_scaled]
  simp only [row,val_clause [-s,-a,b] (by simp [Valid,hs,ha,hb]),
    val_clause [-s,-b,c] (by simp [Valid,hs,hb,hc]),val_clause [-s,-a,c] (by simp [Valid,hs,ha,hc]),
    val_litAxiom _ (neg_ne_zero.mpr ha),val_litAxiom _ hc]
  simp only [sum_cons,sum_nil,litVal_neg α b hb]
  ring

theorem checks (D:List Row) (s a b c:Int) (hs:s≠0) (ha:a≠0) (hb:b≠0) (hc:c≠0)
    (h1:row s a b∈D) (h2:row s b c∈D):
    polEval (dbOf D) (tape D s a b c) []=some (row s a c):=by
  simp only [tape,polEval,locate_correct _ _ h1,locate_correct _ _ h2]
  rw [if_pos (neg_ne_zero.mpr ha),if_pos hc,sum_scaled s a b c hs ha hb hc,
    divide_scaled 2 (by decide) (row s a c) (canonical_normalize _ _)]
  rfl

theorem token_count (D:List Row) (s a b c:Int):(tape D s a b c).length=8:=rfl
#print axioms checks
end L3Emitter.GuardedValueComposition

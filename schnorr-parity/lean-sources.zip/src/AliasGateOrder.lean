import AliasRefinement

namespace L3Emitter.AliasRefinement
open EREF AliasNetwork RecursiveAliases L3Uniform.Alias L3Uniform.Circuit
variable {base : List Row} {w : Nat}

theorem encoding_update (as : Nat→Alias) (j : Nat) (a : Alias) :
    (fun i=>encoding w (Function.update as j a i)) =
      Function.update (fun i=>encoding w (as i)) j (encoding w a) := by
  funext i;by_cases hi:i=j <;> simp [Function.update_apply,hi]

/-- Gate-order refinement including the actual mutable alias table.
    The ideal-context hypotheses are visible, not silently assumed from
    the existence of a checked definition trace. -/
theorem runValue_agrees (h : High) (beta gamma : Nat) (b c : Bool)
    (hbg : beta≠gamma) (topo : ∀g<h.s,h.left g<h.k+g ∧ h.right g<h.k+g)
    (firstRight : h.right 0=1) (g m : Nat) (hs : g+m≤h.s) :
    runValue (ideal h beta gamma b c) (fun j=>encoding w (aliases h beta gamma b c g j)) g m =
      (fun j=>encoding w (aliases h beta gamma b c (g+m) j)) := by
  induction m generalizing g with
  | zero => simp [runValue]
  | succ m ih =>
    have hg:g<h.s:=by omega
    have st:=step_agrees (w:=w) h beta gamma g b c (aliases h beta gamma b c g) hbg
      (topo g hg).1 (topo g hg).2 (by
        intro he;subst g
        simp [aliases,firstRight,L3Uniform.Circuit.initial])
    simp only [runValue]
    rw [st,←encoding_update]
    change runValue (ideal h beta gamma b c)
      (fun j=>encoding w (aliases h beta gamma b c (g+1) j)) (g+1) m = _
    have ht:=ih (g+1) (by omega)
    simpa only [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using ht

theorem emitted_aliases (α : Val) (cfg : Config Bit) (h : High)
    (beta gamma : Nat) (b c : Bool) (as : Nat→AliasBits w)
    (hcfg : cfg.map (eval α)=ideal h beta gamma b c)
    (ha : (fun j=>view α (as j))=(fun j=>encoding w (L3Uniform.Circuit.initial b j)))
    (hbg : beta≠gamma) (topo : ∀g<h.s,h.left g<h.k+g ∧ h.right g<h.k+g)
    (firstRight : h.right 0=1) :
    Spec α (RecursiveAliases.run (base:=base) cfg as 0 h.s)
      (fun result=>(fun j=>view α (result j))=(fun j=>encoding w (aliases h beta gamma b c h.s j))) := by
  exact spec_mono α _ _ _ (run_spec α cfg as 0 h.s) (by
    intro result hr
    rw [hcfg,ha] at hr
    have ht:=runValue_agrees (w:=w) h beta gamma b c hbg topo firstRight 0 h.s (by omega)
    simpa only [aliases,Nat.zero_add] using hr.trans ht)

def sourceValue (w : Nat) (av : AliasValues w) (v : Nat→Bool) :=
  (List.finRange w).any (fun j=>av ⟨j.val,by omega⟩ && v j.val)

def interpret (w : Nat) (av : AliasValues w) (v : Nat→Bool) :=
  if sourceValue w av v then av ⟨w+1,by omega⟩ else av ⟨w,by omega⟩

theorem sourceValue_encoding (a : Alias) (v : Nat→Bool) (ha : a.source<w) :
    sourceValue w (encoding w a) v=v a.source := by
  apply Bool.eq_iff_iff.mpr
  simp only [sourceValue,List.any_eq_true,Bool.and_eq_true]
  constructor
  · rintro ⟨j,hj,he,hv⟩
    have hi:j.val<w:=j.isLt
    simp only [encoding,hi,↓reduceIte,decide_eq_true_eq] at he
    simpa [he] using hv
  · intro hv
    refine ⟨⟨a.source,ha⟩,by simp,?_,hv⟩
    simp [encoding,ha]

theorem interpret_encoding (a : Alias) (v : Nat→Bool) (ha : a.source<w) :
    interpret w (encoding w a) v=a.eval v := by
  rw [interpret,sourceValue_encoding a v ha]
  simp [encoding,Alias.eval,Unary.eval]

/-- If the concrete choice context is identified and the existing circuit
    premises hold, the emitted coordinates give the original output value.
    This is a semantic invariant, not the missing output PB derivation. -/
theorem emitted_value (α : Val) (cfg : Config Bit) (h : High)
    (beta gamma : Nat) (b c : Bool) (as : Nat→AliasBits w)
    (hcfg : cfg.map (eval α)=ideal h beta gamma b c)
    (ha : (fun j=>view α (as j))=(fun j=>encoding w (L3Uniform.Circuit.initial b j)))
    (hk : 2≤h.k) (hb : 0<beta) (hbg : beta<gamma) (hg : gamma<h.s)
    (topo : ∀g<h.s,h.left g<h.k+g ∧ h.right g<h.k+g)
    (first : h.left 0=0) (firstRight : h.right 0=1)
    (hit : h.left gamma=h.k+beta ∨ h.right gamma=h.k+beta)
    (input gate : Nat→Bool) (input0 : input 0=b)
    (evals : Evaluates h input gate) (constant : gate beta=c)
    (i : Nat) (hi : i<h.k+h.s) (hw : (aliases h beta gamma b c h.s i).source<w) :
    Spec α (RecursiveAliases.run (base:=base) cfg as 0 h.s)
      (fun result=>interpret w (view α (result i)) (lowValue h beta gamma input gate) =
        highValue h input gate i) := by
  exact spec_mono α _ _ _
    (emitted_aliases α cfg h beta gamma b c as hcfg ha (by omega) topo firstRight)
    (by
      intro result hr
      have he:=congrFun hr i
      rw [he,interpret_encoding _ _ hw]
      exact aliases_correct h beta gamma b c hk hb hbg hg topo first hit input gate
        input0 evals constant h.s (by omega) i hi)

#print axioms runValue_agrees
#print axioms emitted_aliases
#print axioms interpret_encoding
#print axioms emitted_value
end L3Emitter.AliasRefinement

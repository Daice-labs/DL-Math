import CategoryMainTapes
import BranchMainTapes
import GlobalValueTokenEnvelope
import GlobalPortTapeBounds
import CompleteTableTapes
set_option linter.unusedSimpArgs false
namespace L3Emitter.GlobalExtensionMainTapes
open EREF EREF.GeneralRED U2ConstructionSize MainTapeRecurrence

def Q (n : Nat):Nat:=(n+1)^7*2^n

theorem lift (n C a : Nat) (ha:a≤7) : C*(n+1)^a≤C*Q n := by
  have hp:(n+1)^a≤(n+1)^7:=Nat.pow_le_pow_right (by omega) ha
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have hm:=Nat.mul_le_mul hp ht
  simpa only [Nat.mul_one,Q,Nat.mul_assoc] using Nat.mul_le_mul_left C hm

theorem lift_power (n C a : Nat) (ha:a≤7) : C*(n+1)^a*2^n≤C*Q n := by
  have hp:(n+1)^a≤(n+1)^7:=Nat.pow_le_pow_right (by omega) ha
  exact (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left C hp)).trans_eq (by unfold Q;ring)

/-- All 25 banks after the existing transport prefix. Unit: main POL tokens. -/
theorem complete (n : Nat) (hn : 2≤n) :
    count (RecordedGlobalValues.program n hn)≤count (RecordedTransportPrefix.program n hn)+4000000*Q n := by
  have h0:tokens (RankColumnOneHot.emitted n hn)≤45*Q n:=by
    have h:=SourceCardinalityMainTapes.columns n hn
    have hb:=lift n 45 3 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h1:tokens (PrimaryAliasBank.emitted n hn)≤221*Q n:=by
    have h:=SourceCardinalityMainTapes.primary n hn
    have hb:=lift n 221 4 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h2:tokens (FirstPortOneHot.emitted n hn)≤9100*Q n:=by
    have h:=SourceCardinalityMainTapes.first_ports n hn
    have hb:=lift n 9100 5 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h3:tokens (CategoryBank.emitted n hn)≤11400*Q n:=by
    have h:=CategoryMainTapes.complete n hn
    have hb:=lift n 11400 7 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h4:tokens (SourceRelationBank.program n hn)≤3360*Q n:=by
    have h:=MixtureMainTapes.sources n hn
    have hb:=lift n 3360 3 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h5:tokens (UnitAliasBank.program n hn)≤884*Q n:=by
    have h:=SourceCardinalityMainTapes.units n hn
    have hb:=lift n 884 4 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h6:tokens (SourceAuxBank.program n hn)≤1692*Q n:=by
    have h:=SourceAuxMainTapes.complete n hn
    have hb:=lift n 1692 3 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h7:tokens (GateOrderSources.fullProgram n hn)≤75000*Q n:=by
    have h:=IndexedSourceMainTapes.complete n hn
    have hb:=lift n 75000 6 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h8:tokens (AllSourceCardinalities.program n hn)≤96*Q n:=by
    have h:=SourceCardinalityMainTapes.cardinalities n hn
    have hb:=lift n 96 3 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h9:tokens (UnaryRelationBank.program n hn)≤1860*Q n:=by
    have h:=MixtureMainTapes.unaries n hn
    have hb:=lift n 1860 2 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h10:tokens (UnaryLookupBank.program n hn)≤7200*Q n:=by
    have h:=UnaryLeafMainTapes.lookup n hn
    have hb:=lift n 7200 1 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h11:tokens (UnaryValueBank.program n hn)≤2112*Q n:=by
    have h:=UnaryLeafMainTapes.values n hn
    have hb:=lift n 2112 1 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h12:tokens (BetaValueBank.program n hn)≤77760*Q n:=by
    have h:=GlobalFixedMainTapes.beta n hn
    have hb:=lift_power n 77760 4 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h13:tokens (RankValueBank.program n hn)≤108*Q n:=by
    have h:=GlobalFixedMainTapes.rank n hn
    have hb:=lift n 108 2 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h14:tokens (RankEvaluationBank.program n hn)≤180*Q n:=by
    have h:=GlobalFixedMainTapes.evaluation n hn
    have hb:=lift_power n 180 2 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h15:tokens (HitBranchBank.emitted n hn)≤1386*Q n:=by
    have h:=BranchMainTapes.hits n hn
    have hb:=lift n 1386 5 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h16:tokens (ReceivingEdgeBank.emitted n hn)≤153*Q n:=by
    have h:=BranchMainTapes.receiving n hn
    have hb:=lift n 153 2 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h17:tokens (GammaChoiceBank.emitted n hn)≤31104*Q n:=by
    have h:=GammaBankMainTapes.choices n hn
    have hb:=lift n 31104 4 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h18:tokens (GammaComparisonBank.emitted n hn)≤1990656*Q n:=by
    have h:=GammaBankMainTapes.comparisons n hn
    have hb:=lift_power n 1990656 4 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h19:tokens (SharedValueBank.program n hn)≤80000*Q n:=by
    have h:=GlobalFixedMainTapes.shared n hn
    have hb:=lift_power n 80000 4 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h20:tokens (FirstValueBank.prepare n hn)≤38*Q n:=by
    have h:=FirstGateMainTapes.prepare n hn
    have hb:=lift n 38 1 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h21:tokens (FirstValueBank.program n hn)≤150*Q n:=by
    have h:=FirstGateMainTapes.values n hn
    have hb:=lift_power n 150 0 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h22:tokens (FirstGateBase.program n hn)≤144*Q n:=by
    have h:=FirstGateMainTapes.complete n hn
    have hb:=lift_power n 144 1 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h23:tokens (GlobalValueInduction.program n hn)≤1500000*Q n:=by
    have h:=GlobalValueTokenEnvelope.closed n hn
    have hb:=lift_power n 1500000 5 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  have h24:tokens (GlobalPortValues.program n hn)≤20160*Q n:=by
    have h:=GlobalPortTapeBounds.closed n hn
    have hb:=lift_power n 20160 3 (by omega)
    simp only [pow_zero,pow_one,Nat.mul_one] at hb
    exact h.trans hb
  simp only [RecordedGlobalValues.program,RecordedGlobalValues.p25,RecordedGlobalValues.p24,RecordedGlobalValues.p23,RecordedGlobalValues.p22,RecordedGlobalValues.p21,RecordedGlobalValues.p20,RecordedGlobalValues.p19,RecordedGlobalValues.p18,RecordedGlobalValues.p17,RecordedGlobalValues.p16,RecordedGlobalValues.p15,RecordedGlobalValues.p14,RecordedGlobalValues.p13,RecordedGlobalValues.p12,RecordedGlobalValues.p11,RecordedGlobalValues.p10,RecordedGlobalValues.p9,RecordedGlobalValues.p8,RecordedGlobalValues.p7,RecordedGlobalValues.p6,RecordedGlobalValues.p5,RecordedGlobalValues.p4,RecordedGlobalValues.p3,RecordedGlobalValues.p2,RecordedGlobalValues.p1,RecordedGlobalValues.p0,append,pol_program]
  simp only [tokens] at *
  omega
#print axioms complete
end L3Emitter.GlobalExtensionMainTapes

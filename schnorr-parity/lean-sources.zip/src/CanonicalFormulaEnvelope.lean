import CanonicalPrefixEnvelope

namespace L3Emitter.CanonicalFormulaEnvelope
open CanonicalPrefixEnvelope

/-- Number of original constraints, in ROWS, for the parity target. -/
theorem original_rows (k : Nat) :
    (OriginalEncoding.rows k (3*k-4)).length ≤ 128*(k+1)^2*2^k := by
  have h:=FormulaSize.original_rows_bound k (3*k-4)
  have hs:3*k-4≤3*k:=Nat.sub_le _ _
  have hm: (3*k-4)*(k+(3*k-4))≤(3*k)*(k+3*k):=
    Nat.mul_le_mul hs (Nat.add_le_add_left hs k)
  have hc:4*(3*k-4)*(k+(3*k-4))+8*(3*k-4)+1≤48*k^2+24*k+1:=by
    nlinarith
  have hmul:=Nat.mul_le_mul_right (2^k) hc
  have hp:1≤2^k:=Nat.one_le_pow _ _ (by omega)
  have hk:18*k≤18*k*2^k:=by nlinarith
  simp only [FormulaSize.rowBound,FamilyNamespace.truthRows] at h
  nlinarith [Nat.zero_le (k^2*2^k)]

/-- A common ROW ceiling for every earlier recursion level. -/
def rowsThrough (m : Nat) := 128*(m+3)^2*2^(m+2)

theorem source_rows (i m : Nat) (hi : i<m) : sourceRows i≤rowsThrough m := by
  have h:=original_rows (i+3)
  have hk:i+3≤m+2:=by omega
  have hp:2^(i+3)≤2^(m+2):=Nat.pow_le_pow_right (by omega) hk
  have hsq:(i+3+1)^2≤(m+3)^2:=by nlinarith
  exact h.trans (Nat.mul_le_mul (Nat.mul_le_mul_left 128 hsq) hp)

/-- Actual stored local certificate count. Only the main-prefix command
bound remains a hypothesis; formula and retained-frame bounds are closed. -/
theorem certificates (m A : Nat)
    (ha : ∀ i<m,(CanonicalCountRecurrence.levelPrefix i).length≤A) :
    AuditLocalCosts.certCount (RecordedUniformFamily.family m)≤
      AuditLocalCosts.certCount (RecordedUniformFamily.family 0)+
      m*(A*(rowsThrough m+A))+m*(rowsThrough m+A)*
        (AuditLocalCosts.redCount (RecordedUniformFamily.family 0)+m*A) :=
  certificate_envelope m A (rowsThrough m) ha (fun i hi=>source_rows i m hi)

#print axioms original_rows
#print axioms source_rows
#print axioms certificates
end L3Emitter.CanonicalFormulaEnvelope

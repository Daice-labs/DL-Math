import UnaryLeafMainTapes
import IndexedSourceMainTapes
namespace L3Emitter.MixtureMainTapes
open EREF EREF.GeneralRED AliasNetwork U2ConstructionSize SourceMixture

theorem tree (t : GuardedTree.Tree) (D : List Row) (G : List Int) :
    tokens (t.program G D)≤8*t.count := GuardedTree.Tree.tokens_bound ..

theorem gamma (s : Refs) (D : List Row) : tokens (MixtureGamma.program s D)≤65 := by
  have h0:=tree (gammaTree s true) (D++MixtureGamma.forwardRows s) [-s.gamma.val,-s.m.val]
  have h1:=tree (gammaTree s false) (D++MixtureGamma.forwardBody s++MixtureGamma.backRows s) [-s.gamma.val,s.m.val]
  change _≤8*3 at h0
  change _≤8*4 at h1
  rw [MixtureGamma.program,tokens_append,MixtureGamma.forwardProgram,tokens_append,
    MixtureGamma.backwardProgram,tokens_append]
  have hs0:tokens (MixtureGamma.forwardSeeds s)=2:=rfl
  have hs1:tokens (MixtureGamma.backSeeds s (D++MixtureGamma.forwardBody s))=7:=rfl
  rw [hs0,hs1];omega

theorem beta (s : Refs) (D : List Row) : tokens (MixtureBeta.program s D)≤65 := gamma ..

theorem rank (s : Refs) (c : Bit) (D : List Row) : tokens (MixtureRank.program s c D)≤48 := by
  have h0:=tree (rankTree s true) (D++MixtureRank.positiveRows s c) [-c.val,-s.rank.val]
  have h1:=tree (rankTree s false) (D++MixtureRank.positiveBody s c++MixtureRank.negativeRows s c) [-c.val,s.rank.val]
  change _≤8*1 at h0
  change _≤8*4 at h1
  rw [MixtureRank.program,tokens_append,MixtureRank.positiveProgram,tokens_append,
    MixtureRank.negativeProgram,tokens_append]
  have hs0:tokens (MixtureRank.positiveSeeds s c)=1:=rfl
  have hs1:tokens (MixtureRank.negativeSeeds s c (D++MixtureRank.positiveBody s c))=7:=rfl
  rw [hs0,hs1];omega

theorem ranks (n : Nat) (hn : 2≤n) (g : Nat) (s : Refs) (ts : List Nat) (D : List Row) :
    tokens (CategoryMixtureProgram.rankLoop n hn g s D ts)≤48*ts.length := by
  induction ts generalizing D with
  | nil=>simp [CategoryMixtureProgram.rankLoop,tokens]
  | cons t ts ih=>
    have h:=rank s (GateCategories.bit n hn g (.rank t)) D
    have ht:=ih (D++MixtureRank.rows s (GateCategories.bit n hn g (.rank t)))
    rw [CategoryMixtureProgram.rankLoop,tokens_append,List.length_cons];omega

theorem prep_tape (n : Nat) (hn : 2≤n) (g : Nat) (i : Fin (AliasAssembly.width (n+1)))
    (cat : GateCategories.Category) (D : List Row) :
    (CategorySourceInputs.tape n hn g i cat D).length≤3 := by
  unfold CategorySourceInputs.tape;split
  · simp
  · rfl

theorem mixture (n : Nat) (hn : 2≤n) (g : Nat) (i : Fin (AliasAssembly.width (n+1)))
    (s : Refs) (D : List Row) : tokens (CategoryMixtureProgram.program n hn g i s D)≤280*(n+1) := by
  have hp:tokens (CategorySourceInputs.prepare n hn g i D)≤6:=by
    have h0:=prep_tape n hn g i .beta D;have h1:=prep_tape n hn g i .gamma D
    simp only [CategorySourceInputs.prepare,tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil];omega
  have hb:=beta s (CategoryMixtureProgram.afterPrep n hn g i D)
  have hg:=gamma s (CategoryMixtureProgram.afterBeta n hn g i s D)
  have hr:=ranks n hn g s (CategoryMixtureProgram.ranks n) (CategoryMixtureProgram.afterGamma n hn g i s D)
  have hl:(CategoryMixtureProgram.ranks n).length=RankConstruction.width (n+1):=List.length_range
  rw [hl] at hr
  have hw:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  rw [CategoryMixtureProgram.program,tokens_append,tokens_append,tokens_append]
  omega

theorem source_loop (n : Nat) (hn : 2≤n) (js : List (SourceRelationBank.Job n)) (D : List Row) :
    tokens (SourceRelationBank.loop n hn D js)≤js.length*(280*(n+1)) := by
  induction js generalizing D with
  | nil=>simp [SourceRelationBank.loop,tokens]
  | cons j js ih=>
    have h:=mixture n hn j.1 j.2 (GateSnapshots.refs n hn j.1 j.2) D
    have ht:=ih (D++SourceRelationBank.jobRows n hn j)
    rw [SourceRelationBank.loop,tokens_append,List.length_cons,Nat.succ_mul];omega

theorem sources (n : Nat) (hn : 2≤n) : tokens (SourceRelationBank.program n hn)≤3360*(n+1)^3 := by
  have h:=source_loop n hn (SourceRelationBank.jobs n) (CategoryBank.result n hn)
  rw [ConstructionRelationCount.source_jobs] at h
  have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.mul_le_mul (Nat.sub_le (3*(n+1)) 5) hw)).trans_eq (by ring))

theorem unary_tape (n : Nat) (hn : 2≤n) (g : Nat) (b : Bool) (cat : GateCategories.Category) (D : List Row) :
    (UnaryCategoryProgram.tape n hn g b cat D).length≤16*(n+1) := by
  cases b with
  | false=>change 3≤_;omega
  | true=>
    change (KeptCategoryRows.tape n hn g cat D).length≤_
    rw [KeptCategoryRows.tape,ChoiceProjection.exclude_token_count]
    simp only [KeptCategoryRows.ranks,List.length_map,List.length_range]
    unfold RankConstruction.width;omega

theorem unary (n : Nat) (hn : 2≤n) (g : Nat) (b : Bool) (D : List Row) :
    tokens (UnaryCategoryProgram.program n hn g b D)≤310*(n+1) := by
  have hp:tokens (UnaryCategoryProgram.prep n hn g b D)≤32*(n+1):=by
    have h0:=unary_tape n hn g b .beta D;have h1:=unary_tape n hn g b .gamma D
    simp only [UnaryCategoryProgram.prep,tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil];omega
  have hb:=beta (UnarySnapshots.actual n hn g b) (UnaryCategoryProgram.afterPrep n hn g b D)
  have hg:=gamma (UnarySnapshots.actual n hn g b) (UnaryCategoryProgram.afterBeta n hn g b D)
  have hr:=ranks n hn g (UnarySnapshots.actual n hn g b) (CategoryMixtureProgram.ranks n) (UnaryCategoryProgram.afterGamma n hn g b D)
  have hl:(CategoryMixtureProgram.ranks n).length=RankConstruction.width (n+1):=List.length_range
  rw [hl] at hr
  have hw:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  rw [UnaryCategoryProgram.program,tokens_append,tokens_append,tokens_append];omega

theorem unary_loop (n : Nat) (hn : 2≤n) (js : List UnaryRelationBank.Job) (D : List Row) :
    tokens (UnaryRelationBank.loop n hn D js)≤js.length*(310*(n+1)) := by
  induction js generalizing D with
  | nil=>simp [UnaryRelationBank.loop,tokens]
  | cons j js ih=>
    have h:=unary n hn j.1 j.2 D
    have ht:=ih (D++UnaryRelationBank.jobRows n hn j)
    rw [UnaryRelationBank.loop,tokens_append,List.length_cons,Nat.succ_mul];omega

theorem unaries (n : Nat) (hn : 2≤n) : tokens (UnaryRelationBank.program n hn)≤1860*(n+1)^2 := by
  have h:=unary_loop n hn (UnaryRelationBank.jobs n) (UnaryRelationBank.base n hn)
  have hj:(UnaryRelationBank.jobs n).length=(3*(n+1)-5)*2:=by
    unfold UnaryRelationBank.jobs
    rw [ConstructionRelationCount.flat_exact _ _ 2 (by intro g hg;rfl),ConstructionRelationCount.gates]
  rw [hj] at h
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.mul_le_mul_right 2 (Nat.sub_le (3*(n+1)) 5))).trans_eq (by ring))
#print axioms sources
#print axioms unaries
end L3Emitter.MixtureMainTapes

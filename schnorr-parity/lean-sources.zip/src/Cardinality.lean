import CaseJoin
import TemplateBytes

/- The clique-extension POL command in output.py. This proves its exact
   result, including duplicate/complemented literals, for every arity.
   Pairwise premises must still be supplied by the transport construction. -/
namespace L3Emitter.Cardinality
open EREF L3Emitter.REDWitness L3Emitter.CaseJoin

def amo (xs : List Int) : Row :=
  normalize (xs.map fun x => (1,-x)) ((xs.length : Int)-1)

def pair (x y : Int) : Row := clause [-x,-y]

theorem canonical_amo (xs : List Int) : Canonical (amo xs) := canonical_normalize _ _
theorem canonical_pair (x y : Int) : Canonical (pair x y) := canonical_normalize _ _

def stepTokens (ids : List Nat) (prior : Nat) : List Tok :=
  match ids with
  | [] => []
  | i :: rest => [.ref i] ++ rest.flatMap (fun j => [.ref j,.add]) ++
      [.ref prior,.mul (ids.length-1),.add,.div ids.length]

theorem val_amo (xs : List Int) (hz : Valid xs) (α : Val) :
    (amo xs).val α = sum α (xs.map Neg.neg) - xs.length + 1 := by
  unfold amo
  rw [val_normalize]
  · have hs : tvalZ α (xs.map fun x => (1,-x)) = sum α (xs.map Neg.neg) := by
      induction xs with
      | nil => rfl
      | cons x xs ih =>
        have ih' := ih (by intro l hl; exact hz l (by simp [hl]))
        simpa [tvalZ, sum] using congrArg (fun z => litVal α (-x)+z) ih'
    rw [hs]; ring
  · intro t ht
    obtain ⟨x,hx,rfl⟩ := List.mem_map.mp ht
    have := hz x hx; simp; omega

theorem val_pair (x y : Int) (hx : x ≠ 0) (hy : y ≠ 0) (α : Val) :
    (pair x y).val α = litVal α (-x)+litVal α (-y)-1 := by
  rw [pair, val_clause]
  · simp
  · intro l hl; simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
    rcases hl with rfl | rfl <;> omega

theorem pair_base (x y : Int) : pair x y = amo [x,y] := by
  simp [pair, clause, amo]

theorem fold_pair_values (db : Nat → Option Row) (x : Int) (hx : x ≠ 0)
    (ps : List (Nat × Int)) (hp : ∀ p ∈ ps, p.2 ≠ 0 ∧ db p.1 = some (pair x p.2))
    (acc : Row) (hc : Canonical acc) (α : Val) :
    Canonical (fold db acc (ps.map Prod.fst)) ∧
    (fold db acc (ps.map Prod.fst)).val α = acc.val α +
      ps.length*(litVal α (-x)-1) + sum α (ps.map fun p => -p.2) := by
  induction ps generalizing acc with
  | nil => simp [fold, hc]
  | cons p ps ih =>
    have hh := hp p (by simp)
    simp only [List.map_cons, fold, hh.2, Option.getD_some]
    obtain ⟨hc', hv⟩ := ih (by intro u hu; exact hp u (by simp [hu]))
      (add acc (pair x p.2)) (canonical_add _ _)
    refine ⟨hc', ?_⟩
    rw [hv, val_add acc (pair x p.2) hc (canonical_pair _ _), val_pair _ _ hx hh.1]
    simp only [List.length_cons, Nat.cast_add, Nat.cast_one, sum_cons]
    ring

/-- The command is valid for arbitrary literal IDs, aliases, complements and
    arities greater than one. No propagation oracle is assumed for this step. -/
theorem step_succeeds (db : Nat → Option Row) (x : Int) (hx : x ≠ 0)
    (ps : List (Nat × Int)) (hm : 2 ≤ ps.length) (prior : Nat)
    (hp : ∀ p ∈ ps, p.2 ≠ 0 ∧ db p.1 = some (pair x p.2))
    (ha : db prior = some (amo (ps.map Prod.snd))) :
    polEval db (stepTokens (ps.map Prod.fst) prior) [] =
      some (amo (x :: ps.map Prod.snd)) := by
  cases ps with
  | nil => simp at hm
  | cons p ps =>
    have hp0 := hp p (by simp)
    have hp' := fun u hu => hp u (List.mem_cons_of_mem p hu)
    have hm' : 0 < ps.length := by simp only [List.length_cons] at hm; omega
    have hids : ∀ i ∈ ps.map Prod.fst, ∃ R, db i = some R := by
      intro i hi
      obtain ⟨u,hu,rfl⟩ := List.mem_map.mp hi
      exact ⟨_, (hp' u hu).2⟩
    have hvxs : Valid ((p :: ps).map Prod.snd) := by
      intro l hl; obtain ⟨u,hu,rfl⟩ := List.mem_map.mp hl; exact (hp u hu).1
    have hvc : Valid (x :: (p :: ps).map Prod.snd) := by
      intro l hl; rcases List.mem_cons.mp hl with rfl | hl
      · exact hx
      · exact hvxs l hl
    let f := fold db (pair x p.2) (ps.map Prod.fst)
    let C := amo (x :: (p :: ps).map Prod.snd)
    have hf := fold_pair_values db x hx ps hp' (pair x p.2) (canonical_pair _ _)
    have he : add f (multiply (amo ((p :: ps).map Prod.snd)) ps.length) =
        scaled (ps.length+1) C := by
      apply canonical_ext _ _ (canonical_add _ _) (canonical_scaled _ (by omega) C (canonical_amo _))
      intro α
      rw [val_add _ _ (hf α).1 (canonical_multiply _ _),
        val_multiply (amo ((p :: ps).map Prod.snd)) (canonical_amo _) ps.length]
      change (fold db (pair x p.2) (ps.map Prod.fst)).val α + _ = _
      rw [(hf α).2, val_pair _ _ hx hp0.1, val_amo _ hvxs, val_scaled]
      dsimp only [C]
      rw [val_amo _ hvc]
      simp only [List.map_cons, List.length_cons, List.length_map, Nat.cast_add, Nat.cast_one,
        List.map_map, Function.comp_def, sum_cons]
      ring
    simp only [List.map_cons, stepTokens, List.cons_append, List.nil_append,
      polEval, hp0.2]
    rw [eval_fold db _ hids]
    simp only [List.length_cons, List.length_map, Nat.add_sub_cancel, polEval, ha,
      hm', ↓reduceIte]
    change polEval db [.div (ps.length+1)]
      [add f (multiply (amo ((p :: ps).map Prod.snd)) ps.length)] = some C
    rw [he]
    simp [polEval, divide_scaled _ (by omega : 0 < ps.length+1) C (canonical_amo _)]

theorem step_token_count (ids : List Nat) (prior : Nat) (h : ids ≠ []) :
    (stepTokens ids prior).length = 2*ids.length+3 := by
  cases ids with
  | nil => contradiction
  | cons i ids =>
    simp [stepTokens, List.length_flatMap, List.map_map, Function.comp_def]
    omega

#print axioms step_succeeds
#print axioms step_token_count
end L3Emitter.Cardinality

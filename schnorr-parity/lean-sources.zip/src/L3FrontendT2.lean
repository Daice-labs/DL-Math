/-
Template T2 (frontend.py lines 81–87): a non-forcing port of a U2 gate is semantically
ignored. For every gate g ≥ 1 and port, the four lines

    rup [force, ¬fn(g,a), fn(g,b)] ; rup [force, fn(g,a), ¬fn(g,b)]     (a,b) ∈ pairs(port)

are refuted by one weighted POL sum: 2·¬C + the two OR rows of `force` + one EQ row of
each eqrow + the forbidden-XOR/XNOR row of gate g, whose value is identically −1.
-/
import L3FrontendLemmas

namespace L3
open EREF EREF.GeneralRED

/-- six-row weighted chain: 2·R0 + R1 + R2 + R3 + R4 + R5 < 0 -/
theorem chain6 (D' : List EREF.Row) (hD' : ∀ R ∈ D', Canonical R)
    (R0 R1 R2 R3 R4 R5 : EREF.Row) (h0 : R0 ∈ D') (h1 : R1 ∈ D') (h2 : R2 ∈ D') (h3 : R3 ∈ D')
    (h4 : R4 ∈ D') (h5 : R5 ∈ D')
    (hneg : ∀ α, 2 * R0.val α + R1.val α + R2.val α + R3.val α + R4.val α + R5.val α < 0) :
    Refutation D' := by
  obtain ⟨i0, hi0⟩ := Fam.dbOf_of_mem D' R0 h0
  obtain ⟨i1, hi1⟩ := Fam.dbOf_of_mem D' R1 h1
  obtain ⟨i2, hi2⟩ := Fam.dbOf_of_mem D' R2 h2
  obtain ⟨i3, hi3⟩ := Fam.dbOf_of_mem D' R3 h3
  obtain ⟨i4, hi4⟩ := Fam.dbOf_of_mem D' R4 h4
  obtain ⟨i5, hi5⟩ := Fam.dbOf_of_mem D' R5 h5
  let f : Nat → EREF.Row := fun j => (dbOf D' j).getD ⟨[], 0⟩
  have hf : ∀ j R, dbOf D' j = some R → f j = R := by intro j R h; simp [f, h]
  apply refutation_of_chain D' hD' f i0 [i0, i1, i2, i3, i4, i5]
  · rw [hf _ _ hi0]; exact hi0
  · intro j hj
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hj
    rcases hj with rfl | rfl | rfl | rfl | rfl | rfl
    · rw [hf _ _ hi0]; exact hi0
    · rw [hf _ _ hi1]; exact hi1
    · rw [hf _ _ hi2]; exact hi2
    · rw [hf _ _ hi3]; exact hi3
    · rw [hf _ _ hi4]; exact hi4
    · rw [hf _ _ hi5]; exact hi5
  · intro α
    rw [hf _ _ hi0]
    simp only [List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
    rw [hf _ _ hi0, hf _ _ hi1, hf _ _ hi2, hf _ _ hi3, hf _ _ hi4, hf _ _ hi5]
    have := hneg α; omega

theorem StI.chk_rup {m0 : Nat} (t : StI m0) (c xs : List Int) : (t.rup c).s.chk xs = t.s.chk xs := rfl

namespace Fam
variable (F : Fam)

/-! ### Stage 4 command characterization -/

/-- the four rup clauses of (g, port) in emission order -/
def forceClauses (g port : Nat) (f : Nat) : List (List Int) :=
  (if port = 0 then [(0, 2), (1, 3)] else [(0, 1), (2, 3)]).flatMap fun ab =>
    [[(f : Int), -(F.fn g ab.1 : Int), (F.fn g ab.2 : Int)], [(f : Int), (F.fn g ab.1 : Int), -(F.fn g ab.2 : Int)]]

theorem forceRups_cmds (t : StI F.V) (g port : Nat) (hg : g < F.s)
    (hf : 1 ≤ t.s.force g port ∧ t.s.force g port ≤ t.s.var) :
    (F.forceRups t (g, port)).s.cmds = t.s.cmds ++ (F.forceClauses g port (t.s.force g port)).map Cmd.rup := by
  have hV := t.var_ge
  have hS := F.S4_le_V
  have hfn : ∀ ab, ab < 4 → 1 ≤ ((F.fn g ab : Nat) : Int).natAbs ∧ ((F.fn g ab : Nat) : Int).natAbs ≤ t.s.var := by
    intro ab hab; have := F.fn_range g ab hg hab; simp; omega
  have hfnn : ∀ ab, ab < 4 → 1 ≤ (-((F.fn g ab : Nat) : Int)).natAbs ∧ (-((F.fn g ab : Nat) : Int)).natAbs ≤ t.s.var := by
    intro ab hab; have := F.fn_range g ab hg hab; simp; omega
  have hff : 1 ≤ ((t.s.force g port : Nat) : Int).natAbs ∧ ((t.s.force g port : Nat) : Int).natAbs ≤ t.s.var := by
    simp; omega
  -- the rup steps do not change var or force, so chk is the identity throughout
  have hchk : ∀ (t' : StI F.V), t'.s.var = t.s.var → ∀ a b, a < 4 → b < 4 →
      t'.s.chk [(t.s.force g port : Int), -(F.fn g a : Int), (F.fn g b : Int)]
        = [(t.s.force g port : Int), -(F.fn g a : Int), (F.fn g b : Int)] ∧
      t'.s.chk [(t.s.force g port : Int), (F.fn g a : Int), -(F.fn g b : Int)]
        = [(t.s.force g port : Int), (F.fn g a : Int), -(F.fn g b : Int)] := by
    intro t' hv a b ha hb
    constructor <;> apply StI.chk_eq <;> intro l hl <;>
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hl <;> rw [hv] <;>
      rcases hl with rfl | rfl | rfl
    · exact hff
    · exact hfnn a ha
    · exact hfn b hb
    · exact hff
    · exact hfn a ha
    · exact hfnn b hb
  unfold forceRups forceClauses
  simp only []
  by_cases hp : port = 0
  · subst hp
    simp only [↓reduceIte, List.foldl_cons, List.foldl_nil, List.flatMap_cons, List.flatMap_nil,
      List.append_nil, List.map_cons, List.map_nil, List.cons_append, List.nil_append]
    simp only [StI.cmds_rup, StI.chk_rup]
    rw [(hchk t rfl 0 2 (by omega) (by omega)).1, (hchk t rfl 0 2 (by omega) (by omega)).2,
      (hchk t rfl 1 3 (by omega) (by omega)).1, (hchk t rfl 1 3 (by omega) (by omega)).2]
    simp
  · simp only [hp, ↓reduceIte, List.foldl_cons, List.foldl_nil, List.flatMap_cons, List.flatMap_nil,
      List.append_nil, List.map_cons, List.map_nil, List.cons_append, List.nil_append]
    simp only [StI.cmds_rup, StI.chk_rup]
    rw [(hchk t rfl 0 1 (by omega) (by omega)).1, (hchk t rfl 0 1 (by omega) (by omega)).2,
      (hchk t rfl 2 3 (by omega) (by omega)).1, (hchk t rfl 2 3 (by omega) (by omega)).2]
    simp


/-! ### The eight T2 cases -/

theorem gateRow_nz' (inputs : List Int) (q : Nat) (hq : 1 ≤ q) (hin : ∀ l ∈ inputs, l ≠ 0) (bit : Bool) :
    (gateRow inputs q bit).nz := by
  intro l hl
  unfold gateRow at hl
  simp only [List.mem_append, List.mem_singleton] at hl
  rcases hl with hl | rfl
  · exact hin l hl
  · cases bit <;> simp [pos, neg] <;> omega

theorem lv_negInt (α : Val) (v : Nat) (hv : 1 ≤ v) : lv α (-((v : Nat) : Int)) = 1 - b2i (α v) := lv_neg α v hv
theorem lv_natInt (α : Val) (v : Nat) (hv : 1 ≤ v) : lv α ((v : Nat) : Int) = b2i (α v) := lv_pos α v hv

theorem row2_0_nz' (g c : Nat) : (F.row2 g c).nz := by
  intro l hl
  unfold row2 at hl
  simp only [List.mem_map, List.mem_range] at hl
  obtain ⟨ab, _, rfl⟩ := hl
  have := F.fn_pos g ab
  split <;> first | exact neg_ne_zero _ this | exact pos_ne_zero _ this

theorem row2_rhs' (g c : Nat) : ((F.row2 g c).rhs : Int) = 1 := rfl

theorem row2_lits' (g c : Nat) : (F.row2 g c).lits =
    [if codeBit c 0 then neg (F.fn g 0) else pos (F.fn g 0),
     if codeBit c 1 then neg (F.fn g 1) else pos (F.fn g 1),
     if codeBit c 2 then neg (F.fn g 2) else pos (F.fn g 2),
     if codeBit c 3 then neg (F.fn g 3) else pos (F.fn g 3)] := by
  unfold row2
  have hr : List.range 4 = [0, 1, 2, 3] := by decide
  rw [hr]; rfl

theorem t2_p0_02_0 (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (g : Nat) (hg : g < F.s)
    (f e0 e1 : Nat) (hf : 1 ≤ f) (he0 : 1 ≤ e0) (he1 : 1 ≤ e1)
    (hor : ∀ R ∈ (orDefs [(e0 : Int), (e1 : Int)]).rows f, R ∈ D)
    (hE0 : ∀ R ∈ (eqDefs (F.fn g 0 : Int) (F.fn g 1 : Int)).rows e0, R ∈ D)
    (hE1 : ∀ R ∈ (eqDefs (F.fn g 2 : Int) (F.fn g 3 : Int)).rows e1, R ∈ D)
    (hB : (F.row2 g 9).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(f : Int), -(F.fn g 0 : Int), (F.fn g 2 : Int)]).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow [(f : Int), -(F.fn g 0 : Int), (F.fn g 2 : Int)]).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have f0 := F.fn_pos g 0; have f1 := F.fn_pos g 1; have f2 := F.fn_pos g 2; have f3 := F.fn_pos g 3
  apply chain6 _ hDc (negate (clauseRow [(f : Int), -(F.fn g 0 : Int), (F.fn g 2 : Int)]).toE)
    (gateRow [-(e0 : Int)] f true).toE (gateRow [-(e1 : Int)] f true).toE
    (gateRow [-(F.fn g 0 : Int), -(F.fn g 1 : Int)] e0 true).toE (gateRow [(F.fn g 2 : Int), (F.fn g 3 : Int)] e1 true).toE (F.row2 g 9).toE
  · exact List.mem_append_right _ (List.mem_singleton.mpr rfl)
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE0 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE1 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ hB
  · intro α
    have hnz : (clauseRow [(f : Int), -(F.fn g 0 : Int), (F.fn g 2 : Int)]).nz := by
      intro l hl; simp [clauseRow] at hl; rcases hl with rfl | rfl | rfl <;> omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz,
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ he0 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (gateRow_nz' _ _ he1 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (F.row2_0_nz' g 9), row2_lits']
    have c0 : codeBit 9 0 = true := by decide
    have c1 : codeBit 9 1 = false := by decide
    have c2 : codeBit 9 2 = false := by decide
    have c3 : codeBit 9 3 = true := by decide
    simp only [clauseRow, gateRow, c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.cons_append,
      List.nil_append, lsum_cons, lsum_nil, lv_negInt, lv_natInt, lv_pos, lv_neg, Int.natAbs_natCast,
      Int.natAbs_neg]
    have := lv_pos α f hf; have := lv_neg α f hf; have := lv_natInt α f hf; have := lv_negInt α f hf
    have := lv_pos α e0 he0; have := lv_neg α e0 he0; have := lv_natInt α e0 he0; have := lv_negInt α e0 he0
    have := lv_pos α e1 he1; have := lv_neg α e1 he1; have := lv_natInt α e1 he1; have := lv_negInt α e1 he1
    have := lv_pos α (F.fn g 0) f0; have := lv_neg α (F.fn g 0) f0; have := lv_natInt α (F.fn g 0) f0; have := lv_negInt α (F.fn g 0) f0
    have := lv_pos α (F.fn g 1) f1; have := lv_neg α (F.fn g 1) f1; have := lv_natInt α (F.fn g 1) f1; have := lv_negInt α (F.fn g 1) f1
    have := lv_pos α (F.fn g 2) f2; have := lv_neg α (F.fn g 2) f2; have := lv_natInt α (F.fn g 2) f2; have := lv_negInt α (F.fn g 2) f2
    have := lv_pos α (F.fn g 3) f3; have := lv_neg α (F.fn g 3) f3; have := lv_natInt α (F.fn g 3) f3; have := lv_negInt α (F.fn g 3) f3
    have := b2i_bounds (α f); have := b2i_bounds (α e0); have := b2i_bounds (α e1)
    have := b2i_bounds (α (F.fn g 0)); have := b2i_bounds (α (F.fn g 1))
    have := b2i_bounds (α (F.fn g 2)); have := b2i_bounds (α (F.fn g 3))
    simp only [row2_rhs']
    omega

theorem t2_p0_02_1 (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (g : Nat) (hg : g < F.s)
    (f e0 e1 : Nat) (hf : 1 ≤ f) (he0 : 1 ≤ e0) (he1 : 1 ≤ e1)
    (hor : ∀ R ∈ (orDefs [(e0 : Int), (e1 : Int)]).rows f, R ∈ D)
    (hE0 : ∀ R ∈ (eqDefs (F.fn g 0 : Int) (F.fn g 1 : Int)).rows e0, R ∈ D)
    (hE1 : ∀ R ∈ (eqDefs (F.fn g 2 : Int) (F.fn g 3 : Int)).rows e1, R ∈ D)
    (hB : (F.row2 g 6).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(f : Int), (F.fn g 0 : Int), -(F.fn g 2 : Int)]).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow [(f : Int), (F.fn g 0 : Int), -(F.fn g 2 : Int)]).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have f0 := F.fn_pos g 0; have f1 := F.fn_pos g 1; have f2 := F.fn_pos g 2; have f3 := F.fn_pos g 3
  apply chain6 _ hDc (negate (clauseRow [(f : Int), (F.fn g 0 : Int), -(F.fn g 2 : Int)]).toE)
    (gateRow [-(e0 : Int)] f true).toE (gateRow [-(e1 : Int)] f true).toE
    (gateRow [(F.fn g 0 : Int), (F.fn g 1 : Int)] e0 true).toE (gateRow [-(F.fn g 2 : Int), -(F.fn g 3 : Int)] e1 true).toE (F.row2 g 6).toE
  · exact List.mem_append_right _ (List.mem_singleton.mpr rfl)
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE0 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE1 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ hB
  · intro α
    have hnz : (clauseRow [(f : Int), (F.fn g 0 : Int), -(F.fn g 2 : Int)]).nz := by
      intro l hl; simp [clauseRow] at hl; rcases hl with rfl | rfl | rfl <;> omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz,
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ he0 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (gateRow_nz' _ _ he1 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (F.row2_0_nz' g 6), row2_lits']
    have c0 : codeBit 6 0 = false := by decide
    have c1 : codeBit 6 1 = true := by decide
    have c2 : codeBit 6 2 = true := by decide
    have c3 : codeBit 6 3 = false := by decide
    simp only [clauseRow, gateRow, c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.cons_append,
      List.nil_append, lsum_cons, lsum_nil, lv_negInt, lv_natInt, lv_pos, lv_neg, Int.natAbs_natCast,
      Int.natAbs_neg]
    have := lv_pos α f hf; have := lv_neg α f hf; have := lv_natInt α f hf; have := lv_negInt α f hf
    have := lv_pos α e0 he0; have := lv_neg α e0 he0; have := lv_natInt α e0 he0; have := lv_negInt α e0 he0
    have := lv_pos α e1 he1; have := lv_neg α e1 he1; have := lv_natInt α e1 he1; have := lv_negInt α e1 he1
    have := lv_pos α (F.fn g 0) f0; have := lv_neg α (F.fn g 0) f0; have := lv_natInt α (F.fn g 0) f0; have := lv_negInt α (F.fn g 0) f0
    have := lv_pos α (F.fn g 1) f1; have := lv_neg α (F.fn g 1) f1; have := lv_natInt α (F.fn g 1) f1; have := lv_negInt α (F.fn g 1) f1
    have := lv_pos α (F.fn g 2) f2; have := lv_neg α (F.fn g 2) f2; have := lv_natInt α (F.fn g 2) f2; have := lv_negInt α (F.fn g 2) f2
    have := lv_pos α (F.fn g 3) f3; have := lv_neg α (F.fn g 3) f3; have := lv_natInt α (F.fn g 3) f3; have := lv_negInt α (F.fn g 3) f3
    have := b2i_bounds (α f); have := b2i_bounds (α e0); have := b2i_bounds (α e1)
    have := b2i_bounds (α (F.fn g 0)); have := b2i_bounds (α (F.fn g 1))
    have := b2i_bounds (α (F.fn g 2)); have := b2i_bounds (α (F.fn g 3))
    simp only [row2_rhs']
    omega

theorem t2_p0_13_0 (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (g : Nat) (hg : g < F.s)
    (f e0 e1 : Nat) (hf : 1 ≤ f) (he0 : 1 ≤ e0) (he1 : 1 ≤ e1)
    (hor : ∀ R ∈ (orDefs [(e0 : Int), (e1 : Int)]).rows f, R ∈ D)
    (hE0 : ∀ R ∈ (eqDefs (F.fn g 0 : Int) (F.fn g 1 : Int)).rows e0, R ∈ D)
    (hE1 : ∀ R ∈ (eqDefs (F.fn g 2 : Int) (F.fn g 3 : Int)).rows e1, R ∈ D)
    (hB : (F.row2 g 6).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(f : Int), -(F.fn g 1 : Int), (F.fn g 3 : Int)]).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow [(f : Int), -(F.fn g 1 : Int), (F.fn g 3 : Int)]).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have f0 := F.fn_pos g 0; have f1 := F.fn_pos g 1; have f2 := F.fn_pos g 2; have f3 := F.fn_pos g 3
  apply chain6 _ hDc (negate (clauseRow [(f : Int), -(F.fn g 1 : Int), (F.fn g 3 : Int)]).toE)
    (gateRow [-(e0 : Int)] f true).toE (gateRow [-(e1 : Int)] f true).toE
    (gateRow [-(F.fn g 0 : Int), -(F.fn g 1 : Int)] e0 true).toE (gateRow [(F.fn g 2 : Int), (F.fn g 3 : Int)] e1 true).toE (F.row2 g 6).toE
  · exact List.mem_append_right _ (List.mem_singleton.mpr rfl)
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE0 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE1 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ hB
  · intro α
    have hnz : (clauseRow [(f : Int), -(F.fn g 1 : Int), (F.fn g 3 : Int)]).nz := by
      intro l hl; simp [clauseRow] at hl; rcases hl with rfl | rfl | rfl <;> omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz,
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ he0 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (gateRow_nz' _ _ he1 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (F.row2_0_nz' g 6), row2_lits']
    have c0 : codeBit 6 0 = false := by decide
    have c1 : codeBit 6 1 = true := by decide
    have c2 : codeBit 6 2 = true := by decide
    have c3 : codeBit 6 3 = false := by decide
    simp only [clauseRow, gateRow, c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.cons_append,
      List.nil_append, lsum_cons, lsum_nil, lv_negInt, lv_natInt, lv_pos, lv_neg, Int.natAbs_natCast,
      Int.natAbs_neg]
    have := lv_pos α f hf; have := lv_neg α f hf; have := lv_natInt α f hf; have := lv_negInt α f hf
    have := lv_pos α e0 he0; have := lv_neg α e0 he0; have := lv_natInt α e0 he0; have := lv_negInt α e0 he0
    have := lv_pos α e1 he1; have := lv_neg α e1 he1; have := lv_natInt α e1 he1; have := lv_negInt α e1 he1
    have := lv_pos α (F.fn g 0) f0; have := lv_neg α (F.fn g 0) f0; have := lv_natInt α (F.fn g 0) f0; have := lv_negInt α (F.fn g 0) f0
    have := lv_pos α (F.fn g 1) f1; have := lv_neg α (F.fn g 1) f1; have := lv_natInt α (F.fn g 1) f1; have := lv_negInt α (F.fn g 1) f1
    have := lv_pos α (F.fn g 2) f2; have := lv_neg α (F.fn g 2) f2; have := lv_natInt α (F.fn g 2) f2; have := lv_negInt α (F.fn g 2) f2
    have := lv_pos α (F.fn g 3) f3; have := lv_neg α (F.fn g 3) f3; have := lv_natInt α (F.fn g 3) f3; have := lv_negInt α (F.fn g 3) f3
    have := b2i_bounds (α f); have := b2i_bounds (α e0); have := b2i_bounds (α e1)
    have := b2i_bounds (α (F.fn g 0)); have := b2i_bounds (α (F.fn g 1))
    have := b2i_bounds (α (F.fn g 2)); have := b2i_bounds (α (F.fn g 3))
    simp only [row2_rhs']
    omega

theorem t2_p0_13_1 (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (g : Nat) (hg : g < F.s)
    (f e0 e1 : Nat) (hf : 1 ≤ f) (he0 : 1 ≤ e0) (he1 : 1 ≤ e1)
    (hor : ∀ R ∈ (orDefs [(e0 : Int), (e1 : Int)]).rows f, R ∈ D)
    (hE0 : ∀ R ∈ (eqDefs (F.fn g 0 : Int) (F.fn g 1 : Int)).rows e0, R ∈ D)
    (hE1 : ∀ R ∈ (eqDefs (F.fn g 2 : Int) (F.fn g 3 : Int)).rows e1, R ∈ D)
    (hB : (F.row2 g 9).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(f : Int), (F.fn g 1 : Int), -(F.fn g 3 : Int)]).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow [(f : Int), (F.fn g 1 : Int), -(F.fn g 3 : Int)]).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have f0 := F.fn_pos g 0; have f1 := F.fn_pos g 1; have f2 := F.fn_pos g 2; have f3 := F.fn_pos g 3
  apply chain6 _ hDc (negate (clauseRow [(f : Int), (F.fn g 1 : Int), -(F.fn g 3 : Int)]).toE)
    (gateRow [-(e0 : Int)] f true).toE (gateRow [-(e1 : Int)] f true).toE
    (gateRow [(F.fn g 0 : Int), (F.fn g 1 : Int)] e0 true).toE (gateRow [-(F.fn g 2 : Int), -(F.fn g 3 : Int)] e1 true).toE (F.row2 g 9).toE
  · exact List.mem_append_right _ (List.mem_singleton.mpr rfl)
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE0 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE1 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ hB
  · intro α
    have hnz : (clauseRow [(f : Int), (F.fn g 1 : Int), -(F.fn g 3 : Int)]).nz := by
      intro l hl; simp [clauseRow] at hl; rcases hl with rfl | rfl | rfl <;> omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz,
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ he0 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (gateRow_nz' _ _ he1 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (F.row2_0_nz' g 9), row2_lits']
    have c0 : codeBit 9 0 = true := by decide
    have c1 : codeBit 9 1 = false := by decide
    have c2 : codeBit 9 2 = false := by decide
    have c3 : codeBit 9 3 = true := by decide
    simp only [clauseRow, gateRow, c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.cons_append,
      List.nil_append, lsum_cons, lsum_nil, lv_negInt, lv_natInt, lv_pos, lv_neg, Int.natAbs_natCast,
      Int.natAbs_neg]
    have := lv_pos α f hf; have := lv_neg α f hf; have := lv_natInt α f hf; have := lv_negInt α f hf
    have := lv_pos α e0 he0; have := lv_neg α e0 he0; have := lv_natInt α e0 he0; have := lv_negInt α e0 he0
    have := lv_pos α e1 he1; have := lv_neg α e1 he1; have := lv_natInt α e1 he1; have := lv_negInt α e1 he1
    have := lv_pos α (F.fn g 0) f0; have := lv_neg α (F.fn g 0) f0; have := lv_natInt α (F.fn g 0) f0; have := lv_negInt α (F.fn g 0) f0
    have := lv_pos α (F.fn g 1) f1; have := lv_neg α (F.fn g 1) f1; have := lv_natInt α (F.fn g 1) f1; have := lv_negInt α (F.fn g 1) f1
    have := lv_pos α (F.fn g 2) f2; have := lv_neg α (F.fn g 2) f2; have := lv_natInt α (F.fn g 2) f2; have := lv_negInt α (F.fn g 2) f2
    have := lv_pos α (F.fn g 3) f3; have := lv_neg α (F.fn g 3) f3; have := lv_natInt α (F.fn g 3) f3; have := lv_negInt α (F.fn g 3) f3
    have := b2i_bounds (α f); have := b2i_bounds (α e0); have := b2i_bounds (α e1)
    have := b2i_bounds (α (F.fn g 0)); have := b2i_bounds (α (F.fn g 1))
    have := b2i_bounds (α (F.fn g 2)); have := b2i_bounds (α (F.fn g 3))
    simp only [row2_rhs']
    omega

theorem t2_p1_01_0 (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (g : Nat) (hg : g < F.s)
    (f e0 e1 : Nat) (hf : 1 ≤ f) (he0 : 1 ≤ e0) (he1 : 1 ≤ e1)
    (hor : ∀ R ∈ (orDefs [(e0 : Int), (e1 : Int)]).rows f, R ∈ D)
    (hE0 : ∀ R ∈ (eqDefs (F.fn g 0 : Int) (F.fn g 2 : Int)).rows e0, R ∈ D)
    (hE1 : ∀ R ∈ (eqDefs (F.fn g 1 : Int) (F.fn g 3 : Int)).rows e1, R ∈ D)
    (hB : (F.row2 g 9).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(f : Int), -(F.fn g 0 : Int), (F.fn g 1 : Int)]).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow [(f : Int), -(F.fn g 0 : Int), (F.fn g 1 : Int)]).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have f0 := F.fn_pos g 0; have f1 := F.fn_pos g 1; have f2 := F.fn_pos g 2; have f3 := F.fn_pos g 3
  apply chain6 _ hDc (negate (clauseRow [(f : Int), -(F.fn g 0 : Int), (F.fn g 1 : Int)]).toE)
    (gateRow [-(e0 : Int)] f true).toE (gateRow [-(e1 : Int)] f true).toE
    (gateRow [-(F.fn g 0 : Int), -(F.fn g 2 : Int)] e0 true).toE (gateRow [(F.fn g 1 : Int), (F.fn g 3 : Int)] e1 true).toE (F.row2 g 9).toE
  · exact List.mem_append_right _ (List.mem_singleton.mpr rfl)
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE0 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE1 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ hB
  · intro α
    have hnz : (clauseRow [(f : Int), -(F.fn g 0 : Int), (F.fn g 1 : Int)]).nz := by
      intro l hl; simp [clauseRow] at hl; rcases hl with rfl | rfl | rfl <;> omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz,
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ he0 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (gateRow_nz' _ _ he1 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (F.row2_0_nz' g 9), row2_lits']
    have c0 : codeBit 9 0 = true := by decide
    have c1 : codeBit 9 1 = false := by decide
    have c2 : codeBit 9 2 = false := by decide
    have c3 : codeBit 9 3 = true := by decide
    simp only [clauseRow, gateRow, c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.cons_append,
      List.nil_append, lsum_cons, lsum_nil, lv_negInt, lv_natInt, lv_pos, lv_neg, Int.natAbs_natCast,
      Int.natAbs_neg]
    have := lv_pos α f hf; have := lv_neg α f hf; have := lv_natInt α f hf; have := lv_negInt α f hf
    have := lv_pos α e0 he0; have := lv_neg α e0 he0; have := lv_natInt α e0 he0; have := lv_negInt α e0 he0
    have := lv_pos α e1 he1; have := lv_neg α e1 he1; have := lv_natInt α e1 he1; have := lv_negInt α e1 he1
    have := lv_pos α (F.fn g 0) f0; have := lv_neg α (F.fn g 0) f0; have := lv_natInt α (F.fn g 0) f0; have := lv_negInt α (F.fn g 0) f0
    have := lv_pos α (F.fn g 1) f1; have := lv_neg α (F.fn g 1) f1; have := lv_natInt α (F.fn g 1) f1; have := lv_negInt α (F.fn g 1) f1
    have := lv_pos α (F.fn g 2) f2; have := lv_neg α (F.fn g 2) f2; have := lv_natInt α (F.fn g 2) f2; have := lv_negInt α (F.fn g 2) f2
    have := lv_pos α (F.fn g 3) f3; have := lv_neg α (F.fn g 3) f3; have := lv_natInt α (F.fn g 3) f3; have := lv_negInt α (F.fn g 3) f3
    have := b2i_bounds (α f); have := b2i_bounds (α e0); have := b2i_bounds (α e1)
    have := b2i_bounds (α (F.fn g 0)); have := b2i_bounds (α (F.fn g 1))
    have := b2i_bounds (α (F.fn g 2)); have := b2i_bounds (α (F.fn g 3))
    simp only [row2_rhs']
    omega

theorem t2_p1_01_1 (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (g : Nat) (hg : g < F.s)
    (f e0 e1 : Nat) (hf : 1 ≤ f) (he0 : 1 ≤ e0) (he1 : 1 ≤ e1)
    (hor : ∀ R ∈ (orDefs [(e0 : Int), (e1 : Int)]).rows f, R ∈ D)
    (hE0 : ∀ R ∈ (eqDefs (F.fn g 0 : Int) (F.fn g 2 : Int)).rows e0, R ∈ D)
    (hE1 : ∀ R ∈ (eqDefs (F.fn g 1 : Int) (F.fn g 3 : Int)).rows e1, R ∈ D)
    (hB : (F.row2 g 6).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(f : Int), (F.fn g 0 : Int), -(F.fn g 1 : Int)]).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow [(f : Int), (F.fn g 0 : Int), -(F.fn g 1 : Int)]).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have f0 := F.fn_pos g 0; have f1 := F.fn_pos g 1; have f2 := F.fn_pos g 2; have f3 := F.fn_pos g 3
  apply chain6 _ hDc (negate (clauseRow [(f : Int), (F.fn g 0 : Int), -(F.fn g 1 : Int)]).toE)
    (gateRow [-(e0 : Int)] f true).toE (gateRow [-(e1 : Int)] f true).toE
    (gateRow [(F.fn g 0 : Int), (F.fn g 2 : Int)] e0 true).toE (gateRow [-(F.fn g 1 : Int), -(F.fn g 3 : Int)] e1 true).toE (F.row2 g 6).toE
  · exact List.mem_append_right _ (List.mem_singleton.mpr rfl)
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE0 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE1 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ hB
  · intro α
    have hnz : (clauseRow [(f : Int), (F.fn g 0 : Int), -(F.fn g 1 : Int)]).nz := by
      intro l hl; simp [clauseRow] at hl; rcases hl with rfl | rfl | rfl <;> omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz,
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ he0 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (gateRow_nz' _ _ he1 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (F.row2_0_nz' g 6), row2_lits']
    have c0 : codeBit 6 0 = false := by decide
    have c1 : codeBit 6 1 = true := by decide
    have c2 : codeBit 6 2 = true := by decide
    have c3 : codeBit 6 3 = false := by decide
    simp only [clauseRow, gateRow, c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.cons_append,
      List.nil_append, lsum_cons, lsum_nil, lv_negInt, lv_natInt, lv_pos, lv_neg, Int.natAbs_natCast,
      Int.natAbs_neg]
    have := lv_pos α f hf; have := lv_neg α f hf; have := lv_natInt α f hf; have := lv_negInt α f hf
    have := lv_pos α e0 he0; have := lv_neg α e0 he0; have := lv_natInt α e0 he0; have := lv_negInt α e0 he0
    have := lv_pos α e1 he1; have := lv_neg α e1 he1; have := lv_natInt α e1 he1; have := lv_negInt α e1 he1
    have := lv_pos α (F.fn g 0) f0; have := lv_neg α (F.fn g 0) f0; have := lv_natInt α (F.fn g 0) f0; have := lv_negInt α (F.fn g 0) f0
    have := lv_pos α (F.fn g 1) f1; have := lv_neg α (F.fn g 1) f1; have := lv_natInt α (F.fn g 1) f1; have := lv_negInt α (F.fn g 1) f1
    have := lv_pos α (F.fn g 2) f2; have := lv_neg α (F.fn g 2) f2; have := lv_natInt α (F.fn g 2) f2; have := lv_negInt α (F.fn g 2) f2
    have := lv_pos α (F.fn g 3) f3; have := lv_neg α (F.fn g 3) f3; have := lv_natInt α (F.fn g 3) f3; have := lv_negInt α (F.fn g 3) f3
    have := b2i_bounds (α f); have := b2i_bounds (α e0); have := b2i_bounds (α e1)
    have := b2i_bounds (α (F.fn g 0)); have := b2i_bounds (α (F.fn g 1))
    have := b2i_bounds (α (F.fn g 2)); have := b2i_bounds (α (F.fn g 3))
    simp only [row2_rhs']
    omega

theorem t2_p1_23_0 (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (g : Nat) (hg : g < F.s)
    (f e0 e1 : Nat) (hf : 1 ≤ f) (he0 : 1 ≤ e0) (he1 : 1 ≤ e1)
    (hor : ∀ R ∈ (orDefs [(e0 : Int), (e1 : Int)]).rows f, R ∈ D)
    (hE0 : ∀ R ∈ (eqDefs (F.fn g 0 : Int) (F.fn g 2 : Int)).rows e0, R ∈ D)
    (hE1 : ∀ R ∈ (eqDefs (F.fn g 1 : Int) (F.fn g 3 : Int)).rows e1, R ∈ D)
    (hB : (F.row2 g 6).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(f : Int), -(F.fn g 2 : Int), (F.fn g 3 : Int)]).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow [(f : Int), -(F.fn g 2 : Int), (F.fn g 3 : Int)]).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have f0 := F.fn_pos g 0; have f1 := F.fn_pos g 1; have f2 := F.fn_pos g 2; have f3 := F.fn_pos g 3
  apply chain6 _ hDc (negate (clauseRow [(f : Int), -(F.fn g 2 : Int), (F.fn g 3 : Int)]).toE)
    (gateRow [-(e0 : Int)] f true).toE (gateRow [-(e1 : Int)] f true).toE
    (gateRow [-(F.fn g 0 : Int), -(F.fn g 2 : Int)] e0 true).toE (gateRow [(F.fn g 1 : Int), (F.fn g 3 : Int)] e1 true).toE (F.row2 g 6).toE
  · exact List.mem_append_right _ (List.mem_singleton.mpr rfl)
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE0 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE1 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ hB
  · intro α
    have hnz : (clauseRow [(f : Int), -(F.fn g 2 : Int), (F.fn g 3 : Int)]).nz := by
      intro l hl; simp [clauseRow] at hl; rcases hl with rfl | rfl | rfl <;> omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz,
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ he0 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (gateRow_nz' _ _ he1 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (F.row2_0_nz' g 6), row2_lits']
    have c0 : codeBit 6 0 = false := by decide
    have c1 : codeBit 6 1 = true := by decide
    have c2 : codeBit 6 2 = true := by decide
    have c3 : codeBit 6 3 = false := by decide
    simp only [clauseRow, gateRow, c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.cons_append,
      List.nil_append, lsum_cons, lsum_nil, lv_negInt, lv_natInt, lv_pos, lv_neg, Int.natAbs_natCast,
      Int.natAbs_neg]
    have := lv_pos α f hf; have := lv_neg α f hf; have := lv_natInt α f hf; have := lv_negInt α f hf
    have := lv_pos α e0 he0; have := lv_neg α e0 he0; have := lv_natInt α e0 he0; have := lv_negInt α e0 he0
    have := lv_pos α e1 he1; have := lv_neg α e1 he1; have := lv_natInt α e1 he1; have := lv_negInt α e1 he1
    have := lv_pos α (F.fn g 0) f0; have := lv_neg α (F.fn g 0) f0; have := lv_natInt α (F.fn g 0) f0; have := lv_negInt α (F.fn g 0) f0
    have := lv_pos α (F.fn g 1) f1; have := lv_neg α (F.fn g 1) f1; have := lv_natInt α (F.fn g 1) f1; have := lv_negInt α (F.fn g 1) f1
    have := lv_pos α (F.fn g 2) f2; have := lv_neg α (F.fn g 2) f2; have := lv_natInt α (F.fn g 2) f2; have := lv_negInt α (F.fn g 2) f2
    have := lv_pos α (F.fn g 3) f3; have := lv_neg α (F.fn g 3) f3; have := lv_natInt α (F.fn g 3) f3; have := lv_negInt α (F.fn g 3) f3
    have := b2i_bounds (α f); have := b2i_bounds (α e0); have := b2i_bounds (α e1)
    have := b2i_bounds (α (F.fn g 0)); have := b2i_bounds (α (F.fn g 1))
    have := b2i_bounds (α (F.fn g 2)); have := b2i_bounds (α (F.fn g 3))
    simp only [row2_rhs']
    omega

theorem t2_p1_23_1 (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (g : Nat) (hg : g < F.s)
    (f e0 e1 : Nat) (hf : 1 ≤ f) (he0 : 1 ≤ e0) (he1 : 1 ≤ e1)
    (hor : ∀ R ∈ (orDefs [(e0 : Int), (e1 : Int)]).rows f, R ∈ D)
    (hE0 : ∀ R ∈ (eqDefs (F.fn g 0 : Int) (F.fn g 2 : Int)).rows e0, R ∈ D)
    (hE1 : ∀ R ∈ (eqDefs (F.fn g 1 : Int) (F.fn g 3 : Int)).rows e1, R ∈ D)
    (hB : (F.row2 g 9).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(f : Int), (F.fn g 2 : Int), -(F.fn g 3 : Int)]).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow [(f : Int), (F.fn g 2 : Int), -(F.fn g 3 : Int)]).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have f0 := F.fn_pos g 0; have f1 := F.fn_pos g 1; have f2 := F.fn_pos g 2; have f3 := F.fn_pos g 3
  apply chain6 _ hDc (negate (clauseRow [(f : Int), (F.fn g 2 : Int), -(F.fn g 3 : Int)]).toE)
    (gateRow [-(e0 : Int)] f true).toE (gateRow [-(e1 : Int)] f true).toE
    (gateRow [(F.fn g 0 : Int), (F.fn g 2 : Int)] e0 true).toE (gateRow [-(F.fn g 1 : Int), -(F.fn g 3 : Int)] e1 true).toE (F.row2 g 9).toE
  · exact List.mem_append_right _ (List.mem_singleton.mpr rfl)
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hor _ (by simp [orDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE0 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ (hE1 _ (by simp [eqDefs, Defs.rows]))
  · exact List.mem_append_left _ hB
  · intro α
    have hnz : (clauseRow [(f : Int), (F.fn g 2 : Int), -(F.fn g 3 : Int)]).nz := by
      intro l hl; simp [clauseRow] at hl; rcases hl with rfl | rfl | rfl <;> omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz,
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ hf (by intro l hl; simp at hl; subst hl; omega) _),
      val_toE _ (gateRow_nz' _ _ he0 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (gateRow_nz' _ _ he1 (by intro l hl; simp at hl; rcases hl with rfl | rfl <;> omega) _),
      val_toE _ (F.row2_0_nz' g 9), row2_lits']
    have c0 : codeBit 9 0 = true := by decide
    have c1 : codeBit 9 1 = false := by decide
    have c2 : codeBit 9 2 = false := by decide
    have c3 : codeBit 9 3 = true := by decide
    simp only [clauseRow, gateRow, c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.cons_append,
      List.nil_append, lsum_cons, lsum_nil, lv_negInt, lv_natInt, lv_pos, lv_neg, Int.natAbs_natCast,
      Int.natAbs_neg]
    have := lv_pos α f hf; have := lv_neg α f hf; have := lv_natInt α f hf; have := lv_negInt α f hf
    have := lv_pos α e0 he0; have := lv_neg α e0 he0; have := lv_natInt α e0 he0; have := lv_negInt α e0 he0
    have := lv_pos α e1 he1; have := lv_neg α e1 he1; have := lv_natInt α e1 he1; have := lv_negInt α e1 he1
    have := lv_pos α (F.fn g 0) f0; have := lv_neg α (F.fn g 0) f0; have := lv_natInt α (F.fn g 0) f0; have := lv_negInt α (F.fn g 0) f0
    have := lv_pos α (F.fn g 1) f1; have := lv_neg α (F.fn g 1) f1; have := lv_natInt α (F.fn g 1) f1; have := lv_negInt α (F.fn g 1) f1
    have := lv_pos α (F.fn g 2) f2; have := lv_neg α (F.fn g 2) f2; have := lv_natInt α (F.fn g 2) f2; have := lv_negInt α (F.fn g 2) f2
    have := lv_pos α (F.fn g 3) f3; have := lv_neg α (F.fn g 3) f3; have := lv_natInt α (F.fn g 3) f3; have := lv_negInt α (F.fn g 3) f3
    have := b2i_bounds (α f); have := b2i_bounds (α e0); have := b2i_bounds (α e1)
    have := b2i_bounds (α (F.fn g 0)); have := b2i_bounds (α (F.fn g 1))
    have := b2i_bounds (α (F.fn g 2)); have := b2i_bounds (α (F.fn g 3))
    simp only [row2_rhs']
    omega


/-! ### Stage 4 as a whole -/

theorem forceRups_var (t : StI F.V) (gp : Nat × Nat) : (F.forceRups t gp).s.var = t.s.var := by
  obtain ⟨g, port⟩ := gp
  unfold forceRups
  simp only []
  split <;> rfl

theorem forceRups_force (t : StI F.V) (gp : Nat × Nat) : (F.forceRups t gp).s.force = t.s.force :=
  (F.keeps_forceRups t gp).2.2

/-- the (g, port) pairs of stage 4 -/
def pairs4 : List (Nat × Nat) := (List.range' 1 (F.s - 1)).flatMap fun g => [(g, 0), (g, 1)]

theorem mem_pairs4 (gp : Nat × Nat) : gp ∈ F.pairs4 ↔ 1 ≤ gp.1 ∧ gp.1 < F.s ∧ gp.2 < 2 := by
  unfold pairs4
  simp only [List.mem_flatMap, List.mem_range'_1, List.mem_cons, List.not_mem_nil, or_false]
  constructor
  · rintro ⟨g, hg, h | h⟩ <;> subst h <;> simp <;> omega
  · intro h
    refine ⟨gp.1, ⟨h.1, by omega⟩, ?_⟩
    have : gp.2 = 0 ∨ gp.2 = 1 := by omega
    rcases this with h2 | h2
    · left; exact Prod.ext rfl h2
    · right; exact Prod.ext rfl h2

/-- stage 4 appends exactly the force clauses of every pair -/
theorem stage4_cmds (t : StI F.V)
    (hb : ∀ gp ∈ F.pairs4, 1 ≤ t.s.force gp.1 gp.2 ∧ t.s.force gp.1 gp.2 ≤ t.s.var) :
    (F.stage4 t).s.cmds = t.s.cmds ++ F.pairs4.flatMap fun gp =>
      (F.forceClauses gp.1 gp.2 (t.s.force gp.1 gp.2)).map Cmd.rup := by
  unfold stage4
  -- strengthen: for every state with the same var and force
  suffices h : ∀ (l : List (Nat × Nat)), (∀ gp ∈ l, gp ∈ F.pairs4) → ∀ (t' : StI F.V),
      t'.s.var = t.s.var → t'.s.force = t.s.force →
      (l.foldl F.forceRups t').s.cmds = t'.s.cmds ++ l.flatMap fun gp =>
        (F.forceClauses gp.1 gp.2 (t.s.force gp.1 gp.2)).map Cmd.rup by
    exact h F.pairs4 (fun gp h => h) t rfl rfl
  intro l
  induction l with
  | nil => intro _ t' _ _; simp
  | cons gp l ih =>
    intro hl t' hv hf
    simp only [List.foldl_cons, List.flatMap_cons]
    have hgp := hl gp (by simp)
    have hg : gp.1 < F.s := ((F.mem_pairs4 gp).mp hgp).2.1
    have hb' := hb gp hgp
    rw [ih (fun gp' h => hl gp' (by simp [h])) _ (by rw [F.forceRups_var, hv]) (by rw [F.forceRups_force, hf])]
    obtain ⟨g, port⟩ := gp
    rw [F.forceRups_cmds t' g port hg (by rw [hf, hv]; exact hb')]
    rw [hf]; simp [List.append_assoc]

/-- every rup obligation's database consists of canonical rows -/
theorem obls_canonical (D : List EREF.Row) (m : Nat) (cs : List Cmd) (hD : DBBounded D m) (hwf : WF m cs) :
    ∀ o ∈ obls D cs, ∀ R ∈ o.1, Canonical R := by
  induction cs generalizing D m with
  | nil => intro o ho; simp [obls] at ho
  | cons c cs ih =>
    intro o ho
    cases c with
    | rup c =>
      simp only [obls, List.mem_cons] at ho
      rcases ho with rfl | ho
      · exact hD.canonical
      · exact ih _ _ (hD.append (clauseRow c) hwf.1) hwf.2 o ho
    | orDef q xs =>
      obtain ⟨rfl, hxs, hwf⟩ := hwf
      have hD' := exec_bounded D m [.orDef (m + 1) xs] hD ⟨rfl, hxs, trivial⟩
      simp only [exec, varAfter] at hD'
      exact ih _ _ hD' hwf o ho
    | andDef q xs =>
      obtain ⟨rfl, hxs, hwf⟩ := hwf
      have hD' := exec_bounded D m [.andDef (m + 1) xs] hD ⟨rfl, hxs, trivial⟩
      simp only [exec, varAfter] at hD'
      exact ih _ _ hD' hwf o ho
    | eqDef q a b =>
      obtain ⟨rfl, hab, hwf⟩ := hwf
      have hD' := exec_bounded D m [.eqDef (m + 1) a b] hD ⟨rfl, hab, trivial⟩
      simp only [exec, varAfter] at hD'
      exact ih _ _ hD' hwf o ho

theorem row2_mem_db5 (hs : 1 ≤ F.s) (g c : Nat) (hg : g < F.s) (hc : c = 6 ∨ c = 9) : (F.row2 g c).toE ∈ F.db5 := by
  unfold db5 db4
  exact List.mem_append_left _ (List.mem_append_left _ (F.db2_sub_db3 _ (F.toE_mem_db2 F.k _ (F.row2_mem g c hg hc))))

/-- **Template T2 for all k, s**: every rup obligation of stage 4 is refuted -/
theorem stage4_obls (hk : 1 ≤ F.k) (hs : 1 ≤ F.s) (t : StI F.V)
    (hPF : ∀ g port, 1 ≤ g → g < F.s → port < 2 → F.PForce g port t)
    (hPE : ∀ g port b, 1 ≤ g → g < F.s → port < 2 → b < 2 → F.PEq g port b t) :
    ∀ o ∈ obls (exec F.db5 t.s.cmds) (F.pairs4.flatMap fun gp =>
        (F.forceClauses gp.1 gp.2 (t.s.force gp.1 gp.2)).map Cmd.rup),
      Refutation (o.1 ++ [negate (clauseRow o.2).toE]) := by
  intro o ho
  -- the database at the start of stage 4 and its canonicity
  have hDB : DBBounded (exec F.db5 t.s.cmds) (varAfter F.V t.s.cmds) :=
    exec_bounded _ _ _ (F.db5_bounded hk hs) t.inv.1
  have hwf4 : WF (varAfter F.V t.s.cmds) (F.pairs4.flatMap fun gp =>
      (F.forceClauses gp.1 gp.2 (t.s.force gp.1 gp.2)).map Cmd.rup) := by
    -- rup-only command lists are WF when their literals are bounded
    rw [t.inv.2]
    have : ∀ (l : List (Nat × Nat)), (∀ gp ∈ l, gp ∈ F.pairs4) → WF t.s.var (l.flatMap fun gp =>
        (F.forceClauses gp.1 gp.2 (t.s.force gp.1 gp.2)).map Cmd.rup) := by
      intro l
      induction l with
      | nil => intro _; trivial
      | cons gp l ih =>
        intro hl
        have hgp := hl gp (by simp)
        obtain ⟨hg1, hg, hp⟩ := (F.mem_pairs4 gp).mp hgp
        obtain ⟨_, hfl, hfu⟩ := hPF gp.1 gp.2 hg1 hg hp
        have hV := t.var_ge; have hS := F.S4_le_V
        have hfn : ∀ ab, ab < 4 → 1 ≤ ((F.fn gp.1 ab : Nat) : Int).natAbs ∧ ((F.fn gp.1 ab : Nat) : Int).natAbs ≤ t.s.var := by
          intro ab hab; have := F.fn_range gp.1 ab hg hab; simp; omega
        have h0 := hfn 0 (by omega); have h1 := hfn 1 (by omega)
        have h2 := hfn 2 (by omega); have h3 := hfn 3 (by omega)
        simp only [List.flatMap_cons]
        apply WF_append _ _ _ _ (by
          have := ih (fun gp' h => hl gp' (by simp [h]))
          rwa [show varAfter t.s.var ((F.forceClauses gp.1 gp.2 (t.s.force gp.1 gp.2)).map Cmd.rup) = t.s.var from by
            unfold forceClauses; split <;> rfl])
        unfold forceClauses
        split <;> simp only [List.flatMap_cons, List.flatMap_nil, List.append_nil, List.map_cons, List.map_nil,
          List.cons_append, List.nil_append, WF] <;>
          refine ⟨?_, ?_, ?_, ?_, trivial⟩ <;> intro l hl <;>
          simp only [List.mem_cons, List.not_mem_nil, or_false] at hl <;>
          rcases hl with rfl | rfl | rfl <;> simp <;> omega
    exact this F.pairs4 (fun gp h => h)
  have hcan : ∀ R ∈ o.1, Canonical R := obls_canonical _ _ _ hDB hwf4 o ho
  obtain ⟨ext, hext⟩ := obls_db_ext _ _ o ho
  have hrup := obls_clause_mem _ _ o ho
  -- identify the pair and the clause
  simp only [List.mem_flatMap, List.mem_map] at hrup
  obtain ⟨gp, hgp, c, hc, hcr⟩ := hrup
  have hceq : c = o.2 := Cmd.rup.inj hcr
  rw [← hceq]
  obtain ⟨hg1, hg, hp⟩ := (F.mem_pairs4 gp).mp hgp
  obtain ⟨g, port⟩ := gp
  simp only at hg1 hg hp
  -- the rows of the definitions and the forbidden-code rows are in the database
  have hmemD : ∀ R ∈ exec F.db5 t.s.cmds, R ∈ o.1 := by
    intro R hR; rw [hext]; exact List.mem_append_left _ hR
  obtain ⟨hforce, hfl, _⟩ := hPF g port hg1 hg hp
  have hor : ∀ R ∈ (orDefs [(t.s.eqrow g port 0 : Int), (t.s.eqrow g port 1 : Int)]).rows (t.s.force g port), R ∈ o.1 :=
    fun R hR => hmemD R (mem_exec_of_cmd _ _ _ hforce R hR)
  obtain ⟨heq0, he0l, _⟩ := hPE g port 0 hg1 hg hp (by omega)
  obtain ⟨heq1, he1l, _⟩ := hPE g port 1 hg1 hg hp (by omega)
  have hE0 : ∀ R ∈ (eqDefs (F.fn g (eqPair port 0).1 : Int) (F.fn g (eqPair port 0).2 : Int)).rows (t.s.eqrow g port 0), R ∈ o.1 :=
    fun R hR => hmemD R (mem_exec_of_cmd _ _ _ heq0 R hR)
  have hE1 : ∀ R ∈ (eqDefs (F.fn g (eqPair port 1).1 : Int) (F.fn g (eqPair port 1).2 : Int)).rows (t.s.eqrow g port 1), R ∈ o.1 :=
    fun R hR => hmemD R (mem_exec_of_cmd _ _ _ heq1 R hR)
  have hB6 : (F.row2 g 6).toE ∈ o.1 := hmemD _ (exec_mono _ _ _ (F.row2_mem_db5 hs g 6 hg (by omega)))
  have hB9 : (F.row2 g 9).toE ∈ o.1 := hmemD _ (exec_mono _ _ _ (F.row2_mem_db5 hs g 9 hg (by omega)))
  have hf1 : 1 ≤ t.s.force g port := by omega
  have he0' : 1 ≤ t.s.eqrow g port 0 := by omega
  have he1' : 1 ≤ t.s.eqrow g port 1 := by omega
  -- the eight cases
  have hp' : port = 0 ∨ port = 1 := by omega
  rcases hp' with rfl | rfl
  · simp only [eqPair, ↓reduceIte] at hE0 hE1
    simp [forceClauses] at hc
    rcases hc with rfl | rfl | rfl | rfl
    · exact F.t2_p0_02_0 o.1 hcan g hg _ _ _ hf1 he0' he1' hor hE0 hE1 hB9
    · exact F.t2_p0_02_1 o.1 hcan g hg _ _ _ hf1 he0' he1' hor hE0 hE1 hB6
    · exact F.t2_p0_13_0 o.1 hcan g hg _ _ _ hf1 he0' he1' hor hE0 hE1 hB6
    · exact F.t2_p0_13_1 o.1 hcan g hg _ _ _ hf1 he0' he1' hor hE0 hE1 hB9
  · simp only [eqPair, Nat.one_ne_zero, ↓reduceIte] at hE0 hE1
    simp [forceClauses] at hc
    rcases hc with rfl | rfl | rfl | rfl
    · exact F.t2_p1_01_0 o.1 hcan g hg _ _ _ hf1 he0' he1' hor hE0 hE1 hB9
    · exact F.t2_p1_01_1 o.1 hcan g hg _ _ _ hf1 he0' he1' hor hE0 hE1 hB6
    · exact F.t2_p1_23_0 o.1 hcan g hg _ _ _ hf1 he0' he1' hor hE0 hE1 hB6
    · exact F.t2_p1_23_1 o.1 hcan g hg _ _ _ hf1 he0' he1' hor hE0 hE1 hB9


/-! ### Assembly: stages 0–4 discharged, obligations reduced to stages 5–7 -/

end Fam

/-- a command list without rup lines contributes no obligations -/
def NoRup (cs : List Cmd) : Prop := ∀ c ∈ cs, ∀ x, c ≠ Cmd.rup x

theorem obls_nil_of_noRup (D : List EREF.Row) (cs : List Cmd) (h : NoRup cs) : obls D cs = [] := by
  induction cs generalizing D with
  | nil => rfl
  | cons c cs ih =>
    cases c with
    | rup x => exact absurd rfl (h _ (by simp) x)
    | orDef q xs => exact ih _ (fun c hc => h c (by simp [hc]))
    | andDef q xs => exact ih _ (fun c hc => h c (by simp [hc]))
    | eqDef q a b => exact ih _ (fun c hc => h c (by simp [hc]))

namespace StI
variable {m0 : Nat}

/-- a transition that appends only definition commands -/
def DefsOnly (t t' : StI m0) : Prop := ∃ cs, t'.s.cmds = t.s.cmds ++ cs ∧ NoRup cs

theorem defsOnly_refl (t : StI m0) : DefsOnly t t := ⟨[], by simp, fun c hc => by simp at hc⟩
theorem defsOnly_trans {a b c : StI m0} (h1 : DefsOnly a b) (h2 : DefsOnly b c) : DefsOnly a c := by
  obtain ⟨c1, h1, n1⟩ := h1; obtain ⟨c2, h2, n2⟩ := h2
  refine ⟨c1 ++ c2, by rw [h2, h1, List.append_assoc], ?_⟩
  intro c hc x
  rcases List.mem_append.mp hc with hc | hc
  · exact n1 c hc x
  · exact n2 c hc x
theorem defsOnly_OR (t : StI m0) (xs) : DefsOnly t (t.OR xs).2 :=
  ⟨_, rfl, fun c hc x => by simp at hc; subst hc; simp⟩
theorem defsOnly_AND (t : StI m0) (xs) : DefsOnly t (t.AND xs).2 :=
  ⟨_, rfl, fun c hc x => by simp at hc; subst hc; simp⟩
theorem defsOnly_EQ (t : StI m0) (hm : 1 ≤ m0) (a b) : DefsOnly t (t.EQ hm a b).2 :=
  ⟨_, rfl, fun c hc x => by simp at hc; subst hc; simp⟩
theorem defsOnly_set (t : StI m0) (t' : StI m0) (h : t'.s.cmds = t.s.cmds) : DefsOnly t t' :=
  ⟨[], by simp [h], fun c hc => by simp at hc⟩
theorem defsOnly_foldl {α : Type} (f : StI m0 → α → StI m0) (l : List α) (hf : ∀ t x, DefsOnly t (f t x)) :
    ∀ t, DefsOnly t (l.foldl f t) := by
  intro t
  apply foldl_pres (fun t' => DefsOnly t t') f l
  · intro x _ t' h; exact defsOnly_trans h (hf t' x)
  · exact defsOnly_refl t
theorem defsOnly_foldl_pair {α β : Type} (f : StI m0 × β → α → StI m0 × β) (l : List α)
    (hf : ∀ acc x, DefsOnly acc.1 (f acc x).1) : ∀ acc, DefsOnly acc.1 (l.foldl f acc).1 := by
  intro acc
  apply foldl_pres (fun acc' => DefsOnly acc.1 acc'.1) f l
  · intro x _ acc' h; exact defsOnly_trans h (hf acc' x)
  · exact defsOnly_refl _

end StI

namespace Fam
variable (F : Fam)
open StI

theorem defsOnly_edgeStep (g : Nat) (acc : StI F.V × List Int) (hp : Nat × Nat) :
    DefsOnly acc.1 (F.edgeStep g acc hp).1 := by
  obtain ⟨t, terms⟩ := acc; obtain ⟨h, port⟩ := hp
  exact defsOnly_trans (defsOnly_AND _ _) (defsOnly_set _ _ rfl)
theorem defsOnly_gateStep (t : StI F.V) (g : Nat) : DefsOnly t (F.gateStep t g) := by
  unfold gateStep
  simp only []
  generalize hP : (F.edgePairs g).foldl (F.edgeStep g) (t, []) = P
  have k1 : DefsOnly t P.1 := by rw [← hP]; exact defsOnly_foldl_pair _ _ (fun acc hp => F.defsOnly_edgeStep g acc hp) (t, [])
  obtain ⟨t', terms⟩ := P
  simp only []
  exact defsOnly_trans k1 (defsOnly_trans (defsOnly_OR _ _) (defsOnly_set _ _ rfl))
theorem defsOnly_stage1 (t : StI F.V) : DefsOnly t (F.stage1 t) :=
  defsOnly_foldl _ _ (fun t' g => F.defsOnly_gateStep t' g) t
theorem defsOnly_eqStep (hm : 1 ≤ F.V) (g port : Nat) (acc : StI F.V × List Int) (b : Nat) :
    DefsOnly acc.1 (F.eqStep hm g port acc b).1 := by
  obtain ⟨t, eqs⟩ := acc
  exact defsOnly_trans (defsOnly_EQ _ hm _ _) (defsOnly_set _ _ rfl)
theorem defsOnly_portStep (hm : 1 ≤ F.V) (g : Nat) (acc : StI F.V × List Int) (port : Nat) :
    DefsOnly acc.1 (F.portStep hm g acc port).1 := by
  obtain ⟨t, ports⟩ := acc
  show DefsOnly t ((((([0, 1].foldl (F.eqStep hm g port) (t, [])).1.OR _).2.setForce _).AND _).2.setP0force _)
  apply defsOnly_trans (defsOnly_foldl_pair _ _ (fun acc b => F.defsOnly_eqStep hm g port acc b) (t, []))
  exact defsOnly_trans (defsOnly_OR _ _) (defsOnly_trans (defsOnly_set _ _ rfl)
    (defsOnly_trans (defsOnly_AND _ _) (defsOnly_set _ _ rfl)))
theorem defsOnly_eligStep (hm : 1 ≤ F.V) (t : StI F.V) (g : Nat) : DefsOnly t (F.eligStep hm t g) := by
  show DefsOnly t (((([0, 1].foldl (F.portStep hm g) (t, [])).1.OR _).2.AND _).2.setEligible _)
  apply defsOnly_trans (defsOnly_foldl_pair _ _ (fun acc port => F.defsOnly_portStep hm g acc port) (t, []))
  exact defsOnly_trans (defsOnly_OR _ _) (defsOnly_trans (defsOnly_AND _ _) (defsOnly_set _ _ rfl))
theorem defsOnly_stage2 (hm : 1 ≤ F.V) (t : StI F.V) : DefsOnly t (F.stage2 hm t) :=
  defsOnly_foldl _ _ (fun t' g => F.defsOnly_eligStep hm t' g) t
theorem defsOnly_stage3 (t : StI F.V) : DefsOnly t (F.stage3 t) :=
  defsOnly_trans (defsOnly_OR _ _) (defsOnly_set _ _ rfl)

/-- the state after stage 3 -/
def t3 (hs : 1 ≤ F.s) : StI F.V := F.stage3 (F.stage2 (F.V_pos hs) (F.stage1 F.stage0))
/-- the state after stage 4 -/
def t4 (hs : 1 ≤ F.s) : StI F.V := F.stage4 (F.t3 hs)

theorem t3_PForce (hs : 1 ≤ F.s) (g port : Nat) (hg1 : 1 ≤ g) (hg : g < F.s) (hp : port < 2) :
    F.PForce g port (F.t3 hs) := by
  have h2 := F.stage2_PForce (F.V_pos hs) (F.stage1 F.stage0) g port hg1 hg hp
  have k := F.keeps_stage3 (F.stage2 (F.V_pos hs) (F.stage1 F.stage0))
  unfold t3
  exact F.PForce_of_grows k.1 (fun b => by rw [k.2.1]) (by rw [k.2.2]) h2

theorem t3_PEq (hs : 1 ≤ F.s) (g port b : Nat) (hg1 : 1 ≤ g) (hg : g < F.s) (hp : port < 2) (hb : b < 2) :
    F.PEq g port b (F.t3 hs) := by
  have h2 := F.stage2_PEq (F.V_pos hs) (F.stage1 F.stage0) g port b hg1 hg hp hb
  have k := F.keeps_stage3 (F.stage2 (F.V_pos hs) (F.stage1 F.stage0))
  unfold t3
  exact F.PEq_of_grows k.1 (by rw [k.2.1]) h2

/-- **all rup obligations up to and including stage 4 are refuted** -/
theorem obls_t4 (hk : 1 ≤ F.k) (hs : 1 ≤ F.s) :
    ∀ o ∈ obls F.db5 (F.t4 hs).s.cmds, Refutation (o.1 ++ [negate (clauseRow o.2).toE]) := by
  have hb : ∀ gp ∈ F.pairs4, 1 ≤ (F.t3 hs).s.force gp.1 gp.2 ∧ (F.t3 hs).s.force gp.1 gp.2 ≤ (F.t3 hs).s.var := by
    intro gp hgp
    obtain ⟨hg1, hg, hp⟩ := (F.mem_pairs4 gp).mp hgp
    obtain ⟨_, h1, h2⟩ := F.t3_PForce hs gp.1 gp.2 hg1 hg hp
    exact ⟨by omega, h2⟩
  have h4 := F.stage4_cmds (F.t3 hs) hb
  show ∀ o ∈ obls F.db5 (F.stage4 (F.t3 hs)).s.cmds, _
  rw [h4, obls_append]
  intro o ho
  rcases List.mem_append.mp ho with ho | ho
  · -- stages 0–3: only the T1 obligation
    have d123 : DefsOnly F.stage0 (F.t3 hs) :=
      defsOnly_trans (F.defsOnly_stage1 _) (defsOnly_trans (F.defsOnly_stage2 _ _) (F.defsOnly_stage3 _))
    obtain ⟨c123, hc, hn⟩ := d123
    rw [hc, obls_append, obls_nil_of_noRup _ _ hn, List.append_nil] at ho
    exact F.stage0_obls hk hs o ho
  · exact F.stage4_obls hk hs (F.t3 hs) (fun g port => F.t3_PForce hs g port)
      (fun g port b => F.t3_PEq hs g port b) o ho

/-- **the frontend trace with the obligations reduced to stages 5–7** -/
theorem frontendX_trace_57 (hk : 1 ≤ F.k) (hs : 1 ≤ F.s) (c567 : List Cmd)
    (hc : (F.frontendX hs).s.cmds = (F.t4 hs).s.cmds ++ c567)
    (hobl : ∀ o ∈ obls (exec F.db5 (F.t4 hs).s.cmds) c567, Refutation (o.1 ++ [negate (clauseRow o.2).toE])) :
    CheckedTrace F.db5 (exec F.db5 (F.frontendX hs).s.cmds) := by
  apply exec_trace F.db5 F.V _ (F.db5_bounded hk hs) (F.frontendX hs).inv.1
  rw [hc, obls_append]
  intro o ho
  rcases List.mem_append.mp ho with ho | ho
  · exact F.obls_t4 hk hs o ho
  · exact hobl o ho

end Fam
end L3

#print axioms L3.Fam.stage4_obls
#print axioms L3.Fam.obls_t4
#print axioms L3.Fam.frontendX_trace_57

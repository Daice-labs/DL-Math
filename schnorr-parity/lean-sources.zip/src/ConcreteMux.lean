import ConcretePortTokens

namespace L3Emitter.ConcreteMux
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteGateRows ReferenceTransport
variable {base : List Row}

theorem backwards_sum (c a y v q : Bit) :
    add (add (clause [-q.val,y.val,v.val]) (clause [-y.val,a.val]))
      (clause [-v.val,-c.val])=clause [-c.val,-q.val,a.val] := by
  apply canonical_ext _ _ (canonical_add _ _) (canonical_normalize _ _)
  intro α
  change (add (add (clause [-q.val,y.val,v.val]) (clause [-y.val,a.val]))
    (clause [-v.val,-c.val])).val α=(clause [-c.val,-q.val,a.val]).val α
  rw [val_add (add (clause [-q.val,y.val,v.val]) (clause [-y.val,a.val]))
      (clause [-v.val,-c.val]) (canonical_add _ _) (canonical_normalize _ _),
    val_add (clause [-q.val,y.val,v.val]) (clause [-y.val,a.val]) (canonical_normalize _ _) (canonical_normalize _ _),
    val_clause _ (by simp [Valid,q.property,y.property,v.property]),
    val_clause _ (by simp [Valid,y.property,a.property]),
    val_clause _ (by simp [Valid,v.property,c.property]),
    val_clause _ (by simp [Valid,c.property,q.property,a.property])]
  simp only [sum_cons,sum_nil,litVal_neg α y.val y.property,litVal_neg α v.val v.property]
  ring

def backTape (D : List Row) (c a y v q : Bit) : List Tok :=
  [.ref (locate D (clause [-q.val,y.val,v.val])),
   .ref (locate D (clause [-y.val,a.val])),.add,
   .ref (locate D (clause [-v.val,-c.val])),.add]

theorem back_check (D : List Row) (c a y v q : Bit)
    (h1 : clause [-q.val,y.val,v.val]∈D)
    (h2 : clause [-y.val,a.val]∈D) (h3 : clause [-v.val,-c.val]∈D) :
    polEval (dbOf D) (backTape D c a y v q) []=some (clause [-c.val,-q.val,a.val]) := by
  simp only [backTape,polEval,locate_correct _ _ h1,locate_correct _ _ h2,locate_correct _ _ h3]
  rw [backwards_sum]

structure Inputs (D : List Row) (c a b y v q : Bit) : Prop where
  leftUp : clause [-c.val,-a.val,y.val]∈D
  rightUp : clause [c.val,-b.val,v.val]∈D
  leftDown : clause [-y.val,a.val]∈D
  leftChoice : clause [-y.val,c.val]∈D
  rightDown : clause [-v.val,b.val]∈D
  rightChoice : clause [-v.val,-c.val]∈D
  orLeft : clause [-y.val,q.val]∈D
  orRight : clause [-v.val,q.val]∈D
  orBack : clause [-q.val,y.val,v.val]∈D

theorem actual_inputs (z : Net base) (c a b : Bit) :
    Inputs (MUX c a b z).2.rows c a b (AND [c,a] z).1
      (AND [neg c,b] (AND [c,a] z).2).1 (MUX c a b z).1 := by
  let l:=AND [c,a] z
  let r:=AND [neg c,b] l.2
  let o:=OR [l.1,r.1] r.2
  have hR:∀R∈r.2.rows,R∈o.2.rows:=push_retains r.2 false _
  have hL:∀R∈l.2.rows,R∈o.2.rows:=fun R hr=>hR R (push_retains l.2 true _ R hr)
  change Inputs o.2.rows c a b l.1 r.1 o.1
  refine ⟨hL _ (and_up z c a),?_,hL _ (and_down z _ a (by simp)),
    hL _ (and_down z _ c (by simp)),hR _ (and_down l.2 _ b (by simp)),
    hR _ (and_down l.2 _ (neg c) (by simp)),or_up r.2 _ l.1 (by simp),
    or_up r.2 _ r.1 (by simp),?_⟩
  · simpa only [neg,neg_neg] using hR _ (and_up l.2 (neg c) b)
  · have h:=or_down r.2 [l.1,r.1]
    change clause [l.1.val,r.1.val,-o.1.val]∈o.2.rows at h
    have hp : [l.1.val,r.1.val,-o.1.val].Perm [-o.1.val,l.1.val,r.1.val] := by
      simpa using (List.perm_append_comm :
        ([l.1.val,r.1.val]++[-o.1.val]).Perm ([-o.1.val]++[l.1.val,r.1.val]))
    rw [ProjectionTrace.clause_perm _ _
      (by simp [Valid,l.1.property,r.1.property,o.1.property])
      (by simp [Valid,l.1.property,r.1.property,o.1.property]) hp] at h
    exact h

def program (D : List Row) (c a b y v q : Bit) : AliasProgram.Program :=
  [(clause [-c.val,-a.val,q.val],SelectedAlias.forwardTokens D c.val a.val y.val q.val),
   (clause [-c.val,-q.val,a.val],backTape D c a y v q),
   (clause [c.val,-b.val,q.val],SelectedAlias.forwardTokens D (-c.val) b.val v.val q.val),
   (clause [c.val,-q.val,b.val],backTape D (neg c) b v y q)]

theorem checks (D : List Row) (c a b y v q : Bit) (h : Inputs D c a b y v q) :
    AliasProgram.check D (program D c a b y v q)=
      some (D++AliasProgram.outputs (program D c a b y v q)) := by
  apply IndependentProgram.check_base
  intro cmd hm
  simp only [program,List.mem_cons,List.not_mem_nil,or_false] at hm
  rcases hm with rfl|rfl|rfl|rfl
  · exact SelectedAlias.forward_succeeds D c.val a.val y.val q.val
      c.property a.property y.property q.property h.leftUp h.orLeft
  · exact back_check D c a y v q h.orBack h.leftDown h.rightChoice
  · simpa only [neg_neg] using SelectedAlias.forward_succeeds D (-c.val) b.val v.val q.val
      (neg_ne_zero.mpr c.property) b.property v.property q.property
      (by simpa only [neg_neg] using h.rightUp) h.orRight
  · have hp : [-q.val,y.val,v.val].Perm [-q.val,v.val,y.val] :=
      List.Perm.cons _ (List.Perm.swap _ _ [])
    have ho:=h.orBack
    rw [ProjectionTrace.clause_perm _ _ (by simp [Valid,q.property,y.property,v.property])
      (by simp [Valid,q.property,y.property,v.property]) hp] at ho
    simpa only [neg,neg_neg] using back_check D (neg c) b v y q ho h.rightDown
      (by simpa only [neg,neg_neg] using h.leftChoice)

def actual (z : Net base) (c a b : Bit) := program (MUX c a b z).2.rows c a b
  (AND [c,a] z).1 (AND [neg c,b] (AND [c,a] z).2).1 (MUX c a b z).1

theorem actual_check (z : Net base) (c a b : Bit) :
    AliasProgram.check (MUX c a b z).2.rows (actual z c a b)=
      some ((MUX c a b z).2.rows++AliasProgram.outputs (actual z c a b)) :=
  checks _ _ _ _ _ _ _ (actual_inputs z c a b)

theorem actual_trace (z : Net base) (c a b : Bit) :
    CheckedTrace base ((MUX c a b z).2.rows++AliasProgram.outputs (actual z c a b)) :=
  L3.Fam.checkedTrace_trans (MUX c a b z).2.checked
    (AliasProgram.check_trace _ _ _ (actual_check z c a b))

#print axioms actual_inputs
#print axioms actual_check
#print axioms actual_trace
end L3Emitter.ConcreteMux

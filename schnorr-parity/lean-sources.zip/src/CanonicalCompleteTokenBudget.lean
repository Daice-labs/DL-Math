import FieldLengthsFromIDs
import FamilyReferenceWidths
namespace L3Emitter.CanonicalCompleteTokenBudget
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace CanonicalScopedBytes
open ConstructionClosedAllocation RecordedOperandFields FieldLengthsFromIDs

theorem references (n M : Nat) (hn : 2≤n) (hm:ConstructionClosedReference.nextBound n≤M) :
    ActionReferenceBounds.ProgramBound M (NativeRecordedFamily.original n)
      (initial (NativeRecordedFamily.original n)) id (RecordedUniformFamily.emitter n) := by
  have hp:=(RecordedUniformFamily.recorded_refutation n hn).1
  have h:=ActionReferenceBounds.program 0 (RecordedUniformFamily.guard n) _ _
    (initial (NativeRecordedFamily.original n)) id _ (by change 0 < _+1;omega)
    (initial_embeds _) hp
  have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
    (initial (NativeRecordedFamily.original n)) id _ hp
  rw [←he] at h
  exact ActionReferenceBounds.program_mono _ _ _ _ _ _ ((ConstructionClosedReference.next_bound n hn).trans hm) h

/-- Both row-term and witness-entry lengths follow from the actual checked
family; physical-reference widths use the proved allocation envelope. Only
non-reference numeric operands of the recorded construction remain assumed. -/
theorem fields (n M : Nat) (hn : 2≤n) (hm:ConstructionClosedReference.nextBound n≤M)
    (hc:∀c∈RecordedUniformFamily.emitter n,Content M c) :
    WholeFileByteBudget.Fields M (M+1) (M+1) (NativeRecordedFamily.original n)
      (initial (NativeRecordedFamily.original n)) id (RecordedUniformFamily.emitter n) :=
  program_compile M (M+1) (M+1) _ _ _ _
    (program_widths M 0 (RecordedUniformFamily.guard n) _ _ _ (RecordedUniformFamily.recorded_refutation n hn).1 hc)
    (references n M hn hm)

/-- Unit: ASCII BYTES. All count terms are closed in n. This is still
conditional on Content M for the actual family, not a closed n-only bound. -/
def byteEnvelope (n M : Nat) : Nat :=101+2*digits M+
  (SerializedActionBudget.overhead M (M+1) (M+1)+7)*ConstructionCompleteCount.mainBound n+
  (22+2*digits M)*certificateBound n+(10+digits M)*localTokenBound n+
  (3+digits M)*CanonicalFamilyMainTapes.mainTokenBound n

theorem bytes (n M : Nat) (hn : 2≤n) (hm:ConstructionClosedReference.nextBound n≤M)
    (hc:∀c∈RecordedUniformFamily.emitter n,Content M c) :
    (familyBytes n).length≤byteEnvelope n M := by
  have h:=WholeFileByteBudget.family_closed_counts n M (M+1) (M+1)
    (CanonicalFamilyMainTapes.mainTokenBound n) hn (fields n M hn hm hc) (CanonicalFamilyMainTapes.main n hn)
  have hf:=CanonicalFormulaEnvelope.original_rows n
  have hnxt:=ConstructionClosedReference.next_bound n hn
  have href:=(NativeRecordedFamily.physical_refutation n hn).2
  have hid:=CanonicalMachineReference.read_id_below_next _ _ _ href
  have hfM:(NativeRecordedFamily.original n).length≤M:=by
    unfold ConstructionClosedReference.nextBound formulaBound at hm
    change (OriginalEncoding.rows n (3*n-4)).length≤M
    omega
  have hd1:=digits_mono hfM
  have hd2:=digits_mono (show NativeRecordedFamily.conclusion n≤M by omega)
  unfold byteEnvelope
  omega
#print axioms fields
#print axioms bytes
end L3Emitter.CanonicalCompleteTokenBudget

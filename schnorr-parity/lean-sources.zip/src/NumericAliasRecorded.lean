import NumericGateSupport
import NumericAliasWidths
namespace L3Emitter.NumericAliasRecorded
open EREF EREF.GeneralRED AliasNetwork NumericNetwork NumericNetworkWidths
open FieldLengthsFromIDs

def namespaceCap (n:Nat) (hn:2≤n):Nat:=
  CanonicalTrace.ceiling (AliasAssembly.source n hn)+externalCeiling (n+1)+1000*(n+2)^3

def fieldCap (n:Nat) (hn:2≤n):Nat:=namespaceCap n hn+1+(aliasWidth (n+1)+1)^2

theorem network_ceiling (n:Nat) (hn:2≤n):
    CanonicalTrace.ceiling (AliasAssembly.built n hn).2.rows≤namespaceCap n hn:=by
  have h:=(actual_program (n+1) (by omega)
    (initial (AliasAssembly.source n hn) (AliasAssembly.source_canonical n hn))).2.2
  simpa only [AliasAssembly.built, AliasNetwork.Net.rows, AliasNetwork.initial, List.flatMap_nil, List.append_nil] using h

theorem fields (n:Nat) (hn:2≤n):
    ∀c∈RecordedAliasDefinitions.program n hn,Content (fieldCap n hn) c:=by
  have hf:=NumericGateSupport.built_fields _ _ (RecordedAliasDefinitions.built n hn)
  have hc:=network_ceiling n hn
  have hw:=built_width n hn
  apply NumericRecordedGates.network
  · intro g hg;have h:=(hf g hg).1
    change g.q≤CanonicalTrace.ceiling (AliasAssembly.built n hn).2.rows at h
    unfold fieldCap;omega
  · intro g hg x hx;have h:=(hf g hg).2 x hx
    change x.val.natAbs≤CanonicalTrace.ceiling (AliasAssembly.built n hn).2.rows at h
    unfold fieldCap;omega
  · intro g hg
    have h:=hw g hg
    have hs:=Nat.pow_le_pow_left (Nat.add_le_add_right h 1) 2
    unfold fieldCap;omega

/-- Explicit non-reference numeric cap for the actual recorded alias bank,
including candidate coefficients/RHS and every local RED certificate.
Only the upstream source database ceiling remains as a parameter. -/
theorem field_polynomial (n:Nat) (hn:2≤n):
    fieldCap n hn≤CanonicalTrace.ceiling (AliasAssembly.source n hn)+
      4000*(n+2)^4*2^(n+1):=by
  have hp:1≤2^(n+1):=Nat.one_le_pow _ _ (by omega)
  have h2:(n+2)^2≤(n+2)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have h3:(n+2)^3≤(n+2)^4:=by
    have h:=Nat.le_mul_of_pos_right ((n+2)^3) (show 0<n+2 by omega)
    nlinarith
  have h1:1≤(n+2)^4:=Nat.one_le_pow _ _ (by omega)
  have ht2:=Nat.mul_le_mul_right (2^(n+1)) h2
  have ht4:=Nat.le_mul_of_pos_right ((n+2)^4) hp
  unfold fieldCap namespaceCap externalCeiling FrontendNamespaceEnvelope.scale aliasWidth
  have he:1+(10*(n+1+1)^2+1)^2≤122*(n+2)^4:=by nlinarith
  nlinarith

#print axioms fields
#print axioms field_polynomial
end L3Emitter.NumericAliasRecorded

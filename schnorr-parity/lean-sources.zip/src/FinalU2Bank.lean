import OutputU2POL
namespace L3Emitter.FinalU2Bank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL U2SourcePOL
open FinalOutputDefinitions
open FinalFunctionFullLinks (Case guards guards_valid)
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def code (a b:Bool):Fin 4:=⟨RankTableBank.code a b,by cases a <;> cases b <;> decide⟩
def f (n:Nat) (hn:2≤n):Table:=fun a b=>FinalFunctionFullLinks.raw n hn (code a b)
def q (n:Nat) (hn:2≤n):Table:=fun a b=>FinalFunctionFullLinks.q n hn (code a b)
def base (n:Nat) (hn:2≤n):=FinalFunctionCases.result n hn

theorem definitions_kept (n:Nat) (hn:2≤n):∀R∈FinalOutputDefinitions.result n hn,R∈base n hn:=by
  intro R h
  apply List.mem_append_left
  apply List.mem_append_left
  apply FinalTransferBank.retained
  exact FinalTransferContext.definitions_kept n hn R h

theorem raw_U2 (n:Nat) (hn:2≤n) (p:Bool):original (f n hn) p∈base n hn:=by
  have h:=LowerU2Bank.all_rows n hn (lastRank n) (by unfold lastRank RankConstruction.width;omega) p
  apply definitions_kept
  apply FinalOutputDefinitions.retains
  unfold FinalOutputDefinitions.base
  apply List.mem_append_left
  apply List.mem_append_left
  apply List.mem_append_left
  simpa only [RankU2Transport.row,RankU2Transport.table,f,FinalFunctionFullLinks.raw,FinalFunctionCases.raw,code] using h

def jobs:List (Bool×Bool×Bool):=[false,true].flatMap fun a=>[false,true].flatMap fun b=>[false,true].map fun r=>(a,b,r)
def linkRows (n:Nat) (hn:2≤n) (c:Case):List Row:=jobs.map fun (a,b,r)=>FinalFunctionFullLinks.row n hn c (code a b) r
def linkProgram (n:Nat) (hn:2≤n) (c:Case) (D:List Row):Program:=
  jobs.map fun (a,b,r)=>(FinalFunctionFullLinks.row n hn c (code a b) r,FinalFunctionFullLinks.tape n hn c (code a b) r D)
theorem link_check (n:Nat) (hn:2≤n) (c:Case) (D:List Row) (hd:∀R∈base n hn,R∈D):
    check D (linkProgram n hn c D)=some (D++linkRows n hn c):=by
  have h:=IndependentProgram.check_base D (linkProgram n hn c D) (by
    intro z hz;obtain ⟨⟨a,b,r⟩,h,rfl⟩:=List.mem_map.mp hz
    exact FinalFunctionFullLinks.checks n hn c _ r D hd)
  simpa only [linkProgram,linkRows,outputs,List.map_map,Function.comp_def] using h

theorem link_eq (n:Nat) (hn:2≤n) (c:Case) (a b r:Bool):
    FinalFunctionFullLinks.row n hn c (code a b) r=OutputU2POL.link (guards n hn c) (f n hn) (q n hn) c a b r:=by
  have he:FinalFunctionFullLinks.input (code a b)=a:=by cases a <;> cases b <;> decide
  simp only [FinalFunctionFullLinks.row,OutputU2POL.link,f,q,he]
theorem links_present (n:Nat) (hn:2≤n) (c:Case) (a b r:Bool):
    OutputU2POL.link (guards n hn c) (f n hn) (q n hn) c a b r∈linkRows n hn c:=by
  rw [←link_eq]
  apply List.mem_map.mpr
  exact ⟨(a,b,r),by cases a <;> cases b <;> cases r <;> simp [jobs],rfl⟩

def cases:List Case:=[false,true].flatMap fun u0=>[false,true].flatMap fun u1=>
  [false,true].flatMap fun h=>[false,true].map fun p=>(u0,u1,h,p)
def vars (n:Nat) (hn:2≤n):List Int:=[(unary n hn false).val,(unary n hn true).val,(H n hn).val,(OutputPhaseRows.phase n hn).val]
def body (n:Nat) (hn:2≤n) (p:Bool) (c:Case):=
  linkRows n hn c++OutputU2POL.rows (guards n hn c) (q n hn) c p
def leaf (n:Nat) (hn:2≤n) (p:Bool) (c:Case) (D:List Row):Program:=
  linkProgram n hn c D++OutputU2POL.program (D++linkRows n hn c) (guards n hn c) (f n hn) (q n hn) c p
theorem leaf_check (n:Nat) (hn:2≤n) (p:Bool) (c:Case) (D:List Row) (hd:∀R∈base n hn,R∈D):
    check D (leaf n hn p c D)=some (D++body n hn p c):=by
  have h0:=link_check n hn c D hd
  have h1:=OutputU2POL.checks (D++linkRows n hn c) (guards n hn c) (f n hn) (q n hn) c p (guards_valid n hn c)
    (fun v=>List.mem_append_left _ (hd _ (raw_U2 n hn v))) (fun a b r=>List.mem_append_right _ (links_present n hn c a b r))
  simpa only [leaf,body,List.append_assoc] using check_append _ _ _ _ _ h0 h1

theorem cover (n:Nat) (hn:2≤n):cases.map (guards n hn)=SplitJoinPOL.choices (vars n hn):=by
  simp [cases,guards,vars,SplitJoinPOL.choices,sign]
def rows (n:Nat) (hn:2≤n) (p:Bool):=
  RetainedBlockFold.body (body n hn p) cases++SplitJoinPOL.rows (literals (q n hn) identity identity p) (vars n hn)
def program (n:Nat) (hn:2≤n) (p:Bool) (D:List Row):Program:=
  RetainedBlockFold.run (leaf n hn p) (body n hn p) cases D++
  SplitJoinPOL.program (D++RetainedBlockFold.body (body n hn p) cases) (literals (q n hn) identity identity p) (vars n hn)
theorem checks (n:Nat) (hn:2≤n) (p:Bool) (D:List Row) (hd:∀R∈base n hn,R∈D):
    check D (program n hn p D)=some (D++rows n hn p):=by
  have h0:=RetainedBlockFold.checks (base n hn) (leaf n hn p) (body n hn p) (fun _:Case=>True)
    (fun c _ E he=>leaf_check n hn p c E he) cases (by simp) D hd
  have hh (gs:List Int) (hgs:gs∈SplitJoinPOL.choices (vars n hn)):
      clause (literals (q n hn) identity identity p++gs)∈D++RetainedBlockFold.body (body n hn p) cases:=by
    rw [←cover] at hgs
    obtain ⟨c,hc,rfl⟩:=List.mem_map.mp hgs
    rw [U2ComposedPOL.clause_comm _ _ (U2SourcePOL.valid _ _ _ _) (guards_valid n hn c)]
    apply List.mem_append_right
    apply RetainedBlockFold.contains (body n hn p) cases c hc
    exact List.mem_append_right _ (OutputU2POL.final_mem _ _ _ _)
  have h1:=SplitJoinPOL.checks _ _ _ (U2SourcePOL.valid _ _ _ _) (by simp [vars,Valid,(unary n hn false).property,(unary n hn true).property,(H n hn).property,(OutputPhaseRows.phase n hn).property]) hh
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h1

def bothProgram (n:Nat) (hn:2≤n):Program:=program n hn false (base n hn)++program n hn true (base n hn++rows n hn false)
def result (n:Nat) (hn:2≤n):=base n hn++rows n hn false++rows n hn true
theorem both_check (n:Nat) (hn:2≤n):check (base n hn) (bothProgram n hn)=some (result n hn):=
  check_append _ _ _ _ _ (checks n hn false _ (fun _ h=>h)) (checks n hn true _ (fun _ h=>List.mem_append_left _ h))
theorem original_to_replacement_U2 (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalFunctionCases.original_to_function_cases n hn) (check_trace _ _ _ (both_check n hn))
theorem all_rows (n:Nat) (hn:2≤n) (p:Bool):original (q n hn) p∈result n hn:=by
  have h:original (q n hn) p∈rows n hn p:=List.mem_append_right _ (SplitJoinPOL.final_mem _ _)
  cases p
  · exact List.mem_append_left _ (List.mem_append_right _ h)
  · exact List.mem_append_right _ h
#print axioms original_to_replacement_U2
#print axioms all_rows
end L3Emitter.FinalU2Bank

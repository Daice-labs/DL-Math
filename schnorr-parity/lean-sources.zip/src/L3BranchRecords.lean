import L3BranchChains

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def BranchRecord (b g : Nat) (t : StI F.V) (brs : List Int) : Prop :=
  ∃q r, Cmd.orDef q [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)]∈t.s.cmds ∧
    Cmd.andDef r [(t.s.eligible b:Int),(q:Int)]∈t.s.cmds ∧ (r:Int)∈brs ∧
    1≤q ∧ q≤t.s.var ∧ 1≤r ∧ r≤t.s.var

theorem BranchRecord_keeps {t u : StI F.V} (hk : Keeps2 t u)
    {xs ys : List Int} (hxy : ∀x∈xs,x∈ys) (b g : Nat)
    (hr : F.BranchRecord b g t xs) : F.BranchRecord b g u ys := by
  obtain ⟨q,r,hq,hr,hm,hql,hqu,hrl,hru⟩ := hr
  refine ⟨q,r,?_,?_,hxy _ hm,hql,?_,hrl,?_⟩
  · rw [hk.2.1.2]; exact mem_of_grows hk.1 hq
  · rw [hk.2.2.2.2.2.1]; exact mem_of_grows hk.1 hr
  · exact Nat.le_trans hqu (var_le_of_grows hk.1)
  · exact Nat.le_trans hru (var_le_of_grows hk.1)

theorem branchStep_list (b g : Nat) (acc : StI F.V × List Int) :
    (F.branchStep b acc g).2=acc.2++[((acc.1.s.var+2:Nat):Int)] := rfl

theorem branchStep_record (t : StI F.V) (brs : List Int) (ht : F.Good3 t)
    (b g : Nat) (hb : 1≤b) (hbg : b<g) (hg : g<F.s) :
    F.BranchRecord b g (F.branchStep b (t,brs) g).1 (F.branchStep b (t,brs) g).2 := by
  have he0 : F.PEdge b g 0 t := (ht.2.1 b (by omega)).2 (g,0) ((F.mem_edgePairs b (g,0)).mpr ⟨by omega,hg,by simp⟩)
  have he1 : F.PEdge b g 1 t := (ht.2.1 b (by omega)).2 (g,1) ((F.mem_edgePairs b (g,1)).mpr ⟨by omega,hg,by simp⟩)
  obtain ⟨cons,hcons,helig,hconsL,heligL,heligU⟩ := ht.2.2.2.1 b hb (by omega)
  have hxs : Bounded t.s.var [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)] := by
    have h0 := he0.2; have h1 := he1.2
    intro l hl; simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> omega
  let u := (t.OR [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)]).2
  have hy : Bounded u.s.var [(t.s.eligible b:Int),((t.s.var+1:Nat):Int)] := by
    change Bounded (t.s.var+1) _
    intro l hl; simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> omega
  refine ⟨t.s.var+1,t.s.var+2,?_,?_,?_,by omega,?_,by omega,?_⟩
  · change Cmd.orDef (t.s.var+1) [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)] ∈ (t.s.cmds ++ [.orDef _ (t.s.chk _)]) ++ [.andDef _ (u.s.chk _)]
    rw [StI.chk_eq t _ hxs]; simp
  · change Cmd.andDef (t.s.var+1+1) [(t.s.eligible b:Int),((t.s.var+1:Nat):Int)] ∈ u.s.cmds ++ [.andDef (t.s.var+1+1) (u.s.chk [(t.s.eligible b:Int),((t.s.var+1:Nat):Int)])]
    rw [StI.chk_eq u _ hy]; simp
  · rw [F.branchStep_list]; simp
  · change t.s.var+1≤t.s.var+1+1; omega
  · change t.s.var+2≤t.s.var+1+1; omega

theorem branchStep_obls (b g : Nat) (acc : StI F.V × List Int)
    (ho : ObligationsChecked F.db5 acc.1.s.cmds) :
    ObligationsChecked F.db5 (F.branchStep b acc g).1.s.cmds := by
  change ObligationsChecked F.db5 ((acc.1.s.cmds ++ [.orDef _ _]) ++ [.andDef _ _])
  apply obligations_append _ _ _ (obligations_append _ _ _ ho ?_) <;> intro o ho <;> simp [obls] at ho

theorem branchStep_old (b g : Nat) (acc : StI F.V × List Int) (x : Int) (hx : x∈acc.2) :
    x∈(F.branchStep b acc g).2 := by rw [F.branchStep_list]; exact List.mem_append_left _ hx

theorem branchFold_keeps (b : Nat) (gs : List Nat) (acc : StI F.V × List Int) :
    Keeps2 acc.1 (gs.foldl (F.branchStep b) acc).1 :=
  keeps2_foldl_pair _ _ (fun a g => F.keeps2_branchStep b a g) acc

theorem branchFold_old (b : Nat) (gs : List Nat) (acc : StI F.V × List Int) :
    ∀x∈acc.2,x∈(gs.foldl (F.branchStep b) acc).2 := by
  induction gs generalizing acc with
  | nil => exact fun _ h => h
  | cons g gs ih =>
    exact fun x hx => ih _ x (F.branchStep_old b g acc x hx)

theorem branchFold_records (b : Nat) (gs : List Nat) (acc : StI F.V × List Int)
    (ht : F.Good3 acc.1) (hb : 1≤b) (hgs : ∀g∈gs,b<g ∧ g<F.s) :
    ∀g∈gs,F.BranchRecord b g (gs.foldl (F.branchStep b) acc).1 (gs.foldl (F.branchStep b) acc).2 := by
  induction gs generalizing acc with
  | nil => simp
  | cons j js ih =>
    intro g hg
    have hj := hgs j (by simp)
    let u := F.branchStep b acc j
    have hu : F.Good3 u.1 := F.Good3_of_keeps2 (F.keeps2_branchStep b acc j) ht
    rcases List.mem_cons.mp hg with rfl | hg
    · exact F.BranchRecord_keeps (F.branchFold_keeps b js u) (F.branchFold_old b js u) b g
        (F.branchStep_record acc.1 acc.2 ht b g hb hj.1 hj.2)
    · exact ih u hu (fun z hz => hgs z (by simp [hz])) g hg

theorem branchFold_obls (b : Nat) (gs : List Nat) (acc : StI F.V × List Int)
    (ho : ObligationsChecked F.db5 acc.1.s.cmds) :
    ObligationsChecked F.db5 (gs.foldl (F.branchStep b) acc).1.s.cmds := by
  induction gs generalizing acc with
  | nil => exact ho
  | cons g gs ih => exact ih _ (F.branchStep_obls b g acc ho)

#print axioms branchFold_records
#print axioms branchFold_obls
end L3.Fam

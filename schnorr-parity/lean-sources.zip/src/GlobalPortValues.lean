import GlobalValueInduction
namespace L3Emitter.GlobalPortValues
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram
abbrev Job (n:Nat):=Nat×Nat×FirstGateBase.Job n

def jobs (n:Nat):List (Job n):=(List.range (3*(n+1)-4)).flatMap fun g=>
  (List.range 2).flatMap fun p=>(FirstGateBase.jobs n).map fun j=>(g,p,j)
def ValidJob (n:Nat) (j:Job n):Prop:=j.1<3*(n+1)-4 ∧ j.2.1<2 ∧ j.2.2.1<FamilyNamespace.truthRows n

theorem job_mem (n:Nat) (j:Job n):j∈jobs n ↔ ValidJob n j:=by
  obtain ⟨g,p,x,i,b,v⟩:=j
  cases b <;> cases v <;> simp [jobs,ValidJob,FirstGateBase.jobs]

def block (n:Nat) (hn:2≤n) (j:Job n) (D:List Row):Program:=
  PortSelectorJoin.program n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1
    (SourceCoordinateValue.value n hn j.2.2.2.1 j.2.2.1) j.2.2.2.2.1 j.2.2.2.2.2 D
def blockRows (n:Nat) (hn:2≤n) (j:Job n):=
  PortSelectorJoin.rows n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1
    (SourceCoordinateValue.value n hn j.2.2.2.1 j.2.2.1) j.2.2.2.2.1 j.2.2.2.2.2

theorem block_checks (n:Nat) (hn:2≤n) (j:Job n) (hj:ValidJob n j) (D:List Row)
    (hd:∀R∈GlobalValueInduction.result n hn,R∈D):
    check D (block n hn j D)=some (D++blockRows n hn j):=by
  apply PortSelectorJoin.full_port_checks n hn _ _ _ hj.1 hj.2.1 hj.2.2
  · intro a ha hz he;exact SourceCoordinateValue.primary n hn _ _ a ha hz he
  · exact fun R h=>hd R (GlobalValueInduction.retained n hn R (SharedValueBank.gamma_retained n hn R h))
  · intro h hh
    exact hd _ (GlobalValueInduction.global_value_induction n hn h (Nat.lt_trans hh hj.1) _ hj.2.2 _ _ _)

def rows (n:Nat) (hn:2≤n):=(jobs n).flatMap (blockRows n hn)
def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (block n hn) (blockRows n hn) (jobs n) (GlobalValueInduction.result n hn)
def result (n:Nat) (hn:2≤n):=GlobalValueInduction.result n hn++rows n hn

theorem checks (n:Nat) (hn:2≤n):check (GlobalValueInduction.result n hn) (program n hn)=some (result n hn):=by
  apply RetainedBlockFold.checks (GlobalValueInduction.result n hn) _ _ (ValidJob n) _ _
    (fun j hj=>(job_mem _ _).mp hj) _ (fun _ h=>h)
  exact fun j hj D hd=>block_checks n hn j hj D hd

theorem port_values (n:Nat) (hn:2≤n) (g p x:Nat) (hg:g<3*(n+1)-4) (hp:p<2) (hx:x<FamilyNamespace.truthRows n)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):
    PortValueBank.target n hn g p x i (SourceCoordinateValue.value n hn i x) b v∈result n hn:=by
  apply List.mem_append_right
  exact List.mem_flatMap.mpr ⟨(g,p,x,i,b,v),(job_mem _ _).mpr ⟨hg,hp,hx⟩,
    List.mem_append_right _ (List.mem_singleton_self _)⟩

theorem retained (n:Nat) (hn:2≤n):∀R∈GlobalValueInduction.result n hn,R∈result n hn:=
  fun R h=>List.mem_append_left _ h

theorem original_to_port_values (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (GlobalValueInduction.original_to_global_values n hn) (check_trace _ _ _ (checks n hn))
#print axioms port_values
#print axioms original_to_port_values
end L3Emitter.GlobalPortValues

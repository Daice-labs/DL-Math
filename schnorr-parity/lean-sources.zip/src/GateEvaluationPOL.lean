import LowerPortEvalBank
namespace L3Emitter.GateEvaluationPOL
open EREF EREF.GeneralRED REDWitness ReferenceTransport LocalCombination ClauseTransport CaseJoin

structure Literals where
  c : Int
  a : Int
  b : Int
  u : Int
  v : Int
  p : Int
  r : Int
  f : Int
  q : Int
  o : Int

def Literals.Valid (z:Literals):Prop := REDWitness.Valid [z.c,z.a,z.b,z.u,z.v,z.p,z.r,z.f,z.q,z.o]
def source (z:Literals):=clause [-z.p,-z.r,-z.f,z.o]
def port0 (z:Literals):=clause [z.c,z.a,z.u,z.p]
def port1 (z:Literals):=clause [z.c,z.b,z.v,z.r]
def lookup (z:Literals):=clause [z.u,z.v,z.f,z.q]
def extra (z:Literals):=[z.a,z.b,z.q,z.o]
def targetLits (z:Literals):=[z.c,z.a,z.b,z.q,z.o,z.u,z.v]
def target (z:Literals):=clause (targetLits z)
def premises (z:Literals):=[port0 z,port1 z,lookup z]
def combined (z:Literals):=chain (chain (source z) (premises z)) ((extra z).map litAxiom)
def tape (D:List Row) (z:Literals):List Tok:=
  [.ref (locate D (source z))]++steps D (premises z)++padSteps (extra z)++[.div 2]

theorem combined_eq (z:Literals) (hz:z.Valid):combined z=scaled 2 (target z):=by
  have h : z.c≠0 ∧ z.a≠0 ∧ z.b≠0 ∧ z.u≠0 ∧ z.v≠0 ∧ z.p≠0 ∧ z.r≠0 ∧ z.f≠0 ∧ z.q≠0 ∧ z.o≠0 := by
    simpa [Literals.Valid,REDWitness.Valid] using hz
  have hs:REDWitness.Valid [-z.p,-z.r,-z.f,z.o]:=by simp [REDWitness.Valid,h]
  have h0:REDWitness.Valid [z.c,z.a,z.u,z.p]:=by simp [REDWitness.Valid,h]
  have h1:REDWitness.Valid [z.c,z.b,z.v,z.r]:=by simp [REDWitness.Valid,h]
  have hl:REDWitness.Valid [z.u,z.v,z.f,z.q]:=by simp [REDWitness.Valid,h]
  have he:REDWitness.Valid (extra z):=by simp [extra,REDWitness.Valid,h]
  have ht:REDWitness.Valid (targetLits z):=by simp [targetLits,REDWitness.Valid,h]
  apply canonical_ext _ _ (chain_canonical _ _ (chain_canonical _ _ (canonical_normalize _ _)))
    (canonical_scaled 2 (by decide) _ (canonical_normalize _ _))
  intro α
  change (combined z).val α=(scaled 2 (target z)).val α
  rw [combined,chain_value (chain (source z) (premises z)) ((extra z).map litAxiom)
    (chain_canonical _ _ (canonical_normalize _ _))
    (by intro R hr;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hr;exact canonical_litAxiom _),
    chain_value (source z) (premises z) (canonical_normalize _ _)
    (by intro R hr;simp only [premises,List.mem_cons,List.not_mem_nil,or_false] at hr
        rcases hr with rfl|rfl|rfl <;> exact canonical_normalize _ _),
    ChoiceProjection.literal_sum _ he,val_scaled]
  simp only [premises,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil]
  change (clause [-z.p,-z.r,-z.f,z.o]).val α+((clause [z.c,z.a,z.u,z.p]).val α+
    ((clause [z.c,z.b,z.v,z.r]).val α+((clause [z.u,z.v,z.f,z.q]).val α+0)))+sum α (extra z)=_
  rw [val_clause _ hs,val_clause _ h0,val_clause _ h1,val_clause _ hl]
  change _=2*(clause (targetLits z)).val α+2-1
  rw [val_clause _ ht]
  simp only [extra,targetLits,sum_cons,sum_nil,litVal_neg α z.p h.2.2.2.2.2.1,
    litVal_neg α z.r h.2.2.2.2.2.2.1,litVal_neg α z.f h.2.2.2.2.2.2.2.1]
  ring

theorem checks (D:List Row) (z:Literals) (hz:z.Valid)
    (hs:source z∈D) (h0:port0 z∈D) (h1:port1 z∈D) (hl:lookup z∈D):
    polEval (dbOf D) (tape D z) []=some (target z):=by
  have hm:∀R∈premises z,R∈D:=by
    intro R hr;simp only [premises,List.mem_cons,List.not_mem_nil,or_false] at hr
    rcases hr with rfl|rfl|rfl <;> assumption
  have he:REDWitness.Valid (extra z):=by
    intro l hl;apply hz l;simp only [extra,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl|rfl <;> simp
  simp only [tape,List.append_assoc,List.cons_append,List.nil_append,polEval,locate_correct D _ hs]
  rw [steps_eval _ _ hm,padSteps_eval _ _ he]
  change some (divide (combined z) 2)=_
  rw [combined_eq z hz,divide_scaled 2 (by decide) (target z) (canonical_normalize _ _)]

theorem token_count (D:List Row) (z:Literals):(tape D z).length=16:=by
  simp [tape,steps,premises,padSteps,extra]
#print axioms checks
end L3Emitter.GateEvaluationPOL

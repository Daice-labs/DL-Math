import AliasGateOrder
import AliasCost

namespace L3Emitter.AliasOutput
open EREF AliasNetwork RecursiveAliases AliasRefinement
open L3Uniform.Alias L3Uniform.Circuit
variable {base : List Row} {w : Nat}

/-- Evaluate the shared source selector once, then apply its unary map.
    Earlier alias networks remain literal references. -/
def evaluate (a : AliasBits w) (v : Fin w→Bit) : StateM (Net base) Bit := do
  let x ← select ((List.finRange w).map (fun j=>(a ⟨j.val,by omega⟩,v j)))
  MUX x (a ⟨w+1,by omega⟩) (a ⟨w,by omega⟩)

theorem evaluate_extends (a : AliasBits w) (v : Fin w→Bit) :
    Extends (evaluate (base:=base) a v) :=
  bind_extends _ _ (select_extends _) (fun _=>mux_extends _ _ _)

theorem evaluate_cost (a : AliasBits w) (v : Fin w→Bit) :
    Cost (evaluate (base:=base) a v) (w+4) := by
  simpa using bind_cost (base:=base) _ _ (w+1) 3
    (by
      simpa using select_cost (base:=base)
        ((List.finRange w).map (fun j=>(a ⟨j.val,by omega⟩,v j))))
    (fun _=>mux_cost _ _ _)

def values (α : Val) (v : Fin w→Bit) (j : Nat) : Bool :=
  if hj:j<w then eval α (v ⟨j,hj⟩) else false

theorem evaluate_spec (α : Val) (a : AliasBits w) (v : Fin w→Bit) :
    Spec α (evaluate (base:=base) a v)
      (fun q=>eval α q=interpret w (view α a) (values α v)) := by
  unfold evaluate
  refine bind_spec α _ _ _ _ (fun _=>mux_extends _ _ _) (select_spec α _) ?_
  intro x hx
  refine spec_mono α _ _ _ (mux_spec α x (a ⟨w+1,by omega⟩) (a ⟨w,by omega⟩)) ?_
  intro q hq
  rw [hq,hx]
  simp [interpret,sourceValue,view,values]

/-- Connect the recursive emitted coordinates and their emitted evaluation
    gate to the existing circuit theorem. Width is derived, not assumed. -/
theorem output_correct (α : Val) (cfg : Config Bit) (h : High)
    (beta gamma : Nat) (b c : Bool)
    (as : Nat→AliasBits (h.k-1+(h.s-3)))
    (v : Fin (h.k-1+(h.s-3))→Bit)
    (hcfg : cfg.map (eval α)=ideal h beta gamma b c)
    (ha : (fun j=>view α (as j))=(fun j=>encoding _ (L3Uniform.Circuit.initial b j)))
    (hk : 2≤h.k) (hb : 0<beta) (hbg : beta<gamma) (hg : gamma<h.s)
    (topo : ∀g<h.s,h.left g<h.k+g ∧ h.right g<h.k+g)
    (first : h.left 0=0) (firstRight : h.right 0=1)
    (hit : h.left gamma=h.k+beta ∨ h.right gamma=h.k+beta)
    (input gate : Nat→Bool) (input0 : input 0=b)
    (evals : Evaluates h input gate) (constant : gate beta=c)
    (hv : ∀j,eval α (v j)=lowValue h beta gamma input gate j.val) :
    Spec α (do
      let result ← RecursiveAliases.run (base:=base) cfg as 0 h.s
      evaluate (result (h.k+h.s-1)) v)
      (fun q=>eval α q=gate (h.s-1)) := by
  refine bind_spec α _ _ _ _ (fun _=>evaluate_extends _ _)
    (emitted_aliases α cfg h beta gamma b c as hcfg ha (by omega) topo firstRight) ?_
  intro result hr
  refine spec_mono α _ _ _ (evaluate_spec α _ v) ?_
  intro q hq
  have he:=congrFun hr (h.k+h.s-1)
  rw [hq,he,interpret_encoding _ _ (output_alias_bounded h beta gamma b c hk hb hbg hg topo)]
  have hs : 0<h.s:=by omega
  have bound:=output_alias_bounded h beta gamma b c hk hb hbg hg topo
  have heval :
      (aliases h beta gamma b c h.s (h.k+h.s-1)).eval (values α v) =
      (aliases h beta gamma b c h.s (h.k+h.s-1)).eval (lowValue h beta gamma input gate) := by
    unfold Alias.eval
    rw [values,dif_pos bound,hv]
  rw [heval,aliases_correct h beta gamma b c hk hb hbg hg topo first hit input gate
    input0 evals constant h.s (by omega) (h.k+h.s-1) (by omega)]
  simp only [highValue]
  rw [if_neg (by omega)]
  congr 1
  omega

#print axioms evaluate_cost
#print axioms evaluate_spec
#print axioms output_correct
end L3Emitter.AliasOutput

import GateEvaluationSize
import ConstructionLowerBasicCount
namespace L3Emitter.ConstructionLowerEvaluationCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount ConstructionLowerBasicCount

theorem composed (n : Nat) (hn : 2≤n) : (ComposedU2Bank.program n hn).length≤858*(n+1) := by
  have h:=retained_fold (ComposedU2Bank.leaf n hn) (ComposedU2Bank.rows n hn)
    (ComposedU2Bank.jobs n) (ComposedU2Bank.base n hn) 143
    (by intro j hj D;exact U2ConstructionSize.composed_commands ..)
  change (ComposedU2Bank.program n hn).length≤_ at h
  have hj:(ComposedU2Bank.jobs n).length=(3*(n+1)-5)*2:=by
    unfold ComposedU2Bank.jobs;rw [flat_exact _ _ 2 (by intros;rfl),gates]
  rw [hj] at h;omega

theorem u2 (n : Nat) (hn : 2≤n) : (LowerU2Bank.program n hn).length≤24*(n+1)^2 := by
  have h:=retained_fold (LowerU2Bank.leaf n hn) (LowerU2Bank.rows n hn)
    (LowerU2Bank.jobs n) (ComposedU2Bank.result n hn) (4*(n+1)) (by
      intro j hj D
      simp [LowerU2Bank.leaf,RankU2Transport.program,RankU2Transport.casesProgram,RankZeroTransport.gates];omega)
  change (LowerU2Bank.program n hn).length≤_ at h
  have hj:(LowerU2Bank.jobs n).length=2*RankConstruction.width (n+1):=by
    simp [LowerU2Bank.jobs,List.length_flatMap];ring
  rw [hj] at h
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 2 (width n))).trans_eq (by ring))

theorem ports (n : Nat) (hn : 2≤n) : (LowerPortEvalBank.program n hn).length≤72*(n+1)^2*2^n := by
  have hj:(LowerPortEvalBank.jobs n hn).length=
      (RawLowerInputBank.result n hn).2.length*((3*(n+1)-5)*(2^n*4)):=by
    unfold LowerPortEvalBank.jobs
    rw [flat_exact _ _ ((3*(n+1)-5)*(2^n*4)) (by
      intro r hr
      rw [flat_exact _ _ (2^n*4) (by
        intro G hG
        rw [flat_exact _ _ 4 (by intros;rfl),List.length_range]
        rfl)]
      simp [RankZeroTransport.gates])]
  simp only [LowerPortEvalBank.program,List.length_map,hj,RawInputSize.raw_record_count]
  have hm:=Nat.mul_le_mul (Nat.mul_le_mul_left 2 (width n))
    (Nat.mul_le_mul_right (2^n*4) (Nat.sub_le (3*(n+1)) 5))
  exact hm.trans_eq (by ring)

theorem evaluation (n : Nat) (hn : 2≤n) : (LowerGateBank.program n hn).length≤888*(n+1)^2*2^n := by
  have h:=GateEvaluationSize.bank_commands n hn
  change _≤RankConstruction.width (n+1)*2^n*8*(12*(3*(n+1)-5)+1) at h
  have hm:=Nat.mul_le_mul (Nat.mul_le_mul_right 8 (Nat.mul_le_mul_right (2^n) (width n)))
    (show 12*(3*(n+1)-5)+1≤37*(n+1) by omega)
  exact h.trans (hm.trans_eq (by ring))

theorem phase (n : Nat) (hn : 2≤n) : (OutputPhaseBank.program n hn).length≤16*(n+1)*2^n := by
  have hj:(OutputPhaseBank.jobs n).length=2^n*(AliasAssembly.width (n+1)*4):=by
    unfold OutputPhaseBank.jobs
    rw [flat_exact _ _ (AliasAssembly.width (n+1)*4) (by
      intro x hx;rw [flat_exact _ _ 4 (by intros;rfl),List.length_finRange]),List.length_range]
    rfl
  simp only [OutputPhaseBank.program,List.length_map,hj]
  have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  exact (Nat.mul_le_mul_left (2^n) (Nat.mul_le_mul_right 4 hw)).trans_eq (by ring)
#print axioms composed
#print axioms u2
#print axioms ports
#print axioms evaluation
#print axioms phase
end L3Emitter.ConstructionLowerEvaluationCount

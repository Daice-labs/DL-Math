import ConcretePortRows

namespace L3Emitter.ConcreteOriginalPorts
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteSelection ConcretePortRows
variable {base : List Row} {w : Nat}

def portInputs (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) (i : Fin (w+2)) :=
  (List.range (k+g)).map (fun j=>(sel j,as j i))

theorem original_choices (n : Nat) (hn : 2≤n) (g p : Nat)
    (hg : g<3*(n+1)-4) (hp : p<2) (as : Nat→AliasBits w) (i : Fin (w+2))
    (D : List Row) (hd : ∀R∈SelectorBank.result n hn,R∈D) :
    Choices (portInputs (n+1) g (AliasAssembly.selector (n+1) (3*(n+1)-4) g p) as i) D := by
  constructor
  · simpa only [portInputs,List.map_map,AliasAssembly.selector,Function.comp_def,SelectorBank.selectors]
      using SelectorBank.nodup (n+1) (3*(n+1)-4) g p
  · intro a ha b hb hab
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp ha
    obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hb
    apply hd
    exact SelectorBank.pair_present n hn g p hg hp _ (List.mem_map.mpr ⟨j,hj,rfl⟩)
      _ (List.mem_map.mpr ⟨l,hl,rfl⟩) hab

def recorded (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) :
    StateM (Net base) (AliasBits w × List Job) := fun z=>
  let r:=ConcretePortRows.run (w+2) (portInputs k g sel as) z
  ((fun i=>(r.1 i).q,List.ofFn r.1),r.2)

theorem binding (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) (z : Net base) :
    ((recorded k g sel as z).1.1,(recorded k g sel as z).2)=port k g sel as z :=
  ConcretePortRows.binding (w+2) (portInputs k g sel as) z

theorem retains (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) :
    Extends (recorded (base:=base) k g sel as) := fun z=>
  ConcretePortRows.retains _ _ z

theorem ready (n : Nat) (hn : 2≤n) (g p : Nat)
    (hg : g<3*(n+1)-4) (hp : p<2) (as : Nat→AliasBits w) (z : Net base)
    (hd : ∀R∈SelectorBank.result n hn,R∈z.rows) :
    ∀j∈(recorded (n+1) g (AliasAssembly.selector (n+1) (3*(n+1)-4) g p) as z).1.2,
      Ready (recorded (n+1) g (AliasAssembly.selector (n+1) (3*(n+1)-4) g p) as z).2.rows j := by
  intro j hj
  obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hj
  exact ConcretePortRows.ready _ _ z (fun i=>original_choices n hn g p hg hp as i z.rows hd) i

#print axioms original_choices
#print axioms binding
#print axioms ready
end L3Emitter.ConcreteOriginalPorts

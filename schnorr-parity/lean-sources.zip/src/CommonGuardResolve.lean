import ReceivingEdgeBank
namespace L3Emitter.CommonGuardResolve
open EREF EREF.GeneralRED REDWitness ReferenceTransport LocalCombination ClauseTransport CaseJoin

def left (G H:List Int) (a:Int):=clause (G++H++[a])
def right (G Q:List Int) (a:Int):=clause (G++[-a]++Q)
def target (G H Q:List Int):=clause (G++H++Q)
def combined (G H Q:List Int) (a:Int):=chain (add (left G H a) (right G Q a)) ((H++Q).map litAxiom)
def tape (D:List Row) (G H Q:List Int) (a:Int):List Tok:=
  [.ref (locate D (left G H a)),.ref (locate D (right G Q a)),.add]++padSteps (H++Q)++[.div 2]

theorem scaled_sum (G H Q:List Int) (a:Int) (hG:Valid G) (hH:Valid H) (hQ:Valid Q) (ha:a≠0):
    combined G H Q a=scaled 2 (target G H Q):=by
  have vGH:=EvaluationCaseSeeds.valid_join hG hH
  have vHQ:=EvaluationCaseSeeds.valid_join hH hQ
  have vl:Valid (G++H++[a]):=EvaluationCaseSeeds.valid_join vGH (by simp [Valid,ha])
  have vr:Valid (G++[-a]++Q):=EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join hG (by simp [Valid,ha])) hQ
  have vt:Valid (G++H++Q):=EvaluationCaseSeeds.valid_join vGH hQ
  apply canonical_ext _ _ (chain_canonical _ _ (canonical_add _ _))
    (canonical_scaled 2 (by decide) _ (canonical_normalize _ _))
  intro α
  change (combined G H Q a).val α=(scaled 2 (target G H Q)).val α
  rw [combined,chain_value (add (left G H a) (right G Q a)) ((H++Q).map litAxiom)
    (canonical_add _ _) (by intro R hr;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hr;exact canonical_litAxiom _),
    val_add (left G H a) (right G Q a) (canonical_normalize _ _) (canonical_normalize _ _),
    ChoiceProjection.literal_sum _ vHQ,val_scaled]
  change (clause (G++H++[a])).val α+(clause (G++[-a]++Q)).val α+sum α (H++Q)=2*(clause (G++H++Q)).val α+2-1
  rw [val_clause _ vl,val_clause _ vr,val_clause _ vt]
  simp only [sum_append,sum_cons,sum_nil,litVal_neg α a ha]
  ring

theorem checks (D:List Row) (G H Q:List Int) (a:Int) (hG:Valid G) (hH:Valid H) (hQ:Valid Q) (ha:a≠0)
    (hl:left G H a∈D) (hr:right G Q a∈D):
    polEval (dbOf D) (tape D G H Q a) []=some (target G H Q):=by
  simp only [tape,List.append_assoc,List.cons_append,List.nil_append,polEval,locate_correct D _ hl,locate_correct D _ hr]
  rw [padSteps_eval (dbOf D) _ (EvaluationCaseSeeds.valid_join hH hQ)]
  change some (divide (combined G H Q a) 2)=_
  rw [scaled_sum G H Q a hG hH hQ ha,divide_scaled 2 (by decide) (target G H Q) (canonical_normalize _ _)]

theorem token_count (D:List Row) (G H Q:List Int) (a:Int):(tape D G H Q a).length=4+2*(H.length+Q.length):=by
  simp [tape,padSteps,List.length_flatMap,List.map_map,Function.comp_def];omega
#print axioms checks
end L3Emitter.CommonGuardResolve

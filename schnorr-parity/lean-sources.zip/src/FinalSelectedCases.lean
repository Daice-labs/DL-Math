import FinalSelectedEvaluation
namespace L3Emitter.FinalSelectedCases
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions FinalEvaluationContext
open FinalKeptEvaluation (port)
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def core (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):List Int:=
  [(H n hn).val,-sign side (OutputPhaseRows.phase n hn),-sign a (port n hn x 0),-sign b (port n hn x 1),qlit n hn x a b]
def caseRow (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n)):=
  Resolution.branch (clause (core n hn x a b side)) (-(source n hn i).val)
theorem core_valid (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):Valid (core n hn x a b side):=by
  simp [core,qlit,Valid,sign_valid,(H n hn).property]

def earlierRows (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n-1)):=
  FinalSelectedEvaluation.rows n hn x i a b side++[caseRow n hn x a b side (coord n i)]
def earlierProgram (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n-1)) (E:List Row):Program:=
  FinalSelectedEvaluation.program n hn x i a b side E++
    [(caseRow n hn x a b side (coord n i),ChoiceProjection.weakenTokens (E++FinalSelectedEvaluation.rows n hn x i a b side)
      [-(source n hn (coord n i)).val,-sign a (port n hn x 0),(H n hn).val,-sign side (OutputPhaseRows.phase n hn),qlit n hn x a b]
      [-sign b (port n hn x 1)])]
theorem earlier_check (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n-1)) (E:List Row) (he:∀R∈D n hn,R∈E):
    check E (earlierProgram n hn x a b side i E)=some (E++earlierRows n hn x a b side i):=by
  have h0:=FinalSelectedEvaluation.checks n hn x i a b side E he
  have h1:=ChoiceProjection.weaken_succeeds (E++FinalSelectedEvaluation.rows n hn x i a b side)
    [-(source n hn (coord n i)).val,-sign a (port n hn x 0),(H n hn).val,-sign side (OutputPhaseRows.phase n hn),qlit n hn x a b]
    [-sign b (port n hn x 1)]
    (by simp [Valid,sign_valid,qlit,(source n hn (coord n i)).property,(H n hn).property]) (by simp [Valid,sign_valid])
    (List.mem_append_right _ (by simp [FinalSelectedEvaluation.rows,SelectedOutputPOL.rows,SelectedOutputPOL.r2,FinalSelectedEvaluation.lits]))
  have hr:clause ([ -(source n hn (coord n i)).val,-sign a (port n hn x 0),(H n hn).val,-sign side (OutputPhaseRows.phase n hn),qlit n hn x a b]++[-sign b (port n hn x 1)])=
      caseRow n hn x a b side (coord n i):=by
    rw [caseRow,ProjectionTrace.branch_clause _ (core_valid n hn x a b side) _ (neg_ne_zero.mpr (source n hn (coord n i)).property)]
    apply GateUnaryCompositionPOL.clause_value_eq _ _
      (by simp [Valid,qlit,sign_valid,(source n hn (coord n i)).property,(H n hn).property])
      (by simp [core,Valid,qlit,sign_valid,(source n hn (coord n i)).property,(H n hn).property])
    intro α;simp only [core,sum_append,sum_cons,sum_nil];ring
  rw [hr] at h1
  have h2:check (E++FinalSelectedEvaluation.rows n hn x i a b side)
      [(caseRow n hn x a b side (coord n i),ChoiceProjection.weakenTokens (E++FinalSelectedEvaluation.rows n hn x i a b side)
      [-(source n hn (coord n i)).val,-sign a (port n hn x 0),(H n hn).val,-sign side (OutputPhaseRows.phase n hn),qlit n hn x a b] [-sign b (port n hn x 1)])]=
      some ((E++FinalSelectedEvaluation.rows n hn x i a b side)++[caseRow n hn x a b side (coord n i)]):=by simp only [check,h1,↓reduceIte]
  simpa only [earlierProgram,earlierRows,List.append_assoc] using check_append _ _ _ _ _ h0 h2

def lastExtra (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):List Int:=
  [-sign side (OutputPhaseRows.phase n hn),-sign a (port n hn x 0),-sign b (port n hn x 1),qlit n hn x a b]
def lastRows (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):List Row:=
  [clause [(H n hn).val,-(H n hn).val],caseRow n hn x a b side (lastCoord n hn)]
def lastProgram (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row):Program:=
  [(clause [(H n hn).val,-(H n hn).val],ComplementChoice.tautTokens (H n hn).val),
   (caseRow n hn x a b side (lastCoord n hn),ChoiceProjection.weakenTokens (E++[clause [(H n hn).val,-(H n hn).val]]) [(H n hn).val,-(H n hn).val] (lastExtra n hn x a b side))]
theorem last_check (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row):
    check E (lastProgram n hn x a b side E)=some (E++lastRows n hn x a b side):=by
  have h0:=ComplementChoice.taut_pair_succeeds (dbOf E) (H n hn).val (H n hn).property
  have h1:=ChoiceProjection.weaken_succeeds (E++[clause [(H n hn).val,-(H n hn).val]]) [(H n hn).val,-(H n hn).val] (lastExtra n hn x a b side)
    (by simp [Valid,(H n hn).property]) (by simp [lastExtra,Valid,qlit,sign_valid]) (List.mem_append_right _ (List.mem_singleton_self _))
  have hr:clause ([(H n hn).val,-(H n hn).val]++lastExtra n hn x a b side)=caseRow n hn x a b side (lastCoord n hn):=by
    rw [caseRow,ProjectionTrace.branch_clause _ (core_valid n hn x a b side) _ (neg_ne_zero.mpr (source n hn (lastCoord n hn)).property)]
    apply GateUnaryCompositionPOL.clause_value_eq _ _ (by simp [lastExtra,Valid,qlit,sign_valid,(H n hn).property])
      (by simp [core,Valid,qlit,sign_valid,(H n hn).property,(source n hn (lastCoord n hn)).property])
    intro α;simp only [core,lastExtra,H,sum_append,sum_cons,sum_nil];ring
  rw [hr] at h1
  simp only [lastProgram,lastRows,check,h0,h1,↓reduceIte,List.append_assoc,List.cons_append,List.nil_append]

def rows (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n)):=
  if h:i.val<W n-1 then earlierRows n hn x a b side ⟨i.val,h⟩ else lastRows n hn x a b side
def leaf (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n)) (E:List Row):Program:=
  if h:i.val<W n-1 then earlierProgram n hn x a b side ⟨i.val,h⟩ E else lastProgram n hn x a b side E
theorem checks (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n)) (E:List Row) (he:∀R∈D n hn,R∈E):
    check E (leaf n hn x a b side i E)=some (E++rows n hn x a b side i):=by
  unfold leaf rows;split
  · exact earlier_check n hn x a b side _ E he
  · exact last_check n hn x a b side E

theorem contains (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n)):
    caseRow n hn x a b side i∈rows n hn x a b side i:=by
  unfold rows;split
  · rename_i h
    have he:coord n ⟨i.val,h⟩=i:=Fin.ext rfl
    simp only [earlierRows,he]
    exact List.mem_append_right _ (List.mem_singleton_self _)
  · rename_i h
    have he:i=lastCoord n hn:=Fin.ext (by change i.val=W n-1;have:=i.isLt;omega)
    rw [he];simp [lastRows]
#print axioms checks
#print axioms contains
end L3Emitter.FinalSelectedCases

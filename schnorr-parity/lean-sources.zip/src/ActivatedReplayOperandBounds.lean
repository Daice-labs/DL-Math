import ReplayOperandBounds
namespace L3Emitter.ActivatedReplayOperandBounds
open EREF EREF.GeneralRED RecordedScopedTrace RecordedOperandFields FieldLengthsFromIDs
open ReplayOperandBounds RecursiveOperandBounds
theorem relocate (M:Nat) (D F:List Row) (C:Row) (w:FiniteWitness.Data)
    (ps:List RecordedRefutation.Certificate) (R:Row) (h:∀p∈ps,Local M p):
    Local M (RecordedActivatedReplay.relocateGoal D F C w ps R):=
  rebase_local M _ _ _ (pick M _ ps R h)

theorem goals (M:Nat) (D U I:List Row) (a:Row→Nat) (l:Int) (C:Row) (w:FiniteWitness.Data)
    (ps:List RecordedRefutation.Certificate) (ha:∀R∈I,a R≤M) (hl:l.natAbs≤M)
    (h:∀p∈ps,Local M p):∀p∈RecordedActivatedReplay.goals D U I a l C w ps,Local M p:=by
  intro p hp
  simp only [RecordedActivatedReplay.goals,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hp
  rcases hp with (((rfl|hp)|hp)|hp)|hp
  · exact relocate M D _ C w ps C h
  · obtain ⟨R,hR,rfl⟩:=List.mem_map.mp hp;exact ReplayOperandBounds.fixed M _ C R
  · obtain ⟨R,hR,rfl⟩:=List.mem_map.mp hp
    exact guarded M D _ C R w (a R) l _ (ha R hR) hl (pick M _ ps R h)
  · subst p;exact ReplayOperandBounds.fixed M _ C _
  · obtain ⟨R,hR,rfl⟩:=List.mem_map.mp hp;exact relocate M D _ C w ps R h

/-- Retained-frame replay adds only cancellation operands: the guard literal
and the weakening amount. All existing non-reference operands are unchanged. -/
theorem step (M:Nat) (D U I:List Row) (a:Row→Nat) (l:Int) (c:Step)
    (ha:∀R∈I,a R≤M) (hl:l.natAbs≤M) (h:Content M c):
    Content M (RecordedActivatedReplay.step D U I a l c):=by
  cases c with
  | pol R ts=>exact rebase_tape M D _ ts h
  | consequence R p=>exact ⟨h.1,rebase_local M _ _ p h.2⟩
  | red R w ps=>exact ⟨h.1,h.2.1,goals M D U I a l R w ps ha hl h.2.2⟩

theorem program (M:Nat) (D U I:List Row) (a:Row→Nat) (l:Int) (p:Program)
    (ha:∀R∈I,a R≤M) (hl:l.natAbs≤M) (h:∀c∈p,Content M c):
    ∀c∈RecordedActivatedReplay.program D U I a l p,Content M c:=by
  induction p generalizing D with
  | nil=>simp [RecordedActivatedReplay.program]
  | cons c cs ih=>
    intro t ht
    rcases List.mem_cons.mp ht with rfl|ht
    · exact step M D U I a l c ha hl (h c (by simp))
    · exact ih _ (fun c hc=>h c (by simp [hc])) t ht


#print axioms program
end L3Emitter.ActivatedReplayOperandBounds

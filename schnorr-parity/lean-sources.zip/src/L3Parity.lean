/-
The parity target `parity(k)` of family.py (popcount parity) is invariant under every
exchange of two input wires. This discharges the `hinv` hypothesis of
`normalization_prefix_trace` for the family actually emitted (`parityFam k s`).
-/
import L3SwapRED

namespace L3

/-- popcount restricted to the n low bits, as an integer sum -/
def popLow (n x : Nat) : Int := sumR n fun i => if x.testBit i then 1 else 0

theorem sumR_succ_left (n : Nat) (g : Nat → Int) : sumR (n + 1) g = g 0 + sumR n (fun i => g (i + 1)) := by
  induction n with
  | zero => simp [sumR_succ, sumR_zero]
  | succ n ih => rw [sumR_succ, ih, sumR_succ]; omega

theorem popLow_succ (n x : Nat) :
    popLow (n + 1) x = (if x % 2 = 1 then 1 else 0) + popLow n (x / 2) := by
  unfold popLow
  rw [sumR_succ_left]
  simp only [Nat.testBit_zero, Nat.testBit_succ]
  congr 1
  split <;> simp_all

theorem popLow_zero (n : Nat) : popLow n 0 = 0 := by
  unfold popLow; apply sumR_zero_of; intro i _; simp

theorem parityBit_eq_popLow (n : Nat) : ∀ x, x < 2 ^ n → parityBit x = decide (popLow n x % 2 = 1) := by
  induction n with
  | zero =>
    intro x hx
    have : x = 0 := by simp at hx; omega
    subst this
    simp [parityBit, popLow, sumR_zero]
  | succ n ih =>
    intro x hx
    rw [parityBit, popLow_succ]
    have hx2 : x / 2 < 2 ^ n := by
      rw [Nat.pow_succ] at hx; omega
    rw [ih (x / 2) hx2]
    by_cases h0 : x = 0
    · subst h0; simp [popLow_zero]
    · simp only [h0, ↓reduceDIte]
      by_cases hx1 : x % 2 = 1 <;> by_cases hp : popLow n (x / 2) % 2 = 1 <;>
        simp [hx1, hp] <;> omega

/-- the low-n popcount is invariant under exchanging two bit positions below n -/
theorem popLow_xm (F : Fam) (a b x : Nat) (ha : a < F.k) (hb : b < F.k) (hab : a ≠ b) :
    popLow F.k (F.xm a b x) = popLow F.k x := by
  unfold popLow
  have hP : F.bitPos a < F.k := by unfold Fam.bitPos; omega
  have hQ : F.bitPos b < F.k := by unfold Fam.bitPos; omega
  have hPQ : F.bitPos a ≠ F.bitPos b := by unfold Fam.bitPos; omega
  have hg : ∀ i, (if (F.xm a b x).testBit i then (1 : Int) else 0) =
      (fun i => if x.testBit i then (1 : Int) else 0) (Fam.jmap (F.bitPos a) (F.bitPos b) i) := by
    intro i
    rw [Fam.testBit_xm]
    unfold Fam.jmap
    by_cases h1 : i = F.bitPos a
    · simp [h1]
    · by_cases h2 : i = F.bitPos b
      · simp [h1, h2, Ne.symm hPQ]
      · simp [h1, h2]
  calc sumR F.k (fun i => if (F.xm a b x).testBit i then (1 : Int) else 0)
      = sumR F.k (fun i => (fun i => if x.testBit i then (1 : Int) else 0)
          (Fam.jmap (F.bitPos a) (F.bitPos b) i)) := by
        unfold sumR; congr 1; apply List.map_congr_left; intro i _; exact hg i
    _ = sumR F.k (fun i => if x.testBit i then (1 : Int) else 0) :=
        sumR_swap F.k (F.bitPos a) (F.bitPos b) (fun i => if x.testBit i then (1 : Int) else 0) hP hQ hPQ

/-- **parity is swap-invariant**: the target of `parityFam` satisfies `hinv` -/
theorem parityBit_xm (F : Fam) (a b x : Nat) (ha : a < F.k) (hb : b < F.k) (hab : a ≠ b)
    (hx : x < F.T) : parityBit (F.xm a b x) = parityBit x := by
  have hx' : F.xm a b x < F.T := F.xm_lt a b x ha hb hx
  unfold Fam.T at hx hx'
  rw [parityBit_eq_popLow F.k _ hx', parityBit_eq_popLow F.k _ hx, popLow_xm F a b x ha hb hab]

/-- **The selector-normalization prefix for the emitted family**: for every k ≥ 2 and s ≥ 1,
    `parityFam k s` admits the checked trace of the 2k−3 swap-RED commands. -/
theorem parity_normalization_prefix_trace (k s : Nat) (hk : 2 ≤ k) (hs : 1 ≤ s) :
    EREF.GeneralRED.CheckedTrace ((parityFam k s).rows.map Row.toE) ((parityFam k s).db2 k) := by
  apply Fam.normalization_prefix_trace _ hk hs
  intro a j ha hj haj x hx
  exact parityBit_xm (parityFam k s) a j x ha hj haj hx

/-- the emitter's actual parameters s = 3k − 4, k ≥ 3 -/
theorem parity_normalization_prefix_trace_emitter (k : Nat) (hk : 3 ≤ k) :
    EREF.GeneralRED.CheckedTrace ((parityFam k (3 * k - 4)).rows.map Row.toE)
      ((parityFam k (3 * k - 4)).db2 k) :=
  parity_normalization_prefix_trace k (3 * k - 4) (by omega) (by omega)

end L3

#print axioms L3.parity_normalization_prefix_trace_emitter

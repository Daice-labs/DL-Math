import ConstructionConstantCount
import RecordedRankAdmission

namespace L3Emitter.ConstructionRankCount
open EREF EREF.GeneralRED ConstructionConstantCount

theorem blocks {A : Type} (rows : A→List Row)
    (block : List Row→A→RecordedScopedTrace.Program) (D : List Row) (xs : List A) (M : Nat)
    (h : ∀D x,(block D x).length=M) :
    (RecordedBlocks.program rows block D xs).length=xs.length*M := by
  induction xs generalizing D with
  | nil=>simp [RecordedBlocks.program]
  | cons x xs ih=>rw [RecordedBlocks.program,List.length_append,h,ih,List.length_cons];ring

theorem alo {A : Type} (D : List Row) (xs : List A) (c o : A→Int) (qs : List Int) :
    (RecordedCaseProjection.aloProgram D xs c o qs).length=xs.length+1 := by
  rw [RecordedCaseProjection.aloProgram,List.length_append,blocks _ _ _ _ 1 (by intros;rfl)]
  simp [RecordedBlocks.pol]

theorem amo {A : Type} (D : List Row) (xs : List A) (c : A→Int) (q r : Int)
    (side : A→Bool) (ls rs : List Int) :
    (RecordedCaseProjection.amoProgram D xs c q r side ls rs).length=2*xs.length+1 := by
  rw [RecordedCaseProjection.amoProgram,List.length_append,blocks _ _ _ _ 2 (by intros;rfl)]
  simp [RecordedBlocks.pol,Nat.mul_comm]

theorem columns (s : Nat) : (RankAdmission.columnPairs s).length≤s^3 := by
  unfold RankAdmission.columnPairs
  have hh:=flat_count (List.range (s-1)) (fun j=>(List.range (s-1)).flatMap fun h=>
    if j<h then (List.range (s-3)).map (fun t=>(j+1,h+1,t)) else []) (s*s) (by
      intro j hj
      have h:=flat_count (List.range (s-1)) (fun h=>
        if j<h then (List.range (s-3)).map (fun t=>(j+1,h+1,t)) else []) s (by
          intro h hh;dsimp only;split <;> simp <;> omega)
      simp only [List.length_range] at h
      exact h.trans (Nat.mul_le_mul_right _ (Nat.sub_le ..)))
  simp only [List.length_range] at hh
  exact hh.trans (by have h:=Nat.mul_le_mul_right (s*s) (Nat.sub_le s 1);nlinarith)

theorem rows (s : Nat) : (RankAdmission.rowPairs s).length≤s^3 := by
  unfold RankAdmission.rowPairs
  have hh:=flat_count (List.range (s-1)) (fun j=>(List.range (s-3)).flatMap fun t=>
    (List.range (s-3)).flatMap fun u=>if t<u then [(j+1,t,u)] else []) (s*s) (by
      intro j hj
      have h:=flat_count (List.range (s-3)) (fun t=>
        (List.range (s-3)).flatMap fun u=>if t<u then [(j+1,t,u)] else []) s (by
          intro t ht
          have hu:=flat_count (List.range (s-3)) (fun u=>if t<u then [(j+1,t,u)] else []) 1 (by
            intro u hu;dsimp only;split <;> simp)
          simpa only [List.length_range,mul_one] using hu.trans (by simp))
      simp only [List.length_range] at h
      exact h.trans (Nat.mul_le_mul_right _ (Nat.sub_le ..)))
  simp only [List.length_range] at hh
  exact hh.trans (by have h:=Nat.mul_le_mul_right (s*s) (Nat.sub_le s 1);nlinarith)

theorem exact_count (k : Nat) (hk : 3≤k) (D : List Row) :
    (RecordedRankAdmission.program k hk D).length=
      ((3*k-4)-3)*((BranchChoices.chosen k hk).length+1)+
      ((RankAdmission.columnPairs (3*k-4)).length+(RankAdmission.rowPairs (3*k-4)).length)*
        (2*(BranchChoices.chosen k hk).length+1) := by
  simp only [RecordedRankAdmission.program,List.length_append,
    RecordedRankAdmission.columns,RecordedRankAdmission.columnPairsProgram,
    RecordedRankAdmission.rowPairsProgram,RecordedRankProjection.columnProgram,
    RecordedRankProjection.cellsProgram,
    blocks _ _ _ _ _ (fun E t=>alo E _ _ _ _),
    blocks _ _ _ _ _ (fun E q=>amo E _ _ _ _ _ _ _),List.length_range]
  ring

/-- Main-command count for all rank-column and rank-row cardinality proofs. -/
theorem complete (k : Nat) (hk : 3≤k) (D : List Row) :
    (RecordedRankAdmission.program k hk D).length≤1100*(k+1)^5 := by
  have hc:=ForcingSize.chosen_bound k hk
  have hcol:=columns (3*k-4)
  have hrow:=rows (3*k-4)
  have hs:3*k-4≤3*k:=Nat.sub_le ..
  have hs3: (3*k-4)^3≤27*k^3:=by
    have h:=Nat.pow_le_pow_left hs 3;nlinarith
  have hsmall:(3*k-4)-3≤3*k:=by omega
  have h1:=Nat.mul_le_mul hsmall (show (BranchChoices.chosen k hk).length+1≤9*k^2+1 by omega)
  have h2:=Nat.mul_le_mul (show (RankAdmission.columnPairs (3*k-4)).length+
    (RankAdmission.rowPairs (3*k-4)).length≤54*k^3 by omega)
    (show 2*(BranchChoices.chosen k hk).length+1≤18*k^2+1 by omega)
  rw [exact_count]
  nlinarith

#print axioms exact_count
#print axioms complete
end L3Emitter.ConstructionRankCount

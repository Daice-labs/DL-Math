import NativeRuntimeWitnessSupport
namespace L3Emitter.NativeRuntimeSupport
open EREF EREF.GeneralRED NativeSparseStore CanonicalScopeKernel

theorem push_vars (K:Nat) (s:Store) (R:Row) (hs:StoreVars K s) (hc:Canonical R) (hr:RowVars K R):StoreVars K (push s R):=by
 intro i Q h
 by_cases hi:i=s.next
 · simp only [push,if_pos hi,Option.some.injEq] at h;subst Q;exact ⟨hc,hr⟩
 · simp only [push,if_neg hi] at h;exact hs i Q h
 theorem close_vars (K:Nat) (s:Store) (first:Nat) (hs:StoreVars K s):StoreVars K (closeFrom s first):=by
 intro i R h
 by_cases hi:first ≤ i
 · simp [closeFrom,hi] at h
 · simp only [closeFrom,if_neg hi] at h;exact hs i R h
 theorem read_vars (K:Nat) (s:Store) (i:Int) (R:Row) (hs:StoreVars K s) (h:NativeSparseStore.read s i=some R):Canonical R ∧ RowVars K R:=by
 obtain ⟨j,hj,hr⟩:=Option.bind_eq_some_iff.mp h
 exact hs j R hr
 theorem program_vars (K:Nat) (s q:Store) (ps:List (List Tok)) (hs:StoreVars K s)
 (hp:∀ts∈ps,TapeVars K ts) (h:NativeLocalProgram.execute s ps=some q):StoreVars K q:=by
 induction ps generalizing s with
 | nil=>simp only [NativeLocalProgram.execute,Option.some.injEq] at h;subst q;exact hs
 | cons ts ps ih=>
   cases he:polEval s.rows ts [] with
   | none=>simp [NativeLocalProgram.execute,he] at h
   | some R=>
     have hR:=pol_vars K s.rows ts [] R (fun i Q hQ=>(hs i Q hQ).2) (hp ts (by simp)) (by simp) he
     have hc:=CanonicalTrace.pol s.rows (fun i Q hQ=>(hs i Q hQ).1) ts [] (by simp) R he
     apply ih (push s R) (push_vars K s R hs hc hR) (fun ts ht=>hp ts (by simp [ht]))
     simpa only [NativeLocalProgram.execute,he] using h
 theorem local_goal_vars (K:Nat) (s q:Store) (G:Row) (p:LocalProof)
 (hs:StoreVars K s) (hg:RowVars K G) (hp:∀ts∈p.tapes,TapeVars K ts)
 (h:NativeScopedLocalGoal.execute s G (restore p)=some q):StoreVars K q:=by
 obtain ⟨t,ht,hread⟩:=Option.bind_eq_some_iff.mp h
 obtain ⟨R,hR,hclose⟩:=Option.bind_eq_some_iff.mp hread
 have ht':StoreVars K t:=program_vars K _ t p.tapes
   (push_vars K s (negate G) hs (canonical_negate G) (negate_vars K G hg)) hp ht
 split at hclose
 · have hh:=Option.some.inj hclose;subst q;exact close_vars K t s.next ht'
 · contradiction
 theorem source_vars (K:Nat) (original:Store) (C:Row) (key:GoalKey) (R:Row)
 (ho:StoreVars K original) (hc:Canonical C) (hC:RowVars K C)
 (h:PinnedREDKeyExecution.sourceRow original C key=some R):Canonical R ∧ RowVars K R:=by
 cases key with
 | candidate=>simp only [PinnedREDKeyExecution.sourceRow,Option.some.injEq] at h;subst R;exact ⟨hc,hC⟩
 | database i=>exact read_vars K original (i:Int) R ho h
 theorem goals_vars (K:Nat) (original:Store) (C:Row) (w:FiniteWitness.Data) (s q:Store) (gs:List Goal)
 (ho:StoreVars K original) (hc:Canonical C) (hC:RowVars K C) (hw:WitnessVars K w)
 (hs:StoreVars K s) (hg:∀g∈gs,∀ts∈g.proof.tapes,TapeVars K ts)
 (h:PinnedREDKeyExecution.execute original C w s gs=some q):StoreVars K q:=by
 induction gs generalizing s with
 | nil=>simp only [PinnedREDKeyExecution.execute,Option.some.injEq] at h;subst q;exact hs
 | cons g gs ih=>
   obtain ⟨R,hR,ht⟩:=Option.bind_eq_some_iff.mp h
   obtain ⟨t,ht,hq⟩:=Option.bind_eq_some_iff.mp ht
   have hsrc:=source_vars K original C g.key R ho hc hC hR
   have hsub:=native_substitution_vars K w hw R hsrc.2
   apply ih t (local_goal_vars K s t _ g.proof hs hsub (hg g (by simp)) ht)
     (fun g hg'=>hg g (by simp [hg'])) hq
 theorem execute_vars (K:Nat) (s q:Store) (c:CanonicalScopeKernel.Command) (hs:StoreVars K s)
 (hc:CommandVars K c) (h:PinnedScopeExecution.execute s c=some q):StoreVars K q:=by
 cases c with
 | pol ts=>
   obtain ⟨R,hR,hq⟩:=Option.bind_eq_some_iff.mp h
   have he:=Option.some.inj hq;subst q
   exact push_vars K s R hs
     (CanonicalTrace.pol s.rows (fun i Q hQ=>(hs i Q hQ).1) ts [] (by simp) R hR)
     (pol_vars K s.rows ts [] R (fun i Q hQ=>(hs i Q hQ).2) hc (by simp) hR)
 | consequence R p=>
   by_cases hR:Canonical R
   · simp only [PinnedScopeExecution.execute,decide_eq_true hR,Bool.not_true,Bool.false_eq_true,↓reduceIte] at h
     obtain ⟨t,ht,hq⟩:=Option.bind_eq_some_iff.mp h
     have he:=Option.some.inj hq;subst q
     exact push_vars K t R (local_goal_vars K s t R p hs hc.1 hc.2 ht) hR hc.1
   · simp [PinnedScopeExecution.execute,hR] at h
 | red R w gs=>
   by_cases hR:Canonical R
   · by_cases hv:(FiniteWitness.valid w && PinnedScopeExecution.covers s gs)=true
     · simp only [PinnedScopeExecution.execute,decide_eq_true hR,Bool.true_and,hv,
         Bool.not_true,Bool.false_eq_true,↓reduceIte] at h
       obtain ⟨t,ht,hq⟩:=Option.bind_eq_some_iff.mp h
       have he:=Option.some.inj hq;subst q
       apply push_vars K _ R ?_ hR hc.1
       apply close_vars K t s.next
       exact goals_vars K s R w _ t gs hs hR hc.1 hc.2.1
         (push_vars K s (negate R) hs (canonical_negate R) (negate_vars K R hc.1)) hc.2.2 ht
     · simp [PinnedScopeExecution.execute,hR,hv] at h
   · simp [PinnedScopeExecution.execute,hR] at h
#print axioms execute_vars
end L3Emitter.NativeRuntimeSupport

import FullNormalization

set_option linter.unusedSimpArgs false
namespace L3Emitter.FullNormalization
open FamilyNamespace FamilyRows NamedWitness InputSwap SelectorNormalization
open TemplateBytes NormalizationEmitter

theorem named_witness_bound (k s : Nat) (f : Wire → Target)
    (hf : ∀ w,Valid k s w → (f w).valid k s) :
    exactBytes (L3Emitter.witness (NamedSerialization.entries k s f)) ≤
      variableCount k s*(7+2*digits (variableCount k s)) := by
  let es := NamedSerialization.entries k s f
  let M := variableCount k s
  have hh := separated_bound (fixed " ") (es.map
    (fun t => literal ⟨t.1,false⟩ ++ fixed " -> " ++ image t.2))
  have he : ∀ p∈es,
      exactBytes (literal ⟨p.1,false⟩ ++ fixed " -> " ++ image p.2)≤6+2*digits M := by
    intro p hp
    obtain ⟨w,hw,rfl⟩ := List.mem_map.mp hp
    have hv := (WireEnumeration.mem_all k s w).mp (List.mem_filter.mp hw).1
    have ha := digits_mono (encode_bounds k s w hv).2
    have ht := hf w hv
    cases hm : f w with
    | bit b =>
      cases b <;> simp only [hm,NamedSerialization.targetImage,image,literal,
        exactBytes_append,fixed_bytes,number_bytes]
      all_goals
        change 1+digits (encode k s w)+4+1≤6+2*digits M
        dsimp only [M] at *
        omega
    | wire v =>
      rw [hm] at ht
      have hb := digits_mono (encode_bounds k s v ht).2
      simp only [hm,NamedSerialization.targetImage,image,literal,exactBytes_append,fixed_bytes,number_bytes]
      change 1+digits (encode k s w)+4+(1+digits (encode k s v))≤6+2*digits M
      dsimp only [M] at *
      omega
  have hs := sum_bound es (fun t => exactBytes (literal ⟨t.1,false⟩ ++ fixed " -> " ++ image t.2))
    (6+2*digits M) he
  have hn := NamedSerialization.entries_length k s f
  simp only [List.length_map,List.map_map,Function.comp_def,fixed_bytes] at hh
  change _≤(es.map (fun t => exactBytes (literal ⟨t.1,false⟩ ++ fixed " -> " ++ image t.2))).sum+es.length*1 at hh
  change exactBytes (separated (fixed " ") (es.map _))≤M*(7+2*digits M)
  dsimp only [es,M] at *
  nlinarith

theorem named_literal_bound (k s : Nat) (l : NamedLit) (hl : Valid k s l.1) :
    exactBytes (literal (signedLiteral (lit k s l)))≤2+digits (variableCount k s) := by
  have hp := (encode_bounds k s l.1 hl).1
  have hb := digits_mono (encode_bounds k s l.1 hl).2
  rw [literal_bytes]
  rcases l with ⟨w,b⟩
  cases b <;> simp [lit,literalBytes,hp,show ¬(encode k s w:Int)<0 by omega] <;>
    dsimp only at hb <;> omega

theorem spec_row_bound (k s : Nat) (r : Spec) (hr : r.valid k s)
    (hn : r.literals.length≤4) (hb : r.rhs=1) :
    exactBytes (row (specPB k s r))≤25+4*digits (variableCount k s) := by
  have he : ∀ l∈r.literals,
      exactBytes (number 1++fixed " "++literal (signedLiteral (lit k s l)))≤4+digits (variableCount k s) := by
    intro l hl
    have hh := named_literal_bound k s l (hr l hl)
    simp only [exactBytes_append,number_bytes,fixed_bytes]
    change 1+1+_≤4+digits (variableCount k s)
    omega
  have hs := sum_bound r.literals (fun l => exactBytes (number 1++fixed " "++literal (signedLiteral (lit k s l))))
    (4+digits (variableCount k s)) he
  have hh := separated_bound (fixed " ") (r.literals.map
    (fun l => number 1++fixed " "++literal (signedLiteral (lit k s l))))
  unfold row specPB
  simp only [List.map_map,Function.comp_def,exactBytes_append,hb,integer,
    show ¬(1:Int)<0 by omega,↓reduceIte,number_bytes,fixed_bytes]
  change _+4+1≤25+4*digits (variableCount k s)
  simp only [List.length_map,List.map_map,Function.comp_def,fixed_bytes] at hh
  change _≤(r.literals.map _).sum+r.literals.length*1 at hh
  nlinarith

def stepBound (k s : Nat) :=
  35+4*digits (variableCount k s)+variableCount k s*(7+2*digits (variableCount k s))

theorem named_command_bound (k s : Nat) (r : Spec) (hr : r.valid k s)
    (hn : r.literals.length≤4) (hb : r.rhs=1) (f : Wire → Target)
    (hf : ∀ w,Valid k s w → (f w).valid k s) :
    exactBytes (command (.red (specPB k s r) (NamedSerialization.entries k s f)))≤stepBound k s := by
  have hrow := spec_row_bound k s r hr hn hb
  have hw := named_witness_bound k s f hf
  unfold command stepBound
  simp only [exactBytes_append,fixed_bytes]
  change 4+_+3+_+3≤_
  omega

theorem extra_bound (k s : Nat) (hk : 2≤k) (hs : 0<s) (c : Command) (hc : c∈extraCommands k s) :
    exactBytes (command c)≤stepBound k s := by
  simp only [extraCommands,List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl | rfl | rfl
  · exact named_command_bound k s (unitSpec 1 0) (unit_valid _ _ _ _ hs (by decide) (by omega))
      (by decide) rfl (RepeatedWitness.image k) (RepeatedWitness.image_valid k s)
  · exact named_command_bound k s (forbidden 0 3) (ProjectionNormalization.forbidden_valid _ _ _ hs)
      (by decide) rfl _ (PortSwap.combined_valid k s hk)
  · exact named_command_bound k s (forbidden 0 12) (ProjectionNormalization.forbidden_valid _ _ _ hs)
      (by decide) rfl _ (PortSwap.combined_valid k s hk)

theorem full_document_bound (k s : Nat) (hk : 2≤k) (hs : 0<s) :
    (emit (document k s)).length≤2*k*stepBound k s := by
  rw [emit_length]
  unfold document
  rw [flatMap_bytes]
  have hh := sum_bound (commands k s) (fun c => exactBytes (command c)) (stepBound k s) (by
    intro c hc
    rcases List.mem_append.mp hc with hc | hc
    · obtain ⟨pj,hpj,rfl⟩ := List.mem_map.mp hc
      have hb : pj.1<2 ∧ pj.1<k ∧ pj.2<k := by
        rcases (right_mem k k pj.1 pj.2).mp hpj with h | h <;> omega
      have h := command_bound k s pj.1 pj.2 hs hb.1 hb.2.1 hb.2.2
      unfold stepByteBound at h
      unfold stepBound
      dsimp only
      omega
    · exact extra_bound k s hk hs c hc)
  simpa only [command_count k s hk] using hh

def boundInN (n : Nat) := 2*n*stepBound n (3*n-4)

theorem normalization_size_in_n (n : Nat) (hn : 3≤n) :
    (emit (document n (3*n-4))).length≤boundInN n :=
  full_document_bound n _ (by omega) (by omega)

#print axioms full_document_bound
#print axioms normalization_size_in_n
end L3Emitter.FullNormalization

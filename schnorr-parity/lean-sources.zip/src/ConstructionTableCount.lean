import ConstructionCoordinateCount
import ConstructionTableValueCount
import ConstructionComposedTableCount
namespace L3Emitter.ConstructionTableCount
open EREF EREF.GeneralRED ConstructionGlobalCount ConstructionCountTools
/-- Main commands for the entire table-transport stage, not bytes. -/
theorem complete (n : Nat) (hn : 2≤n) :
    (RecordedTableTransport.program n hn).length≤6000*Q n := by
  have h0: (RecordedRankPorts.program n hn).length≤1800*Q n :=
    (ConstructionCoordinateCount.rank n hn).trans (lift_plain n 1800 4 (by omega))
  have h1:= (ConstructionTableValueCount.values n hn).trans (lift_power n 1320 3 (by omega))
  have h2:= (ConstructionCoordinateCount.raw n hn).trans (lift_power n 150 2 (by omega))
  have h3:= (ConstructionTableValueCount.raw_unary n hn).trans (lift_power n 120 2 (by omega))
  have h4: (RecordedComposedTables.program n hn).length≤1500*Q n :=
    (ConstructionComposedTableCount.complete n hn).trans (by simpa using lift_plain n 1500 1 (by omega))
  have h5:= (ConstructionCoordinateCount.table n hn).trans (lift_plain n 228 2 (by omega))
  simp only [RecordedTableTransport.program,RecordedTableTransport.p5,RecordedTableTransport.p4,
    RecordedTableTransport.p3,RecordedTableTransport.p2,RecordedTableTransport.p1,
    RecordedTableTransport.p0,List.length_append,polProgram_length]
  omega
#print axioms complete
end L3Emitter.ConstructionTableCount

import NumericRecordedGlobal
import NumericRecordedTables
import NumericRecordedLower
import NumericRecordedFinal
import RecordedCompleteLower
namespace L3Emitter.NumericCompletePrefix
open EREF EREF.GeneralRED FieldLengthsFromIDs
/-- Integer magnitude, including every local certificate; not a byte count. -/
def bound (n:Nat):Nat:=NumericRecordedGlobal.bound n+NumericRecordedTables.bound n+NumericRecordedLower.bound n+NumericRecordedFinal.bound n

theorem program (n:Nat) (hn:2≤n):∀c∈RecordedCompleteLower.program n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · rcases List.mem_append.mp hc with hc|hc
   · rcases List.mem_append.mp hc with hc|hc
     · exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c (NumericRecordedGlobal.program n hn c hc)
     · exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c (NumericRecordedTables.program n hn c hc)
   · exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c (NumericRecordedLower.program n hn c hc)
 · exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c (NumericRecordedFinal.program n hn c hc)
#print axioms program
end L3Emitter.NumericCompletePrefix

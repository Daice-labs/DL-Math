import L3BranchChains

namespace L3
open EREF EREF.GeneralRED

theorem branch_root_sum (α : Val) (B : Nat) (xs : List Int) (hx : ∀x∈xs,x≠0) :
    ((xs.map fun x => clauseRow [(B:Int),-x]).map fun r => lsum α r.lits-(r.rhs:Int)).sum =
      (xs.length:Int)*lv α (B:Int)-lsum α xs := by
  induction xs with
  | nil => simp [lsum_nil]
  | cons x xs ih =>
    rw [List.map_cons,List.map_cons,List.sum_cons,ih (fun y hy => hx y (by simp [hy]))]
    have hn := lv_neg_lit α x (hx x (by simp))
    simp only [clauseRow,lsum_cons,lsum_nil,List.length_cons]
    rw [show ((xs.length+1:Nat):Int)=(xs.length:Int)+1 by omega,Int.add_mul]
    omega

/-- Coverage plus exclusion of the output gate closes the branch OR. -/
theorem branch_merge_chain (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (B A last : Nat) (xs : List Int) (hB : 1≤B) (hA : 1≤A) (hL : 1≤last)
    (hx : ∀x∈xs,x≠0) (hr : ∀x∈xs,(clauseRow [(B:Int),-x]).toE∈D)
    (ha : (gateRow (xs++[(last:Int)]) A false).toE∈D)
    (hAr : (clauseRow [(A:Int)]).toE∈D)
    (hl : (clauseRow [-(last:Int)]).toE∈D) :
    Refutation (D++[negate (clauseRow [(B:Int)]).toE]) := by
  apply weighted_clause_chain D _ xs.length
    ((xs.map fun x => clauseRow [(B:Int),-x])++
      [gateRow (xs++[(last:Int)]) A false,clauseRow [(A:Int)],clauseRow [-(last:Int)]]) hD
  · nz_lits
  · apply All.append
    · apply All.of_mem
      intro r h
      obtain ⟨x,hx,rfl⟩ := List.mem_map.mp h
      exact hr x hx
    · exact ⟨ha,hAr,hl,trivial⟩
  · apply All.append
    · apply All.of_mem
      intro r h
      obtain ⟨x,hmem,rfl⟩ := List.mem_map.mp h
      have hn := hx x hmem
      intro l hm
      simp only [clauseRow,List.mem_cons,List.not_mem_nil,or_false] at hm
      rcases hm with rfl | rfl <;> omega
    · refine ⟨?_,?_,?_,trivial⟩
      · intro l hm
        simp only [gateRow,pos,neg,Bool.false_eq_true,ite_false] at hm
        rcases List.mem_append.mp hm with hm | hm
        · rcases List.mem_append.mp hm with hm | hm
          · exact hx l hm
          · simp only [List.mem_cons,List.not_mem_nil,or_false] at hm; subst l; omega
        · simp only [List.mem_cons,List.not_mem_nil,or_false] at hm; subst l; omega
      · nz_lits
      · nz_lits
  · intro α
    rw [List.map_append,List.sum_append,branch_root_sum α B xs hx]
    simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      gateRow,clauseRow,pos,neg,Bool.false_eq_true,ite_false,lsum_append,lsum_cons,lsum_nil]
    have hn := lv_neg_lit α (A:Int) (by omega)
    have hl := lv_neg_lit α (last:Int) (by omega)
    have hb := (lv_bounds α (B:Int)).1
    rw [show ((xs.length+1:Nat):Int)=(xs.length:Int)+1 by omega]
    simp only [Int.neg_mul,Int.add_mul,Int.one_mul,Int.add_zero]
    omega

#print axioms branch_merge_chain
end L3

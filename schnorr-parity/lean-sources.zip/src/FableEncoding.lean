import L3PortsSwap
import OriginalEncoding

set_option linter.unusedSimpArgs false
namespace L3Emitter.FableEncoding
open FamilyNamespace FamilyRows InputSwap OriginalEncoding

abbrev fam (k s : Nat) : L3.Fam := L3.parityFam k s

@[simp] theorem selectors_eq (k s : Nat) : (fam k s).S = selectors k s := rfl
@[simp] theorem variables_eq (k s : Nat) : (fam k s).V = variableCount k s := rfl
@[simp] theorem sel_eq (k s t p j : Nat) : (fam k s).sel t p j = encode k s (.sel t p j) := rfl
@[simp] theorem fn_eq (k s t ab : Nat) : (fam k s).fn t ab = encode k s (.fn t ab) := rfl
@[simp] theorem port_eq (k s t p x : Nat) : (fam k s).port t p x = encode k s (.port t p x) := rfl
@[simp] theorem val_eq (k s t x : Nat) : (fam k s).val t x = encode k s (.val t x) := rfl

 theorem bit_eq (k s j x : Nat) (hj : j<k) :
    (fam k s).inputBit j x = bit k x j := by
  simp only [L3.Fam.inputBit, fam, L3.parityFam, bit, BitVec.getMsbD_eq_getLsbD,
    BitVec.getLsbD_ofNat]
  simp [hj, show k-1-j<k by omega]

 theorem popLow_eq (k x : Nat) :
    L3.popLow k x = (TruthTranspose.weight (BitVec.ofNat k x) : Int) := by
  have h (n : Nat) (hn : n≤k) : L3.popLow n x =
      ((∑ i ∈ Finset.range n, ((BitVec.ofNat k x).getLsbD i).toNat : Nat) : Int) := by
    induction n with
    | zero => simp [L3.popLow, L3.sumR]
    | succ n ih =>
      have he : L3.popLow (n+1) x = L3.popLow n x + (if x.testBit n then 1 else 0) := by
        exact L3.sumR_succ n _
      rw [he, ih (by omega), Finset.sum_range_succ]
      simp only [Nat.cast_add, BitVec.getLsbD_ofNat, show n<k from by omega, decide_true, Bool.true_and]
      cases x.testBit n <;> simp
  unfold TruthTranspose.weight
  rw [Fin.sum_univ_eq_sum_range (fun i => ((BitVec.ofNat k x).getLsbD i).toNat) k]
  exact h k (Nat.le_refl _)

 theorem parity_eq (k x : Nat) (hx : x<truthRows k) : L3.parityBit x = parity k x := by
  rw [L3.parityBit_eq_popLow k x hx, popLow_eq]
  unfold parity
  congr 1
  norm_cast

 theorem pos_lit (k s : Nat) (w : Wire) : L3.pos (encode k s w) = lit k s (w,true) := rfl
 theorem neg_lit (k s : Nat) (w : Wire) : L3.neg (encode k s w) = lit k s (w,false) := rfl

 theorem selectors_block (k s : Nat) (hk : 0<k) :
    ((fam k s).block1.map L3.Row.toE) = (selectorsBlock k s).map (Spec.row k s) := by
  simp only [L3.Fam.block1, fam, L3.parityFam, selectorsBlock, loop,
    List.map_flatMap]
  apply congrArg (List.flatMap · (List.range s))
  funext t
  apply congrArg (List.flatMap · (List.range 2))
  funext p
  simp only [List.map_cons, List.map_nil]
  congr 1
  · simp [L3.Row.toE, Spec.row, oneHot, lit, L3.pos, L3.Fam.sel, encode, selectorStart, List.map_map, Function.comp_def]
  · simp [L3.Row.toE, Spec.row, oneHot, lit, L3.neg, L3.Fam.sel, encode, selectorStart, List.map_map, Function.comp_def,
      Nat.cast_sub (show 1≤k+t by omega)]

 theorem forbidden_block (k s : Nat) :
    ((fam k s).block2.map L3.Row.toE) = (forbiddenBlock s).map (Spec.row k s) := by
  simp only [L3.Fam.block2, fam, L3.parityFam, forbiddenBlock, loop, List.map_flatMap,
    List.map_map, Function.comp_def]
  congr 1

theorem flatMap_congr_on {α β : Type} (xs : List α) (f g : α → List β)
    (h : ∀ x ∈ xs, f x=g x) : xs.flatMap f=xs.flatMap g := by
  induction xs with
  | nil => rfl
  | cons a xs ih => simp only [List.flatMap_cons]; rw [h a (by simp), ih (by intro x hx; exact h x (by simp [hx]))]

theorem input_rows (k s t p j : Nat) (hj : j<k) :
    ((fam k s).inputRows t p j).map L3.Row.toE =
    (loop (truthRows k) fun x => [inputTransfer k t p j x]).map (Spec.row k s) := by
  simp only [L3.Fam.inputRows, L3.Fam.T, fam, L3.parityFam, loop, truthRows,
    List.map_map, List.flatMap_cons, List.flatMap_nil, ← List.map_eq_flatMap]
  apply List.map_congr_left
  intro x _
  have hb := bit_eq k s j x hj
  change (fam k s).inputBit j x = bit k x j at hb
  dsimp only [Function.comp_def]
  simp only [L3.Row.toE, Spec.row, inputTransfer, List.map_cons, List.map_nil]
  simp only [lit]
  rw [←hb]
  rfl

theorem gate_rows (k s t p g : Nat) :
    ((fam k s).gateRows t p g).map L3.Row.toE =
    (loop (truthRows k) fun x => [gateTransfer k t p g x true,gateTransfer k t p g x false]).map (Spec.row k s) := by
  simp only [L3.Fam.gateRows, L3.Fam.T, fam, L3.parityFam, loop, truthRows, List.map_flatMap]
  congr 1

theorem transfers_block (k s : Nat) :
    ((fam k s).block3.map L3.Row.toE) = (transfersBlock k s).map (Spec.row k s) := by
  simp only [L3.Fam.block3, transfersBlock, loop, List.map_flatMap, List.map_append,
    show (fam k s).k=k from rfl, show (fam k s).s=s from rfl]
  apply flatMap_congr_on
  intro t _
  apply flatMap_congr_on
  intro p _
  congr 1
  · apply flatMap_congr_on
    intro j hj
    simpa only [loop, List.map_flatMap] using input_rows k s t p j (List.mem_range.mp hj)
  · apply flatMap_congr_on
    intro g _
    simpa only [loop, List.map_flatMap] using gate_rows k s t p g

theorem semantics_block (k s : Nat) :
    ((fam k s).block4.map L3.Row.toE) = (semanticsBlock k s).map (Spec.row k s) := by
  simp only [L3.Fam.block4, semanticsBlock, loop, L3.Fam.T,
    fam, L3.parityFam, truthRows, List.map_flatMap]
  apply flatMap_congr_on
  intro t _
  apply flatMap_congr_on
  intro x _
  simp [List.range_succ, L3.Row.toE, Spec.row, semantics, lit, L3.pos, L3.neg,
    L3.Fam.port, L3.Fam.val, L3.Fam.fn, L3.Fam.S, L3.Fam.T, encode, selectors, truthRows]

theorem outputs_block (k s : Nat) :
    ((fam k s).block5.map L3.Row.toE) = (outputsBlock k s).map (Spec.row k s) := by
  simp only [L3.Fam.block5, outputsBlock, loop, ← List.map_eq_flatMap, List.map_map,
    show (fam k s).T=truthRows k from rfl]
  apply List.map_congr_left
  intro x hx
  have hp := parity_eq k x (List.mem_range.mp hx)
  dsimp only [Function.comp_def]
  simp only [L3.Row.toE, Spec.row, outputRow, List.map_cons, List.map_nil]
  change EREF.normalize [(1,if L3.parityBit x then L3.pos ((fam k s).val (s-1) x)
    else L3.neg ((fam k s).val (s-1) x))] 1 = _
  rw [hp]
  cases parity k x <;> rfl

/-- Exact ordered normalized database equality, not just model equivalence. -/
theorem original_rows (k s : Nat) (hk : 0<k) :
    (fam k s).rows.map L3.Row.toE = OriginalEncoding.rows k s := by
  simp only [L3.Fam.rows, OriginalEncoding.rows, specs, List.map_append]
  rw [selectors_block k s hk, forbidden_block, transfers_block, semantics_block, outputs_block]

/-- Fable's exact original row count now applies to the v5 database. -/
theorem row_count (k s : Nat) (hk : 0<k) :
    (OriginalEncoding.rows k s).length = (2*s*(k+s+3)+1)*2^k+6*s := by
  rw [← original_rows k s hk, List.length_map, L3.Fam.length_rows]
  rfl

/-- Transfer the independently checked full prefix onto the v5 original rows. -/
theorem fable_prefix_on_v5 (k : Nat) (hk : 3≤k) :
    EREF.GeneralRED.CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (fam k (3*k-4)).db5 := by
  rw [← original_rows k (3*k-4) (by omega)]
  exact L3.parity_frontend_prefix_trace k hk

#print axioms original_rows
#print axioms row_count
#print axioms fable_prefix_on_v5
end L3Emitter.FableEncoding

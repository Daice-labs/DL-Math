import NumericActualCeiling
namespace L3Emitter.NumericActivationImages
open EREF EREF.GeneralRED AliasNetwork NumericNetwork ByteOperandBounds

theorem wire (n:Nat) (hn:2≤n) (w:FamilyNamespace.Wire):
    BitBound (NumericFinalConstruction.bound n) (FinalLowerImage.wire n hn w):=by
  have hpos:1≤NumericFinalConstruction.bound n:=by
    have h:0<NumericValueClosed.bound n:=by unfold NumericValueClosed.bound;positivity
    have h':=NumericFinalSelectors.value_le n
    omega
  have hf:BitBound (NumericFinalConstruction.bound n) SelectedCoordinateBank.fallback:=hpos
  have hl:=NumericLowerWire.wire n hn w
  have hl':BitBound (NumericFinalConstruction.bound n) (LowerTransferImage.wire n hn w):=
    hl.trans (NumericFinalSelectors.lower_le n)
  have hb:=(NumericFinalConstruction.built n hn).1
  cases w with
  | sel t p j=>
    simp only [FinalLowerImage.wire]
    split
    · split
      · split
        · exact hb.2.1 _ _
        · exact hf
      · exact hf
    · exact hl'
  | port t p x=>
    simp only [FinalLowerImage.wire]
    split
    · split
      · split
        · exact hb.2.2.1 _ _
        · exact hf
      · exact hf
    · exact hl'
  | fn t ab=>
    simp only [FinalLowerImage.wire]
    split
    · split
      · exact hb.2.2.2 _
      · exact hf
    · exact hl'
  | val t x=>
    simp only [FinalLowerImage.wire]
    split
    · exact NumericLowerComplete.final_value n hn x
    · exact hl'

theorem lookup (M k s v:Nat) (f:FamilyNamespace.Wire→Bit) (ws:List FamilyNamespace.Wire)
    (hM:1≤M) (hf:∀w∈ws,BitBound M (f w)):
    BitBound M (LowerActivationImage.lookup k s f v ws):=by
  induction ws with
  | nil=>exact hM
  | cons w ws ih=>simp only [LowerActivationImage.lookup];split
                  · exact hf w (by simp)
                  · exact ih (fun w hw=>hf w (by simp [hw]))

theorem image (n:Nat) (hn:2≤n) (v:Nat):
    BitBound (NumericFinalConstruction.bound n) (LowerActivationImage.image n hn v):=by
  apply lookup
  · have h:0<NumericValueClosed.bound n:=by unfold NumericValueClosed.bound;positivity
    have h':=NumericFinalSelectors.value_le n
    omega
  · intro w _;exact wire n hn w

theorem image_data (M:Nat) (b:Bit) (h:BitBound M b):
    match RecordedActivationWitness.imageData b with
    | .bit _=>True
    | .lit l=>l.varId≤M:=by
  exact h

theorem entries (K M L N:Nat) (f:Nat→Bit) (hq:M+N+1≤K) (hL:L≤N)
    (hf:∀v,BitBound K (f v)):
    WitnessBound K (RecordedActivationWitness.entries M L N f):=by
  intro e he
  rcases List.mem_cons.mp he with rfl|he
  · exact ⟨hq,trivial⟩
  · obtain ⟨v,hv,rfl⟩:=List.mem_map.mp he
    have hv':=(RecordedActivationWitness.mem_keys M L v).mp hv
    exact ⟨by omega,image_data K _ (hf _)⟩

#print axioms wire
#print axioms image
#print axioms entries
end L3Emitter.NumericActivationImages

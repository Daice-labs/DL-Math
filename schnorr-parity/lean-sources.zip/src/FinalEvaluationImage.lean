import FinalEvaluationBank
namespace L3Emitter.FinalEvaluationImage
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions FinalEvaluationContext
open FinalKeptEvaluation (port)
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def literals (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):List Int:=
  [-sign a (port n hn x 0),-sign b (port n hn x 1),sign w (FinalLowerImage.finalValue n hn x.val),-sign w (FinalU2Bank.q n hn a b)]
def row (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):Row:=clause (literals n hn x a b w)
def source (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):List Int:=
  if w=InputSwap.parity n x.val then [(PrimaryAliasBank.cfg n hn).T.val] else FinalEvaluationJoin.literals n hn x a b
def extra (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):List Int:=
  if w=InputSwap.parity n x.val then [-sign a (port n hn x 0),-sign b (port n hn x 1),-sign w (FinalU2Bank.q n hn a b)]
  else [sign w (FinalLowerImage.finalValue n hn x.val)]
theorem valid_source (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):Valid (source n hn x a b w):=by
  unfold source;split
  · simp [Valid,(PrimaryAliasBank.cfg n hn).T.property]
  · exact FinalEvaluationJoin.literal_valid n hn x a b
theorem valid_extra (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):Valid (extra n hn x a b w):=by
  unfold extra;split <;> simp [Valid,sign_valid]
theorem weakened (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):
    clause (source n hn x a b w++extra n hn x a b w)=row n hn x a b w:=by
  apply GateUnaryCompositionPOL.clause_value_eq _ _ (EvaluationCaseSeeds.valid_join (valid_source n hn x a b w) (valid_extra n hn x a b w))
    (by simp [literals,Valid,sign_valid])
  intro α
  cases hp:InputSwap.parity n x.val <;> cases w <;>
    simp only [source,extra,hp,↓reduceIte,Bool.false_eq_true,Bool.true_eq_false,FinalEvaluationJoin.literals,literals,
      qlit,FinalLowerImage.finalValue,PrimaryAliasBank.false_bit,neg,sign,neg_neg,sum_append,sum_cons,sum_nil] <;> ring

theorem source_present (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):
    clause (source n hn x a b w)∈FinalEvaluationBank.result n hn:=by
  unfold source;split
  · apply List.mem_append_left
    exact definitions_kept n hn _ (FinalLowerImage.true_present n hn)
  · exact FinalEvaluationBank.contains n hn x a b

def tape (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool) (E:List Row):=
  ChoiceProjection.weakenTokens E (source n hn x a b w) (extra n hn x a b w)
theorem leaf_check (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool) (E:List Row) (he:∀R∈FinalEvaluationBank.result n hn,R∈E):
    polEval (dbOf E) (tape n hn x a b w E) []=some (row n hn x a b w):=by
  have h:=ChoiceProjection.weaken_succeeds E _ _ (valid_source n hn x a b w) (valid_extra n hn x a b w) (he _ (source_present n hn x a b w))
  rw [weakened] at h;exact h
abbrev Job (n:Nat):=Fin (T n)×Bool×Bool×Bool
def jobs (n:Nat):List (Job n):=(List.finRange (T n)).flatMap fun x=>[false,true].flatMap fun a=>[false,true].flatMap fun b=>[false,true].map fun w=>(x,a,b,w)
def program (n:Nat) (hn:2≤n):Program:=(jobs n).map fun j=>(row n hn j.1 j.2.1 j.2.2.1 j.2.2.2,tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2 (FinalEvaluationBank.result n hn))
def result (n:Nat) (hn:2≤n):=FinalEvaluationBank.result n hn++(jobs n).map fun j=>row n hn j.1 j.2.1 j.2.2.1 j.2.2.2
theorem checks (n:Nat) (hn:2≤n):check (FinalEvaluationBank.result n hn) (program n hn)=some (result n hn):=by
  have h:=IndependentProgram.check_base (FinalEvaluationBank.result n hn) (program n hn) (by
    intro c hc;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc;exact leaf_check n hn _ _ _ _ _ (fun _ h=>h))
  simpa only [program,result,outputs,List.map_map,Function.comp_def] using h
theorem original_to_final_evaluation_rows (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalEvaluationBank.original_to_replacement_evaluation n hn) (check_trace _ _ _ (checks n hn))
theorem contains (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):row n hn x a b w∈result n hn:=
  List.mem_append_right _ (List.mem_map.mpr ⟨(x,a,b,w),by cases a <;> cases b <;> cases w <;> simp [jobs],rfl⟩)
theorem image_eq (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b w:Bool):
    FinalLowerImage.image n hn (InputSwap.semantics (lastRank n) x.val a b (!w))=row n hn x a b w:=by
  have hc:(if a then 2 else 0)+(if b then 1 else 0)<4:=by cases a <;> cases b <;> decide
  simp only [FinalLowerImage.image,InputSwap.semantics,List.map_cons,List.map_nil,FinalLowerImage.wire,
    ↓reduceIte,dif_pos (show 0<2 by decide),dif_pos (show 1<2 by decide),dif_pos x.isLt,
    LowerPortEvaluation.sign_not,Bool.not_not,row,literals,FinalKeptEvaluation.port,FinalU2Bank.q,FinalFunctionFullLinks.q,FinalU2Bank.code,RankTableBank.code,clause]
  cases a <;> cases b <;> rfl

theorem definitions_retained (n:Nat) (hn:2≤n):∀R∈FinalOutputDefinitions.result n hn,R∈result n hn:=
  fun R h=>List.mem_append_left _ (List.mem_append_left _ (definitions_kept n hn R h))
theorem all_semantics_images (n:Nat) (hn:2≤n) (r:FamilyRows.Spec) (hr:r∈OriginalEncoding.semanticsBlock n (3*n-4)):
    FinalLowerImage.image n hn r∈result n hn:=by
  obtain ⟨t,x,a,b,c,ht,hx,rfl⟩:=(OriginalEncoding.semantics_mem _ _ r).mp hr
  by_cases he:t=lastRank n
  · subst t
    have h:=contains n hn ⟨x,hx⟩ a b (!c)
    rw [←image_eq] at h
    simpa only [Bool.not_not] using h
  · apply definitions_retained
    exact FinalLowerEarlier.evaluation n hn t x a b c (by unfold lastRank RankConstruction.width at he ⊢;omega) hx
#print axioms original_to_final_evaluation_rows
#print axioms all_semantics_images
end L3Emitter.FinalEvaluationImage

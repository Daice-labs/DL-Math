import FirstValueBank
namespace L3Emitter.FirstGateBase
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram
abbrev Job (n:Nat):=Nat×Fin (AliasAssembly.width (n+1))×Bool×Bool

def jobs (n:Nat):List (Job n):=(List.range (FamilyNamespace.truthRows n)).flatMap fun x=>
  (List.finRange (AliasAssembly.width (n+1))).flatMap fun i=>[false,true].flatMap fun b=>[false,true].map fun v=>(x,i,b,v)
def row (n:Nat) (hn:2≤n) (j:Job n):=ValueBranchRows.row n hn 0 j.1 j.2.1 (SourceCoordinateValue.value n hn j.2.1 j.1) j.2.2.1 j.2.2.2
def program (n:Nat) (hn:2≤n):Program:=(jobs n).map fun j=>
  (row n hn j,FirstBaseLeaves.tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2 (FirstValueBank.result n hn))
def result (n:Nat) (hn:2≤n):=FirstValueBank.result n hn++(jobs n).map (row n hn)

theorem job_mem (n:Nat) (j:Job n):j∈jobs n↔j.1<FamilyNamespace.truthRows n:=by
  obtain ⟨x,i,b,v⟩:=j
  cases b <;> cases v <;> simp [jobs]
theorem checks (n:Nat) (hn:2≤n):check (FirstValueBank.result n hn) (program n hn)=some (result n hn):=by
  have h:=IndependentProgram.check_base (FirstValueBank.result n hn) (program n hn) (by
    intro cmd hc
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    exact FirstBaseLeaves.checks n hn j.1 j.2.1 j.2.2.1 j.2.2.2 _ (FirstValueBank.retained n hn)
      (FirstValueBank.value_row n hn j.1 ((job_mem _ _).mp hj)))
  simpa only [program,result,outputs,List.map_map,Function.comp_def] using h

theorem first_gate_base (n:Nat) (hn:2≤n):ValueInductionBranches.Before n hn 1 (result n hn):=by
  intro g hg x hx i b v
  have he:g=0:=by omega
  subst g
  exact List.mem_append_right _ (List.mem_map.mpr ⟨(x,i,b,v),(job_mem _ _).mpr hx,rfl⟩)
theorem retained (n:Nat) (hn:2≤n):∀R∈SharedValueBank.result n hn,R∈result n hn:=
  fun R h=>List.mem_append_left _ (FirstValueBank.retained n hn R h)
theorem original_to_base (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FirstValueBank.original_to_first_values n hn) (check_trace _ _ _ (checks n hn))

#print axioms first_gate_base
#print axioms original_to_base
end L3Emitter.FirstGateBase

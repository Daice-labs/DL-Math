/-
Structural lemmas about the fold-based frontend builder: commands only grow, the name
maps hold their definitions, and every definition's rows are in the final database.
-/
import L3FrontendX

namespace L3
open EREF EREF.GeneralRED

/-! ### Generic: commands only grow -/

namespace StI
variable {m0 : Nat}

theorem cmds_OR (t : StI m0) (xs : List Int) : (t.OR xs).2.s.cmds = t.s.cmds ++ [.orDef (t.s.var + 1) (t.s.chk xs)] := rfl
theorem cmds_AND (t : StI m0) (xs : List Int) : (t.AND xs).2.s.cmds = t.s.cmds ++ [.andDef (t.s.var + 1) (t.s.chk xs)] := rfl
theorem cmds_EQ (t : StI m0) (hm : 1 ≤ m0) (a b : Int) :
    (t.EQ hm a b).2.s.cmds = t.s.cmds ++ [.eqDef (t.s.var + 1) (t.s.chk1 a) (t.s.chk1 b)] := rfl
theorem cmds_rup (t : StI m0) (c : List Int) : (t.rup c).s.cmds = t.s.cmds ++ [.rup (t.s.chk c)] := rfl
theorem cmds_split (vs : List Int) : ∀ (t : StI m0) (c : List Int), ∃ cs, (t.split c vs).s.cmds = t.s.cmds ++ cs := by
  induction vs with
  | nil => intro t c; exact ⟨_, rfl⟩
  | cons v vs ih =>
    intro t c
    obtain ⟨c1, h1⟩ := ih t (c ++ [v])
    obtain ⟨c2, h2⟩ := ih _ (c ++ [-v])
    refine ⟨c1 ++ c2 ++ [.rup ((((t.split (c ++ [v]) vs).split (c ++ [-v]) vs)).s.chk c)], ?_⟩
    rw [show t.split c (v :: vs) = ((t.split (c ++ [v]) vs).split (c ++ [-v]) vs).rup c from rfl,
      StI.cmds_rup, h2, h1]
    simp

/-- a step function that only appends commands -/
def Grows (f : StI m0 → StI m0) : Prop := ∀ t, ∃ cs, (f t).s.cmds = t.s.cmds ++ cs

theorem grows_foldl {α : Type} (l : List α) (f : StI m0 → α → StI m0) (hf : ∀ x, Grows (fun t => f t x)) :
    ∀ t, ∃ cs, (l.foldl f t).s.cmds = t.s.cmds ++ cs := by
  induction l with
  | nil => intro t; exact ⟨[], by simp⟩
  | cons x l ih =>
    intro t
    obtain ⟨c1, h1⟩ := hf x t
    obtain ⟨c2, h2⟩ := ih (f t x)
    exact ⟨c1 ++ c2, by simp [List.foldl_cons, h2, h1]⟩

theorem mem_of_grows {t t' : StI m0} (h : ∃ cs, t'.s.cmds = t.s.cmds ++ cs) {c : Cmd} (hc : c ∈ t.s.cmds) :
    c ∈ t'.s.cmds := by
  obtain ⟨cs, h⟩ := h; rw [h]; exact List.mem_append_left _ hc

end StI

/-- rows of a command in the list are in the executed database -/
theorem mem_exec_of_cmd (D : List EREF.Row) (cs : List Cmd) (c : Cmd) (hc : c ∈ cs) (R : EREF.Row) (hR : R ∈ c.rows) :
    R ∈ exec D cs := by
  induction cs generalizing D with
  | nil => simp at hc
  | cons c' cs ih =>
    rcases List.mem_cons.mp hc with rfl | hc
    · simp only [exec]
      have : R ∈ D ++ c.rows := List.mem_append_right _ hR
      -- exec only appends
      have mono : ∀ (D : List EREF.Row) (cs : List Cmd) (R : EREF.Row), R ∈ D → R ∈ exec D cs := by
        intro D cs; induction cs generalizing D with
        | nil => intro R h; exact h
        | cons c cs ih => intro R h; exact ih _ R (List.mem_append_left _ h)
      exact mono _ _ _ this
    · exact ih _ hc

theorem exec_mono (D : List EREF.Row) (cs : List Cmd) (R : EREF.Row) (h : R ∈ D) : R ∈ exec D cs := by
  induction cs generalizing D with
  | nil => exact h
  | cons c cs ih => exact ih _ (List.mem_append_left _ h)

/-- the database of a rup obligation extends the database at the start of its command list -/
theorem obls_db_ext (D : List EREF.Row) (cs : List Cmd) :
    ∀ o ∈ obls D cs, ∃ ext, o.1 = D ++ ext := by
  induction cs generalizing D with
  | nil => intro o ho; simp [obls] at ho
  | cons c cs ih =>
    intro o ho
    cases c with
    | rup c =>
      simp only [obls, List.mem_cons] at ho
      rcases ho with rfl | ho
      · exact ⟨[], by simp⟩
      · obtain ⟨ext, h⟩ := ih _ o ho; exact ⟨(clauseRow c).toE :: ext, by rw [h]; simp⟩
    | orDef q xs => obtain ⟨ext, h⟩ := ih _ o ho; exact ⟨(Cmd.orDef q xs).rows ++ ext, by rw [h]; simp⟩
    | andDef q xs => obtain ⟨ext, h⟩ := ih _ o ho; exact ⟨(Cmd.andDef q xs).rows ++ ext, by rw [h]; simp⟩
    | eqDef q a b => obtain ⟨ext, h⟩ := ih _ o ho; exact ⟨(Cmd.eqDef q a b).rows ++ ext, by rw [h]; simp⟩

/-- every rup obligation has, as its clause, the literal list of a `.rup` command -/
theorem obls_clause_mem (D : List EREF.Row) (cs : List Cmd) : ∀ o ∈ obls D cs, Cmd.rup o.2 ∈ cs := by
  induction cs generalizing D with
  | nil => intro o ho; simp [obls] at ho
  | cons c cs ih =>
    intro o ho
    cases c with
    | rup c =>
      simp only [obls, List.mem_cons] at ho
      rcases ho with rfl | ho
      · simp
      · exact List.mem_cons_of_mem _ (ih _ o ho)
    | orDef q xs => exact List.mem_cons_of_mem _ (ih _ o ho)
    | andDef q xs => exact List.mem_cons_of_mem _ (ih _ o ho)
    | eqDef q a b => exact List.mem_cons_of_mem _ (ih _ o ho)

namespace Fam
variable (F : Fam)

/-! ### Stage 0 -/

theorem stage0_cmds : F.stage0.s.cmds =
    [.orDef (F.V + 1) [], .rup [-((F.V + 1 : Nat) : Int)], .andDef (F.V + 2) []] := by
  simp [stage0, StI.OR, StI.AND, StI.rup, StI.setLive, St.OR, St.AND, St.rup, St.chk, StI.init, St.init,
    List.filter]
  have h1 : (1 ≤ ((F.V : Int) + 1).natAbs) := by omega
  have h2 : (((F.V : Int) + 1).natAbs ≤ F.V + 1) := by omega
  simp [h1, h2]

theorem stage0_var : F.stage0.s.var = F.V + 2 := by
  simp [stage0, StI.OR, StI.AND, StI.rup, StI.setLive, St.OR, St.AND, St.rup, StI.init, St.init]
theorem stage0_live_last : F.stage0.s.live (F.s - 1) = F.V + 2 := by
  simp [stage0, StI.OR, StI.AND, StI.rup, StI.setLive, St.OR, St.AND, St.rup, StI.init, St.init]

/-! ### Template T1: `rup [¬unused_false]` — the clause is itself a database row -/

end Fam

/-- a clause already in the database is RUP: C + ¬C is contradictory -/
theorem refutation_of_clause_mem (D : List EREF.Row) (C : EREF.Row) (hC : C ∈ D)
    (hD : ∀ R ∈ D, Canonical R) : Refutation (D ++ [negate C]) := by
  have hDc : ∀ R ∈ D ++ [negate C], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  obtain ⟨i, hi⟩ := Fam.dbOf_of_mem D C hC
  have hi' := dbOf_ext_append D [negate C] _ _ hi
  have hn : dbOf (D ++ [negate C]) (D.length + 1) = some (negate C) := dbOf_append_last D (negate C)
  let f : Nat → EREF.Row := fun j => (dbOf (D ++ [negate C]) j).getD ⟨[], 0⟩
  have hf : ∀ j R, dbOf (D ++ [negate C]) j = some R → f j = R := by intro j R h; simp [f, h]
  apply refutation_of_chain _ hDc f i [D.length + 1]
  · rw [hf _ _ hi']; exact hi'
  · intro j hj; simp at hj; subst hj; rw [hf _ _ hn]; exact hn
  · intro α
    rw [hf _ _ hi']
    simp only [List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
    rw [hf _ _ hn, val_negate _ (hD C hC)]
    omega

namespace Fam
variable (F : Fam)

theorem stage0_obls (hk : 1 ≤ F.k) (hs : 1 ≤ F.s) :
    ∀ o ∈ obls F.db5 F.stage0.s.cmds, Refutation (o.1 ++ [negate (clauseRow o.2).toE]) := by
  rw [F.stage0_cmds]
  intro o ho
  simp only [obls, Cmd.rows, orDefs, Defs.rows, List.map_nil, List.nil_append, List.map_cons,
    List.mem_cons, List.not_mem_nil, or_false] at ho
  subst ho
  apply refutation_of_clause_mem
  · -- the clause row is the single row of `unused_false = OR([])`
    simp only [List.mem_append, List.mem_singleton]
    right
    rfl
  · intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact (F.db5_bounded hk hs).canonical R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_toE _

/-! ### Generic fold lemmas -/

end Fam

theorem foldl_pres {α β : Type} (P : β → Prop) (f : β → α → β) (l : List α)
    (hf : ∀ x ∈ l, ∀ b, P b → P (f b x)) : ∀ b, P b → P (l.foldl f b) := by
  induction l with
  | nil => intro b h; exact h
  | cons x l ih => intro b h; exact ih (fun x' hx' => hf x' (by simp [hx'])) _ (hf x (by simp) b h)

theorem foldl_split {α β : Type} (f : β → α → β) (l : List α) (x : α) (hx : x ∈ l) :
    ∃ l1 l2, l = l1 ++ x :: l2 ∧ ∀ b, l.foldl f b = l2.foldl f (f (l1.foldl f b) x) := by
  obtain ⟨l1, l2, rfl⟩ := List.append_of_mem hx
  exact ⟨l1, l2, rfl, fun b => by simp [List.foldl_append, List.foldl_cons]⟩

namespace StI
variable {m0 : Nat}

theorem var_ge (t : StI m0) : m0 ≤ t.s.var := by
  have := varAfter_mono m0 t.s.cmds; rw [t.inv.2] at this; exact this

/-- the counter never decreases along a growth -/
theorem var_le_of_grows {t t' : StI m0} (h : ∃ cs, t'.s.cmds = t.s.cmds ++ cs) : t.s.var ≤ t'.s.var := by
  obtain ⟨cs, h⟩ := h
  have h1 := t.inv.2; have h2 := t'.inv.2
  rw [h, varAfter_append, h1] at h2
  rw [← h2]; exact varAfter_mono _ _

theorem var_OR (t : StI m0) (xs : List Int) : (t.OR xs).2.s.var = t.s.var + 1 := rfl
theorem var_AND (t : StI m0) (xs : List Int) : (t.AND xs).2.s.var = t.s.var + 1 := rfl
theorem var_EQ (t : StI m0) (hm : 1 ≤ m0) (a b : Int) : (t.EQ hm a b).2.s.var = t.s.var + 1 := rfl
theorem fst_OR (t : StI m0) (xs : List Int) : (t.OR xs).1 = t.s.var + 1 := rfl
theorem fst_AND (t : StI m0) (xs : List Int) : (t.AND xs).1 = t.s.var + 1 := rfl
theorem fst_EQ (t : StI m0) (hm : 1 ≤ m0) (a b : Int) : (t.EQ hm a b).1 = t.s.var + 1 := rfl

theorem chk1_eq (t : StI m0) (a : Int) (h : 1 ≤ a.natAbs ∧ a.natAbs ≤ t.s.var) : t.s.chk1 a = a := by
  unfold St.chk1; simp [h]

theorem chk_eq (t : StI m0) (xs : List Int) (h : ∀ l ∈ xs, 1 ≤ l.natAbs ∧ l.natAbs ≤ t.s.var) : t.s.chk xs = xs := by
  unfold St.chk
  apply List.filter_eq_self.mpr
  intro l hl; simpa using h l hl

/-- growth facts for the primitive operations -/
def GrowsTo (t t' : StI m0) : Prop := ∃ cs, t'.s.cmds = t.s.cmds ++ cs
theorem growsTo_refl (t : StI m0) : GrowsTo t t := ⟨[], by simp⟩
theorem growsTo_trans {a b c : StI m0} (h1 : GrowsTo a b) (h2 : GrowsTo b c) : GrowsTo a c := by
  obtain ⟨c1, h1⟩ := h1; obtain ⟨c2, h2⟩ := h2
  exact ⟨c1 ++ c2, by rw [h2, h1, List.append_assoc]⟩
theorem growsTo_OR (t : StI m0) (xs : List Int) : GrowsTo t (t.OR xs).2 := ⟨_, rfl⟩
theorem growsTo_AND (t : StI m0) (xs : List Int) : GrowsTo t (t.AND xs).2 := ⟨_, rfl⟩
theorem growsTo_EQ (t : StI m0) (hm : 1 ≤ m0) (a b : Int) : GrowsTo t (t.EQ hm a b).2 := ⟨_, rfl⟩
theorem growsTo_rup (t : StI m0) (c : List Int) : GrowsTo t (t.rup c) := ⟨_, rfl⟩
theorem growsTo_split (t : StI m0) (c vs : List Int) : GrowsTo t (t.split c vs) := cmds_split vs t c
theorem growsTo_setLive (t : StI m0) (f) : GrowsTo t (t.setLive f) := growsTo_refl t
theorem growsTo_setEdges (t : StI m0) (f) : GrowsTo t (t.setEdges f) := growsTo_refl t
theorem growsTo_setEqrow (t : StI m0) (f) : GrowsTo t (t.setEqrow f) := growsTo_refl t
theorem growsTo_setForce (t : StI m0) (f) : GrowsTo t (t.setForce f) := growsTo_refl t
theorem growsTo_setP0force (t : StI m0) (f) : GrowsTo t (t.setP0force f) := growsTo_refl t
theorem growsTo_setEligible (t : StI m0) (f) : GrowsTo t (t.setEligible f) := growsTo_refl t
theorem growsTo_setVeq (t : StI m0) (f) : GrowsTo t (t.setVeq f) := growsTo_refl t
theorem growsTo_setBranches (t : StI m0) (f) : GrowsTo t (t.setBranches f) := growsTo_refl t
theorem growsTo_setA (t : StI m0) (a) : GrowsTo t (t.setA a) := growsTo_refl t
theorem growsTo_setB (t : StI m0) (b) : GrowsTo t (t.setB b) := growsTo_refl t

/-- eqrow is untouched by every primitive except setEqrow -/
theorem eqrow_OR (t : StI m0) (xs) : (t.OR xs).2.s.eqrow = t.s.eqrow := rfl
theorem eqrow_AND (t : StI m0) (xs) : (t.AND xs).2.s.eqrow = t.s.eqrow := rfl
theorem eqrow_EQ (t : StI m0) (hm : 1 ≤ m0) (a b) : (t.EQ hm a b).2.s.eqrow = t.s.eqrow := rfl
theorem eqrow_rup (t : StI m0) (c) : (t.rup c).s.eqrow = t.s.eqrow := rfl
theorem eqrow_split (vs : List Int) : ∀ (t : StI m0) (c), (t.split c vs).s.eqrow = t.s.eqrow := by
  induction vs with
  | nil => intro t c; rfl
  | cons v vs ih => intro t c; show ((t.split (c ++ [v]) vs).split (c ++ [-v]) vs).s.eqrow = _; rw [ih, ih]
theorem eqrow_setForce (t : StI m0) (f) : (t.setForce f).s.eqrow = t.s.eqrow := rfl
theorem eqrow_setP0force (t : StI m0) (f) : (t.setP0force f).s.eqrow = t.s.eqrow := rfl
theorem eqrow_setEligible (t : StI m0) (f) : (t.setEligible f).s.eqrow = t.s.eqrow := rfl
theorem eqrow_setLive (t : StI m0) (f) : (t.setLive f).s.eqrow = t.s.eqrow := rfl
theorem eqrow_setEdges (t : StI m0) (f) : (t.setEdges f).s.eqrow = t.s.eqrow := rfl
theorem eqrow_setVeq (t : StI m0) (f) : (t.setVeq f).s.eqrow = t.s.eqrow := rfl
theorem eqrow_setBranches (t : StI m0) (f) : (t.setBranches f).s.eqrow = t.s.eqrow := rfl
theorem eqrow_setA (t : StI m0) (a) : (t.setA a).s.eqrow = t.s.eqrow := rfl
theorem eqrow_setB (t : StI m0) (b) : (t.setB b).s.eqrow = t.s.eqrow := rfl

end StI

namespace Fam
variable (F : Fam)

/-! ### Stage 2: the eqrow and force definitions survive to the end -/

/-- the eqrow definition of (g, port, b) is recorded and bounded -/
def PEq (g port b : Nat) (t : StI F.V) : Prop :=
  Cmd.eqDef (t.s.eqrow g port b) (F.fn g (eqPair port b).1 : Int) (F.fn g (eqPair port b).2 : Int) ∈ t.s.cmds ∧
  F.V < t.s.eqrow g port b ∧ t.s.eqrow g port b ≤ t.s.var

/-- the force definition of (g, port) is recorded and bounded -/
def PForce (g port : Nat) (t : StI F.V) : Prop :=
  Cmd.orDef (t.s.force g port) [(t.s.eqrow g port 0 : Int), (t.s.eqrow g port 1 : Int)] ∈ t.s.cmds ∧
  F.V < t.s.force g port ∧ t.s.force g port ≤ t.s.var

theorem PEq_of_grows {g port b : Nat} {t t' : StI F.V} (hg : ∃ cs, t'.s.cmds = t.s.cmds ++ cs)
    (he : t'.s.eqrow g port b = t.s.eqrow g port b) (h : F.PEq g port b t) : F.PEq g port b t' := by
  obtain ⟨h1, h2, h3⟩ := h
  refine ⟨?_, ?_, ?_⟩
  · rw [he]; exact StI.mem_of_grows hg h1
  · rw [he]; exact h2
  · rw [he]; exact Nat.le_trans h3 (StI.var_le_of_grows hg)

theorem PForce_of_grows {g port : Nat} {t t' : StI F.V} (hg : ∃ cs, t'.s.cmds = t.s.cmds ++ cs)
    (he : ∀ b, t'.s.eqrow g port b = t.s.eqrow g port b) (hf : t'.s.force g port = t.s.force g port)
    (h : F.PForce g port t) : F.PForce g port t' := by
  obtain ⟨h1, h2, h3⟩ := h
  refine ⟨?_, ?_, ?_⟩
  · rw [hf, he 0, he 1]; exact StI.mem_of_grows hg h1
  · rw [hf]; exact h2
  · rw [hf]; exact Nat.le_trans h3 (StI.var_le_of_grows hg)

/-- one eqStep for a different key preserves PEq (g,port,b) and leaves eqrow (g,port,b) alone -/
theorem eqStep_eqrow_other (hm : 1 ≤ F.V) (g port : Nat) (acc : StI F.V × List Int) (b' : Nat) (g0 p0 b0 : Nat)
    (hne : ¬ (g0 = g ∧ p0 = port ∧ b0 = b')) :
    (F.eqStep hm g port acc b').1.s.eqrow g0 p0 b0 = acc.1.s.eqrow g0 p0 b0 := by
  obtain ⟨t, eqs⟩ := acc
  simp [eqStep, StI.setEqrow, StI.EQ, St.EQ, hne]

theorem eqStep_grows (hm : 1 ≤ F.V) (g port : Nat) (acc : StI F.V × List Int) (b' : Nat) :
    ∃ cs, (F.eqStep hm g port acc b').1.s.cmds = acc.1.s.cmds ++ cs := by
  obtain ⟨t, eqs⟩ := acc
  exact ⟨_, rfl⟩

/-- the eqStep for (g, port, b) establishes PEq (g, port, b) -/
theorem eqPair_lt (port b : Nat) (hb : b < 2) : (eqPair port b).1 < 4 ∧ (eqPair port b).2 < 4 := by
  unfold eqPair; split <;> simp <;> omega

theorem eqStep_establishes (hm : 1 ≤ F.V) (g port b : Nat) (hg : g < F.s) (hb : b < 2) (acc : StI F.V × List Int) :
    F.PEq g port b (F.eqStep hm g port acc b).1 := by
  obtain ⟨t, eqs⟩ := acc
  have hV := t.var_ge
  have ha := F.fn_range g (eqPair port b).1 hg (eqPair_lt port b hb).1
  have hd := F.fn_range g (eqPair port b).2 hg (eqPair_lt port b hb).2
  have hS := F.S4_le_V
  refine ⟨?_, ?_, ?_⟩
  · simp only [eqStep, StI.setEqrow, StI.EQ, St.EQ, StI.cmds_EQ]
    simp only [and_self, ↓reduceIte]
    rw [StI.chk1_eq t _ (by simp; omega), StI.chk1_eq t _ (by simp; omega)]
    simp
  · simp [eqStep, StI.setEqrow, StI.EQ, St.EQ]; omega
  · simp [eqStep, StI.setEqrow, StI.EQ, St.EQ]

/-! ### PEq is preserved by every later step and established in stage 2 -/

/-- an (StI × List Int) accumulator step that only grows cmds and keeps eqrow (g,port,b) -/
theorem PEq_pres_pair {g port b : Nat} (f : StI F.V × List Int → Nat → StI F.V × List Int) (l : List Nat)
    (hgrow : ∀ x ∈ l, ∀ acc, ∃ cs, (f acc x).1.s.cmds = acc.1.s.cmds ++ cs)
    (heq : ∀ x ∈ l, ∀ acc, (f acc x).1.s.eqrow g port b = acc.1.s.eqrow g port b) :
    ∀ acc, F.PEq g port b acc.1 → F.PEq g port b (l.foldl f acc).1 :=
  foldl_pres (fun acc => F.PEq g port b acc.1) f l
    (fun x hx acc h => F.PEq_of_grows (hgrow x hx acc) (heq x hx acc) h)

theorem portStep_eqrow (hm : 1 ≤ F.V) (g' : Nat) (acc : StI F.V × List Int) (port' : Nat)
    (g port b : Nat) (hne : ¬ (g' = g ∧ port' = port)) :
    (F.portStep hm g' acc port').1.s.eqrow g port b = acc.1.s.eqrow g port b := by
  obtain ⟨t, ports⟩ := acc
  simp only [portStep, StI.setP0force, StI.AND, StI.setForce, StI.OR, St.AND, St.OR]
  -- the inner eq fold keeps the entry
  have : ∀ (acc : StI F.V × List Int), ([0, 1].foldl (F.eqStep hm g' port') acc).1.s.eqrow g port b
      = acc.1.s.eqrow g port b := by
    intro acc
    simp only [List.foldl_cons, List.foldl_nil]
    rw [F.eqStep_eqrow_other hm g' port' _ 1 g port b (by omega),
      F.eqStep_eqrow_other hm g' port' _ 0 g port b (by omega)]
  exact this (t, [])

theorem portStep_grows (hm : 1 ≤ F.V) (g' : Nat) (acc : StI F.V × List Int) (port' : Nat) :
    ∃ cs, (F.portStep hm g' acc port').1.s.cmds = acc.1.s.cmds ++ cs := by
  obtain ⟨t, ports⟩ := acc
  simp only [portStep, StI.setP0force, StI.AND, StI.setForce, StI.OR, St.AND, St.OR, List.foldl_cons,
    List.foldl_nil]
  obtain ⟨c1, h1⟩ := F.eqStep_grows hm g' port' (t, []) 0
  obtain ⟨c2, h2⟩ := F.eqStep_grows hm g' port' (F.eqStep hm g' port' (t, []) 0) 1
  rw [h2, h1]; simp only [List.append_assoc]; exact ⟨_, rfl⟩

theorem eligStep_eqrow (hm : 1 ≤ F.V) (t : StI F.V) (g' : Nat) (g port b : Nat) (hne : g' ≠ g) :
    (F.eligStep hm t g').s.eqrow g port b = t.s.eqrow g port b := by
  simp only [eligStep, StI.setEligible, StI.AND, StI.OR, St.AND, St.OR, List.foldl_cons, List.foldl_nil]
  rw [F.portStep_eqrow hm g' _ 1 g port b (by omega), F.portStep_eqrow hm g' _ 0 g port b (by omega)]

theorem eligStep_grows (hm : 1 ≤ F.V) (t : StI F.V) (g' : Nat) :
    ∃ cs, (F.eligStep hm t g').s.cmds = t.s.cmds ++ cs := by
  simp only [eligStep, StI.setEligible, StI.AND, StI.OR, St.AND, St.OR, List.foldl_cons, List.foldl_nil]
  obtain ⟨c1, h1⟩ := F.portStep_grows hm g' (t, []) 0
  obtain ⟨c2, h2⟩ := F.portStep_grows hm g' (F.portStep hm g' (t, []) 0) 1
  rw [h2, h1]; simp only [List.append_assoc]; exact ⟨_, rfl⟩

/-- the port fold of gate g establishes PEq (g, port, b) for its own port -/
theorem portStep_establishes (hm : 1 ≤ F.V) (g port b : Nat) (hg : g < F.s) (hb : b < 2)
    (acc : StI F.V × List Int) : F.PEq g port b (F.portStep hm g acc port).1 := by
  obtain ⟨t, ports⟩ := acc
  -- after the eq fold the entry is established; the OR/AND/set steps keep it
  have hfold : F.PEq g port b (F.eqStep hm g port (F.eqStep hm g port (t, []) 0) 1).1 := by
    have hb' : b = 0 ∨ b = 1 := by omega
    rcases hb' with rfl | rfl
    · exact F.PEq_of_grows (F.eqStep_grows hm g port _ 1)
        (F.eqStep_eqrow_other hm g port _ 1 g port 0 (by omega)) (F.eqStep_establishes hm g port 0 hg hb _)
    · exact F.eqStep_establishes hm g port 1 hg hb _
  show F.PEq g port b ((((([0, 1].foldl (F.eqStep hm g port) (t, [])).1.OR _).2.setForce _).AND _).2.setP0force _)
  simp only [List.foldl_cons, List.foldl_nil]
  apply F.PEq_of_grows _ _ hfold
  · exact StI.growsTo_trans (StI.growsTo_OR _ _) (StI.growsTo_trans (StI.growsTo_setForce _ _)
      (StI.growsTo_trans (StI.growsTo_AND _ _) (StI.growsTo_setP0force _ _)))
  · rfl

theorem eligStep_establishes (hm : 1 ≤ F.V) (g port b : Nat) (hg : g < F.s) (hp : port < 2) (hb : b < 2)
    (t : StI F.V) : F.PEq g port b (F.eligStep hm t g) := by
  have hfold : F.PEq g port b (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1 := by
    have hp' : port = 0 ∨ port = 1 := by omega
    rcases hp' with rfl | rfl
    · exact F.PEq_of_grows (F.portStep_grows hm g _ 1)
        (F.portStep_eqrow hm g _ 1 g 0 b (by omega)) (F.portStep_establishes hm g 0 b hg hb _)
    · exact F.portStep_establishes hm g 1 b hg hb _
  show F.PEq g port b (((([0, 1].foldl (F.portStep hm g) (t, [])).1.OR _).2.AND _).2.setEligible _)
  simp only [List.foldl_cons, List.foldl_nil]
  apply F.PEq_of_grows _ _ hfold
  · exact StI.growsTo_trans (StI.growsTo_OR _ _) (StI.growsTo_trans (StI.growsTo_AND _ _) (StI.growsTo_setEligible _ _))
  · rfl

/-- **stage 2 establishes every PEq** -/
theorem stage2_PEq (hm : 1 ≤ F.V) (t : StI F.V) (g port b : Nat) (hg1 : 1 ≤ g) (hg : g < F.s)
    (hp : port < 2) (hb : b < 2) : F.PEq g port b (F.stage2 hm t) := by
  unfold stage2
  have hmem : g ∈ List.range' 1 (F.s - 1) := List.mem_range'_1.mpr ⟨hg1, by omega⟩
  obtain ⟨l1, l2, hl, hfold⟩ := foldl_split (F.eligStep hm) _ g hmem
  rw [hfold t]
  have hnd : (List.range' 1 (F.s - 1)).Nodup := List.nodup_range' (step := 1)
  rw [hl] at hnd
  have hg_not : g ∉ l2 := (List.nodup_cons.mp (List.nodup_append.mp hnd).2.1).1
  apply foldl_pres (F.PEq g port b) (F.eligStep hm) l2
  · intro g' hg' t' h
    have hne : g' ≠ g := fun e => hg_not (e ▸ hg')
    exact F.PEq_of_grows (F.eligStep_grows hm t' g') (F.eligStep_eqrow hm t' g' g port b hne) h
  · exact F.eligStep_establishes hm g port b hg hp hb _

/-! ### PForce: established in stage 2 -/

theorem eqStep_force (hm : 1 ≤ F.V) (g port : Nat) (acc : StI F.V × List Int) (b : Nat) :
    (F.eqStep hm g port acc b).1.s.force = acc.1.s.force := by
  obtain ⟨t, eqs⟩ := acc; rfl

theorem portStep_force_other (hm : 1 ≤ F.V) (g' : Nat) (acc : StI F.V × List Int) (port' : Nat)
    (g port : Nat) (hne : ¬ (g' = g ∧ port' = port)) :
    (F.portStep hm g' acc port').1.s.force g port = acc.1.s.force g port := by
  obtain ⟨t, ports⟩ := acc
  have hne' : ¬ (g = g' ∧ port = port') := fun h => hne ⟨h.1.symm, h.2.symm⟩
  simp only [portStep, StI.setP0force, StI.AND, StI.setForce, StI.OR, St.AND, St.OR, List.foldl_cons,
    List.foldl_nil, hne', ↓reduceIte]
  rw [F.eqStep_force, F.eqStep_force]

theorem eligStep_force_other (hm : 1 ≤ F.V) (t : StI F.V) (g' : Nat) (g port : Nat) (hne : g' ≠ g) :
    (F.eligStep hm t g').s.force g port = t.s.force g port := by
  show ((((([0, 1].foldl (F.portStep hm g') (t, [])).1.OR _).2.AND _).2.setEligible _)).s.force g port = _
  simp only [List.foldl_cons, List.foldl_nil]
  show (([0, 1].foldl (F.portStep hm g') (t, [])).1).s.force g port = _
  simp only [List.foldl_cons, List.foldl_nil]
  rw [F.portStep_force_other hm g' _ 1 g port (by omega), F.portStep_force_other hm g' _ 0 g port (by omega)]

/-- the port step of (g, port) establishes PForce (g, port) -/
theorem portStep_establishes_force (hm : 1 ≤ F.V) (g port : Nat) (hg : g < F.s) (hp : port < 2)
    (acc : StI F.V × List Int) : F.PForce g port (F.portStep hm g acc port).1 := by
  obtain ⟨t, ports⟩ := acc
  have hV := t.var_ge
  have ha0 := F.fn_range g (eqPair port 0).1 hg (eqPair_lt port 0 (by omega)).1
  have hd0 := F.fn_range g (eqPair port 0).2 hg (eqPair_lt port 0 (by omega)).2
  have ha1 := F.fn_range g (eqPair port 1).1 hg (eqPair_lt port 1 (by omega)).1
  have hd1 := F.fn_range g (eqPair port 1).2 hg (eqPair_lt port 1 (by omega)).2
  have hS := F.S4_le_V
  have c1 : 1 ≤ ((t.s.var + 1 : Nat) : Int).natAbs ∧ ((t.s.var + 1 : Nat) : Int).natAbs ≤ t.s.var + 1 + 1 := by
    omega
  have c2 : 1 ≤ ((t.s.var + 1 + 1 : Nat) : Int).natAbs ∧ ((t.s.var + 1 + 1 : Nat) : Int).natAbs ≤ t.s.var + 1 + 1 := by
    omega
  simp only [PForce, portStep, eqStep, StI.setP0force, StI.AND, StI.setForce, StI.OR, StI.setEqrow, StI.EQ,
    St.AND, St.OR, St.EQ, List.foldl_cons, List.foldl_nil, List.nil_append, List.singleton_append,
    List.cons_append, List.append_assoc, and_self, ↓reduceIte, Nat.zero_ne_one, and_false, false_and]
  refine ⟨?_, ?_, ?_⟩
  · simp only [St.chk, List.filter, c1, c2, and_self, decide_true, List.mem_append, List.mem_cons]
    simp
  · omega
  · omega

theorem eligStep_establishes_force (hm : 1 ≤ F.V) (g port : Nat) (hg : g < F.s) (hp : port < 2)
    (t : StI F.V) : F.PForce g port (F.eligStep hm t g) := by
  have hfold : F.PForce g port (F.portStep hm g (F.portStep hm g (t, []) 0) 1).1 := by
    have hp' : port = 0 ∨ port = 1 := by omega
    rcases hp' with rfl | rfl
    · exact F.PForce_of_grows (F.portStep_grows hm g _ 1)
        (fun b => F.portStep_eqrow hm g _ 1 g 0 b (by omega)) (F.portStep_force_other hm g _ 1 g 0 (by omega))
        (F.portStep_establishes_force hm g 0 hg (by omega) _)
    · exact F.portStep_establishes_force hm g 1 hg (by omega) _
  show F.PForce g port (((([0, 1].foldl (F.portStep hm g) (t, [])).1.OR _).2.AND _).2.setEligible _)
  simp only [List.foldl_cons, List.foldl_nil]
  apply F.PForce_of_grows _ _ _ hfold
  · exact StI.growsTo_trans (StI.growsTo_OR _ _) (StI.growsTo_trans (StI.growsTo_AND _ _) (StI.growsTo_setEligible _ _))
  · intro b; rfl
  · rfl

/-- **stage 2 establishes every PForce** -/
theorem stage2_PForce (hm : 1 ≤ F.V) (t : StI F.V) (g port : Nat) (hg1 : 1 ≤ g) (hg : g < F.s)
    (hp : port < 2) : F.PForce g port (F.stage2 hm t) := by
  unfold stage2
  have hmem : g ∈ List.range' 1 (F.s - 1) := List.mem_range'_1.mpr ⟨hg1, by omega⟩
  obtain ⟨l1, l2, hl, hfold⟩ := foldl_split (F.eligStep hm) _ g hmem
  rw [hfold t]
  have hnd : (List.range' 1 (F.s - 1)).Nodup := List.nodup_range' (step := 1)
  rw [hl] at hnd
  have hg_not : g ∉ l2 := (List.nodup_cons.mp (List.nodup_append.mp hnd).2.1).1
  apply foldl_pres (F.PForce g port) (F.eligStep hm) l2
  · intro g' hg' t' h
    have hne : g' ≠ g := fun e => hg_not (e ▸ hg')
    exact F.PForce_of_grows (F.eligStep_grows hm t' g') (fun b => F.eligStep_eqrow hm t' g' g port b hne)
      (F.eligStep_force_other hm t' g' g port hne) h
  · exact F.eligStep_establishes_force hm g port hg hp _

/-! ### Stages 3–7 keep eqrow and force -/

end Fam

namespace StI
variable {m0 : Nat}

/-- a transition that only grows the commands and leaves eqrow and force alone -/
def Keeps (t t' : StI m0) : Prop := GrowsTo t t' ∧ t'.s.eqrow = t.s.eqrow ∧ t'.s.force = t.s.force

theorem keeps_refl (t : StI m0) : Keeps t t := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps_trans {a b c : StI m0} (h1 : Keeps a b) (h2 : Keeps b c) : Keeps a c :=
  ⟨growsTo_trans h1.1 h2.1, h2.2.1.trans h1.2.1, h2.2.2.trans h1.2.2⟩
theorem keeps_OR (t : StI m0) (xs) : Keeps t (t.OR xs).2 := ⟨growsTo_OR t xs, rfl, rfl⟩
theorem keeps_AND (t : StI m0) (xs) : Keeps t (t.AND xs).2 := ⟨growsTo_AND t xs, rfl, rfl⟩
theorem keeps_EQ (t : StI m0) (hm : 1 ≤ m0) (a b) : Keeps t (t.EQ hm a b).2 := ⟨growsTo_EQ t hm a b, rfl, rfl⟩
theorem keeps_rup (t : StI m0) (c) : Keeps t (t.rup c) := ⟨growsTo_rup t c, rfl, rfl⟩
theorem force_split (vs : List Int) : ∀ (t : StI m0) (c), (t.split c vs).s.force = t.s.force := by
  induction vs with
  | nil => intro t c; rfl
  | cons v vs ih => intro t c; show ((t.split (c ++ [v]) vs).split (c ++ [-v]) vs).s.force = _; rw [ih, ih]
theorem keeps_split (t : StI m0) (c vs) : Keeps t (t.split c vs) := ⟨growsTo_split t c vs, eqrow_split vs t c, force_split vs t c⟩
theorem keeps_setLive (t : StI m0) (f) : Keeps t (t.setLive f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps_setEdges (t : StI m0) (f) : Keeps t (t.setEdges f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps_setP0force (t : StI m0) (f) : Keeps t (t.setP0force f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps_setEligible (t : StI m0) (f) : Keeps t (t.setEligible f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps_setVeq (t : StI m0) (f) : Keeps t (t.setVeq f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps_setBranches (t : StI m0) (f) : Keeps t (t.setBranches f) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps_setA (t : StI m0) (a) : Keeps t (t.setA a) := ⟨growsTo_refl t, rfl, rfl⟩
theorem keeps_setB (t : StI m0) (b) : Keeps t (t.setB b) := ⟨growsTo_refl t, rfl, rfl⟩

theorem keeps_foldl {α : Type} (f : StI m0 → α → StI m0) (l : List α) (hf : ∀ t x, Keeps t (f t x)) :
    ∀ t, Keeps t (l.foldl f t) := by
  intro t
  apply foldl_pres (fun t' => Keeps t t') f l
  · intro x _ t' h; exact keeps_trans h (hf t' x)
  · exact keeps_refl t

theorem keeps_foldl_pair {α β : Type} (f : StI m0 × β → α → StI m0 × β) (l : List α)
    (hf : ∀ acc x, Keeps acc.1 (f acc x).1) : ∀ acc, Keeps acc.1 (l.foldl f acc).1 := by
  intro acc
  apply foldl_pres (fun acc' => Keeps acc.1 acc'.1) f l
  · intro x _ acc' h; exact keeps_trans h (hf acc' x)
  · exact keeps_refl _

end StI

namespace Fam
variable (F : Fam)
open StI

theorem keeps_stage3 (t : StI F.V) : Keeps t (F.stage3 t) :=
  keeps_trans (keeps_OR _ _) (keeps_setA _ _)

theorem keeps_forceRups (t : StI F.V) (gp : Nat × Nat) : Keeps t (F.forceRups t gp) := by
  obtain ⟨g, port⟩ := gp
  apply keeps_foldl _ _ _ t
  intro t' ab; obtain ⟨a, b⟩ := ab
  exact keeps_trans (keeps_rup _ _) (keeps_rup _ _)

theorem keeps_stage4 (t : StI F.V) : Keeps t (F.stage4 t) :=
  keeps_foldl _ _ (fun t' gp => F.keeps_forceRups t' gp) t

theorem keeps_portEqStep (hm : 1 ≤ F.V) (g bit cb : Nat) (t : StI F.V) (port : Nat) :
    Keeps t (F.portEqStep hm g bit cb t port) := by
  unfold portEqStep
  apply keeps_trans (keeps_EQ _ hm _ _)
  apply keeps_trans (keeps_foldl _ _ (fun t' j => keeps_split _ _ _) _)
  exact keeps_trans (keeps_rup _ _) (keeps_rup _ _)

theorem keeps_veqStep (hm : 1 ≤ F.V) (bit cb : Nat) (t : StI F.V) (g : Nat) :
    Keeps t (F.veqStep hm bit cb t g) := by
  unfold veqStep
  apply keeps_trans (keeps_EQ _ hm _ _)
  apply keeps_trans (keeps_setVeq _ _)
  split
  · exact keeps_split _ _ _
  · exact keeps_trans (keeps_foldl _ _ (fun t' port => F.keeps_portEqStep hm g bit cb t' port) _) (keeps_split _ _ _)

theorem keeps_bitStep (hm : 1 ≤ F.V) (acc : StI F.V × List Int) (bit : Nat) :
    Keeps acc.1 (F.bitStep hm acc bit).1 := by
  obtain ⟨t, C⟩ := acc
  show Keeps t ((((List.range F.s).foldl
    (F.veqStep hm bit (t.EQ hm (F.fn 0 bit : Int) (F.fn 0 (bit + 2) : Int)).1)
    (t.EQ hm (F.fn 0 bit : Int) (F.fn 0 (bit + 2) : Int)).2)).rup _)
  apply keeps_trans (keeps_EQ _ hm _ _)
  apply keeps_trans (keeps_foldl _ _ (fun t' g => F.keeps_veqStep hm bit _ t' g) _)
  exact keeps_rup _ _

theorem keeps_stage5 (hm : 1 ≤ F.V) (t : StI F.V) : Keeps t (F.stage5 hm t) := by
  show Keeps t ((([0, 1].foldl (F.bitStep hm) (t, [])).1.split _ _).rup _)
  apply keeps_trans (keeps_foldl_pair _ _ (fun acc bit => F.keeps_bitStep hm acc bit) (t, []))
  exact keeps_trans (keeps_split _ _ _) (keeps_rup _ _)

theorem keeps_outSplit (t : StI F.V) (pb : Nat × Nat) : Keeps t (F.outSplit t pb) := by
  obtain ⟨port, b⟩ := pb; exact keeps_split _ _ _
theorem keeps_outRup (t : StI F.V) (port : Nat) : Keeps t (F.outRup t port) :=
  keeps_trans (keeps_rup _ _) (keeps_rup _ _)
theorem keeps_stage6 (t : StI F.V) : Keeps t (F.stage6 t) := by
  unfold stage6
  apply keeps_trans (keeps_foldl _ _ (fun t' pb => F.keeps_outSplit t' pb) t)
  apply keeps_trans (keeps_foldl _ _ (fun t' port => F.keeps_outRup t' port) _)
  exact keeps_rup _ _

theorem keeps_branchStep (b : Nat) (acc : StI F.V × List Int) (g : Nat) : Keeps acc.1 (F.branchStep b acc g).1 := by
  obtain ⟨t, brs⟩ := acc
  exact keeps_trans (keeps_OR _ _) (keeps_trans (keeps_AND _ _) (keeps_setBranches _ _))

theorem keeps_bStep (acc : StI F.V × List Int) (b : Nat) : Keeps acc.1 (F.bStep acc b).1 :=
  keeps_foldl_pair _ _ (fun acc' g => F.keeps_branchStep b acc' g) acc

theorem keeps_bRup (t : StI F.V) (b : Nat) : Keeps t (F.bRup t b) := keeps_rup _ _
theorem keeps_stage7 (t : StI F.V) : Keeps t (F.stage7 t) := by
  unfold stage7
  simp only []
  generalize hP : (List.range' 1 (F.s - 2)).foldl F.bStep (t, []) = P
  have k1 : Keeps t P.1 := by rw [← hP]; exact keeps_foldl_pair _ _ (fun acc b => F.keeps_bStep acc b) (t, [])
  obtain ⟨t', brs⟩ := P
  simp only []
  apply keeps_trans k1
  apply keeps_trans (keeps_OR _ _)
  apply keeps_trans (keeps_setB _ _)
  apply keeps_trans (keeps_foldl _ _ (fun t' b => F.keeps_bRup t' b) _)
  exact keeps_rup _ _

/-- after the whole frontend, every eqrow and force definition is in the commands, bounded -/
theorem frontendX_PEq (hs : 1 ≤ F.s) (g port b : Nat) (hg1 : 1 ≤ g) (hg : g < F.s) (hp : port < 2) (hb : b < 2) :
    F.PEq g port b (F.frontendX hs) := by
  unfold frontendX
  have h2 := F.stage2_PEq (F.V_pos hs) (F.stage1 F.stage0) g port b hg1 hg hp hb
  have k := keeps_trans (F.keeps_stage3 (F.stage2 (F.V_pos hs) (F.stage1 F.stage0)))
    (keeps_trans (F.keeps_stage4 _) (keeps_trans (F.keeps_stage5 (F.V_pos hs) _)
    (keeps_trans (F.keeps_stage6 _) (F.keeps_stage7 _))))
  exact F.PEq_of_grows k.1 (by rw [k.2.1]) h2

theorem frontendX_PForce (hs : 1 ≤ F.s) (g port : Nat) (hg1 : 1 ≤ g) (hg : g < F.s) (hp : port < 2) :
    F.PForce g port (F.frontendX hs) := by
  unfold frontendX
  have h2 := F.stage2_PForce (F.V_pos hs) (F.stage1 F.stage0) g port hg1 hg hp
  have k := keeps_trans (F.keeps_stage3 (F.stage2 (F.V_pos hs) (F.stage1 F.stage0)))
    (keeps_trans (F.keeps_stage4 _) (keeps_trans (F.keeps_stage5 (F.V_pos hs) _)
    (keeps_trans (F.keeps_stage6 _) (F.keeps_stage7 _))))
  exact F.PForce_of_grows k.1 (fun b => by rw [k.2.1]) (by rw [k.2.2]) h2

end Fam
end L3

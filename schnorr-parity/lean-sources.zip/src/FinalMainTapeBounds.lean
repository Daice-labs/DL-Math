import FinalEvaluationSize
import MainTapeRecurrence
namespace L3Emitter.FinalMainTapeBounds
open EREF EREF.GeneralRED AliasNetwork AliasProgram U2ConstructionSize
open FinalOutputDefinitions

theorem selected_core (D : List Row) (z : SelectedOutputPOL.Lits) :
    tokens (SelectedOutputPOL.program D z)=36 := by
  simp [tokens,SelectedOutputPOL.program,SelectedOutputPOL.tape0,
    SelectedOutputPOL.tape1,SelectedOutputPOL.tape2,CommonGuardResolve.token_count]

theorem selected_leaf (n : Nat) (hn : 2≤n) (x : Fin (T n)) (a b side : Bool)
    (i : Fin (W n)) (D : List Row) :
    tokens (FinalSelectedCases.leaf n hn x a b side i D)≤39 := by
  unfold FinalSelectedCases.leaf
  split
  · simp only [FinalSelectedCases.earlierProgram,tokens_append,
      FinalSelectedEvaluation.program,selected_core]
    simp [tokens,ChoiceProjection.weakenTokens,ClauseTransport.padSteps]
  · simp [tokens,FinalSelectedCases.lastProgram,ComplementChoice.tautTokens,
      ChoiceProjection.weakenTokens,FinalSelectedCases.lastExtra,ClauseTransport.padSteps]

theorem selected_join (n : Nat) (hn : 2≤n) (x : Fin (T n)) (a b side : Bool)
    (D : List Row) : tokens (FinalSelectedJoin.program n hn x a b side D)≤41*W n+2 := by
  have h:=fold_tokens (FinalSelectedCases.leaf n hn x a b side)
    (FinalSelectedCases.rows n hn x a b side) (List.finRange (W n)) D 39
    (fun i _ E=>selected_leaf n hn x a b side i E)
  simp only [List.length_finRange] at h
  simp only [FinalSelectedJoin.program,tokens_append]
  simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
    FinalSelectedJoin.joinTape,ProjectionTrace.joinCaseTokens,CaseJoin.join_token_count,
    List.length_map,List.length_finRange]
  change tokens (RetainedBlockFold.run _ _ _ _)+(2*W n+2+0)≤_
  omega

theorem kept_core (D : List Row) (G P : List Int) (o f : Bit) (u : Bool→Int) (q : Int) :
    tokens (GateUnaryCompositionPOL.program D G P o f u q)=36+4*G.length+4*P.length := by
  simp [tokens,GateUnaryCompositionPOL.program,GateUnaryCompositionPOL.firstTape,
    GateUnaryCompositionPOL.secondTape,CommonGuardResolve.token_count]
  omega

theorem kept (n : Nat) (hn : 2≤n) (x : Fin (T n)) (a b side : Bool) (D : List Row) :
    tokens (FinalKeptEvaluation.program n hn x a b side D)=94 := by
  simp only [FinalKeptEvaluation.program,tokens_append,FinalKeptEvaluation.coreProgram,kept_core]
  simp [FinalEvaluationContext.G,FinalEvaluationContext.P,tokens,FinalKeptEvaluation.transportTape,
    GuardedTwoPortPOL.tape,GuardedTwoPortPOL.links,GuardedTransport.tokens,
    GuardedTransport.padding,ClauseTransport.linkSteps,ClauseTransport.Link.tokens,
    ClauseTransport.padSteps]

theorem phase (n : Nat) (hn : 2≤n) (x : Fin (T n)) (a b side : Bool) (D : List Row) :
    tokens (FinalEvaluationJoin.phaseProgram n hn x a b side D)≤41*W n+100 := by
  have h:=selected_join n hn x a b side (D++FinalKeptEvaluation.rows n hn x a b side)
  simp only [FinalEvaluationJoin.phaseProgram,tokens_append,kept]
  simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,Resolution.mergeTokens,
    List.length_cons,List.length_nil]
  change 94+tokens (FinalSelectedJoin.program _ _ _ _ _ _ _)+(4+0)≤_
  omega

theorem leaf (n : Nat) (hn : 2≤n) (x : Fin (T n)) (a b : Bool) (D : List Row) :
    tokens (FinalEvaluationJoin.program n hn x a b D)≤82*W n+204 := by
  have h0:=phase n hn x a b false D
  have h1:=phase n hn x a b true (D++FinalEvaluationJoin.phaseRows n hn x a b false)
  simp only [FinalEvaluationJoin.program,tokens_append]
  simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,Resolution.mergeTokens,
    List.length_cons,List.length_nil]
  change tokens (FinalEvaluationJoin.phaseProgram _ _ _ _ _ _ _)+
    tokens (FinalEvaluationJoin.phaseProgram _ _ _ _ _ _ _)+(4+0)≤_
  omega

theorem image_leaf (n : Nat) (hn : 2≤n) (x : Fin (T n)) (a b w : Bool) (D : List Row) :
    (FinalEvaluationImage.tape n hn x a b w D).length≤7 := by
  unfold FinalEvaluationImage.tape
  simp [ChoiceProjection.weakenTokens,FinalEvaluationImage.extra,ClauseTransport.padSteps]
  split <;> simp

theorem image (n : Nat) (hn : 2≤n) : tokens (FinalEvaluationImage.program n hn)≤56*2^n := by
  have h : ∀js : List (FinalEvaluationImage.Job n),
      ((js.map (fun j=>(FinalEvaluationImage.tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2
        (FinalEvaluationBank.result n hn)).length)).sum)≤js.length*7 := by
    intro js
    induction js with
    | nil => simp
    | cons j js ih =>
      have hj:=image_leaf n hn j.1 j.2.1 j.2.2.1 j.2.2.2 (FinalEvaluationBank.result n hn)
      simp only [List.map_cons,List.sum_cons,List.length_cons];omega
  have hh:=h (FinalEvaluationImage.jobs n)
  have hj : (FinalEvaluationImage.jobs n).length=8*2^n := by
    simp [FinalEvaluationImage.jobs,List.length_flatMap,List.map_map,Function.comp_def,
      List.sum_replicate,T,FamilyNamespace.truthRows];ring
  rw [hj] at hh
  simpa [tokens,FinalEvaluationImage.program,List.map_map,Function.comp_def,
    Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using hh

/-- Main POL tokens for the complete replacement-gate evaluation and its
original-formula image. This does not count the other reduction banks. -/
theorem evaluation_in_n (n : Nat) (hn : 2≤n) :
    tokens (FinalEvaluationBank.program n hn)+tokens (FinalEvaluationImage.program n hn)≤
      1312*(n+1)*2^n := by
  have h:=fold_tokens (FinalEvaluationBank.leaf n hn) (FinalEvaluationBank.rows n hn)
    (FinalEvaluationBank.jobs n) (FinalEvaluationContext.D n hn) (82*W n+204)
    (fun j _ E=>leaf n hn j.1 j.2.1 j.2.2 E)
  rw [FinalEvaluationSize.job_count] at h
  change tokens (FinalEvaluationBank.program n hn)≤(4*T n)*(82*W n+204) at h
  have hi:=image n hn
  have hw:W n=4*n-4:=by unfold W AliasAssembly.width RankConstruction.width;omega
  have hc:4*(82*W n+204)+56≤1312*(n+1):=by rw [hw];omega
  have hm:=Nat.mul_le_mul_right (2^n) hc
  unfold T FamilyNamespace.truthRows at h
  nlinarith
#print axioms evaluation_in_n
#print axioms kept
end L3Emitter.FinalMainTapeBounds

import GateEvaluationPOL
namespace L3Emitter.GateEvaluationBindings
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL AliasProgram

def base (n:Nat) (hn:2≤n):=LowerPortEvalBank.result n hn
theorem selector_keep (n:Nat) (hn:2≤n):∀R∈LowerSelectorALO.result n hn,R∈base n hn:=by
  intro R hr;exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hr))
theorem unary_keep (n:Nat) (hn:2≤n):∀R∈UnaryValueBank.result n hn,R∈base n hn:=by
  intro R hr
  apply selector_keep
  apply LowerSelectorComplete.predecessor_kept
  apply TopologyContext.global_kept
  apply GlobalPortValues.retained
  apply GlobalValueInduction.retained
  apply SharedValueBank.gamma_retained
  exact EarlierPortValues.unary_keep n hn R hr

theorem semantics_mem (n:Nat) (hn:2≤n) (G x:Nat) (hG:G<3*(n+1)-4) (hx:x<FamilyNamespace.truthRows n) (u v w:Bool):
    CofactorSemantics.goal n (3*(n+1)-4) (ConstantCofactor.offset n hn) G x u v w∈base n hn:=by
  apply unary_keep
  apply CofactorValueRows.beta_keep
  exact List.mem_append_left _ (BetaValue.semantics_present n hn G x hG hx u v w)

def lits (n:Nat) (hn:2≤n) (t G x:Nat) (a b w u v:Bool):GateEvaluationPOL.Literals where
  c := -(TopologyContext.guard n hn G t).val
  a := -sign a (LowerTransferImage.wire n hn (.port t 0 x))
  b := -sign b (LowerTransferImage.wire n hn (.port t 1 x))
  u := -sign u (ComposedTableBank.unary n hn G 0 a)
  v := -sign v (ComposedTableBank.unary n hn G 1 b)
  p := sign u (EarlierPortValues.portValue n hn G 0 x)
  r := sign v (EarlierPortValues.portValue n hn G 1 x)
  f := sign w (ComposedTableBank.originalFunction n G u v)
  q := -sign w (RankTableBank.table n hn G a b)
  o := sign w (CofactorValueRows.cofactor n hn G x)

theorem valid (n:Nat) (hn:2≤n) (t G x:Nat) (a b w u v:Bool):
    (lits n hn t G x a b w u v).Valid:=by
  simp [lits,GateEvaluationPOL.Literals.Valid,Valid,sign_valid,(TopologyContext.guard n hn G t).property]

theorem source_eq (n:Nat) (hn:2≤n) (t G x:Nat) (a b w u v:Bool):
    GateEvaluationPOL.source (lits n hn t G x a b w u v)=
      CofactorSemantics.goal n (3*(n+1)-4) (ConstantCofactor.offset n hn) G x u v (!w):=by
  have hp:=ProjectionTrace.clause_perm
    [-sign u (EarlierPortValues.portValue n hn G 0 x),-sign v (EarlierPortValues.portValue n hn G 1 x),
      -sign w (ComposedTableBank.originalFunction n G u v),sign w (CofactorValueRows.cofactor n hn G x)]
    [-sign u (EarlierPortValues.portValue n hn G 0 x),-sign v (EarlierPortValues.portValue n hn G 1 x),
      sign w (CofactorValueRows.cofactor n hn G x),-sign w (ComposedTableBank.originalFunction n G u v)]
    (by simp [Valid,sign_valid]) (by simp [Valid,sign_valid]) (List.Perm.cons _ (List.Perm.cons _ (List.Perm.swap ..)))
  change clause [-sign u (EarlierPortValues.portValue n hn G 0 x),-sign v (EarlierPortValues.portValue n hn G 1 x),
    -sign w (ComposedTableBank.originalFunction n G u v),sign w (CofactorValueRows.cofactor n hn G x)]=_
  rw [hp]
  cases u <;> cases v <;> cases w <;>
    simp [CofactorSemantics.goal,CofactorSemantics.fnLiteral,REDWitness.output,sign,EarlierPortValues.portValue,
      CofactorValueRows.cofactor,ComposedTableBank.originalFunction,AliasAssembly.functionBit]

theorem checks (n:Nat) (hn:2≤n) (t G x:Nat) (ht:t<RankConstruction.width (n+1))
    (hG:G∈RankZeroTransport.gates n) (hx:x<FamilyNamespace.truthRows n) (a b w u v:Bool)
    (D:List Row) (hd:∀R∈base n hn,R∈D):
    polEval (dbOf D) (GateEvaluationPOL.tape D (lits n hn t G x a b w u v)) []=
      some (GateEvaluationPOL.target (lits n hn t G x a b w u v)):=by
  have hg:=(RankZeroTransport.gate_mem n G).mp hG
  apply GateEvaluationPOL.checks D _ (valid n hn t G x a b w u v)
  · rw [source_eq];exact hd _ (semantics_mem n hn G x hg.2 hx u v (!w))
  · exact hd _ (LowerPortEvalBank.actual_port_rows n hn t 0 G x ht (by decide) hG hx a u)
  · exact hd _ (LowerPortEvalBank.actual_port_rows n hn t 1 G x ht (by decide) hG hx b v)
  · have h:=ComposedU2Bank.lookup_rows n hn G hg.1 hg.2 (fun _=>u) (fun _=>v) a b (!w)
    apply hd
    apply selector_keep
    simpa only [GateEvaluationPOL.lookup,lits,U2LookupLink.short,ComposedU2Bank.unary,
      ComposedU2Bank.table,LowerPortEvaluation.sign_not,neg_neg] using h
#print axioms checks
end L3Emitter.GateEvaluationBindings

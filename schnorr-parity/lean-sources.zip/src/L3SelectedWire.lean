import L3GatePropagation
import L3OutputSplit

namespace L3
open EREF EREF.GeneralRED
namespace Fam
variable (F : Fam)

def wireLeaf (g p j x a cb live q : Nat) (pol : Bool) : List Int :=
  [(a : Int),-(cb : Int),-(live : Int),-(F.sel g p j : Int),(q : Int),
    if pol then -(F.port g p x : Int) else (F.port g p x : Int)]

def wireEqRow (g p x y q : Nat) (pol : Bool) : Row :=
  gateRow [if pol then -(F.port g p x : Int) else (F.port g p x : Int),
    if pol then -(F.port g p y : Int) else (F.port g p y : Int)] q true

/-- T5b, primary-input branch. The input has the same bit in both compared rows. -/
theorem input_wire_leaf (g p j x y a cb live q : Nat) (pol bit : Bool)
    (ha : 1≤a) (hc : 1≤cb) (hl : 1≤live) (hq : 1≤q)
    (hix : F.inputBit j x=bit) (hiy : F.inputBit j y=bit)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hx : (F.row3i g p j x).toE∈D) (hy : (F.row3i g p j y).toE∈D)
    (he : (F.wireEqRow g p x y q pol).toE∈D) :
    Refutation (D ++ [negate (clauseRow (F.wireLeaf g p j x a cb live q pol)).toE]) := by
  have hs := F.sel_pos g p j
  have hpx := F.port_pos g p x
  have hpy := F.port_pos g p y
  apply weighted_clause_chain D _ 2
    [F.row3i g p j x,F.row3i g p j y,F.wireEqRow g p x y q pol] hD
  · cases pol <;> simp only [wireLeaf,Bool.false_eq_true,↓reduceIte] <;> nz_lits
  · exact ⟨hx,hy,he,trivial⟩
  · cases bit <;> cases pol <;>
      simp only [row3i,hix,hiy,wireEqRow,gateRow,pos,neg,Bool.false_eq_true,↓reduceIte,All]
    all_goals repeat' first | apply And.intro | exact True.intro
    all_goals nz_lits
  · intro α
    cases bit <;> cases pol <;>
      simp [row3i,hix,hiy,wireEqRow,gateRow,wireLeaf,pos,neg,lsum_cons,lsum_nil] <;> lv_omega

def predecessorRows (g p h x y a cb live liveh edge v q : Nat) (pol : Bool) : List Row :=
  [gateRow [-(live : Int),-(F.sel g p (F.k+h) : Int)] edge true,
   gateRow [-(edge : Int)] liveh true,
   clauseRow [(a : Int),-(cb : Int),-(liveh : Int),(v : Int)],
   if pol then F.row3g' g p h x else F.row3g g p h x,
   gateRow [if pol then -(F.val h x : Int) else (F.val h x : Int),
     if pol then (F.val h y : Int) else -(F.val h y : Int)] v false,
   if pol then F.row3g g p h y else F.row3g' g p h y,
   F.wireEqRow g p x y q pol]

/-- T5b, earlier-gate branch: liveness travels backwards along the selected
    edge and equality travels forwards. Seven named rows suffice for either
    sign of the selected port. No dynamic search premise. -/
theorem predecessor_wire_leaf (g p h x y a cb live liveh edge v q : Nat) (pol : Bool)
    (ha : 1≤a) (hc : 1≤cb) (hl : 1≤live) (hlh : 1≤liveh)
    (he : 1≤edge) (hv : 1≤v) (hq : 1≤q)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hm : All (fun r => r.toE∈D) (F.predecessorRows g p h x y a cb live liveh edge v q pol)) :
    Refutation (D ++ [negate (clauseRow (F.wireLeaf g p (F.k+h) x a cb live q pol)).toE]) := by
  have hs := F.sel_pos g p (F.k+h)
  have hpx := F.port_pos g p x
  have hpy := F.port_pos g p y
  have hvx := F.val_pos h x
  have hvy := F.val_pos h y
  apply weighted_clause_chain D _ 5
    (F.predecessorRows g p h x y a cb live liveh edge v q pol) hD
  · cases pol <;> simp only [wireLeaf,Bool.false_eq_true,↓reduceIte] <;> nz_lits
  · exact hm
  · cases pol <;>
      simp only [predecessorRows,wireEqRow,row3g,row3g',gateRow,pos,neg,Bool.false_eq_true,↓reduceIte,All]
    all_goals repeat' first | apply And.intro | exact True.intro
    all_goals nz_lits
  · intro α
    cases pol <;>
      simp [predecessorRows,wireEqRow,row3g,row3g',gateRow,clauseRow,wireLeaf,pos,neg,lsum_cons,lsum_nil,lsum_append] <;> lv_omega

#print axioms input_wire_leaf
#print axioms predecessor_wire_leaf
end Fam
end L3

import AliasGateSemantics
import SelectionBytes

namespace L3Emitter.AliasNetwork
open EREF EREF.GeneralRED REDWitness AliasGateSemantics

/-- Signed, nonzero references. Constants are emitted empty gates, not literal 0. -/
abbrev Bit := {l : Int // l≠0}

def neg (a : Bit) : Bit := ⟨-a.val,neg_ne_zero.mpr a.property⟩
def eval (α : Val) (a : Bit) := truth α a.val

structure Gate where
  isAnd : Bool
  q : Nat
  xs : List Bit

def Gate.rows (g : Gate) : List Row :=
  ((if g.isAnd then andGate else orGate) (g.xs.map Subtype.val)).map (GateRow.row g.q)

def Gate.document (g : Gate) : Doc :=
  TemplateBytes.gateDoc g.q ((if g.isAnd then andGate else orGate) (g.xs.map Subtype.val))

def Gate.meaning (g : Gate) (α : Val) :=
  if g.isAnd then g.xs.all (eval α) else g.xs.any (eval α)

theorem gate_meaning (g : Gate) (α : Val) (hq : 0<g.q)
    (hm : Models α g.rows) : α g.q=g.meaning α := by
  have hv : Valid (g.xs.map Subtype.val) := by
    intro x hx;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hx;exact l.property
  cases h:g.isAnd
  · have hh:=or_semantics α (g.xs.map Subtype.val) g.q hq hv
      (by simpa [Gate.rows,h] using hm)
    simpa [Gate.meaning,h,eval] using hh
  · have hh:=and_semantics α (g.xs.map Subtype.val) g.q hq hv
      (by simpa [Gate.rows,h] using hm)
    simpa [Gate.meaning,h,eval] using hh

/-- The network carries the actual accumulated rows and a checked trace.
    It does not carry a satisfiability or RUP-search assumption. -/
structure Net (base : List Row) where
  gates : List Gate
  canonical : ∀R∈base++gates.flatMap Gate.rows,Canonical R
  checked : CheckedTrace base (base++gates.flatMap Gate.rows)

def Net.rows {base : List Row} (z : Net base) := base++z.gates.flatMap Gate.rows

def initial (base : List Row) (hc : ∀R∈base,Canonical R) : Net base :=
  ⟨[],by simpa using hc,by simpa using CheckedTrace.refl base⟩

def allocation {base : List Row} (z : Net base) (xs : List Bit) :=
  max (CanonicalTrace.ceiling z.rows) (RawValueBank.literalMax (xs.map Subtype.val))

theorem input_bound {base : List Row} (z : Net base) (xs : List Bit) :
    L3.Bounded (allocation z xs) (xs.map Subtype.val) := by
  intro l hl
  obtain ⟨a,ha,rfl⟩:=List.mem_map.mp hl
  have h:=CanonicalTrace.fold_max_bound
    ((xs.map Subtype.val).map Int.natAbs) a.val.natAbs
    (List.mem_map.mpr ⟨a.val,List.mem_map.mpr ⟨a,ha,rfl⟩,rfl⟩)
  exact ⟨by have:=a.property;omega,by unfold allocation RawValueBank.literalMax;omega⟩

def freshGate {base : List Row} (z : Net base) (b : Bool) (xs : List Bit) : Gate :=
  ⟨b,allocation z xs+1,xs⟩

theorem append_checked {base : List Row} (z : Net base) (b : Bool) (xs : List Bit) :
    CheckedTrace z.rows (z.rows++(freshGate z b xs).rows) := by
  have hb:=RowSupport.mono z.rows
    (show CanonicalTrace.ceiling z.rows≤allocation z xs by unfold allocation;omega)
    (CanonicalTrace.bounded z.rows z.canonical)
  have hi:=input_bound z xs
  cases b
  · have h:=SupportSelection.or_step z.rows (allocation z xs) _ hb hi
    simpa only [L3.exec,SupportSelection.or_binding,freshGate,Gate.rows,Bool.false_eq_true,
      ↓reduceIte,List.append_nil] using h.1
  · have h:=SupportSelection.and_step z.rows (allocation z xs) _ hb hi
    simpa only [L3.exec,SupportSelection.and_binding,freshGate,Gate.rows,↓reduceIte,
      List.append_nil] using h.1

def push {base : List Row} (z : Net base) (b : Bool) (xs : List Bit) : Net base where
  gates := z.gates++[freshGate z b xs]
  checked := by
    have h:=L3.Fam.checkedTrace_trans z.checked (append_checked z b xs)
    simpa [Net.rows,List.flatMap_append,List.append_assoc] using h
  canonical := by
    have h:=CanonicalTrace.trace (append_checked z b xs) z.canonical
    simpa [Net.rows,List.flatMap_append,List.append_assoc] using h

def output {base : List Row} (z : Net base) (xs : List Bit) : Bit :=
  ⟨(allocation z xs+1:Nat),by omega⟩

def gate {base : List Row} (b : Bool) (xs : List Bit) : StateM (Net base) Bit :=
  fun z=>(output z xs,push z b xs)

def AND {base : List Row} (xs : List Bit) : StateM (Net base) Bit := gate true xs
def OR {base : List Row} (xs : List Bit) : StateM (Net base) Bit := gate false xs

def MUX {base : List Row} (c a b : Bit) : StateM (Net base) Bit := do
  let l ← AND [c,a]
  let r ← AND [neg c,b]
  OR [l,r]

def select {base : List Row} (xs : List (Bit×Bit)) : StateM (Net base) Bit := do
  let ts ← xs.mapM (fun p=>AND [p.1,p.2])
  OR ts

theorem rows_push {base : List Row} (z : Net base) (b : Bool) (xs : List Bit) :
    (push z b xs).rows=z.rows++(freshGate z b xs).rows := by
  simp [Net.rows,push,List.flatMap_append,List.append_assoc]

theorem push_retains {base : List Row} (z : Net base) (b : Bool) (xs : List Bit) :
    ∀R∈z.rows,R∈(push z b xs).rows := by
  rw [rows_push];exact fun R h=>List.mem_append_left _ h

theorem gate_value {base : List Row} (z : Net base) (b : Bool) (xs : List Bit)
    (α : Val) (hm : Models α (push z b xs).rows) :
    eval α (output z xs) = if b then xs.all (eval α) else xs.any (eval α) := by
  have h:=gate_meaning (freshGate z b xs) α (by dsimp [freshGate];omega)
    (models_mono α _ _ (by intro R hr;rw [rows_push];exact List.mem_append_right _ hr) hm)
  change truth α ((allocation z xs+1:Nat):Int)=_
  rw [truth_nat α _ (by omega)]
  exact h

theorem push_count {base : List Row} (z : Net base) (b : Bool) (xs : List Bit) :
    (push z b xs).gates.length=z.gates.length+1 := by simp [push]

#print axioms gate_meaning
#print axioms append_checked
#print axioms push
#print axioms gate_value
end L3Emitter.AliasNetwork

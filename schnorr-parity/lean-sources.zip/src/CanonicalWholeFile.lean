import CanonicalLineEncoding

set_option linter.unusedSimpArgs false
namespace L3Emitter.CanonicalWholeFile
open EREF CanonicalScopeKernel CanonicalLineParser CanonicalFileGrammar
open CanonicalByteFraming CanonicalLineEncoding

structure File where
  formulaRows : Nat
  commands : List CanonicalScopeKernel.Command
  conclusion : Nat

def readEvents : List Bytes→Option (List Event)
  | []=>some []
  | l::ls=>do return (←CanonicalLineParser.parse l)::(←readEvents ls)

theorem events_roundtrip (es : List Event) (hv : ∀ e∈es,CanonicalLineParser.Valid e) :
    readEvents (es.map line)=some es := by
  induction es with
  | nil=>rfl
  | cons e es ih=>
    have hh:=CanonicalLineParser.roundtrip e (hv e (by simp))
    have ht:=ih (by intro x hx;exact hv x (by simp [hx]))
    simp [readEvents,hh,ht,bind,Option.bind]

def prefixLines (F : Nat) := [ascii "pseudo-Boolean proof version 3.0",ascii "f "++decimal F++ascii " ;"]
def suffixLines (c : Nat) := [ascii "output NONE ;",ascii "conclusion UNSAT : "++decimal c++ascii " ;",
  ascii "end pseudo-Boolean proof ;"]

def render (f : File) := joinLines (prefixLines f.formulaRows++
  (f.commands.flatMap commandEvents).map line++suffixLines f.conclusion)

/-- End markers, declared formula count, conclusion reference, complete body,
and final line ending are all consumed. A trailing command or unclosed scope
is rejected rather than ignored. -/
def parseLines : List Bytes→Option File
  | h::f::ls=>
    if h≠ascii "pseudo-Boolean proof version 3.0" then none else
    match ls.reverse with
    | []::e::c::o::body=>
      if e≠ascii "end pseudo-Boolean proof ;" ∨ o≠ascii "output NONE ;" then none else do
        let fb←strip (ascii "f ") (ascii " ;") f
        let F←DecimalParser.parse fb
        let cb←strip (ascii "conclusion UNSAT : ") (ascii " ;") c
        let C←DecimalParser.parse cb
        let es←readEvents body.reverse
        let cs←CanonicalFileGrammar.parse es
        return ⟨F,cs,C⟩
    | _=>none
  | _=>none

def parse (bs : Bytes) := parseLines (fileLines bs)

theorem prefix_safe (F : Nat) : ∀ l∈prefixLines F,(10:UInt8)∉l := by
  intro l hl
  simp only [prefixLines,List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl|rfl
  · decide
  · simp only [List.mem_append,not_or]
    exact ⟨⟨by decide,decimal_avoids F 10 (Or.inl (by decide))⟩,by decide⟩

theorem suffix_safe (c : Nat) : ∀ l∈suffixLines c,(10:UInt8)∉l := by
  intro l hl
  simp only [suffixLines,List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl|rfl|rfl
  · decide
  · simp only [List.mem_append,not_or]
    exact ⟨⟨by decide,decimal_avoids c 10 (Or.inl (by decide))⟩,by decide⟩
  · decide

theorem strip_assoc (h m t : Bytes) : strip h t (h++(m++t))=some m := by
  simpa only [List.append_assoc] using strip_roundtrip h m t

theorem roundtrip (f : File)
    (hv : ∀ e∈f.commands.flatMap commandEvents,CanonicalLineParser.Valid e) :
    parse (render f)=some f := by
  have hn:∀ l∈prefixLines f.formulaRows++(f.commands.flatMap commandEvents).map line++suffixLines f.conclusion,
      (10:UInt8)∉l:=by
    intro l hl
    rcases List.mem_append.mp hl with hl|hl
    · rcases List.mem_append.mp hl with hl|hl
      · exact prefix_safe _ l hl
      · obtain ⟨e,he,rfl⟩:=List.mem_map.mp hl
        exact line_no_newline e
    · exact suffix_safe _ l hl
  rw [parse,render,split_lines _ hn]
  simp only [prefixLines,suffixLines,List.cons_append,List.nil_append,parseLines,
    ne_eq,not_true_eq_false,↓reduceIte,List.reverse_append,List.reverse_cons,List.reverse_nil,
    List.append_assoc,List.reverse_reverse,strip_assoc,or_self,strip_roundtrip,DecimalParser.roundtrip,
    bind,Option.bind,events_roundtrip _ hv,commands_roundtrip]
  rfl

theorem join_append (a b : List Bytes) : joinLines (a++b)=joinLines a++joinLines b := by
  simp [joinLines]

theorem prefix_bytes (F : Nat) : joinLines (prefixLines F)=emit (CanonicalScopedBytes.header F) := by
  simp only [prefixLines,joinLines,List.flatMap_cons,List.flatMap_nil,List.append_nil,
    CanonicalScopedBytes.header,emit_append,emit_fixed]
  have h:emit (number F)=decimal F:=by simp [emit,number,Piece.emit]
  rw [h,show ascii "pseudo-Boolean proof version 3.0\nf "=
    ascii "pseudo-Boolean proof version 3.0"++[10]++ascii "f " by decide,
    show ascii " ;\n"=ascii " ;"++[10] by decide]
  simp only [List.append_assoc]

theorem suffix_bytes (c : Nat) : joinLines (suffixLines c)=emit (CanonicalScopedBytes.footer c) := by
  simp only [suffixLines,joinLines,List.flatMap_cons,List.flatMap_nil,List.append_nil,
    CanonicalScopedBytes.footer,emit_append,emit_fixed]
  have h:emit (number c)=decimal c:=by simp [emit,number,Piece.emit]
  rw [h,show ascii "output NONE ;\nconclusion UNSAT : "=
    ascii "output NONE ;"++[10]++ascii "conclusion UNSAT : " by decide,
    show ascii " ;\nend pseudo-Boolean proof ;\n"=
      ascii " ;"++[10]++ascii "end pseudo-Boolean proof ;"++[10] by decide]
  simp only [List.append_assoc]

def family (n : Nat) : File := ⟨(NativeRecordedFamily.original n).length,
  CanonicalWireFamily.commands n,NativeRecordedFamily.conclusion n⟩

theorem family_bytes (n : Nat) : render (family n)=CanonicalScopedBytes.familyBytes n := by
  rw [render,join_append,join_append,prefix_bytes,suffix_bytes]
  change emit (CanonicalScopedBytes.header (family n).formulaRows)++
    eventBytes ((family n).commands.flatMap commandEvents)++
    emit (CanonicalScopedBytes.footer (family n).conclusion)=_
  rw [←CanonicalLineEncoding.commands_bytes]
  simpa only [CanonicalWireFamily.document,emit_append,family] using
    congrArg emit (CanonicalWireFamily.document_eq n)

/-- Whole document readback, conditional here only on field lexical validity;
no parsed commands are passed to the actual parser. -/
theorem family_roundtrip_of_valid (n : Nat)
    (hv : ∀ e∈(CanonicalWireFamily.commands n).flatMap commandEvents,CanonicalLineParser.Valid e) :
    parse (CanonicalScopedBytes.familyBytes n)=some (family n) := by
  rw [←family_bytes]
  exact roundtrip _ hv

#print axioms roundtrip
#print axioms family_bytes
#print axioms family_roundtrip_of_valid
end L3Emitter.CanonicalWholeFile

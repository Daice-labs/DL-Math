import ConstructionRankCount
import RecordedTransportPrefix
import RawBankSize

namespace L3Emitter.ConstructionTransportCount
open EREF EREF.GeneralRED ConstructionConstantCount ConstructionCountTools

theorem wire_jobs (n s : Nat) : (WireBank.jobs n s).length≤4*s^2*2^n := by
  unfold WireBank.jobs
  have h:=flat_count (List.range s) (fun g=>(List.range 2).flatMap fun p=>
    (List.range g).flatMap fun h=>(List.range (FamilyNamespace.truthRows n)).flatMap fun x=>
      [(g,p,h,x,false),(g,p,h,x,true)]) (4*s*2^n) (by
        intro g hg
        have hg':g≤s:=by have:=List.mem_range.mp hg;omega
        simp [List.length_flatMap,FamilyNamespace.truthRows]
        nlinarith [Nat.mul_le_mul_right (2^n) hg'])
  simp only [List.length_range] at h
  exact h.trans (by ring_nf;exact Nat.le_refl _)

theorem wire (n : Nat) (hn : 2≤n) :
    (WireBank.program n hn).length≤36*(n+1)^2*2^n := by
  simp only [WireBank.program,ForcingSize.rebase_length,WireBank.sourceProgram,List.length_map]
  have h:=wire_jobs n (3*(n+1)-4)
  have hs:3*(n+1)-4≤3*(n+1):=Nat.sub_le ..
  have hh:=Nat.mul_le_mul_right (2^n) (Nat.pow_le_pow_left hs 2)
  nlinarith

theorem gamma_jobs (n : Nat) (hn : 2≤n) :
    (GammaConstant.jobs n hn).length≤15552*(n+1)^5*2^n := by
  unfold GammaConstant.jobs
  have h:=flat_count (BetaPort.jobs n hn) (fun j=>(List.range (3*(n+1)-4)).flatMap fun g=>
    if j.1.2.parent.beta<g then (List.range 2).flatMap fun p=>[(j,g,p,false),(j,g,p,true)] else [])
    (12*(n+1)) (by
      intro j hj
      dsimp only
      have hh:=flat_count (List.range (3*(n+1)-4)) (fun g=>
        if j.1.2.parent.beta<g then (List.range 2).flatMap fun p=>[(j,g,p,false),(j,g,p,true)] else []) 4 (by
          intro g hg;dsimp only;split <;> simp [List.length_flatMap])
      simp only [List.length_range] at hh
      omega)
  have hb:=beta_port n hn
  simp only [BetaPort.program,List.length_map] at hb
  have hm:=Nat.mul_le_mul_right (12*(n+1)) hb
  exact h.trans (hm.trans (by ring_nf;exact Nat.le_refl _))

theorem input (n : Nat) (hn : 2≤n) :
    (InputBank.program n hn).length=2*(3*(n+1)-4)*n*2^n := by
  simp [InputBank.program,ForcingSize.rebase_length,InputBank.sourceProgram,
    InputBank.jobs,List.length_flatMap,FamilyNamespace.truthRows] <;> ring

theorem output (n : Nat) (hn : 2≤n) : (OutputBank.program n hn).length=2*2^n := by
  simp [OutputBank.program,ForcingSize.rebase_length,OutputBank.sourceProgram,
    OutputBank.jobs,List.length_flatMap,FamilyNamespace.truthRows,Nat.mul_comm]

theorem unary (n : Nat) (hn : 2≤n) :
    (GammaUnary.program n hn).length≤62208*(n+1)^5*2^n := by
  have h: (GammaUnary.program n hn).length=4*(GammaConstant.jobs n hn).length:=by
    simp [GammaUnary.program,GammaUnary.jobs,List.length_flatMap,Nat.mul_comm]
  rw [h];have hg:=gamma_jobs n hn;nlinarith

theorem selector_jobs (k s : Nat) : (SelectorBank.jobs k s).length≤2*s*(k+s)^2 := by
  unfold SelectorBank.jobs
  have h:=flat_count (List.range s) (fun g=>(List.range 2).flatMap fun p=>
    (List.range (k+g)).flatMap fun a=>(List.range (k+g)).filterMap fun b=>
      if a=b then none else some (g,p,a,b)) (2*(k+s)^2) (by
        intro g hg
        have hg':g≤s:=by have:=List.mem_range.mp hg;omega
        have hp:=flat_count (List.range 2) (fun p=>(List.range (k+g)).flatMap fun a=>
          (List.range (k+g)).filterMap fun b=>if a=b then none else some (g,p,a,b)) ((k+s)^2) (by
            intro p hp
            have ha:=flat_count (List.range (k+g)) (fun a=>(List.range (k+g)).filterMap fun b=>
              if a=b then none else some (g,p,a,b)) (k+g) (by
                intro a ha;exact (List.length_filterMap_le ..).trans (by simp))
            simp only [List.length_range] at ha
            exact ha.trans (by nlinarith [Nat.pow_le_pow_left (show k+g≤k+s by omega) 2]))
        simpa only [List.length_range] using hp)
  simp only [List.length_range] at h
  exact h.trans (by ring_nf;exact Nat.le_refl _)

theorem selector (n : Nat) (hn : 2≤n) :
    (SelectorBank.program n hn).length≤96*(n+1)^3 := by
  simp only [SelectorBank.program,ForcingSize.rebase_length,SelectorBank.sourceProgram,List.length_map]
  have h:=selector_jobs (n+1) (3*(n+1)-4)
  have hs:3*(n+1)-4≤3*(n+1):=Nat.sub_le ..
  have hm:=Nat.mul_le_mul hs (Nat.pow_le_pow_left (show n+1+(3*(n+1)-4)≤4*(n+1) by omega) 2)
  nlinarith

theorem support_gate (D : List Row) (m : Nat) (b : Bool) (xs : List Int) :
    (RecordedSupportSelection.gate D m b xs).length=xs.length+1 := by
  rw [RecordedSupportSelection.gate,ConstructionFrontendCountTools.gate_length]
  cases b <;> simp [REDWitness.andGate,REDWitness.orGate]

theorem support_ands (D : List Row) (m : Nat) (f : Int→Int) (xs : List Int) :
    (RecordedSupportSelection.ands D m f xs).length=3*xs.length := by
  induction xs generalizing D m with
  | nil=>rfl
  | cons x xs ih=>
    rw [RecordedSupportSelection.ands,List.length_append,support_gate,ih,List.length_cons]
    simp only [List.length_cons,List.length_nil];omega

theorem support_selection (D : List Row) (m : Nat) (xs : List Int) (f : Int→Int) :
    (RecordedSupportSelection.program D m xs f).length=6*xs.length+1 := by
  simp only [RecordedSupportSelection.program,RecordedSupportSelection.definitions,
    List.length_append,support_ands,support_gate,polProgram_length,
    ConstructionCofactorCount.value_lines,SelectedValue.terms,List.length_map,SelectedValueSize.cells_length]
  omega

theorem raw_block (n : Nat) (hn : 2≤n) (D : List Row) (j : RawValueBank.Job) :
    (RecordedRawValues.blockProgram n hn D j).length=6*(3*(n+1)-5)+1 := by
  rw [RecordedRawValues.blockProgram,support_selection,RawBankSize.choices_length n hn]
  rfl

theorem raw_run (n : Nat) (hn : 2≤n) (D : List Row) (js : List RawValueBank.Job) :
    (RecordedRawValues.runProgram n hn D js).length=js.length*(6*(3*(n+1)-5)+1) := by
  induction js generalizing D with
  | nil=>simp [RecordedRawValues.runProgram]
  | cons j js ih=>rw [RecordedRawValues.runProgram,List.length_append,raw_block,ih,List.length_cons];ring

theorem raw (n : Nat) (hn : 2≤n) :
    (RecordedRawValues.program n hn).length≤57*(n+1)^2*2^n := by
  rw [RecordedRawValues.program,raw_run,RawBankSize.jobs_length]
  have hw:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hh:6*(3*(n+1)-5)+1≤19*(n+1):=by omega
  have h:=Nat.mul_le_mul hw hh
  have ht:=Nat.mul_le_mul_right (2^n) h
  simp only [FamilyNamespace.truthRows]
  nlinarith

#print axioms gamma_jobs
#print axioms selector
#print axioms raw
end L3Emitter.ConstructionTransportCount

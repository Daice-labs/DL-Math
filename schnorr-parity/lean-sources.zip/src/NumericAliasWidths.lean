import NumericNetworkWidths
namespace L3Emitter.NumericNetworkWidths
open EREF EREF.GeneralRED AliasNetwork AliasAssembly
variable {base:List Row}

def aliasWidth (k:Nat):Nat:=10*(k+1)^2

theorem choice_length (k:Nat) (hk:3≤k) (b:Bool) (g:Nat):
    (choiceSupport k hk b g).length≤9*k^2:=by
  unfold choiceSupport;rw[List.length_map]
  exact (List.length_filter_le _ _).trans (ForcingSize.chosen_bound k hk)

theorem context_keeps (k:Nat) (hk:3≤k):Keeps (aliasWidth k) (AliasAssembly.context (base:=base) k hk):=by
  have h2:2≤aliasWidth k:=by unfold aliasWidth;nlinarith
  have hchoice:9*k^2≤aliasWidth k:=by unfold aliasWidth;nlinarith
  have hs:3*k-4≤aliasWidth k:=by unfold aliasWidth;nlinarith[Nat.sub_le (3*k) 4]
  have hr:RankConstruction.width k≤aliasWidth k:=by unfold RankConstruction.width;omega
  apply bind_keeps _ _ _ (gate_keeps _ true [] (by simp))
  intro T
  apply bind_keeps _ _ _
    (tabulate_keeps _ _ _ (fun g=>gate_keeps _ false _ ((choice_length k hk true g.val).trans hchoice)))
  intro beta
  apply bind_keeps _ _ _
    (tabulate_keeps _ _ _ (fun g=>gate_keeps _ false _ ((choice_length k hk false g.val).trans hchoice)))
  intro gamma
  apply bind_keeps _ _ _
    (tabulate_keeps _ _ _ (fun g=>gate_keeps _ false _ (by simpa using hr)))
  intro kept
  apply bind_keeps _ _ _ (tabulate_keeps _ _ _ (fun g=>select_keeps _ h2 _ (by
    simp only[List.length_map,List.length_range];have h:=g.isLt;omega)))
  intro hit
  exact pure_keeps _ _

theorem program_keeps (k:Nat) (hk:3≤k):Keeps (aliasWidth k) (AliasAssembly.program (base:=base) k hk):=by
  intro z hz
  let c:=AliasAssembly.context k hk z
  have hc:=context_keeps k hk z hz
  have he:c.1.k=k:=rfl
  have hr:=run_keeps (aliasWidth k) (by unfold aliasWidth;nlinarith) c.1 (inputAliases (width k) c.1) 0 (3*k-4) (by
    rw[he];unfold aliasWidth;have h:=Nat.sub_le (3*k) 4;nlinarith) c.2 hc
  exact hr

theorem built_width (n:Nat) (hn:2≤n):Width (aliasWidth (n+1)) (AliasAssembly.built n hn).2.gates:=
  program_keeps (n+1) (by omega) _ (by intro g hg;exact False.elim (List.not_mem_nil hg))

#print axioms built_width
end L3Emitter.NumericNetworkWidths

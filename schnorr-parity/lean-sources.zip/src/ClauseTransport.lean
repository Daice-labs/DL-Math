import LocalCombination
import CaseJoin

set_option linter.unusedSimpArgs false

namespace L3Emitter.ClauseTransport
open EREF REDWitness Resolution CaseJoin

/-- A reference to a guarded implication, or an unchanged literal. -/
inductive Link where
  | same (l : Int)
  | mapped (source target : Int) (rowId : Nat)
  deriving DecidableEq, Repr

def Link.source : Link → Int
  | .same l => l
  | .mapped a _ _ => a

def Link.target : Link → Int
  | .same l => l
  | .mapped _ b _ => b

def Link.row (g : Int) (p : Link) : Row := clause [g,-p.source,p.target]

def Link.tokens (g : Int) : Link → List Tok
  | .same _ => [.lit g,.add]
  | .mapped _ _ i => [.ref i,.add]

def Link.Available (db : Nat → Option Row) (g : Int) (p : Link) : Prop :=
  p.source ≠ 0 ∧ p.target ≠ 0 ∧
  match p with
  | .same _ => True
  | .mapped _ _ i => db i = some (p.row g)

theorem link_value (g : Int) (hg : g≠0) (p : Link)
    (ha : p.source≠0) (hb : p.target≠0) (α : Val) :
    (p.row g).val α = litVal α g-litVal α p.source+litVal α p.target := by
  rw [Link.row,val_clause _ (by simp [Valid,ha,hb,hg])]
  simp only [sum_cons,sum_nil,litVal_neg α p.source ha]
  ring

theorem same_row (g l : Int) (hg : g≠0) (hl : l≠0) :
    (Link.same l).row g = litAxiom g := by
  apply canonical_ext _ _ (canonical_normalize _ _) (canonical_litAxiom _)
  intro α
  change ((Link.same l).row g).val α = _
  rw [link_value g hg (.same l) hl hl,val_litAxiom g hg]
  simp [Link.source,Link.target]

def linkSteps (g : Int) (ls : List Link) : List Tok := ls.flatMap (Link.tokens g)

theorem linkSteps_eval (db : Nat → Option Row) (g : Int) (hg : g≠0)
    (ls : List Link) (ha : ∀ p∈ls,p.Available db g) (R : Row)
    (st : List Row) (tail : List Tok) :
    polEval db (linkSteps g ls++tail) (R::st) =
      polEval db tail (LocalCombination.chain R (ls.map (Link.row g))::st) := by
  induction ls generalizing R with
  | nil => rfl
  | cons p ps ih =>
    have hp := ha p (by simp)
    have hps : ∀ p∈ps,p.Available db g := by intro p h; exact ha p (by simp [h])
    cases p with
    | same l =>
      simp only [linkSteps,List.flatMap_cons,Link.tokens,List.append_assoc,
        List.cons_append,List.nil_append,polEval,hg,↓reduceIte,List.map_cons,
        LocalCombination.chain]
      rw [←same_row g l hg hp.1]
      rw [if_pos hg]
      exact ih hps _
    | mapped a b i =>
      simp only [Link.Available] at hp
      simp only [linkSteps,List.flatMap_cons,Link.tokens,List.append_assoc,
        List.cons_append,List.nil_append,polEval,hp.2.2,List.map_cons,
        LocalCombination.chain]
      exact ih hps _

def padSteps (xs : List Int) : List Tok := xs.flatMap (fun l => [.lit l,.add])

theorem padSteps_eval (db : Nat → Option Row) (xs : List Int) (hx : Valid xs)
    (R : Row) (st : List Row) (tail : List Tok) :
    polEval db (padSteps xs++tail) (R::st) =
      polEval db tail (LocalCombination.chain R (xs.map litAxiom)::st) := by
  induction xs generalizing R with
  | nil => rfl
  | cons x xs ih =>
    have hz := hx x (by simp)
    simp only [padSteps,List.flatMap_cons,List.append_assoc,List.cons_append,
      List.nil_append,polEval,hz,↓reduceIte,List.map_cons,LocalCombination.chain]
    rw [if_pos hz]
    exact ih (by intro l hl; exact hx l (by simp [hl])) _

def sourceClause (ls : List Link) : Row := clause (ls.map Link.source)
def targetClause (ls : List Link) : Row := clause (ls.map Link.target)
def padding (ls : List Link) : List Int :=
  (List.replicate (ls.length-1) (ls.map Link.target)).flatten

theorem padding_valid (ls : List Link) (h : ∀ p∈ls,p.target≠0) : Valid (padding ls) := by
  intro l hl
  obtain ⟨xs,hxs,hl⟩ := List.mem_flatten.mp hl
  have hx := (List.mem_replicate.mp hxs).2
  subst xs
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hl
  exact h p hp

theorem padding_sum (ls : List Link) (α : Val) :
    sum α (padding ls) = (ls.length-1 : Nat)*(sum α (ls.map Link.target)) := by
  have gen : ∀ (m : Nat) (xs : List Int),
      sum α ((List.replicate m xs).flatten) = m*sum α xs := by
    intro m xs
    induction m with
    | zero => simp [sum]
    | succ m ih => simp [List.replicate_succ,sum_append,ih]; ring
  exact gen _ _

theorem link_sum (ls : List Link) (g : Int) (hg : g≠0)
    (ha : ∀ p∈ls,p.source≠0 ∧ p.target≠0) (α : Val) :
    ((ls.map (Link.row g)).map (fun R => R.val α)).sum =
      ls.length*litVal α g-sum α (ls.map Link.source)+sum α (ls.map Link.target) := by
  induction ls with
  | nil => simp
  | cons p ps ih =>
    have hp := ha p (by simp)
    have ht := ih (by intro p h; exact ha p (by simp [h]))
    simp only [List.map_cons,List.sum_cons,List.length_cons, Nat.cast_add,Nat.cast_one,
      sum_cons,link_value g hg p hp.1 hp.2,ht]
    ring

def combined (g : Int) (ls : List Link) : Row :=
  LocalCombination.chain
    (LocalCombination.chain (sourceClause ls) (ls.map (Link.row g)))
    ((padding ls).map litAxiom)

theorem combined_scaled (ls : List Link) (hne : ls≠[]) (g : Int) (hg : g≠0)
    (ha : ∀ p∈ls,p.source≠0 ∧ p.target≠0) :
    combined g ls = scaled ls.length (branch (targetClause ls) g) := by
  have hlen : 0<ls.length := List.length_pos_iff.mpr hne
  have hs : Valid (ls.map Link.source) := by
    intro l hl; obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hl; exact (ha p hp).1
  have ht : Valid (ls.map Link.target) := by
    intro l hl; obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hl; exact (ha p hp).2
  have hp := padding_valid ls (by intro p h; exact (ha p h).2)
  apply canonical_ext _ _
    (LocalCombination.chain_canonical _ _ (LocalCombination.chain_canonical _ _
      (canonical_normalize _ _)))
    (canonical_scaled _ hlen _ (canonical_normalize _ _))
  intro α
  change (combined g ls).val α = (scaled ls.length (branch (targetClause ls) g)).val α
  have hpad : (((padding ls).map litAxiom).map (fun R => R.val α)).sum =
      sum α (padding ls) := by
    simp only [List.map_map,sum]
    congr 1
    apply List.map_congr_left
    intro l hl
    exact val_litAxiom l (hp l hl) α
  have hsc : Canonical (sourceClause ls) := canonical_normalize _ _
  rw [combined,LocalCombination.chain_value
    (LocalCombination.chain (sourceClause ls) (ls.map (Link.row g)))
    ((padding ls).map litAxiom)
    (LocalCombination.chain_canonical (sourceClause ls) _ hsc)
    (by intro R h; obtain ⟨l,hl,rfl⟩:=List.mem_map.mp h; exact canonical_litAxiom _),
    LocalCombination.chain_value (sourceClause ls) (ls.map (Link.row g)) hsc
    (by intro R h; obtain ⟨p,hp,rfl⟩:=List.mem_map.mp h; exact canonical_normalize _ _),
    sourceClause,val_clause _ hs,link_sum ls g hg ha,hpad,padding_sum,
    val_scaled, val_branch (targetClause ls) (canonical_normalize _ _) g hg]
  have hv := val_clause _ ht α
  change (targetClause ls).val α = _ at hv
  unfold Row.val at hv
  have hn : ((ls.length-1:Nat):Int) = (ls.length:Int)-1 := by omega
  rw [hn]
  nlinarith

/-- Total POL transport, including weakening and division. The length of
    the clause is arbitrary; no branching over assignments or RUP search. -/
def tokens (sourceId : Nat) (g : Int) (ls : List Link) : List Tok :=
  [.ref sourceId]++linkSteps g ls++padSteps (padding ls)++[.div ls.length]

theorem succeeds (db : Nat → Option Row) (sourceId : Nat) (g : Int)
    (hg : g≠0) (ls : List Link) (hne : ls≠[])
    (hsource : db sourceId=some (sourceClause ls))
    (hlinks : ∀ p∈ls,p.Available db g) :
    polEval db (tokens sourceId g ls) [] = some (branch (targetClause ls) g) := by
  have hm : 0<ls.length := List.length_pos_iff.mpr hne
  simp only [tokens,List.append_assoc,List.cons_append,List.nil_append,polEval,hsource]
  rw [linkSteps_eval db g hg ls hlinks,
    padSteps_eval db _ (padding_valid ls (by intro p hp; exact (hlinks p hp).2.1))]
  change polEval db [.div ls.length] [combined g ls] = _
  rw [combined_scaled ls hne g hg (by intro p hp; exact ⟨(hlinks p hp).1,(hlinks p hp).2.1⟩)]
  simp only [polEval,hm,↓reduceIte]
  rw [divide_scaled ls.length hm (branch (targetClause ls) g) (canonical_normalize _ _)]

theorem token_count (sourceId : Nat) (g : Int) (ls : List Link) :
    (tokens sourceId g ls).length = 2+2*ls.length+2*((ls.length-1)*ls.length) := by
  have hl : (linkSteps g ls).length=2*ls.length := by
    induction ls with
    | nil => rfl
    | cons p ps ih => cases p <;> simp [linkSteps,Link.tokens] at * <;> omega
  have hp : ∀ xs, (padSteps xs).length=2*xs.length := by
    intro xs
    induction xs with
    | nil => rfl
    | cons x xs ih => simp [padSteps] at *; omega
  have hpad : (padding ls).length=(ls.length-1)*ls.length := by
    simp [padding,List.length_flatten,List.map_replicate]
  simp only [tokens,List.length_append,List.length_cons,List.length_nil,hl,hp,hpad]
  omega

#print axioms succeeds
#print axioms token_count
end L3Emitter.ClauseTransport

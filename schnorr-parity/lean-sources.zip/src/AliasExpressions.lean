import AliasCoordinates

namespace L3Emitter.AliasNetwork
open EREF EREF.GeneralRED AliasGateSemantics
variable {base : List Row}

/-- Small expressions only describe one newly built coordinate. Earlier
    aliases enter as literal references, so their constructions are not copied. -/
inductive Expr where
  | lit : Bit→Expr
  | and : Expr→Expr→Expr
  | or : Expr→Expr→Expr
  | mux : Expr→Expr→Expr→Expr

def Expr.value (α : Val) : Expr→Bool
  | .lit b => eval α b
  | .and a b => a.value α && b.value α
  | .or a b => a.value α || b.value α
  | .mux c a b => if c.value α then a.value α else b.value α

def Expr.compile : Expr→StateM (Net base) Bit
  | .lit b => pure b
  | .and a b => do
    let x ← a.compile
    let y ← b.compile
    AND [x,y]
  | .or a b => do
    let x ← a.compile
    let y ← b.compile
    OR [x,y]
  | .mux c a b => do
    let x ← c.compile
    let y ← a.compile
    let z ← b.compile
    MUX x y z

theorem Expr.extends (e : Expr) : Extends (e.compile (base:=base)) := by
  induction e with
  | lit b => exact pure_extends b
  | and a b ha hb =>
    exact bind_extends _ _ ha (fun x=>bind_extends _ _ hb (fun y=>gate_extends true _))
  | or a b ha hb =>
    exact bind_extends _ _ ha (fun x=>bind_extends _ _ hb (fun y=>gate_extends false _))
  | mux c a b hc ha hb =>
    exact bind_extends _ _ hc (fun x=>bind_extends _ _ ha (fun y=>
      bind_extends _ _ hb (fun z=>mux_extends x y z)))

theorem Expr.spec (α : Val) (e : Expr) :
    Spec α (e.compile (base:=base)) (fun q=>eval α q=e.value α) := by
  induction e with
  | lit b => exact pure_spec α b _ rfl
  | and a b ha hb =>
    refine bind_spec α a.compile (fun x=>do let y ← b.compile; AND [x,y]) _ _
      (fun x=>bind_extends _ _ b.extends (fun y=>gate_extends true _)) ha ?_
    intro x hx
    refine bind_spec α b.compile (fun y=>AND [x,y]) _ _ (fun y=>gate_extends true _) hb ?_
    intro y hy
    exact spec_mono α _ _ _ (and_spec α [x,y]) (by intro q h;simpa [Expr.value,hx,hy] using h)
  | or a b ha hb =>
    refine bind_spec α a.compile (fun x=>do let y ← b.compile; OR [x,y]) _ _
      (fun x=>bind_extends _ _ b.extends (fun y=>gate_extends false _)) ha ?_
    intro x hx
    refine bind_spec α b.compile (fun y=>OR [x,y]) _ _ (fun y=>gate_extends false _) hb ?_
    intro y hy
    exact spec_mono α _ _ _ (or_spec α [x,y]) (by intro q h;simpa [Expr.value,hx,hy] using h)
  | mux c a b hc ha hb =>
    refine bind_spec α c.compile (fun x=>do
      let y ← a.compile
      let z ← b.compile
      MUX x y z) _ _
      (fun x=>bind_extends _ _ a.extends (fun y=>
        bind_extends _ _ b.extends (fun z=>mux_extends x y z))) hc ?_
    intro x hx
    refine bind_spec α a.compile (fun y=>do let z ← b.compile; MUX x y z) _ _
      (fun y=>bind_extends _ _ b.extends (fun z=>mux_extends x y z)) ha ?_
    intro y hy
    refine bind_spec α b.compile (fun z=>MUX x y z) _ _ (fun z=>mux_extends x y z) hb ?_
    intro z hz
    exact spec_mono α _ _ _ (mux_spec α x y z)
      (by intro q h;simpa [Expr.value,hx,hy,hz] using h)

def lookup (f : Bool→Bool→Bit) (a b : Expr) : Expr :=
  .mux a (.mux b (.lit (f true true)) (.lit (f true false)))
    (.mux b (.lit (f false true)) (.lit (f false false)))

theorem lookup_value (α : Val) (f : Bool→Bool→Bit) (a b : Expr) :
    (lookup f a b).value α=eval α (f (a.value α) (b.value α)) := by
  cases ha:a.value α <;> cases hb:b.value α <;> simp [lookup,Expr.value,ha,hb]

#print axioms Expr.extends
#print axioms Expr.spec
#print axioms lookup_value
end L3Emitter.AliasNetwork

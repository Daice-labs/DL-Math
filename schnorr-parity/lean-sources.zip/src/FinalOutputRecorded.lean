import FinalOutputDefinitions
import LoggedConstruction
namespace L3Emitter.FinalOutputRecorded
open EREF EREF.GeneralRED REDWitness AliasNetwork
open RecordedExpressions RecordedExpressionRun
variable {base : List Row}

def selector (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (FinalOutputDefinitions.W n-1)):Logged base Bit:=
  mux (FinalOutputDefinitions.H n hn) (LowerTransferImage.wire n hn (.sel (FinalOutputDefinitions.lastRank n) p.val i.val))
    (if p.val=0 then FinalOutputDefinitions.source n hn (FinalOutputDefinitions.coord n i)
     else if i.val=0 then (PrimaryAliasBank.cfg n hn).T else (PrimaryAliasBank.cfg n hn).F)
def port (n:Nat) (hn:2≤n) (xs:Fin (FinalOutputDefinitions.T n)→Bit) (p:Fin 2) (x:Fin (FinalOutputDefinitions.T n)):Logged base Bit:=
  mux (FinalOutputDefinitions.H n hn) (LowerTransferImage.wire n hn (.port (FinalOutputDefinitions.lastRank n) p.val x.val))
    (if p.val=0 then xs x else SourceCoordinateValue.value n hn ⟨0,by unfold AliasAssembly.width;omega⟩ x.val)
def function (n:Nat) (hn:2≤n) (ab:Fin 4):Logged base Bit:=
  RecordedExpressions.bind (mux (LowerTransferImage.wire n hn (.fn (FinalOutputDefinitions.lastRank n) ab.val))
    (FinalOutputDefinitions.unary n hn true) (FinalOutputDefinitions.unary n hn false)) (fun composed=>
  RecordedExpressions.bind (mux (FinalOutputDefinitions.H n hn) composed
    (if ab.val/2=0 then FinalOutputDefinitions.unary n hn false else FinalOutputDefinitions.unary n hn true)) (fun selected=>
  mux (OutputPhaseRows.phase n hn) (neg selected) selected))

theorem selector_binding (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (FinalOutputDefinitions.W n-1)):
    forget (selector (base:=base) n hn p i)=FinalOutputDefinitions.selector n hn p i:=rfl
theorem port_binding (n:Nat) (hn:2≤n) (xs:Fin (FinalOutputDefinitions.T n)→Bit) (p:Fin 2) (x:Fin (FinalOutputDefinitions.T n)):
    forget (port (base:=base) n hn xs p x)=FinalOutputDefinitions.port n hn xs p x:=rfl
theorem function_binding (n:Nat) (hn:2≤n) (ab:Fin 4):
    forget (function (base:=base) n hn ab)=FinalOutputDefinitions.function n hn ab:=rfl

theorem function_certified (n:Nat) (hn:2≤n) (ab:Fin 4):
    LoggedConstruction.Certified (function (base:=base) n hn ab):=by
  unfold function
  exact LoggedConstruction.bind _ _ (LoggedConstruction.mux _ _ _)
    (fun _=>LoggedConstruction.bind _ _ (LoggedConstruction.mux _ _ _) (fun _=>LoggedConstruction.mux _ _ _))

theorem function_correct (n:Nat) (hn:2≤n) (ab:Fin 4):Correct (function (base:=base) n hn ab):=
  (function_certified n hn ab).1

def construction (n:Nat) (hn:2≤n):Logged base (FinalOutputDefinitions.Data n):=
  RecordedExpressions.bind (lift (tabulate (FinalOutputDefinitions.T n) (FinalOutputDefinitions.out n hn))) (fun xs=>
  RecordedExpressions.bind (tabulateLog 2 (fun p=>tabulateLog (FinalOutputDefinitions.W n-1) (selector n hn p))) (fun ss=>
  RecordedExpressions.bind (tabulateLog 2 (fun p=>tabulateLog (FinalOutputDefinitions.T n) (port n hn xs p))) (fun ps=>
  RecordedExpressions.bind (tabulateLog 4 (function n hn)) (fun fs=>
  lift (pure ⟨xs,ss,ps,fs⟩)))))

theorem construction_binding (n:Nat) (hn:2≤n):
    forget (construction (base:=base) n hn)=FinalOutputDefinitions.construction n hn:=by
  simp only [construction,forget_bind,forget_lift,tabulate_binding,selector_binding,port_binding,function_binding,
    FinalOutputDefinitions.construction]

theorem construction_certified (n:Nat) (hn:2≤n):
    LoggedConstruction.Certified (construction (base:=base) n hn):=by
  unfold construction
  apply LoggedConstruction.bind _ _ (LoggedConstruction.lift _ (tabulate_extends _ _ (fun _=>select_extends _)))
  intro xs
  apply LoggedConstruction.bind _ _ (LoggedConstruction.tabulate _ _
    (fun _=>LoggedConstruction.tabulate _ _ (fun _=>LoggedConstruction.mux _ _ _)))
  intro ss
  apply LoggedConstruction.bind _ _ (LoggedConstruction.tabulate _ _
    (fun _=>LoggedConstruction.tabulate _ _ (fun _=>LoggedConstruction.mux _ _ _)))
  intro ps
  apply LoggedConstruction.bind _ _ (LoggedConstruction.tabulate _ _ (function_certified n hn))
  exact fun _=>LoggedConstruction.pure _

theorem construction_correct (n:Nat) (hn:2≤n):Correct (construction (base:=base) n hn):=
  (construction_certified n hn).1

def jobs (n:Nat) (hn:2≤n):List Job:=(construction n hn (FinalOutputDefinitions.initialNet n hn)).1.2

theorem jobs_ready (n:Nat) (hn:2≤n):∀j∈jobs n hn,Ready (FinalOutputDefinitions.result n hn) j:=by
  have h:=construction_correct (base:=FinalOutputDefinitions.base n hn) n hn (FinalOutputDefinitions.initialNet n hn)
  have hb:=congrArg Prod.snd (congrFun (construction_binding n hn) (FinalOutputDefinitions.initialNet n hn))
  have hb' : (construction n hn (FinalOutputDefinitions.initialNet n hn)).2=(FinalOutputDefinitions.built n hn).2 := by
    simpa only [forget,FinalOutputDefinitions.built] using hb
  simpa only [hb'] using h

def program (n:Nat) (hn:2≤n):=RecordedExpressions.program (FinalOutputDefinitions.result n hn) (jobs n hn)
def result (n:Nat) (hn:2≤n):=FinalOutputDefinitions.result n hn++(jobs n hn).flatMap jobRows

theorem checks (n:Nat) (hn:2≤n):AliasProgram.check (FinalOutputDefinitions.result n hn) (program n hn)=some (result n hn):=
  RecordedExpressions.checks _ _ (jobs_ready n hn)
theorem original_to_mux_relations (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalOutputDefinitions.original_to_definitions n hn) (AliasProgram.check_trace _ _ _ (checks n hn))
#print axioms construction_binding
#print axioms original_to_mux_relations
end L3Emitter.FinalOutputRecorded

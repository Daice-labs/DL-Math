import Mathlib.Tactic

/- Mathematical row-reference semantics of pinned database.rs: entry zero is
   reserved; next is entries.len(); negative references count back from next.
   Machine isize range and the Rust implementation refinement are separate. -/
namespace L3Emitter.NativeReference

def normalize (next : Nat) (ref : Int) : Int :=
  if ref < 0 then (next:Int)+ref else ref

def resolve (next : Nat) (ref : Int) : Option Nat :=
  let i := normalize next ref
  if 0 < i ∧ i < (next:Int) then some i.toNat else none

def relocate (offset : Nat) (ref : Int) : Int :=
  if ref < 0 then ref else ref+offset

theorem absolute (next id : Nat) (hp : 0 < id) (hlt : id < next) :
    resolve next (id:Int) = some id := by
  simp [resolve,normalize,show ¬(id:Int) < 0 by omega,show id≠0 by omega,
    show (id:Int) < next by omega]

theorem relative (next id : Nat) (hp : 0 < id) (hlt : id < next) :
    resolve next ((id:Int)-next) = some id := by
  have hn : (id:Int)-(next:Int) < 0 := by omega
  simp [resolve,normalize,hn,show id≠0 by omega,show (id:Int) < next by omega]

theorem last (next : Nat) (hn : 1 < next) :
    resolve next (-1) = some (next-1) := by
  have h := relative next (next-1) (by omega) (by omega)
  have he : ((next-1:Nat):Int)-(next:Int) = -1 := by omega
  rwa [he] at h

theorem normalize_relocate (next offset : Nat) (ref : Int) :
    normalize (next+offset) (relocate offset ref) = normalize next ref + offset := by
  by_cases hn : ref < 0
  · simp [relocate,normalize,hn]; omega
  · have hs : ¬ref+(offset:Int) < 0 := by omega
    simp [relocate,normalize,hn,hs]

theorem resolve_relocate (next offset id : Nat) (ref : Int)
    (h : resolve next ref = some id) :
    resolve (next+offset) (relocate offset ref) = some (id+offset) := by
  unfold resolve at h ⊢
  dsimp only at h ⊢
  split_ifs at h with hi
  · have he : (normalize next ref).toNat=id := Option.some.inj h
    rw [normalize_relocate]
    have hp : 0 < normalize next ref+(offset:Int) := by omega
    have hb : normalize next ref+(offset:Int) < ((next+offset:Nat):Int) := by omega
    simp only [hp,hb,and_self,↓reduceIte]
    congr 1
    omega

/-- A one-copy tail's relative references need no rewriting when a fixed
    prefix is prepended; absolute references must be shifted. -/
theorem relative_tail (next offset id : Nat) (hp : 0 < id) (hlt : id < next) :
    resolve (next+offset) ((id:Int)-next) = some (id+offset) := by
  have h := resolve_relocate next offset id ((id:Int)-next) (relative next id hp hlt)
  simpa [relocate,show (id:Int)-next < 0 by omega] using h

#print axioms resolve_relocate
#print axioms relative_tail
end L3Emitter.NativeReference

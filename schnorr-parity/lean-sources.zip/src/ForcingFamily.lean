import ForcingConstruction
import ForcingJoin

namespace L3Emitter.ForcingFamily
open EREF EREF.GeneralRED REDWitness RankProjection
open ForcingBinding ForcingProgram ForcingBounds ForcingConstruction

variable (k : Nat) (hk : 3≤k)

def bodies (m : Nat) : List (Choice (3*k-4))→List Row
  | [] => []
  | c::cs => body k hk c m++bodies (m+4) cs

def pairs (m : Nat) : List (Choice (3*k-4))→List (Int×List Int)
  | [] => []
  | c::cs => (c.lit,[(m+1:Int),(m+2:Int),(m+3:Int),(m+4:Int)])::pairs (m+4) cs

theorem pairs_choices (m : Nat) (cs : List (Choice (3*k-4))) :
    ForcingJoin.choices (pairs k m cs)=cs.map Choice.lit := by
  induction cs generalizing m with
  | nil => rfl
  | cons c cs ih => exact congrArg (List.cons c.lit) (ih (m+4))

theorem pairs_valid (m : Nat) (cs : List (Choice (3*k-4))) : ForcingJoin.valid (pairs k m cs) := by
  induction cs generalizing m with
  | nil => simp [pairs,ForcingJoin.valid]
  | cons c cs ih =>
    intro p hp;rcases List.mem_cons.mp hp with rfl|hp
    · refine ⟨c.nonzero,?_⟩
      intro l hl;simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
      rcases hl with rfl|rfl|rfl|rfl <;> omega
    · exact ih (m+4) p hp

theorem cases_present (m : Nat) (cs : List (Choice (3*k-4))) :
    ∀R∈ForcingJoin.rows (pairs k m cs),R∈bodies k hk m cs := by
  induction cs generalizing m with
  | nil => simp [pairs,ForcingJoin.rows]
  | cons c cs ih =>
    intro R hR
    simp only [pairs,ForcingJoin.rows,List.map_cons,List.mem_cons] at hR
    rcases hR with rfl|hR
    · apply List.mem_append_left
      simp [body,coverageRows,gate,ForcingPOL.Gate.target,ForcingPOL.Gate.qs]
    · exact List.mem_append_right _ (ih (m+4) _ hR)

theorem raw_bounded (m : Nat) (cs : List (Choice (3*k-4))) :
    L3.Bounded (m+4*cs.length) (ForcingJoin.literals (pairs k m cs)) := by
  induction cs generalizing m with
  | nil => simp [pairs,ForcingJoin.literals,L3.Bounded]
  | cons c cs ih =>
    intro l hl
    simp only [pairs,ForcingJoin.literals,List.flatMap_cons,List.mem_append] at hl
    rcases hl with hl|hl
    · simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
      rcases hl with rfl|rfl|rfl|rfl <;> norm_cast <;> simp only [List.length_cons] <;> omega
    · have h:=ih (m+4) l hl;simp only [List.length_cons];constructor <;> omega

theorem stage_trace (D : List Row) (m : Nat) (cs : List (Choice (3*k-4)))
    (hc : ∀c∈cs,c∈BranchChoices.chosen k hk) (hm : ceiling k hk≤m)
    (hD : L3.DBBounded D m) (hsub : ∀R∈FrontendSelection.finalRows k hk,R∈D) :
    CheckedTrace D (D++bodies k hk m cs) ∧ L3.DBBounded (D++bodies k hk m cs) (m+4*cs.length) := by
  induction cs generalizing D m with
  | nil => simpa [bodies] using And.intro (CheckedTrace.refl D) hD
  | cons c cs ih =>
    have hs:=step_trace D k hk c m (hc c (by simp)) hm hD hsub
    have ht:=ih (step D k hk c m) (m+4) (by intro a ha;exact hc a (by simp [ha]))
      (by omega) hs.2 (by intro R hR;exact List.mem_append_left _ (hsub R hR))
    constructor
    · simpa [step,bodies,List.append_assoc] using L3.Fam.checkedTrace_trans hs.1 ht.1
    · have he : m+4+4*cs.length=m+4*(c::cs).length := by simp;omega
      rw [he] at ht
      simpa [step,bodies,List.append_assoc] using ht.2

def raw (k : Nat) (hk : 3≤k) :=
  ForcingJoin.literals (pairs k (ceiling k hk) (BranchChoices.chosen k hk))
def stage (k : Nat) (hk : 3≤k) :=
  FrontendSelection.finalRows k hk++bodies k hk (ceiling k hk) (BranchChoices.chosen k hk)
def covered (k : Nat) (hk : 3≤k) := stage k hk++[clause (raw k hk)]
def upper (k : Nat) (hk : 3≤k) := ceiling k hk+4*(BranchChoices.chosen k hk).length

theorem original_to_covered :
    CheckedTrace (OriginalEncoding.rows k (3*k-4)) (covered k hk) ∧
    L3.DBBounded (covered k hk) (upper k hk) := by
  have hs:=stage_trace k hk (FrontendSelection.finalRows k hk) (ceiling k hk) (BranchChoices.chosen k hk)
    (by intros;assumption) (Nat.le_refl _) (front_bounded k hk) (by intros;assumption)
  have ha : clause (ForcingJoin.choices (pairs k (ceiling k hk) (BranchChoices.chosen k hk)))∈stage k hk := by
    rw [pairs_choices];exact List.mem_append_left _ (BranchChoices.chosen_onehot k hk).1
  have hr : ∀R∈ForcingJoin.rows (pairs k (ceiling k hk) (BranchChoices.chosen k hk)),R∈stage k hk :=
    fun R hR=>List.mem_append_right _ (cases_present k hk _ _ R hR)
  have he:=ForcingJoin.succeeds (stage k hk) _ (pairs_valid k _ _) ha hr
  constructor
  · exact L3.Fam.checkedTrace_trans (FrontendSelection.original_to_selected_branches k hk).1
      (L3.Fam.checkedTrace_trans hs.1 (.cons (.pol _ _ _ he) (.refl _)))
  · exact hs.2.append (L3.clauseRow _) (raw_bounded k _ _)

def selected (k : Nat) (hk : 3≤k) := PrioritySelection.selected (covered k hk) (upper k hk) (raw k hk)

theorem raw_nonempty : raw k hk≠[] := by
  have hx:=(FableEncoding.fam k (3*k-4)).branchList_nonempty (by change 3≤3*k-4;omega)
    (FrontendSelection.prior k hk) (FrontendSelection.prior_good k hk)
  have hn : BranchChoices.chosen k hk≠[] := by
    intro he
    have hl:=BranchChoices.chosen_literals k hk
    rw [he] at hl
    have hlen:=congrArg List.length hl
    simp only [List.map_nil,List.length_nil,PriorityBank.choices,List.length_map,PriorityBank.nodes_length] at hlen
    exact hx (List.length_eq_zero_iff.mp hlen.symm)
  unfold raw
  cases he : BranchChoices.chosen k hk with
  | nil => exact False.elim (hn he)
  | cons c cs => simp [pairs,ForcingJoin.literals]

/-- Original formula to an explicit one-hot bank of forcing port/value choices.
    This is a constructed selection stage, not the whole recursive emitter. -/
theorem original_to_selected_forcing :
    CheckedTrace (OriginalEncoding.rows k (3*k-4)) (selected k hk) ∧
    clause (PriorityBank.choices (PriorityBank.nodes (upper k hk+1) (raw k hk)))∈selected k hk ∧
    (∀c∈PriorityBank.choices (PriorityBank.nodes (upper k hk+1) (raw k hk)),
     ∀d∈PriorityBank.choices (PriorityBank.nodes (upper k hk+1) (raw k hk)),c≠d→
       clause [-c,-d]∈selected k hk) := by
  have hs:=original_to_covered k hk
  have ht:=PrioritySelection.selection_trace (covered k hk) (upper k hk) (raw k hk) hs.2
    (raw_bounded k _ _) (raw_nonempty k hk) (by simp [covered])
  exact ⟨L3.Fam.checkedTrace_trans hs.1 ht.1,ht.2⟩

theorem body_count (m : Nat) (cs : List (Choice (3*k-4))) :
    (bodies k hk m cs).length=21*cs.length := by
  induction cs generalizing m with
  | nil => rfl
  | cons c cs ih => simp [bodies,body_length,ih];omega

#print axioms original_to_selected_forcing
#print axioms body_count
end L3Emitter.ForcingFamily

import L3FrontendLemmas

namespace L3
open EREF EREF.GeneralRED

/-- Every collected RUP obligation is discharged against its actual database. -/
def ObligationsChecked (D : List EREF.Row) (cs : List Cmd) : Prop :=
  ∀ o ∈ obls D cs, Refutation (o.1 ++ [negate (clauseRow o.2).toE])

theorem obligations_append (D : List EREF.Row) (xs ys : List Cmd)
    (hx : ObligationsChecked D xs)
    (hy : ObligationsChecked (exec D xs) ys) :
    ObligationsChecked D (xs ++ ys) := by
  intro o ho
  rw [obls_append] at ho
  rcases List.mem_append.mp ho with ho | ho
  · exact hx o ho
  · exact hy o ho

/-- Fold glue for the actual state-dependent command suffix, with its invariant.
    This does not assume the whole fold's obligations: only each individual step
    under the invariant, in the database produced by preceding commands. -/
theorem fold_obligations {σ α : Type} (D : List EREF.Row)
    (commands : σ → List Cmd) (step : σ → α → σ)
    (suffix : σ → α → List Cmd) (I : σ → Prop)
    (xs : List α)
    (hstep : ∀ t x, x ∈ xs → I t →
      commands (step t x) = commands t ++ suffix t x ∧
      I (step t x) ∧
      ObligationsChecked (exec D (commands t)) (suffix t x))
    (t : σ) (ht : I t) (hc : ObligationsChecked D (commands t)) :
    I (xs.foldl step t) ∧ ObligationsChecked D (commands (xs.foldl step t)) := by
  induction xs generalizing t with
  | nil => exact ⟨ht, hc⟩
  | cons x xs ih =>
    obtain ⟨he, hi, ho⟩ := hstep t x (by simp) ht
    have hnext : ObligationsChecked D (commands (step t x)) := by
      rw [he]
      exact obligations_append D _ _ hc ho
    exact ih (fun u y hy hu => hstep u y (by simp [hy]) hu) (step t x) hi hnext

#print axioms fold_obligations
end L3

import PrunedMuxEvaluation

namespace L3Emitter.LookupEvaluation
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL GuardedTree AliasProgram
variable {base:List Row}

def job (c a b:Bit) (z:Net base):RecordedExpressions.Job:=
  ⟨c,a,b,(AND [c,a] z).1,(AND [neg c,b] (AND [c,a] z).2).1,(MUX c a b z).1⟩
theorem job_ready (c a b:Bit) (z:Net base):RecordedExpressions.Ready (MUX c a b z).2.rows (job c a b z):=
  ConcreteMux.actual_inputs z c a b

def top (f:Bool→Bool→Bit) (b:Bit) (z:Net base):=MUX b (f true true) (f true false) z
def bottom (f:Bool→Bool→Bit) (b:Bit) (z:Net base):=MUX b (f false true) (f false false) (top f b z).2
def result (f:Bool→Bool→Bit) (a b:Bit) (z:Net base):=MUX a (top f b z).1 (bottom f b z).1 (bottom f b z).2
def innerJob (f:Bool→Bool→Bit) (b:Bit) (va:Bool) (z:Net base):=
  if va then job b (f true true) (f true false) z
  else job b (f false true) (f false false) (top f b z).2
def outerJob (f:Bool→Bool→Bit) (a b:Bit) (z:Net base):=
  job a (top f b z).1 (bottom f b z).1 (bottom f b z).2

theorem compiled (f:Bool→Bool→Bit) (a b:Bit) (z:Net base):
    result f a b z=(lookup f (.lit a) (.lit b)).compile z:=rfl

theorem inner_ready (f:Bool→Bool→Bit) (a b:Bit) (va:Bool) (z:Net base):
    RecordedExpressions.Ready (result f a b z).2.rows (innerJob f b va z):=by
  have keep:∀R∈(bottom f b z).2.rows,R∈(result f a b z).2.rows:=mux_extends _ _ _ _
  cases va
  · exact (job_ready b (f false true) (f false false) (top f b z).2).mono keep
  · exact (job_ready b (f true true) (f true false) z).mono
      (fun R h=>keep R (mux_extends _ _ _ (top f b z).2 R h))
theorem outer_ready (f:Bool→Bool→Bit) (a b:Bit) (z:Net base):
    RecordedExpressions.Ready (result f a b z).2.rows (outerJob f a b z):=job_ready ..

def innerTree (f:Bool→Bool→Bit) (b:Bit) (va vb v:Bool) (z:Net base):=
  PrunedMuxEvaluation.tree (innerJob f b va z) vb (.leaf (f va vb) v)
def tree (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base):=
  PrunedMuxEvaluation.tree (outerJob f a b z) va (innerTree f b va vb v z)

theorem root (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base):
    (tree f a b va vb v z).root=(result f a b z).1:=PrunedMuxEvaluation.root ..
theorem value (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base):
    (tree f a b va vb v z).value=v:=by
  rw [tree,PrunedMuxEvaluation.value,innerTree,PrunedMuxEvaluation.value];rfl

theorem ready (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base):
    (tree f a b va vb v z).Ready (result f a b z).2.rows:=by
  apply PrunedMuxEvaluation.ready _ _ _ _ (outer_ready f a b z)
  · apply PrunedMuxEvaluation.ready (innerJob f b va z) vb (.leaf (f va vb) v) _ (inner_ready f a b va z) True.intro
    cases va <;> cases vb <;> rfl
  · rw [innerTree,PrunedMuxEvaluation.root]
    cases va <;> rfl

theorem assumptions (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base) (D:List Row) (G:List Int)
    (ha:guarded G (sign va a)∈D) (hb:guarded G (sign vb b)∈D) (hf:guarded G (sign v (f va vb))∈D):
    (tree f a b va vb v z).Assumptions D G:=by
  apply PrunedMuxEvaluation.assumptions _ _ _ _ _ ha
  apply PrunedMuxEvaluation.assumptions
  · cases va <;> exact hb
  · intro x hx;obtain rfl:=List.mem_singleton.mp hx;exact hf

def guards (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool):=
  [-sign va a,-sign vb b,-sign v (f va vb)]
def seedRows (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool):=EvaluationCaseSeeds.rows [] (guards f a b va vb v)
def rows (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base):=
  seedRows f a b va vb v++(tree f a b va vb v z).rows (guards f a b va vb v)
def program (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base) (D:List Row):=
  EvaluationCaseSeeds.program D [] (guards f a b va vb v)++
    (tree f a b va vb v z).program (guards f a b va vb v) (D++seedRows f a b va vb v)

theorem checks (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base) (D:List Row)
    (hd:∀R∈(result f a b z).2.rows,R∈D):
    check D (program f a b va vb v z D)=some (D++rows f a b va vb v z) ∧
    guarded (guards f a b va vb v) (sign v (result f a b z).1)∈D++rows f a b va vb v z:=by
  let G:=guards f a b va vb v
  have hg:Valid G:=by simp [G,guards,Valid,sign_valid]
  have h0:=EvaluationCaseSeeds.checks D [] G (by simp [Valid]) hg
  have present (x:Int) (hx:x∈G):guarded G (-x)∈D++seedRows f a b va vb v:=by
    exact List.mem_append_right _ (by simpa only [List.nil_append] using EvaluationCaseSeeds.contains [] G x hx)
  have ha:guarded G (sign va a)∈D++seedRows f a b va vb v:=by
    simpa only [neg_neg] using present (-sign va a) (by simp [G,guards])
  have hb:guarded G (sign vb b)∈D++seedRows f a b va vb v:=by
    simpa only [neg_neg] using present (-sign vb b) (by simp [G,guards])
  have hf:guarded G (sign v (f va vb))∈D++seedRows f a b va vb v:=by
    simpa only [neg_neg] using present (-sign v (f va vb)) (by simp [G,guards])
  have hh:=assumptions f a b va vb v z _ G ha hb hf
  have h1:=(tree f a b va vb v z).checks _ G hg
    ((ready f a b va vb v z).mono (fun R h=>List.mem_append_left _ (hd R h))) hh
  refine ⟨?_,?_⟩
  · simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h1
  · have h:=(tree f a b va vb v z).output_mem (D++seedRows f a b va vb v) G hh
    simpa only [value,root,rows,List.append_assoc] using h

theorem output_rows (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base):
    guarded (guards f a b va vb v) (sign v (result f a b z).1)∈rows f a b va vb v z:=by
  apply List.mem_append_right
  have hv:=value f a b va vb v z
  have hi:=(PrunedMuxEvaluation.value (innerJob f b va z) vb (.leaf (f va vb) v))
  change (innerTree f b va vb v z).value=v at hi
  unfold tree PrunedMuxEvaluation.tree
  cases va <;> cases v <;> simp [hi,Tree.rows,Tree.value,GuardedGatePOL.value,sign,outerJob,job,result]

theorem count (f:Bool→Bool→Bit) (a b:Bit) (va vb v:Bool) (z:Net base) (D:List Row):
    (program f a b va vb v z D).length≤12:=by
  have h1:=PrunedMuxEvaluation.count (innerJob f b va z) vb (.leaf (f va vb) v)
  have h2:=PrunedMuxEvaluation.count (outerJob f a b z) va (innerTree f b va vb v z)
  rw [program,List.length_append,EvaluationCaseSeeds.commands_count,Tree.commands_count]
  change 2*3+(tree f a b va vb v z).count≤12
  change (innerTree f b va vb v z).count≤0+3 at h1
  change (tree f a b va vb v z).count≤(innerTree f b va vb v z).count+3 at h2
  omega

#print axioms checks
#print axioms compiled
#print axioms count
end L3Emitter.LookupEvaluation

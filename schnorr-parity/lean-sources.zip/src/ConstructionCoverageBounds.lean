import ConstructionFoldBounds
import RecordedFrontendComplete

namespace L3Emitter.ConstructionCoverageBounds
open EREF EREF.GeneralRED L3 L3.Fam RecordedScopedTrace CanonicalReplayEnvelope RecordedReplayCost
open ConstructionLocalTools ConstructionFoldBounds

/-- POL tokens per stored certificate, not bytes. -/
def cap (F : Fam) (g : Nat := 0) := 100*(F.k+F.s+g+1)

theorem chain (D : List EREF.Row) (c : List Int) (w : Nat) (rs : List L3.Row) :
    tokens (RecordedClauseChain.certificate D c w rs)=1+2*(w+rs.length) := RecordedClauseChain.tokens ..

theorem wire (F : Fam) (t : StI F.V) (g p j bit cb q : Nat) (D : List EREF.Row) :
    BoundedProgram (cap F g) (RecordedWireSplit.program F t g p j bit cb q D) := by
  apply split
  · unfold cap;omega
  · intro E c
    dsimp only [RecordedWireSplit.leaf,RecordedWireSplit.certificate]
    split <;> rw [chain] <;> simp only [predecessorActualRows,List.length_cons,List.length_nil] <;>
      unfold cap <;> omega

theorem portFinish (F : Fam) (t : StI F.V) (g p cb q : Nat) :
    BoundedProgram (cap F g) (RecordedPortFinish.program F t g p cb q) := by
  intro c hc
  rcases List.mem_cons.mp hc with rfl|hc
  · apply consequence
    dsimp only [RecordedPortFinish.coverCertificate]
    rw [chain]
    simp only [List.length_append,List.length_map,List.length_range',List.length_cons,List.length_nil]
    unfold cap;omega
  · obtain rfl:=List.mem_singleton.mp hc
    apply consequence
    dsimp only [RecordedPortFinish.forceCertificate]
    rw [chain]
    simp only [List.length_cons,List.length_nil]
    unfold cap;omega

theorem portStep (F : Fam) (hm : 1≤F.V) (t : StI F.V) (g p bit cb : Nat) :
    BoundedProgram (cap F g) (RecordedPortStep.program F hm t g p bit cb) := by
  apply append
  · apply append
    · exact CanonicalFamilyEnvelope.bounded_mono 3 _ _ (by unfold cap;omega) (suffix _ _ _ _)
    · exact fold _ _ _ _ _ (fun u j=>wire F u g p j bit cb _ _)
  · exact portFinish F _ g p cb _

theorem gate (F : Fam) (hk : 2≤F.k) (hm : 1≤F.V) (bit cb g : Nat) (t : StI F.V) :
    BoundedProgram (cap F g) (RecordedGateStep.program F hm bit cb t g) := by
  apply append
  · exact CanonicalFamilyEnvelope.bounded_mono 3 _ _ (by unfold cap;omega) (suffix _ _ _ _)
  · dsimp only [RecordedGateStep.finish]
    split
    · apply split
      · unfold cap;omega
      · intro D c
        calc
          _ = 8*F.k+21 := RecordedSplitCost.first_leaf_tokens F hk D bit cb _ _
          _ ≤ cap F g := by unfold cap;omega
    · apply append
      · exact append _ _ _ (portStep F hm _ g 0 bit cb) (portStep F hm _ g 1 bit cb)
      · apply split
        · unfold cap;omega
        · intro D c
          exact (RecordedSplitCost.gate_leaf_tokens F _ g bit cb _ _ D c).trans (by unfold cap;omega)

theorem order (F : Fam) (hk : 2≤F.k) (hm : 1≤F.V) (bit cb : Nat) (t : StI F.V) (m : Nat) :
    BoundedProgram (cap F m) (RecordedGateOrder.program F hm bit cb t m) := by
  induction m with
  | zero=>exact empty _
  | succ m ih=>
    apply append
    · exact CanonicalFamilyEnvelope.bounded_mono _ _ _ (by unfold cap;omega) ih
    · exact CanonicalFamilyEnvelope.bounded_mono _ _ _ (by unfold cap;omega) (gate F hk hm bit cb m _)

theorem bit (F : Fam) (hk : 2≤F.k) (hm : 1≤F.V) (t : StI F.V) (b : Nat) :
    BoundedProgram (cap F F.s) (RecordedBitStep.program F hm t b) := by
  apply append
  · apply append
    · exact CanonicalFamilyEnvelope.bounded_mono 3 _ _ (by unfold cap;omega) (suffix _ _ _ _)
    · exact order F hk hm b _ _ F.s
  · apply ConstructionFoldBounds.singleton
    apply consequence
    dsimp only [RecordedBitStep.certificate]
    rw [chain]
    simp only [List.length_cons,List.length_nil]
    unfold cap;omega

theorem merge (F : Fam) (t : StI F.V) (c0 c1 : Nat) :
    BoundedProgram (cap F F.s) (RecordedMergeFinish.program F t c0 c1) := by
  apply append
  · apply split
    · unfold cap;omega
    · intro D c
      dsimp only [RecordedCoverageMerge.leaf,RecordedCoverageMerge.certificate]
      rw [chain]
      simp only [List.length_cons,List.length_nil]
      unfold cap;omega
  · apply ConstructionFoldBounds.singleton
    apply consequence
    dsimp only [RecordedMergeFinish.finalCertificate]
    rw [chain]
    simp only [List.length_cons,List.length_nil]
    unfold cap;omega

theorem stage5 (F : Fam) (hk : 2≤F.k) (hm : 1≤F.V) (t : StI F.V) :
    BoundedProgram (cap F F.s) (RecordedStage5.program F hm t) :=
  append _ _ _ (append _ _ _ (bit F hk hm t 0) (bit F hk hm _ 1)) (merge F _ _ _)

#print axioms stage5
#print axioms order
end L3Emitter.ConstructionCoverageBounds

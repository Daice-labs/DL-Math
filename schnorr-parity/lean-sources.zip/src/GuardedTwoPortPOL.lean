import GateUnaryCompositionPOL
namespace L3Emitter.GuardedTwoPortPOL
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL ReferenceTransport ClauseTransport

def source (g side a b q:Int):Row:=clause [g,side,a,b,q]
def target (g side a b q:Int):Row:=clause [g,side,a,b,q]
def links (D:List Row) (g side a b a' b' q:Int):List Link:=
  [.same side,.mapped a a' (locate D (clause [g,-a,a'])),.mapped b b' (locate D (clause [g,-b,b'])),.same q]
def tape (D:List Row) (g side a b a' b' q:Int):List Tok:=
  GuardedTransport.tokens (locate D (source g side a b q)) g (links D g side a b a' b' q)
theorem checks (D:List Row) (g side a b a' b' q:Int)
    (hg:g≠0) (hs:side≠0) (ha:a≠0) (hb:b≠0) (ha':a'≠0) (hb':b'≠0) (hq:q≠0)
    (h0:source g side a b q∈D) (h1:clause [g,-a,a']∈D) (h2:clause [g,-b,b']∈D):
    polEval (dbOf D) (tape D g side a b a' b' q) []=some (target g side a' b' q):=by
  have he:Resolution.branch (sourceClause (links D g side a b a' b' q)) g=source g side a b q:=by
    simp only [sourceClause,links,List.map_cons,List.map_nil,Link.source]
    rw [ProjectionTrace.branch_clause _ (by simp [Valid,hs,ha,hb,hq]) _ hg]
    rfl
  have ht:Resolution.branch (targetClause (links D g side a b a' b' q)) g=target g side a' b' q:=by
    simp only [targetClause,links,List.map_cons,List.map_nil,Link.target]
    rw [ProjectionTrace.branch_clause _ (by simp [Valid,hs,ha',hb',hq]) _ hg]
    rfl
  have hl:∀p∈links D g side a b a' b' q,p.Available (dbOf D) g:=by
    intro p hp;simp only [links,List.mem_cons,List.not_mem_nil,or_false] at hp
    rcases hp with rfl|rfl|rfl|rfl
    · exact ⟨hs,hs,True.intro⟩
    · exact ⟨ha,ha',locate_correct D _ h1⟩
    · exact ⟨hb,hb',locate_correct D _ h2⟩
    · exact ⟨hq,hq,True.intro⟩
  have h:=GuardedTransport.succeeds (dbOf D) (locate D (source g side a b q)) g (links D g side a b a' b' q) hg
    (by rw [he];exact locate_correct D _ h0) hl
  rw [ht] at h;exact h
#print axioms checks
end L3Emitter.GuardedTwoPortPOL

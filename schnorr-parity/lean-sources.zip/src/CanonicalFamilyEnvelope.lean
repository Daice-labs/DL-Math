import CanonicalFormulaEnvelope

namespace L3Emitter.CanonicalFamilyEnvelope
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation AuditLocalCosts
open CanonicalCountRecurrence CanonicalPrefixEnvelope CanonicalReplayEnvelope

/-- The actual new main-command count depends on the current reduction and
lower ORIGINAL formula only. The reserve of the accumulated tail does not
occur on the right-hand side. Unit: MAIN COMMANDS, not bytes. -/
theorem prefix_main (i : Nat) : (levelPrefix i).length=
    (RecordedCompleteLower.program (i+2) (by omega)).length+
      2*(ActualLowerComposition.inputs (i+2) (by omega)).length+1 := by
  unfold levelPrefix RecordedActualActivation.fullProgram
  rw [List.length_append,RecordedActualActivation.main_length]
  omega

theorem bounded_mono (a b : Nat) (p : Program) (h : a≤b)
    (hp : BoundedProgram a p) : BoundedProgram b p := by
  intro c hc q hq
  exact (hp c hc q hq).trans h

/-- Per-local-proof POL TOKEN ceiling after m recursive levels. Prefix
and base token ceilings remain explicit inputs, not assumed final theorems. -/
theorem local_tokens (m A B : Nat)
    (h0 : BoundedProgram B (RecordedUniformFamily.family 0))
    (ha : ∀i<m,BoundedProgram A (levelPrefix i)) :
    BoundedProgram (max A B+4*m) (RecordedUniformFamily.family m) := by
  induction m with
  | zero=>exact bounded_mono B (max A B+4*0) _ (by omega) h0
  | succ m ih=>
    have ht:=ih (by intro i hi;exact ha i (by omega))
    have hh:=successor_bound (m+2) A (max A B+4*m) (by omega)
      (RecordedUniformFamily.family m) ht (ha m (by omega))
    exact bounded_mono _ _ _ (by omega) hh

def mainBound (m A : Nat) := (RecordedUniformFamily.family 0).length+m*A

theorem main_bound (m A : Nat) (ha : ∀i<m,(levelPrefix i).length≤A) :
    (RecordedUniformFamily.family m).length≤mainBound m A := by
  rw [main_exact]
  exact Nat.add_le_add_left (main_sum_bound m A ha) _

def tokenBound (m B C : Nat) := max B C+4*m

def allocationBound (m A B C : Nat) :=
  2*mainBound m A+mainBound m A*
    (128*(m+3)^2*2^(m+2)+mainBound m A)*(tokenBound m B C+1)

/-- All physical row ALLOCATIONS, including rows deleted at scope exit.
This polynomial expression reduces the allocation issue to two remaining
prefix envelopes: main commands A and per-certificate POL tokens B. -/
theorem allocations (m A B C : Nat)
    (h0 : BoundedProgram C (RecordedUniformFamily.family 0))
    (ha : ∀i<m,(levelPrefix i).length≤A)
    (hb : ∀i<m,BoundedProgram B (levelPrefix i)) :
    NativeRecordedAllocation.program (RecordedUniformFamily.family m)≤allocationBound m A B C := by
  have hm:=main_bound m A ha
  have ht:=local_tokens m B C h0 hb
  have hf:=CanonicalFormulaEnvelope.original_rows (m+2)
  have he:RecordedUniformFamily.emitter (m+2)=RecordedUniformFamily.family m:=by
    simp [RecordedUniformFamily.emitter]
  have h:=CanonicalAllocationBound.family_allocation_bound (m+2) (tokenBound m B C)
    (by omega) (by simpa only [he,tokenBound] using ht)
  rw [he] at h
  apply h.trans
  unfold allocationBound
  have hr: (OriginalEncoding.rows (m+2) (3*(m+2)-4)).length≤128*(m+3)^2*2^(m+2):=by
    simpa only [Nat.add_assoc] using hf
  exact Nat.add_le_add (Nat.mul_le_mul_left 2 hm)
    (Nat.mul_le_mul_right _ (Nat.mul_le_mul hm (Nat.add_le_add hr hm)))

#print axioms prefix_main
#print axioms local_tokens
#print axioms main_bound
#print axioms allocations
end L3Emitter.CanonicalFamilyEnvelope

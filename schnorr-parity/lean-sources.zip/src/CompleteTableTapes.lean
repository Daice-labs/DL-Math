import RankPortMainTapes
import RankValueMainTapes
import ComposedTableMainTapes
namespace L3Emitter.CompleteTableTapes
open EREF EREF.GeneralRED U2ConstructionSize MainTapeRecurrence

def Q (n : Nat):Nat:=(n+1)^6*2^n

theorem lift (n c p t : Nat) (hp:p≤6) (ht:t≤1) :
    c*(n+1)^p*(2^n)^t≤c*Q n := by
  have h1:=Nat.pow_le_pow_right (show 0<n+1 by omega) hp
  have h2:=Nat.pow_le_pow_right (show 0<2^n by positivity) ht
  exact (Nat.mul_le_mul (Nat.mul_le_mul_left c h1) h2).trans_eq (by unfold Q;simp;ring)

/-- Every main POL tape in all six actual table-transport banks.
Fresh-definition local certificates are counted separately by C and L. -/
theorem complete (n : Nat) (hn : 2≤n) :
    count (RecordedTableTransport.program n hn)≤60000*Q n := by
  have h0:count (RecordedRankPorts.program n hn)≤30000*Q n:= (RankPortMainTapes.complete n hn).trans (by simpa using lift n 30000 6 0 (by omega) (by omega))
  have h1:count (RecordedRankPortValues.program n hn)≤11040*Q n:= (RankValueMainTapes.values n hn).trans (by simpa using lift n 11040 3 1 (by omega) (by omega))
  have h2:count (RecordedRawLowerInputs.program n hn)≤792*Q n:= (CoordinateMainTapes.raw n hn).trans (by simpa using lift n 792 3 1 (by omega) (by omega))
  have h3:tokens (RawUnaryBank.program n hn)≤1200*Q n:= (RankValueMainTapes.raw_unary n hn).trans (by simpa using lift n 1200 2 1 (by omega) (by omega))
  have h4:count (RecordedComposedTables.program n hn)≤7200*Q n:= (ComposedTableMainTapes.complete n hn).trans (by simpa using lift n 7200 1 0 (by omega) (by omega))
  have h5:count (RecordedRankTables.program n hn)≤900*Q n:= (CoordinateMainTapes.tables n hn).trans (by simpa using lift n 900 3 0 (by omega) (by omega))
  simp only [RecordedTableTransport.program,RecordedTableTransport.p5,RecordedTableTransport.p4,
    RecordedTableTransport.p3,RecordedTableTransport.p2,RecordedTableTransport.p1,RecordedTableTransport.p0,
    append,pol_program]
  change count _+count _+count _+tokens _+count _+count _≤_
  omega

theorem in_formula (n : Nat) (hn : 2≤n) :
    count (RecordedTableTransport.program n hn)≤60000*(ConstructionFormulaScale.rows n)^7 := by
  exact (complete n hn).trans (by simpa only [Q,pow_one,Nat.one_mul,Nat.mul_assoc] using ConstructionFormulaScale.monomial n 6 1 60000 hn)
#print axioms complete
#print axioms in_formula
end L3Emitter.CompleteTableTapes

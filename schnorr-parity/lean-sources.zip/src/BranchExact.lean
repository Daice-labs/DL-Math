import BranchChoices

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def ExactBranch (b g r : Nat) (t : StI F.V) : Prop :=
  ∃q,Cmd.orDef q [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)]∈t.s.cmds ∧
    Cmd.andDef r [(t.s.eligible b:Int),(q:Int)]∈t.s.cmds ∧ 0<q ∧ 0<r

def branchRecords (m : Nat) : List (Nat×Nat) → List ((Nat×Nat)×Nat)
  | [] => []
  | p::ps => (p,m+2)::branchRecords (m+2) ps

theorem branchRecords_append (m : Nat) (ps qs : List (Nat×Nat)) :
    branchRecords m (ps++qs)=branchRecords m ps++branchRecords (m+2*ps.length) qs := by
  induction ps generalizing m with
  | nil => simp [branchRecords]
  | cons p ps ih =>
    simp only [List.cons_append,branchRecords,ih,List.length_cons]
    rw [show m+2+2*ps.length=m+2*(ps.length+1) by omega]

theorem ExactBranch_keeps {t u : StI F.V} (h : Keeps2 t u) (b g r : Nat)
    (he : F.ExactBranch b g r t) : F.ExactBranch b g r u := by
  obtain ⟨q,hq,hr,hqp,hrp⟩ := he
  refine ⟨q,?_,?_,hqp,hrp⟩
  · rw [h.2.1.2]; exact mem_of_grows h.1 hq
  · rw [h.2.2.2.2.2.1]; exact mem_of_grows h.1 hr

theorem branchStep_exact (t : StI F.V) (brs : List Int) (ht : F.Good3 t)
    (b g : Nat) (hb : 1≤b) (hbg : b<g) (hg : g<F.s) :
    F.ExactBranch b g (t.s.var+2) (F.branchStep b (t,brs) g).1 := by
  have he0 : F.PEdge b g 0 t := (ht.2.1 b (by omega)).2 (g,0)
    ((F.mem_edgePairs b (g,0)).mpr ⟨by omega,hg,by simp⟩)
  have he1 : F.PEdge b g 1 t := (ht.2.1 b (by omega)).2 (g,1)
    ((F.mem_edgePairs b (g,1)).mpr ⟨by omega,hg,by simp⟩)
  obtain ⟨cons,hcons,helig,hconsL,heligL,heligU⟩ := ht.2.2.2.1 b hb (by omega)
  have hx : Bounded t.s.var [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)] := by
    intro l hl
    have h0:=he0.2;have h1:=he1.2
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl <;> simp <;> omega
  let u := (t.OR [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)]).2
  have hy : Bounded u.s.var [(t.s.eligible b:Int),((t.s.var+1:Nat):Int)] := by
    change Bounded (t.s.var+1) _
    intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl <;> simp <;> omega
  refine ⟨t.s.var+1,?_,?_,by omega,by omega⟩
  · change Cmd.orDef (t.s.var+1) [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)]∈(t.s.cmds++[.orDef _ (t.s.chk _)])++
      [.andDef _ (u.s.chk _)]
    rw [StI.chk_eq t _ hx];simp
  · change Cmd.andDef (t.s.var+1+1) [(t.s.eligible b:Int),((t.s.var+1:Nat):Int)]∈u.s.cmds++
      [.andDef (t.s.var+1+1) (u.s.chk [(t.s.eligible b:Int),((t.s.var+1:Nat):Int)])]
    rw [StI.chk_eq u _ hy];simp

theorem branchFold_exact (b : Nat) (gs : List Nat) (a : StI F.V × List Int)
    (ht : F.Good3 a.1) (hb : 1≤b) (hgs : ∀g∈gs,b<g ∧ g<F.s) :
    ∀z∈branchRecords a.1.s.var (gs.map fun g => (b,g)),
      F.ExactBranch z.1.1 z.1.2 z.2 (gs.foldl (F.branchStep b) a).1 := by
  induction gs generalizing a with
  | nil => simp [branchRecords]
  | cons g gs ih =>
    intro z hz
    simp only [List.map_cons,branchRecords,List.mem_cons] at hz
    rcases hz with rfl|hz
    · apply F.ExactBranch_keeps (F.branchFold_keeps b gs (F.branchStep b a g))
      exact F.branchStep_exact a.1 a.2 ht b g hb (hgs g (by simp)).1 (hgs g (by simp)).2
    · have h := ih (F.branchStep b a g)
        (F.Good3_of_keeps2 (F.keeps2_branchStep b a g) ht)
        (by intro j hj;exact hgs j (by simp [hj])) z
      apply h
      rw [F.branchStep_var]
      exact hz

theorem branchBank_exact (bs : List Nat) (a : StI F.V × List Int)
    (ht : F.Good3 a.1) (hbs : ∀b∈bs,1≤b) :
    ∀z∈branchRecords a.1.s.var (F.branchPairs bs),
      F.ExactBranch z.1.1 z.1.2 z.2 (F.branchBank bs a).1 := by
  induction bs generalizing a with
  | nil => simp [branchPairs,branchRecords]
  | cons b bs ih =>
    intro z hz
    simp only [branchPairs,List.flatMap_cons,branchRecords_append,List.mem_append,
      List.length_map,List.length_range'] at hz
    rcases hz with hz|hz
    · apply F.ExactBranch_keeps (F.branchBank_keeps bs (F.bStep a b))
      exact F.branchFold_exact b _ a ht (hbs b (by simp))
        (by intro g hg;have h:=List.mem_range'_1.mp hg;omega) z hz
    · have h := ih (F.bStep a b) (F.Good3_of_keeps2 (F.keeps2_bStep a b) ht)
        (by intro j hj;exact hbs j (by simp [hj])) z
      apply h
      have hl := (F.branchFold_layout b (List.range' (b+1) (F.s-1-b)) a).1
      change (F.bStep a b).1.s.var=_ at hl
      simp only [List.length_range'] at hl
      rw [hl];exact hz

theorem frontend_exact (t : StI F.V) (ht : F.Good3 t) :
    ∀z∈branchRecords t.s.var (F.branchPairs F.branchIndices),
      F.ExactBranch z.1.1 z.1.2 z.2 (F.stage7 t) := by
  intro z hz
  have h := F.branchBank_exact F.branchIndices (t,[]) ht
    (by intro b hb;exact (List.mem_range'_1.mp hb).1) z hz
  have hu : Keeps2 (F.preparedBank t).1 (F.preparedBranches t) :=
    keeps2_trans (keeps2_OR _ _) (keeps2_setB _ _)
  apply F.ExactBranch_keeps (keeps2_trans hu
    (keeps2_trans (F.branchRups_keeps _ _) (keeps2_rup _ _)))
  exact h

#print axioms frontend_exact
end L3.Fam

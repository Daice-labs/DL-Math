import NumericRecordedGates
import RecordedAllocationLoop
namespace L3Emitter.NumericAllocationLoop
open EREF EREF.GeneralRED FieldLengthsFromIDs

theorem program (M n:Nat) (base:List Row) (rows:Nat→List Row)
 (block:Nat→List Row→RecordedScopedTrace.Program)
 (hb:∀i<n,∀D,∀c∈block i D,Content M c):
 ∀c∈RecordedAllocationLoop.program base rows block n,Content M c:=by
 induction n with
 | zero=>simp [RecordedAllocationLoop.program]
 | succ n ih=>
   intro c hc;rcases List.mem_append.mp hc with hc|hc
   · exact ih (by intro i hi;exact hb i (by omega)) c hc
   · exact hb n (by omega) _ c hc
#print axioms program
end L3Emitter.NumericAllocationLoop

import NumericExpressionBank
import NumericPortBank
namespace L3Emitter.NumericAliasRelationRows
open EREF EREF.GeneralRED REDWitness AliasNetwork NumericNetwork

theorem port_job (M:Nat) (j:ConcretePortRows.Job) (h:NumericLoggedPorts.JobBound M j):
    RowSupport.Bounded M (ConcretePortRows.jobRows j):=by
  intro R hR
  obtain ⟨e,he,hR⟩:=List.mem_flatMap.mp hR
  have hc:=h.2 e he
  change R∈[clause [-e.choice.val,-e.value.val,j.q.val],clause [-e.choice.val,-j.q.val,e.value.val]] at hR
  simp only[List.mem_cons,List.not_mem_nil,or_false] at hR
  rcases hR with rfl|rfl
  · refine ⟨canonical_normalize _ _,RowSupport.clause_bound M _ ?_⟩
    intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl
    · simpa using hc.1
    · simpa using hc.2.1
    · exact h.1
  · refine ⟨canonical_normalize _ _,RowSupport.clause_bound M _ ?_⟩
    intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl
    · simpa using hc.1
    · simpa using h.1
    · exact hc.2.1

theorem expression_job (M:Nat) (j:RecordedExpressions.Job) (h:NumericLoggedExpressions.JobBound M j):
    RowSupport.Bounded M (RecordedExpressions.jobRows j):=by
  intro R hR
  simp only[RecordedExpressions.jobRows,List.mem_cons,List.not_mem_nil,or_false] at hR
  rcases hR with rfl|rfl|rfl|rfl <;>
    refine ⟨canonical_normalize _ _,RowSupport.clause_bound M _ ?_⟩ <;>
    intro l hl <;> simp only[List.mem_cons,List.not_mem_nil,or_false] at hl <;>
    rcases hl with rfl|rfl|rfl <;> (try simp only[Int.natAbs_neg]) <;>
    first | exact h.1 | exact h.2.1 | exact h.2.2.1 | exact h.2.2.2.2.2

theorem alias_network (n:Nat) (hn:2≤n):
    RowSupport.Bounded (NumericValueClosed.bound n) (AliasAssembly.built n hn).2.rows:=by
  have h:=(NumericAliasValues.before n hn (3*(n+1)-4) (by omega)).2
  have hle:CanonicalTrace.ceiling (AliasAssembly.built n hn).2.rows≤NumericValueClosed.bound n:=
    h.trans (le_trans (by unfold NumericAliasValues.fullCap;omega) (NumericValueClosed.full_bound n hn))
  exact RowSupport.mono _ hle (CanonicalTrace.bounded _ (AliasAssembly.built n hn).2.canonical)

theorem port_result (n:Nat) (hn:2≤n):
    RowSupport.Bounded (NumericValueClosed.bound n) (RecordedAliasRun.result n hn):=by
  apply RowSupport.append
  · rw[(RecordedAliasRun.built_binding n hn).2];exact alias_network n hn
  · intro R hR;obtain ⟨j,hj,hR⟩:=List.mem_flatMap.mp hR
    exact port_job _ j (NumericPortBank.actual n hn j hj) R hR

theorem expression_result (n:Nat) (hn:2≤n):
    RowSupport.Bounded (NumericValueClosed.bound n) (RecordedExpressionRun.result n hn):=by
  apply RowSupport.append _ _ _ (port_result n hn)
  intro R hR;obtain ⟨j,hj,hR⟩:=List.mem_flatMap.mp hR
  exact expression_job _ j (NumericExpressionBank.actual n hn j hj) R hR
#print axioms expression_result
end L3Emitter.NumericAliasRelationRows

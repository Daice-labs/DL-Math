import TransportBankMainTapes
namespace L3Emitter.AliasSelectorMainTapes
open EREF EREF.GeneralRED MainTapeRecurrence U2ConstructionSize GlobalFixedMainTapes

theorem pair (D : List Row) (xs : List Int) (a b : Int) :
    (SelectorPairs.tape D xs a b).length≤1+2*xs.length := by
  have h1:(xs.erase a).length≤xs.length:=List.length_erase_le
  have h2:((xs.erase a).erase b).length≤(xs.erase a).length:=List.length_erase_le
  simp [SelectorPairs.tape,SelectorPairs.rest,ClauseTransport.padSteps,List.length_flatMap]
  omega

theorem selectors (n : Nat) (hn : 2≤n) : tokens (SelectorBank.program n hn)≤864*(n+1)^4 := by
  have h:tokens (SelectorBank.sourceProgram (n+1) (3*(n+1)-4))≤
      (9*(n+1))*(SelectorBank.jobs (n+1) (3*(n+1)-4)).length:=by
    apply map_factor
    intro j hj
    have hg:=((SelectorBank.job_mem _ _ j).mp hj).1
    have hp:=pair (OriginalEncoding.rows (n+1) (3*(n+1)-4))
      (SelectorBank.selectors (n+1) (3*(n+1)-4) j.1 j.2.1)
      (SelectorBank.left (n+1) (3*(n+1)-4) j) (SelectorBank.right (n+1) (3*(n+1)-4) j)
    simp only [SelectorBank.selectors,List.length_map,List.length_range] at hp
    exact hp.trans (by omega)
  have hl:=ConstructionTransportCount.selector n hn
  simp only [SelectorBank.program,ForcingSize.rebase_length,SelectorBank.sourceProgram,List.length_map] at hl
  rw [SelectorBank.program,rebase]
  nlinarith [Nat.mul_le_mul_left (9*(n+1)) hl]

theorem aliases (n : Nat) (hn : 2≤n) : count (RecordedAliasBanks.program n hn)≤200000*(n+1)^6 := by
  have hp:=NetworkMainTokens.ports (RecordedAliasRun.built n hn).2.rows (RecordedAliasRun.built n hn).1.2
  have hm:=ConcretePortCost.built_count n hn
  rw [RecordedAliasRun.program,ConcretePortCost.program_count] at hm
  have h23:(n+1)^2≤(n+1)^3:=Nat.pow_le_pow_right (by omega) (by omega)
  have h3:ConcretePortCost.mass (RecordedAliasRun.built n hn).1.2≤144*(n+1)^3:=by nlinarith
  have hsq:=Nat.pow_le_pow_left h3 2
  have h36:(n+1)^3≤(n+1)^6:=Nat.pow_le_pow_right (by omega) (by omega)
  have h16:n+1≤(n+1)^6:=by
    have h:(n+1)^1≤(n+1)^6:=Nat.pow_le_pow_right (by omega) (by omega)
    simpa using h
  have he:=ConstructionAliasBankCount.expressions n hn
  have ht:=NetworkMainTokens.expressions (RecordedAliasRun.result n hn) (RecordedExpressionRun.built n hn).1.2
  change tokens (RecordedExpressionRun.program n hn)=4*(RecordedExpressionRun.program n hn).length at ht
  change tokens (RecordedAliasRun.program n hn)≤_ at hp
  rw [RecordedAliasBanks.program,append,append,RecordedAliasDefinitions.program,CompleteFinalRowTapes.network_zero,pol_program,pol_program]
  change 0+tokens (RecordedAliasRun.program n hn)+tokens (RecordedExpressionRun.program n hn)≤_
  nlinarith
#print axioms selectors
#print axioms aliases
end L3Emitter.AliasSelectorMainTapes

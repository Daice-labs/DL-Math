import NativeReference
import ReferenceTransport

/- Row-store projection of database.rs. This tracks allocation and deletion,
   including holes; it is not a proof of the Rust parser or propagator. -/
namespace L3Emitter.NativeSparseStore
open EREF EREF.GeneralRED
structure Store where
  next : Nat
  rows : Nat → Option Row

def initial (D:List Row) : Store :=  ⟨D.length+1,dbOf D⟩
def push (s:Store) (R:Row) : Store := 
  ⟨s.next+1,fun i => if i = s.next then some R else s.rows i⟩
def erase (s:Store) (i:Nat) : Option Store := 
  if i < s.next then
    match s.rows i with
    | none => none
    | some _ => some ⟨s.next,fun j => if j = i then none else s.rows j⟩
  else none

def closeFrom (s:Store) (mark:Nat) : Store := 
  ⟨s.next,fun i => if mark ≤ i then none else s.rows i⟩
def read (s:Store) (ref:Int) : Option Row := 
  (NativeReference.resolve s.next ref).bind s.rows

def Embeds (D:List Row) (s:Store) (ids:Nat → Nat) : Prop := 
  ∀i R,dbOf D i = some R → 0 < ids i ∧ ids i < s.next ∧ s.rows (ids i) = some R

theorem initial_embeds (D:List Row) : Embeds D (initial D) id :=  by
  intro i R h
  have hl:= dbOf_le_length D i R h
  have hp:0 < i:= by
    by_contra hh
    have hi:i = 0:= by omega
    simp [dbOf,hi] at h
  exact ⟨hp,by dsimp [initial];omega,h⟩

theorem read_absolute (D:List Row) (s:Store) (ids:Nat → Nat) (h:Embeds D s ids)
    (i:Nat) (R:Row) (hi:dbOf D i = some R) : read s (ids i:Int) = some R :=  by
  obtain ⟨hp,hl,hr⟩:= h i R hi
  simp [read,NativeReference.absolute s.next (ids i) hp hl,hr]

theorem pol_reindex (D:List Row) (s:Store) (ids:Nat → Nat) (h:Embeds D s ids)
    (ts:List Tok) (st:List Row) (R:Row) (he:polEval (dbOf D) ts st = some R) :
    polEval s.rows (ts.map (ReferenceTransport.token ids)) st = some R := 
  ReferenceTransport.reindex _ _ ids (fun i R hi => (h i R hi).2.2) ts st R he

theorem push_preserves (D:List Row) (s:Store) (ids:Nat → Nat) (h:Embeds D s ids) (R:Row) :
    Embeds D (push s R) ids :=  by
  intro i Q hi
  obtain ⟨hp,hl,hr⟩:= h i Q hi
  exact ⟨hp,by dsimp [push];omega,by simpa [push,show ids i ≠ s.next by omega] using hr⟩

def extend (ids:Nat → Nat) (len next:Nat) : Nat → Nat:= 
  fun i => if i = len+1 then next else ids i

theorem push_embeds (D:List Row) (s:Store) (ids:Nat → Nat) (h:Embeds D s ids)
    (hs:0 < s.next) (R:Row) : Embeds (D++[R]) (push s R) (extend ids D.length s.next) :=  by
  intro i Q hi
  have hiL:= dbOf_le_length (D++[R]) i Q hi
  by_cases he:i = D.length+1
  · subst i
    have hQ:Q = R:= by
      simpa [dbOf] using hi.symm
    subst Q
    simp [extend,push,hs]
  · have hil:i ≤ D.length:= by simp at hiL;omega
    rw [dbOf_append_le D [R] i hil] at hi
    simpa [extend,he] using push_preserves D s ids h R i Q hi

theorem erase_next (s:Store) (i:Nat) (t:Store) (h:erase s i = some t) : t.next = s.next :=  by
  unfold erase at h
  split at h
  · split at h
    · contradiction
    · cases h; rfl
  · contradiction

theorem erase_keeps (s:Store) (i j:Nat) (t:Store) (h:erase s i = some t) (hne:j ≠ i) :
    t.rows j = s.rows j :=  by
  unfold erase at h
  split at h
  · split at h
    · contradiction
    · cases h; simp [hne]
  · contradiction

theorem close_preserves (D:List Row) (s:Store) (ids:Nat → Nat) (h:Embeds D s ids)
    (mark:Nat) (hm:∀i R,dbOf D i = some R → ids i < mark) : Embeds D (closeFrom s mark) ids :=  by
  intro i R hi
  obtain ⟨hp,hl,hr⟩:= h i R hi
  exact ⟨hp,hl,by simpa [closeFrom,show ¬mark ≤ ids i by have:= hm i R hi;omega] using hr⟩

theorem close_next (s:Store) (mark:Nat) : (closeFrom s mark).next = s.next :=  rfl

theorem push_closed_id (s:Store) (mark:Nat) (R:Row) :
    (push (closeFrom s mark) R).rows s.next = some R :=  by simp [push,closeFrom]

theorem reindex_tokens (ids:Nat → Nat) (ts:List Tok) :
    (ts.map (ReferenceTransport.token ids)).length = ts.length :=  by simp

#print axioms initial_embeds
#print axioms read_absolute
#print axioms pol_reindex
#print axioms push_embeds
#print axioms erase_next
#print axioms erase_keeps
#print axioms close_preserves
#print axioms push_closed_id
end L3Emitter.NativeSparseStore

import CanonicalCheckedPOL

namespace L3Emitter.CanonicalNativePOLShape
open EREF

/-- Stack-size checks in the pinned v3 parser's pol_rule, restricted to the
emitted instruction subset. A coefficient followed by * or d is counted as
one temporary operand then consumed, so the resulting depth is unchanged.
This is the parser-shape obligation, not the optimized arithmetic refinement. -/
def shape : List Tok→Nat→Option Nat
  | [],d=>if d=1 then some 1 else none
  | .ref _::ts,d=>shape ts (d+1)
  | .lit _::ts,d=>shape ts (d+1)
  | .add::ts,d=>if 2≤d then shape ts (d-1) else none
  | .mul k::ts,d=>if 1≤d ∧ 0<k then shape ts d else none
  | .div k::ts,d=>if 1≤d ∧ 0<k then shape ts d else none
  | .sat::ts,d=>if 1≤d then shape ts d else none

theorem checked_shape (db : Nat→Option Row) (ts : List Tok) (st : List Row) (R : Row)
    (h : polEval db ts st=some R) : shape ts st.length=some 1 := by
  induction ts generalizing st with
  | nil=>
    cases st with
    | nil=>simp [polEval] at h
    | cons a st=>
      cases st with
      | nil=>rfl
      | cons b st=>simp [polEval] at h
  | cons t ts ih=>
    cases t with
    | ref i=>
      simp only [polEval] at h
      split at h
      · exact ih _ h
      · contradiction
    | lit l=>
      simp only [polEval] at h
      split at h
      · exact ih _ h
      · contradiction
    | add=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        cases st with
        | nil=>simp [polEval] at h
        | cons b st=>simpa [shape] using ih (add b a::st) h
    | mul k=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        simp only [polEval] at h
        split at h
        · rename_i hk
          simpa [shape,hk] using ih (multiply a k::st) h
        · contradiction
    | div k=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        simp only [polEval] at h
        split at h
        · rename_i hk
          simpa [shape,hk] using ih (divide a k::st) h
        · contradiction
    | sat=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>simpa [shape] using ih (saturate a::st) h

/-- Byte parsing and the additional native stack-shape condition are both
entailed by successful checked POL execution. -/
theorem bytes_and_shape (db : Nat→Option Row) (hz : db 0=none) (ts : List Tok) (R : Row)
    (h : polEval db ts []=some R) :
    CanonicalPOLParser.parse (emit (separated (fixed " ")
      (ts.map (fun t=>polToken (CompactTapeBytes.token t)))))=some ts ∧ shape ts 0=some 1 :=
  ⟨CanonicalPOLParser.tape_roundtrip ts (CanonicalCheckedPOL.evaluated_valid db hz ts [] R h),
    checked_shape db ts [] R h⟩

#print axioms checked_shape
#print axioms bytes_and_shape
end L3Emitter.CanonicalNativePOLShape

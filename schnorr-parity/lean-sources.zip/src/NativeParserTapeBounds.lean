import NativeParserDepth
import ConstructionFamilyLocalBounds
import CanonicalFamilyMainTapes
namespace L3Emitter.NativeParserTapeBounds
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace CanonicalScopeKernel CanonicalFileGrammar
open CanonicalReplayEnvelope AuditLocalCosts

theorem member_sum (xs:List Nat) (x:Nat) (h:x∈xs):x≤xs.sum:=by
 induction xs with
 | nil=>simp at h
 | cons y ys ih=>
   rcases List.mem_cons.mp h with rfl|h
   · simp
   · have hh:=ih h;simp only [List.sum_cons];omega

theorem local_bound (B len:Nat) (s:Store) (ids:Nat→Nat) (G:Row) (p:RecordedRefutation.Certificate)
 (h:RecordedReplayCost.tokens p≤B):
 ∀ts∈(NativeScopedLocalGoal.compile len s ids G p).tapes,ts.length≤B:=by
 intro ts ht
 have hm:=member_sum ((NativeScopedLocalGoal.compile len s ids G p).tapes.map List.length)
   ts.length (List.mem_map.mpr ⟨ts,ht,rfl⟩)
 change _≤SerializedLocalBudget.tokens _ at hm
 rw [PhysicalTokenAccounting.local_tokens] at hm
 exact hm.trans h

theorem goals (B:Nat) (D:List Row) (C:Row) (w:FiniteWitness.Data) (s:Store) (ids:Nat→Nat)
 (rs:List Row) (ps:List RecordedRefutation.Certificate) (h:BoundedGoals B ps):
 ∀b∈(NativeREDGoalSequence.compile D C w s ids rs ps).blocks,∀ts∈b.2.tapes,ts.length≤B:=by
 induction rs generalizing s ps with
 | nil=>simp [NativeREDGoalSequence.compile]
 | cons R rs ih=>
   cases ps with
   | nil=>simp [NativeREDGoalSequence.compile]
   | cons p ps=>
     intro b hb
     simp only [NativeREDGoalSequence.compile,List.mem_cons] at hb
     rcases hb with rfl|hb
     · exact local_bound B _ _ _ _ p (h p (by simp))
     · exact ih _ ps (fun q hq=>h q (by simp [hq])) b hb

def EventBound (B:Nat):CanonicalLineParser.Event→Prop
 | .pol ts=>ts.length≤B
 | _=>True

theorem local_events (B:Nat) (b:NativeScopedLocalGoal.Built) (h:∀ts∈b.tapes,ts.length≤B):
 ∀e∈localEvents (stripLocal b),EventBound B e:=by
 intro e he
 simp only [localEvents,List.mem_append,List.mem_singleton] at he
 rcases he with he|rfl
 · obtain ⟨ts,ht,rfl⟩:=List.mem_map.mp he;exact h ts ht
 · trivial

theorem packed (B:Nat) (ids:Nat→Nat) (i:Nat) (bs:List (Row×NativeScopedLocalGoal.Built))
 (h:∀b∈bs,∀ts∈b.2.tapes,ts.length≤B):
 ∀e∈(packGoals ids i bs).flatMap goalEvents,EventBound B e:=by
 induction bs generalizing i with
 | nil=>simp [packGoals]
 | cons b bs ih=>
   intro e he
   simp only [packGoals,List.flatMap_cons,List.mem_append] at he
   rcases he with he|he
   · rcases List.mem_cons.mp he with rfl|he
     · trivial
     · exact local_events B b.2 (h b (by simp)) e he
   · exact ih (i+1) (fun q hq=>h q (by simp [hq])) e he

theorem step (A B:Nat) (D:List Row) (s:Store) (ids:Nat→Nat) (c:Step)
 (ha:MainTapeRecurrence.step c≤A) (hb:BoundedGoals B (certificates c)):
 ∀e∈commandEvents (pack ids (NativeRecordedStep.compile D s ids c).action),EventBound (max A B) e:=by
 cases c with
 | pol R ts=>
   intro e he
   obtain rfl:=List.mem_singleton.mp he
   change (ts.map (ReferenceTransport.token ids)).length≤_
   rw [List.length_map]
   exact ha.trans (Nat.le_max_left _ _)
 | consequence R p=>
   intro e he
   rcases List.mem_cons.mp he with rfl|he
   · trivial
   · exact local_events _ _ (fun ts ht=>(local_bound B _ _ _ _ p (hb p (by simp [certificates])) ts ht).trans (Nat.le_max_right _ _)) e he
 | red R w ps=>
   intro e he
   simp only [NativeRecordedStep.compile,pack,commandEvents,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at he
   rcases he with (rfl|he)|rfl
   · trivial
   · exact packed _ ids 0 _ (fun b hb'=>fun ts ht=>(goals B _ _ _ _ _ _ ps hb b hb' ts ht).trans (Nat.le_max_right _ _)) e he
   · trivial

theorem program (A B:Nat) (D:List Row) (s:Store) (ids:Nat→Nat) (p:Program)
 (ha:∀c∈p,MainTapeRecurrence.step c≤A) (hb:BoundedProgram B p):
 ∀e∈(CanonicalScopeKernel.compile D s ids p).flatMap commandEvents,EventBound (max A B) e:=by
 induction p generalizing D s ids with
 | nil=>simp [CanonicalScopeKernel.compile]
 | cons c cs ih=>
   intro e he
   simp only [CanonicalScopeKernel.compile,List.flatMap_cons,List.mem_append] at he
   rcases he with he|he
   · exact step A B D s ids c (ha c (by simp)) (hb c (by simp)) e he
   · exact ih _ _ _ (fun q hq=>ha q (by simp [hq])) (fun q hq=>hb q (by simp [hq])) e he

/-- Native trivial-goal lowering cannot increase any individual local
certificate's token count, not just the sum over all local certificates. -/
theorem lower_goals (B:Nat) (D:List Row) (C:Row) (w:FiniteWitness.Data)
 (rs:List Row) (ps:List RecordedRefutation.Certificate) (h:BoundedGoals B ps):
 BoundedGoals B (NativeTautGoalLowering.goals D C w rs ps):=by
 induction rs generalizing ps with
 | nil=>simp [NativeTautGoalLowering.goals,BoundedGoals]
 | cons R rs ih=>
   cases ps with
   | nil=>simp [NativeTautGoalLowering.goals,BoundedGoals]
   | cons p ps=>
     intro q hq
     rcases List.mem_cons.mp hq with rfl|hq
     · exact (NativeTautGoalLowering.local_tokens (D++[negate C]) (substRow R (FiniteWitness.interpret w)) p).trans (h p (by simp))
     · exact ih ps (fun p hp=>h p (by simp [hp])) q hq

theorem lower_step (B:Nat) (D:List Row) (c:Step) (h:BoundedGoals B (certificates c)):
 BoundedGoals B (certificates (NativeTautGoalLowering.step D c)):=by
 cases c with
 | pol R ts=>simp [NativeTautGoalLowering.step,certificates,BoundedGoals]
 | consequence R p=>
   intro q hq
   obtain rfl:=List.mem_singleton.mp hq
   exact (NativeTautGoalLowering.local_tokens D R p).trans (h p (by simp [certificates]))
 | red R w ps=>exact lower_goals B D R w (R::D) ps h

theorem lower_program (B:Nat) (D:List Row) (p:Program) (h:BoundedProgram B p):
 BoundedProgram B (NativeTautGoalLowering.program D p):=by
 induction p generalizing D with
 | nil=>simp [NativeTautGoalLowering.program,BoundedProgram]
 | cons c cs ih=>
   intro q hq
   rcases List.mem_cons.mp hq with rfl|hq
   · exact lower_step B D c (h c (by simp))
   · exact ih _ (fun q hq=>h q (by simp [hq])) q hq

def bound (n:Nat):Nat:=max (CanonicalFamilyMainTapes.mainTokenBound n) (704*n+700)

theorem family (n:Nat) (hn:2≤n):
 ∀e∈(NativeCompatibleFamily.commands n).flatMap commandEvents,EventBound (bound n) e:=by
 apply program
 · intro c hc
   have h:=member_sum ((NativeCompatibleFamily.emitter n).map MainTapeRecurrence.step)
      (MainTapeRecurrence.step c) (List.mem_map.mpr ⟨c,hc,rfl⟩)
   change _≤MainTapeRecurrence.count (NativeCompatibleFamily.emitter n) at h
   rw [NativeCompatibleFamily.emitter,NativeTautGoalCosts.main_tokens] at h
   exact h.trans (CanonicalFamilyMainTapes.main n hn)
 · exact lower_program _ _ _ (ConstructionFamilyLocalBounds.emitter n hn)

#print axioms family
end L3Emitter.NativeParserTapeBounds

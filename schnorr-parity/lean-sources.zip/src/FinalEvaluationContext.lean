import GateUnaryCompositionPOL
namespace L3Emitter.FinalEvaluationContext
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def D (n:Nat) (hn:2≤n):=FinalU2Bank.result n hn
def G (n:Nat) (hn:2≤n) (side:Bool):List Int:=[-(H n hn).val,-sign side (OutputPhaseRows.phase n hn)]
def P (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool):List Int:=
  [-sign a (LowerTransferImage.wire n hn (.port (lastRank n) 0 x.val)),
   -sign b (LowerTransferImage.wire n hn (.port (lastRank n) 1 x.val))]
def output (n:Nat) (hn:2≤n) (x:Fin (T n)):=LowerTransferImage.wire n hn (.val (lastRank n) x.val)
def u (n:Nat) (hn:2≤n) (x:Fin (T n)) (side r:Bool):Int:=sign (OutputPhaseRows.truth n x.val side) (unary n hn r)
def qlit (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool):Int:=sign (InputSwap.parity n x.val) (FinalU2Bank.q n hn a b)

theorem definitions_kept (n:Nat) (hn:2≤n):∀R∈FinalOutputDefinitions.result n hn,R∈D n hn:=
  fun R h=>FinalU2Image.retained n hn R (FinalU2Bank.definitions_kept n hn R h)
theorem function_kept (n:Nat) (hn:2≤n):∀R∈FinalFunctionCases.result n hn,R∈D n hn:=FinalU2Image.retained n hn
theorem phase_kept (n:Nat) (hn:2≤n):∀R∈OutputPhaseBank.result n hn,R∈D n hn:=
  by
  intro R h
  apply definitions_kept
  apply FinalOutputDefinitions.retains
  unfold FinalOutputDefinitions.base
  exact h
theorem raw_kept (n:Nat) (hn:2≤n):∀R∈LowerGateBank.result n hn,R∈D n hn:=
  fun R h=>phase_kept n hn R (List.mem_append_left _ h)

theorem value_binding (n:Nat) (hn:2≤n) (x:Fin (T n)):
    SourceCoordinateValue.value n hn (lastCoord n hn) x.val=output n hn x:=by
  have hi:n+lastRank n<AliasAssembly.width (n+1):=by unfold lastRank AliasAssembly.width RankConstruction.width;omega
  simp only [output,LowerTransferImage.wire,dif_pos hi]
  congr 1
  apply Fin.ext
  exact (FinalSelectorSources.width_binding n hn).symm

theorem phase_row (n:Nat) (hn:2≤n) (x:Fin (T n)) (side r:Bool):
    GateUnaryCompositionPOL.phaseRow (G n hn side) (sign r (output n hn x)) (u n hn x side r)∈D n hn:=by
  have h:=phase_kept n hn _ (OutputPhaseBank.all_rows n hn x.val x.isLt (lastCoord n hn) r side)
  have he:OutputPhaseRows.row n hn x.val (lastCoord n hn) r side=
      GateUnaryCompositionPOL.phaseRow (G n hn side) (sign r (output n hn x)) (u n hn x side r):=by
    change clause ([-(H n hn).val,-sign r (SourceCoordinateValue.value n hn (lastCoord n hn) x.val),
      sign (OutputPhaseRows.truth n x.val side) (unary n hn r)]++[-sign side (OutputPhaseRows.phase n hn)])=_
    rw [value_binding]
    apply GateUnaryCompositionPOL.clause_value_eq _ _
      (by simp [Valid,sign_valid,(H n hn).property])
      (by simp [G,u,Valid,sign_valid,(H n hn).property])
    intro α;simp only [G,u,H,unary,sum_append,sum_cons,sum_nil];ring
  rw [he] at h;exact h

theorem function_row (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side r:Bool):
    GateUnaryCompositionPOL.functionRow (G n hn side) (sign r (FinalU2Bank.f n hn a b)) (u n hn x side r) (qlit n hn x a b)∈D n hn:=by
  let v:=OutputPhaseRows.truth n x.val side
  let j:FinalFunctionCases.Job:=(FinalU2Bank.code a b,true,r,v,side)
  have h:=function_kept n hn _ (List.mem_append_right _
    (RetainedBlockFold.contains (FinalFunctionCases.rows n hn) FinalFunctionCases.jobs j
      (FinalFunctionFullLinks.job_mem _ true r v side (by simp)) _ (List.mem_cons_of_mem _ (List.mem_singleton_self _))))
  have he:(v^^side)=InputSwap.parity n x.val:=by unfold v OutputPhaseRows.truth;cases InputSwap.parity n x.val <;> cases side <;> decide
  change clause (([-sign r (FinalFunctionCases.raw n hn (FinalU2Bank.code a b)),
    -sign v (unary n hn r),-(H n hn).val]++[-sign side (OutputPhaseRows.phase n hn)])++
    [sign (v^^side) ((built n hn).1.functions (FinalU2Bank.code a b))])∈D n hn at h
  rw [he] at h
  have hr:clause (([-sign r (FinalFunctionCases.raw n hn (FinalU2Bank.code a b)),
    -sign v (unary n hn r),-(H n hn).val]++[-sign side (OutputPhaseRows.phase n hn)])++
    [sign (InputSwap.parity n x.val) ((built n hn).1.functions (FinalU2Bank.code a b))])=
    GateUnaryCompositionPOL.functionRow (G n hn side) (sign r (FinalU2Bank.f n hn a b)) (u n hn x side r) (qlit n hn x a b):=by
    apply GateUnaryCompositionPOL.clause_value_eq _ _ (by simp [Valid,sign_valid,(H n hn).property])
      (by simp [G,u,qlit,Valid,sign_valid,(H n hn).property])
    intro α;simp only [G,u,qlit,FinalU2Bank.f,FinalU2Bank.q,FinalFunctionFullLinks.raw,FinalFunctionFullLinks.q,v,sum_append,sum_cons,sum_nil];ring
  rw [hr] at h;exact h

theorem gate_row (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b r:Bool):
    GateUnaryCompositionPOL.gateRow (P n hn x a b) (sign r (FinalU2Bank.f n hn a b)) (sign r (output n hn x))∈D n hn:=by
  have h:=raw_kept n hn _ (LowerGateBank.all_rows n hn (lastRank n) x.val
    (by unfold lastRank RankConstruction.width;omega) x.isLt a b r)
  simpa only [GateUnaryCompositionPOL.gateRow,P,output,FinalU2Bank.f,FinalFunctionFullLinks.raw,
    FinalFunctionCases.raw,FinalU2Bank.code,RankGateEvaluation.row,RankGateEvaluation.literals,List.cons_append,List.nil_append] using h

#print axioms phase_row
#print axioms function_row
#print axioms gate_row
end L3Emitter.FinalEvaluationContext

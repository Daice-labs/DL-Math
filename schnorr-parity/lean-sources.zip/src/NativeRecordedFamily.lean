import NativeRecordedProgram
import RecordedUniformFamily
namespace L3Emitter.NativeRecordedFamily
open EREF EREF.GeneralRED NativeSparseStore

def original (n : Nat) := OriginalEncoding.rows n (3*n-4)
def compiled (n : Nat) := NativeRecordedProgram.compile (original n)
  (initial (original n)) id (RecordedUniformFamily.emitter n)
def conclusion (n : Nat) : Nat := (compiled n).ids
  (ReferenceTransport.locate (RecordedUniformFamily.finalRows n) (REDWitness.clause []))

/-- Every n has a concrete physical-store execution ending with a live
contradiction reference. This is the complete row-store projection, not yet
serialized-byte acceptance or implementation refinement for pinned VeriPB. -/
theorem physical_refutation (n : Nat) (hn : 2≤n) :
    NativeRecordedProgram.execute (original n) (initial (original n)) (compiled n).actions=
      some (compiled n).store ∧
    read (compiled n).store (conclusion n:Int)=some (REDWitness.clause []) := by
  have hf := RecordedUniformFamily.recorded_refutation n hn
  have hh := NativeRecordedProgram.correct 0 (RecordedUniformFamily.guard n)
    (original n) (RecordedUniformFamily.finalRows n) (initial (original n)) id
    (RecordedUniformFamily.emitter n) (by change 0<_+1;omega)
    (initial_embeds (original n)) hf.1
  exact ⟨hh.1,read_absolute _ _ _ hh.2.1 _ _ (ReferenceTransport.locate_correct _ _ hf.2)⟩

#print axioms physical_refutation
end L3Emitter.NativeRecordedFamily

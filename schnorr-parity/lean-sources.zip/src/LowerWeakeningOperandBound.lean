import ActualTailOperandBounds
namespace L3Emitter.LowerWeakeningOperandBound
open EREF EREF.GeneralRED FamilyRows InputSwap ActualLowerComposition RecordedScopedTrace FieldLengthsFromIDs

theorem signFix_unit (xs:List Int): (signFix (xs.map (fun l=>(1,l)))).2=0:=by
  induction xs with
  | nil=>rfl
  | cons x xs ih=>simpa only [List.map_cons,signFix,show ¬(1:Int)<0 by omega,
      show ¬(1:Int)=0 by omega,if_false] using ih

theorem spec_bound (k s:Nat) (r:Spec): (r.row k s).bound≤r.rhs:=by
  have h:=signFix_unit (r.literals.map (FamilyRows.lit k s))
  simp only [List.map_map,Function.comp_def] at h
  change r.rhs-(signFix (r.literals.map (fun l=>(1,FamilyRows.lit k s l)))).2-_
    ≤r.rhs
  rw [h]
  omega

theorem original_rhs (k s:Nat) (hs:0<s) (r:Spec) (h:Original k s r):r.rhs≤(k+s:Nat):=by
  cases h with
  | oneHot t p b ht hp=>cases b <;> simp only [oneHot,Bool.false_eq_true,if_false,if_true] <;> push_cast <;> omega
  | forbidden t c ht hc=>change (1:Int)≤k+s;omega
  | input t p j x ht hp hj hx=>change (1:Int)≤k+s;omega
  | gate t p g x b ht hp hg hx=>change (1:Int)≤k+s;omega
  | semantics t x a b c ht hx=>change (1:Int)≤k+s;omega
  | output x hss hx=>change (1:Int)≤k+s;omega

theorem original_amount (k s:Nat) (hs:0<s) (R:Row) (h:R∈OriginalEncoding.rows k s):
    amount R≤k+s+1:=by
  obtain ⟨r,hr,rfl⟩:=List.mem_map.mp h
  have h1:=spec_bound k s r
  have h2:=original_rhs k s hs r ((OriginalEncoding.spec_mem_iff k s hs r).mp hr)
  unfold amount
  omega

/-- Every weakening scalar for an actual lower input row is at most 4n+1.
This is a numeric-operand bound, independent of the replayed tail. -/
theorem inputs_amount (n:Nat) (hn:2≤n) (R:Row) (h:R∈inputs n hn):amount R≤4*n+1:=by
  change R∈LowerActivationImage.inputs n (ceiling n hn) at h
  rw [←RecordedOffsetOriginal.inputs (ceiling n hn) n hn] at h
  obtain ⟨r,hr,rfl⟩:=List.mem_map.mp h
  have hh:=original_amount n (3*n-4) (by omega) r hr
  change r.bound.toNat+1≤4*n+1
  change r.bound.toNat+1≤n+(3*n-4)+1 at hh
  omega

/-- The actual one-copy lower tail now has no assumed weakening-scalar
bound. Its remaining numeric parameter is the lower family's operand bound. -/
theorem tail (n M:Nat) (hn:2≤n) (p:Program) (h:∀c∈p,Content M c):
    ∀c∈ActualRecordedTail.emit n hn (RecordedRecursiveStep.reserve n p)
      (RecordedRecursiveStep.shifted n hn p),
      Content (ActualTailOperandBounds.tailBound n M (4*n+1) hn) c:=
  ActualTailOperandBounds.tail n M (4*n+1) hn p h (inputs_amount n hn)

#print axioms inputs_amount
#print axioms tail
end L3Emitter.LowerWeakeningOperandBound

import BetaValue

namespace L3Emitter.ConstantAdmission
open EREF EREF.GeneralRED REDWitness

def result (n : Nat) (hn : 2≤n) := BetaValue.result n hn++RankAdmission.blocks (n+1) (by omega)

theorem rank_present (n : Nat) (hn : 2≤n) (R:Row) (hR:R∈RankConstruction.database (n+1) (by omega)) :
    R∈BetaValue.result n hn :=
  List.mem_append_left _ (BetaValue.constant_retained n hn R (ConstantConstruction.retains_rank _ _ R hR))

theorem original_to_constant_and_rank (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (BetaValue.original_to_beta_value n hn)
    (RankAdmission.rank_trace (n+1) (by omega) (BetaValue.result n hn) (rank_present n hn))

theorem beta_value_rows (n : Nat) (hn : 2≤n) (j : BetaPort.Job n) (hj:j∈BetaPort.jobs n hn) :
    BetaValue.row n hn (j,false)∈result n hn ∧ BetaValue.row n hn (j,true)∈result n hn := by
  constructor <;> apply List.mem_append_left <;> apply List.mem_append_right <;> apply List.mem_map.mpr
  · exact ⟨(j,false),(BetaValue.job_mem n hn _).mpr hj,rfl⟩
  · exact ⟨(j,true),(BetaValue.job_mem n hn _).mpr hj,rfl⟩

#print axioms original_to_constant_and_rank
#print axioms beta_value_rows
end L3Emitter.ConstantAdmission

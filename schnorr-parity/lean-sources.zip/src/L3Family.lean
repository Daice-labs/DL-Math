/-
L3 family encoding (obligation 0 of OPEN_OBLIGATIONS.txt), transcribed from
`project/emitter/family.py` (unchanged v4 source) into core Lean 4 (no Mathlib).

Conventions copied from the Python source:
* inputs are zero-based wires 0..k-1; gate t outputs wire k+t; ports range over 0..k+t-1;
* a row is a list of signed literal ids with unit coefficients and a right-hand side;
  a negative id means Boolean complement;
* the five ORIGINAL blocks are emitted in the order (1) port one-hot, (2) forbidden
  function codes 6 and 9, (3) selected-parent transfer, (4) gate semantics, (5) output
  units; serialization is `1 x7 1 ~x9 >= 1 ;\n` per row after the header
  `* #variable= V #constraint= F\n`.

Block 3 is written with the source range split as `range k ++ [k, k+t)`; this is the
same list in the same order as Python's single `range(k+t)` loop because the branch
`j < k` holds exactly on the first k indices.

Everything here is a definition plus theorems about counts and literal ranges; the
agreement with the Python serializer is checked byte-for-byte on finite instances by
`L3FamilyEval.lean` (that check is a finite test, stated as such).
-/
import EREF_Rows

namespace L3

/-- a family instance: k inputs, s gates, target table `b x` for x < 2^k -/
structure Fam where
  k : Nat
  s : Nat
  b : Nat → Bool

namespace Fam

/-- T = 2^k rows of the truth table -/
def T (F : Fam) : Nat := 2 ^ F.k
/-- S = s(2k+s-1) selector variables -/
def S (F : Fam) : Nat := F.s * (2 * F.k + F.s - 1)
/-- V = S + 4s + 3sT variables -/
def V (F : Fam) : Nat := F.S + 4 * F.s + 3 * F.s * F.T
/-- F = (2s(k+s+3)+1)T + 6s original rows -/
def F (F : Fam) : Nat := (2 * F.s * (F.k + F.s + 3) + 1) * F.T + 6 * F.s

/-- selector variable: gate t, port p ∈ {0,1}, source wire j < k+t -/
def sel (F : Fam) (t p j : Nat) : Nat := 2 * t * F.k + t * (t - 1) + p * (F.k + t) + j + 1
/-- function-bit variable: gate t, entry ab ∈ {0,1,2,3} (ab = 2a+b) -/
def fn (F : Fam) (t ab : Nat) : Nat := F.S + 4 * t + ab + 1
/-- port value variable at input x -/
def port (F : Fam) (t p x : Nat) : Nat := F.S + 4 * F.s + (2 * t + p) * F.T + x + 1
/-- gate value variable at input x -/
def val (F : Fam) (t x : Nat) : Nat := F.S + 4 * F.s + 2 * F.s * F.T + t * F.T + x + 1

/-- bit j of input x in the Python convention `(x >> (k-1-j)) & 1` -/
def inputBit (F : Fam) (j x : Nat) : Bool := Nat.testBit x (F.k - 1 - j)

end Fam

/-- an original row: signed literal ids (unit coefficients) and a right-hand side -/
structure Row where
  lits : List Int
  rhs : Nat
  deriving DecidableEq, Repr

def pos (v : Nat) : Int := (v : Int)
def neg (v : Nat) : Int := -(v : Int)

/-- `forbidden >> (3-ab) & 1` for forbidden ∈ {6, 9} -/
def codeBit (code ab : Nat) : Bool := Nat.testBit code (3 - ab)

namespace Fam

/-- Block 1: exactly one parent per port, as `≥ 1` and the complemented `≥ n-1` -/
def block1 (F : Fam) : List Row :=
  (List.range F.s).flatMap fun t =>
    (List.range 2).flatMap fun p =>
      let n := F.k + t
      let ids := (List.range n).map fun j => F.sel t p j
      [ { lits := ids.map pos, rhs := 1 }, { lits := ids.map neg, rhs := n - 1 } ]

/-- Block 2: forbid XOR (0110 = 6) and XNOR (1001 = 9) -/
def block2 (F : Fam) : List Row :=
  (List.range F.s).flatMap fun t =>
    [6, 9].map fun forbidden =>
      { lits := (List.range 4).map fun ab =>
          if codeBit forbidden ab then neg (F.fn t ab) else pos (F.fn t ab), rhs := 1 }

/-- Block 3, input source j < k at gate t, port p: one row per x -/
def inputRows (F : Fam) (t p j : Nat) : List Row :=
  (List.range F.T).map fun x =>
    { lits := [neg (F.sel t p j), if F.inputBit j x then pos (F.port t p x) else neg (F.port t p x)],
      rhs := 1 }

/-- Block 3, gate source j = k + i at gate t, port p: two rows per x -/
def gateRows (F : Fam) (t p i : Nat) : List Row :=
  (List.range F.T).flatMap fun x =>
    [ { lits := [neg (F.sel t p (F.k + i)), neg (F.val i x), pos (F.port t p x)], rhs := 1 },
      { lits := [neg (F.sel t p (F.k + i)), pos (F.val i x), neg (F.port t p x)], rhs := 1 } ]

/-- Block 3: a selected input is a constant under x; a selected earlier gate transfers -/
def block3 (F : Fam) : List Row :=
  (List.range F.s).flatMap fun t =>
    (List.range 2).flatMap fun p =>
      ((List.range F.k).flatMap fun j => F.inputRows t p j) ++
      ((List.range t).flatMap fun i => F.gateRows t p i)

/-- Block 4: (w1 = a ∧ w2 = b) → (v = f_ab), two clauses per (a, b) -/
def block4 (F : Fam) : List Row :=
  (List.range F.s).flatMap fun t =>
    (List.range F.T).flatMap fun x =>
      (List.range 2).flatMap fun a =>
        (List.range 2).flatMap fun b =>
          let m1 := if a = 1 then neg (F.port t 0 x) else pos (F.port t 0 x)
          let m2 := if b = 1 then neg (F.port t 1 x) else pos (F.port t 1 x)
          [ { lits := [m1, m2, neg (F.val t x), pos (F.fn t (2 * a + b))], rhs := 1 },
            { lits := [m1, m2, pos (F.val t x), neg (F.fn t (2 * a + b))], rhs := 1 } ]

/-- Block 5: the requested truth table on the last gate -/
def block5 (F : Fam) : List Row :=
  (List.range F.T).map fun x =>
    { lits := [if F.b x then pos (F.val (F.s - 1) x) else neg (F.val (F.s - 1) x)], rhs := 1 }

/-- all original rows, in emission order -/
def rows (F : Fam) : List Row := F.block1 ++ F.block2 ++ F.block3 ++ F.block4 ++ F.block5

/-! ### Row counts (universal in k, s) -/

theorem length_flatMap_const {α β : Type} (l : List α) (f : α → List β) (c : Nat)
    (h : ∀ a ∈ l, (f a).length = c) : (l.flatMap f).length = l.length * c := by
  induction l with
  | nil => simp
  | cons a l ih =>
    simp only [List.flatMap_cons, List.length_append, List.length_cons]
    rw [h a (by simp), ih (fun a' ha' => h a' (by simp [ha'])), Nat.succ_mul]
    omega

theorem length_block1 (F : Fam) : F.block1.length = 4 * F.s := by
  unfold block1
  rw [length_flatMap_const _ _ 4]
  · simp; omega
  · intro t _
    rw [length_flatMap_const _ _ 2]
    · simp
    · intro p _; simp

theorem length_block2 (F : Fam) : F.block2.length = 2 * F.s := by
  unfold block2
  rw [length_flatMap_const _ _ 2]
  · simp; omega
  · intro t _; simp

theorem length_inputRows (F : Fam) (t p j : Nat) : (F.inputRows t p j).length = F.T := by
  unfold inputRows; simp

theorem length_gateRows (F : Fam) (t p i : Nat) : (F.gateRows t p i).length = 2 * F.T := by
  unfold gateRows
  rw [length_flatMap_const _ _ 2]
  · simp; omega
  · intro x _; simp

/-- Σ_{t<s} (2kT + 4tT) -/
theorem length_block3 (F : Fam) : F.block3.length = 2 * F.s * F.T * (F.k + F.s - 1) := by
  unfold block3
  -- inner length for fixed t: 2 * (k*T + 2*t*T)
  have inner : ∀ t, ((List.range 2).flatMap fun p =>
      ((List.range F.k).flatMap fun j => F.inputRows t p j) ++
      ((List.range t).flatMap fun i => F.gateRows t p i)).length = 2 * (F.k * F.T + t * (2 * F.T)) := by
    intro t
    rw [length_flatMap_const _ _ (F.k * F.T + t * (2 * F.T))]
    · simp
    · intro p _
      rw [List.length_append, length_flatMap_const _ _ F.T (fun j _ => F.length_inputRows t p j),
        length_flatMap_const _ _ (2 * F.T) (fun i _ => F.length_gateRows t p i)]
      simp
  -- sum over t of the inner lengths
  have sum : ∀ s, ((List.range s).flatMap fun t =>
      (List.range 2).flatMap fun p =>
        ((List.range F.k).flatMap fun j => F.inputRows t p j) ++
        ((List.range t).flatMap fun i => F.gateRows t p i)).length
      = 2 * s * F.T * (F.k + s - 1) := by
    intro s
    induction s with
    | zero => simp
    | succ s ih =>
      rw [List.range_succ (n := s), List.flatMap_append, List.length_append, ih]
      simp only [List.flatMap_cons, List.flatMap_nil, List.append_nil]
      rw [inner s]
      -- 2 s T (k+s-1) + 2(kT + 2sT) = 2(s+1)T(k+s)
      cases s with
      | zero => simp; grind
      | succ s =>
        have h1 : F.k + (s + 1) - 1 = F.k + s := by omega
        have h2 : F.k + (s + 1 + 1) - 1 = F.k + s + 1 := by omega
        rw [h1, h2]
        grind
  exact sum F.s

theorem length_block4 (F : Fam) : F.block4.length = 8 * F.s * F.T := by
  unfold block4
  rw [length_flatMap_const _ _ (8 * F.T)]
  · simp; grind
  · intro t _
    rw [length_flatMap_const _ _ 8]
    · simp; grind
    · intro x _
      rw [length_flatMap_const _ _ 4]
      · simp
      · intro a _
        rw [length_flatMap_const _ _ 2]
        · simp
        · intro b _; simp

theorem length_block5 (F : Fam) : F.block5.length = F.T := by
  unfold block5; simp

/-- the emitted row count is exactly the header's `#constraint=` value F -/
theorem length_rows (F : Fam) : F.rows.length = F.F := by
  unfold rows
  simp only [List.length_append, length_block1, length_block2, length_block3, length_block4,
    length_block5]
  unfold Fam.F
  cases F.s with
  | zero => simp
  | succ s =>
    have h : F.k + (s + 1) - 1 = F.k + s := by omega
    rw [h]; grind

/-! ### Literal ranges: every variable id lies in `1 .. V` -/

/-- unsigned id of a literal -/
def Int.varOf (l : Int) : Nat := l.natAbs

theorem sel_pos (F : Fam) (t p j : Nat) : 1 ≤ F.sel t p j := by unfold sel; omega
theorem fn_pos (F : Fam) (t ab : Nat) : 1 ≤ F.fn t ab := by unfold fn; omega
theorem port_pos (F : Fam) (t p x : Nat) : 1 ≤ F.port t p x := by unfold port; omega
theorem val_pos (F : Fam) (t x : Nat) : 1 ≤ F.val t x := by unfold val; omega

/-- sel(t,p,j) ≤ S for t < s, p ≤ 1, j < k + t (the maximum is attained exactly at S) -/
theorem sel_le_S (F : Fam) (t p j : Nat) (ht : t < F.s) (hp : p ≤ 1) (hj : j < F.k + t) :
    F.sel t p j ≤ F.S := by
  unfold sel S
  have h1 : 2 * t * F.k + t * (t - 1) + p * (F.k + t) + j + 1 ≤ (t + 1) * (2 * F.k + t) := by
    have hp' : p * (F.k + t) ≤ F.k + t := by
      calc p * (F.k + t) ≤ 1 * (F.k + t) := Nat.mul_le_mul_right _ hp
        _ = F.k + t := Nat.one_mul _
    cases t with
    | zero => simp at *; omega
    | succ t =>
      simp only [Nat.add_sub_cancel] at *
      grind
  have h2 : (t + 1) * (2 * F.k + t) ≤ F.s * (2 * F.k + F.s - 1) :=
    Nat.mul_le_mul ht (by omega)
  omega

theorem fn_le (F : Fam) (t ab : Nat) (ht : t < F.s) (hab : ab < 4) :
    F.fn t ab ≤ F.S + 4 * F.s := by
  unfold fn; omega

theorem port_le (F : Fam) (t p x : Nat) (ht : t < F.s) (hp : p ≤ 1) (hx : x < F.T) :
    F.port t p x ≤ F.S + 4 * F.s + 2 * F.s * F.T := by
  unfold port
  have : (2 * t + p + 1) * F.T ≤ 2 * F.s * F.T := Nat.mul_le_mul_right _ (by omega)
  grind

theorem val_le (F : Fam) (t x : Nat) (ht : t < F.s) (hx : x < F.T) :
    F.val t x ≤ F.V := by
  unfold val V
  have : (t + 1) * F.T ≤ F.s * F.T := Nat.mul_le_mul_right _ ht
  grind

end Fam

/-- a row is well formed for the header if every literal id lies in `1 .. V` -/
def Row.wf (V : Nat) (r : Row) : Prop := ∀ l ∈ r.lits, 1 ≤ l.natAbs ∧ l.natAbs ≤ V

theorem natAbs_pos (v : Nat) : (pos v).natAbs = v := by simp [pos]
theorem natAbs_neg (v : Nat) : (neg v).natAbs = v := by simp [neg]

namespace Fam

theorem S_le_V (F : Fam) : F.S ≤ F.V := by unfold V; omega
theorem S4_le_V (F : Fam) : F.S + 4 * F.s ≤ F.V := by unfold V; omega
theorem port_bound_le_V (F : Fam) : F.S + 4 * F.s + 2 * F.s * F.T ≤ F.V := by
  unfold V; grind

theorem block1_wf (F : Fam) : ∀ r ∈ F.block1, r.wf F.V := by
  unfold block1
  intro r hr
  simp only [List.mem_flatMap, List.mem_range] at hr
  obtain ⟨t, ht, p, hp, hr⟩ := hr
  simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hr
  have key : ∀ j < F.k + t, 1 ≤ F.sel t p j ∧ F.sel t p j ≤ F.V := fun j hj =>
    ⟨F.sel_pos t p j, Nat.le_trans (F.sel_le_S t p j ht (by omega) hj) F.S_le_V⟩
  rcases hr with rfl | rfl <;> intro l hl <;> simp only [List.mem_map, List.mem_range] at hl <;>
    obtain ⟨v, ⟨j, hj, rfl⟩, rfl⟩ := hl
  · rw [natAbs_pos]; exact key j hj
  · rw [natAbs_neg]; exact key j hj

theorem block2_wf (F : Fam) : ∀ r ∈ F.block2, r.wf F.V := by
  unfold block2
  intro r hr
  simp only [List.mem_flatMap, List.mem_range, List.mem_map] at hr
  obtain ⟨t, ht, c, _, rfl⟩ := hr
  intro l hl
  simp only [List.mem_map, List.mem_range] at hl
  obtain ⟨ab, hab, rfl⟩ := hl
  have := F.fn_le t ab ht hab
  have := F.fn_pos t ab
  have := F.S4_le_V
  split <;> simp only [natAbs_pos, natAbs_neg] <;> omega

theorem inputRows_wf (F : Fam) (t p j : Nat) (ht : t < F.s) (hp : p ≤ 1) (hj : j < F.k + t) :
    ∀ r ∈ F.inputRows t p j, r.wf F.V := by
  unfold inputRows
  intro r hr
  simp only [List.mem_map, List.mem_range] at hr
  obtain ⟨x, hx, rfl⟩ := hr
  intro l hl
  have hs := F.sel_pos t p j
  have hs' := Nat.le_trans (F.sel_le_S t p j ht hp hj) F.S_le_V
  have hq := F.port_pos t p x
  have hq' := Nat.le_trans (F.port_le t p x ht hp hx) F.port_bound_le_V
  simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl
  · rw [natAbs_neg]; exact ⟨hs, hs'⟩
  · split <;> simp only [natAbs_pos, natAbs_neg] <;> exact ⟨hq, hq'⟩

theorem gateRows_wf (F : Fam) (t p i : Nat) (ht : t < F.s) (hp : p ≤ 1) (hi : i < t) :
    ∀ r ∈ F.gateRows t p i, r.wf F.V := by
  unfold gateRows
  intro r hr
  simp only [List.mem_flatMap, List.mem_range] at hr
  obtain ⟨x, hx, hr⟩ := hr
  have hs := F.sel_pos t p (F.k + i)
  have hs' := Nat.le_trans (F.sel_le_S t p (F.k + i) ht hp (by omega)) F.S_le_V
  have hq := F.port_pos t p x
  have hq' := Nat.le_trans (F.port_le t p x ht hp hx) F.port_bound_le_V
  have hv := F.val_pos i x
  have hv' := F.val_le i x (by omega) hx
  simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hr
  rcases hr with rfl | rfl <;> intro l hl <;>
    simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hl <;>
    rcases hl with rfl | rfl | rfl <;> simp only [natAbs_pos, natAbs_neg] <;> omega

theorem block3_wf (F : Fam) : ∀ r ∈ F.block3, r.wf F.V := by
  unfold block3
  intro r hr
  simp only [List.mem_flatMap, List.mem_range, List.mem_append] at hr
  obtain ⟨t, ht, p, hp, hr | hr⟩ := hr
  · obtain ⟨j, hj, hr⟩ := hr
    exact F.inputRows_wf t p j ht (by omega) (by omega) r hr
  · obtain ⟨i, hi, hr⟩ := hr
    exact F.gateRows_wf t p i ht (by omega) hi r hr

theorem block4_wf (F : Fam) : ∀ r ∈ F.block4, r.wf F.V := by
  unfold block4
  intro r hr
  simp only [List.mem_flatMap, List.mem_range] at hr
  obtain ⟨t, ht, x, hx, a, ha, b, hb, hr⟩ := hr
  have h0 := F.port_pos t 0 x
  have h0' := Nat.le_trans (F.port_le t 0 x ht (by omega) hx) F.port_bound_le_V
  have h1 := F.port_pos t 1 x
  have h1' := Nat.le_trans (F.port_le t 1 x ht (by omega) hx) F.port_bound_le_V
  have hv := F.val_pos t x
  have hv' := F.val_le t x ht hx
  have hf := F.fn_pos t (2 * a + b)
  have hf' := Nat.le_trans (F.fn_le t (2 * a + b) ht (by omega)) F.S4_le_V
  simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hr
  rcases hr with rfl | rfl <;> intro l hl <;>
    simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hl <;>
    rcases hl with rfl | rfl | rfl | rfl <;> (try split) <;> simp only [natAbs_pos, natAbs_neg] <;> omega

theorem block5_wf (F : Fam) (hs : 1 ≤ F.s) : ∀ r ∈ F.block5, r.wf F.V := by
  unfold block5
  intro r hr
  simp only [List.mem_map, List.mem_range] at hr
  obtain ⟨x, hx, rfl⟩ := hr
  intro l hl
  have hv := F.val_pos (F.s - 1) x
  have hv' := F.val_le (F.s - 1) x (by omega) hx
  simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hl
  subst hl
  split <;> simp only [natAbs_pos, natAbs_neg] <;> omega

/-- every emitted original row is well formed for the header (`1 ≤ id ≤ V`), for all k, s ≥ 1 -/
theorem rows_wf (F : Fam) (hs : 1 ≤ F.s) : ∀ r ∈ F.rows, r.wf F.V := by
  unfold rows
  intro r hr
  simp only [List.mem_append] at hr
  rcases hr with ((((hr | hr) | hr) | hr) | hr)
  · exact F.block1_wf r hr
  · exact F.block2_wf r hr
  · exact F.block3_wf r hr
  · exact F.block4_wf r hr
  · exact F.block5_wf hs r hr

end Fam
end L3

import SelectedCategoryRows
namespace L3Emitter.HitSnapshots
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases ConcreteSelection ContextRows
variable {base:List Row} {A B:Type}

theorem tabulate_map (n:Nat) (f:Fin n→StateM (Net base) A) (h:A→B) (z:Net base):
    tabulate n (fun i z=>(h (f i z).1,(f i z).2)) z =
      ((fun i=>h ((tabulate n f z).1 i)),(tabulate n f z).2):=by
  induction n generalizing z with
  | zero=>apply Prod.ext;funext i;exact Fin.elim0 i;rfl
  | succ n ih=>
    change ((fun i:Fin (n+1)=>Fin.cases (motive:=fun _=>B) (h (f 0 z).1)
      (tabulate n (fun i z=>(h (f i.succ z).1,(f i.succ z).2)) (f 0 z).2).1 i),
      (tabulate n (fun i z=>(h (f i.succ z).1,(f i.succ z).2)) (f 0 z).2).2)=_
    rw [ih]
    apply Prod.ext
    · funext i
      exact Fin.cases rfl (fun j=>rfl) i
    · rfl

def record (xs:List (Bit×Bit)) (z:Net base): (List Cell×Bit)×Net base:=
  ((cells xs z,(select xs z).1),(select xs z).2)
def inputs:=HitSelectorRows.inputs

def run (n:Nat) (hn:2≤n):=
  tabulate (3*(n+1)-4) (fun g=>record (inputs n hn g.val)) (keptRun n hn).2

theorem binding (n:Nat) (hn:2≤n):
    ((fun i=>((run n hn).1 i).2),(run n hn).2)=hitRun n hn:=by
  exact (tabulate_map _ (fun g=>record (inputs n hn g.val)) Prod.snd (keptRun n hn).2).symm

def entries (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4):List Cell:=((run n hn).1 ⟨g,hg⟩).1

theorem properties (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4):
    (entries n hn g hg).map (fun e=>(e.choice,e.value))=inputs n hn g ∧
    (∀e∈entries n hn g hg,CellRows (UnaryValueBank.result n hn) e) ∧
    OrRows (UnaryValueBank.result n hn) ((entries n hn g hg).map Cell.term) ((PrimaryAliasBank.cfg n hn).hit g):=by
  have h:=tabulate_post (3*(n+1)-4) (fun g=>record (inputs n hn g.val))
    (fun g eq D=>eq.1.map (fun e=>(e.choice,e.value))=inputs n hn g.val ∧
      (∀e∈eq.1,CellRows D e) ∧ OrRows D (eq.1.map Cell.term) eq.2)
    (fun _=>select_extends _) (by
      intro i z
      refine ⟨pairs _ _,?_,?_⟩
      · intro e he
        have h:=(ands_rows (inputs n hn i.val) z e he).mono (push_retains _ false ((cells (inputs n hn i.val) z).map Cell.term))
        simpa only [record,←select_binding,selected,cells,middle,OR] using h
      · have h:=ContextRows.actual_or ((cells (inputs n hn i.val) z).map Cell.term) (middle (inputs n hn i.val) z)
        simpa only [←select_binding,record,selected] using h)
    (fun _ _ _ _ h hm=>⟨h.1,fun e he=>(h.2.1 e he).mono hm,h.2.2.mono hm⟩) (keptRun n hn).2 ⟨g,hg⟩
  have neteq: (run n hn).2=(hitRun n hn).2:=congrArg Prod.snd (binding n hn)
  have qe:((run n hn).1 ⟨g,hg⟩).2=(PrimaryAliasBank.cfg n hn).hit g:=by
    have hq:=congrFun (congrArg Prod.fst (binding n hn)) ⟨g,hg⟩
    change ((run n hn).1 ⟨g,hg⟩).2=(hitRun n hn).1 ⟨g,hg⟩ at hq
    rw [hq]
    change _=AliasAssembly.refAt _ (hitRun n hn).1 g
    simp only [AliasAssembly.refAt,dif_pos hg]
  have keep:∀R∈(run n hn).2.rows,R∈UnaryValueBank.result n hn:=by
    rw [neteq]
    intro R hr
    exact UnaryPortTransport.category_keep n hn R (CategoryBank.retains n hn R (context_to_endpoint n hn R hr))
  exact ⟨h.1,fun e he=>(h.2.1 e he).mono keep,by rw [←qe];exact h.2.2.mono keep⟩

#print axioms binding
#print axioms properties
end L3Emitter.HitSnapshots

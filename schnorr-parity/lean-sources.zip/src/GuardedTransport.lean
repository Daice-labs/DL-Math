import GateEvaluationBindings
namespace L3Emitter.GuardedTransport
open EREF EREF.GeneralRED REDWitness Resolution ReferenceTransport LocalCombination ClauseTransport CaseJoin

def padding (ls:List Link):List Int:=(List.replicate ls.length (ls.map Link.target)).flatten
def combined (g:Int) (ls:List Link):=
  chain (chain (branch (sourceClause ls) g) (ls.map (Link.row g))) ((padding ls).map litAxiom)
def tokens (i:Nat) (g:Int) (ls:List Link):List Tok:=
  [.ref i]++linkSteps g ls++padSteps (padding ls)++[.div (ls.length+1)]

theorem pad_valid (ls:List Link) (h:∀p∈ls,p.target≠0):Valid (padding ls):=by
  intro l hl;obtain ⟨xs,hxs,hl⟩:=List.mem_flatten.mp hl
  have he:xs=ls.map Link.target:=(List.mem_replicate.mp hxs).2
  subst xs;obtain ⟨p,hp,rfl⟩:=List.mem_map.mp hl;exact h p hp

theorem scaled_eq (g:Int) (ls:List Link) (hg:g≠0) (hl:∀p∈ls,p.source≠0 ∧ p.target≠0):
    combined g ls=scaled (ls.length+1) (branch (targetClause ls) g):=by
  have hs:Valid (ls.map Link.source):=by
    intro l h;obtain ⟨p,hp,rfl⟩:=List.mem_map.mp h;exact (hl p hp).1
  have ht:Valid (ls.map Link.target):=by
    intro l h;obtain ⟨p,hp,rfl⟩:=List.mem_map.mp h;exact (hl p hp).2
  have hp:=pad_valid ls (fun p hp=>(hl p hp).2)
  apply canonical_ext _ _ (chain_canonical _ _ (chain_canonical _ _ (canonical_normalize _ _)))
    (canonical_scaled _ (by omega) _ (canonical_normalize _ _))
  intro α
  change (combined g ls).val α=(scaled (ls.length+1) (branch (targetClause ls) g)).val α
  rw [combined,chain_value (chain (branch (sourceClause ls) g) (ls.map (Link.row g))) ((padding ls).map litAxiom)
    (chain_canonical _ _ (canonical_normalize _ _))
    (by intro R hr;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hr;exact canonical_litAxiom _),
    chain_value (branch (sourceClause ls) g) (ls.map (Link.row g)) (canonical_normalize _ _)
    (by intro R hr;obtain ⟨p,hp,rfl⟩:=List.mem_map.mp hr;exact canonical_normalize _ _),
    ChoiceProjection.literal_sum _ hp,ClauseTransport.link_sum ls g hg hl,val_scaled,
    val_branch (sourceClause ls) (canonical_normalize _ _) g hg,
    val_branch (targetClause ls) (canonical_normalize _ _) g hg]
  have hpv:sum α (padding ls)=ls.length*sum α (ls.map Link.target):=by
    simp [padding,sum,List.map_flatten,List.sum_flatten,List.map_replicate,List.sum_replicate]
  rw [hpv]
  have hsrc:=val_clause _ hs α
  have htgt:=val_clause _ ht α
  change tval α (sourceClause ls).terms-(sourceClause ls).bound=_ at hsrc
  change tval α (targetClause ls).terms-(targetClause ls).bound=_ at htgt
  push_cast
  nlinarith

theorem succeeds (db:Nat→Option Row) (i:Nat) (g:Int) (ls:List Link) (hg:g≠0)
    (hs:db i=some (branch (sourceClause ls) g)) (hl:∀p∈ls,p.Available db g):
    polEval db (tokens i g ls) []=some (branch (targetClause ls) g):=by
  simp only [tokens,List.append_assoc,List.cons_append,List.nil_append,polEval,hs]
  rw [linkSteps_eval db g hg ls hl,padSteps_eval db _ (pad_valid ls (fun p hp=>(hl p hp).2.1))]
  change polEval db [.div (ls.length+1)] [combined g ls]=_
  rw [scaled_eq g ls hg (fun p hp=>⟨(hl p hp).1,(hl p hp).2.1⟩)]
  simp only [polEval,show 0<ls.length+1 by omega,↓reduceIte]
  rw [divide_scaled (ls.length+1) (by omega) (branch (targetClause ls) g) (canonical_normalize _ _)]
#print axioms succeeds
end L3Emitter.GuardedTransport

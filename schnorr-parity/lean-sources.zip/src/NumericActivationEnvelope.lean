import NumericActualActivation
namespace L3Emitter.NumericActivationEnvelope
open EREF EREF.GeneralRED RecordedScopedTrace RecordedOperandFields FieldLengthsFromIDs

def E (n:Nat):Nat:=NumericClosedNamespace.envelope n

theorem positive (n:Nat):1≤E n:=by
  have h:0<E n:=by unfold E NumericClosedNamespace.envelope;positivity
  omega

theorem original (n:Nat):NumericActivationInputs.originalCost n≤E n:=by
  have hv:=FrontendNamespaceEnvelope.original n
  have hp:(n+1)^2≤(n+2)^9:=
    (Nat.pow_le_pow_left (by omega) 2).trans (Nat.pow_le_pow_right (by omega) (by omega))
  have ht:2^n≤(2^(n+1))^4:=
    (Nat.pow_le_pow_right (by omega) (show n≤n+1 by omega)).trans (by
      have h:1≤2^(n+1):=Nat.one_le_pow _ _ (by omega)
      simpa only [pow_one] using (show (2^(n+1))^1≤(2^(n+1))^4 from Nat.pow_le_pow_right h (by omega)))
  have hv':FamilyNamespace.variableCount n (3*n-4)≤36*(n+2)^9*(2^(n+1))^4:=by
    exact hv.trans (by
      unfold FrontendNamespaceEnvelope.scale
      simpa only [Nat.mul_assoc] using Nat.mul_le_mul_left 36 (Nat.mul_le_mul hp ht))
  have hs:3*n-4≤3*n:=Nat.sub_le ..
  have hmag:NumericOriginalFields.magnitude n (3*n-4)≤32*(n+2)^2:=by
    unfold NumericOriginalFields.magnitude;nlinarith
  have hp':(n+2)^2≤(n+2)^9:=Nat.pow_le_pow_right (by omega) (by omega)
  have ht':1≤(2^(n+1))^4:=Nat.one_le_pow _ _ (Nat.one_le_pow _ _ (by omega))
  have hmag':NumericOriginalFields.magnitude n (3*n-4)≤32*(n+2)^9*(2^(n+1))^4:=
    hmag.trans (by nlinarith [Nat.mul_le_mul hp' ht'])
  unfold NumericActivationInputs.originalCost E NumericClosedNamespace.envelope
  nlinarith

theorem inputs (n:Nat):NumericActivationInputs.inputCost n+1≤3*E n:=by
  have ho:=original n;have he:=positive n
  unfold NumericActivationInputs.inputCost E at *
  omega

def activationCost (n:Nat):Nat:=1000*(E n)^3

theorem level (n:Nat):NumericActualActivation.levelCost n≤activationCost n:=by
  have he:=positive n
  have hi:=inputs n
  have hi0:NumericActivationInputs.inputCost n≤3*E n:=by omega
  have hh:NumericActivationInputs.inputCost n+1+2≤5*E n:=by omega
  have hsq:(NumericActivationInputs.inputCost n+1+2)^2≤25*(E n)^2:=by nlinarith
  have hm:=Nat.mul_le_mul hsq hi
  unfold NumericActualActivation.levelCost NumericGuardFields.rowCost activationCost
  change E n+1+(NumericActivationInputs.inputCost n+1+
    (NumericActivationInputs.inputCost n+1+2)^2*(NumericActivationInputs.inputCost n+1))+
    NumericActivationInputs.inputCost n+3≤1000*(E n)^3
  have h13:E n≤(E n)^3:=by simpa using Nat.pow_le_pow_right he (show 1≤3 by omega)
  nlinarith

/-- Full activation numeric envelope with a linear reserve contribution.
The unit is integer magnitude; this is not a serialized byte count. -/
theorem program (n N:Nat) (hn:2≤n) (hN:FamilyNamespace.variableCount n (3*n-4)≤N):
    ∀c∈RecordedActualActivation.program n hn N,Content (N+activationCost n) c:=by
  intro c hc
  exact RecursiveOperandBounds.content_mono (Nat.add_le_add_left (level n) N) c
    (NumericActualActivation.program n N hn hN c hc)

#print axioms original
#print axioms level
#print axioms program
end L3Emitter.NumericActivationEnvelope

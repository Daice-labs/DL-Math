import FormulaSize
import PolTapeBytes

set_option linter.unusedSimpArgs false

namespace L3Emitter.CofactorBytes
open EREF REDWitness ReferenceTransport ClauseTransport CofactorClause
open CofactorSemantics FamilyNamespace FormulaSize PolTapeBytes TemplateBytes

def width (n s offset B : Nat) : Nat := databaseBound n s+offset+
  3*s*truthRows n+variableCount (n+1) s+B+4

theorem low_bound (n s offset g p x : Nat) (hg : g<s) (hp : p<3)
    (hx : x<truthRows n) : low n offset g p x≤offset+3*s*truthRows n := by
  have h := Nat.mul_le_mul_right (truthRows n) (show 3*g+p+1≤3*s by omega)
  unfold low
  nlinarith

theorem locate_bound (rows : List Row) (R : Row) (hR : R∈rows) :
    locate rows R≤rows.length := by
  have h := List.idxOf_lt_length_iff.mpr hR
  unfold locate; omega

theorem links_bound (n s offset B g x : Nat) (hg : g<s) (hx : x<truthRows n)
    (a b c side : Bool) : ∀ p∈links n s offset B g x a b c side,
      LinkBound (width n s offset B) p := by
  have one : ∀ p<3, ∀ sign,
      LinkBound (width n s offset B) (link n s offset B g p x side sign) := by
    intro p hp sign
    have hlo := low_bound n s offset g p x hg hp hx
    have hid := locate_bound _ _ (link_in_bank n s offset B g p x hg hp hx side sign)
    have hlen := database_length_bound n s offset B
    constructor
    · change (output (low n offset g p x) sign).natAbs≤_
      cases sign <;> simp only [output,Bool.false_eq_true,↓reduceIte,Int.natAbs_neg,
        Int.natAbs_natCast,Bool.true_eq] <;> unfold width <;> omega
    · change locate _ _≤_
      unfold width; omega
  intro p hp
  simp only [links,List.mem_cons,List.not_mem_nil,or_false] at hp
  rcases hp with rfl|rfl|rfl|rfl
  · exact one 0 (by decide) (!a)
  · exact one 1 (by decide) (!b)
  · exact one 2 (by decide) (!c)
  · have hfn := (encode_bounds (n+1) s (.fn g (2*a.toNat+b.toNat))
      ⟨hg,by cases a <;> cases b <;> decide⟩).2
    refine ⟨?_,True.intro⟩
    change (fnLiteral n s g a b c).natAbs≤_
    cases c <;> simp only [fnLiteral,output,Bool.false_eq_true,↓reduceIte,
      Int.natAbs_neg,Int.natAbs_natCast,Bool.true_eq] <;> unfold width <;> omega

def leafDocument (n s offset B g x : Nat) (a b c : Bool) : Doc :=
  tapeDoc (tape n s offset B g x a b c)

def leafBound (n s offset B : Nat) : Nat := 7+70*(3+digits (width n s offset B))

theorem leaf_serialized_bound (n s offset B g x : Nat) (hg : g<s)
    (hx : x<truthRows n) (a b c : Bool) :
    (emit (leafDocument n s offset B g x a b c)).length≤leafBound n s offset B := by
  have hs : ∀ side, sourceId n s offset B g x a b c side≤width n s offset B := by
    intro side
    have h0 := locate_bound _ _ (original_in_database n s offset B g x hg hx a b c side)
    have h1 := database_length_bound n s offset B
    change locate _ _≤_
    unfold width; omega
  exact cofactor_four_bytes (width n s offset B) _ _ _ _ _ (by unfold width; omega)
    (hs false) (hs true) (by simp only [Int.natAbs_natCast]; unfold width; omega)
    (by simp [links]) (by simp [links])
    (links_bound n s offset B g x hg hx a b c false)
    (links_bound n s offset B g x hg hx a b c true)

def semanticsDocument (n s offset B : Nat) : Doc :=
  (List.range s).flatMap fun g => (List.range (truthRows n)).flatMap fun x =>
    [false,true].flatMap fun a => [false,true].flatMap fun b =>
      [false,true].flatMap fun c => leafDocument n s offset B g x a b c

theorem document_flatMap_bound {α : Type} (xs : List α) (f : α→Doc) (M : Nat)
    (hf : ∀ x∈xs,exactBytes (f x)≤M) : exactBytes (xs.flatMap f)≤xs.length*M := by
  induction xs with
  | nil => simp [exactBytes]
  | cons x xs ih =>
    have hh := hf x (by simp)
    have ht := ih (by intro y hy; exact hf y (by simp [hy]))
    simp only [List.flatMap_cons,exactBytes_append,List.length_cons]
    nlinarith

theorem semantics_serialized_bound (n s offset B : Nat) :
    (emit (semanticsDocument n s offset B)).length≤
      8*s*truthRows n*leafBound n s offset B := by
  rw [emit_length]
  unfold semanticsDocument
  have h := document_flatMap_bound (List.range s)
    (fun g => (List.range (truthRows n)).flatMap fun x =>
      [false,true].flatMap fun a => [false,true].flatMap fun b =>
        [false,true].flatMap fun c => leafDocument n s offset B g x a b c)
    (8*truthRows n*leafBound n s offset B) (by
      intro g hg
      have h' := document_flatMap_bound (List.range (truthRows n))
        (fun x => [false,true].flatMap fun a => [false,true].flatMap fun b =>
          [false,true].flatMap fun c => leafDocument n s offset B g x a b c)
        (8*leafBound n s offset B) (by
          intro x hx
          have hv := fun a b c => leaf_serialized_bound n s offset B g x
            (List.mem_range.mp hg) (List.mem_range.mp hx) a b c
          simp only [emit_length] at hv
          simp only [List.flatMap_cons,List.flatMap_nil,List.append_nil,exactBytes_append]
          have h000 := hv false false false
          have h001 := hv false false true
          have h010 := hv false true false
          have h011 := hv false true true
          have h100 := hv true false false
          have h101 := hv true false true
          have h110 := hv true true false
          have h111 := hv true true true
          omega)
      simpa [Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using h')
  simpa [Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using h

/-- An explicit bound in k for this section ONLY. The offset is deliberately
    specified here, not claimed to be the still-unproved full frontend offset. -/
def sectionOffset (k : Nat) : Nat := variableCount k (3*k-4)+1
def sectionDocument (k : Nat) : Doc :=
  semanticsDocument (k-1) (3*k-4) (sectionOffset k) (sectionOffset k)
def sectionBound (k : Nat) : Nat :=
  8*(3*k-4)*truthRows (k-1)*leafBound (k-1) (3*k-4) (sectionOffset k) (sectionOffset k)

theorem actual_section_bound_in_k (k : Nat) :
    (emit (sectionDocument k)).length≤sectionBound k := semantics_serialized_bound ..

#print axioms leaf_serialized_bound
#print axioms semantics_serialized_bound
#print axioms actual_section_bound_in_k
end L3Emitter.CofactorBytes

import HitBranchBinding
namespace L3Emitter.HitBranchBank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram HitBranchBinding

def mid (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row):=D++HitExclusions.rows n hn c++cellRows n hn c
def endRows (n:Nat) (hn:2≤n) (c:Choice n):=[forwardRow n hn c,backRow n hn c]
def tailProgram (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row):Program:=
  [(forwardRow n hn c,forwardTape n hn c D),(backRow n hn c,backTape n hn c D)]
def rows (n:Nat) (hn:2≤n) (c:Choice n):=HitExclusions.rows n hn c++cellRows n hn c++endRows n hn c
def program (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row):Program:=
  HitExclusions.program n hn c D++cellProgram n hn c (D++HitExclusions.rows n hn c)++tailProgram n hn c (mid n hn c D)

theorem checks (n:Nat) (hn:2≤n) (c:Choice n) (hc:c∈CategoryPrograms.choices n hn)
    (D:List Row) (hd:∀R∈UnaryValueBank.result n hn,R∈D):
    check D (program n hn c D)=some (D++rows n hn c):=by
  have h1:=HitExclusions.checks n hn c hc D hd
  have h2:=cell_checks n hn c (D++HitExclusions.rows n hn c)
    (fun R h=>List.mem_append_left _ (hd R h)) (fun R h=>List.mem_append_right _ h)
  have keep:∀R∈UnaryValueBank.result n hn,R∈mid n hn c D:=
    fun R h=>List.mem_append_left _ (List.mem_append_left _ (hd R h))
  have hf:=forward_check n hn c hc (mid n hn c D) keep
  have hb:=back_check n hn c (mid n hn c D) keep (fun R h=>List.mem_append_right _ h)
  have ht:=IndependentProgram.check_base (mid n hn c D) (tailProgram n hn c (mid n hn c D)) (by
    intro cmd hc;simp only [tailProgram,List.mem_cons,List.not_mem_nil,or_false] at hc
    rcases hc with rfl|rfl;exact hf;exact hb)
  have h12:=check_append _ _ _ _ _ h1 h2
  have all:=check_append _ _ _ _ _ h12 ht
  simpa only [program,rows,mid,tailProgram,endRows,outputs,List.map_cons,List.map_nil,List.append_assoc] using all

def body (n:Nat) (hn:2≤n) (cs:List (Choice n)):=cs.flatMap (rows n hn)
def loop (n:Nat) (hn:2≤n) (D:List Row):List (Choice n)→Program
  | []=>[]
  | c::cs=>program n hn c D++loop n hn (D++rows n hn c) cs

theorem loop_checks (n:Nat) (hn:2≤n) (cs:List (Choice n))
    (hc:∀c∈cs,c∈CategoryPrograms.choices n hn) (D:List Row)
    (hd:∀R∈UnaryValueBank.result n hn,R∈D):
    check D (loop n hn D cs)=some (D++body n hn cs):=by
  induction cs generalizing D with
  | nil=>simp [loop,body,check]
  | cons c cs ih=>
    have h1:=checks n hn c (hc c (by simp)) D hd
    have h2:=ih (fun d h=>hc d (by simp [h])) (D++rows n hn c) (fun R h=>List.mem_append_left _ (hd R h))
    simpa only [loop,body,List.flatMap_cons,List.append_assoc] using check_append _ _ _ _ _ h1 h2

def base (n:Nat) (hn:2≤n):=RankEvaluationBank.result n hn
def result (n:Nat) (hn:2≤n):=base n hn++body n hn (CategoryPrograms.choices n hn)
def emitted (n:Nat) (hn:2≤n):=loop n hn (base n hn) (CategoryPrograms.choices n hn)

theorem base_keeps (n:Nat) (hn:2≤n):∀R∈UnaryValueBank.result n hn,R∈base n hn:=by
  intro R hr
  exact List.mem_append_left _ (RankValueBank.retains n hn R hr)

theorem original_to_hit_relations (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (RankEvaluationBank.original_to_rank_evaluation n hn)
    (check_trace _ _ _ (loop_checks n hn _ (fun c h=>h) _ (base_keeps n hn)))

theorem retains (n:Nat) (hn:2≤n):∀R∈UnaryValueBank.result n hn,R∈result n hn:=
  fun R h=>List.mem_append_left _ (base_keeps n hn R h)

theorem relations (n:Nat) (hn:2≤n) (c:Choice n) (hc:c∈CategoryPrograms.choices n hn):
    forwardRow n hn c∈result n hn ∧ backRow n hn c∈result n hn:=by
  have keep:∀R∈endRows n hn c,R∈result n hn:=fun R h=>List.mem_append_right _
    (List.mem_flatMap.mpr ⟨c,hc,List.mem_append_right _ h⟩)
  exact ⟨keep _ (by simp [endRows]),keep _ (by simp [endRows])⟩

#print axioms checks
#print axioms original_to_hit_relations
#print axioms relations
end L3Emitter.HitBranchBank

import ActualLowerComposition
import ReplacementStageSize
import FormulaSize
namespace L3Emitter.FinalEvaluationSize
open EREF AliasNetwork AliasProgram FinalOutputDefinitions

theorem selected_leaf (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (i:Fin (W n)) (D:List Row):
    (FinalSelectedCases.leaf n hn x a b side i D).length≤4:=by
  unfold FinalSelectedCases.leaf
  split
  · simp [FinalSelectedCases.earlierProgram,FinalSelectedEvaluation.program,SelectedOutputPOL.program]
  · simp [FinalSelectedCases.lastProgram]
theorem selected_join (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (D:List Row):
    (FinalSelectedJoin.program n hn x a b side D).length≤4*W n+1:=by
  have h:=U2ConstructionSize.fold_commands (FinalSelectedCases.leaf n hn x a b side)
    (FinalSelectedCases.rows n hn x a b side) (List.finRange (W n)) D 4
    (fun i _ E=>selected_leaf n hn x a b side i E)
  simp only [List.length_finRange] at h
  simp only [FinalSelectedJoin.program,List.length_append,List.length_cons,List.length_nil]
  omega
theorem kept (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (D:List Row):
    (FinalKeptEvaluation.program n hn x a b side D).length=6:=by
  simp [FinalKeptEvaluation.program,FinalKeptEvaluation.coreProgram,GateUnaryCompositionPOL.program]
theorem phase (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (D:List Row):
    (FinalEvaluationJoin.phaseProgram n hn x a b side D).length≤4*W n+8:=by
  have h:=selected_join n hn x a b side (D++FinalKeptEvaluation.rows n hn x a b side)
  simp only [FinalEvaluationJoin.phaseProgram,List.length_append,List.length_cons,List.length_nil,kept]
  omega
theorem leaf (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool) (D:List Row):
    (FinalEvaluationJoin.program n hn x a b D).length≤8*W n+17:=by
  have h0:=phase n hn x a b false D
  have h1:=phase n hn x a b true (D++FinalEvaluationJoin.phaseRows n hn x a b false)
  simp only [FinalEvaluationJoin.program,List.length_append,List.length_cons,List.length_nil]
  omega
theorem job_count (n:Nat):(FinalEvaluationBank.jobs n).length=4*T n:=by
  simp [FinalEvaluationBank.jobs,List.length_flatMap,List.map_map,Function.comp_def,List.sum_replicate]
  ring
theorem bank (n:Nat) (hn:2≤n):(FinalEvaluationBank.program n hn).length≤(128*n-60)*2^n:=by
  have h:=U2ConstructionSize.fold_commands (FinalEvaluationBank.leaf n hn) (FinalEvaluationBank.rows n hn)
    (FinalEvaluationBank.jobs n) (FinalEvaluationContext.D n hn) (8*W n+17)
    (fun j _ E=>leaf n hn j.1 j.2.1 j.2.2 E)
  rw [job_count] at h
  have hw:W n=4*n-4:=by unfold W AliasAssembly.width RankConstruction.width;omega
  have hc:4*(8*W n+17)=128*n-60:=by rw [hw];omega
  change _≤(4*T n)*(8*W n+17) at h
  have he:(4*T n)*(8*W n+17)=(128*n-60)*2^n:=by rw [←hc];unfold T FamilyNamespace.truthRows;ring
  rw [he] at h
  exact h
theorem image_commands (n:Nat) (hn:2≤n):(FinalEvaluationImage.program n hn).length=8*2^n:=by
  simp [FinalEvaluationImage.program,FinalEvaluationImage.jobs,List.length_flatMap,List.map_map,Function.comp_def,List.sum_replicate,T,FamilyNamespace.truthRows]
  ring
theorem evaluation_commands_in_n (n:Nat) (hn:2≤n):
    (FinalEvaluationBank.program n hn).length+(FinalEvaluationImage.program n hn).length≤(128*n-52)*2^n:=by
  have h:=Nat.add_le_add_right (bank n hn) (FinalEvaluationImage.program n hn).length
  rw [image_commands,←Nat.add_mul] at h
  have he:128*n-60+8=128*n-52:=by omega
  rw [he] at h
  simpa only [image_commands] using h

theorem actual_inputs (n:Nat) (hn:2≤n):
    (ActualLowerComposition.inputs n hn).length=(OriginalEncoding.rows n (3*n-4)).length:=by
  simp [ActualLowerComposition.inputs,LowerActivationImage.inputs,OriginalEncoding.rows]
/-- Main-line composition overhead only: the recursive tail occurs once.
RED obligation tapes and serialized bytes are NOT counted by this theorem. -/
theorem composition_commands (n:Nat) (hn:2≤n) (m:Nat):
    (ActualLowerComposition.inputs n hn).length+((ActualLowerComposition.inputs n hn).length+m+1)≤
      m+2*FormulaSize.rowBound n (3*n-4)+1:=by
  rw [actual_inputs]
  have h:=FormulaSize.original_rows_bound n (3*n-4)
  omega
#print axioms evaluation_commands_in_n
#print axioms composition_commands
end L3Emitter.FinalEvaluationSize

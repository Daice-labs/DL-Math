import FamilyNamespace
import NormalizationPOL

open Classical
set_option linter.unusedSimpArgs false

namespace L3Emitter.FamilyRows
open EREF EREF.GeneralRED FamilyNamespace

abbrev NamedLit := Wire × Bool

def lit (k s : Nat) (l : NamedLit) : Int :=
  if l.2 then (encode k s l.1 : Int) else -(encode k s l.1 : Int)

theorem lit_nonzero (k s : Nat) (l : NamedLit) (h : Valid k s l.1) : lit k s l≠0 := by
  have hh := (encode_bounds k s l.1 h).1
  unfold lit
  split <;> omega

structure Spec where
  literals : List NamedLit
  rhs : Int
  deriving DecidableEq, Repr

def Spec.row (k s : Nat) (r : Spec) : Row :=
  normalize (r.literals.map fun l => (1, lit k s l)) r.rhs

def Spec.valid (k s : Nat) (r : Spec) : Prop :=
  ∀ l ∈ r.literals, Valid k s l.1

def Spec.rename (f : Wire → Wire) (r : Spec) : Spec :=
  ⟨r.literals.map (fun l => (f l.1,l.2)),r.rhs⟩

theorem row_value (k s : Nat) (r : Spec) (h : r.valid k s) (α : Val) :
    (r.row k s).val α = REDWitness.sum α (r.literals.map (lit k s)) - r.rhs := by
  unfold Spec.row
  rw [val_normalize]
  · have hs : ∀ ls : List NamedLit,
        tvalZ α (ls.map fun l => (1,lit k s l)) = REDWitness.sum α (ls.map (lit k s)) := by
      intro ls
      induction ls with
      | nil => rfl
      | cons l ls ih => simp [tvalZ, REDWitness.sum, ih]
    rw [hs]
  · intro t ht
    obtain ⟨l,hl,rfl⟩ := List.mem_map.mp ht
    exact lit_nonzero k s l (h l hl)

/-- A simultaneous map on the actual original IDs. Positive original IDs are
    unambiguous by encode_injective; variables outside the original namespace
    are left alone. This is a mathematical witness, not yet a Python binding. -/
noncomputable def wireWitness (k s : Nat) (f : Wire → Wire)
    (hf : ∀ w, Valid k s w → Valid k s (f w)) : Witness := fun v =>
  if h : ∃ w, Valid k s w ∧ encode k s w=v then
    .literal (encode k s (f (Classical.choose h)) : Int)
      (by have hb := (encode_bounds k s _ (hf _ (Classical.choose_spec h).1)).1; omega)
  else if hz : v=0 then .constant false
  else .literal (v : Int) (by omega)

theorem witness_at (k s : Nat) (f : Wire → Wire)
    (hf : ∀ w, Valid k s w → Valid k s (f w)) (w : Wire) (hw : Valid k s w)
    (α : Val) :
    applyWitness (wireWitness k s f hf) α (encode k s w) = α (encode k s (f w)) := by
  have he : ∃ u, Valid k s u ∧ encode k s u=encode k s w := ⟨w,hw,rfl⟩
  have hu : Classical.choose he=w :=
    encode_injective k s _ _ (Classical.choose_spec he).1 hw (Classical.choose_spec he).2
  unfold applyWitness wireWitness
  simp only [dif_pos he, Image.eval, hu]
  have hp : (0:Int)<encode k s (f w) := by exact_mod_cast (encode_bounds k s _ (hf w hw)).1
  simp [hp]
  omega

theorem witness_literal (k s : Nat) (f : Wire → Wire)
    (hf : ∀ w, Valid k s w → Valid k s (f w)) (l : NamedLit) (hl : Valid k s l.1)
    (α : Val) :
    litVal (applyWitness (wireWitness k s f hf) α) (lit k s l) =
      litVal α (lit k s (f l.1,l.2)) := by
  rcases l with ⟨w,b⟩
  have hp : 0<encode k s w := (encode_bounds k s w hl).1
  have hq : 0<encode k s (f w) := (encode_bounds k s _ (hf w hl)).1
  cases b <;> simp [lit, litVal, hp, hq,
    show ¬(encode k s w:Int)<0 by omega,
    show ¬(encode k s (f w):Int)<0 by omega,
    witness_at k s f hf w hl]

theorem rename_valid (k s : Nat) (f : Wire → Wire)
    (hf : ∀ w, Valid k s w → Valid k s (f w)) (r : Spec) (hr : r.valid k s) :
    (r.rename f).valid k s := by
  intro l hl
  change l ∈ r.literals.map (fun l => (f l.1,l.2)) at hl
  obtain ⟨u,hu,rfl⟩ := List.mem_map.mp hl
  exact hf _ (hr _ hu)

/-- Exact normalized PB equality for all ORIGINAL-row templates. -/
theorem subst_row (k s : Nat) (f : Wire → Wire)
    (hf : ∀ w, Valid k s w → Valid k s (f w)) (r : Spec) (hr : r.valid k s) :
    substRow (r.row k s) (wireWitness k s f hf) = (r.rename f).row k s := by
  apply canonical_ext _ _ (canonical_substRow _ _) (canonical_normalize _ _)
  intro α
  change (substRow (r.row k s) (wireWitness k s f hf)).val α = ((r.rename f).row k s).val α
  rw [val_substRow, row_value _ _ r hr,
    row_value _ _ _ (rename_valid k s f hf r hr)]
  simp only [Spec.rename, REDWitness.sum, List.map_map, Function.comp_def]
  congr 1
  congr 1
  apply List.map_congr_left
  intro l hl
  exact witness_literal k s f hf l (hr l hl) α

theorem row_of_perm (k s : Nat) (r q : Spec) (hr : r.valid k s) (hq : q.valid k s)
    (hp : r.literals.Perm q.literals) (hb : r.rhs=q.rhs) : r.row k s=q.row k s := by
  apply canonical_ext _ _ (canonical_normalize _ _) (canonical_normalize _ _)
  intro α
  change (r.row k s).val α = (q.row k s).val α
  rw [row_value _ _ _ hr, row_value _ _ _ hq, hb]
  unfold REDWitness.sum
  rw [List.Perm.sum_eq ((hp.map (lit k s)).map (litVal α))]

#print axioms subst_row
#print axioms row_of_perm
end L3Emitter.FamilyRows

import LowerSelectorALO
namespace L3Emitter.LowerSelectorComplete
open EREF EREF.GeneralRED REDWitness FamilyRows

theorem predecessor_kept (n:Nat) (hn:2≤n):∀R∈LowerSelectorAMO.result n hn,R∈LowerSelectorALO.result n hn:=
  fun R h=>List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ h))

theorem all_selector_images (n:Nat) (hn:2≤n) (r:Spec) (hr:r∈OriginalEncoding.selectorsBlock n (3*n-4)):
    LowerTransferImage.image n hn r∈LowerSelectorALO.result n hn:=by
  obtain ⟨t,p,b,ht,hp,rfl⟩:=(OriginalEncoding.selectors_mem n (3*n-4) r).mp hr
  cases b
  · exact predecessor_kept n hn _ (LowerSelectorAMO.all_AMO_images n hn t p ht hp)
  · exact LowerSelectorALO.all_ALO_images n hn t p ht hp

theorem all_transfer_images (n:Nat) (hn:2≤n) (r:Spec) (hr:r∈OriginalEncoding.transfersBlock n (3*n-4)):
    LowerTransferImage.image n hn r∈LowerSelectorALO.result n hn:=
  predecessor_kept n hn _ (List.mem_append_left _ (LowerTransferImage.all_transfer_images n hn r hr))

#print axioms all_selector_images
#print axioms all_transfer_images
end L3Emitter.LowerSelectorComplete

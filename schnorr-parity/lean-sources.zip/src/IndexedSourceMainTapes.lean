import SourceCardinalityMainTapes
set_option maxRecDepth 4096
namespace L3Emitter.IndexedSourceMainTapes
open EREF EREF.GeneralRED AliasNetwork RecordedPortLinks U2ConstructionSize GlobalFixedMainTapes
variable {w : Nat} {C : Type}

def unitCost (c W : Nat):Nat:=c*(2+2*W+2*W^2)+2*c+2

theorem block (D : List Row) (cs : List C) (v : C→Bit) (a : C→AliasBits w) (q : AliasBits w)
    (ls : List (Lit w)) (W : Nat) (hl : ls.length≤W) :
    tokens (IndexedSourceOneHot.block D cs v a q ls)≤unitCost cs.length W := by
  have h:=map_factor cs (fun c=>Resolution.branch (RecordedPortLinks.row q ls) (-(v c).val))
    (fun c=>RecordedPortLinks.tape D (v c) (a c) q ls) (2+2*W+2*W^2) (by
      intro c hc;dsimp only
      have hs:=Nat.pow_le_pow_left hl 2
      exact (SelectedVectorTapeBounds.tape D (v c) (a c) q ls).trans (by omega))
  change tokens (IndexedSourceOneHot.casesProgram D cs v a q ls)≤_ at h
  rw [IndexedSourceOneHot.block,tokens_append]
  simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
    ProjectionTrace.joinCaseTokens,CaseJoin.join_token_count,List.length_map]
  change tokens (IndexedSourceOneHot.casesProgram D cs v a q ls)+(2*cs.length+2+0)≤_
  unfold unitCost;nlinarith

theorem loop (D : List Row) (cs : List C) (v : C→Bit) (a : C→AliasBits w) (q : AliasBits w)
    (ss : List (List (Lit w))) (W : Nat) (hl : ∀ls∈ss,ls.length≤W) :
    tokens (IndexedSourceOneHot.loop D cs v a q ss)≤ss.length*unitCost cs.length W := by
  induction ss generalizing D with
  | nil=>simp [IndexedSourceOneHot.loop,tokens]
  | cons s ss ih=>
    have h:=block D cs v a q s W (hl s (by simp))
    have ht:=ih (D++IndexedSourceOneHot.blockRows cs v q s) (fun l h=>hl l (by simp [h]))
    simp only [IndexedSourceOneHot.loop,tokens_append,List.length_cons];nlinarith

theorem indexed (n : Nat) (D : List Row) (cs : List C) (v : C→Bit) (a : C→AliasBits w) (q : AliasBits w)
    (hw:w≤4*(n+1)) (hc:cs.length≤4*(n+1)) :
    tokens (IndexedSourceOneHot.program D cs v a q)≤6100*(n+1)^5 := by
  have h:=loop D cs v a q (SelectedVectorOneHot.specs w) (w+2) (fun l h=>SelectedVectorTapeBounds.spec_width l h)
  have hspec:=ConstructionOneHotCount.specifications w
  have hs:=Nat.pow_le_pow_left hw 2
  have hw2:w+2≤6*(n+1):=by omega
  have hs2:=Nat.pow_le_pow_left hw2 2
  have hb:2+2*(w+2)+2*(w+2)^2≤86*(n+1)^2:=by nlinarith
  have hm:=Nat.mul_le_mul hc hb
  have hp:unitCost cs.length (w+2)≤354*(n+1)^3:=by unfold unitCost;nlinarith
  have hh:(SelectedVectorOneHot.specs w).length≤17*(n+1)^2:=by nlinarith
  have hall:=Nat.mul_le_mul hh hp
  exact h.trans (by nlinarith)

theorem selected (n : Nat) (D : List Row) (cs : List Bit) (a : Bit→AliasBits w) (q : AliasBits w)
    (hw:w≤4*(n+1)) (hc:cs.length≤4*(n+1)) :
    tokens (SelectedVectorOneHot.program D cs a q)≤6100*(n+1)^5 := by
  have h:=SelectedVectorTapeBounds.selected D cs a q
  have hs:=Nat.pow_le_pow_left hw 2
  have hs2:=Nat.pow_le_pow_left (show w+2≤6*(n+1) by omega) 2
  have hb:2+2*(w+2)+2*(w+2)^2≤86*(n+1)^2:=by nlinarith
  have hm:=Nat.mul_le_mul hc hb
  have hp:cs.length*(2+2*(w+2)+2*(w+2)^2)+2*cs.length+2≤354*(n+1)^3:=by nlinarith
  have hh:1+w^2≤17*(n+1)^2:=by nlinarith
  have hall:=Nat.mul_le_mul hh hp
  have ht:w^2+2*w≤24*(n+1)^2:=by nlinarith
  have hp25:=Nat.pow_le_pow_right (show 0<n+1 by omega) (show 2≤5 by omega)
  nlinarith

theorem gate_step (n : Nat) (hn : 2≤n) (g : Nat) (hg:g<3*(n+1)-4) (D : List Row) :
    tokens (GateOrderSources.stepProgram n hn g D)≤25000*(n+1)^5 := by
  have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  have port (p : Nat) (E : List Row):tokens (GatePortOneHot.program n hn g p E)≤6100*(n+1)^5:=by
    apply selected n _ _ _ _ hw
    simp only [GatePortOneHot.cs,SelectedVectorClauses.choices,List.length_map,List.length_range];omega
  have mux:tokens (MuxSourceStep.program n hn g (GateOrderSources.afterRight n hn g D))≤6100*(n+1)^5+4:=by
    have h:=indexed n (MuxSourceStep.seeded n hn g (GateOrderSources.afterRight n hn g D))
      [true,false] (MuxSourceStep.choices n hn g) (MuxSourceStep.inputs n hn g) (MuxSourceStep.vector n hn g) hw (by simp;omega)
    simp only [MuxSourceStep.program,tokens_append]
    have hs:tokens (MuxSourceStep.seed n hn g)=4:=rfl
    rw [hs];omega
  have source:tokens (GateSourceOneHot.program n hn g (GateOrderSources.afterMux n hn g D))≤6100*(n+1)^5:=by
    apply indexed n _ _ _ _ _ hw
    simp only [CategoryPrograms.cats,GateCategories.categories,List.length_cons,List.length_map,List.length_range]
    omega
  have p0:=port 0 D;have p1:=port 1 (GateOrderSources.afterLeft n hn g D)
  rw [GateOrderSources.stepProgram,tokens_append,tokens_append,tokens_append]
  have hp:1≤(n+1)^5:=Nat.one_le_pow _ _ (by omega)
  omega

theorem run (n : Nat) (hn : 2≤n) (g m : Nat) (hm:g+m≤3*(n+1)-4) (D : List Row) :
    tokens (GateOrderSources.program n hn g D m)≤m*(25000*(n+1)^5) := by
  induction m generalizing g D with
  | zero=>simp [GateOrderSources.program,tokens]
  | succ m ih=>
    have h:=gate_step n hn g (by omega) D
    have ht:=ih (g+1) (by omega) (GateOrderSources.stepResult n hn g D)
    rw [GateOrderSources.program,tokens_append,Nat.succ_mul];omega

theorem complete (n : Nat) (hn : 2≤n) : tokens (GateOrderSources.fullProgram n hn)≤75000*(n+1)^6 := by
  have h:=run n hn 1 (3*(n+1)-5) (by omega) (SourceAuxBank.result n hn)
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.sub_le (3*(n+1)) 5)).trans_eq (by ring))
#print axioms complete
end L3Emitter.IndexedSourceMainTapes

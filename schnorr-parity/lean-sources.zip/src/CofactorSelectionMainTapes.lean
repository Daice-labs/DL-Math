import SelectionMainTapes
namespace L3Emitter.CofactorSelectionMainTapes
open EREF EREF.GeneralRED MainTapeRecurrence U2ConstructionSize

theorem definition_zero (D : List Row) (q : Nat) (defs : L3.Defs) : count (RecordedDefinitions.emit D q defs)=0 :=
  CompleteFinalRowTapes.gate_zero ..

theorem bit_leaf (D : List Row) (all : List Int) (B c : Int) (f : Int→Bool) :
    (OneHotBit.tokens D all f c B).length≤4*all.length+4 := by
  unfold OneHotBit.tokens;split
  · change 1≤_;omega
  · rw [ChoiceProjection.exclude_token_count]
    have h:(OneHotBit.ones all f).length≤all.length:=List.length_filter_le ..
    omega

theorem bit_loop (D : List Row) (all : List Int) (B : Int) (f : Int→Bool) (todo : List Int) :
    tokens (OneHotBit.program D all B f todo)≤todo.length*(4*all.length+4) := by
  induction todo generalizing D with
  | nil=>simp [OneHotBit.program,tokens]
  | cons c cs ih=>
    have h:=bit_leaf D all B c f
    have ht:=ih (D++[OneHotBit.target c B f])
    change (OneHotBit.tokens D all f c B).length+tokens (OneHotBit.program _ all B f cs)≤(cs.length+1)*(4*all.length+4)
    nlinarith

theorem bit (D : List Row) (m : Nat) (xs : List Int) (f : Int→Bool) :
    count (RecordedOneHotBit.program D m xs f)≤4*xs.length^2+4*xs.length := by
  rw [RecordedOneHotBit.program,append,definition_zero,pol_program]
  change 0+tokens (OneHotBit.program _ _ _ _ _)≤_
  have h:=bit_loop (OneHotBit.defined D m xs f) xs (m+1:Int) f xs
  nlinarith

theorem value (D : List Row) (m : Nat) (xs : List Int) (f : Int→Int) :
    count (RecordedSelectedValue.program D m xs f)≤8*xs.length^2+4*xs.length := by
  have hd:=SelectionMainTapes.definitions D (SelectedValue.cmds m f xs)
  rw [ConstructionCofactorCount.value_definitions] at hd
  have ht:=SelectedValueSize.selected_tokens D m xs f
  rw [RecordedSelectedValue.program,append,RecordedSelectedValue.definitionProgram,append,definition_zero,pol_program]
  change _+0+PrioritySize.tokensCount _≤_
  nlinarith

theorem complete (k : Nat) (hk : 3≤k) : count (RecordedCofactorSelection.program k hk)≤25000*(k+1)^4 := by
  have h0:=SelectionMainTapes.selected k hk
  have h1:=bit (ForcingFamily.selected k hk) (RestrictionBit.upper k hk) (RestrictionBit.choices k hk) (RestrictionBit.predicate k hk)
  have hc:=(ConstructionCofactorCount.restriction_choices k hk).trans (Nat.mul_le_mul_left 36 (Nat.pow_le_pow_left (show k≤k+1 by omega) 2))
  have hc2:=Nat.pow_le_pow_left hc 2
  have h2:count (RecordedRankDefinitions.program k hk)≤90*(k+1)^4:=
    (FrontendMainTapeLength.definitions _ _).trans (ConstructionCofactorCount.rank k hk)
  have h3:=value (RankConstruction.database k hk) (ConstantConstruction.m k hk) (ConstantConstruction.choices k hk) (ConstantLookup.value k hk)
  have hx:=(SelectedValueSize.choice_count k hk).trans (Nat.mul_le_mul_left 36 (Nat.pow_le_pow_left (show k≤k+1 by omega) 2))
  have hx2:=Nat.pow_le_pow_left hx 2
  have h24:(k+1)^2≤(k+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  rw [RecordedCofactorSelection.program,append,append,RecordedCofactorSelection.restrictionProgram,append]
  nlinarith
#print axioms complete
end L3Emitter.CofactorSelectionMainTapes

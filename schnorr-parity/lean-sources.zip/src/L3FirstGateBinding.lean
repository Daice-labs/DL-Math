import L3FirstGate

namespace L3
open EREF EREF.GeneralRED

theorem All.of_mem {α : Type} {P : α → Prop} (xs : List α) (h : ∀x∈xs,P x) : All P xs := by
  induction xs with
  | nil => trivial
  | cons x xs ih => exact ⟨h x (by simp),ih (fun y hy => h y (by simp [hy]))⟩

namespace Fam
variable (F : Fam)

def other0 : List Int := (List.range' 1 (F.k-1)).map fun j => (F.sel 0 0 j : Int)
def other1 : List Int := (F.sel 0 1 0 : Int)::((List.range' 2 (F.k-2)).map fun j => (F.sel 0 1 j : Int))

theorem others_nz : (∀l∈F.other0,l≠0) ∧ (∀l∈F.other1,l≠0) := by
  constructor
  · intro l hl; obtain ⟨j,_,rfl⟩ := List.mem_map.mp hl
    have := F.sel_pos 0 0 j; omega
  · intro l hl
    rcases List.mem_cons.mp hl with rfl | hl
    · have := F.sel_pos 0 1 0; omega
    · obtain ⟨j,_,rfl⟩ := List.mem_map.mp hl
      have := F.sel_pos 0 1 j; omega

theorem range_head (n : Nat) (hn : 1≤n) : List.range n = 0::List.range' 1 (n-1) := by
  rw [List.range_eq_range',show n=(n-1)+1 by omega,List.range'_succ]
  simp

theorem range_two (n : Nat) (hn : 2≤n) : List.range n = 0::1::List.range' 2 (n-2) := by
  rw [range_head n (by omega),show n-1=(n-2)+1 by omega,List.range'_succ]

/-- Exact canonical-row equality; no assumed permutation of the database. -/
theorem pinALO0 (hk : 2≤F.k) :
    (clauseRow ((F.sel 0 0 0 : Int)::F.other0)).toE=(F.row1 0 0).toE := by
  congr 1
  simp only [clauseRow,row1,other0,Nat.add_zero,List.map_map,range_head F.k (by omega),List.map_cons,pos,Function.comp_def]

theorem pinALO1 (hk : 2≤F.k) :
    (clauseRow ((F.sel 0 1 1 : Int)::F.other1)).toE=(F.row1 0 1).toE := by
  apply toE_of_equiv
  · have := F.sel_pos 0 1 1
    intro l hl; rcases List.mem_cons.mp hl with rfl | hl
    · omega
    · exact F.others_nz.2 l hl
  · intro l hl
    simp only [row1,List.map_map] at hl
    obtain ⟨j,_,rfl⟩ := List.mem_map.mp hl
    change (F.sel 0 1 j : Int) ≠ 0
    have := F.sel_pos 0 1 j; omega
  · constructor
    · rfl
    · intro α
      simp only [clauseRow,row1,other1,Nat.add_zero,List.map_map,range_two F.k hk,List.map_cons,pos,Function.comp_def,lsum_cons]
      omega

theorem normalized_pins (hk : 2≤F.k) (hs : 1≤F.s) :
    All (fun r => r.toE∈F.db5) (pinRows (F.sel 0 0 0 : Int) F.other0) ∧
    All (fun r => r.toE∈F.db5) (pinRows (F.sel 0 1 1 : Int) F.other1) := by
  have lift2 : ∀R∈F.db2 F.k,R∈F.db5 := fun R h =>
    List.mem_append_left _ (List.mem_append_left _ (F.db2_sub_db3 R h))
  constructor
  · refine ⟨?_,All.of_mem _ ?_⟩
    · dsimp only; rw [F.pinALO0 hk]; exact F.original_mem_db5 _ (F.row1_mem 0 0 hs (by omega))
    · intro r hr
      obtain ⟨l,hl,rfl⟩ := List.mem_map.mp hr
      obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hl
      have hj' := List.mem_range'.mp hj
      exact lift2 _ (F.unit0_mem_db2 F.k j (by omega) (by omega))
  · refine ⟨?_,All.of_mem _ ?_⟩
    · dsimp only; rw [F.pinALO1 hk]; exact F.original_mem_db5 _ (F.row1_mem 0 1 hs (by omega))
    · intro r hr
      obtain ⟨l,hl,rfl⟩ := List.mem_map.mp hr
      rcases List.mem_cons.mp hl with rfl | hl
      · exact List.mem_append_left _ (List.mem_append_left _ F.unit10_mem_db3)
      · obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hl
        have hj' := List.mem_range'.mp hj
        exact lift2 _ (F.unit1_mem_db2 F.k j (by omega) (by omega))

#print axioms normalized_pins
end Fam
end L3

namespace L3.Fam
open L3 EREF EREF.GeneralRED
variable (F : Fam)

/-- Both first-gate leaves from the actual normalized database and recorded EQ
    commands. All original and normalization-row premises are discharged here. -/
theorem first_gate_from_database (hk : 2≤F.k) (hs : 1≤F.s)
    (t : StI F.V) (bit cb v : Nat) (hb : bit<2) (hc : 1≤cb) (hv : 1≤v)
    (hcb : Cmd.eqDef cb (F.fn 0 bit : Int) (F.fn 0 (bit+2) : Int)∈t.s.cmds)
    (hve : Cmd.eqDef v (F.val 0 (F.bitX bit) : Int) (F.val 0 (F.bitY bit) : Int)∈t.s.cmds)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hm : ∀R∈exec F.db5 t.s.cmds,R∈D) (pol : Bool) :
    Refutation (D ++ [negate (clauseRow (F.firstLeaf (F.bitX bit) cb v pol)).toE]) := by
  have hbase : ∀R∈F.db5,R∈D := fun R h => hm R (exec_mono _ _ R h)
  have horig : ∀r∈F.rows,r.toE∈D := fun r hr => hbase _ (F.original_mem_db5 r hr)
  have hp := F.normalized_pins hk hs
  have hp' : ∀rs : List L3.Row, All (fun r => r.toE∈F.db5) rs → All (fun r => r.toE∈D) rs := by
    intro rs hr
    exact All.of_mem rs (fun r h => hbase _ (All.mem hr r h))
  have hcx := eqDef_rows F.db5 t.s.cmds _ _ _ hcb
  have hvx := eqDef_rows F.db5 t.s.cmds _ _ _ hve
  have hxy := F.bitX_lt hk bit hb
  have hyy := F.bitY_lt hk bit hb
  apply F.first_gate_leaf (F.bitX bit) (F.bitY bit) cb v (decide (bit=1)) pol hc hv
    (F.inputBit_bitX_0 hk bit hb) (F.inputBit_bitY_0 hk bit hb)
    (F.inputBit_bitX_1 hk bit hb) (F.inputBit_bitY_1 hk bit hb)
    F.other0 F.other1 F.others_nz.1 F.others_nz.2 D hD (hp' _ hp.1) (hp' _ hp.2)
  refine ⟨horig _ (F.row3i_mem 0 0 0 _ hs (by omega) (by omega) hxy),
    horig _ (F.row3i_mem 0 0 0 _ hs (by omega) (by omega) hyy),
    horig _ (F.row3i_mem 0 1 1 _ hs (by omega) (by omega) hxy),
    horig _ (F.row3i_mem 0 1 1 _ hs (by omega) (by omega) hyy),?_,?_,?_,?_,trivial⟩
  · exact horig _ (F.row4P_mem pol 0 _ 0 _ hs hxy (by omega) (by cases (decide (bit=1)) <;> decide))
  · exact horig _ (F.row4P_mem (!pol) 0 _ 1 _ hs hyy (by omega) (by cases (decide (bit=1)) <;> decide))
  · have e : (decide (bit=1)).toNat=bit := by
      rcases (by omega : bit=0 ∨ bit=1) with rfl | rfl <;> rfl
    simp only [e]
    cases pol
    · exact hm _ hcx.2.1
    · exact hm _ hcx.2.2.1
  · cases pol
    · exact hm _ hvx.1
    · exact hm _ hvx.2.2.2

#print axioms first_gate_from_database
end L3.Fam

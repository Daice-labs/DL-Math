import GuardedReplay
namespace L3Emitter.GuardActivation
open EREF EREF.GeneralRED REDWitness

def unit (q:Nat):Row:=clause [(q:Int)]
def bank (inputs:List Row) (a:Row→Nat) (q:Nat):List Row:=
  inputs.map (fun R=>GuardedFrame.weaken R (a R) (-(q:Int)))

theorem unit_canonical (q:Nat):Canonical (unit q):=canonical_normalize _ _
theorem unit_value (q:Nat) (hq:0<q) (α:Val):
    (unit q).val α=litVal α (q:Int)-1:=by
  rw [unit,val_clause _ (by intro l hl; simpa using List.mem_singleton.mp hl ▸ (show (q:Int)≠0 by omega))]
  simp [sum]

theorem member_certificate (D:List Row) (C G:Row) (hg:G∈D) (hc:Canonical G):
    Refutation (D++[negate C,negate G]):=by
  obtain ⟨i,hi,he⟩:=List.mem_iff_getElem.mp hg
  have h:=old_certificate D C i hi (he ▸ hc)
  rw [he] at h
  exact single_to_refutation _ _ _ h

theorem subst_guard_on (R:Row) (hR:Canonical R) (a q:Nat) (hq:0<q)
    (ω:Witness) (hon:∀α,applyWitness ω α q=true):
    substRow (GuardedFrame.weaken R a (-(q:Int))) ω=substRow R ω:=by
  apply canonical_ext _ _ (canonical_substRow _ _) (canonical_substRow _ _)
  intro α
  rw [val_substRow,GuardedFrame.val_weaken R hR a _ (by omega),val_substRow]
  simp [litVal,show ¬(0:Int)< -(q:Int) by omega,hon,b2i]

/-- Activation discharges every retained row by an old-row certificate or a
tautology. Lower image membership is deliberately an explicit premise until
the actual complete lower-row bank has been constructed. -/
theorem activate (D inputs:List Row) (a:Row→Nat) (q:Nat) (hq:0<q)
    (ω:Witness) (hd:∀R∈D,Canonical R) (hi:∀R∈inputs,Canonical R)
    (hf:∀R∈D,substRow R ω=R) (hon:∀α,applyWitness ω α q=true)
    (himage:∀R∈inputs,substRow R ω∈D):
    CheckedStep (D++bank inputs a q) ((D++bank inputs a q)++[unit q]):=by
  apply CheckedStep.red _ _ ω (unit_canonical q)
  intro R hr
  rcases List.mem_cons.mp hr with rfl|hr
  · apply single_to_refutation
    apply taut_certificate _ _ _ (canonical_substRow _ _)
    intro α
    unfold Row.sat
    rw [val_substRow,unit_value q hq]
    simp [litVal,hq,hon,b2i]
  · rcases List.mem_append.mp hr with hr|hr
    · rw [hf R hr]
      exact member_certificate _ _ R (List.mem_append_left _ hr) (hd R hr)
    · obtain ⟨Q,hQ,rfl⟩:=List.mem_map.mp hr
      rw [subst_guard_on Q (hi Q hQ) (a Q) q hq ω hon]
      exact member_certificate _ _ _ (List.mem_append_left _ (himage Q hQ)) (canonical_substRow _ _)

theorem cancel_row (R:Row) (hR:Canonical R) (a q:Nat) (hq:0<q):
    add (GuardedFrame.weaken R a (-(q:Int))) (multiply (unit q) a)=R:=by
  apply canonical_ext _ _ (canonical_add _ _) hR
  intro α
  rw [val_add _ _ (GuardedFrame.canonical_weaken _ _ _) (canonical_multiply _ _),
    GuardedFrame.val_weaken R hR a _ (by omega),
    val_multiply _ (unit_canonical q) a α,unit_value q hq,
    litVal_neg α (q:Int) (by omega)]
  ring

def cancelTokens (guard activation a:Nat):List Tok:=
  [.ref guard,.ref activation,.mul a,.add]

theorem cancel_checks (db:Nat→Option Row) (guard activation a q:Nat) (R:Row)
    (hR:Canonical R) (ha:0<a) (hq:0<q)
    (hg:db guard=some (GuardedFrame.weaken R a (-(q:Int))))
    (hu:db activation=some (unit q)):
    polEval db (cancelTokens guard activation a) []=some R:=by
  simp only [cancelTokens,polEval,hg,hu,if_pos ha]
  rw [cancel_row R hR a q hq]

/-- Every guarded input is activated once, in its original order. -/
theorem cancel_bank (D inputs:List Row) (a:Row→Nat) (q:Nat)
    (hi:∀R∈inputs,Canonical R) (ha:∀R∈inputs,0<a R) (hq:0<q)
    (hg:∀R∈inputs,GuardedFrame.weaken R (a R) (-(q:Int))∈D)
    (hu:unit q∈D):
    GuardedReplay.Counted D (D++inputs) inputs.length:=by
  induction inputs generalizing D with
  | nil=>simpa using GuardedReplay.Counted.refl D
  | cons R rs ih=>
    let g:=ReferenceTransport.locate D (GuardedFrame.weaken R (a R) (-(q:Int)))
    have hg':=ReferenceTransport.locate_correct D _ (hg R (by simp))
    let u:=ReferenceTransport.locate D (unit q)
    have hu':=ReferenceTransport.locate_correct D _ hu
    have step:=CheckedStep.pol D R (cancelTokens g u (a R))
      (cancel_checks _ g u (a R) q R (hi R (by simp)) (ha R (by simp)) hq hg' hu')
    have tail:=ih (D++[R]) (fun R hr=>hi R (by simp [hr])) (fun R hr=>ha R (by simp [hr]))
      (fun R hr=>List.mem_append_left _ (hg R (by simp [hr]))) (List.mem_append_left _ hu)
    simpa only [List.length_cons,List.append_assoc,List.singleton_append] using
      GuardedReplay.Counted.cons step tail

#print axioms activate
#print axioms cancel_bank
end L3Emitter.GuardActivation

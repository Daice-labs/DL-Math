import L3CoverageChains
import L3FrontInv2

namespace L3
open EREF EREF.GeneralRED

theorem All.append {α : Type} {p : α → Prop} {xs ys : List α}
    (hx : All p xs) (hy : All p ys) : All p (xs ++ ys) := by
  induction xs with
  | nil => exact hy
  | cons x xs ih => exact ⟨hx.1, ih hx.2⟩

theorem All.replicate {α : Type} {p : α → Prop} (n : Nat) {x : α}
    (hx : p x) : All p (List.replicate n x) := by
  induction n with
  | zero => trivial
  | succ n ih => exact ⟨hx,ih⟩

theorem int_replicate_sum (n : Nat) (x : Int) : (List.replicate n x).sum = (n : Int)*x := by
  induction n with
  | zero => simp
  | succ n ih => simp [List.replicate_succ,ih,Int.add_mul,Int.add_comm]

theorem weighted_clause_chain (D : List EREF.Row) (c : List Int) (w : Nat) (rs : List Row)
    (hD : ∀ R ∈ D, Canonical R) (hc : ∀ l ∈ c, l ≠ 0)
    (hr : All (fun r => r.toE ∈ D) rs) (hn : All Row.nz rs)
    (hv : ∀ α, -(w+1 : Nat)*lsum α c +
      (rs.map fun r => lsum α r.lits - (r.rhs : Int)).sum < 0) :
    Refutation (D ++ [negate (clauseRow c).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow c).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have hr' : All (fun r => r.toE ∈ D ++ [negate (clauseRow c).toE]) rs := by
    clear hv hn
    induction rs with
    | nil => trivial
    | cons r rs ih => exact ⟨List.mem_append_left _ hr.1, ih hr.2⟩
  apply refutation_of_rowlist _ hDc (List.replicate (w+1) (negClause c) ++ rs)
  · simp
  · apply All.append _ hr'
    apply All.replicate
    change (negClause c).toE ∈ D ++ [negate (clauseRow c).toE]
    rw [negClause_toE c hc]; simp
  · exact All.append (All.replicate _ (negClause_nz c hc)) hn
  · intro α
    simp only [List.map_append,List.sum_append,List.map_replicate,int_replicate_sum]
    have he : lsum α (negClause c).lits - ((negClause c).rhs : Int) = -lsum α c := by
      simp only [negClause,lsum_map_neg α c hc]
      omega
    rw [he]
    simpa only [Int.mul_neg,Int.neg_mul] using hv α

/-- T5h: merge the two compared input-bit cases. -/
theorem coverage_merge (D : List EREF.Row) (a c0 c1 : Nat)
    (ha : 1 ≤ a) (h0 : 1 ≤ c0) (h1 : 1 ≤ c1)
    (hD : ∀ R ∈ D, Canonical R)
    (hA0 : (clauseRow [(a : Int),-(c0 : Int)]).toE ∈ D)
    (hA1 : (clauseRow [(a : Int),-(c1 : Int)]).toE ∈ D)
    (hC : (clauseRow [(c0 : Int),(c1 : Int)]).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [(a : Int)]).toE]) := by
  apply weighted_clause_chain D _ 1 [
    clauseRow [(a : Int),-(c0 : Int)],
    clauseRow [(a : Int),-(c1 : Int)],
    clauseRow [(c0 : Int),(c1 : Int)]] hD
  · nz_lits
  · exact ⟨hA0,hA1,hC,trivial⟩
  · refine ⟨?_,?_,?_,trivial⟩ <;> nz_lits
  · intro α
    simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      clauseRow,lsum_cons,lsum_nil]
    lv_omega

/-- T6b: both forcing rows excluded implies the forcing OR is excluded. -/
theorem output_force_excluded (D : List EREF.Row) (sel force eq0 eq1 : Nat)
    (hs : 1 ≤ sel) (hf : 1 ≤ force) (h0 : 1 ≤ eq0) (h1 : 1 ≤ eq1)
    (hD : ∀ R ∈ D, Canonical R)
    (hE0 : (clauseRow [-(sel : Int),-(eq0 : Int)]).toE ∈ D)
    (hE1 : (clauseRow [-(sel : Int),-(eq1 : Int)]).toE ∈ D)
    (hOR : (gateRow [(eq0 : Int),(eq1 : Int)] force false).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [-(sel : Int),-(force : Int)]).toE]) := by
  apply weighted_clause_chain D _ 1 [
    clauseRow [-(sel : Int),-(eq0 : Int)],
    clauseRow [-(sel : Int),-(eq1 : Int)],
    gateRow [(eq0 : Int),(eq1 : Int)] force false] hD
  · nz_lits
  · exact ⟨hE0,hE1,hOR,trivial⟩
  · refine ⟨?_,?_,?_,trivial⟩ <;> nz_lits
  · intro α
    simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      clauseRow,gateRow,lsum_cons,lsum_nil,lsum_append,pos,neg,Bool.false_eq_true,ite_false]
    lv_omega

/-- T6c: an output port cannot be a forcing consumer. -/
theorem output_p0_excluded (D : List EREF.Row) (sel force pf : Nat)
    (hs : 1 ≤ sel) (hf : 1 ≤ force) (hp : 1 ≤ pf)
    (hD : ∀ R ∈ D, Canonical R)
    (hS : (gateRow [(sel : Int)] pf false).toE ∈ D)
    (hF : (gateRow [(force : Int)] pf false).toE ∈ D)
    (hX : (clauseRow [-(sel : Int),-(force : Int)]).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [-(pf : Int)]).toE]) := by
  apply weighted_clause_chain D _ 1 [
    gateRow [(sel : Int)] pf false,gateRow [(force : Int)] pf false,
    clauseRow [-(sel : Int),-(force : Int)]] hD
  · nz_lits
  · exact ⟨hS,hF,hX,trivial⟩
  · refine ⟨?_,?_,?_,trivial⟩ <;> nz_lits
  · intro α
    simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      clauseRow,gateRow,lsum_cons,lsum_nil,lsum_append,pos,neg,Bool.false_eq_true,ite_false]
    lv_omega

/-- T6d: neither output port can force, so the output is not eligible. -/
theorem output_eligible_excluded (D : List EREF.Row) (eligible cons p0 p1 : Nat)
    (he : 1 ≤ eligible) (hc : 1 ≤ cons) (h0 : 1 ≤ p0) (h1 : 1 ≤ p1)
    (hD : ∀ R ∈ D, Canonical R)
    (hE : (gateRow [(cons : Int)] eligible false).toE ∈ D)
    (hC : (gateRow [(p0 : Int),(p1 : Int)] cons false).toE ∈ D)
    (hP0 : (clauseRow [-(p0 : Int)]).toE ∈ D)
    (hP1 : (clauseRow [-(p1 : Int)]).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow [-(eligible : Int)]).toE]) := by
  apply clause_chain D _ [
    gateRow [(cons : Int)] eligible false,
    gateRow [(p0 : Int),(p1 : Int)] cons false,
    clauseRow [-(p0 : Int)],clauseRow [-(p1 : Int)]] hD
  · nz_lits
  · exact ⟨hE,hC,hP0,hP1,trivial⟩
  · refine ⟨?_,?_,?_,?_,trivial⟩ <;> nz_lits
  · intro α
    simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      clauseRow,gateRow,lsum_cons,lsum_nil,lsum_append,pos,neg,Bool.false_eq_true,ite_false]
    lv_omega

#print axioms coverage_merge
#print axioms output_force_excluded
#print axioms output_p0_excluded
#print axioms output_eligible_excluded
end L3

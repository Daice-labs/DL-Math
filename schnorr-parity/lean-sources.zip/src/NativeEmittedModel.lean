import NativeRetainedFamily
import PinnedFamilyPendingInterned
import PinnedNativeProfile
import NativeParserDepthFamily
import NativeCompatibleBaseRanges
import NativeCompatibleBytes
namespace L3Emitter.NativeEmittedModel
open EREF CanonicalFileGrammar PinnedRetainedStore

/-- Source-derived emitted-subset acceptance combines the width-aware parser,
shared online variable allocation, retained arithmetic, mode/scope state, and
candidate-once/pending-map execution. The two executions are related by their
proved row-store projection; neither is a test of the compiled Rust binary.
Rust source translation, compiler and operating system remain trusted. -/
def check (choose:PinnedFamilyPending.Selection) (formula proof:Bytes):Bool:=
 match NativeParserBundle.parse formula proof with
 | none=>false
 | some f=>
   if hc:∀R∈f.original,Canonical R then
    match PinnedNativeProfile.run (PinnedNativeProfile.profile false [])
       (f.commands.flatMap commandEvents) with
    | none=>false
    | some context=>
      if !context.stack.isEmpty then false else
      match PinnedRetainedScope.run (NativeRetainedFamily.initial f.original hc) f.commands with
      | none=>false
      | some q=>
        match PinnedFamilyPending.run choose (NativeSparseStore.initial f.original) f.commands with
        | none=>false
        | some p=>
          match read q (f.conclusion:Int),NativeSparseStore.read p (f.conclusion:Int) with
          | some R,some S=>decide ((PinnedRetainedPacked.row R).total<(PinnedRetainedPacked.row R).bound ∧ S.total<S.bound)
          | _,_=>false
   else false

/-- Counts have different units: allocated row slots, distinct encountered
variable names, and maximum transient POL parser slots, respectively. Scalars
are deliberately not restricted to signed64: the runtime proves promotion. -/
def MachineRange (n:Nat):Prop:=
 (NativeCompatibleFamily.compiled n).store.next<2^63 ∧
 (NativeParserBundle.names n).length<2^63 ∧
 NativeParserTapeBounds.bound n+1<2^64

theorem accepted (choose:PinnedFamilyPending.Selection) (n:Nat) (hn:2≤n) (hm:MachineRange n):
 check choose (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n)))
   (NativeCompatibleFamily.bytes n)=true:=by
 have hp:=NativeParserBundle.family n hn (Nat.le_of_lt hm.1)
 obtain ⟨b,hprofile⟩:=PinnedNativeProfile.all_commands false (NativeParserBundle.parsed n).commands
 obtain ⟨q,hq,hproj,hqn,R,hR,hrow⟩:=NativeRetainedFamily.execution n hn hm.2.1
 obtain ⟨hpend,hread⟩:=PinnedFamilyPendingInterned.family choose (NativeParserBundle.names n) n hn
 change PinnedFamilyPending.run choose (NativeSparseStore.initial (NativeParserBundle.parsed n).original)
   (NativeParserBundle.parsed n).commands=some _ at hpend
 change NativeSparseStore.read _ ((NativeParserBundle.parsed n).conclusion:Int)=some _ at hread
 rw [check,hp]
 simp only [dif_pos (NativeRetainedFamily.original_canonical n),hprofile]
 change (if !([]:List PinnedNativeProfile.Frame).isEmpty then false else _)=true
 simp only [List.isEmpty_nil,Bool.not_true,Bool.false_eq_true,↓reduceIte]
 change (match PinnedRetainedScope.run (NativeRetainedFamily.start n) (NativeParserBundle.parsed n).commands with
   | none=>false
   | some q=>_) = true
 simp only [hq,hpend,hR,hread,hrow]
 decide

theorem base_range:MachineRange 2:=
 ⟨NativeCompatibleBaseRanges.counter,NativeCompatibleBaseRanges.names,NativeParserDepthFamily.base_in_range⟩

/-- End-to-end theorem for the formal native-source model, with explicit,
nonvacuous machine conditions. The unconditional all-n formal theorem and
serialized ASCII-byte polynomial bound remain separate conjuncts. No model
correspondence or successful-run hypothesis is supplied by the caller. -/
theorem emitter (choose:PinnedFamilyPending.Selection) (n:Nat) (hn:2≤n):
 CanonicalByteAcceptance.check
   (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n)))
   (NativeCompatibleFamily.bytes n)=true ∧
 (NativeCompatibleFamily.bytes n).length≤NumericFamilyClosed.bytes n ∧
 (NativeCompatibleFamily.bytes n).length≤CanonicalPolynomialBytes.polynomial (ConstructionFormulaScale.rows n) ∧
 (MachineRange n→check choose
   (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n)))
   (NativeCompatibleFamily.bytes n)=true):=
 ⟨NativeCompatibleFamily.accepted n hn,NativeCompatibleFamily.serialized_bytes n hn,
 NativeCompatibleFamily.polynomial_bytes n hn,accepted choose n hn⟩

theorem base_accepted (choose:PinnedFamilyPending.Selection):
 check choose (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original 2)))
   (NativeCompatibleFamily.bytes 2)=true:=accepted choose 2 (by omega) base_range

#print axioms emitter
#print axioms base_accepted
end L3Emitter.NativeEmittedModel

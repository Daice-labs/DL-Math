import ConstructionOneHotCount

namespace L3Emitter.ConstructionSourceCount
open EREF EREF.GeneralRED REDWitness AliasNetwork RecordedPortLinks
open SelectedVectorOneHot

def width (n : Nat) := AliasAssembly.width (n+1)

theorem width_eq (n : Nat) (hn : 2≤n) : width n=4*n-4 := by
  unfold width AliasAssembly.width RankConstruction.width
  omega

theorem indexed_loop {w : Nat} {C : Type} (D : List Row) (cs : List C)
    (v : C→Bit) (a : C→AliasBits w) (q : AliasBits w) (ls : List (List (Lit w))) :
    (IndexedSourceOneHot.loop D cs v a q ls).length=ls.length*(cs.length+1) := by
  induction ls generalizing D with
  | nil => simp [IndexedSourceOneHot.loop]
  | cons l ls ih =>
    simp only [IndexedSourceOneHot.loop,IndexedSourceOneHot.block,List.length_append,
      IndexedSourceOneHot.casesProgram,List.length_map,List.length_cons,List.length_nil,ih]
    ring

theorem indexed {w : Nat} {C : Type} (D : List Row) (cs : List C)
    (v : C→Bit) (a : C→AliasBits w) (q : AliasBits w) :
    (IndexedSourceOneHot.program D cs v a q).length≤(1+w^2)*(cs.length+1) := by
  unfold IndexedSourceOneHot.program
  rw [indexed_loop]
  exact Nat.mul_le_mul_right _ (ConstructionOneHotCount.specifications w)

theorem primary_loop (n : Nat) (hn : 2≤n) (D : List Row) (js : List Nat) :
    (PrimaryAliasBank.program n hn D js).length≤js.length*(1+(width n)^2) := by
  induction js generalizing D with
  | nil => simp [PrimaryAliasBank.program]
  | cons j js ih =>
    have h:(PrimaryAliasRows.program D (PrimaryAliasBank.cfg n hn) j (width n)).length≤1+(width n)^2 := by
      simp only [PrimaryAliasRows.program,List.length_map]
      exact ConstructionOneHotCount.specifications _
    simp only [PrimaryAliasBank.program,List.length_append,List.length_cons]
    exact (Nat.add_le_add h (ih _)).trans_eq (by ring)

theorem primary (n : Nat) (hn : 2≤n) :
    (PrimaryAliasBank.emitted n hn).length≤(n+1)*(1+(width n)^2) := by
  simpa only [List.length_range] using primary_loop n hn (RankColumnOneHot.result n hn) (List.range (n+1))

theorem first_port (n : Nat) (hn : 2≤n) (p : Nat) (D : List Row) :
    (FirstPortOneHot.block n hn p D).length≤(1+(width n)^2)*(n+2)+width n := by
  have h:=ConstructionOneHotCount.selected D (FirstPortOneHot.cs n hn p)
    (FirstPortOneHot.inputs n hn p) (FirstPortOneHot.target n hn p)
  simpa only [FirstPortOneHot.cs,SelectedVectorClauses.choices,List.length_map,List.length_range,Nat.add_zero,Nat.add_assoc] using h

theorem first_ports (n : Nat) (hn : 2≤n) :
    (FirstPortOneHot.emitted n hn).length≤2*((1+(width n)^2)*(n+2)+width n) := by
  simp only [FirstPortOneHot.emitted,List.length_append]
  exact (Nat.add_le_add (first_port n hn 0 _) (first_port n hn 1 _)).trans_eq (by ring)

theorem port (n : Nat) (hn : 2≤n) (g p : Nat) (D : List Row) :
    (GatePortOneHot.program n hn g p D).length≤(1+(width n)^2)*(n+g+2)+width n := by
  have h:=ConstructionOneHotCount.selected D (GatePortOneHot.cs n hn g p)
    (GatePortOneHot.inputs n hn g p) (GatePortOneHot.target n hn g p)
  simpa only [GatePortOneHot.program,GatePortOneHot.cs,SelectedVectorClauses.choices,List.length_map,List.length_range,width,Nat.add_assoc,Nat.add_comm 1 g,show 1+1=2 from rfl] using h

theorem mux (n : Nat) (hn : 2≤n) (g : Nat) (D : List Row) :
    (MuxSourceStep.program n hn g D).length≤1+3*(1+(width n)^2) := by
  have h:=indexed (MuxSourceStep.seeded n hn g D) [true,false]
    (MuxSourceStep.choices n hn g) (MuxSourceStep.inputs n hn g) (MuxSourceStep.vector n hn g)
  simp only [List.length_cons,List.length_nil] at h
  simp only [MuxSourceStep.program,List.length_append,MuxSourceStep.seed,List.length_cons,List.length_nil]
  exact (Nat.add_le_add_left h 1).trans_eq (by unfold width;ring)

theorem categories (n : Nat) (hn : 2≤n) (g : Nat) (D : List Row) :
    (GateSourceOneHot.program n hn g D).length≤(1+(width n)^2)*(3*n+3) := by
  have h:=indexed D (CategoryPrograms.cats n) (GateCategories.bit n hn g)
    (GateSourceOneHot.inputs n hn g) (GateSourceOneHot.target n hn g)
  apply h.trans
  apply Nat.mul_le_mul_left
  simp only [CategoryPrograms.cats,GateCategories.categories,List.length_cons,List.length_map,List.length_range]
  omega

/-- All source-coordinate preservation work for one later gate. -/
theorem gate (n : Nat) (hn : 2≤n) (g : Nat) (hg : g<3*(n+1)-4) (D : List Row) :
    (GateOrderSources.stepProgram n hn g D).length≤
      (1+(width n)^2)*(11*n+12)+2*width n+1 := by
  have h0:=port n hn g 0 D
  have h1:=port n hn g 1 (GateOrderSources.afterLeft n hn g D)
  have h2:=mux n hn g (GateOrderSources.afterRight n hn g D)
  have h3:=categories n hn g (GateOrderSources.afterMux n hn g D)
  have hm : n+g+2≤4*n+3 := by omega
  have hp:=Nat.mul_le_mul_left (1+(width n)^2) hm
  simp only [GateOrderSources.stepProgram,List.length_append]
  nlinarith

theorem loop (n : Nat) (hn : 2≤n) (m g : Nat) (hg : g+m≤3*(n+1)-4) (D : List Row) :
    (GateOrderSources.program n hn g D m).length≤
      m*((1+(width n)^2)*(11*n+12)+2*width n+1) := by
  induction m generalizing g D with
  | zero => simp [GateOrderSources.program]
  | succ m ih =>
    simp only [GateOrderSources.program,List.length_append]
    exact (Nat.add_le_add (gate n hn g (by omega) D) (ih (g+1) (by omega) _)).trans_eq (by ring)

theorem bank (n : Nat) (hn : 2≤n) :
    (GateOrderSources.fullProgram n hn).length≤
      (3*(n+1)-5)*((1+(4*n-4)^2)*(11*n+12)+2*(4*n-4)+1) := by
  have h:=loop n hn (3*(n+1)-5) 1 (by omega) (SourceAuxBank.result n hn)
  simpa only [width_eq n hn] using h

#print axioms primary
#print axioms first_ports
#print axioms bank
end L3Emitter.ConstructionSourceCount

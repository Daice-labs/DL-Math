import LowerPortEvaluation
namespace L3Emitter.LowerPortEvalBank
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL AliasProgram
abbrev Job (n:Nat):=RawLowerInputBank.Record n×Nat×Nat×Bool×Bool
def jobs (n:Nat) (hn:2≤n):List (Job n):=
  (RawLowerInputBank.result n hn).2.flatMap fun r=>(RankZeroTransport.gates n).flatMap fun G=>
  (List.range (FamilyNamespace.truthRows n)).flatMap fun x=>[false,true].flatMap fun b=>[false,true].map fun v=>(r,G,x,b,v)
def ValidJob (n:Nat) (hn:2≤n) (j:Job n):Prop:=
  j.1∈(RawLowerInputBank.result n hn).2 ∧ j.2.1∈RankZeroTransport.gates n ∧ j.2.2.1<FamilyNamespace.truthRows n

theorem job_mem (n:Nat) (hn:2≤n) (j:Job n):j∈jobs n hn↔ValidJob n hn j:=by
  obtain ⟨⟨⟨⟨t,p,a⟩,hp⟩,lp⟩,G,x,b,v⟩:=j;cases b <;> cases v <;> simp [jobs,ValidJob]

def row (n:Nat) (hn:2≤n) (j:Job n):=
  LowerPortEvaluation.row n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2
def program (n:Nat) (hn:2≤n):Program:=
  (jobs n hn).map fun j=>(row n hn j,LowerPortEvaluation.tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2 (LowerU2Bank.result n hn))
def result (n:Nat) (hn:2≤n):=LowerU2Bank.result n hn++(jobs n hn).map (row n hn)

theorem record_valid (n:Nat) (hn:2≤n) (r:RawLowerInputBank.Record n) (hr:r∈(RawLowerInputBank.result n hn).2):
    r.1.1.1<RankConstruction.width (n+1) ∧ r.1.1.2.1<2:=
  RankPortValue.record_valid n hn r.1.1 (RawLowerInputBank.port_present n hn r.1 (RawUnaryBank.port_present n hn r hr))

theorem checks (n:Nat) (hn:2≤n):check (LowerU2Bank.result n hn) (program n hn)=some (result n hn):=by
  have h:=IndependentProgram.check_base (LowerU2Bank.result n hn) (program n hn) (by
    intro c hc;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    have hv:=(job_mem n hn j).mp hj
    exact LowerPortEvaluation.checks n hn j.1 hv.1 j.2.1 hv.2.1 (record_valid n hn j.1 hv.1).1
      j.2.2.1 hv.2.2 j.2.2.2.1 j.2.2.2.2 _ (fun _ h=>h))
  simpa only [program,result,outputs,List.map_map,Function.comp_def] using h

theorem original_to_port_evaluations (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (LowerU2Bank.original_to_lower_U2 n hn) (check_trace _ _ _ (checks n hn))

theorem all_rows (n:Nat) (hn:2≤n) (r:RawLowerInputBank.Record n) (hr:r∈(RawLowerInputBank.result n hn).2)
    (G:Nat) (hG:G∈RankZeroTransport.gates n) (x:Nat) (hx:x<FamilyNamespace.truthRows n) (b v:Bool):
    LowerPortEvaluation.row n hn r G x b v∈result n hn:=
  List.mem_append_right _ (List.mem_map.mpr ⟨(r,G,x,b,v),(job_mem n hn _).mpr ⟨hr,hG,hx⟩,rfl⟩)

theorem actual_port_rows (n:Nat) (hn:2≤n) (t p G x:Nat) (ht:t<RankConstruction.width (n+1)) (hp:p<2)
    (hG:G∈RankZeroTransport.gates n) (hx:x<FamilyNamespace.truthRows n) (b v:Bool):
    clause [-(TopologyContext.guard n hn G t).val,-sign b (LowerTransferImage.wire n hn (.port t p x)),
      -sign v (ComposedTableBank.unary n hn G p b),sign v (EarlierPortValues.portValue n hn G p x)]∈result n hn:=by
  obtain ⟨r,he,heq⟩:=LowerTransferImage.port_exists n hn t p ht hp
  have ht':r.val.1.1.1=t:=congrArg Prod.fst heq
  have hp':r.val.1.1.2.1=p:=congrArg Prod.snd heq
  have h:=all_rows n hn r.val r.property G hG x hx b v
  simpa only [LowerPortEvaluation.row,LowerPortEvaluation.low,LowerPortEvaluation.upperUnary,
    LowerPortEvaluation.upperValue,ht',hp',LowerTransferImage.wire,he,ComposedTableBank.unary] using h
#print axioms original_to_port_evaluations
#print axioms actual_port_rows
end L3Emitter.LowerPortEvalBank

import ActivatedReplayOperandBounds
namespace L3Emitter.ActualTailOperandBounds
open EREF EREF.GeneralRED RecordedScopedTrace RecordedOperandFields FieldLengthsFromIDs
open ActualLowerComposition RecursiveOperandBounds

theorem guard_keys (M:Nat) (p:Program) (h:∀c∈p,Content M c):RecordedGuard.ceiling p≤M:=by
  unfold RecordedGuard.ceiling
  have hmax : ∀xs:List Nat,(∀x∈xs,x≤M)→xs.foldr max 0≤M:=by
    intro xs hx
    induction xs with
    | nil=>exact Nat.zero_le _
    | cons x xs ih=>exact max_le (hx x (by simp)) (ih (fun y hy=>hx y (by simp [hy])))
  apply hmax
  intro a ha
  obtain ⟨c,hc,ha⟩:=List.mem_flatMap.mp ha
  have hh:=h c hc
  cases c with
  | pol R ts=>simp [RecordedGuard.keys] at ha
  | consequence R q=>simp [RecordedGuard.keys] at ha
  | red R w ps=>
    obtain ⟨e,he,rfl⟩:=List.mem_map.mp ha
    exact (hh.2.1 e he).1

def tailBound (n M A:Nat) (hn:2≤n):Nat:=
  ceiling n hn+M+FamilyNamespace.variableCount n (3*n-4)+A+1

/-- Actual shifted and activated shared tail, including every retained-frame
local certificate. The operand envelope is additive in the previous level M.
A bounds only the lower input weakening amounts; no accumulated tail count
appears as a multiplier. -/
theorem tail (n M A:Nat) (hn:2≤n) (p:Program) (h:∀c∈p,Content M c)
    (ha:∀R∈inputs n hn,amount R≤A):
    ∀c∈ActualRecordedTail.emit n hn (RecordedRecursiveStep.reserve n p)
      (RecordedRecursiveStep.shifted n hn p),Content (tailBound n M A hn) c:=by
  have hg:=guard_keys M p h
  have hr:RecordedRecursiveStep.reserve n p≤FamilyNamespace.variableCount n (3*n-4)+M:=by
    unfold RecordedRecursiveStep.reserve;omega
  apply ActivatedReplayOperandBounds.program
  · intro R hR
    exact (ha R hR).trans (by unfold tailBound;omega)
  · simp only [Int.natAbs_neg,Int.natAbs_natCast]
    unfold tailBound
    omega
  · intro c hc
    have hh:=program_offset (ceiling n hn) M p h c hc
    exact content_mono (by unfold tailBound;omega) c hh

/-- Separates the one new prefix's field obligation from the now-proved
shared-tail operand propagation. This is not yet a prefix bound. -/
theorem successor (n M A K:Nat) (hn:2≤n) (p:Program) (h:∀c∈p,Content M c)
    (ha:∀R∈inputs n hn,amount R≤A)
    (hp:∀c∈RecordedActualActivation.fullProgram n hn (RecordedRecursiveStep.reserve n p),Content K c):
    ∀c∈RecordedRecursiveStep.program n hn p,Content (max K (tailBound n M A hn)) c:=by
  intro c hc
  rcases List.mem_append.mp hc with hc|hc
  · exact content_mono (Nat.le_max_left _ _) c (hp c hc)
  · exact content_mono (Nat.le_max_right _ _) c (tail n M A hn p h ha c hc)

#print axioms tail
#print axioms successor
end L3Emitter.ActualTailOperandBounds

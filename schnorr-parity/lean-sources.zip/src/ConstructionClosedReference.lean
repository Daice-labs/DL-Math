import ConstructionClosedAllocation
import CanonicalMachineReference
namespace L3Emitter.ConstructionClosedReference
open EREF NativeSparseStore ConstructionClosedAllocation

def nextBound (n : Nat) :=formulaBound n+1+allocationBound n

/-- All physical row allocations, including deleted local rows, are bounded.
Variable IDs and every intermediate emitted reference still need separate
operand proofs; this theorem concerns the final store's allocation counter. -/
theorem next_bound (n : Nat) (hn : 2≤n) :
    (NativeRecordedFamily.compiled n).store.next≤nextBound n := by
  have h:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n)
    _ _ (initial (NativeRecordedFamily.original n)) id _
    (RecordedUniformFamily.recorded_refutation n hn).1
  change (NativeRecordedFamily.compiled n).store.next=_ at h
  simp only [initial,NativeRecordedFamily.original] at h
  have hf:=CanonicalFormulaEnvelope.original_rows n
  have ha:=allocations n hn
  unfold nextBound formulaBound
  rw [h]
  omega

/-- The conclusion row's signed-64 representation, under a closed condition
in n. This is not a theorem about native parser/executable acceptance. -/
theorem conclusion_cast (n : Nat) (hn : 2≤n)
    (hlimit : nextBound n≤CanonicalMachineReference.referenceLimit) :
    read (NativeRecordedFamily.compiled n).store
      (Int64.ofNat (NativeRecordedFamily.conclusion n)).toInt=some (REDWitness.clause []) := by
  have href:=(NativeRecordedFamily.physical_refutation n hn).2
  have hi:=CanonicalMachineReference.read_id_below_next _ _ _ href
  have hb:=next_bound n hn
  rw [CanonicalMachineReference.positive_cast _ (by omega)]
  exact href
#print axioms next_bound
#print axioms conclusion_cast
end L3Emitter.ConstructionClosedReference

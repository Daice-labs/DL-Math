import ConstructionTableCount
namespace L3Emitter.ConstructionFinalDefinitionCount
open EREF EREF.GeneralRED AliasNetwork FinalOutputDefinitions
open ConstructionAliasCount
variable {base : List Row}
set_option maxRecDepth 2000
set_option maxHeartbeats 50000
attribute [local irreducible] FinalOutputDefinitions.base PrimaryAliasBank.cfg LowerTransferImage.wire SourceCoordinateValue.value

theorem out_cost (n : Nat) (hn : 2≤n) (x : Fin (T n)) :
    ConstructionAliasCount.Cost (out (base:=base) n hn x) (4*(W n-1)+1) := by
  unfold out
  simpa only [List.length_map,List.length_finRange] using ConstructionAliasCount.select_cost (base:=base)
    ((List.finRange (W n-1)).map fun i=>(source n hn (coord n i),SourceCoordinateValue.value n hn (coord n i) x.val))

#print axioms out_cost
theorem selector_cost (n : Nat) (hn : 2≤n) (p : Fin 2) (i : Fin (W n-1)) :
    ConstructionAliasCount.Cost (selector (base:=base) n hn p i) 9 := by
  unfold selector;exact ConstructionAliasCount.mux_cost _ _ _

#print axioms selector_cost
theorem port_cost (n : Nat) (hn : 2≤n) (xs : Fin (T n)→Bit) (p : Fin 2) (x : Fin (T n)) :
    ConstructionAliasCount.Cost (FinalOutputDefinitions.port (base:=base) n hn xs p x) 9 := by
  unfold FinalOutputDefinitions.port;exact ConstructionAliasCount.mux_cost _ _ _

#print axioms port_cost
theorem function_cost (n : Nat) (hn : 2≤n) (ab : Fin 4) :
    ConstructionAliasCount.Cost (function (base:=base) n hn ab) 27 := by
  unfold function
  exact ConstructionAliasCount.bind_cost _ _ 9 18 (ConstructionAliasCount.mux_cost _ _ _)
    (fun _=>ConstructionAliasCount.bind_cost _ _ 9 9 (ConstructionAliasCount.mux_cost _ _ _)
      (fun _=>ConstructionAliasCount.mux_cost _ _ _))

#print axioms function_cost
attribute [local irreducible] out selector FinalOutputDefinitions.port function

theorem construction (n : Nat) (hn : 2≤n) : ConstructionAliasCount.Cost
    (FinalOutputDefinitions.construction (base:=base) n hn)
    (T n*(4*(W n-1)+1)+18*(W n-1)+18*T n+108) := by
  have h0:=ConstructionAliasCount.tabulate_cost (T n) (out (base:=base) n hn) _ (out_cost n hn)
  have h1:=ConstructionAliasCount.tabulate_cost 2 (fun p=>tabulate (W n-1) (selector (base:=base) n hn p)) (9*(W n-1))
    (fun p=>by simpa only [Nat.mul_comm] using ConstructionAliasCount.tabulate_cost (W n-1) (selector (base:=base) n hn p) 9 (selector_cost n hn p))
  have h2 (xs:Fin (T n)→Bit):ConstructionAliasCount.Cost (tabulate 2 (fun p=>tabulate (T n) (FinalOutputDefinitions.port (base:=base) n hn xs p))) (2*(T n*9)):=
    ConstructionAliasCount.tabulate_cost _ _ _ (fun p=>ConstructionAliasCount.tabulate_cost _ _ _ (port_cost n hn xs p))
  have h3:=ConstructionAliasCount.tabulate_cost 4 (function (base:=base) n hn) 27 (function_cost n hn)
  have h:=ConstructionAliasCount.bind_cost _ _ _ _ h0 (fun xs=>ConstructionAliasCount.bind_cost _ _ _ _ h1
    (fun ss=>ConstructionAliasCount.bind_cost _ _ _ _ (h2 xs)
      (fun ps=>ConstructionAliasCount.bind_cost _ _ _ _ h3 (fun fs=>ConstructionAliasCount.pure_cost (⟨xs,ss,ps,fs⟩:Data n)))))
  unfold FinalOutputDefinitions.construction
  exact ConstructionAliasCount.cost_mono _ _ _ h (by omega)

#print axioms construction
attribute [local irreducible] FinalOutputDefinitions.construction

theorem complete (n : Nat) (hn : 2≤n) : (RecordedOutputDefinitions.program n hn).length≤220*(n+1)*2^n := by
  rw [RecordedOutputDefinitions.program,ConstructionAliasBankCount.network_rows]
  unfold FinalOutputDefinitions.built
  have h:=construction n hn (initialNet n hn)
  change mass (FinalOutputDefinitions.construction n hn (initialNet n hn)).2.gates≤
    0+(T n*(4*(W n-1)+1)+18*(W n-1)+18*T n+108) at h
  apply h.trans
  clear h
  have hw:W n-1≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);unfold W;omega
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  change 0+(2^n*(4*(W n-1)+1)+18*(W n-1)+18*2^n+108)≤_
  have hm:=Nat.mul_le_mul_left (2^n) (show 4*(W n-1)+1≤16*(n+1)+1 by omega)
  have hc:=Nat.mul_le_mul_left (72*(n+1)+108) ht
  nlinarith
#print axioms complete
end L3Emitter.ConstructionFinalDefinitionCount

import RankZeroTransport
namespace L3Emitter.LowerTopologyBank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot
abbrev Job (n:Nat):=RankPortBank.Record n×Fin (RankConstruction.width (n+1))
def ValidJob (n:Nat) (hn:2≤n) (j:Job n):Prop:=j.1∈(RankPortBank.result n hn).2 ∧ j.1.1≤j.2.val
def jobs (n:Nat) (hn:2≤n):List (Job n):=(RankPortBank.result n hn).2.flatMap fun r=>
  (List.finRange (RankConstruction.width (n+1))).filterMap fun u=>if r.1≤u.val then some (r,u) else none

theorem job_mem (n:Nat) (hn:2≤n) (j:Job n):j∈jobs n hn↔ValidJob n hn j:=by
  obtain ⟨r,u⟩:=j
  simp only [jobs,List.mem_flatMap,List.mem_filterMap,List.mem_finRange,true_and,ValidJob]
  constructor
  · rintro ⟨r',hr,u',he⟩
    split at he
    · have he:=Option.some.inj he
      obtain ⟨rfl,rfl⟩:=Prod.mk.inj he
      exact ⟨hr,by assumption⟩
    · contradiction
  · rintro ⟨hr,hu⟩;exact ⟨r,hr,u,by simp [hu]⟩
def rows (n:Nat) (hn:2≤n) (j:Job n):=RankZeroTransport.rows n hn j.1 j.2
def leaf (n:Nat) (hn:2≤n) (j:Job n) (D:List Row):=RankZeroTransport.program n hn j.1 j.2 D

def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n hn) (TopologyBank.result n hn)
def result (n:Nat) (hn:2≤n):=TopologyBank.result n hn++RetainedBlockFold.body (rows n hn) (jobs n hn)
theorem checks (n:Nat) (hn:2≤n):check (TopologyBank.result n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (ValidJob n hn)
    (fun j hj D hd=>RankZeroTransport.checks n hn j.1 hj.1 j.2 hj.2 D hd) _
    (fun j hj=>(job_mem n hn j).mp hj) _ (fun _ h=>h)
theorem original_to_lower_topology (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (TopologyBank.original_to_topology n hn) (check_trace _ _ _ (checks n hn))
theorem all_units (n:Nat) (hn:2≤n) (r:RankPortBank.Record n) (hr:r∈(RankPortBank.result n hn).2)
    (u:Fin (RankConstruction.width (n+1))) (hu:r.1≤u.val):
    clause [-(r.2.2 (position (TopologyContext.coord n u))).val]∈result n hn:=by
  apply List.mem_append_right
  apply RetainedBlockFold.contains (rows n hn) (jobs n hn) (r,u) ((job_mem n hn _).mpr ⟨hr,hu⟩)
  exact List.mem_append_right _ (List.mem_singleton_self _)
#print axioms original_to_lower_topology
#print axioms all_units
end L3Emitter.LowerTopologyBank

import CanonicalRowParser

namespace L3Emitter.CanonicalWitnessParser
open CanonicalRowParser

def parseImage (bs : Bytes) : Option Image :=
  if bs=decimal 0 then some (.bit false)
  else if bs=decimal 1 then some (.bit true)
  else (LiteralParser.parse bs).map Image.lit

theorem literal_not_decimal (l : Literal) (n : Nat) : emit (literal l)≠decimal n := by
  intro he
  have hn:DecimalParser.parse (emit (literal l))=none:=by
    rw [LiteralParser.encoded]
    cases l.negative <;> rfl
  rw [he,DecimalParser.roundtrip] at hn
  contradiction

theorem image_roundtrip (v : Image) (hv : FiniteWitness.validImage v=true) :
    parseImage (emit (image v))=some v := by
  cases v with
  | bit b=>cases b <;> rfl
  | lit l=>
    have hp:0<l.varId:=of_decide_eq_true hv
    simp only [image,parseImage,if_neg (literal_not_decimal l 0),
      if_neg (literal_not_decimal l 1),LiteralParser.roundtrip l hp]
    rfl

theorem image_lex (v : Image) : lex (emit (image v))=[emit (image v)] := by
  cases v with
  | bit b=>simpa [image,emit,number,Piece.emit] using lex_decimal (if b then 1 else 0)
  | lit l=>exact lex_literal l

def entryWords (e : Nat×Image) : List Bytes :=
  [emit (literal ⟨e.1,false⟩),[45,62],emit (image e.2)]

theorem entry_lex (e : Nat×Image) :
    lex (emit (literal ⟨e.1,false⟩++fixed " -> "++image e.2))=entryWords e := by
  have he:emit (literal ⟨e.1,false⟩++fixed " -> "++image e.2)=
      emit (literal ⟨e.1,false⟩)++32::([45,62]++32::emit (image e.2)):=by
    simp [emit,Piece.emit,fixed,ascii,List.append_assoc]
    rfl
  rw [he,lex_space,lex_space,lex_literal,image_lex]
  rfl

theorem witness_lex (w : FiniteWitness.Data) :
    lex (emit (witness w))=w.flatMap entryWords := by
  simp only [witness,separated_lex,List.flatMap_map,entry_lex]

def parseWords : List Bytes→Option FiniteWitness.Data
  | []=>some []
  | a::arr::img::rest=>do
      let l←LiteralParser.parse a
      if l.negative || arr≠[45,62] then none else do
        let v←parseImage img
        let w←parseWords rest
        return (l.varId,v)::w
  | _=>none

def parse (bs : Bytes) := parseWords (lex bs)

theorem words_roundtrip (w : FiniteWitness.Data)
    (hv : ∀ e∈w,0<e.1 ∧ FiniteWitness.validImage e.2=true) :
    parseWords (w.flatMap entryWords)=some w := by
  induction w with
  | nil=>rfl
  | cons e w ih=>
    have he:=hv e (by simp)
    have ht:=ih (by intro t ht;exact hv t (by simp [ht]))
    change parseWords (emit (literal ⟨e.1,false⟩)::[45,62]::emit (image e.2)::w.flatMap entryWords)=_
    rw [parseWords,LiteralParser.roundtrip _ he.1]
    simp only [Bool.false_or,ne_eq,not_true_eq_false,decide_false,Bool.false_eq_true,↓reduceIte,
      Option.bind_some,image_roundtrip _ he.2,ht]
    rfl

/-- Parsing the actual witness bytes recovers the finite simultaneous map,
including entry order. No pre-parsed witness is supplied to this parser. -/
theorem witness_roundtrip (w : FiniteWitness.Data) (hv : FiniteWitness.valid w=true) :
    parse (emit (witness w))=some w := by
  rw [parse,witness_lex]
  apply words_roundtrip
  intro e he
  have h:=(List.all_eq_true.mp (Bool.and_eq_true_iff.mp hv).1) e he
  obtain ⟨hk,hi⟩:=Bool.and_eq_true_iff.mp h
  exact ⟨of_decide_eq_true hk,hi⟩

#print axioms image_roundtrip
#print axioms witness_lex
#print axioms words_roundtrip
#print axioms witness_roundtrip
end L3Emitter.CanonicalWitnessParser

import ForcingPOL
import ConsumerLookup

namespace L3Emitter.ForcingDefinitions
open EREF EREF.GeneralRED REDWitness

structure Input where
  c : Int
  sel0 : Int
  sel1 : Int
  e00 : Int
  e01 : Int
  e10 : Int
  e11 : Int

def Input.lits (v : Input) := [v.c,v.sel0,v.sel1,v.e00,v.e01,v.e10,v.e11]
def Input.cmds (v : Input) (m : Nat) : List L3.Cmd := [
  .andDef (m+1) [v.c,v.sel0,v.e00], .andDef (m+2) [v.c,v.sel0,v.e01],
  .andDef (m+3) [v.c,v.sel1,v.e10], .andDef (m+4) [v.c,v.sel1,v.e11]]
def Input.rows (v : Input) (m : Nat) := (v.cmds m).flatMap L3.Cmd.rows

theorem exec_flat (D : List Row) (cs : List L3.Cmd) : L3.exec D cs=D++cs.flatMap L3.Cmd.rows := by
  induction cs generalizing D with
  | nil => simp [L3.exec]
  | cons c cs ih => simp [L3.exec,ih,List.append_assoc]

theorem wf (v : Input) (m : Nat) (h : L3.Bounded m v.lits) : L3.WF m (v.cmds m) := by
  have hc:=h v.c (by simp [Input.lits])
  have hs0:=h v.sel0 (by simp [Input.lits]); have hs1:=h v.sel1 (by simp [Input.lits])
  have h00:=h v.e00 (by simp [Input.lits]); have h01:=h v.e01 (by simp [Input.lits])
  have h10:=h v.e10 (by simp [Input.lits]); have h11:=h v.e11 (by simp [Input.lits])
  dsimp only [Input.cmds,L3.WF]
  refine ⟨rfl,?_,by omega,?_,by omega,?_,by omega,?_,trivial⟩ <;>
    intro l hl <;> simp only [List.mem_cons,List.not_mem_nil,or_false] at hl <;>
    rcases hl with rfl|rfl|rfl <;> omega

theorem trace (D : List Row) (v : Input) (m : Nat) (hD : L3.DBBounded D m)
    (h : L3.Bounded m v.lits) : CheckedTrace D (D++v.rows m) ∧
      L3.DBBounded (D++v.rows m) (m+4) := by
  have hw:=wf v m h
  constructor
  · rw [Input.rows,←exec_flat]
    apply L3.exec_trace D m _ hD hw
    simp [Input.cmds,L3.obls]
  · have hh:=L3.exec_bounded D m _ hD hw
    simpa [exec_flat,Input.rows,Input.cmds,L3.varAfter,Nat.add_assoc] using hh

theorem back_rows (D : List Row) (v : Input) (m : Nat) :
    clause [-v.c,-v.sel0,-v.e00,(m+1:Int)]∈D++v.rows m ∧
    clause [-v.c,-v.sel0,-v.e01,(m+2:Int)]∈D++v.rows m ∧
    clause [-v.c,-v.sel1,-v.e10,(m+3:Int)]∈D++v.rows m ∧
    clause [-v.c,-v.sel1,-v.e11,(m+4:Int)]∈D++v.rows m := by
  have h0:=L3.andDef_row_up D (v.cmds m) (m+1) [v.c,v.sel0,v.e00] (by simp [Input.cmds])
  have h1:=L3.andDef_row_up D (v.cmds m) (m+2) [v.c,v.sel0,v.e01] (by simp [Input.cmds])
  have h2:=L3.andDef_row_up D (v.cmds m) (m+3) [v.c,v.sel1,v.e10] (by simp [Input.cmds])
  have h3:=L3.andDef_row_up D (v.cmds m) (m+4) [v.c,v.sel1,v.e11] (by simp [Input.cmds])
  exact ⟨by simpa [exec_flat,Input.rows] using h0,
    by simpa [exec_flat,Input.rows] using h1,
    by simpa [exec_flat,Input.rows] using h2,
    by simpa [exec_flat,Input.rows] using h3⟩

theorem rows_length (v : Input) (m : Nat) : (v.rows m).length=16 := by
  simp [Input.rows,Input.cmds,L3.Cmd.rows,L3.andDefs,L3.Defs.rows]

#print axioms trace
#print axioms back_rows
end L3Emitter.ForcingDefinitions

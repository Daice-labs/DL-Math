import AliasProgram

namespace L3Emitter.IndependentProgram
open EREF EREF.GeneralRED REDWitness

theorem check (D : List Row) (p : AliasProgram.Program)
    (h : ∀c∈p,polEval (dbOf D) c.2 []=some c.1) (pre : List Row) :
    AliasProgram.check (D++pre) p=some ((D++pre)++AliasProgram.outputs p) := by
  induction p generalizing pre with
  | nil => simp [AliasProgram.check,AliasProgram.outputs]
  | cons c cs ih =>
    have he:=polEval_mono _ _ (dbOf_ext_append D pre) _ [] _ (h c (by simp))
    have ht:=ih (by intro d hd;exact h d (by simp [hd])) (pre++[c.1])
    simpa [AliasProgram.check,AliasProgram.outputs,he,List.append_assoc] using ht

theorem check_base (D : List Row) (p : AliasProgram.Program)
    (h : ∀c∈p,polEval (dbOf D) c.2 []=some c.1) :
    AliasProgram.check D p=some (D++AliasProgram.outputs p) := by
  simpa using check D p h []

#print axioms check_base
end L3Emitter.IndependentProgram

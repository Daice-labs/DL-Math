import NativeParserNameRanges
namespace L3Emitter.NativeParserFieldNames
open EREF NativeSparseStore RecordedScopedTrace CanonicalScopeKernel CanonicalFileGrammar
open NativeParserEventCoordinates ByteOperandBounds

theorem row_names (M:Nat) (R:Row) (h:RowBound M R):∀v∈rowNames R,v≤M:=by
 intro v hv
 obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hv
 exact (h.1 t ht).2

theorem tape_names (M:Nat) (ts:List Tok) (h:∀t∈ts,TokenBound M t):
 ∀v∈ts.flatMap tokenNames,v≤M:=by
 intro v hv
 obtain ⟨t,ht,hv⟩:=List.mem_flatMap.mp hv
 cases t with
 | lit l=>obtain rfl:=List.mem_singleton.mp hv;exact h _ ht
 | ref _ | mul _ | div _ | add | sat=>simp [tokenNames] at hv

theorem witness_names (M:Nat) (w:FiniteWitness.Data) (h:WitnessBound M w):
 ∀v∈witnessNames w,v≤M:=by
 intro v hv
 obtain ⟨e,he,hv⟩:=List.mem_flatMap.mp hv
 rcases List.mem_cons.mp hv with rfl|hv
 · exact (h e he).1
 · have hh:=(h e he).2
   cases hx:e.2 with
   | bit b=>simp [hx,imageNames] at hv
   | lit l=>
     rw [hx] at hh
     have heq:v=l.varId:=by simpa only [hx,imageNames,List.mem_singleton] using hv
     rw [heq];exact hh

theorem local_names (M:Nat) (b:NativeScopedLocalGoal.Built) (h:SerializedLocalBudget.Fields M b):
 ∀e∈localEvents (stripLocal b),∀v∈eventNames e,v≤M:=by
 intro e he v hv
 simp only [localEvents,List.mem_append,List.mem_singleton] at he
 rcases he with he|rfl
 · obtain ⟨ts,ht,rfl⟩:=List.mem_map.mp he
   exact tape_names M ts (h.1 ts ht) v hv
 · simp [eventNames] at hv

theorem goals_names (M:Nat) (ids:Nat→Nat) (i:Nat) (bs:List (Row×NativeScopedLocalGoal.Built))
 (h:∀b∈bs,SerializedLocalBudget.Fields M b.2):
 ∀e∈(packGoals ids i bs).flatMap goalEvents,∀v∈eventNames e,v≤M:=by
 induction bs generalizing i with
 | nil=>simp [packGoals]
 | cons b bs ih=>
   intro e he v hv
   simp only [packGoals,List.flatMap_cons,List.mem_append] at he
   rcases he with he|he
   · rcases List.mem_cons.mp he with rfl|he
     · simp [eventNames] at hv
     · exact local_names M b.2 (h b (by simp)) e he v hv
   · exact ih (i+1) (fun q hq=>h q (by simp [hq])) e he v hv

theorem action_names (M W V:Nat) (ids:Nat→Nat) (a:NativeRecordedStep.Action)
 (h:SerializedActionBudget.Fields M W V ids a):
 ∀e∈commandEvents (pack ids a),∀v∈eventNames e,v≤M:=by
 cases a with
 | pol ts=>
   intro e he
   obtain rfl:=List.mem_singleton.mp he
   exact tape_names M ts h
 | consequence R b=>
   intro e he
   rcases List.mem_cons.mp he with rfl|he
   · exact row_names M R h.1
   · exact local_names M b h.2.2 e he
 | red R w bs=>
   intro e he v hv
   simp only [pack,commandEvents,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at he
   rcases he with (rfl|he)|rfl
   · rcases List.mem_append.mp hv with hv|hv
     · exact row_names M R h.1 v hv
     · exact witness_names M w h.2.2.1 v hv
   · exact goals_names M ids 0 bs h.2.2.2.2.1 e he v hv
   · simp [eventNames] at hv

theorem program_names (M W V:Nat) (D:List Row) (s:Store) (ids:Nat→Nat) (p:Program)
 (h:WholeFileByteBudget.Fields M W V D s ids p):
 ∀e∈(CanonicalScopeKernel.compile D s ids p).flatMap commandEvents,∀v∈eventNames e,v≤M:=by
 induction p generalizing D s ids with
 | nil=>simp [CanonicalScopeKernel.compile]
 | cons c cs ih=>
   intro e he v hv
   simp only [CanonicalScopeKernel.compile,List.flatMap_cons,List.mem_append] at he
   rcases he with he|he
   · exact action_names M W V ids _ h.1 e he v hv
   · exact ih _ _ _ h.2 e he v hv

theorem names_length (n M W V:Nat)
 (hf:∀R∈NativeRecordedFamily.original n,RowBound M R)
 (hp:WholeFileByteBudget.Fields M W V (NativeRecordedFamily.original n)
   (initial (NativeRecordedFamily.original n)) id (NativeCompatibleFamily.emitter n)):
 (NativeParserBundle.names n).length≤M+1:=by
 rw [NativeParserNameRanges.full_names]
 apply PinnedNameSequence.length_bound M _ (PinnedNameSequence.nodup [] _ (by simp))
 apply PinnedNameSequence.bounded M [] _ (by simp)
 intro v hv
 rcases List.mem_append.mp hv with hv|hv
 · obtain ⟨R,hR,hv⟩:=List.mem_flatMap.mp hv
   exact row_names M R (hf R hR) v hv
 · obtain ⟨e,he,hv⟩:=List.mem_flatMap.mp hv
   exact program_names M W V _ _ _ _ hp e he v hv
#print axioms names_length
end L3Emitter.NativeParserFieldNames

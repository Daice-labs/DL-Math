import PortSelectorJoin
namespace L3Emitter.GammaSourcePorts
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
abbrev Job:=BetaPort.Job

def q (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))):=
  (EarlierPortValues.wireAlias n hn (GammaCofactorValue.g j)) (SelectedVectorOneHot.position i)
def m (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))):=(GateSnapshots.refs n hn (GammaCofactorValue.g j) i).m
def port (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (side:Bool):=
  EarlierPortValues.portAlias n hn (GammaCofactorValue.g j) (if side then 1 else 0) (SelectedVectorOneHot.position i)

theorem aux_keep (n:Nat) (hn:2≤n):∀R∈SourceAuxBank.result n hn,R∈GammaComparisonBank.result n hn:=by
  intro R h
  apply EarlierPortValues.unary_keep n hn
  apply CofactorValueRows.unary_keep n hn
  apply UnaryRelationBank.retains n hn
  exact List.mem_append_left _ (SelectorBank.trace_retains (check_trace _ _ _ (GateOrderSources.full_check n hn)) R h)
theorem source_keep (n:Nat) (hn:2≤n):∀R∈SourceRelationBank.result n hn,R∈GammaComparisonBank.result n hn:=
  fun R h=>aux_keep n hn R (SourceAuxBank.retains n hn R (UnitAliasBank.retains n hn R h))

theorem gamma_relation (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))):
    clause [-((PrimaryAliasBank.cfg n hn).gamma (GammaCofactorValue.g j)).val,-(q n hn j i).val,(m n hn j i).val]∈GammaComparisonBank.result n hn:=by
  have hg:=SelectedCategoryRows.gamma_bounds j
  exact source_keep n hn _ (SourceRelationBank.gamma_relations n hn _ hg.1 hg.2 i).2

theorem left_binding (n:Nat) (hn:2≤n) (g:Nat):
    (RecordedGateSnapshots.left n hn g).1.1=
      (CoordinateSnapshots.left (PrimaryAliasBank.cfg n hn) (GateSnapshots.beforeGate n hn g).1 g (GateSnapshots.beforeGate n hn g).2).1:=
  congrArg Prod.fst (ConcreteOriginalPorts.binding ..)
theorem right_binding (n:Nat) (hn:2≤n) (g:Nat):
    (RecordedGateSnapshots.right n hn g).1.1=
      (CoordinateSnapshots.right (PrimaryAliasBank.cfg n hn) (GateSnapshots.beforeGate n hn g).1 g (GateSnapshots.beforeGate n hn g).2).1:=by
  have hz:=congrArg Prod.snd (ConcreteOriginalPorts.binding (n+1) g ((PrimaryAliasBank.cfg n hn).sel g 0)
    (GateSnapshots.beforeGate n hn g).1 (GateSnapshots.beforeGate n hn g).2)
  have hr:=congrArg Prod.fst (ConcreteOriginalPorts.binding (n+1) g ((PrimaryAliasBank.cfg n hn).sel g 1)
    (GateSnapshots.beforeGate n hn g).1 (RecordedGateSnapshots.left n hn g).2)
  change (RecordedGateSnapshots.right n hn g).1.1=_ at hr
  change (RecordedGateSnapshots.left n hn g).2=(CoordinateSnapshots.left (PrimaryAliasBank.cfg n hn) (GateSnapshots.beforeGate n hn g).1 g (GateSnapshots.beforeGate n hn g).2).2 at hz
  rw [hz] at hr
  exact hr

theorem mux_relation (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (side:Bool):
    clause [-sign side (GammaChoiceBank.hit n hn j.1),-(m n hn j i).val,(port n hn j i side).val]∈GammaComparisonBank.result n hn:=by
  have hg:=SelectedCategoryRows.gamma_bounds j
  apply aux_keep n hn
  apply SourceAuxBank.contains_job n hn (.mux (GammaCofactorValue.g j) i) (SourceAuxBank.mux_mem n _ hg.1 hg.2 i)
  have he:(SourceMuxSnapshots.actual n hn (GammaCofactorValue.g j) i).q=m n hn j i:=rfl
  have ha:port n hn j i true=(SourceMuxSnapshots.actual n hn (GammaCofactorValue.g j) i).a:=by
    exact congrFun (right_binding n hn (GammaCofactorValue.g j)) _
  have hb:port n hn j i false=(SourceMuxSnapshots.actual n hn (GammaCofactorValue.g j) i).b:=by
    exact congrFun (left_binding n hn (GammaCofactorValue.g j)) _
  cases side <;> simp only [ha,hb,←he,SourceAuxBank.jobRows,RecordedExpressions.jobRows,sign,Bool.false_eq_true,↓reduceIte,neg_neg]
  · apply List.mem_cons_of_mem _;apply List.mem_cons_of_mem _;apply List.mem_cons_of_mem _
    exact List.mem_singleton_self _
  · apply List.mem_cons_of_mem _;exact List.mem_cons_self

def firstRow (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))):=
  clause [-BetaAliasValue.choice j,-(q n hn j i).val,(m n hn j i).val]
def firstTape (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (D:List Row):=
  CommonGuardResolve.tape D [] [-BetaAliasValue.choice j] [-(q n hn j i).val,(m n hn j i).val]
    ((PrimaryAliasBank.cfg n hn).gamma (GammaCofactorValue.g j)).val

theorem first_check (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (D:List Row)
    (hd:∀R∈GammaComparisonBank.result n hn,R∈D):
    polEval (dbOf D) (firstTape n hn j i D) []=some (firstRow n hn j i):=by
  apply CommonGuardResolve.checks D [] _ _ _ (by simp [Valid])
    (by simp [Valid,BetaAliasValue.choice_valid n hn j hj]) (by simp [Valid,(q n hn j i).property,(m n hn j i).property])
    ((PrimaryAliasBank.cfg n hn).gamma (GammaCofactorValue.g j)).property
  · apply hd
    apply List.mem_append_left;apply List.mem_append_left;apply List.mem_append_left
    exact GammaChoiceBank.gamma n hn j.1 (GammaCofactorValue.forcing_job n hn j hj)
  · exact hd _ (gamma_relation n hn j i)

def row (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (side:Bool):=
  clause [-BetaAliasValue.choice j,-(q n hn j i).val,-sign side (GammaChoiceBank.hit n hn j.1),(port n hn j i side).val]
def tape (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (side:Bool) (D:List Row):=
  CommonGuardResolve.tape D [] [-BetaAliasValue.choice j,-(q n hn j i).val]
    [-sign side (GammaChoiceBank.hit n hn j.1),(port n hn j i side).val] (m n hn j i).val

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (side:Bool) (D:List Row)
    (hd:∀R∈GammaComparisonBank.result n hn,R∈D) (hf:firstRow n hn j i∈D):
    polEval (dbOf D) (tape n hn j i side D) []=some (row n hn j i side):=by
  apply CommonGuardResolve.checks D [] [-BetaAliasValue.choice j,-(q n hn j i).val]
    [-sign side (GammaChoiceBank.hit n hn j.1),(port n hn j i side).val] _ (by simp [Valid])
    (by simp [Valid,BetaAliasValue.choice_valid n hn j hj,(q n hn j i).property])
    (by simp [Valid,sign_valid,(port n hn j i side).property]) (m n hn j i).property hf
  have hh:=hd _ (mux_relation n hn j i side)
  have he:clause [-sign side (GammaChoiceBank.hit n hn j.1),-(m n hn j i).val,(port n hn j i side).val]=
      CommonGuardResolve.right [] [-sign side (GammaChoiceBank.hit n hn j.1),(port n hn j i side).val] (m n hn j i).val:=by
    apply ProjectionTrace.clause_perm _ _ (by simp [Valid,sign_valid,(m n hn j i).property,(port n hn j i side).property])
      (by simp [Valid,sign_valid,(m n hn j i).property,(port n hn j i side).property])
    exact List.Perm.swap _ _ _
  exact he ▸ hh
#print axioms gamma_relation
#print axioms mux_relation
#print axioms checks
end L3Emitter.GammaSourcePorts

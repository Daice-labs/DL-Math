/-
Obligation 1(d): the two RED commands

    for c in (3,12): p.red([(-1 if (c>>(3-ab))&1 else 1)*F.fun(0,ab) for ab in range(4)],
                           swap(F,0,1,True))

`swap(F,0,1,True)` is the input-wire swap 0 ↔ 1 followed, on gate 0 only, by the port
flip p ↦ 1−p (selectors and port values) and the function-entry flip fn(0,1) ↔ fn(0,2).
We factor it as `flipId ∘ swapId 0 1` and reuse `image_rows` for the first factor.
The candidate rows are `row2 0 3` and `row2 0 12`; their substituted images are the
codes-5 and codes-10 rows, which are not in the database: the obligations are discharged
by the cover certificate ¬C + ¬(C|ω) (the shared fn literals cancel).
-/
import L3ConstWitness

namespace L3
open EREF EREF.GeneralRED

/-! ### Generic pieces -/

/-- If the two rows cover every assignment with a literal to spare, their negations add
    to a contradictory row (transcribed from REDWitness.cover_certificate). -/
theorem cover_certificate (rows : List EREF.Row) (C G : EREF.Row)
    (hC : Canonical C) (hG : Canonical G)
    (hcover : ∀ α, -1 ≤ C.val α + G.val α) : LocalCertificate rows C G := by
  refine ⟨[.ref (rows.length+1),.ref (rows.length+2),.add], add (negate C) (negate G), ?_, ?_⟩
  · simp [polEval, db_neg_left, db_neg_right]
  · apply (canonical_contra_iff _ (canonical_add _ _)).mpr
    intro α hs
    have hv := val_add (negate C) (negate G) (canonical_negate _) (canonical_negate _) α
    rw [val_negate _ hC, val_negate _ hG] at hv
    have := hcover α
    unfold Row.sat at hs
    omega

theorem refutation_of_cover (D : List EREF.Row) (C G : EREF.Row) (hC : Canonical C) (hG : Canonical G)
    (hcover : ∀ α, -1 ≤ C.val α + G.val α) : Refutation (D ++ [negate C, negate G]) :=
  single_to_refutation D C G (cover_certificate D C G hC hG hcover)

/-- RED step: every old row's image is in the database or has its own refutation -/
theorem checkedStep_red_general (D : List EREF.Row) (C : EREF.Row) (ω : Witness)
    (hD : ∀ R ∈ D, Canonical R) (hC : Canonical C)
    (hclosed : ∀ R ∈ D, substRow R ω ∈ D ∨ Refutation (D ++ [negate C, negate (substRow R ω)]))
    (hcand : Refutation (D ++ [negate C, negate (substRow C ω)])) :
    CheckedStep D (D ++ [C]) := by
  apply CheckedStep.red D C ω hC
  intro R hR
  rcases List.mem_cons.mp hR with rfl | hR
  · exact hcand
  · rcases hclosed R hR with h | h
    · exact refutation_of_mem D C _ hD h
    · exact h

theorem Row.equiv_trans {r s t : Row} (h1 : r.equiv s) (h2 : s.equiv t) : r.equiv t :=
  ⟨h1.1.trans h2.1, fun α => (h1.2 α).trans (h2.2 α)⟩

theorem mapLit_comp (ρ σ : Nat → Nat) (l : Int) (hσ : 1 ≤ σ l.natAbs) :
    mapLit (fun v => ρ (σ v)) l = mapLit ρ (mapLit σ l) := by
  unfold mapLit
  have h0 : ¬ σ l.natAbs = 0 := by omega
  split
  · have : (0 : Int) < (σ l.natAbs : Nat) := by omega
    simp [this, h0]
  · have : ¬ (0 : Int) < -((σ l.natAbs : Nat) : Int) := by omega
    have h1 : ¬ ((σ l.natAbs : Nat) : Int) < 0 := by omega
    simp [this, h0, h1]

theorem imageRow_comp (ρ σ : Nat → Nat) (r : Row) (hσ : ∀ l ∈ r.lits, 1 ≤ σ l.natAbs) :
    imageRow (fun v => ρ (σ v)) r = imageRow ρ (imageRow σ r) := by
  unfold imageRow
  simp only [List.map_map, Row.mk.injEq, and_true]
  apply List.map_congr_left
  intro l hl
  exact mapLit_comp ρ σ l (hσ l hl)

/-- images under a positive id map respect semantic identity -/
theorem equiv_image (ρ : Nat → Nat) (hρ : ∀ v, 1 ≤ v → 1 ≤ ρ v) (r r' : Row)
    (hz : r.nz) (hz' : r'.nz) (h : r.equiv r') : (imageRow ρ r).equiv (imageRow ρ r') := by
  refine ⟨h.1, fun α => ?_⟩
  unfold imageRow
  simp only
  rw [← lsum_image ρ α r.lits (fun l hl => hρ _ (by have := hz l hl; omega)),
    ← lsum_image ρ α r'.lits (fun l hl => hρ _ (by have := hz' l hl; omega))]
  exact h.2 _

namespace Fam

/-! ### The gate-0 port flip ρ -/

def flipId (F : Fam) (v : Nat) : Nat :=
  match F.decodeSel v with
  | some (t, p, j) => if t = 0 then F.sel 0 (1 - p) j else v
  | none =>
    if v = F.fn 0 1 then F.fn 0 2
    else if v = F.fn 0 2 then F.fn 0 1
    else match F.decodePort v with
      | some (t, p, x) => if t = 0 then F.port 0 (1 - p) x else v
      | none => v

theorem flipId_sel0 (F : Fam) (hs : 1 ≤ F.s) (p j : Nat) (hp : p < 2) (hj : j < F.k) :
    F.flipId (F.sel 0 p j) = F.sel 0 (1 - p) j := by
  unfold flipId; rw [F.decodeSel_sel 0 p j hs hp (by omega)]; simp

theorem flipId_sel (F : Fam) (t p j : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k + t) (h0 : t ≠ 0) :
    F.flipId (F.sel t p j) = F.sel t p j := by
  unfold flipId; rw [F.decodeSel_sel t p j ht hp hj]; simp [h0]

theorem flipId_fn01 (F : Fam) : F.flipId (F.fn 0 1) = F.fn 0 2 := by
  unfold flipId; rw [F.decodeSel_none _ (by unfold fn; omega)]; simp

theorem flipId_fn02 (F : Fam) : F.flipId (F.fn 0 2) = F.fn 0 1 := by
  unfold flipId; rw [F.decodeSel_none _ (by unfold fn; omega)]
  have h1 : ¬ F.fn 0 2 = F.fn 0 1 := by unfold fn; omega
  simp [h1]

theorem flipId_fn (F : Fam) (t ab : Nat) (ht : t < F.s) (hab : ab < 4)
    (hne : ¬ (t = 0 ∧ (ab = 1 ∨ ab = 2))) : F.flipId (F.fn t ab) = F.fn t ab := by
  unfold flipId; rw [F.decodeSel_none _ (by unfold fn; omega)]
  have h1 : ¬ F.fn t ab = F.fn 0 1 := by unfold fn; omega
  have h2 : ¬ F.fn t ab = F.fn 0 2 := by unfold fn; omega
  simp only [h1, h2, ↓reduceIte]
  have hr := F.fn_range t ab ht hab
  rw [F.decodePort_none _ (Or.inl (by omega))]

theorem flipId_port0 (F : Fam) (hs : 1 ≤ F.s) (p x : Nat) (hp : p < 2) (hx : x < F.T) :
    F.flipId (F.port 0 p x) = F.port 0 (1 - p) x := by
  unfold flipId
  have hr := F.port_range 0 p x hs hp hx
  rw [F.decodeSel_none _ (by omega)]
  have h1 : ¬ F.port 0 p x = F.fn 0 1 := by unfold fn; omega
  have h2 : ¬ F.port 0 p x = F.fn 0 2 := by unfold fn; omega
  simp only [h1, h2, ↓reduceIte]
  rw [F.decodePort_port 0 p x hs hp hx]; simp

theorem flipId_port (F : Fam) (t p x : Nat) (ht : t < F.s) (hp : p < 2) (hx : x < F.T) (h0 : t ≠ 0) :
    F.flipId (F.port t p x) = F.port t p x := by
  unfold flipId
  have hr := F.port_range t p x ht hp hx
  rw [F.decodeSel_none _ (by omega)]
  have h1 : ¬ F.port t p x = F.fn 0 1 := by unfold fn; omega
  have h2 : ¬ F.port t p x = F.fn 0 2 := by unfold fn; omega
  simp only [h1, h2, ↓reduceIte]
  rw [F.decodePort_port t p x ht hp hx]; simp [h0]

theorem flipId_val (F : Fam) (t x : Nat) (ht : t < F.s) (hx : x < F.T) :
    F.flipId (F.val t x) = F.val t x := by
  unfold flipId
  have hr := F.val_range t x ht hx
  rw [F.decodeSel_none _ (by omega)]
  have h1 : ¬ F.val t x = F.fn 0 1 := by unfold fn; omega
  have h2 : ¬ F.val t x = F.fn 0 2 := by unfold fn; omega
  simp only [h1, h2, ↓reduceIte]
  rw [F.decodePort_none _ (Or.inr (by omega))]

theorem flipId_pos (F : Fam) (v : Nat) (hv : 1 ≤ v) : 1 ≤ F.flipId v := by
  unfold flipId
  split
  · split
    · exact F.sel_pos _ _ _
    · exact hv
  · split
    · exact F.fn_pos _ _
    · split
      · exact F.fn_pos _ _
      · split
        · split
          · exact F.port_pos _ _ _
          · exact hv
        · exact hv

/-- `swap(F,0,1,True)` as an id map -/
def portsSwapId (F : Fam) (v : Nat) : Nat := F.flipId (F.swapId 0 1 v)

theorem portsSwapId_pos (F : Fam) (v : Nat) (hv : 1 ≤ v) : 1 ≤ F.portsSwapId v :=
  F.flipId_pos _ (F.swapId_pos 0 1 v hv)

/-! ### ρ-images of the named rows -/

section Flip
variable (F : Fam) (hs : 1 ≤ F.s)
include hs

theorem flip_row1 (t p : Nat) (ht : t < F.s) (hp : p < 2) :
    imageRow F.flipId (F.row1 t p) = (if t = 0 then F.row1 0 (1 - p) else F.row1 t p) := by
  unfold imageRow row1
  by_cases h0 : t = 0
  · subst h0
    simp only [↓reduceIte, List.map_map, Row.mk.injEq, and_true, Nat.add_zero]
    apply List.map_congr_left; intro j hj
    simp only [Function.comp]
    rw [mapLit_pos _ _ (F.sel_pos _ _ _), F.flipId_sel0 hs p j hp (List.mem_range.mp hj)]
  · simp only [h0, ↓reduceIte, List.map_map, Row.mk.injEq, and_true]
    apply List.map_congr_left; intro j hj
    simp only [Function.comp]
    rw [mapLit_pos _ _ (F.sel_pos _ _ _), F.flipId_sel t p j ht hp (List.mem_range.mp hj) h0]

theorem flip_row1' (t p : Nat) (ht : t < F.s) (hp : p < 2) :
    imageRow F.flipId (F.row1' t p) = (if t = 0 then F.row1' 0 (1 - p) else F.row1' t p) := by
  unfold imageRow row1'
  by_cases h0 : t = 0
  · subst h0
    simp only [↓reduceIte, List.map_map, Row.mk.injEq, and_true, Nat.add_zero]
    apply List.map_congr_left; intro j hj
    simp only [Function.comp]
    rw [mapLit_neg _ _ (F.sel_pos _ _ _), F.flipId_sel0 hs p j hp (List.mem_range.mp hj)]
  · simp only [h0, ↓reduceIte, List.map_map, Row.mk.injEq, and_true]
    apply List.map_congr_left; intro j hj
    simp only [Function.comp]
    rw [mapLit_neg _ _ (F.sel_pos _ _ _), F.flipId_sel t p j ht hp (List.mem_range.mp hj) h0]

omit hs in
theorem flip_row2 (t c : Nat) (ht : t < F.s) (h0 : t ≠ 0) :
    imageRow F.flipId (F.row2 t c) = F.row2 t c := by
  unfold imageRow row2
  simp only [List.map_map, Row.mk.injEq, and_true]
  apply List.map_congr_left; intro ab hab
  have hab4 := List.mem_range.mp hab
  simp only [Function.comp]
  split
  · rw [mapLit_neg _ _ (F.fn_pos t ab), F.flipId_fn t ab ht hab4 (by omega)]
  · rw [mapLit_pos _ _ (F.fn_pos t ab), F.flipId_fn t ab ht hab4 (by omega)]

/-- the gate-0 code rows 6 and 9 are symmetric under fn(0,1) ↔ fn(0,2) -/
theorem flip_row2_0 (c : Nat) (hc : c = 6 ∨ c = 9) :
    (imageRow F.flipId (F.row2 0 c)).equiv (F.row2 0 c) := by
  refine ⟨rfl, fun α => ?_⟩
  unfold imageRow row2
  have hr : List.range 4 = [0, 1, 2, 3] := by decide
  simp only [hr, List.map_cons, List.map_nil, lsum_cons, lsum_nil]
  have f0 := F.flipId_fn 0 0 hs (by omega) (by omega)
  have f3 := F.flipId_fn 0 3 hs (by omega) (by omega)
  have f1 := F.flipId_fn01
  have f2 := F.flipId_fn02
  rcases hc with rfl | rfl
  · have c0 : codeBit 6 0 = false := by decide
    have c1 : codeBit 6 1 = true := by decide
    have c2 : codeBit 6 2 = true := by decide
    have c3 : codeBit 6 3 = false := by decide
    simp only [c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte]
    rw [mapLit_pos _ _ (F.fn_pos 0 0), mapLit_neg _ _ (F.fn_pos 0 1), mapLit_neg _ _ (F.fn_pos 0 2),
      mapLit_pos _ _ (F.fn_pos 0 3), f0, f1, f2, f3]
    omega
  · have c0 : codeBit 9 0 = true := by decide
    have c1 : codeBit 9 1 = false := by decide
    have c2 : codeBit 9 2 = false := by decide
    have c3 : codeBit 9 3 = true := by decide
    simp only [c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte]
    rw [mapLit_neg _ _ (F.fn_pos 0 0), mapLit_pos _ _ (F.fn_pos 0 1), mapLit_pos _ _ (F.fn_pos 0 2),
      mapLit_neg _ _ (F.fn_pos 0 3), f0, f1, f2, f3]
    omega

theorem flip_row3i (t p j x : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k) (hx : x < F.T) :
    imageRow F.flipId (F.row3i t p j x) = (if t = 0 then F.row3i 0 (1 - p) j x else F.row3i t p j x) := by
  unfold imageRow row3i
  by_cases h0 : t = 0
  · subst h0
    simp only [↓reduceIte, List.map_cons, List.map_nil, Row.mk.injEq, and_true]
    rw [mapLit_neg _ _ (F.sel_pos _ _ _), F.flipId_sel0 hs p j hp hj]
    split
    · rw [mapLit_pos _ _ (F.port_pos _ _ _), F.flipId_port0 hs p x hp hx]
    · rw [mapLit_neg _ _ (F.port_pos _ _ _), F.flipId_port0 hs p x hp hx]
  · simp only [h0, ↓reduceIte, List.map_cons, List.map_nil, Row.mk.injEq, and_true]
    rw [mapLit_neg _ _ (F.sel_pos _ _ _), F.flipId_sel t p j ht hp (by omega) h0]
    split
    · rw [mapLit_pos _ _ (F.port_pos _ _ _), F.flipId_port t p x ht hp hx h0]
    · rw [mapLit_neg _ _ (F.port_pos _ _ _), F.flipId_port t p x ht hp hx h0]

omit hs in
theorem flip_row3g (t p i x : Nat) (ht : t < F.s) (hp : p < 2) (hi : i < t) (hx : x < F.T) :
    imageRow F.flipId (F.row3g t p i x) = F.row3g t p i x := by
  unfold imageRow row3g
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [mapLit_neg _ _ (F.sel_pos _ _ _), F.flipId_sel t p _ ht hp (by omega) (by omega),
    mapLit_neg _ _ (F.val_pos _ _), F.flipId_val i x (by omega) hx,
    mapLit_pos _ _ (F.port_pos _ _ _), F.flipId_port t p x ht hp hx (by omega)]

omit hs in
theorem flip_row3g' (t p i x : Nat) (ht : t < F.s) (hp : p < 2) (hi : i < t) (hx : x < F.T) :
    imageRow F.flipId (F.row3g' t p i x) = F.row3g' t p i x := by
  unfold imageRow row3g'
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [mapLit_neg _ _ (F.sel_pos _ _ _), F.flipId_sel t p _ ht hp (by omega) (by omega),
    mapLit_pos _ _ (F.val_pos _ _), F.flipId_val i x (by omega) hx,
    mapLit_neg _ _ (F.port_pos _ _ _), F.flipId_port t p x ht hp hx (by omega)]

/-- fn(0, 2a+b) ↦ fn(0, 2b+a) under the entry flip -/
theorem flipId_fn_ab (a b : Nat) (ha : a < 2) (hb : b < 2) :
    F.flipId (F.fn 0 (2 * a + b)) = F.fn 0 (2 * b + a) := by
  have ha' : a = 0 ∨ a = 1 := by omega
  have hb' : b = 0 ∨ b = 1 := by omega
  rcases ha' with rfl | rfl <;> rcases hb' with rfl | rfl
  · show F.flipId (F.fn 0 0) = F.fn 0 0; exact F.flipId_fn 0 0 hs (by omega) (by omega)
  · show F.flipId (F.fn 0 1) = F.fn 0 2; exact F.flipId_fn01
  · show F.flipId (F.fn 0 2) = F.fn 0 1; exact F.flipId_fn02
  · show F.flipId (F.fn 0 3) = F.fn 0 3; exact F.flipId_fn 0 3 hs (by omega) (by omega)

theorem flip_m1 (x a : Nat) (hx : x < F.T) : mapLit F.flipId (F.m1 0 x a) = F.m2 0 x a := by
  unfold m1 m2; split
  · rw [mapLit_neg _ _ (F.port_pos _ _ _), F.flipId_port0 hs 0 x (by omega) hx]
  · rw [mapLit_pos _ _ (F.port_pos _ _ _), F.flipId_port0 hs 0 x (by omega) hx]

theorem flip_m2 (x b : Nat) (hx : x < F.T) : mapLit F.flipId (F.m2 0 x b) = F.m1 0 x b := by
  unfold m1 m2; split
  · rw [mapLit_neg _ _ (F.port_pos _ _ _), F.flipId_port0 hs 1 x (by omega) hx]
  · rw [mapLit_pos _ _ (F.port_pos _ _ _), F.flipId_port0 hs 1 x (by omega) hx]

/-- gate-0 block-4 rows: ports and function entries flip together, giving `row4 0 x b a` up to
    the order of the first two literals -/
theorem flip_row4P_0 (pol : Bool) (x a b : Nat) (hx : x < F.T) (ha : a < 2) (hb : b < 2) :
    (imageRow F.flipId (F.row4P pol 0 x a b)).equiv (F.row4P pol 0 x b a) := by
  refine ⟨by unfold imageRow row4P; cases pol <;> rfl, fun α => ?_⟩
  unfold imageRow
  simp only
  rw [lsum_row4P]
  unfold row4P
  cases pol <;> simp only [row4, row4', Bool.false_eq_true, ↓reduceIte, List.map_cons, List.map_nil,
    lsum_cons, lsum_nil] <;>
    rw [F.flip_m1 hs x a hx, F.flip_m2 hs x b hx] <;>
    first
    | (rw [mapLit_neg _ _ (F.val_pos _ _), F.flipId_val 0 x hs hx,
        mapLit_pos _ _ (F.fn_pos _ _), F.flipId_fn_ab hs a b ha hb]; omega)
    | (rw [mapLit_pos _ _ (F.val_pos _ _), F.flipId_val 0 x hs hx,
        mapLit_neg _ _ (F.fn_pos _ _), F.flipId_fn_ab hs a b ha hb]; omega)

omit hs in
theorem flip_row4P (pol : Bool) (t x a b : Nat) (ht : t < F.s) (hx : x < F.T) (ha : a < 2) (hb : b < 2) (h0 : t ≠ 0) :
    imageRow F.flipId (F.row4P pol t x a b) = F.row4P pol t x a b := by
  unfold imageRow row4P
  cases pol <;> simp only [row4, row4', Bool.false_eq_true, ↓reduceIte, List.map_cons, List.map_nil,
    Row.mk.injEq, and_true]
  all_goals
    have hm1 : mapLit F.flipId (F.m1 t x a) = F.m1 t x a := by
      unfold m1; split
      · rw [mapLit_neg _ _ (F.port_pos _ _ _), F.flipId_port t 0 x ht (by omega) hx h0]
      · rw [mapLit_pos _ _ (F.port_pos _ _ _), F.flipId_port t 0 x ht (by omega) hx h0]
    have hm2 : mapLit F.flipId (F.m2 t x b) = F.m2 t x b := by
      unfold m2; split
      · rw [mapLit_neg _ _ (F.port_pos _ _ _), F.flipId_port t 1 x ht (by omega) hx h0]
      · rw [mapLit_pos _ _ (F.port_pos _ _ _), F.flipId_port t 1 x ht (by omega) hx h0]
    rw [hm1, hm2]
  · rw [mapLit_pos _ _ (F.val_pos _ _), F.flipId_val t x ht hx,
      mapLit_neg _ _ (F.fn_pos _ _), F.flipId_fn t _ ht (by omega) (by omega)]
  · rw [mapLit_neg _ _ (F.val_pos _ _), F.flipId_val t x ht hx,
      mapLit_pos _ _ (F.fn_pos _ _), F.flipId_fn t _ ht (by omega) (by omega)]

theorem flip_row5 (x : Nat) (hx : x < F.T) : imageRow F.flipId (F.row5 x) = F.row5 x := by
  unfold imageRow row5
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  split
  · rw [mapLit_pos _ _ (F.val_pos _ _), F.flipId_val _ x (by omega) hx]
  · rw [mapLit_neg _ _ (F.val_pos _ _), F.flipId_val _ x (by omega) hx]

/-- **ρ maps original rows to original rows** (semantically) -/
theorem flip_rows : ∀ r ∈ F.rows, ∃ r' ∈ F.rows, (imageRow F.flipId r).equiv r' := by
  intro r hr
  rcases F.mem_rows r hr with ⟨t, p, ht, hp, rfl | rfl⟩ | ⟨t, c, ht, hc, rfl⟩ |
    ⟨t, p, j, x, ht, hp, hj, hx, rfl⟩ | ⟨t, p, i, x, ht, hp, hi, hx, rfl | rfl⟩ |
    ⟨t, x, a, b, ht, hx, ha, hb, rfl | rfl⟩ | ⟨x, hx, rfl⟩
  · rw [F.flip_row1 hs t p ht hp]
    split
    · exact ⟨_, F.row1_mem 0 (1 - p) hs (by omega), Row.equiv_refl _⟩
    · exact ⟨_, F.row1_mem t p ht hp, Row.equiv_refl _⟩
  · rw [F.flip_row1' hs t p ht hp]
    split
    · exact ⟨_, F.row1'_mem 0 (1 - p) hs (by omega), Row.equiv_refl _⟩
    · exact ⟨_, F.row1'_mem t p ht hp, Row.equiv_refl _⟩
  · by_cases h0 : t = 0
    · subst h0; exact ⟨_, F.row2_mem 0 c hs hc, F.flip_row2_0 hs c hc⟩
    · rw [F.flip_row2 t c ht h0]; exact ⟨_, F.row2_mem t c ht hc, Row.equiv_refl _⟩
  · rw [F.flip_row3i hs t p j x ht hp hj hx]
    split
    · exact ⟨_, F.row3i_mem 0 (1 - p) j x hs (by omega) hj hx, Row.equiv_refl _⟩
    · exact ⟨_, F.row3i_mem t p j x ht hp hj hx, Row.equiv_refl _⟩
  · rw [F.flip_row3g t p i x ht hp hi hx]; exact ⟨_, F.row3g_mem t p i x ht hp hi hx, Row.equiv_refl _⟩
  · rw [F.flip_row3g' t p i x ht hp hi hx]; exact ⟨_, F.row3g'_mem t p i x ht hp hi hx, Row.equiv_refl _⟩
  · rw [← F.row4P_true]
    by_cases h0 : t = 0
    · subst h0; exact ⟨_, F.row4P_mem true 0 x b a hs hx hb ha, F.flip_row4P_0 hs true x a b hx ha hb⟩
    · rw [F.flip_row4P true t x a b ht hx ha hb h0]; exact ⟨_, F.row4P_mem true t x a b ht hx ha hb, Row.equiv_refl _⟩
  · rw [← F.row4P_false]
    by_cases h0 : t = 0
    · subst h0; exact ⟨_, F.row4P_mem false 0 x b a hs hx hb ha, F.flip_row4P_0 hs false x a b hx ha hb⟩
    · rw [F.flip_row4P false t x a b ht hx ha hb h0]; exact ⟨_, F.row4P_mem false t x a b ht hx ha hb, Row.equiv_refl _⟩
  · rw [F.flip_row5 hs x hx]; exact ⟨_, F.row5_mem x hx, Row.equiv_refl _⟩

end Flip

/-- **images of the original rows under swap(F,0,1,True) are original rows** -/
theorem portsSwap_rows (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s)
    (hinv : ∀ x, x < F.T → F.b (F.xm 0 1 x) = F.b x) :
    ∀ r ∈ F.rows, ∃ r' ∈ F.rows, (imageRow F.portsSwapId r).equiv r' := by
  intro r hr
  have hσ : ∀ l ∈ r.lits, 1 ≤ F.swapId 0 1 l.natAbs := F.rows_sigma_pos hs 0 1 r hr
  obtain ⟨r1, hr1, h1⟩ := F.image_rows 0 1 (by omega) (by omega) (by omega) hs hinv r hr
  obtain ⟨r2, hr2, h2⟩ := F.flip_rows hs r1 hr1
  refine ⟨r2, hr2, ?_⟩
  unfold portsSwapId
  rw [imageRow_comp F.flipId (F.swapId 0 1) r hσ]
  have hz1 : (imageRow (F.swapId 0 1) r).nz := nz_imageRow _ r hσ
  have hz2 : r1.nz := nz_of_wf r1 F.V (F.rows_wf hs r1 hr1)
  exact Row.equiv_trans (equiv_image F.flipId (fun v hv => F.flipId_pos v hv) _ _ hz1 hz2 h1) h2

theorem portsSwap_unit (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s) (p j : Nat) (hp : p < 2) (hj : j < F.k) :
    imageRow F.portsSwapId (F.unitNegSel p j) = F.unitNegSel (1 - p) (jmap 0 1 j) := by
  unfold portsSwapId
  rw [imageRow_comp F.flipId (F.swapId 0 1) _ (F.unit_sigma_pos 0 1 p j),
    F.image_unitNegSel 0 1 p j hs hp hj]
  unfold imageRow unitNegSel
  simp only [List.map_cons, List.map_nil, Row.mk.injEq, and_true]
  rw [mapLit_neg _ _ (F.sel_pos _ _ _), F.flipId_sel0 hs p _ hp (Fam.jmap_lt 0 1 j F.k (by omega) (by omega) hj)]

/-! ### The two code steps -/

theorem portsSwapId_fn0 (F : Fam) (hs : 1 ≤ F.s) (ab : Nat) (hab : ab < 4) :
    F.portsSwapId (F.fn 0 ab) = F.fn 0 (if ab = 1 then 2 else if ab = 2 then 1 else ab) := by
  unfold portsSwapId
  rw [F.swapId_fn 0 1 0 ab hs hab]
  have h : ab = 0 ∨ ab = 1 ∨ ab = 2 ∨ ab = 3 := by omega
  rcases h with rfl | rfl | rfl | rfl
  · simp; exact F.flipId_fn 0 0 hs (by omega) (by omega)
  · simp; exact F.flipId_fn01
  · simp; exact F.flipId_fn02
  · simp; exact F.flipId_fn 0 3 hs (by omega) (by omega)

theorem row2_lits (F : Fam) (c : Nat) : (F.row2 0 c).lits =
    [if codeBit c 0 then neg (F.fn 0 0) else pos (F.fn 0 0),
     if codeBit c 1 then neg (F.fn 0 1) else pos (F.fn 0 1),
     if codeBit c 2 then neg (F.fn 0 2) else pos (F.fn 0 2),
     if codeBit c 3 then neg (F.fn 0 3) else pos (F.fn 0 3)] := by
  unfold row2
  have hr : List.range 4 = [0, 1, 2, 3] := by decide
  rw [hr]; rfl

/-- the image rows: code 3 ↦ code 5 (fn1, fn2 exchanged), code 12 ↦ code 10 -/
def G3 (F : Fam) : Row := { lits := [pos (F.fn 0 0), pos (F.fn 0 2), neg (F.fn 0 1), neg (F.fn 0 3)], rhs := 1 }
def G12 (F : Fam) : Row := { lits := [neg (F.fn 0 0), neg (F.fn 0 2), pos (F.fn 0 1), pos (F.fn 0 3)], rhs := 1 }

theorem image_row2_3 (F : Fam) (hs : 1 ≤ F.s) : imageRow F.portsSwapId (F.row2 0 3) = F.G3 := by
  unfold imageRow G3
  rw [row2_lits]
  have c0 : codeBit 3 0 = false := by decide
  have c1 : codeBit 3 1 = false := by decide
  have c2 : codeBit 3 2 = true := by decide
  have c3 : codeBit 3 3 = true := by decide
  simp only [c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.map_cons, List.map_nil]
  rw [mapLit_pos _ _ (F.fn_pos _ _), mapLit_pos _ _ (F.fn_pos _ _), mapLit_neg _ _ (F.fn_pos _ _),
    mapLit_neg _ _ (F.fn_pos _ _), F.portsSwapId_fn0 hs 0 (by omega), F.portsSwapId_fn0 hs 1 (by omega),
    F.portsSwapId_fn0 hs 2 (by omega), F.portsSwapId_fn0 hs 3 (by omega)]
  rfl

theorem image_row2_12 (F : Fam) (hs : 1 ≤ F.s) : imageRow F.portsSwapId (F.row2 0 12) = F.G12 := by
  unfold imageRow G12
  rw [row2_lits]
  have c0 : codeBit 12 0 = true := by decide
  have c1 : codeBit 12 1 = true := by decide
  have c2 : codeBit 12 2 = false := by decide
  have c3 : codeBit 12 3 = false := by decide
  simp only [c0, c1, c2, c3, Bool.false_eq_true, ↓reduceIte, List.map_cons, List.map_nil]
  rw [mapLit_neg _ _ (F.fn_pos _ _), mapLit_neg _ _ (F.fn_pos _ _), mapLit_pos _ _ (F.fn_pos _ _),
    mapLit_pos _ _ (F.fn_pos _ _), F.portsSwapId_fn0 hs 0 (by omega), F.portsSwapId_fn0 hs 1 (by omega),
    F.portsSwapId_fn0 hs 2 (by omega), F.portsSwapId_fn0 hs 3 (by omega)]
  rfl

theorem pos_ne_zero (v : Nat) (hv : 1 ≤ v) : pos v ≠ 0 := by unfold pos; omega
theorem neg_ne_zero (v : Nat) (hv : 1 ≤ v) : neg v ≠ 0 := by unfold neg; omega

theorem row2_0_nz (F : Fam) (c : Nat) : (F.row2 0 c).nz := by
  intro l hl
  rw [row2_lits] at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl | rfl | rfl <;> split <;>
    first | exact neg_ne_zero _ (F.fn_pos _ _) | exact pos_ne_zero _ (F.fn_pos _ _)

theorem G3_nz (F : Fam) : F.G3.nz := by
  intro l hl; unfold G3 at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl | rfl | rfl <;>
    first | exact neg_ne_zero _ (F.fn_pos _ _) | exact pos_ne_zero _ (F.fn_pos _ _)

theorem G12_nz (F : Fam) : F.G12.nz := by
  intro l hl; unfold G12 at hl
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with rfl | rfl | rfl | rfl <;>
    first | exact neg_ne_zero _ (F.fn_pos _ _) | exact pos_ne_zero _ (F.fn_pos _ _)

theorem row2_0_sigma_pos (F : Fam) (c : Nat) : ∀ l ∈ (F.row2 0 c).lits, 1 ≤ F.portsSwapId l.natAbs := by
  intro l hl
  exact F.portsSwapId_pos _ (by have := F.row2_0_nz c l hl; omega)

theorem subst_row2_3 (F : Fam) (hs : 1 ≤ F.s) :
    substRow (F.row2 0 3).toE (permWitness F.portsSwapId) = F.G3.toE := by
  rw [substRow_toE _ _ (F.row2_0_nz 3) (F.row2_0_sigma_pos 3), F.image_row2_3 hs]

theorem subst_row2_12 (F : Fam) (hs : 1 ≤ F.s) :
    substRow (F.row2 0 12).toE (permWitness F.portsSwapId) = F.G12.toE := by
  rw [substRow_toE _ _ (F.row2_0_nz 12) (F.row2_0_sigma_pos 12), F.image_row2_12 hs]

/-- the four fn(0,·) literal values -/
theorem cover_aux (F : Fam) (α : Val) (c : Nat) (G : Row) (hG : G.nz) (hc0 hc1 hc2 hc3 : Bool)
    (h0 : codeBit c 0 = hc0) (h1 : codeBit c 1 = hc1) (h2 : codeBit c 2 = hc2) (h3 : codeBit c 3 = hc3) :
    (F.row2 0 c).toE.val α + G.toE.val α
      = (if hc0 then 1 - b2i (α (F.fn 0 0)) else b2i (α (F.fn 0 0)))
        + (if hc1 then 1 - b2i (α (F.fn 0 1)) else b2i (α (F.fn 0 1)))
        + (if hc2 then 1 - b2i (α (F.fn 0 2)) else b2i (α (F.fn 0 2)))
        + (if hc3 then 1 - b2i (α (F.fn 0 3)) else b2i (α (F.fn 0 3))) - 1
        + (lsum α G.lits - G.rhs) := by
  rw [val_toE _ (F.row2_0_nz c), val_toE _ hG, row2_lits]
  have hr : ((F.row2 0 c).rhs : Int) = 1 := rfl
  rw [hr]
  simp only [h0, h1, h2, h3, lsum_cons, lsum_nil]
  cases hc0 <;> cases hc1 <;> cases hc2 <;> cases hc3 <;>
    simp only [Bool.false_eq_true, ↓reduceIte, lv_pos _ _ (F.fn_pos 0 0), lv_pos _ _ (F.fn_pos 0 1),
      lv_pos _ _ (F.fn_pos 0 2), lv_pos _ _ (F.fn_pos 0 3), lv_neg _ _ (F.fn_pos 0 0),
      lv_neg _ _ (F.fn_pos 0 1), lv_neg _ _ (F.fn_pos 0 2), lv_neg _ _ (F.fn_pos 0 3)] <;> omega

theorem lsum_G3 (F : Fam) (α : Val) : lsum α F.G3.lits
    = b2i (α (F.fn 0 0)) + b2i (α (F.fn 0 2)) + (1 - b2i (α (F.fn 0 1))) + (1 - b2i (α (F.fn 0 3))) := by
  unfold G3; simp only [lsum_cons, lsum_nil]
  rw [lv_pos _ _ (F.fn_pos 0 0), lv_pos _ _ (F.fn_pos 0 2), lv_neg _ _ (F.fn_pos 0 1), lv_neg _ _ (F.fn_pos 0 3)]
  omega

theorem lsum_G12 (F : Fam) (α : Val) : lsum α F.G12.lits
    = (1 - b2i (α (F.fn 0 0))) + (1 - b2i (α (F.fn 0 2))) + b2i (α (F.fn 0 1)) + b2i (α (F.fn 0 3)) := by
  unfold G12; simp only [lsum_cons, lsum_nil]
  rw [lv_neg _ _ (F.fn_pos 0 0), lv_neg _ _ (F.fn_pos 0 2), lv_pos _ _ (F.fn_pos 0 1), lv_pos _ _ (F.fn_pos 0 3)]
  omega

theorem cover_3_5 (F : Fam) (α : Val) : -1 ≤ (F.row2 0 3).toE.val α + F.G3.toE.val α := by
  rw [F.cover_aux α 3 F.G3 F.G3_nz false false true true (by decide) (by decide) (by decide) (by decide),
    lsum_G3]
  have := b2i_bounds (α (F.fn 0 0)); have := b2i_bounds (α (F.fn 0 1))
  have := b2i_bounds (α (F.fn 0 2)); have := b2i_bounds (α (F.fn 0 3))
  simp only [Bool.false_eq_true, ↓reduceIte, G3]; omega

theorem cover_12_10 (F : Fam) (α : Val) : -1 ≤ (F.row2 0 12).toE.val α + F.G12.toE.val α := by
  rw [F.cover_aux α 12 F.G12 F.G12_nz true true false false (by decide) (by decide) (by decide) (by decide),
    lsum_G12]
  have := b2i_bounds (α (F.fn 0 0)); have := b2i_bounds (α (F.fn 0 1))
  have := b2i_bounds (α (F.fn 0 2)); have := b2i_bounds (α (F.fn 0 3))
  simp only [Bool.false_eq_true, ↓reduceIte, G12]; omega

theorem cover_12_5 (F : Fam) (α : Val) : -1 ≤ (F.row2 0 12).toE.val α + F.G3.toE.val α := by
  rw [F.cover_aux α 12 F.G3 F.G3_nz true true false false (by decide) (by decide) (by decide) (by decide),
    lsum_G3]
  have := b2i_bounds (α (F.fn 0 0)); have := b2i_bounds (α (F.fn 0 1))
  have := b2i_bounds (α (F.fn 0 2)); have := b2i_bounds (α (F.fn 0 3))
  simp only [Bool.false_eq_true, ↓reduceIte, G3]; omega

/-! ### Databases and memberships -/

def db4 (F : Fam) : List EREF.Row := F.db3 ++ [(F.row2 0 3).toE]
def db5 (F : Fam) : List EREF.Row := F.db4 ++ [(F.row2 0 12).toE]

theorem db3_shape (F : Fam) : ∀ R ∈ F.db3, ∃ r : Row, R = r.toE := by
  intro R hR
  unfold db3 at hR
  rcases List.mem_append.mp hR with hR | hR
  · exact F.db2_shape F.k R hR
  · exact ⟨_, List.mem_singleton.mp hR⟩

theorem db4_shape (F : Fam) : ∀ R ∈ F.db4, ∃ r : Row, R = r.toE := by
  intro R hR
  unfold db4 at hR
  rcases List.mem_append.mp hR with hR | hR
  · exact F.db3_shape R hR
  · exact ⟨_, List.mem_singleton.mp hR⟩

theorem unit0_mem_db2 (F : Fam) (m j : Nat) (hj1 : 1 ≤ j) (hjk : j < F.k) : (F.unitNegSel 0 j).toE ∈ F.db2 m := by
  unfold db2
  exact List.mem_append_left _ (List.mem_append_right _
    (List.mem_map.mpr ⟨j, List.mem_range'_1.mpr ⟨hj1, by omega⟩, rfl⟩))

theorem unit1_mem_db2 (F : Fam) (m j : Nat) (hj2 : 2 ≤ j) (hjm : j < m) : (F.unitNegSel 1 j).toE ∈ F.db2 m := by
  unfold db2
  exact List.mem_append_right _ (List.mem_map.mpr ⟨j, List.mem_range'_1.mpr ⟨hj2, by omega⟩, rfl⟩)

theorem unit10_mem_db3 (F : Fam) : (F.unitNegSel 1 0).toE ∈ F.db3 := by
  unfold db3; exact List.mem_append_right _ (List.mem_singleton.mpr rfl)

theorem db2_sub_db3 (F : Fam) : ∀ R ∈ F.db2 F.k, R ∈ F.db3 := fun R h => List.mem_append_left _ h
theorem db3_sub_db4 (F : Fam) : ∀ R ∈ F.db3, R ∈ F.db4 := fun R h => List.mem_append_left _ h

/-- closure of `db3` under swap(F,0,1,True): every row's image is again in `db3` -/
theorem db3_closed (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s)
    (hinv : ∀ x, x < F.T → F.b (F.xm 0 1 x) = F.b x) :
    ∀ R ∈ F.db3, substRow R (permWitness F.portsSwapId) ∈ F.db3 := by
  intro R hR
  unfold db3 at hR
  rcases List.mem_append.mp hR with hR | hR
  · unfold db2 at hR
    simp only [List.mem_append, List.mem_map, List.mem_range'_1] at hR
    rcases hR with (⟨r, hr, rfl⟩ | ⟨j, hj, rfl⟩) | ⟨j, hj, rfl⟩
    · obtain ⟨r', hr', heq⟩ := F.portsSwap_rows hk hs hinv r hr
      have hσ : ∀ l ∈ r.lits, 1 ≤ F.portsSwapId l.natAbs :=
        fun l hl => F.portsSwapId_pos _ (F.rows_wf hs r hr l hl).1
      rw [substRow_toE _ r (nz_of_wf r F.V (F.rows_wf hs r hr)) hσ,
        toE_of_equiv _ _ (nz_imageRow _ r hσ) (nz_of_wf r' F.V (F.rows_wf hs r' hr')) heq]
      exact F.db2_sub_db3 _ (F.toE_mem_db2 F.k r' hr')
    · -- loop-1 unit ¬sel(0,0,j) ↦ ¬sel(0,1,jmap j)
      rw [substRow_toE _ _ (F.unit_nz 0 j) (fun l hl => F.portsSwapId_pos _ (by
          have := F.unit_nz 0 j l hl; omega)), F.portsSwap_unit hk hs 0 j (by omega) (by omega)]
      by_cases hj1 : j = 1
      · subst hj1; rw [Fam.jmap_b]; exact F.unit10_mem_db3
      · rw [Fam.jmap_other 0 1 j (by omega) hj1]
        exact F.db2_sub_db3 _ (F.unit1_mem_db2 F.k j (by omega) (by omega))
    · -- loop-2 unit ¬sel(0,1,j), j ≥ 2 ↦ ¬sel(0,0,j)
      rw [substRow_toE _ _ (F.unit_nz 1 j) (fun l hl => F.portsSwapId_pos _ (by
          have := F.unit_nz 1 j l hl; omega)), F.portsSwap_unit hk hs 1 j (by omega) (by omega),
        Fam.jmap_other 0 1 j (by omega) (by omega)]
      exact F.db2_sub_db3 _ (F.unit0_mem_db2 F.k j (by omega) (by omega))
  · -- the constant-witness unit ¬sel(0,1,0) ↦ ¬sel(0,0,1)
    rw [List.mem_singleton.mp hR]
    rw [substRow_toE _ _ (F.unit_nz 1 0) (fun l hl => F.portsSwapId_pos _ (by
        have := F.unit_nz 1 0 l hl; omega)), F.portsSwap_unit hk hs 1 0 (by omega) (by omega),
      Fam.jmap_a]
    exact F.db2_sub_db3 _ (F.unit0_mem_db2 F.k 1 (by omega) (by omega))

/-- **Obligation 1(d), first command**: `red [code-3 row of gate 0] ; swap(F,0,1,True)` -/
theorem stepD1 (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s)
    (hinv : ∀ x, x < F.T → F.b (F.xm 0 1 x) = F.b x) : CheckedStep F.db3 F.db4 := by
  unfold db4
  apply checkedStep_red_general F.db3 _ (permWitness F.portsSwapId)
    (canonical_db _ F.db3_shape) (canonical_toE _)
  · intro R hR; exact Or.inl (F.db3_closed hk hs hinv R hR)
  · rw [F.subst_row2_3 hs]
    exact refutation_of_cover _ _ _ (canonical_toE _) (canonical_toE _) F.cover_3_5

/-- **Obligation 1(d), second command**: `red [code-12 row of gate 0] ; swap(F,0,1,True)` -/
theorem stepD2 (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s)
    (hinv : ∀ x, x < F.T → F.b (F.xm 0 1 x) = F.b x) : CheckedStep F.db4 F.db5 := by
  unfold db5
  apply checkedStep_red_general F.db4 _ (permWitness F.portsSwapId)
    (canonical_db _ F.db4_shape) (canonical_toE _)
  · intro R hR
    unfold db4 at hR
    rcases List.mem_append.mp hR with hR | hR
    · exact Or.inl (F.db3_sub_db4 _ (F.db3_closed hk hs hinv R hR))
    · -- the code-3 row: its image (code 5) is covered by ¬C12 + ¬G3
      rw [List.mem_singleton.mp hR, F.subst_row2_3 hs]
      exact Or.inr (refutation_of_cover _ _ _ (canonical_toE _) (canonical_toE _) F.cover_12_5)
  · rw [F.subst_row2_12 hs]
    exact refutation_of_cover _ _ _ (canonical_toE _) (canonical_toE _) F.cover_12_10

/-- **The complete 2k-command prefix of frontend.py** (loops 1 and 2, the constant witness,
    and the two code steps) is a checked trace for every k ≥ 2, s ≥ 1 and swap-invariant target. -/
theorem frontend_prefix_trace (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s)
    (hinv : ∀ a j, a < F.k → j < F.k → a ≠ j → ∀ x, x < F.T → F.b (F.xm a j x) = F.b x) :
    CheckedTrace (F.rows.map Row.toE) F.db5 :=
  checkedTrace_trans (F.prefix_trace_with_const hk hs hinv)
    (CheckedTrace.cons (F.stepD1 hk hs (hinv 0 1 (by omega) (by omega) (by omega)))
      (CheckedTrace.cons (F.stepD2 hk hs (hinv 0 1 (by omega) (by omega) (by omega)))
        (CheckedTrace.refl _)))

end Fam

/-- the emitted family: parity, s = 3k − 4, k ≥ 3: the first 2k frontend commands -/
theorem parity_frontend_prefix_trace (k : Nat) (hk : 3 ≤ k) :
    EREF.GeneralRED.CheckedTrace ((parityFam k (3 * k - 4)).rows.map Row.toE) (parityFam k (3 * k - 4)).db5 :=
  Fam.frontend_prefix_trace _ (by show 2 ≤ k; omega) (by show 1 ≤ 3 * k - 4; omega)
    (fun a j ha hj haj x hx => parityBit_xm (parityFam k (3 * k - 4)) a j x ha hj haj hx)

end L3

#print axioms L3.Fam.stepD1
#print axioms L3.Fam.stepD2
#print axioms L3.parity_frontend_prefix_trace

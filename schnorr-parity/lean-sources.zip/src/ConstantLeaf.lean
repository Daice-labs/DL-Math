import SelectedAlias

namespace L3Emitter.ConstantLeaf
open EREF REDWitness Resolution LocalCombination ClauseTransport CaseJoin ReferenceTransport ChoiceProjection

/-- A fixed POL proof that a selected forcing port makes a gate constant.
All arguments are signed literals, so the same tape proves both directions. -/
def premises (s p q v a b e C : Int) : List Row :=
  [clause [-p,q,-v,a],clause [-p,-q,-v,b],clause [-e,-b,a],
   clause [-s,e],clause [-s,p],clause [-s,p],clause [-s,-a,C],clause [-s,-a,C]]
def padding (v C : Int) : List Int := [-v,C,-v,C,-v,C]
def combined (s p q v a b e C : Int) : Row :=
  chain (chain (clause [-p,q,-v,a]) ((premises s p q v a b e C).tail))
    ((padding v C).map litAxiom)
def tape (D : List Row) (s p q v a b e C : Int) : List Tok :=
  [.ref (locate D (clause [-p,q,-v,a]))] ++
    steps D ((premises s p q v a b e C).tail) ++ padSteps (padding v C) ++ [.div 5]

theorem combined_scaled (s p q v a b e C : Int)
    (hz : Valid [s,p,q,v,a,b,e,C]) :
    combined s p q v a b e C = scaled 5 (clause [-s,-v,C]) := by
  have hs:=hz s (by simp);have hp:=hz p (by simp);have hq:=hz q (by simp)
  have hv:=hz v (by simp);have ha:=hz a (by simp);have hb:=hz b (by simp)
  have he:=hz e (by simp);have hC:=hz C (by simp)
  have hcan : ∀R∈(premises s p q v a b e C).tail,Canonical R := by
    intro R h; simp only [premises,List.tail_cons,List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> exact canonical_normalize _ _
  have hpad : Valid (padding v C) := by simp [padding,Valid,hv,hC]
  apply canonical_ext _ _
    (chain_canonical _ _ (chain_canonical _ _ (canonical_normalize _ _)))
    (canonical_scaled 5 (by decide) _ (canonical_normalize _ _))
  intro α
  change (combined s p q v a b e C).val α = _
  rw [combined,chain_value (chain (clause [-p,q,-v,a]) ((premises s p q v a b e C).tail))
    ((padding v C).map litAxiom) (chain_canonical _ _ (canonical_normalize _ _))
    (by intro R h; obtain ⟨l,hl,rfl⟩:=List.mem_map.mp h;exact canonical_litAxiom _),
    chain_value (clause [-p,q,-v,a]) ((premises s p q v a b e C).tail) (canonical_normalize _ _) hcan,literal_sum _ hpad,val_scaled]
  simp only [premises,List.tail_cons,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil]
  rw [val_clause [-p,q,-v,a] (by simp [Valid,hp,hq,hv,ha]),
    val_clause [-p,-q,-v,b] (by simp [Valid,hp,hq,hv,hb]),
    val_clause [-e,-b,a] (by simp [Valid,he,hb,ha]),
    val_clause [-s,e] (by simp [Valid,hs,he]),
    val_clause [-s,p] (by simp [Valid,hs,hp]),
    val_clause [-s,-a,C] (by simp [Valid,hs,ha,hC])]
  change _ = (5:Int)*(clause [-s,-v,C]).val α+5-1
  rw [val_clause [-s,-v,C] (by simp [Valid,hs,hv,hC])]
  simp only [padding,sum_cons,sum_nil,litVal_neg α p hp,litVal_neg α q hq,
    litVal_neg α a ha,litVal_neg α b hb,litVal_neg α e he]
  ring

theorem succeeds (D : List Row) (s p q v a b e C : Int)
    (hz : Valid [s,p,q,v,a,b,e,C]) (hr : ∀R∈premises s p q v a b e C,R∈D) :
    polEval (dbOf D) (tape D s p q v a b e C) []=some (clause [-s,-v,C]) := by
  have hv:=hz v (by simp);have hC:=hz C (by simp)
  have hfirst:=hr (clause [-p,q,-v,a]) (by simp [premises])
  have htail : ∀R∈(premises s p q v a b e C).tail,R∈D := by
    intro R h;exact hr R (List.mem_of_mem_tail h)
  simp only [tape,List.append_assoc,List.cons_append,List.nil_append,polEval,locate_correct _ _ hfirst]
  rw [steps_eval _ _ htail,padSteps_eval _ _ (by simp [padding,Valid,hv,hC])]
  change some (divide (combined s p q v a b e C) 5)=_
  rw [combined_scaled _ _ _ _ _ _ _ _ hz,divide_scaled 5 (by decide) (clause [-s,-v,C]) (canonical_normalize _ _)]

theorem token_count (D : List Row) (s p q v a b e C : Int) :
    (tape D s p q v a b e C).length=28 := by
  simp [tape,premises,steps,padSteps,padding]

#print axioms succeeds
#print axioms token_count
end L3Emitter.ConstantLeaf

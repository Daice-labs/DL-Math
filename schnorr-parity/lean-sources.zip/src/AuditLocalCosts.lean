import NativeRecordedAllocation
import RecordedReplayCost
import RecordedSelector
namespace L3Emitter.AuditLocalCosts
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation

def certificates : Step→List Certificate
  | .pol _ _ => []
  | .consequence _ p => [p]
  | .red _ _ ps => ps

def localRows (c : Step) : Nat := ((certificates c).map (fun p=>p.program.length)).sum
def localTokens (c : Step) : Nat := ((certificates c).map RecordedReplayCost.tokens).sum
def allCertificates (p : Program) : List Certificate := p.flatMap certificates
/-- Enumerates every local certificate, including all RED frame goals. -/
def allLocalPrograms (p : Program) : AliasProgram.Program :=
  (allCertificates p).flatMap (fun c=>c.program)
def certCount (p : Program) := (allCertificates p).length
def localRowCount (p : Program) := (allLocalPrograms p).length
def localTokenCount (p : Program) := ((allLocalPrograms p).map (fun c=>c.2.length)).sum

def redCount (p : Program) : Nat := (p.map (fun c=>match c with | .red _ _ _=>1 | _=>0)).sum

theorem certs_cons (c : Step) (p : Program) : certCount (c::p)=(certificates c).length+certCount p := by
  simp [certCount,allCertificates]
theorem rows_cons (c : Step) (p : Program) : localRowCount (c::p)=localRows c+localRowCount p := by
  simp [localRowCount,allLocalPrograms,allCertificates,localRows,List.length_flatMap]
theorem flat_tokens (ps : List Certificate) :
    ((ps.flatMap (fun p=>p.program)).map (fun c=>c.2.length)).sum =
    (ps.map RecordedReplayCost.tokens).sum := by
  induction ps with
  | nil=>rfl
  | cons p ps ih=>simp [RecordedReplayCost.tokens,ih]

theorem tokens_cons (c : Step) (p : Program) : localTokenCount (c::p)=localTokens c+localTokenCount p := by
  simp [localTokenCount,allLocalPrograms,allCertificates,localTokens,flat_tokens]

/-- Physical allocation counts every main row, every local negation/POL row,
and the additional outer negation of each RED. Nothing is excluded as auxiliary. -/
theorem allocations (p : Program) : NativeRecordedAllocation.program p =
    p.length+certCount p+localRowCount p+redCount p := by
  induction p with
  | nil=>rfl
  | cons c p ih=>
    rw [certs_cons,rows_cons]
    cases c <;> simp_all [NativeRecordedAllocation.program,NativeRecordedAllocation.step,
      NativeRecordedAllocation.goals,certificates,localRows,redCount,List.sum_map_add,
      Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] <;> omega

def triangle : Nat→Nat | 0=>0 | m+1=>triangle m+m

def IsRED : Step→Prop | .red _ _ _=>True | _=>False

theorem goals_length (D : List Row) (C : Row) (w : FiniteWitness.Data)
    (rs : List Row) (ps : List Certificate) (h : checkGoals D C w rs ps=true) :
    ps.length=rs.length := by
  induction rs generalizing ps with
  | nil=>cases ps <;> simp_all [checkGoals]
  | cons R rs ih=>
    cases ps with
    | nil=>simp [checkGoals] at h
    | cons p ps=>exact congrArg (·+1) (ih ps (Bool.and_eq_true_iff.mp h).2)

theorem red_cert_count (M guard : Nat) (D E : List Row) (p : Program)
    (hp : check M guard D p=some E) (hr : ∀ c∈p,IsRED c) :
    certCount p=p.length*(D.length+1)+triangle p.length := by
  induction p generalizing D with
  | nil=>simp [certCount,allCertificates,triangle]
  | cons c p ih=>
    have hc:=hr c (by simp)
    cases c with
    | pol R ts=>exact False.elim hc
    | consequence R q=>exact False.elim hc
    | red R w ps=>
      simp only [check] at hp
      split at hp
      · rename_i hs
        have hg:=goals_length D R w (R::D) ps (Bool.and_eq_true_iff.mp hs).2
        have ht:=ih (D++[R]) hp (by intro c h;exact hr c (by simp [h]))
        rw [certs_cons,ht]
        simp only [certificates,hg,List.length_cons,List.length_append,List.length_singleton,List.length_nil,triangle]
        ring
      · contradiction

/-- First selector RED has one POL row in every local certificate. -/
theorem first_selector_rows (D : List Row) (k s a j p : Nat) :
    localRows (RecordedSelector.step D k s a j p)=D.length+1 := by
  simp [localRows,certificates,RecordedSelector.step,RecordedSelector.goals,
    RecordedSelector.candidate,RecordedLocal.old,RecordedLocal.fromTape,Function.comp_def,Nat.add_comm]

theorem first_selector_certificates (D : List Row) (k s a j p : Nat) :
    (certificates (RecordedSelector.step D k s a j p)).length=D.length+1 := by
  simp [certificates,RecordedSelector.step,RecordedSelector.goals]

theorem first_selector_allocations (D : List Row) (k s a j p : Nat) :
    NativeRecordedAllocation.step (RecordedSelector.step D k s a j p)=2*D.length+4 := by
  simp [NativeRecordedAllocation.step,NativeRecordedAllocation.goals,RecordedSelector.step,
    RecordedSelector.goals,RecordedSelector.candidate,RecordedLocal.old,RecordedLocal.fromTape,Function.comp_def]
  omega

#print axioms allocations
#print axioms red_cert_count
#print axioms first_selector_rows
#print axioms first_selector_allocations
end L3Emitter.AuditLocalCosts

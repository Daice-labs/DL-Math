import ConstructionGlobalCount
set_option maxRecDepth 2000
set_option maxHeartbeats 800000

namespace L3Emitter.ConstructionCoordinateCount
open EREF EREF.GeneralRED ConstructionCountTools ConstructionRelationCount

theorem coordinate (cs : List Int) (f : Int→Nat→Int) (D : List Row) (i m : Nat) :
    (RecordedCoordinateBank.program cs f D i m).length=m*(6*cs.length+1) := by
  induction m generalizing D i with
  | zero=>simp [RecordedCoordinateBank.program]
  | succ m ih=>
    simp only [RecordedCoordinateBank.program,List.length_append,RecordedCoordinateBank.blockProgram,
      ConstructionTransportCount.support_selection,ih]
    ring

theorem choices (n : Nat) (hn : 2≤n) (t : Nat) :
    (RankPortSelection.cs n hn t).length=3*(n+1)-5 := by
  exact RawBankSize.choices_length n hn t

theorem rank_block (n : Nat) (hn : 2≤n) (j : RankPortBank.Job) (D : List Row) :
    (RecordedRankPorts.blockProgram n hn j D).length≤300*(n+1)^3 := by
  have hd:(RecordedRankPorts.definitionProgram n hn j D).length=
      (AliasAssembly.width (n+1)+2)*(6*(3*(n+1)-5)+1):=by
    rw [RecordedRankPorts.definitionProgram,coordinate,choices]
  have hp:=ConstructionOneHotCount.selected (RankPortSelection.built n hn j.1 j.2 D).1
    (RankPortSelection.choices n hn j.1) (fun c=>RankPortSelection.inputs n hn j.2 c.val)
    (RankPortSelection.target n hn j.1 j.2 D)
  have hc:(RankPortSelection.choices n hn j.1).length=3*(n+1)-5:=by
    simp only [RankPortSelection.choices,List.length_map,List.length_attach,choices]
  rw [hc] at hp
  have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  have hs:3*(n+1)-5≤3*(n+1):=Nat.sub_le ..
  have hsq:=Nat.pow_le_pow_left hw 2
  have hm:=Nat.mul_le_mul (Nat.add_le_add_right hw 2) (show 6*(3*(n+1)-5)+1≤19*(n+1) by omega)
  have hm2:=Nat.mul_le_mul (Nat.add_le_add_left hsq 1) (Nat.add_le_add_right hs 1)
  simp only [RecordedRankPorts.blockProgram,List.length_append,hd,polProgram_length]
  change _+(SelectedVectorOneHot.program _ _ _ _).length≤_
  nlinarith [Nat.zero_le (n^3)]

theorem rank_run (n : Nat) (hn : 2≤n) (js : List RankPortBank.Job) (D : List Row) :
    (RecordedRankPorts.runProgram n hn D js).length≤js.length*(300*(n+1)^3) := by
  induction js generalizing D with
  | nil=>simp [RecordedRankPorts.runProgram]
  | cons j js ih=>
    simp only [RecordedRankPorts.runProgram,List.length_append,List.length_cons]
    exact (Nat.add_le_add (rank_block n hn j D) (ih _)).trans_eq (by ring)

theorem rank (n : Nat) (hn : 2≤n) :
    (RecordedRankPorts.program n hn).length≤1800*(n+1)^4 := by
  have h:=rank_run n hn (RankPortBank.jobs n) (GlobalPortValues.result n hn)
  have hj:(RankPortBank.jobs n).length=RankConstruction.width (n+1)*2:=by
    unfold RankPortBank.jobs
    rw [flat_exact _ _ 2 (by intro t ht;rfl),List.length_range]
  rw [hj] at h
  have hw:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  exact h.trans (by nlinarith [Nat.mul_le_mul_right (600*(n+1)^3) hw])

theorem raw_run (n : Nat) (hn : 2≤n) (rs : List (RawLowerInputBank.Port n)) (D : List Row) :
    (RecordedRawLowerInputs.runProgram n hn D rs).length=
      rs.length*2^n*(6*AliasAssembly.width (n+1)+1) := by
  induction rs generalizing D with
  | nil=>simp [RecordedRawLowerInputs.runProgram]
  | cons r rs ih=>
    simp only [RecordedRawLowerInputs.runProgram,List.length_append,RecordedRawLowerInputs.blockProgram,
      coordinate,SelectedVectorOneHot.sourceLiterals,List.length_ofFn,FamilyNamespace.truthRows,ih,List.length_cons]
    ring

theorem raw (n : Nat) (hn : 2≤n) :
    (RecordedRawLowerInputs.program n hn).length≤150*(n+1)^2*2^n := by
  rw [RecordedRawLowerInputs.program,raw_run,RawInputSize.evaluated_port_count]
  have hr:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hw:6*AliasAssembly.width (n+1)+1≤25*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  have hp:=Nat.mul_le_mul (Nat.mul_le_mul_left 2 hr) hw
  nlinarith [Nat.mul_le_mul_right (2^n) hp]

theorem table_run (n : Nat) (hn : 2≤n) (ts : List Nat) (D : List Row) :
    (RecordedRankTables.runProgram n hn D ts).length=ts.length*4*(6*(3*(n+1)-5)+1) := by
  induction ts generalizing D with
  | nil=>simp [RecordedRankTables.runProgram]
  | cons t ts ih=>
    simp only [RecordedRankTables.runProgram,List.length_append,RecordedRankTables.blockProgram,
      coordinate,choices,ih,List.length_cons]
    ring

theorem table (n : Nat) (hn : 2≤n) :
    (RecordedRankTables.program n hn).length≤228*(n+1)^2 := by
  rw [RecordedRankTables.program,table_run,List.length_range]
  have hr:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hc:6*(3*(n+1)-5)+1≤19*(n+1):=by omega
  nlinarith [Nat.mul_le_mul hr hc]

#print axioms coordinate
#print axioms rank
#print axioms raw
#print axioms table
end L3Emitter.ConstructionCoordinateCount

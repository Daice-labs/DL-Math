import ConstructionTopologyCount
import ConstructionRankOrderCount
import ConstructionLowerEvaluationCount
namespace L3Emitter.ConstructionLowerCount
open EREF EREF.GeneralRED ConstructionCountTools
/-- A common scale for one complete reduction level. -/
def Q (n : Nat) := (n+2)^6*2^n

theorem lift_power (n C a : Nat) (ha : a≤6) : C*(n+1)^a*2^n≤C*Q n := by
  have h:(n+1)^a≤(n+2)^6:=(Nat.pow_le_pow_left (by omega) a).trans (Nat.pow_le_pow_right (by omega) ha)
  exact (Nat.mul_le_mul_right (2^n) (Nat.mul_le_mul_left C h)).trans_eq (by unfold Q;ring)
theorem lift_plain (n C a : Nat) (ha : a≤6) : C*(n+1)^a≤C*Q n := by
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  exact (show C*(n+1)^a≤C*(n+1)^a*2^n by simpa only [Nat.mul_one] using Nat.mul_le_mul_left (C*(n+1)^a) ht).trans (lift_power n C a ha)

theorem complete (n : Nat) (hn : 2≤n) : (RecordedLowerRows.program n hn).length≤8000*Q n := by
  have h0: (RankOrderExclusion.emitted n hn).length≤1539*Q n:=
    (ConstructionRankOrderCount.complete n hn).trans (lift_plain n 1539 6 (by omega))
  have h1:= (ConstructionLowerBasicCount.primary n hn).trans (lift_power n 6 2 (by omega))
  have h2:= (ConstructionLowerBasicCount.amo n hn).trans (lift_plain n 24 2 (by omega))
  have h3:= (ConstructionTopologyCount.complete n hn).trans (lift_plain n 4050 5 (by omega))
  have h4:= (ConstructionLowerBasicCount.zero n hn).trans (lift_plain n 72 3 (by omega))
  have h5: (LowerSelectorALO.program n hn).length≤6*Q n:=
    (ConstructionLowerBasicCount.alo n hn).trans (by simpa using lift_plain n 6 1 (by omega))
  have h6: (ComposedU2Bank.program n hn).length≤858*Q n:=
    (ConstructionLowerEvaluationCount.composed n hn).trans (by simpa using lift_plain n 858 1 (by omega))
  have h7:= (ConstructionLowerEvaluationCount.u2 n hn).trans (lift_plain n 24 2 (by omega))
  have h8:= (ConstructionLowerEvaluationCount.ports n hn).trans (lift_power n 72 2 (by omega))
  have h9:= (ConstructionLowerEvaluationCount.evaluation n hn).trans (lift_power n 888 2 (by omega))
  have h10: (OutputPhaseBank.program n hn).length≤16*Q n:=
    (ConstructionLowerEvaluationCount.phase n hn).trans (by simpa using lift_power n 16 1 (by omega))
  simp only [RecordedLowerRows.program,RecordedLowerRows.p10,RecordedLowerRows.p9,
    RecordedLowerRows.p8,RecordedLowerRows.p7,RecordedLowerRows.p6,RecordedLowerRows.p5,
    RecordedLowerRows.p4,RecordedLowerRows.p3,RecordedLowerRows.p2,RecordedLowerRows.p1,
    RecordedLowerRows.p0,List.length_append,polProgram_length]
  omega
#print axioms complete
end L3Emitter.ConstructionLowerCount

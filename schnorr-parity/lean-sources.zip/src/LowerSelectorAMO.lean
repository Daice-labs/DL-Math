import LowerTransferImage
namespace L3Emitter.LowerSelectorAMO
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram FamilyRows FamilyNamespace

def xs (n:Nat) (hn:2≤n) (t p:Nat):List Int:=
  List.ofFn fun i:Fin (n+t)=>(LowerTransferImage.wire n hn (.sel t p i.val)).val

theorem pairs (n:Nat) (hn:2≤n) (t p:Nat) (ht:t<RankConstruction.width (n+1)) (hp:p<2):
    (xs n hn t p).Pairwise (fun a b=>Cardinality.pair a b∈RawPrimaryTransferBank.result n hn):=by
  obtain ⟨r,he,heq⟩:=LowerTransferImage.port_exists n hn t p ht hp
  have hv:=RawUnaryBank.port_present n hn r.val r.property
  have hs:=RawLowerInputBank.port_present n hn r.val.1 hv
  have pair:=((RankPortBank.original_to_rank_port_bank n hn).2 r.val.1.1 hs).1.2
  apply List.pairwise_ofFn.mpr
  intro i j hij
  have hi:i.val<AliasAssembly.width (n+1):=by have:=i.isLt;unfold AliasAssembly.width;omega
  have hj:j.val<AliasAssembly.width (n+1):=by have:=j.isLt;unfold AliasAssembly.width;omega
  have hh:=pair ⟨i.val,hi⟩ ⟨j.val,hj⟩ hij
  simp only [LowerTransferImage.wire,he,dif_pos hi,dif_pos hj]
  apply List.mem_append_left
  apply RawPrimaryTransferBank.raw_retained
  apply RawLowerInputBank.run_retains
  exact RawLowerInputBank.base_retains n hn _ hh

theorem valid (n:Nat) (hn:2≤n) (t p:Nat):REDWitness.Valid (xs n hn t p):=by
  intro c hc;obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hc
  exact (LowerTransferImage.wire n hn (.sel t p i.val)).property

theorem image_eq (n:Nat) (hn:2≤n) (t p:Nat):
    LowerTransferImage.image n hn (InputSwap.oneHot n t p false)=Cardinality.amo (xs n hn t p):=by
  simp only [LowerTransferImage.image,InputSwap.oneHot,Bool.false_eq_true,↓reduceIte,
    List.map_map,GuardedGatePOL.sign,Cardinality.amo,xs,List.length_ofFn]
  congr 1
  apply List.ext_getElem
  · simp
  · intro i hi hj
    simp

def jobs (n:Nat):=RankPortBank.jobs n
def rows (n:Nat) (hn:2≤n) (j:RankPortBank.Job):=OneHotPOL.rows (xs n hn j.1 j.2)
def leaf (n:Nat) (hn:2≤n) (j:RankPortBank.Job) (D:List Row):=OneHotPOL.program D (xs n hn j.1 j.2)

theorem leaf_check (n:Nat) (hn:2≤n) (j:RankPortBank.Job) (hj:RankPortBank.ValidJob n j)
    (D:List Row) (hk:∀R∈RawPrimaryTransferBank.result n hn,R∈D):
    check D (leaf n hn j D)=some (D++rows n hn j):=by
  apply OneHotPOL.checks D _ (valid n hn j.1 j.2)
  exact (pairs n hn j.1 j.2 hj.1 hj.2).imp (fun h=>hk _ h)

def program (n:Nat) (hn:2≤n):=
  RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n) (RawPrimaryTransferBank.result n hn)
def result (n:Nat) (hn:2≤n):=
  RawPrimaryTransferBank.result n hn++RetainedBlockFold.body (rows n hn) (jobs n)

theorem checks (n:Nat) (hn:2≤n):
    check (RawPrimaryTransferBank.result n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (RankPortBank.ValidJob n) (leaf_check n hn) _
    (fun j hj=>(RankPortBank.job_mem n j).mp hj) _ (fun _ h=>h)

theorem original_to_selector_AMO (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (RawPrimaryTransferBank.original_to_primary_transfers n hn)
    (check_trace _ _ _ (checks n hn))

theorem all_AMO_images (n:Nat) (hn:2≤n) (t p:Nat) (ht:t<3*n-4) (hp:p<2):
    LowerTransferImage.image n hn (InputSwap.oneHot n t p false)∈result n hn:=by
  rw [image_eq]
  apply List.mem_append_right
  apply RetainedBlockFold.contains (rows n hn) (jobs n) (t,p)
    ((RankPortBank.job_mem n _).mpr ⟨by unfold RankConstruction.width;omega,hp⟩)
  apply OneHotPOL.final_mem
  intro h;have:=congrArg List.length h;simp [xs] at this;omega

#print axioms image_eq
#print axioms original_to_selector_AMO
#print axioms all_AMO_images
end L3Emitter.LowerSelectorAMO

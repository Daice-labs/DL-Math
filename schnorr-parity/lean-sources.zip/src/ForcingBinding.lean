import ForcingDefinitions

namespace L3Emitter.ForcingBinding
open EREF EREF.GeneralRED REDWitness RankProjection
open ForcingDefinitions ForcingPOL

theorem rotate3 (a b c : Int) (ha : a≠0) (hb : b≠0) (hc : c≠0) :
    clause [a,b,c]=clause [c,a,b] := by
  simpa using FrontendSelection.rotate_clause c [a,b] hc (by
    intro l hl; simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl <;> assumption)

def port (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (p m : Nat) : Port :=
  let F:=FableEncoding.fam k (3*k-4)
  let t:=FrontendSelection.front k hk
  ⟨c.lit,(t.s.p0force c.beta p:Int),(F.sel c.beta p 0:Int),
    (t.s.force c.beta p:Int),(t.s.eqrow c.beta p 0:Int),(t.s.eqrow c.beta p 1:Int),
    (m+1:Int),(m+2:Int)⟩

def input (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) : Input :=
  let F:=FableEncoding.fam k (3*k-4)
  let t:=FrontendSelection.front k hk
  ⟨c.lit,(F.sel c.beta 0 0:Int),(F.sel c.beta 1 0:Int),
    (t.s.eqrow c.beta 0 0:Int),(t.s.eqrow c.beta 0 1:Int),
    (t.s.eqrow c.beta 1 0:Int),(t.s.eqrow c.beta 1 1:Int)⟩

theorem port_old (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (p m : Nat) (hp : p<2) :
    (port k hk c p m).valid ∧
    (port k hk c p m).r∈FrontendSelection.finalRows k hk ∧
    clause [-(port k hk c p m).p,(port k hk c p m).force]∈FrontendSelection.finalRows k hk ∧
    clause [-(port k hk c p m).force,(port k hk c p m).e0,(port k hk c p m).e1]∈FrontendSelection.finalRows k hk := by
  let F:=FableEncoding.fam k (3*k-4)
  let t:=FrontendSelection.front k hk
  have hg:= (F.final_branch_ready (FrontendSelection.prior k hk)
    (FrontendSelection.prior_good k hk)).1
  change F.Good3 t at hg
  obtain ⟨he0,he1,hforce,hp0⟩:=hg.2.2.1 c.beta p
    (by have:=c.beta_pos;omega) (by change c.beta<3*k-4;have:=c.ordered;have:=c.gamma_lt;omega) hp
  have hs:=F.sel_pos c.beta p 0
  have h0 : F.V<t.s.eqrow c.beta p 0 := he0.2.1
  have h1 : F.V<t.s.eqrow c.beta p 1 := he1.2.1
  have hf : F.V<t.s.force c.beta p := hforce.2.1
  have hpf : F.V<t.s.p0force c.beta p := hp0.2.1
  constructor
  · change Valid [c.lit,(t.s.p0force c.beta p:Int),(F.sel c.beta p 0:Int),
      (t.s.force c.beta p:Int),(t.s.eqrow c.beta p 0:Int),(t.s.eqrow c.beta p 1:Int),
      (m+1:Int),(m+2:Int)]
    intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> try omega
    exact c.nonzero
  have hsel:=L3.andDef_row_down F.db5 t.s.cmds _ _ hp0.1 (F.sel c.beta p 0:Int) (by simp)
  have hfor:=L3.andDef_row_down F.db5 t.s.cmds _ _ hp0.1 (t.s.force c.beta p:Int) (by simp)
  have heq:=L3.orDef_row_down F.db5 t.s.cmds _ _ hforce.1
  change clause [(F.sel c.beta p 0:Int),-(t.s.p0force c.beta p:Int)]∈FrontendSelection.db k hk at hsel
  change clause [(t.s.force c.beta p:Int),-(t.s.p0force c.beta p:Int)]∈FrontendSelection.db k hk at hfor
  change clause [(t.s.eqrow c.beta p 0:Int),(t.s.eqrow c.beta p 1:Int),-(t.s.force c.beta p:Int)]∈FrontendSelection.db k hk at heq
  rw [PriorityExclusive.clause_swap _ _ (by omega) (by omega)] at hsel hfor
  rw [rotate3 _ _ _ (by omega) (by omega) (by omega)] at heq
  exact ⟨SelectedBranch.retained k hk _ hsel, SelectedBranch.retained k hk _ hfor,
    SelectedBranch.retained k hk _ heq⟩

def eligible (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) : Int :=
  ((FrontendSelection.front k hk).s.eligible c.beta:Int)
def consumer (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) : Int :=
  (ConsumerLookup.consumer (FableEncoding.fam k (3*k-4)) (FrontendSelection.front k hk) c.beta:Int)

theorem consumer_rows (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) :
    eligible k hk c≠0 ∧ consumer k hk c≠0 ∧
    clause [-eligible k hk c,consumer k hk c]∈FrontendSelection.finalRows k hk ∧
    clause [-consumer k hk c,(port k hk c 0 0).p,(port k hk c 1 0).p]∈FrontendSelection.finalRows k hk := by
  let F:=FableEncoding.fam k (3*k-4)
  let t:=FrontendSelection.front k hk
  have hg:= (F.final_branch_ready (FrontendSelection.prior k hk)
    (FrontendSelection.prior_good k hk)).1
  change F.Good3 t at hg
  obtain ⟨q,hq,he,hqp,hep,heu⟩:=hg.2.2.2.1 c.beta
    (by have:=c.beta_pos;omega) (by change c.beta<3*k-4;have:=c.ordered;have:=c.gamma_lt;omega)
  obtain ⟨hco,hel,hcp⟩ := ConsumerLookup.frontend_consumer k hk c
  have hE : eligible k hk c≠0 := by change (t.s.eligible c.beta:Int)≠0;omega
  have hC : consumer k hk c≠0 := by change F.V<ConsumerLookup.consumer F t c.beta at hcp; change (ConsumerLookup.consumer F t c.beta:Int)≠0;omega
  have h0:=(port_old k hk c 0 0 (by decide)).1
  have h1:=(port_old k hk c 1 0 (by decide)).1
  have hp0 : (port k hk c 0 0).p≠0 := h0 _ (by simp)
  have hp1 : (port k hk c 1 0).p≠0 := h1 _ (by simp)
  have hrow:=L3.andDef_row_down F.db5 t.s.cmds _ _ hel (consumer k hk c) (by simp [consumer])
  have hcons:=L3.orDef_row_down F.db5 t.s.cmds _ _ hco
  change clause [consumer k hk c,-eligible k hk c]∈FrontendSelection.db k hk at hrow
  change clause [(port k hk c 0 0).p,(port k hk c 1 0).p,-consumer k hk c]∈FrontendSelection.db k hk at hcons
  rw [PriorityExclusive.clause_swap _ _ hC (by omega)] at hrow
  rw [rotate3 _ _ _ hp0 hp1 (by omega)] at hcons
  exact ⟨hE,hC,SelectedBranch.retained k hk _ hrow,SelectedBranch.retained k hk _ hcons⟩

#print axioms port_old
#print axioms consumer_rows
end L3Emitter.ForcingBinding

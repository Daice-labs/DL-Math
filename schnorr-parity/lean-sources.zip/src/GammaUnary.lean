import RawValueBank

namespace L3Emitter.GammaUnary
open EREF EREF.GeneralRED REDWitness ReferenceTransport CofactorSemantics

/-- Actual forcing choice, receiving port, forcing-input bit, other bit,
output-table bit. All three bit cases are emitted explicitly. -/
abbrev Job (n : Nat) := GammaConstant.Job n × Bool × Bool

def jobs (n : Nat) (hn : 2≤n) : List (Job n) :=
  (GammaConstant.jobs n hn).flatMap fun j=>[false,true].flatMap fun b=>[false,true].map fun v=>(j,b,v)

def a {n : Nat} (j : Job n) := !j.1.2.2.2
def other {n : Nat} (j : Job n) := j.2.1
def positive {n : Nat} (j : Job n) := j.2.2

def sem (n : Nat) (hn : 2≤n) (j : Job n) :=
  goal n (3*(n+1)-4) (ConstantCofactor.offset n hn) j.1.2.1 j.1.1.2
    (if j.1.2.2.1=0 then a j else other j) (if j.1.2.2.1=0 then other j else a j) (positive j)
def wire (n : Nat) (hn : 2≤n) (j : Job n) :=
  output (low n (ConstantCofactor.offset n hn) j.1.2.1 j.1.2.2.1 j.1.1.2) (a j)
def otherWire (n : Nat) (hn : 2≤n) (j : Job n) :=
  output (low n (ConstantCofactor.offset n hn) j.1.2.1 (1-j.1.2.2.1) j.1.1.2) (!(other j))
def outWire (n : Nat) (hn : 2≤n) (j : Job n) :=
  output (low n (ConstantCofactor.offset n hn) j.1.2.1 2 j.1.1.2) (!(positive j))
def fn (n : Nat) (j : Job n) :=
  fnLiteral n (3*(n+1)-4) j.1.2.1
    (if j.1.2.2.1=0 then a j else other j) (if j.1.2.2.1=0 then other j else a j) (positive j)
def row (n : Nat) (hn : 2≤n) (j : Job n) :=
  clause [-GammaConstant.c j.1,-GammaConstant.e n j.1,
    BetaValue.C n hn (GammaConstant.betaJob j.1),otherWire n hn j,outWire n hn j,fn n j]

def base (n : Nat) (hn : 2≤n) := (RawValueBank.result n hn).1

theorem retains (n : Nat) (hn : 2≤n) (R:Row) (hR:R∈GammaConstant.result n hn) : R∈base n hn :=
  RawValueBank.run_retains n hn _ _ R (List.mem_append_left _ (List.mem_append_left _ hR))

def tape (n : Nat) (hn : 2≤n) (j : Job n) : List Tok :=
  [.ref (locate (base n hn) (GammaConstant.row n hn j.1)),.ref (locate (base n hn) (sem n hn j)),.add]

theorem resolve (c e w C q v f : Int)
    (hz:REDWitness.Valid [c,e,w,C,q,v,f]) :
    add (clause [-c,-e,w,C]) (clause [-w,q,v,f])=clause [-c,-e,C,q,v,f] := by
  have hc:=hz c (by simp);have he:=hz e (by simp);have hw:=hz w (by simp)
  have hC:=hz C (by simp);have hq:=hz q (by simp);have hv:=hz v (by simp);have hf:=hz f (by simp)
  apply canonical_ext _ _ (canonical_add _ _) (canonical_normalize _ _)
  intro α
  change (add (clause [-c,-e,w,C]) (clause [-w,q,v,f])).val α=(clause [-c,-e,C,q,v,f]).val α
  rw [val_add (clause [-c,-e,w,C]) (clause [-w,q,v,f]) (canonical_normalize _ _) (canonical_normalize _ _),
    val_clause [-c,-e,w,C] (by simp [REDWitness.Valid,hc,he,hw,hC]),
    val_clause [-w,q,v,f] (by simp [REDWitness.Valid,hw,hq,hv,hf]),
    val_clause [-c,-e,C,q,v,f] (by simp [REDWitness.Valid,hc,he,hC,hq,hv,hf])]
  simp only [sum_cons,sum_nil,litVal_neg α w hw];ring

theorem succeeds (n : Nat) (hn : 2≤n) (j : Job n) (hj:j.1∈GammaConstant.jobs n hn) :
    polEval (dbOf (base n hn)) (tape n hn j) []=some (row n hn j) := by
  have h:=(GammaConstant.job_mem n hn j.1).mp hj
  have hb:=BetaPort.valid_job n hn j.1.1 h.1
  have hc : GammaConstant.c j.1≠0 := by
    have := RestrictionBit.choice_above _ _ j.1.1.1.1 hb.1
    unfold GammaConstant.c;omega
  have he : GammaConstant.e n j.1≠0 := by
    have := (FamilyNamespace.encode_bounds (n+1) (3*(n+1)-4)
      (.sel j.1.2.1 j.1.2.2.1 (n+1+j.1.1.1.2.parent.beta)) ⟨h.2.1,h.2.2.2,by omega⟩).1
    unfold GammaConstant.e WireCofactor.selector;omega
  have hw : wire n hn j≠0 := output_nonzero _ (low_pos ..) _
  have hC : BetaValue.C n hn (GammaConstant.betaJob j.1)≠0 :=
    output_nonzero _ (by unfold ConstantConstruction.C;omega) _
  have hq : otherWire n hn j≠0 := output_nonzero _ (low_pos ..) _
  have hv : outWire n hn j≠0 := output_nonzero _ (low_pos ..) _
  have hf : fn n j≠0 := by
    unfold fn fnLiteral
    apply output_nonzero
    apply (FamilyNamespace.encode_bounds (n+1) (3*(n+1)-4) (.fn j.1.2.1 _) ⟨h.2.1,?_⟩).1
    have ha:=Bool.toNat_le (if j.1.2.2.1=0 then a j else other j)
    have hb:=Bool.toNat_le (if j.1.2.2.1=0 then other j else a j)
    omega
  have hr : GammaConstant.row n hn j.1∈base n hn := retains n hn _
    (List.mem_append_right _ (List.mem_map.mpr ⟨j.1,hj,rfl⟩))
  have hs : sem n hn j∈base n hn := by
    apply retains
    apply List.mem_append_left
    apply List.mem_append_left
    apply List.mem_append_left
    apply List.mem_append_left
    exact BetaValue.semantics_present n hn j.1.2.1 j.1.1.2 h.2.1 hb.2.2.2 _ _ _
  have hr' : GammaConstant.row n hn j.1=clause [-GammaConstant.c j.1,-GammaConstant.e n j.1,
      wire n hn j,BetaValue.C n hn (GammaConstant.betaJob j.1)] := by
    cases ht:j.1.2.2.2 <;> simp [GammaConstant.row,GammaConstant.p,wire,a,ht,output]
  have hs' : sem n hn j=clause [-wire n hn j,otherWire n hn j,outWire n hn j,fn n j] := by
    have hp : j.1.2.2.1=0 ∨ j.1.2.2.1=1 := by omega
    rcases hp with hp|hp
    · cases ha:a j <;> simp [sem,goal,wire,otherWire,outWire,fn,hp,ha,output]
    · have perm : clause [otherWire n hn j,-wire n hn j,outWire n hn j,fn n j]=
          clause [-wire n hn j,otherWire n hn j,outWire n hn j,fn n j] :=
        ProjectionTrace.clause_perm _ _ (by simp [REDWitness.Valid,hq,hw,hv,hf])
          (by simp [REDWitness.Valid,hq,hw,hv,hf]) (List.Perm.swap ..)
      convert perm using 1
      cases ha:a j <;> simp [sem,goal,wire,otherWire,outWire,fn,hp,ha,output]
  simp only [tape,polEval,locate_correct _ _ hr,locate_correct _ _ hs]
  rw [hr',hs']
  exact congrArg some (resolve _ _ _ _ _ _ _ (by simp [REDWitness.Valid,hc,he,hw,hC,hq,hv,hf]))

def program (n : Nat) (hn : 2≤n) : AliasProgram.Program := (jobs n hn).map fun j=>(row n hn j,tape n hn j)
def result (n : Nat) (hn : 2≤n) := base n hn++(jobs n hn).map (row n hn)

theorem program_check (n : Nat) (hn : 2≤n) :
    AliasProgram.check (base n hn) (program n hn)=some (result n hn) := by
  have h:=IndependentProgram.check_base (base n hn) (program n hn) (by
    intro c hc;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    apply succeeds n hn j
    obtain ⟨jj,hjj,hh⟩:=List.mem_flatMap.mp hj
    obtain ⟨b,hb,hh⟩:=List.mem_flatMap.mp hh
    obtain ⟨v,hv,rfl⟩:=List.mem_map.mp hh
    exact hjj)
  simpa [program,result,AliasProgram.outputs,List.map_map] using h

theorem original_to_gamma_unary (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (RawValueBank.original_to_raw_bank n hn).1
    (AliasProgram.check_trace _ _ _ (program_check n hn))

#print axioms succeeds
#print axioms original_to_gamma_unary
end L3Emitter.GammaUnary

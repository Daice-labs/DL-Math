import CofactorValueRows

namespace L3Emitter.BetaAliasValue
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL CofactorValueRows
abbrev Job (n:Nat):=BetaPort.Job n

def choice {n:Nat} (j:Job n):Int:=j.1.1.choice
def gate {n:Nat} (j:Job n):Nat:=j.1.2.parent.beta

theorem gate_bounds {n:Nat} (j:Job n):0<gate j ∧ gate j<3*(n+1)-4:=by
  have h:=j.1.2.parent.beta_pos
  have ho:=j.1.2.parent.ordered
  have hs:=j.1.2.parent.gamma_lt
  exact ⟨h,by unfold gate;omega⟩

theorem choice_valid (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn):choice j≠0:=by
  exact BetaValue.nonzero n hn (j,true) ((BetaValue.job_mem n hn _).mpr hj) _ (by simp [choice,BetaValue.s])

theorem constant_link (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (v:Bool):
    GuardedJoin.link [-choice j] (sign v (cofactor n hn (gate j) j.2))
      (sign v (PrimaryAliasBank.cfg n hn).C)∈UnaryValueBank.result n hn:=by
  have hp:BetaValue.row n hn (j,true)∈BetaValue.result n hn:=
    List.mem_append_right _ (List.mem_map.mpr ⟨(j,true),(BetaValue.job_mem n hn _).mpr hj,rfl⟩)
  have hm:BetaValue.row n hn (j,false)∈BetaValue.result n hn:=
    List.mem_append_right _ (List.mem_map.mpr ⟨(j,false),(BetaValue.job_mem n hn _).mpr hj,rfl⟩)
  have hc:=choice_valid n hn j hj
  have hp':clause [-choice j,-(cofactor n hn (gate j) j.2).val,(PrimaryAliasBank.cfg n hn).C.val]∈BetaValue.result n hn:=hp
  have hm':clause [-choice j,-(PrimaryAliasBank.cfg n hn).C.val,(cofactor n hn (gate j) j.2).val]∈BetaValue.result n hn:=by
    have hq:=(cofactor n hn (gate j) j.2).property
    have hC:=(PrimaryAliasBank.cfg n hn).C.property
    change clause [-choice j,-(-(cofactor n hn (gate j) j.2).val),-(PrimaryAliasBank.cfg n hn).C.val]∈BetaValue.result n hn at hm
    simp only [neg_neg] at hm
    rw [ProjectionTrace.clause_perm _ _ (by simp [Valid,hc,hq,hC]) (by simp [Valid,hc,hq,hC])
      (List.Perm.cons _ (List.Perm.swap ..))]
    exact hm
  exact beta_keep n hn _ (UnaryValueStep.conditional_link _ ⟨choice j,hc⟩ _ _ v hp' hm')

theorem constant_reverse_link (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (v:Bool):
    GuardedJoin.link [-choice j] (sign v (PrimaryAliasBank.cfg n hn).C)
      (sign v (cofactor n hn (gate j) j.2))∈UnaryValueBank.result n hn:=by
  have h:=constant_link n hn j hj (!v)
  cases v <;> simp only [Bool.not_false,Bool.not_true,GuardedJoin.link,sign,Bool.false_eq_true,↓reduceIte,neg_neg,List.singleton_append] at h ⊢
  all_goals
    rw [ProjectionTrace.clause_perm _ _
      (by simp [Valid,choice_valid n hn j hj,(cofactor n hn (gate j) j.2).property,(PrimaryAliasBank.cfg n hn).C.property])
      (by simp [Valid,choice_valid n hn j hj,(cofactor n hn (gate j) j.2).property,(PrimaryAliasBank.cfg n hn).C.property])
      (List.Perm.cons _ (List.Perm.swap ..))]
    exact h

def G (n:Nat) (hn:2≤n) (j:Job n) (v:Bool):=[-choice j,-sign v (cofactor n hn (gate j) j.2)]
def H (n:Nat) (hn:2≤n) (j:Job n):=[-((PrimaryAliasBank.cfg n hn).beta (gate j)).val]
def row (n:Nat) (hn:2≤n) (j:Job n) (b v:Bool):=
  GuardedJoin.target (G n hn j v) (H n hn j) (sign v (unary n hn (gate j) b))
def tape (n:Nat) (hn:2≤n) (j:Job n) (b v:Bool) (D:List Row):=
  GuardedJoin.tape D (G n hn j v) (H n hn j)
    (sign v (PrimaryAliasBank.cfg n hn).C) (sign v (unary n hn (gate j) b))

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (b v:Bool)
    (D:List Row) (hd:∀R∈UnaryValueBank.result n hn,R∈D):
    polEval (dbOf D) (tape n hn j b v D) []=some (row n hn j b v):=by
  have hg:=gate_bounds j
  have h:=UnaryRelationBank.beta_relations n hn (gate j) hg.1 hg.2 b
  have link:=UnaryValueStep.conditional_link _ ((PrimaryAliasBank.cfg n hn).beta (gate j))
    (PrimaryAliasBank.cfg n hn).C (unary n hn (gate j) b) v h.1 h.2
  exact GuardedJoin.checks D _ _ _ _
    (by simp [G,Valid,choice_valid n hn j hj,sign_valid])
    (by simp [H,Valid,((PrimaryAliasBank.cfg n hn).beta (gate j)).property])
    (sign_valid v _) (sign_valid v _) (hd _ (constant_link n hn j hj v))
    (hd _ (unary_keep n hn _ link))

#print axioms constant_link
#print axioms constant_reverse_link
#print axioms checks
end L3Emitter.BetaAliasValue

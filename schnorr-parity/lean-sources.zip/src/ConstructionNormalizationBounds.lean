import ConstructionLocalTools
import RecordedNormalization

namespace L3Emitter.ConstructionNormalizationBounds
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation RecordedReplayCost
open CanonicalReplayEnvelope AuditLocalCosts ConstructionLocalTools

theorem weaken_length (xs : List Int) :
    (NormalizationPOL.weakenTokens xs).length=2*xs.length := by
  induction xs with
  | nil=>rfl
  | cons x xs ih=>simp only [NormalizationPOL.weakenTokens,List.flatMap_cons,
      List.length_append,List.length_cons,List.length_nil] at *;omega

theorem selectorRest (k p a j : Nat) : (RecordedSelector.rest k p a j).length≤k := by
  unfold RecordedSelector.rest
  have h1 : (((SelectorNormalization.choices k p).erase
    (SelectorNormalization.selector k p a)).erase (SelectorNormalization.selector k p j)).length≤
    ((SelectorNormalization.choices k p).erase (SelectorNormalization.selector k p a)).length := List.length_erase_le
  have h2 : ((SelectorNormalization.choices k p).erase (SelectorNormalization.selector k p a)).length≤
    (SelectorNormalization.choices k p).length := List.length_erase_le
  have h3:(SelectorNormalization.choices k p).length=k:=by simp [SelectorNormalization.choices]
  omega

theorem selectorCandidate (D : List Row) (k p a j : Nat) :
    tokens (RecordedSelector.candidate D k p a j)≤2*k+7 := by
  rw [RecordedSelector.candidate,fromTape]
  simp only [RecordedSelector.candidateTape,NormalizationPOL.imageTokens,
    NormalizationPOL.pairTokens,List.length_append,List.length_cons,List.length_nil,weaken_length]
  have :=selectorRest k p a j
  omega

theorem selector (D : List Row) (k s a j p : Nat) :
    BoundedGoals (2*k+7) (certificates (RecordedSelector.step D k s a j p)) := by
  intro c hc
  change c∈RecordedSelector.candidate D k p a j::D.map _ at hc
  rcases List.mem_cons.mp hc with rfl|hc
  · exact selectorCandidate ..
  · obtain ⟨R,hR,rfl⟩:=List.mem_map.mp hc
    rw [old];omega

theorem selectorLeft (k s m : Nat) : BoundedProgram (2*k+7) (RecordedSelectorPrefix.left k s m) := by
  induction m with
  | zero=>simp [RecordedSelectorPrefix.left,BoundedProgram]
  | succ m ih=>
    apply append _ _ _ ih
    intro c hc
    obtain rfl:=List.mem_singleton.mp hc
    exact selector _ k s _ _ _

theorem selectorRight (k s m : Nat) : BoundedProgram (2*k+7) (RecordedSelectorPrefix.right k s m) := by
  induction m with
  | zero=>simp [RecordedSelectorPrefix.right,BoundedProgram]
  | succ m ih=>
    apply append _ _ _ ih
    intro c hc
    obtain rfl:=List.mem_singleton.mp hc
    exact selector _ k s _ _ _

theorem combination_steps (D rs : List Row) : (LocalCombination.steps D rs).length=2*rs.length := by
  induction rs with
  | nil=>rfl
  | cons r rs ih=>simp only [LocalCombination.steps,List.flatMap_cons,
      List.length_append,List.length_cons,List.length_nil] at *;omega

theorem combination (D : List Row) (C G R : Row) (rs : List Row) :
    tokens (RecordedCombination.certificate D C G R rs)=2*rs.length+3 := by
  simp only [RecordedCombination.certificate,fromTape,List.length_append,
    List.length_cons,List.length_nil,combination_steps]
  omega

theorem repeatedLeaf (k s x : Nat) (a b c : Bool) :
    tokens (RecordedRepeatedLeaves.certificate k s x a b c)≤2*k+7 := by
  dsimp only [RecordedRepeatedLeaves.certificate]
  split
  · split
    · rw [combination];simp
    · rw [combination]
      simp only [List.length_append,List.length_map,List.length_cons,List.length_nil,
        SelectorNormalization.leftPrevious,List.length_map,List.length_range]
      omega
  · rw [taut];omega

theorem repeatedGoal (k s : Nat) (R : Row) : tokens (RecordedRepeated.goal k s R)≤2*k+7 := by
  dsimp only [RecordedRepeated.goal]
  split
  · rw [old];omega
  · split
    · rw [taut];omega
    · apply pick_bound
      intro c hc
      obtain ⟨q,hq,rfl⟩:=List.mem_map.mp hc
      exact repeatedLeaf k s q.1 q.2.1 q.2.2.1 q.2.2.2

theorem repeated (k s : Nat) : BoundedGoals (2*k+7) (certificates (RecordedRepeated.step k s)) :=
  redMap _ _ _ _ _ (by intros;exact repeatedGoal _ _ _)

theorem projectionGoal (D : List Row) (C : Row) (w : FiniteWitness.Data) (R : Row) :
    tokens (RecordedProjection.goal D C w R)=3 := by
  dsimp only [RecordedProjection.goal]
  split
  · exact old ..
  · exact cover ..

theorem projection (k s c : Nat) : BoundedGoals (2*k+7) (certificates (RecordedProjection.step k s c)) := by
  apply redMap
  intro R hR
  rw [projectionGoal];omega

/-- Every stored local certificate in the complete normalization prefix has
at most 2k+7 POL TOKENS; this counts tokens, not bytes or money. -/
theorem normalization (k s : Nat) : BoundedProgram (2*k+7) (RecordedNormalization.program k s) := by
  apply append
  · exact append _ _ _ (selectorLeft k s _) (selectorRight k s _)
  · intro c hc
    rcases List.mem_cons.mp hc with rfl|hc
    · exact repeated k s
    rcases List.mem_cons.mp hc with rfl|hc
    · exact projection k s 3
    obtain rfl:=List.mem_singleton.mp hc
    exact projection k s 12

#print axioms normalization
#print axioms combination
#print axioms repeatedLeaf
end L3Emitter.ConstructionNormalizationBounds

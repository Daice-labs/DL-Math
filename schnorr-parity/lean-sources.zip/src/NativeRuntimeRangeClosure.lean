import NativeRuntimeStoreSupport
namespace L3Emitter.NativeRuntimeSupport
open EREF EREF.GeneralRED NativeSparseStore CanonicalScopeKernel

/-- Scalar magnitudes do not constrain this range condition. It concerns the
number of distinct native variables, hence every canonical literal count. -/
theorem safe_command (K:Nat) (s q:Store) (c:CanonicalScopeKernel.Command) (hK:K<2^63)
 (hs:StoreVars K s) (hc:CommandVars K c) (h:PinnedScopeExecution.execute s c=some q):
 PinnedRetainedScope.SafeCommand s c:=by
 cases c with
 | pol ts=>trivial
 | consequence R p=>
   by_cases hR:Canonical R
   · exact row_fits K R hR hc.1 hK
   · simp [PinnedScopeExecution.execute,hR] at h
 | red R w gs=>
   by_cases hR:Canonical R
   · refine ⟨row_fits K R hR hc.1 hK,?_⟩
     intro g hg T hT
     have ht:=source_vars K s R g.key T hs hR hc.1 hT
     exact row_fits K _ (native_substitution_canonical T w)
       (native_substitution_vars K w hc.2.1 T ht.2) hK
   · simp [PinnedScopeExecution.execute,hR] at h

/-- Every signed literal-count condition for every main and local RED scope
is discharged from one real native-name count bound. This is a construction-
independent safety theorem, not a premise that a native run succeeds. -/
theorem safe_run (K:Nat) (s q:Store) (cs:List CanonicalScopeKernel.Command) (hK:K<2^63)
 (hs:StoreVars K s) (hc:∀c∈cs,CommandVars K c)
 (h:PinnedScopeExecution.run s cs=some q):PinnedRetainedScope.SafeRun s cs:=by
 induction cs generalizing s with
 | nil=>trivial
 | cons c cs ih=>
   obtain ⟨t,ht,hq⟩:=Option.bind_eq_some_iff.mp h
   refine ⟨safe_command K s t c hK hs (hc c (by simp)) ht,?_⟩
   intro u hu
   have he:some t=some u:=ht.symm.trans hu
   have he:=Option.some.inj he;subst u
   exact ih t (execute_vars K s t c hs (hc c (by simp)) ht)
     (fun c hc'=>hc c (by simp [hc'])) hq

/-- The emitted-subset retained-tag runtime succeeds under field/name bounds,
with no assumed native arithmetic or temporary-row-normalization oracle. -/
theorem retained_run (K:Nat) (s:PinnedRetainedStore.Store) (q:NativeSparseStore.Store)
 (cs:List CanonicalScopeKernel.Command) (hK:K<2^63) (hn:PinnedRetainedStore.Normal s)
 (hs:StoreVars K (PinnedRetainedStore.project s)) (hc:∀c∈cs,CommandVars K c)
 (h:PinnedScopeExecution.run (PinnedRetainedStore.project s) cs=some q):
 ∃out,PinnedRetainedScope.run s cs=some out ∧ PinnedRetainedStore.project out=q ∧ PinnedRetainedStore.Normal out:=
 PinnedRetainedScope.correct s cs q hn (safe_run K _ q cs hK hs hc h) h
#print axioms safe_run
#print axioms retained_run
end L3Emitter.NativeRuntimeSupport

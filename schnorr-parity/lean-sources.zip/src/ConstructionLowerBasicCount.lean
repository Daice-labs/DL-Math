import ConstructionTableCount
namespace L3Emitter.ConstructionLowerBasicCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount

theorem width (n : Nat) : RankConstruction.width (n+1)≤3*(n+1) := by
  unfold RankConstruction.width;omega

theorem port_jobs (n : Nat) : (RankPortBank.jobs n).length=2*RankConstruction.width (n+1) := by
  simp [RankPortBank.jobs,List.length_flatMap];ring

theorem primary (n : Nat) (hn : 2≤n) : (RawPrimaryTransferBank.program n hn).length≤6*(n+1)^2*2^n := by
  have h:=retained_fold (RawPrimaryTransferBank.leaf n hn) (RawPrimaryTransferBank.rows n)
    (RawPrimaryTransferBank.jobs n hn) (RankOrderExclusion.result n hn) 1 (by intros;rfl)
  change (RawPrimaryTransferBank.program n hn).length≤_ at h
  rw [RawPrimaryTransferBank.job_count,RawInputSize.raw_record_count] at h
  change _≤2*RankConstruction.width (n+1)*n*2^n*1 at h
  have hm:=Nat.mul_le_mul_right (2^n) (Nat.mul_le_mul (Nat.mul_le_mul_left 2 (width n)) (show n≤n+1 by omega))
  exact h.trans (by nlinarith)

theorem amo (n : Nat) (hn : 2≤n) : (LowerSelectorAMO.program n hn).length≤24*(n+1)^2 := by
  have h:=retained_fold (LowerSelectorAMO.leaf n hn) (LowerSelectorAMO.rows n hn)
    (LowerSelectorAMO.jobs n) (RawPrimaryTransferBank.result n hn) (4*(n+1)) (by
      intro j hj D
      have hj':RankPortBank.ValidJob n j:=(RankPortBank.job_mem n j).mp hj
      have hh:=OneHotSize.commands_bound D (LowerSelectorAMO.xs n hn j.1 j.2)
      change (LowerSelectorAMO.leaf n hn j D).length≤_ at hh
      simp only [LowerSelectorAMO.xs,List.length_ofFn] at hh
      have:=width n;have:=hj'.1;omega)
  change (LowerSelectorAMO.program n hn).length≤(RankPortBank.jobs n).length*(4*(n+1)) at h
  rw [port_jobs] at h
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 2 (width n))).trans_eq (by ring))

theorem alo (n : Nat) (hn : 2≤n) : (LowerSelectorALO.program n hn).length≤6*(n+1) := by
  have h:=retained_fold (LowerSelectorALO.leaf n hn) (LowerSelectorALO.rows n hn)
    (RankPortBank.jobs n) (LowerTopologyBank.result n hn) 1 (by intros;rfl)
  change (LowerSelectorALO.program n hn).length≤_ at h
  rw [port_jobs,Nat.mul_one] at h
  exact h.trans (by have:=width n;omega)

theorem zero_leaf (n : Nat) (hn : 2≤n) (r : RankPortBank.Record n)
    (u : Fin (RankConstruction.width (n+1))) (D : List Row) :
    (RankZeroTransport.program n hn r u D).length=3*(n+1)-5+1 := by
  simp [RankZeroTransport.program,RankZeroTransport.casesProgram,RankZeroTransport.gates]

theorem zero_jobs (n : Nat) (hn : 2≤n) : (LowerTopologyBank.jobs n hn).length≤18*(n+1)^2 := by
  unfold LowerTopologyBank.jobs
  have h:=flat_bound (RankPortBank.result n hn).2
    (fun r=>(List.finRange (RankConstruction.width (n+1))).filterMap fun u=>if r.1≤u.val then some (r,u) else none)
    (RankConstruction.width (n+1)) (by intro r hr;exact (List.length_filterMap_le ..).trans_eq List.length_finRange)
  rw [RawInputSize.rank_port_count] at h
  have hm:=Nat.mul_le_mul (Nat.mul_le_mul_left 2 (width n)) (width n)
  exact h.trans (hm.trans_eq (by ring))

theorem zero (n : Nat) (hn : 2≤n) : (LowerTopologyBank.program n hn).length≤72*(n+1)^3 := by
  have h:=retained_fold (LowerTopologyBank.leaf n hn) (LowerTopologyBank.rows n hn)
    (LowerTopologyBank.jobs n hn) (TopologyBank.result n hn) (4*(n+1)) (by
      intro j hj D;unfold LowerTopologyBank.leaf;rw [zero_leaf];omega)
  change (LowerTopologyBank.program n hn).length≤_ at h
  exact h.trans ((Nat.mul_le_mul_right _ (zero_jobs n hn)).trans_eq (by ring))

#print axioms primary
#print axioms amo
#print axioms alo
#print axioms zero
end L3Emitter.ConstructionLowerBasicCount

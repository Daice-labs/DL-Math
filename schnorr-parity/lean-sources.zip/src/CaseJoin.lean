import REDWitness

namespace L3Emitter.CaseJoin
open EREF L3Emitter.Resolution L3Emitter.REDWitness

/-- Explicit linear POL join for a complete list of guarded cases. -/
def joinTokens (alo : Nat) (ids : List Nat) : List Tok :=
  [.ref alo] ++ ids.flatMap (fun i => [.ref i,.add]) ++ [.div ids.length]

def fold (db : Nat → Option Row) (acc : Row) : List Nat → Row
  | [] => acc
  | i :: ids => fold db (add acc ((db i).getD contra)) ids

theorem eval_fold (db : Nat → Option Row) (ids : List Nat)
    (hi : ∀ i ∈ ids, ∃ R, db i = some R) (acc : Row) (st : List Row) (tail : List Tok) :
    polEval db (ids.flatMap (fun i => [.ref i,.add]) ++ tail) (acc :: st) =
      polEval db tail (fold db acc ids :: st) := by
  induction ids generalizing acc with
  | nil => rfl
  | cons i ids ih =>
    obtain ⟨R,hr⟩ := hi i (by simp)
    simp only [List.flatMap_cons, List.cons_append, List.nil_append, polEval, hr,
      fold, Option.getD_some]
    exact ih (by intro j hj; exact hi j (by simp [hj])) _

def scaled (m : Nat) (C : Row) : Row :=
  ⟨C.terms.map (fun t => (m*t.1,t.2)), (m:Int)*(C.bound-1)+1⟩

theorem canonical_scaled (m : Nat) (hm : 0 < m) (C : Row) (hC : Canonical C) :
    Canonical (scaled m C) := by
  constructor
  · intro t ht
    obtain ⟨u,hu,rfl⟩ := List.mem_map.mp ht
    exact ⟨Nat.mul_pos hm (hC.1 u hu).1,(hC.1 u hu).2⟩
  · simpa [scaled, List.pairwise_map] using hC.2

theorem tval_scaled (m : Nat) (ts : List (Nat × Int)) (α : Val) :
    tval α (ts.map (fun t => (m*t.1,t.2))) = m * tval α ts := by
  induction ts with
  | nil => simp [tval]
  | cons t ts ih => simp [tval, ih]; ring

theorem val_scaled (m : Nat) (C : Row) (α : Val) :
    (scaled m C).val α = m*C.val α + m-1 := by
  simp only [scaled, Row.val, tval_scaled]
  ring

theorem ceil_mul (m a : Nat) (hm : 0 < m) : ceilDiv ((m*a : Nat):Int) m = a := by
  unfold ceilDiv ceilTerms.ceilDiv'
  have hz : (m:Int) ≠ 0 := by omega
  have he : -((m*a : Nat):Int) = (m:Int) * (-(a:Int)) := by push_cast; ring
  rw [he, Int.mul_ediv_cancel_left _ hz]
  simp

theorem ceil_bound (m : Nat) (hm : 0 < m) (b : Int) :
    ceilDiv ((m:Int)*(b-1)+1) m = b := by
  unfold ceilDiv ceilTerms.ceilDiv'
  have hpos : (0:Int) < m := by omega
  have he : -((m:Int)*(b-1)+1) = (-(b-1)-1)*(m:Int)+((m:Int)-1) := by ring
  rw [he, Int.mul_add_ediv_right _ _ (by omega : (m:Int) ≠ 0)]
  have hz : ((m:Int)-1)/(m:Int) = 0 := Int.ediv_eq_zero_of_lt (by omega) (by omega)
  rw [hz]; ring

theorem divide_scaled (m : Nat) (hm : 0 < m) (C : Row) (hC : Canonical C) :
    divide (scaled m C) m = C := by
  have ht : ceilTerms m (scaled m C).terms = C.toSigned := by
    simp only [scaled, ceilTerms, Row.toSigned, List.map_map]
    apply List.map_congr_left
    intro t ht
    simp only [Function.comp_apply]
    exact Prod.ext (ceil_mul m t.1 hm) rfl
  unfold divide
  rw [ht]
  change normalize C.toSigned (ceilDiv ((m:Int)*(C.bound-1)+1) m) = C
  rw [ceil_bound m hm C.bound]
  exact normalize_identity C hC

/-- The fold's value identity includes every case and does not assume that
    the guard list is exclusive, distinct, or bounded by a concrete n. -/
theorem fold_values (db : Nat → Option Row) (acc C : Row) (hacc : Canonical acc)
    (hC : Canonical C) (pairs : List (Nat × Int))
    (hg : ∀ p ∈ pairs, p.2 ≠ 0 ∧ db p.1 = some (branch C (-p.2))) (α : Val) :
    Canonical (fold db acc (pairs.map Prod.fst)) ∧
    (fold db acc (pairs.map Prod.fst)).val α =
      acc.val α + pairs.length*C.val α + (pairs.map (fun p => litVal α (-p.2))).sum := by
  induction pairs generalizing acc with
  | nil => simp [fold, hacc]
  | cons p pairs ih =>
    have hp := hg p (by simp)
    simp only [List.map_cons, fold, hp.2, Option.getD_some]
    obtain ⟨hc,hv⟩ := ih (add acc (branch C (-p.2))) (canonical_add _ _)
      (by intro r hr; exact hg r (by simp [hr]))
    refine ⟨hc, ?_⟩
    rw [hv, val_add acc (branch C (-p.2)) hacc (canonical_normalize _ _), val_branch C hC (-p.2) (by omega)]
    simp only [List.length_cons, Nat.cast_add, Nat.cast_one, List.sum_cons, Row.val]
    ring

theorem complement_sum (α : Val) (gs : List Int) (hz : Valid gs) :
    sum α gs + (gs.map (fun g => litVal α (-g))).sum = gs.length := by
  induction gs with
  | nil => simp
  | cons g gs ih =>
    have hz' := hz g (by simp)
    have hh := ih (by intro l hl; exact hz l (by simp [hl]))
    simp only [sum_cons, List.map_cons, List.sum_cons, List.length_cons, Nat.cast_add, Nat.cast_one]
    rw [litVal_neg α g hz']; omega

/-- Executable successful join, not a conditional assertion about an oracle's result. -/
theorem join_succeeds (db : Nat → Option Row) (C : Row) (hC : Canonical C)
    (alo : Nat) (pairs : List (Nat × Int)) (hne : pairs ≠ [])
    (ha : db alo = some (clause (pairs.map Prod.snd)))
    (hp : ∀ p ∈ pairs, p.2 ≠ 0 ∧ db p.1 = some (branch C (-p.2))) :
    polEval db (joinTokens alo (pairs.map Prod.fst)) [] = some C := by
  have hm : 0 < pairs.length := List.length_pos_iff.mpr hne
  have hv : Valid (pairs.map Prod.snd) := by
    intro l hl; obtain ⟨p,hp',rfl⟩ := List.mem_map.mp hl; exact (hp p hp').1
  have he : fold db (clause (pairs.map Prod.snd)) (pairs.map Prod.fst) = scaled pairs.length C := by
    have hh := fold_values db (clause (pairs.map Prod.snd)) C (canonical_normalize _ _) hC pairs hp
    apply canonical_ext _ _ (hh (fun _ => false)).1 (canonical_scaled _ hm C hC)
    intro α
    rw [(hh α).2, val_clause _ hv, val_scaled]
    have hc := complement_sum α (pairs.map Prod.snd) hv
    simp only [List.map_map, List.length_map] at hc
    change sum α (List.map Prod.snd pairs) +
      (List.map (fun p => litVal α (-p.2)) pairs).sum = (pairs.length:Int) at hc
    omega
  have hid : ∀ i ∈ pairs.map Prod.fst, ∃ R, db i = some R := by
    intro i hi; obtain ⟨p,hp',rfl⟩ := List.mem_map.mp hi; exact ⟨_,(hp p hp').2⟩
  simp only [joinTokens, List.cons_append, List.nil_append, polEval, ha]
  rw [eval_fold db _ hid, he]
  simp only [List.length_map, polEval, hm, ↓reduceIte, divide_scaled _ hm C hC]

theorem join_token_count (alo : Nat) (ids : List Nat) :
    (joinTokens alo ids).length = 2*ids.length+2 := by
  simp [joinTokens, List.length_flatMap, List.map_map, Function.comp_def]
  omega

#print axioms join_succeeds
#print axioms join_token_count
end L3Emitter.CaseJoin

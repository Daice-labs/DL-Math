import SharedTailComposition
import ShiftedWitnessFrame
import AliasNetwork
namespace L3Emitter.ActivationNamespace
open EREF EREF.GeneralRED AliasNetwork

/-- The activation assignment used by compose.py: q := true and every fresh
lower original variable maps to its previously constructed upper image. -/
def witness (M L N:Nat) (image:Nat→Bit):GeneralRED.Witness:=fun v=>
  if v=M+N+1 then .constant true
  else if M<v ∧ v≤M+L then .literal (image (v-M)).val (image (v-M)).property
  else if hv:v=0 then .constant false else .literal (v:Int) (by omega)

theorem fixes_upper (M L N:Nat) (image:Nat→Bit):
    REDFrame.FixesBelow (witness M L N image) M:=by
  intro v hv hM α
  simp [GeneralRED.applyWitness,witness,show v≠M+N+1 by omega,
    show ¬(M<v ∧ v≤M+L) by omega,show v≠0 by omega,GeneralRED.Image.eval,hv]

theorem guard_on (M L N:Nat) (image:Nat→Bit) (α:Val):
    applyWitness (witness M L N image) α (M+N+1)=true:=by
  simp [GeneralRED.applyWitness,witness,GeneralRED.Image.eval]

theorem lower_image (M L N v:Nat) (image:Nat→Bit) (hv:0<v) (hL:v≤L) (hLN:L≤N):
    witness M L N image (M+v)=.literal (image v).val (image v).property:=by
  simp [witness,show M+v≠M+N+1 by omega,show M<M+v by omega,
    show M+v≤M+L by omega]

/-- Namespace obligations are discharged by the concrete activation map.
The remaining lower-row premise is exact membership of its substituted
original rows, not semantic validity or an assumed RUP success. -/
theorem compose (M L N:Nat) (image:Nat→Bit) (upper inputs E:List Row)
    (a:Row→Nat) (m:Nat) (hu:RowSupport.Bounded M upper)
    (hi:∀R∈inputs,Canonical R) (ha:∀R∈inputs,0<a R)
    (himage:∀R∈inputs,substRow R (witness M L N image)∈upper)
    (tail:GuardedReplay.Scoped M (-((M+N+1:Nat):Int)) inputs E m):
    GuardedReplay.Counted (upper++GuardActivation.bank inputs a (M+N+1))
      (ActivatedReplay.frame upper inputs a (M+N+1)++E) (inputs.length+m+1):=
  SharedTailComposition.activate_cancel_replay M (M+N+1) upper inputs E a m
    (witness M L N image) (by omega) hu hi ha
    (REDFrame.bounded_fixed _ M upper (fixes_upper M L N image) hu)
    (guard_on M L N image) himage tail

#print axioms compose
#print axioms lower_image
end L3Emitter.ActivationNamespace

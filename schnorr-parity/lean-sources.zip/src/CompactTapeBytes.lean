import CompactReferenceWidths
import TemplateBytes
namespace L3Emitter.CompactTapeBytes
open EREF

def token : Tok→PolToken
  | .ref i=>.ref (i:Int)
  | .lit l=>.lit (TemplateBytes.signedLiteral l)
  | .add=>.add
  | .mul a=>.mul a
  | .div a=>.div a
  | .sat=>.sat

/-- Bytes excluding decimal digits of row references. Literal signs, variable
ID digits, multiplication/division coefficient digits and operators are included. -/
def otherTokenBytes : Tok→Nat
  | .ref _=>0
  | .lit l=>TemplateBytes.literalBytes l
  | .add=>1
  | .mul a=>digits a+2
  | .div a=>digits a+2
  | .sat=>1

def refTokenBytes : Tok→Nat | .ref i=>digits i | _=>0

theorem token_exact (t : Tok) :
    exactBytes (polToken (token t))=refTokenBytes t+otherTokenBytes t := by
  cases t with
  | ref i=>simp [token,polToken,integer,refTokenBytes,otherTokenBytes,show ¬(i:Int)<0 by omega]
  | lit l=>simpa [token,polToken,refTokenBytes,otherTokenBytes] using TemplateBytes.literal_bytes l
  | add=>rfl
  | mul a=>simp [token,polToken,refTokenBytes,otherTokenBytes];rfl
  | div a=>simp [token,polToken,refTokenBytes,otherTokenBytes];rfl
  | sat=>rfl

def line (ts : List Tok) : Doc := command (.pol (ts.map token))
def otherBytes (ts : List Tok) := (ts.map otherTokenBytes).sum

/-- Exact ASCII BYTES of a POL line: syntax, separators, reference digits and
all other operand digits. Empty-list subtraction is truncated at zero. -/
theorem line_exact (ts : List Tok) :
    (emit (line ts)).length=7+(ts.length-1)+
      CompactReferenceWidths.referenceDigitBytes ts+otherBytes ts := by
  rw [emit_length]
  simp only [line,command,exactBytes_append]
  have hsep : exactBytes (separated (fixed " ") ((ts.map token).map polToken))=
      CompactReferenceWidths.referenceDigitBytes ts+otherBytes ts+(ts.length-1) := by
    cases ts with
    | nil=>rfl
    | cons t ts=>
      simp only [List.map_cons,TemplateBytes.separated_bytes,List.map_map,
        Function.comp_def,token_exact,List.length_cons,otherBytes,
        CompactReferenceWidths.referenceDigitBytes,List.sum_cons]
      simp only [List.sum_map_add]
      simp only [List.length_map]
      change refTokenBytes t+otherTokenBytes t+
        ((ts.map refTokenBytes).sum+(ts.map otherTokenBytes).sum)+ts.length*1=_
      change _=refTokenBytes t+(ts.map refTokenBytes).sum+
        (otherTokenBytes t+(ts.map otherTokenBytes).sum)+(ts.length+1-1)
      omega
  rw [hsep]
  change 4+(_)+3=_
  omega

theorem line_reference_bound (N : Nat) (ts : List Tok)
    (h : CompactReferenceWidths.BoundedRefs N ts) :
    (emit (line ts)).length≤7+(ts.length-1)+
      CompactReferenceWidths.referenceCount ts*digits N+otherBytes ts := by
  rw [line_exact]
  have hr:=CompactReferenceWidths.reference_digit_bytes_bound N ts h
  omega

/-- All local POL bodies, including every RED goal and consequence certificate,
can be accounted for by summing this identity. Scope lines are separate. -/
def body (p : AliasProgram.Program) : Doc := p.flatMap (fun c=>line c.2)

theorem body_exact (p : AliasProgram.Program) :
    (emit (body p)).length=(p.map (fun c=>7+(c.2.length-1)+
      CompactReferenceWidths.referenceDigitBytes c.2+otherBytes c.2)).sum := by
  rw [emit_length]
  simp only [body,TemplateBytes.flatMap_bytes]
  congr 1
  apply List.map_congr_left
  intro c hc
  exact (emit_length (line c.2)).symm.trans (line_exact c.2)

#print axioms token_exact
#print axioms line_exact
#print axioms line_reference_bound
#print axioms body_exact
end L3Emitter.CompactTapeBytes

import ConstructionFinalDefinitionCount
import ConstructionFinalLogCount
import ConstructionFinalSmallCount
import ConstructionLowerCount
import FinalEvaluationSize
namespace L3Emitter.ConstructionFinalCount
open EREF EREF.GeneralRED ConstructionCountTools ConstructionLowerCount

theorem complete (n : Nat) (hn : 2≤n) : (RecordedFinalRows.program n hn).length≤2000*Q n := by
  have h0: (RecordedOutputDefinitions.program n hn).length≤220*Q n:=
    (ConstructionFinalDefinitionCount.complete n hn).trans (by simpa using lift_power n 220 1 (by omega))
  have h1: (FinalOutputRecorded.program n hn).length≤100*Q n:=
    (ConstructionFinalLogCount.complete n hn).trans (by simpa using lift_power n 100 1 (by omega))
  have h2:= (ConstructionFinalSmallCount.selectors n hn).trans (lift_plain n 136 2 (by omega))
  have h3: (FinalSelectorCardinalities.program n hn).length≤8*Q n:=
    (ConstructionFinalSmallCount.cardinalities n hn).trans (by simpa using lift_plain n 8 1 (by omega))
  have h4: (FinalOutputLinks.program n hn).length≤8*Q n:=
    (ConstructionFinalLogCount.output_links n hn).trans (by simpa using lift_power n 8 1 (by omega))
  have h5: (FinalTransferBank.program n hn).length+(FinalPrimaryTransfers.program n hn).length≤82*Q n:=by
    have h:=ReplacementStageSize.replacement_transfers_in_n n hn
    exact h.trans ((Nat.mul_le_mul_right (2^n) (show 82*n-100≤82*(n+1) by omega)).trans
      (by simpa using lift_power n 82 1 (by omega)))
  have h6: (FinalFunctionCases.program n hn).length≤96*Q n:=
    (ReplacementStageSize.function_commands n hn).trans (by simpa using lift_plain n 96 0 (by omega))
  have h7: (FinalU2Bank.bothProgram n hn).length≤400*Q n:=
    (ConstructionFinalSmallCount.u2 n hn).trans (by simpa using lift_plain n 400 0 (by omega))
  have h8: (FinalEvaluationBank.program n hn).length+(FinalEvaluationImage.program n hn).length≤128*Q n:=by
    have h:=FinalEvaluationSize.evaluation_commands_in_n n hn
    exact h.trans ((Nat.mul_le_mul_right (2^n) (show 128*n-52≤128*(n+1) by omega)).trans
      (by simpa using lift_power n 128 1 (by omega)))
  simp only [RecordedFinalRows.program,RecordedFinalRows.p10,RecordedFinalRows.p9,
    RecordedFinalRows.p8,RecordedFinalRows.p7,RecordedFinalRows.p6,RecordedFinalRows.p5,
    RecordedFinalRows.p4,RecordedFinalRows.p3,RecordedFinalRows.p2,RecordedFinalRows.p1,
    RecordedFinalRows.p0,List.length_append,polProgram_length]
  omega
#print axioms complete
end L3Emitter.ConstructionFinalCount

import NumericPolynomialFields
namespace L3Emitter.CanonicalPolynomialBytes
open CanonicalScopedBytes NumericPolynomialFields

theorem digits_linear (M:Nat):digits M≤M+1:=by
 apply (Nat.length_toDigits_le_iff (by decide:1<10) (show 0<M+1 by omega)).mpr
 have:=Nat.lt_pow_self (n:=M+1) (a:=10) (by decide)
 omega

theorem overhead (M H:Nat) (h:M≤H):SerializedActionBudget.overhead M (M+1) (M+1)+7≤100*(H+1)^2:=by
 have hd:digits M≤H+1:=(digits_linear M).trans (by omega)
 have ha:=Nat.mul_le_mul (show M+1≤H+1 by omega) (show 4+2*digits M≤4+2*(H+1) by omega)
 have hb:=Nat.mul_le_mul (show M+1≤H+1 by omega) (show 8+2*digits M≤8+2*(H+1) by omega)
 unfold SerializedActionBudget.overhead
 nlinarith only [hd,ha,hb]

theorem envelope_bound (n:Nat) (hn:2≤n):NumericFamilyClosed.bytes n≤1000*(envelope n+1)^3:=by
 let H:=envelope n
 let M:=NumericFamilyClosed.fields n
 have hm:M≤H:=fields n hn
 have hd:digits M≤H+1:=(digits_linear M).trans (by omega)
 have hP:=Nat.mul_le_mul (overhead M H hm) (main n hn)
 have hC:=Nat.mul_le_mul (show 22+2*digits M≤24*(H+1) by omega) (certificates n hn)
 have hL:=Nat.mul_le_mul (show 10+digits M≤11*(H+1) by omega) (localTokens n hn)
 have hT:=Nat.mul_le_mul (show 3+digits M≤4*(H+1) by omega) (mainTokens n hn)
 change 101+2*digits M+(SerializedActionBudget.overhead M (M+1) (M+1)+7)*ConstructionCompleteCount.mainBound n+
  (22+2*digits M)*ConstructionClosedAllocation.certificateBound n+(10+digits M)*ConstructionClosedAllocation.localTokenBound n+
  (3+digits M)*CanonicalFamilyMainTapes.mainTokenBound n≤1000*(H+1)^3
 change _≤100*(H+1)^2*H at hP
 change _≤24*(H+1)*H at hC
 change _≤11*(H+1)*H at hL
 change _≤4*(H+1)*H at hT
 nlinarith only [hd,hP,hC,hL,hT]

/-- A deliberately loose proof of polynomiality, unit ASCII BYTES.
The sharper arity-only bound is NumericFamilyClosed.bytes. This does not
assert a practical runtime, allocation, or native-machine admission. -/
def polynomial (R:Nat):Nat:=10^160*R^120

theorem serialized_bytes (n:Nat) (hn:2≤n):
 (CanonicalScopedBytes.familyBytes n).length≤polynomial (ConstructionFormulaScale.rows n):=by
 have hp:=NumericPolynomialFields.positive n hn
 have h2:envelope n+1≤2*envelope n:=by omega
 have h:1000*(envelope n+1)^3≤1000*(2*envelope n)^3:=Nat.mul_le_mul_left _ (Nat.pow_le_pow_left h2 3)
 apply (NumericFamilyClosed.serialized_bytes n hn).trans ((envelope_bound n hn).trans (h.trans _))
 unfold envelope polynomial
 calc
  1000*(2*(10^50*(ConstructionFormulaScale.rows n)^40))^3 = (8000*10^150)*(ConstructionFormulaScale.rows n)^120 := by ring
  _ ≤ _ := Nat.mul_le_mul_right _ (by decide)
#print axioms serialized_bytes
end L3Emitter.CanonicalPolynomialBytes

/-
Serializer for the L3 family (mirrors `Row.opb` and the header in family.py), the
parity target of family.py's `parity(k)` (popcount parity, x1 most significant), and a
small executable that writes the OPB text for the development parameters so that the
bytes can be compared with the Python emitter outside Lean (finite cross-check only).
-/
import L3Family

namespace L3

/-- `"1 x7"` for a positive literal, `"1 ~x7"` for a negated one (family.py `Row.opb`) -/
def litStr (l : Int) : String :=
  if l > 0 then "1 x" ++ toString l.natAbs else "1 ~x" ++ toString l.natAbs

/-- one serialized row, including the trailing `" >= rhs ;\n"` -/
def Row.opb (r : Row) : String :=
  " ".intercalate (r.lits.map litStr) ++ " >= " ++ toString r.rhs ++ " ;\n"

namespace Fam

/-- `"* #variable= V #constraint= F\n"` -/
def header (F : Fam) : String :=
  "* #variable= " ++ toString F.V ++ " #constraint= " ++ toString F.F ++ "\n"

/-- the whole OPB text: header followed by every original row in emission order -/
def opb (F : Fam) : String := F.header ++ String.join (F.rows.map Row.opb)

end Fam

/-- popcount parity of x (family.py `parity(k)`: `x.bit_count() & 1`) -/
def parityBit (x : Nat) : Bool :=
  if h : x = 0 then false else ((x % 2 == 1) != parityBit (x / 2))
decreasing_by omega

/-- the family instance used by the emitter for n = k inputs and s gates -/
def parityFam (k s : Nat) : Fam := { k := k, s := s, b := parityBit }

end L3

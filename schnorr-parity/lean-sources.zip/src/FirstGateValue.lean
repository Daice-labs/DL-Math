import FirstCofactorRows
namespace L3Emitter.FirstGateValue
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL CofactorValueRows FirstCofactorRows

theorem mux_signed (j:RecordedExpressions.Job) (a v:Bool):
    clause [-sign a j.c,-sign v j.q,sign v (if a then j.a else j.b)]∈RecordedExpressions.jobRows j:=by
  cases a <;> cases v <;> simp only [sign,Bool.false_eq_true,↓reduceIte,neg_neg]
  · rw [FirstValueCore.perm3 _ _ _ j.c.property j.q.property (neg_ne_zero.mpr j.b.property)]
    exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))
  · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_singleton_self _)))
  · rw [FirstValueCore.perm3 _ _ _ (neg_ne_zero.mpr j.c.property) j.q.property (neg_ne_zero.mpr j.a.property)]
    exact List.mem_cons_self ..
  · exact List.mem_cons_of_mem _ (List.mem_cons_self ..)

theorem mux_row (n:Nat) (hn:2≤n) (a b v:Bool):
    clause [-sign a (B n hn),-sign v (unary n hn 0 b),sign v ((PrimaryAliasBank.cfg n hn).fn 0 a b)]∈FirstUnaryMux.rows n hn:=by
  rw [←FirstUnaryMux.actual_output n hn b]
  apply List.mem_flatMap.mpr
  refine ⟨FirstUnaryMux.actual n hn b,by cases b <;> simp,?_⟩
  cases a
  · exact mux_signed (FirstUnaryMux.actual n hn b) false v
  · exact mux_signed (FirstUnaryMux.actual n hn b) true v

def args (n:Nat) (hn:2≤n) (x:Nat) (a v:Bool):= (
  signed a (B n hn),signed a (port n hn 0 x),signed (d n x) (port n hn 1 x),
  signed v (cofactor n hn 0 x),signed v ((PrimaryAliasBank.cfg n hn).fn 0 a (d n x)),signed v (unary n hn 0 (d n x)))
def sideRows (n:Nat) (hn:2≤n) (x:Nat) (a v:Bool):=
  FirstValueCore.rows (signed a (B n hn)) (signed a (port n hn 0 x)) (signed (d n x) (port n hn 1 x))
    (signed v (cofactor n hn 0 x)) (signed v ((PrimaryAliasBank.cfg n hn).fn 0 a (d n x))) (signed v (unary n hn 0 (d n x)))
def sideProgram (n:Nat) (hn:2≤n) (x:Nat) (a v:Bool) (D:List Row):=
  FirstValueCore.program (signed a (B n hn)) (signed a (port n hn 0 x)) (signed (d n x) (port n hn 1 x))
    (signed v (cofactor n hn 0 x)) (signed v ((PrimaryAliasBank.cfg n hn).fn 0 a (d n x))) (signed v (unary n hn 0 (d n x))) D

theorem side_checks (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n) (a v:Bool) (D:List Row)
    (hd:∀R∈SharedValueBank.result n hn,R∈D) (hm:∀R∈FirstUnaryMux.rows n hn,R∈D)
    (hp:∀R∈FirstCofactorRows.rows n hn x,R∈D):
    check D (sideProgram n hn x a v D)=some (D++sideRows n hn x a v):=by
  apply FirstValueCore.checks
  · change portRow n hn x a∈D
    apply hp;cases a <;> simp [FirstCofactorRows.rows]
  · change FirstCofactorRows.unitRow n hn x∈D
    exact hp _ (by simp [FirstCofactorRows.rows])
  · exact hd _ (semantics n hn x hx a (d n x) v)
  · exact hm _ (mux_row n hn a (d n x) v)

def target (n:Nat) (hn:2≤n) (x:Nat) (v:Bool):=
  clause [-sign v (unary n hn 0 (d n x)),sign v (cofactor n hn 0 x)]
def joinTape (n:Nat) (hn:2≤n) (x:Nat) (v:Bool) (D:List Row):=
  CommonGuardResolve.tape D [-sign v (unary n hn 0 (d n x)),sign v (cofactor n hn 0 x)] [] [] (B n hn).val

theorem joined (n:Nat) (hn:2≤n) (x:Nat) (v:Bool) (D:List Row)
    (hm:∀a,∀R, R∈sideRows n hn x a v → R∈D):
    polEval (dbOf D) (joinTape n hn x v D) []=some (target n hn x v):=by
  apply CommonGuardResolve.checks D _ [] [] _ (by simp [Valid,sign_valid]) (by simp [Valid]) (by simp [Valid]) (B n hn).property
  · have h:=hm false (R:=clause [(B n hn).val,-sign v (unary n hn 0 (d n x)),sign v (cofactor n hn 0 x)]) (by
      simp [sideRows,FirstValueCore.rows,FirstValueCore.target,signed,sign])
    change clause ([-sign v (unary n hn 0 (d n x)),sign v (cofactor n hn 0 x)]++[(B n hn).val])∈D
    rw [ProjectionTrace.clause_perm _ _ (by simp [Valid,sign_valid,(B n hn).property])
      (by simp [Valid,sign_valid,(B n hn).property]) List.perm_append_comm]
    exact h
  · have h:=hm true (R:=clause [-(B n hn).val,-sign v (unary n hn 0 (d n x)),sign v (cofactor n hn 0 x)]) (by
      simp [sideRows,FirstValueCore.rows,FirstValueCore.target,signed,sign])
    change clause ([-sign v (unary n hn 0 (d n x)),sign v (cofactor n hn 0 x)]++[-(B n hn).val])∈D
    rw [ProjectionTrace.clause_perm _ _ (by simp [Valid,sign_valid,(B n hn).property])
      (by simp [Valid,sign_valid,(B n hn).property]) List.perm_append_comm]
    exact h

def rows (n:Nat) (hn:2≤n) (x:Nat) (v:Bool):=sideRows n hn x false v++sideRows n hn x true v++[target n hn x v]
def program (n:Nat) (hn:2≤n) (x:Nat) (v:Bool) (D:List Row):Program:=
  sideProgram n hn x false v D++sideProgram n hn x true v (D++sideRows n hn x false v)++
    [(target n hn x v,joinTape n hn x v (D++sideRows n hn x false v++sideRows n hn x true v))]

theorem checks (n:Nat) (hn:2≤n) (x:Nat) (hx:x<FamilyNamespace.truthRows n) (v:Bool) (D:List Row)
    (hd:∀R∈SharedValueBank.result n hn,R∈D) (hm:∀R∈FirstUnaryMux.rows n hn,R∈D)
    (hp:∀R∈FirstCofactorRows.rows n hn x,R∈D):
    check D (program n hn x v D)=some (D++rows n hn x v):=by
  have e0:=side_checks n hn x hx false v D hd hm hp
  have e1:=side_checks n hn x hx true v (D++sideRows n hn x false v)
    (fun R h=>List.mem_append_left _ (hd R h)) (fun R h=>List.mem_append_left _ (hm R h))
    (fun R h=>List.mem_append_left _ (hp R h))
  have e2:=joined n hn x v (D++sideRows n hn x false v++sideRows n hn x true v) (by
    intro a R hr;cases a
    · exact List.mem_append_left _ (List.mem_append_right _ hr)
    · exact List.mem_append_right _ hr)
  have e3:check (D++sideRows n hn x false v++sideRows n hn x true v)
      [(target n hn x v,joinTape n hn x v (D++sideRows n hn x false v++sideRows n hn x true v))]=
        some ((D++sideRows n hn x false v++sideRows n hn x true v)++[target n hn x v]):=by
    simp only [check,e2,ite_true]
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ (check_append _ _ _ _ _ e0 e1) e3

#print axioms mux_row
#print axioms checks
end L3Emitter.FirstGateValue

import CofactorBank
import CofactorBytes

namespace L3Emitter.CofactorSection
open EREF EREF.GeneralRED REDWitness FamilyNamespace CofactorSemantics CofactorBytes

abbrev Job := Nat × Nat × Bool × Bool × Bool

def jobs (n s : Nat) : List Job :=
  (List.range s).flatMap fun g => (List.range (truthRows n)).flatMap fun x =>
    [false,true].flatMap fun a => [false,true].flatMap fun b => [false,true].map fun c => (g,x,a,b,c)
def resultRow (n s offset : Nat) (j : Job) : Row := goal n s offset j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2
def resultTape (n s offset B : Nat) (j : Job) : List Tok := tape n s offset B j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2

theorem job_bounds (n s : Nat) (j : Job) (hj : j∈jobs n s) : j.1<s ∧ j.2.1<truthRows n := by
  simp only [jobs,List.mem_flatMap,List.mem_map,List.mem_range] at hj
  obtain ⟨g,hg,x,hx,a,ha,b,hb,c,hc,rfl⟩ := hj
  exact ⟨hg,hx⟩

/-- The same concrete POL tapes remain valid while earlier output rows accumulate. -/
theorem tapes_trace (n s offset B : Nat) (hB : 0<B) (js : List Job)
    (hj : ∀ j∈js,j.1<s ∧ j.2.1<truthRows n) (pre : List Row) :
    CheckedTrace (database n s offset B++pre)
      ((database n s offset B++pre)++js.map (resultRow n s offset)) := by
  induction js generalizing pre with
  | nil => simpa using CheckedTrace.refl (database n s offset B++pre)
  | cons j js ih =>
    have hv := hj j (by simp)
    have he := all_gate_semantics n s offset B j.1 j.2.1 hB hv.1 hv.2 j.2.2.1 j.2.2.2.1 j.2.2.2.2
    have hmono := polEval_mono _ _ (dbOf_ext_append (database n s offset B) pre)
      (resultTape n s offset B j) [] (resultRow n s offset j) he
    have st := CheckedStep.pol _ _ _ hmono
    have ht := ih (by intro q hq; exact hj q (by simp [hq])) (pre++[resultRow n s offset j])
    have hc := CheckedTrace.cons st (by simpa only [List.append_assoc] using ht)
    simpa only [List.map_cons,List.append_assoc,List.singleton_append] using hc

/-- Original rows -> checked bank allocation -> every cofactor gate-semantics leaf.
    It stops at the semantics section, not at a contradiction. -/
theorem original_through_semantics (n s offset B : Nat) (hs : 0<s)
    (hV : variableCount (n+1) s≤offset) (hB : 0<B) (hBm : B≤offset) :
    CheckedTrace (OriginalEncoding.rows (n+1) s)
      (database n s offset B++(jobs n s).map (resultRow n s offset)) := by
  have hbank := CofactorBank.original_to_bank n s offset B hs hV hB hBm
  have hleaves := tapes_trace n s offset B hB (jobs n s) (job_bounds n s) []
  exact L3.Fam.checkedTrace_trans hbank (by simpa using hleaves)

def bankDocument (n s offset B : Nat) : Doc :=
  (List.range s).flatMap fun g => (List.range 3).flatMap fun p =>
    (List.range (truthRows n)).flatMap fun x =>
      TemplateBytes.gateDoc (low n offset g p x)
        (muxGate B (high n s g p x true) (high n s g p x false))
def maxVar (n s offset : Nat) : Nat := offset+3*s*truthRows n

theorem bank_bytes (n s offset B : Nat) (hV : variableCount (n+1) s≤offset)
    (hB : 0<B) (hBm : B≤offset) :
    (emit (bankDocument n s offset B)).length ≤
      3*s*truthRows n*(134+16*digits (maxVar n s offset)) := by
  have each (g p x : Nat) (hg : g<s) (hp : p<3) (hx : x<truthRows n) :
      exactBytes (TemplateBytes.gateDoc (low n offset g p x)
        (muxGate B (high n s g p x true) (high n s g p x false))) ≤
        134+16*digits (maxVar n s offset) := by
    have h := TemplateBytes.mux_exact_bytes (low n offset g p x) (low_pos ..) B
      (high n s g p x true) (high n s g p x false) (by omega)
      (by have := high_pos n s g p x hg hp hx true; omega)
      (by have := high_pos n s g p x hg hp hx false; omega)
    have hl := digits_mono (low_bound n s offset g p x hg hp hx)
    have hc := digits_mono (show B≤maxVar n s offset by unfold maxVar; omega)
    have ha := digits_mono (show high n s g p x true≤maxVar n s offset by
      have := CofactorBank.high_bound n s g p x hg hp hx true; unfold maxVar; omega)
    have hb := digits_mono (show high n s g p x false≤maxVar n s offset by
      have := CofactorBank.high_bound n s g p x hg hp hx false; unfold maxVar; omega)
    simp only [emit_length,Int.natAbs_natCast] at h
    change digits (low n offset g p x)≤digits (maxVar n s offset) at hl
    omega
  have h := document_flatMap_bound (List.range s)
    (fun g => (List.range 3).flatMap fun p => (List.range (truthRows n)).flatMap fun x =>
      TemplateBytes.gateDoc (low n offset g p x)
        (muxGate B (high n s g p x true) (high n s g p x false)))
    (3*truthRows n*(134+16*digits (maxVar n s offset))) (by
      intro g hg
      have hp := document_flatMap_bound (List.range 3) _
        (truthRows n*(134+16*digits (maxVar n s offset))) (by
          intro p hp
          simpa using document_flatMap_bound (List.range (truthRows n)) _
            (134+16*digits (maxVar n s offset)) (by
              intro x hx
              exact each g p x (List.mem_range.mp hg) (List.mem_range.mp hp) (List.mem_range.mp hx)))
      simpa only [List.length_range, Nat.mul_assoc] using hp)
  simpa [emit_length,bankDocument,Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using h

def document (n s offset B : Nat) : Doc := bankDocument n s offset B++semanticsDocument n s offset B

theorem combined_section_bytes (n s offset B : Nat) (hV : variableCount (n+1) s≤offset)
    (hB : 0<B) (hBm : B≤offset) :
    (emit (document n s offset B)).length ≤
      3*s*truthRows n*(134+16*digits (maxVar n s offset))+
      8*s*truthRows n*leafBound n s offset B := by
  have hbank := bank_bytes n s offset B hV hB hBm
  have hleaf := semantics_serialized_bound n s offset B
  simp only [document,emit_length,exactBytes_append] at *
  omega

#print axioms original_through_semantics
#print axioms combined_section_bytes
end L3Emitter.CofactorSection

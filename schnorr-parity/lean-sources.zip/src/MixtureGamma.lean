import SourceMixture

namespace L3Emitter.MixtureGamma
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL GuardedTree SourceMixture

theorem complement_clause (c x:Int) (hc:c≠0) (hx:x≠0) :
    clause [c,-x,x]=litAxiom c := by
  apply canonical_ext _ _ (canonical_normalize _ _) (canonical_litAxiom _)
  intro α
  change (clause [c,-x,x]).val α=(litAxiom c).val α
  rw [val_clause _ (by simp [Valid,hc,hx]),val_litAxiom c hc]
  simp only [sum_cons,sum_nil,litVal_neg α x hx];ring

theorem rotate (a b c:Int) (ha:a≠0) (hb:b≠0) (hc:c≠0) :
    clause [a,b,c]=clause [a,c,b] :=
  ProjectionTrace.clause_perm _ _ (by simp [Valid,ha,hb,hc]) (by simp [Valid,ha,hb,hc])
    (List.Perm.cons a (List.Perm.swap c b []))

def forwardSeeds (s:Refs) : Program :=
  [(clause [-s.gamma.val,-s.m.val,s.gamma.val],[.lit (-s.m.val)]),
   (clause [-s.gamma.val,-s.m.val,s.m.val],[.lit (-s.gamma.val)])]
def forwardRows (s:Refs) := outputs (forwardSeeds s)

theorem forward_seeds (s:Refs) (D:List Row) : check D (forwardSeeds s)=some (D++forwardRows s) := by
  apply IndependentProgram.check_base
  intro cmd hm
  simp only [forwardSeeds,List.mem_cons,List.not_mem_nil,or_false] at hm
  rcases hm with rfl|rfl
  · have he:clause [-s.gamma.val,-s.m.val,s.gamma.val]=litAxiom (-s.m.val):=by
      rw [ProjectionTrace.clause_perm _ [-s.m.val,-s.gamma.val,s.gamma.val]
        (by simp [Valid,s.gamma.property,s.m.property]) (by simp [Valid,s.gamma.property,s.m.property])
        (List.Perm.swap _ _ _)]
      exact complement_clause _ _ (neg_ne_zero.mpr s.m.property) s.gamma.property
    simp [polEval,he,s.m.property]
  · rw [complement_clause _ _ (neg_ne_zero.mpr s.gamma.property) s.m.property]
    simp [polEval,s.gamma.property]

def weakening (D:List Row) (c x m:Bit) := ChoiceProjection.weakenTokens D [-c.val,-x.val] [m.val]
theorem weakening_check (D:List Row) (c x m:Bit) (h:clause [-c.val,-x.val]∈D) :
    polEval (dbOf D) (weakening D c x m) []=some (clause [-c.val,m.val,-x.val]) := by
  have he:=ChoiceProjection.weaken_succeeds D [-c.val,-x.val] [m.val]
    (by simp [Valid,c.property,x.property]) (by simp [Valid,m.property]) h
  simpa only [weakening,List.cons_append,List.nil_append,
    rotate (-c.val) (-x.val) m.val (neg_ne_zero.mpr c.property) (neg_ne_zero.mpr x.property) m.property] using he

def backSeeds (s:Refs) (D:List Row) : Program :=
  [(clause [-s.gamma.val,s.m.val,-s.beta.val],weakening D s.gamma s.beta s.m),
   (clause [-s.gamma.val,s.m.val,-s.m.val],[.lit (-s.gamma.val)]),
   (clause [-s.gamma.val,s.m.val,-s.rank.val],weakening D s.gamma s.rank s.m)]
def backRows (s:Refs) :=
  [clause [-s.gamma.val,s.m.val,-s.beta.val],clause [-s.gamma.val,s.m.val,-s.m.val],
    clause [-s.gamma.val,s.m.val,-s.rank.val]]
theorem back_seeds (s:Refs) (D:List Row)
    (hb:clause [-s.gamma.val,-s.beta.val]∈D) (hr:clause [-s.gamma.val,-s.rank.val]∈D) :
    check D (backSeeds s D)=some (D++backRows s) := by
  apply IndependentProgram.check_base
  intro cmd hm
  simp only [backSeeds,List.mem_cons,List.not_mem_nil,or_false] at hm
  rcases hm with rfl|rfl|rfl
  · exact weakening_check D _ _ _ hb
  · have he:clause [-s.gamma.val,s.m.val,-s.m.val]=litAxiom (-s.gamma.val):=by
      simpa only [neg_neg] using complement_clause (-s.gamma.val) (-s.m.val)
        (neg_ne_zero.mpr s.gamma.property) (neg_ne_zero.mpr s.m.property)
    simp [polEval,he,s.gamma.property]
  · exact weakening_check D _ _ _ hr

def forwardBody (s:Refs) := forwardRows s++(gammaTree s true).rows [-s.gamma.val,-s.m.val]
def backwardBody (s:Refs) := backRows s++(gammaTree s false).rows [-s.gamma.val,s.m.val]
def forwardProgram (s:Refs) (D:List Row) := forwardSeeds s++
  (gammaTree s true).program [-s.gamma.val,-s.m.val] (D++forwardRows s)
def backwardProgram (s:Refs) (D:List Row) := backSeeds s D++
  (gammaTree s false).program [-s.gamma.val,s.m.val] (D++backRows s)

theorem forward_assumptions (s:Refs) (D:List Row) :
    (gammaTree s true).Assumptions (D++forwardRows s) [-s.gamma.val,-s.m.val] := by
  intro x hx
  simp only [gammaTree,Tree.leaves,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hx
  rcases hx with rfl|rfl <;> apply List.mem_append_right <;>
    simp [forwardRows,forwardSeeds,outputs,guarded,sign]
theorem backward_assumptions (s:Refs) (D:List Row) :
    (gammaTree s false).Assumptions (D++backRows s) [-s.gamma.val,s.m.val] := by
  intro x hx
  simp only [gammaTree,Tree.leaves,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hx
  rcases hx with (rfl|rfl)|rfl <;> apply List.mem_append_right <;> simp [backRows,guarded,sign]

theorem ready_mono {s:Refs} {D E:List Row} (h:s.Ready D) (hm:∀R∈D,R∈E) : s.Ready E :=
  ⟨h.1.mono hm,h.2.1.mono hm,h.2.2.1.mono hm,h.2.2.2.mono hm⟩

theorem forward_check (s:Refs) (D:List Row) (h:s.Ready D) :
    check D (forwardProgram s D)=some (D++forwardBody s) := by
  have h1:=forward_seeds s D
  have h2:=(gamma_checks s (D++forwardRows s) [-s.gamma.val,-s.m.val] true
    (by simp [Valid,s.gamma.property,s.m.property]) (ready_mono h (fun R hr=>List.mem_append_left _ hr))
    (forward_assumptions s D)).1
  simpa only [forwardProgram,forwardBody,List.append_assoc] using check_append _ _ _ _ _ h1 h2
theorem backward_check (s:Refs) (D:List Row) (h:s.Ready D)
    (hb:clause [-s.gamma.val,-s.beta.val]∈D) (hr:clause [-s.gamma.val,-s.rank.val]∈D) :
    check D (backwardProgram s D)=some (D++backwardBody s) := by
  have h1:=back_seeds s D hb hr
  have h2:=(gamma_checks s (D++backRows s) [-s.gamma.val,s.m.val] false
    (by simp [Valid,s.gamma.property,s.m.property]) (ready_mono h (fun R hr=>List.mem_append_left _ hr))
    (backward_assumptions s D)).1
  simpa only [backwardProgram,backwardBody,List.append_assoc] using check_append _ _ _ _ _ h1 h2

def program (s:Refs) (D:List Row) := forwardProgram s D++backwardProgram s (D++forwardBody s)
def rows (s:Refs) := forwardBody s++backwardBody s
theorem checks (s:Refs) (D:List Row) (h:s.Ready D)
    (hb:clause [-s.gamma.val,-s.beta.val]∈D) (hr:clause [-s.gamma.val,-s.rank.val]∈D) :
    check D (program s D)=some (D++rows s) := by
  have h1:=forward_check s D h
  have h2:=backward_check s (D++forwardBody s) (ready_mono h (fun R hr=>List.mem_append_left _ hr))
    (List.mem_append_left _ hb) (List.mem_append_left _ hr)
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h1 h2

theorem relations (s:Refs) : clause [-s.gamma.val,-s.m.val,s.q.val]∈rows s ∧
    clause [-s.gamma.val,-s.q.val,s.m.val]∈rows s := by
  constructor
  · simp [rows,forwardBody,gammaTree,Tree.rows,GuardedGatePOL.value,Tree.value,guarded,sign]
  · rw [rotate (-s.gamma.val) (-s.q.val) s.m.val (neg_ne_zero.mpr s.gamma.property)
      (neg_ne_zero.mpr s.q.property) s.m.property]
    simp [rows,backwardBody,gammaTree,Tree.rows,GuardedGatePOL.value,Tree.value,guarded,sign]

#print axioms checks
#print axioms relations
end L3Emitter.MixtureGamma

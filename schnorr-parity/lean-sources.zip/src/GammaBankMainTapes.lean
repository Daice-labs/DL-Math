import GlobalFixedMainTapes
namespace L3Emitter.GammaBankMainTapes
open EREF EREF.GeneralRED AliasProgram U2ConstructionSize GlobalFixedMainTapes

theorem choice_leaf (n : Nat) (hn : 2≤n) (j : GammaChoiceBank.Job n) (D : List Row) :
    tokens (GammaChoiceBank.program n hn j D)=23 := by
  simp [GammaChoiceBank.program,tokens,SelectedCategoryRows.gammaTape,GuardedJoin.tape,
    GammaChoiceBank.edgeTape,CommonGuardResolve.token_count]

theorem choices (n : Nat) (hn : 2≤n) : tokens (GammaChoiceBank.emitted n hn)≤31104*(n+1)^4 := by
  have h:=flat_factor (GammaChoiceBank.jobs n hn)
    (fun j=>GammaChoiceBank.program n hn j (ReceivingEdgeBank.result n hn)) 8 (by
      intro j hj;rw [choice_leaf];change 23≤8*3;decide)
  change tokens (GammaChoiceBank.emitted n hn)≤8*(GammaChoiceBank.emitted n hn).length at h
  exact h.trans ((Nat.mul_le_mul_left 8 (ConstructionValueBankCount.gamma_choice n hn)).trans_eq (by ring))

theorem unary_leaf (n : Nat) (hn : 2≤n) (j : BetaPort.Job n) (u side a b v : Bool) (D : List Row) :
    (GammaUnaryChoice.tape n hn j u side a b v D).length=16 := by
  simp [GammaUnaryChoice.tape,CommonGuardResolve.token_count,GammaUnaryChoice.Q,GammaUnaryChoice.K,
    UnaryValueStep.G,UnaryValueStep.H,LookupEvaluation.guards]

theorem cofactor_leaf (n : Nat) (hn : 2≤n) (j : BetaPort.Job n) (side a b v : Bool) (D : List Row) :
    (GammaCofactorValue.tape n hn j side a b v D).length=14 := by
  simp [GammaCofactorValue.tape,CommonGuardResolve.token_count,GammaCofactorValue.Q]

theorem comparison_leaf (n : Nat) (hn : 2≤n) (j : BetaPort.Job n) (u side a b v : Bool) (D : List Row) :
    (GammaComparison.tape n hn j u side a b v D).length=12 := by
  simp [GammaComparison.tape,CommonGuardResolve.token_count,GammaComparison.G,GammaComparison.H,GammaComparison.Q]

theorem comparisons (n : Nat) (hn : 2≤n) :
    tokens (GammaComparisonBank.emitted n hn)≤1990656*(n+1)^4*2^n := by
  have h0:=map_factor (GammaComparisonBank.unaryJobs n hn) (GammaComparisonBank.unaryRow n hn)
    (fun j=>GammaUnaryChoice.tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 (!j.2.2.2.2.2) (GammaComparisonBank.base n hn)) 16
    (by intro j hj;rw [unary_leaf])
  have h1:=map_factor (GammaComparisonBank.jobs n hn) (GammaComparisonBank.cofactorRow n hn)
    (fun j=>GammaCofactorValue.tape n hn j.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2 (GammaComparisonBank.base n hn)) 16
    (by intro j hj;rw [cofactor_leaf];decide)
  have h2:=map_factor (GammaComparisonBank.jobs n hn) (GammaComparisonBank.comparisonRow n hn)
    (fun j=>GammaComparison.tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2 (GammaComparisonBank.middle n hn)) 16
    (by intro j hj;rw [comparison_leaf];decide)
  dsimp only at h0 h1 h2
  have hb:tokens (GammaComparisonBank.emitted n hn)≤16*(GammaComparisonBank.emitted n hn).length:=by
    simp only [GammaComparisonBank.emitted,GammaComparisonBank.first,GammaComparisonBank.last,
      tokens_append,List.length_append,List.length_map]
    omega
  exact hb.trans ((Nat.mul_le_mul_left 16 (ConstructionValueBankCount.gamma_compare n hn)).trans_eq (by ring))
#print axioms choices
#print axioms comparisons
end L3Emitter.GammaBankMainTapes

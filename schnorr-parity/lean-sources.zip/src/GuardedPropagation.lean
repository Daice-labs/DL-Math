import GuardedValueComposition
namespace L3Emitter.GuardedPropagation
open EREF EREF.GeneralRED REDWitness ReferenceTransport CaseJoin GuardedGatePOL

def tape (D:List Row) (G:List Int) (a q:Int):List Tok:=
  [.ref (locate D (guarded G a)),.ref (locate D (GuardedJoin.link G a q)),.add,.lit q,.add,.div 2]

theorem sum_scaled (G:List Int) (a q:Int) (hg:Valid G) (ha:a≠0) (hq:q≠0):
    add (add (guarded G a) (GuardedJoin.link G a q)) (litAxiom q)=scaled 2 (guarded G q):=by
  apply canonical_ext _ _ (canonical_add _ _) (canonical_scaled 2 (by decide) _ (canonical_normalize _ _))
  intro α
  change (add (add (guarded G a) (GuardedJoin.link G a q)) (litAxiom q)).val α=(scaled 2 (guarded G q)).val α
  rw [val_add _ _ (canonical_add _ _) (canonical_litAxiom _),
    val_add (guarded G a) (GuardedJoin.link G a q) (canonical_normalize _ _) (canonical_normalize _ _),val_scaled]
  simp only [guarded,GuardedJoin.link,
    val_clause (G++[a]) (EvaluationCaseSeeds.valid_join hg (by simp [Valid,ha])),
    val_clause (G++[-a,q]) (EvaluationCaseSeeds.valid_join hg (by simp [Valid,ha,hq])),
    val_clause (G++[q]) (EvaluationCaseSeeds.valid_join hg (by simp [Valid,hq])),val_litAxiom q hq,
    sum_append,sum_cons,sum_nil,litVal_neg α a ha]
  ring

theorem checks (D:List Row) (G:List Int) (a q:Int) (hg:Valid G) (ha:a≠0) (hq:q≠0)
    (h1:guarded G a∈D) (h2:GuardedJoin.link G a q∈D):
    polEval (dbOf D) (tape D G a q) []=some (guarded G q):=by
  simp only [tape,polEval,locate_correct _ _ h1,locate_correct _ _ h2]
  rw [if_pos hq,sum_scaled G a q hg ha hq,
    divide_scaled 2 (by decide) (guarded G q) (canonical_normalize _ _)]
  rfl

theorem token_count (D:List Row) (G:List Int) (a q:Int):(tape D G a q).length=6:=rfl
#print axioms checks
end L3Emitter.GuardedPropagation

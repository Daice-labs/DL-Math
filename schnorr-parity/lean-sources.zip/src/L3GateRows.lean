import L3PortStep

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def ForceRecord (t : StI F.V) : Prop :=
  ∀g p,1≤g → g<F.s → p<2 → ∀c∈F.forceClauses g p (t.s.force g p),Cmd.rup c∈t.s.cmds

def PortRecord (g p bit cb q : Nat) (t : StI F.V) : Prop :=
  Cmd.eqDef q (F.port g p (F.bitX bit) : Int) (F.port g p (F.bitY bit) : Int)∈t.s.cmds ∧
  Cmd.rup (F.wireCoverC t g p cb q)∈t.s.cmds ∧
  Cmd.rup (F.wireForceC t g p)∈t.s.cmds ∧ 1≤q ∧ q≤t.s.var

theorem ForceRecord_keeps {t u : StI F.V} (hk : Keeps2 t u) (hf : F.ForceRecord t) : F.ForceRecord u := by
  intro g p hg1 hg hp c hc
  rw [hk.2.2.2.1] at hc
  exact mem_of_grows hk.1 (hf g p hg1 hg hp c hc)

theorem PortRecord_keeps {t u : StI F.V} (hk : Keeps2 t u) (g p bit cb q : Nat)
    (hr : F.PortRecord g p bit cb q t) : F.PortRecord g p bit cb q u := by
  refine ⟨mem_of_grows hk.1 hr.1,?_,?_,hr.2.2.2.1,Nat.le_trans hr.2.2.2.2 (var_le_of_grows hk.1)⟩
  · have eq : F.wireCoverC u g p cb q=F.wireCoverC t g p cb q := by
      simp only [wireCoverC,hk.2.1.1,hk.2.2.2.2.2.2]
    rw [eq]; exact mem_of_grows hk.1 hr.2.1
  · have eq : F.wireForceC u g p=F.wireForceC t g p := by
      simp only [wireForceC,hk.2.1.1,hk.2.2.2.1,hk.2.2.2.2.2.2]
    rw [eq]; exact mem_of_grows hk.1 hr.2.2.1

theorem portEqStep_record (hk : 2≤F.k) (hm : 1≤F.V) (g p bit cb : Nat) (t : StI F.V)
    (ht : F.Good3 t) (hg1 : 1≤g) (hg : g<F.s) (hp : p<2) (hb : bit<2)
    (hc : 1≤cb ∧ cb≤t.s.var) (hr : ∀h<g,F.GateRecord bit cb h t) :
    F.PortRecord g p bit cb (t.s.var+1) (F.portEqStep hm g bit cb t p) := by
  rw [F.portEqStep_factor]
  let u := F.wireStart hm g p bit t
  let q := t.s.var+1
  have hi := F.wireStart_inv hk hm g p bit cb t ht hg hp hb hc hr
  let v := F.wireSplits g p bit cb q u
  have kv : Keeps2 u v := keeps2_foldl _ _ (F.wireSplit_keeps g p bit cb q) u
  have vv : v.s.veq=u.s.veq := StI.foldl_proj (fun (t : StI F.V) => t.s.veq) _ _ (F.wireSplit_veq g p bit cb q) u
  have hiv : F.WireInv g p bit cb q v := F.WireInv_keeps _ _ _ _ _ kv vv hi
  have kw : Keeps2 v (F.wireFinish g p cb q v) := keeps2_trans (keeps2_rup _ _) (keeps2_rup _ _)
  change F.PortRecord g p bit cb q (F.wireFinish g p cb q v)
  refine ⟨mem_of_grows kw.1 hiv.2.2.1,?_,?_,hiv.2.2.2.2.1,Nat.le_trans hiv.2.2.2.2.2 (var_le_of_grows kw.1)⟩
  · change Cmd.rup (F.wireCoverC v g p cb q)∈(F.wireFinish g p cb q v).s.cmds
    rw [F.wireFinish_commands hk v g p bit cb q hg1 hg hp hiv]
    simp
  · change Cmd.rup (F.wireForceC v g p)∈(F.wireFinish g p cb q v).s.cmds
    rw [F.wireFinish_commands hk v g p bit cb q hg1 hg hp hiv]
    simp

theorem t4_forceRecord (hs : 1≤F.s) : F.ForceRecord (F.t4 hs) := by
  have ht : F.Good3 (F.t3 hs) := F.good3_stage3 hs
  have hk := F.keeps2_stage4 (F.t3 hs)
  intro g p hg1 hg hp c hc
  unfold t4 at hc
  rw [hk.2.2.2.1] at hc
  have hbounds : ∀gp∈F.pairs4,1≤(F.t3 hs).s.force gp.1 gp.2 ∧ (F.t3 hs).s.force gp.1 gp.2≤(F.t3 hs).s.var := by
    intro gp hgp
    obtain ⟨hg1,hg,hp⟩ := (F.mem_pairs4 gp).mp hgp
    have hh := (ht.2.2.1 gp.1 gp.2 hg1 hg hp).2.2.1.2
    exact ⟨by omega,hh.2⟩
  change Cmd.rup c ∈ (F.stage4 (F.t3 hs)).s.cmds
  rw [F.stage4_cmds _ hbounds]
  apply List.mem_append_right
  exact List.mem_flatMap.mpr ⟨(g,p),(F.mem_pairs4 (g,p)).mpr ⟨hg1,hg,hp⟩,
    List.mem_map.mpr ⟨c,hc,rfl⟩⟩

#print axioms portEqStep_record
#print axioms t4_forceRecord
end L3.Fam

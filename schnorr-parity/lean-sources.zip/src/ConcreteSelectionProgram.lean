import ConcreteSelection

namespace L3Emitter.ConcreteSelectionProgram
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteSelection
open AliasClauseTransport AliasProgram
variable {base : List Row}

def body (es : List Cell) (q : AliasNetwork.Bit) (todo : List Cell) :=
  todo.flatMap (fun e=>bitRows e.choice.val (ConcreteSelection.bit es q e))
def program (D : List Row) (es : List Cell) (q : AliasNetwork.Bit) : List Cell→Program
  | [] => []
  | e::rest => bitProgram D e.choice.val (ConcreteSelection.bit es q e)++
      program (D++bitRows e.choice.val (ConcreteSelection.bit es q e)) es q rest

theorem check_program (D : List Row) (es todo : List Cell) (q : AliasNetwork.Bit)
    (hi : ∀e∈todo,BitInputs D e.choice.val (ConcreteSelection.bit es q e)) :
    check D (program D es q todo)=some (D++body es q todo) := by
  induction todo generalizing D with
  | nil => simp [program,body,check]
  | cons e rest ih =>
    have h1:=bit_check D e.choice.val (ConcreteSelection.bit es q e) (hi e (by simp))
    have h2:=ih (D++bitRows e.choice.val (ConcreteSelection.bit es q e)) (by
      intro z hz
      exact (hi z (by simp [hz])).mono (fun R hR=>List.mem_append_left _ hR))
    simpa [program,body,List.append_assoc] using check_append _ _ _ _ _ h1 h2

def result (xs : List (AliasNetwork.Bit×AliasNetwork.Bit)) (z : Net base) :=
  (select xs z).2.rows++body (cells xs z) (select xs z).1 (cells xs z)
def emitted (xs : List (AliasNetwork.Bit×AliasNetwork.Bit)) (z : Net base) :=
  program (select xs z).2.rows (cells xs z) (select xs z).1 (cells xs z)

theorem all_check (xs : List (AliasNetwork.Bit×AliasNetwork.Bit)) (z : Net base)
    (hn : (xs.map (fun p=>p.1.val)).Nodup)
    (ham : ∀a∈xs,∀b∈xs,a.1.val≠b.1.val→clause [-a.1.val,-b.1.val]∈z.rows) :
    check (select xs z).2.rows (emitted xs z)=some (result xs z) := by
  apply check_program
  intro e he
  simpa only [select_binding] using inputs xs z hn ham e he

theorem trace (xs : List (AliasNetwork.Bit×AliasNetwork.Bit)) (z : Net base)
    (hn : (xs.map (fun p=>p.1.val)).Nodup)
    (ham : ∀a∈xs,∀b∈xs,a.1.val≠b.1.val→clause [-a.1.val,-b.1.val]∈z.rows) :
    CheckedTrace base (result xs z) :=
  L3.Fam.checkedTrace_trans (select xs z).2.checked
    (check_trace _ _ _ (all_check xs z hn ham))

theorem relation (xs : List (AliasNetwork.Bit×AliasNetwork.Bit)) (z : Net base)
    (e : Cell) (he : e∈cells xs z) :
    clause [-e.choice.val,-e.value.val,(select xs z).1.val]∈result xs z ∧
    clause [-e.choice.val,-(select xs z).1.val,e.value.val]∈result xs z := by
  constructor <;> apply List.mem_append_right <;> apply List.mem_flatMap.mpr
  · exact ⟨e,he,by simp [bitRows,ConcreteSelection.bit]⟩
  · exact ⟨e,he,by simp [bitRows,ConcreteSelection.bit]⟩

theorem output_rows (D : List Row) (es todo : List Cell) (q : AliasNetwork.Bit) :
    outputs (program D es q todo)=body es q todo := by
  induction todo generalizing D with
  | nil => rfl
  | cons e rest ih =>
    simpa [program,outputs,bitProgram,body,bitRows,List.flatMap_cons] using
      congrArg (fun rs=>bitRows e.choice.val (ConcreteSelection.bit es q e)++rs)
        (ih (D++bitRows e.choice.val (ConcreteSelection.bit es q e)))

theorem commands_count (D : List Row) (es todo : List Cell) (q : AliasNetwork.Bit) :
    (program D es q todo).length=2*todo.length := by
  induction todo generalizing D with
  | nil => rfl
  | cons e rest ih => simp [program,bitProgram,ih];omega

#print axioms all_check
#print axioms trace
#print axioms relation
#print axioms output_rows
#print axioms commands_count
end L3Emitter.ConcreteSelectionProgram

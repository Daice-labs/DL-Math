import NumericNetwork
namespace L3Emitter.NumericNetwork
open EREF EREF.GeneralRED AliasNetwork
variable {base:List Row} {A:Type}

/-- A budget for a stateful bit producer. Existing external variables fit K;
subsequent allocations may start at any larger namespace ceiling. -/
def Produces (K c:Nat) (p:StateM (Net base) Bit):Prop :=
  ∀ M, K≤M → ∀z, CanonicalTrace.ceiling z.rows≤M → ResultBound (M+c) (p z)

theorem map_bits (K c:Nat) (xs:List A) (f:A→StateM (Net base) Bit)
    (hf:∀a∈xs,Produces K c (f a)) (M:Nat) (hM:K≤M) (z:Net base)
    (hz:CanonicalTrace.ceiling z.rows≤M):
    (∀b∈(xs.mapM f z).1, BitBound (M+xs.length*c) b) ∧
      CanonicalTrace.ceiling (xs.mapM f z).2.rows≤M+xs.length*c :=by
  induction xs generalizing M z with
  | nil=>
    simp only [List.mapM_nil,List.length_nil,Nat.zero_mul,Nat.add_zero]
    exact ⟨fun b hb=>False.elim (List.not_mem_nil hb),hz⟩
  | cons a as ih=>
    have ha:=hf a (by simp) M hM z hz
    have ht:=ih (by intro a ha;exact hf a (by simp [ha])) (M+c) (by omega) (f a z).2 ha.2
    rw [List.mapM_cons]
    constructor
    · intro b hb
      change b∈(f a z).1::(as.mapM f (f a z).2).1 at hb
      simp only [List.mem_cons] at hb
      rcases hb with rfl|hb
      · exact ha.1.trans (by simp only [List.length_cons,Nat.add_mul];omega)
      · have h:=ht.1 b hb
        simpa only [List.length_cons,Nat.add_mul,Nat.one_mul,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using h
    · change CanonicalTrace.ceiling (as.mapM f (f a z).2).2.rows≤_
      simpa only [List.length_cons,Nat.add_mul,Nat.one_mul,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using ht.2

theorem select (M:Nat) (z:Net base) (xs:List (Bit×Bit))
    (hz:CanonicalTrace.ceiling z.rows≤M)
    (hx:∀p∈xs,BitBound M p.1 ∧ BitBound M p.2):
    ResultBound (M+xs.length+1) (AliasNetwork.select xs z):=by
  have hs:=map_bits M 1 xs (fun p=>AND [p.1,p.2]) (by
    intro p hp N hN u hu
    apply gate N u true [p.1,p.2] hu
    intro x hh
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hh
    rcases hh with rfl|rfl
    · exact (hx p hp).1.trans hN
    · exact (hx p hp).2.trans hN) M (by omega) z hz
  have h:=gate (M+xs.length) (xs.mapM (fun p=>AND [p.1,p.2]) z).2 false
    (xs.mapM (fun p=>AND [p.1,p.2]) z).1 (by simpa using hs.2) (by simpa using hs.1)
  exact h

theorem tabulate (K c n:Nat) (f:Fin n→StateM (Net base) Bit)
    (hf:∀i,Produces K c (f i)) (M:Nat) (hM:K≤M) (z:Net base)
    (hz:CanonicalTrace.ceiling z.rows≤M):
    (∀i,BitBound (M+n*c) ((AliasNetwork.tabulate n f z).1 i)) ∧
      CanonicalTrace.ceiling (AliasNetwork.tabulate n f z).2.rows≤M+n*c :=by
  induction n generalizing M z with
  | zero=>
    simp only [Nat.zero_mul,Nat.add_zero]
    exact ⟨fun i=>Fin.elim0 i,hz⟩
  | succ n ih=>
    have ha:=hf 0 M hM z hz
    have ht:=ih (fun i=>f i.succ) (fun i=>hf i.succ) (M+c) (by omega) (f 0 z).2 ha.2
    constructor
    · intro i
      refine Fin.cases ?_ (fun j=>?_) i
      · exact ha.1.trans (by simp only [Nat.add_mul,Nat.one_mul];omega)
      · have h:=ht.1 j
        simpa only [Nat.add_mul,Nat.one_mul,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using h
    · change CanonicalTrace.ceiling (AliasNetwork.tabulate n (fun i=>f i.succ) (f 0 z).2).2.rows≤_
      simpa only [Nat.add_mul,Nat.one_mul,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using ht.2

#print axioms map_bits
#print axioms select
#print axioms tabulate
end L3Emitter.NumericNetwork

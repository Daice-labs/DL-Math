import ForcingProgram
import SelectionBounds

namespace L3Emitter.ForcingBounds
open EREF EREF.GeneralRED REDWitness RankProjection
open SelectionBounds ForcingBinding

def ceiling (k : Nat) (hk : 3≤k) := (FrontendSelection.front k hk).s.var+1+2*(FrontendSelection.xs k hk).length

theorem front_bounded (k : Nat) (hk : 3≤k) :
    L3.DBBounded (FrontendSelection.finalRows k hk) (ceiling k hk) := by
  let F:=FableEncoding.fam k (3*k-4)
  let t:=FrontendSelection.front k hk
  have h:=L3.exec_bounded F.db5 F.V t.s.cmds
    (F.db5_bounded (by change 1≤k;omega) (by change 1≤3*k-4;omega)) t.inv.1
  rw [t.inv.2] at h
  have hx:=F.branchList_bounded (FrontendSelection.prior k hk)
  exact selected_bounded _ _ _ (h.append (L3.clauseRow _) hx) hx

theorem choice_bound (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (hc : c∈BranchChoices.chosen k hk) :
    LB (ceiling k hk) c.lit := by
  have hmem : c.lit∈(BranchChoices.chosen k hk).map Choice.lit := List.mem_map.mpr ⟨c,hc,rfl⟩
  rw [BranchChoices.chosen_literals] at hmem
  obtain ⟨n,hn,he⟩:=List.mem_map.mp hmem
  have hb:=PrioritySerialization.allocated_bound ((FrontendSelection.front k hk).s.var+1) (FrontendSelection.xs k hk) n hn
  have hp:=PriorityPrefix.allocated_good ((FrontendSelection.front k hk).s.var+1) (FrontendSelection.xs k hk)
    (L3.bounded_nz ((FableEncoding.fam k (3*k-4)).branchList_bounded (FrontendSelection.prior k hk))) n hn
  rw [←he];change 1≤n.choice ∧ n.choice≤ceiling k hk
  exact ⟨by omega,hb.1⟩

theorem varAfter_ge (m : Nat) (cs : List L3.Cmd) : m≤L3.varAfter m cs := by
  induction cs generalizing m with
  | nil => exact Nat.le_refl _
  | cons cmd cs ih => cases cmd <;> simp only [L3.varAfter] <;> have:=ih (m+1) <;> have:=ih m <;> omega

theorem or_output_bound (m : Nat) (cs : List L3.Cmd) (hw : L3.WF m cs) (q : Nat) (xs : List Int)
    (hq : L3.Cmd.orDef q xs∈cs) : q≤L3.varAfter m cs := by
  induction cs generalizing m with
  | nil => simp at hq
  | cons cmd cs ih =>
    rcases List.mem_cons.mp hq with rfl|hmem
    · have he:=hw.1;have:=varAfter_ge (m+1) cs;simp only [L3.varAfter];omega
    · cases cmd with
      | orDef a ys => exact ih (m+1) hw.2.2 hmem
      | andDef a ys => exact ih (m+1) hw.2.2 hmem
      | eqDef a b c => exact ih (m+1) hw.2.2 hmem
      | rup ys => exact ih m hw.2 hmem

theorem actual_bounds (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (hc : c∈BranchChoices.chosen k hk) :
    L3.Bounded (ceiling k hk) (ForcingBinding.input k hk c).lits ∧
    LB (ceiling k hk) (eligible k hk c) ∧ LB (ceiling k hk) (consumer k hk c) ∧
    LB (ceiling k hk) (port k hk c 0 0).p ∧ LB (ceiling k hk) (port k hk c 1 0).p := by
  let F:=FableEncoding.fam k (3*k-4)
  let t:=FrontendSelection.front k hk
  have hg:= (F.final_branch_ready (FrontendSelection.prior k hk) (FrontendSelection.prior_good k hk)).1
  change F.Good3 t at hg
  have hbeta : c.beta<F.s := by change c.beta<3*k-4;have:=c.ordered;have:=c.gamma_lt;omega
  have hbpos : 1≤c.beta := by have:=c.beta_pos;omega
  obtain ⟨he00,he01,hf0,hp0⟩:=hg.2.2.1 c.beta 0 hbpos hbeta (by decide)
  obtain ⟨he10,he11,hf1,hp1⟩:=hg.2.2.1 c.beta 1 hbpos hbeta (by decide)
  obtain ⟨q,hq,hel,hqp,hep,heu⟩:=hg.2.2.2.1 c.beta hbpos hbeta
  have hco:=ConsumerLookup.frontend_consumer k hk c
  have hcb:=or_output_bound F.V t.s.cmds t.inv.1 _ _ hco.1
  rw [t.inv.2] at hcb
  change ConsumerLookup.consumer F t c.beta≤t.s.var at hcb
  have hV:=t.inv.2
  have hVle : F.V≤t.s.var := by rw [←hV];exact varAfter_ge _ _
  have hm : t.s.var≤ceiling k hk := by dsimp [t,ceiling];omega
  have hs0:=F.sel_pos c.beta 0 0
  have hs1:=F.sel_pos c.beta 1 0
  have hsb0:=F.sel_le_S c.beta 0 0 hbeta (by decide) (by have:=c.beta_pos;omega)
  have hsb1:=F.sel_le_S c.beta 1 0 hbeta (by decide) (by have:=c.beta_pos;omega)
  have hSV : F.S≤F.V := by unfold L3.Fam.V;omega
  have hb:=choice_bound k hk c hc
  have eq00 : F.V<t.s.eqrow c.beta 0 0 ∧ t.s.eqrow c.beta 0 0≤t.s.var := he00.2
  have eq01 : F.V<t.s.eqrow c.beta 0 1 ∧ t.s.eqrow c.beta 0 1≤t.s.var := he01.2
  have eq10 : F.V<t.s.eqrow c.beta 1 0 ∧ t.s.eqrow c.beta 1 0≤t.s.var := he10.2
  have eq11 : F.V<t.s.eqrow c.beta 1 1 ∧ t.s.eqrow c.beta 1 1≤t.s.var := he11.2
  have el : F.V<t.s.eligible c.beta ∧ t.s.eligible c.beta≤t.s.var := ⟨hep,heu⟩
  have po0 : F.V<t.s.p0force c.beta 0 ∧ t.s.p0force c.beta 0≤t.s.var := hp0.2
  have po1 : F.V<t.s.p0force c.beta 1 ∧ t.s.p0force c.beta 1≤t.s.var := hp1.2
  have cp : F.V<ConsumerLookup.consumer F t c.beta := hco.2.2
  constructor
  · change L3.Bounded (ceiling k hk) [c.lit,(F.sel c.beta 0 0:Int),(F.sel c.beta 1 0:Int),
      (t.s.eqrow c.beta 0 0:Int),(t.s.eqrow c.beta 0 1:Int),(t.s.eqrow c.beta 1 0:Int),(t.s.eqrow c.beta 1 1:Int)]
    intro l hl;simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact hb
    all_goals rw [Int.natAbs_natCast];constructor <;> omega
  change (1≤t.s.eligible c.beta ∧ t.s.eligible c.beta≤ceiling k hk) ∧
    (1≤ConsumerLookup.consumer F t c.beta ∧ ConsumerLookup.consumer F t c.beta≤ceiling k hk) ∧
    (1≤t.s.p0force c.beta 0 ∧ t.s.p0force c.beta 0≤ceiling k hk) ∧
    (1≤t.s.p0force c.beta 1 ∧ t.s.p0force c.beta 1≤ceiling k hk)
  omega

#print axioms front_bounded
#print axioms actual_bounds
end L3Emitter.ForcingBounds

import CanonicalScopedBytes

namespace L3Emitter.CanonicalScopeKernel
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

/-- Only data actually needed in the proof file: no expected store or cached
checked result is carried into the checker. -/
structure LocalProof where
  tapes : List (List Tok)
  conclusion : Nat

def stripLocal (b : NativeScopedLocalGoal.Built) : LocalProof := ⟨b.tapes,b.conclusion⟩
def restore (p : LocalProof) : NativeScopedLocalGoal.Built :=
  ⟨p.tapes,p.conclusion,initial [],initial []⟩

inductive GoalKey where
  | candidate
  | database (id : Nat)
  deriving DecidableEq

def keyAt (ids : Nat→Nat) (i : Nat) : GoalKey := if i=0 then .candidate else .database (ids i)
def keys (ids : Nat→Nat) (i : Nat) : Nat→List GoalKey
  | 0=>[]
  | m+1=>keyAt ids i::keys ids (i+1) m

structure Goal where
  key : GoalKey
  proof : LocalProof

def packGoals (ids : Nat→Nat) (i : Nat) : List (EREF.Row×NativeScopedLocalGoal.Built)→List Goal
  | []=>[]
  | (_,b)::bs=>⟨keyAt ids i,stripLocal b⟩::packGoals ids (i+1) bs

def restoreGoals : List EREF.Row→List Goal→List (EREF.Row×NativeScopedLocalGoal.Built)
  | R::rs,g::gs=>(R,restore g.proof)::restoreGoals rs gs
  | _,_=>[]

inductive Command where
  | pol (tape : List Tok)
  | consequence (row : EREF.Row) (proof : LocalProof)
  | red (row : EREF.Row) (witness : FiniteWitness.Data) (goals : List Goal)

def pack (ids : Nat→Nat) : NativeRecordedStep.Action→Command
  | .pol ts=>.pol ts
  | .consequence R b=>.consequence R (stripLocal b)
  | .red R w bs=>.red R w (packGoals ids 0 bs)

/-- Strict fragment semantics: RED goal coverage and ordering are checked;
all temporary assumptions and deletions use the proved physical row store.
This is not yet a refinement theorem for the Rust parser or arithmetic. -/
def execute (D : List EREF.Row) (s : Store) (ids : Nat→Nat) : Command→Option Store
  | .pol ts=>NativeRecordedStep.execute D s (.pol ts)
  | .consequence R p=>NativeRecordedStep.execute D s (.consequence R (restore p))
  | .red R w gs=>
    if gs.map Goal.key=keys ids 0 (D.length+1) then
      NativeRecordedStep.execute D s (.red R w
        (restoreGoals ((R::D).map (fun T=>substRow T (FiniteWitness.interpret w))) gs))
    else none

theorem local_execution (s : Store) (G : EREF.Row) (b : NativeScopedLocalGoal.Built) :
    NativeScopedLocalGoal.execute s G (restore (stripLocal b))=NativeScopedLocalGoal.execute s G b := rfl

theorem goal_execution (s : Store) (bs : List (EREF.Row×NativeScopedLocalGoal.Built)) :
    NativeREDGoalSequence.execute s (bs.map (fun b=>(b.1,restore (stripLocal b.2))))=
      NativeREDGoalSequence.execute s bs := by
  induction bs generalizing s with
  | nil=>rfl
  | cons b bs ih=>
    simp only [List.map_cons,NativeREDGoalSequence.execute,local_execution]
    cases h:NativeScopedLocalGoal.execute s b.1 b.2 <;> simp [h,ih]

theorem pack_keys (ids : Nat→Nat) (i : Nat) (bs : List (EREF.Row×NativeScopedLocalGoal.Built)) :
    (packGoals ids i bs).map Goal.key=keys ids i bs.length := by
  induction bs generalizing i with
  | nil=>rfl
  | cons b bs ih=>simp only [packGoals,List.map_cons,List.length_cons,keys,ih]

theorem restore_pack (ids : Nat→Nat) (i : Nat) (bs : List (EREF.Row×NativeScopedLocalGoal.Built)) :
    restoreGoals (bs.map Prod.fst) (packGoals ids i bs)=
      bs.map (fun b=>(b.1,restore (stripLocal b.2))) := by
  induction bs generalizing i with
  | nil=>rfl
  | cons b bs ih=>simp only [List.map_cons,packGoals,restoreGoals,ih]

theorem erased_red_execution (D : List EREF.Row) (s : Store) (R : EREF.Row)
    (w : FiniteWitness.Data) (bs : List (EREF.Row×NativeScopedLocalGoal.Built)) :
    NativeRecordedStep.execute D s (.red R w (bs.map (fun b=>(b.1,restore (stripLocal b.2)))))=
      NativeRecordedStep.execute D s (.red R w bs) := by
  simp only [NativeRecordedStep.execute,List.map_map,Function.comp_def]
  have hr : bs.map (fun b=>(b.1,restore (stripLocal b.2)).1)=bs.map Prod.fst:=rfl
  rw [hr,goal_execution]

/-- Erasing all cached stores and expected per-goal rows preserves execution
for every compiled accepted step; those rows are reconstructed from the
current database and witness instead. -/
theorem step_correct (M guard : Nat) (D : List EREF.Row) (s : Store) (ids : Nat→Nat)
    (c : Step) (hc : c.accepts M guard D=true) :
    execute D s ids (pack ids (NativeRecordedStep.compile D s ids c).action)=
      NativeRecordedStep.execute D s (NativeRecordedStep.compile D s ids c).action := by
  cases c with
  | pol R ts=>rfl
  | consequence R p=>rfl
  | red R w ps=>
    have hg:checkGoals D R w (R::D) ps=true:=(Bool.and_eq_true_iff.mp hc).2
    let bs:=(NativeREDGoalSequence.compile D R w (push s (negate R))
      (extend ids D.length s.next) (R::D) ps).blocks
    have rows:bs.map Prod.fst=(R::D).map (fun T=>substRow T (FiniteWitness.interpret w)):=
      NativeRecordedStep.goal_rows D R w _ _ _ _ hg
    have hl:bs.length=D.length+1:=by
      have h:=congrArg List.length rows
      simpa using h
    change execute D s ids (.red R w (packGoals ids 0 bs))=
      NativeRecordedStep.execute D s (.red R w bs)
    simp only [execute,pack_keys,hl,↓reduceIte]
    rw [←rows,restore_pack,erased_red_execution]

/-- Executable stream of metadata-free commands. -/
def compile (D : List EREF.Row) (s : Store) (ids : Nat→Nat) : Program→List Command
  | []=>[]
  | c::cs=>let b:=NativeRecordedStep.compile D s ids c
    pack ids b.action::compile (D++[c.row]) b.store b.ids cs

def run (D : List EREF.Row) (s : Store) (ids : Nat→Nat) : List Command→Option Store
  | []=>some s
  | c::cs=>do
    let t←execute D s ids c
    let R←t.rows (t.next-1)
    run (D++[R]) t (extend ids D.length (t.next-1)) cs

theorem compiled_ids (D : List EREF.Row) (s : Store) (ids : Nat→Nat) (c : Step) :
    (NativeRecordedStep.compile D s ids c).ids=
      extend ids D.length ((NativeRecordedStep.compile D s ids c).store.next-1) := by
  cases c <;> simp only [NativeRecordedStep.compile,push,closeFrom,Nat.add_sub_cancel]

theorem correct (M guard : Nat) (D E : List EREF.Row) (s : Store) (ids : Nat→Nat)
    (p : Program) (hs : 0<s.next) (he : Embeds D s ids)
    (hp : check M guard D p=some E) :
    run D s ids (compile D s ids p)=some (NativeRecordedProgram.compile D s ids p).store := by
  induction p generalizing D s ids with
  | nil=>rfl
  | cons c cs ih=>
    simp only [check] at hp
    split at hp
    · rename_i hc
      have h:=NativeRecordedStep.correct M guard D s ids c hs he hc
      simp only [compile,run,step_correct M guard D s ids c hc,h.1,bind,Option.bind,
        NativeRecordedProgram.last_row]
      rw [←compiled_ids]
      exact ih _ _ _ h.2.2 h.2.1 hp
    · contradiction

#print axioms local_execution
#print axioms goal_execution
#print axioms step_correct
#print axioms correct
end L3Emitter.CanonicalScopeKernel

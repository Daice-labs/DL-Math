import CircuitEncoding

namespace L3Emitter.CircuitLowerBound
open EREF EREF.GeneralRED FamilyNamespace InputSwap CircuitEncoding
open L3Uniform.Circuit L3Uniform.Alias
set_option autoImplicit false

def cutoff (h : High) (out : Nat) : Nat := if out<h.k then 0 else out-h.k+1

def projection : Table := ⟨false,false,true,true⟩

theorem projection_allowed : projection.allowed := by simp [projection,Table.allowed]
@[simp] theorem projection_eval (a b : Bool) : projection.eval a b=a := by
  cases a <;> cases b <;> rfl

def padded (h : High) (out T : Nat) : High :=
  ⟨h.k,T,(fun t => if t<cutoff h out then h.left t else out),
    (fun t => if t<cutoff h out then h.right t else out),
    (fun t => if t<cutoff h out then h.table t else projection)⟩

def paddedValues (h : High) (out : Nat) (gs : Nat → Nat → Bool) (x t : Nat) : Bool :=
  if t<cutoff h out then gs x t else highValue h (bit h.k x) (gs x) out

theorem cutoff_le (h : High) (out : Nat) (ho : out<h.k+h.s) : cutoff h out≤h.s := by
  unfold cutoff; split_ifs <;> omega

theorem output_before_cutoff (h : High) (out : Nat) : out<h.k+cutoff h out := by
  unfold cutoff; split_ifs <;> omega

theorem old_wire (h : High) (out T : Nat) (gs : Nat → Nat → Bool) (x i : Nat)
    (hi : i<h.k+cutoff h out) :
    highValue (padded h out T) (bit h.k x) (paddedValues h out gs x) i =
      highValue h (bit h.k x) (gs x) i := by
  unfold highValue
  change (if i<h.k then bit h.k x i else paddedValues h out gs x (i-h.k)) = _
  by_cases hj : i<h.k
  · simp [hj]
  · simp [hj,paddedValues,show i-h.k<cutoff h out by omega]

theorem padded_topology (h : High) (out T : Nat) (ho : out<h.k+h.s)
    (topo : ∀ t, t<h.s → h.left t<h.k+t ∧ h.right t<h.k+t) :
    ∀ t, t<(padded h out T).s →
      (padded h out T).left t<(padded h out T).k+t ∧
      (padded h out T).right t<(padded h out T).k+t := by
  intro t ht
  have hc := cutoff_le h out ho
  have hout := output_before_cutoff h out
  by_cases hg : t<cutoff h out
  · simpa [padded,hg] using topo t (by omega)
  · simp only [padded,if_neg hg]
    constructor <;> omega

theorem padded_allowed (h : High) (out T : Nat) (ho : out<h.k+h.s)
    (allowed : ∀ t, t<h.s → (h.table t).allowed) :
    ∀ t, t<(padded h out T).s → ((padded h out T).table t).allowed := by
  intro t ht
  have hc := cutoff_le h out ho
  by_cases hg : t<cutoff h out
  · simpa [padded,hg] using allowed t (by omega)
  · simpa [padded,hg] using projection_allowed

theorem padded_evaluates (h : High) (out T : Nat) (ho : out<h.k+h.s)
    (gs : Nat → Nat → Bool)
    (topo : ∀ t, t<h.s → h.left t<h.k+t ∧ h.right t<h.k+t)
    (evals : ∀ x, x<truthRows h.k → Evaluates h (bit h.k x) (gs x)) :
    ∀ x, x<truthRows (padded h out T).k →
      Evaluates (padded h out T) (bit (padded h out T).k x) (paddedValues h out gs x) := by
  intro x hx t ht
  have hc := cutoff_le h out ho
  by_cases hg : t<cutoff h out
  · have hts : t<h.s := by omega
    have hl := old_wire h out T gs x (h.left t) (by have := (topo t hts).1; omega)
    have hr := old_wire h out T gs x (h.right t) (by have := (topo t hts).2; omega)
    change paddedValues h out gs x t = _
    simp only [paddedValues,hg,↓reduceIte]
    rw [show (padded h out T).table t=h.table t by simp [padded,hg],
      show (padded h out T).left t=h.left t by simp [padded,hg],
      show (padded h out T).right t=h.right t by simp [padded,hg]]
    change gs x t = (h.table t).eval
      (highValue (padded h out T) (bit h.k x) (paddedValues h out gs x) (h.left t))
      (highValue (padded h out T) (bit h.k x) (paddedValues h out gs x) (h.right t))
    rw [hl,hr]
    exact evals x hx t hts
  · have hv := old_wire h out T gs x out (output_before_cutoff h out)
    change paddedValues h out gs x t = _
    simp only [paddedValues,hg,↓reduceIte]
    rw [show (padded h out T).table t=projection by simp [padded,hg],
      show (padded h out T).left t=out by simp [padded,hg],
      show (padded h out T).right t=out by simp [padded,hg]]
    change highValue h (bit h.k x) (gs x) out = projection.eval
      (highValue (padded h out T) (bit h.k x) (paddedValues h out gs x) out)
      (highValue (padded h out T) (bit h.k x) (paddedValues h out gs x) out)
    rw [projection_eval,hv]

theorem padded_output (h : High) (out T : Nat) (hT : 0<T)
    (hc : cutoff h out≤T) (gs : Nat → Nat → Bool) (x : Nat) :
    paddedValues h out gs x (T-1) = highValue h (bit h.k x) (gs x) out := by
  by_cases hg : T-1<cutoff h out
  · have he : cutoff h out=T := by omega
    have hn : ¬out<h.k := by intro h; simp [cutoff,h] at he; omega
    have hid : out-h.k=T-1 := by simp [cutoff,hn] at he; omega
    simp [paddedValues,hg,highValue,hn,hid]
  · simp [paddedValues,hg]

/-- Schnorr's U2 lower bound, in the conventional gate-count model: arbitrary
    output wire, arbitrary fanout, ordered two-input gates, all tables except
    XOR/XNOR, and no free complemented wires. Includes zero-gate circuits.
    This is the lower bound, not a certificate-size or native-emitter theorem. -/
theorem schnorr_lower_bound (h : High) (hk : 2≤h.k) (out : Nat) (ho : out<h.k+h.s)
    (topo : ∀ t, t<h.s → h.left t<h.k+t ∧ h.right t<h.k+t)
    (allowed : ∀ t, t<h.s → (h.table t).allowed)
    (gs : Nat → Nat → Bool)
    (evals : ∀ x, x<truthRows h.k → Evaluates h (bit h.k x) (gs x))
    (output : ∀ x, x<truthRows h.k → highValue h (bit h.k x) (gs x) out=parity h.k x) :
    3*(h.k-1)≤h.s := by
  by_contra bad
  have hsmall : h.s≤3*h.k-4 := by omega
  let T := 3*h.k-4
  have hT : 0<T := by dsimp [T]; omega
  have hcut : cutoff h out≤T := (cutoff_le h out ho).trans hsmall
  have hm := model_of_circuit (padded h out T) hT (paddedValues h out gs)
    (padded_topology h out T ho topo) (padded_allowed h out T ho allowed)
    (padded_evaluates h out T ho gs topo evals)
    (by
      intro x hx
      change paddedValues h out gs x (T-1)=parity h.k x
      rw [padded_output h out T hT hcut gs x]
      exact output x hx)
  exact UniformSemanticReduction.original_family_unsat h.k hk _ hm

#print axioms schnorr_lower_bound
end L3Emitter.CircuitLowerBound

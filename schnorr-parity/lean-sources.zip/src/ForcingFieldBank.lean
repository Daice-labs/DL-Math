import ConstantSource
import ConstantCofactor

namespace L3Emitter.ForcingFieldBank
open EREF EREF.GeneralRED REDWitness ForcingCandidates PriorityBank
abbrev Job (k : Nat) := Node × Candidate (3*k-4)
abbrev Entry (k : Nat) := Job k × Int

def jobs (k : Nat) (hk : 3≤k) : List (Job k) :=
  (ConstantLookup.ns k hk).flatMap fun n =>
    ((candidates k hk).filter (fun z => decide (n.input=(z.var:Int)))).map (n,·)
def entries (k : Nat) (hk : 3≤k) : List (Entry k) :=
  (jobs k hk).flatMap fun j => (fields k hk j.2).map (j,·)
def row {k : Nat} (e : Entry k) := clause [-(e.1.1.choice:Int),e.2]
def tokens (k : Nat) (hk : 3≤k) (e : Entry k) :=
  PriorityExclusive.tokens (ForcingFamily.selected k hk) (e.1.1.choice:Int) e.1.1.input e.2

theorem job_mem (k : Nat) (hk : 3≤k) (n : Node) (z : Candidate (3*k-4)) :
    (n,z)∈jobs k hk ↔ n∈ConstantLookup.ns k hk ∧ z∈candidates k hk ∧ n.input=(z.var:Int) := by
  simp [jobs]

theorem entry_valid (k : Nat) (hk : 3≤k) (e : Entry k) (he : e∈entries k hk) :
    e.1.1∈ConstantLookup.ns k hk ∧ e.1.2∈candidates k hk ∧
      e.1.1.input=(e.1.2.var:Int) ∧ e.2∈fields k hk e.1.2 := by
  obtain ⟨j,hj,he⟩:=List.mem_flatMap.mp he
  obtain ⟨x,hx,rfl⟩:=List.mem_map.mp he
  have h:=(job_mem k hk j.1 j.2).mp hj
  exact ⟨h.1,h.2.1,h.2.2,hx⟩

def sourceProgram (k : Nat) (hk : 3≤k) (es : List (Entry k)) : AliasProgram.Program :=
  es.map fun e => (row e,tokens k hk e)

theorem source_check (k : Nat) (hk : 3≤k) (es : List (Entry k))
    (he : ∀e∈es,e∈entries k hk) (pre : List Row) :
    AliasProgram.check (ForcingFamily.selected k hk++pre) (sourceProgram k hk es)=
      some ((ForcingFamily.selected k hk++pre)++es.map row) := by
  induction es generalizing pre with
  | nil => simp [sourceProgram,AliasProgram.check]
  | cons e es ih =>
    have h:=entry_valid k hk e (he e (by simp))
    have hs:=ConstantSource.selected_field k hk e.1.1 h.1 e.1.2 h.2.1 h.2.2.1 e.2 h.2.2.2
    have hm:=polEval_mono _ _ (dbOf_ext_append (ForcingFamily.selected k hk) pre) _ [] _ hs
    have ht:=ih (by intro e he';exact he e (by simp [he'])) (pre++[row e])
    simpa [sourceProgram,AliasProgram.check,tokens,row,hm,List.append_assoc] using ht

def program (k : Nat) (hk : 3≤k) (D : List Row) :=
  ProgramRebase.program (ForcingFamily.selected k hk) D (sourceProgram k hk (entries k hk))
def result (k : Nat) (hk : 3≤k) (D : List Row) := D++(entries k hk).map row

theorem program_check (k : Nat) (hk : 3≤k) (D : List Row)
    (hD : ∀R∈ForcingFamily.selected k hk,R∈D) :
    AliasProgram.check D (program k hk D)=some (result k hk D) := by
  have hs:=source_check k hk (entries k hk) (by intros;assumption) []
  simp only [List.append_nil] at hs
  have h:=ProgramRebase.program_check _ _ hD _ _ hs
  simpa [program,result,sourceProgram,AliasProgram.outputs,List.map_map] using h

theorem field_present (k : Nat) (hk : 3≤k) (D : List Row) (n : Node) (z : Candidate (3*k-4))
    (hn : n∈ConstantLookup.ns k hk) (hz : z∈candidates k hk) (hid : n.input=(z.var:Int))
    (x : Int) (hx : x∈fields k hk z) : clause [-(n.choice:Int),x]∈result k hk D := by
  apply List.mem_append_right
  apply List.mem_map.mpr
  exact ⟨((n,z),x),List.mem_flatMap.mpr ⟨(n,z),(job_mem k hk n z).mpr ⟨hn,hz,hid⟩,
    List.mem_map.mpr ⟨x,hx,rfl⟩⟩,rfl⟩

def base (n : Nat) (hn : 2≤n) := ConstantCofactor.result n hn
def full (n : Nat) (hn : 2≤n) := result (n+1) (by omega) (base n hn)

theorem base_contains (n : Nat) (hn : 2≤n) (R : Row) (hR : R∈ForcingFamily.selected (n+1) (by omega)) :
    R∈base n hn := by
  apply List.mem_append_left
  apply List.mem_append_left
  exact ConstantConstruction.retains_rank _ _ R (ConstantConstruction.retains_forcing _ _ R hR)

theorem original_to_fields (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (full n hn) :=
  L3.Fam.checkedTrace_trans (ConstantCofactor.original_to_selected_cofactor n hn)
    (AliasProgram.check_trace _ _ _ (program_check (n+1) (by omega) (base n hn) (base_contains n hn)))

#print axioms original_to_fields
#print axioms program_check
end L3Emitter.ForcingFieldBank

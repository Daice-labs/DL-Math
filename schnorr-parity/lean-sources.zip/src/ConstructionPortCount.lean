import ConstructionOneHotCount
import ConstructionFormulaScale
import PortValueBounds

namespace L3Emitter.ConstructionPortCount
open EREF EREF.GeneralRED

theorem jobs (n : Nat) (hn : 2≤n) : (GlobalPortValues.jobs n).length=
    (3*(n+1)-4)*2*(2^n*(4*n-4)*4) := by
  have h:=GlobalValueSize.jobs_count n
  have hw:AliasAssembly.width (n+1)=4*n-4 := by
    unfold AliasAssembly.width RankConstruction.width
    omega
  simp [GlobalPortValues.jobs,List.length_flatMap,h,hw,FamilyNamespace.truthRows,Nat.mul_assoc]
  left;ring

/-- Full bank of port-value derivations; every selector case and final join
is counted. Unit: MAIN POL COMMANDS. -/
theorem bank (n : Nat) (hn : 2≤n) :
    (GlobalPortValues.program n hn).length≤
      (3*(n+1)-4)*2*(2^n*(4*n-4)*4)*(12*n+1) := by
  unfold GlobalPortValues.program
  calc
    _ ≤ (GlobalPortValues.jobs n).length*(12*n+1) := by
      apply ConstructionCountTools.retained_fold
      intro j hj D
      have hg:=((GlobalPortValues.job_mem n j).mp hj).1
      have h:=PortValueBounds.port_commands n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1
        (SourceCoordinateValue.value n hn j.2.2.2.1 j.2.2.1) j.2.2.2.2.1 j.2.2.2.2.2 D
      dsimp only [GlobalPortValues.block]
      omega
    _ = _ := by rw [jobs n hn]

/-- A polynomial in actual original-formula rows for this complete bank.
This is a component command bound, not the total serialized byte theorem. -/
theorem formula_polynomial (n : Nat) (hn : 2≤n) :
    (GlobalPortValues.program n hn).length≤1248*(ConstructionFormulaScale.rows n)^4 := by
  have h:=bank n hn
  have h1:3*(n+1)-4≤3*(n+1):=Nat.sub_le ..
  have h2:4*n-4≤4*(n+1):=by omega
  have h3:12*n+1≤13*(n+1):=by omega
  have hm:=Nat.mul_le_mul
    (Nat.mul_le_mul (Nat.mul_le_mul_right 2 h1)
      (Nat.mul_le_mul_right 4 (Nat.mul_le_mul_left (2^n) h2))) h3
  have he:3*(n+1)*2*(2^n*(4*(n+1))*4)*(13*(n+1))=1248*(n+1)^3*2^(1*n):=by ring
  rw [he] at hm
  exact h.trans (hm.trans (ConstructionFormulaScale.monomial n 3 1 1248 hn))

#print axioms bank
#print axioms formula_polynomial
end L3Emitter.ConstructionPortCount

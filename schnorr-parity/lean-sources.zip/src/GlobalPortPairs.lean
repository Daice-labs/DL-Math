import GlobalPortCardinalities
namespace L3Emitter.GlobalPortPairs
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot

theorem mono {D E:List Row} {w:Nat} {a:AliasBits w} (h:SourceRows D a)
    (he:∀R∈D,R∈E):SourceRows E a:=⟨he _ h.1,fun i j hij=>he _ (h.2 i j hij)⟩

theorem step_ports (n:Nat) (hn:2≤n) (g p:Nat) (hp:p<2) (D:List Row):
    SourceRows (GateOrderSources.stepResult n hn g D) (EarlierPortValues.portAlias n hn g p):=by
  have hm:=MuxSourceStep.retains n hn g (GateOrderSources.afterRight n hn g D)
  have ht:=GateSourceOneHot.retains n hn g (GateOrderSources.afterMux n hn g D)
  by_cases h:p=0
  · subst p
    exact mono (GatePortOneHot.source_rows n hn g 0 D)
      (fun R hr=>ht R (hm R (GatePortOneHot.retains n hn g 1 _ R hr)))
  · have h1:p=1:=by omega
    subst p
    exact mono (GatePortOneHot.source_rows n hn g 1 (GateOrderSources.afterLeft n hn g D))
      (fun R hr=>ht R (hm R hr))

theorem run_ports (n:Nat) (hn:2≤n) (g m target p:Nat) (hp:p<2) (hg:g≤target) (ht:target<g+m) (D:List Row):
    SourceRows (GateOrderSources.result n hn g D m) (EarlierPortValues.portAlias n hn target p):=by
  induction m generalizing g D with
  | zero=>omega
  | succ m ih=>
    by_cases he:target=g
    · subst target
      exact mono (step_ports n hn g p hp D) (GlobalPortCardinalities.result_retains n hn (g+1) m _)
    · exact ih (g+1) (by omega) (by omega) (GateOrderSources.stepResult n hn g D)

theorem nonzero_ports (n:Nat) (hn:2≤n) (g p:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (hp:p<2):
    SourceRows (GlobalPortValues.result n hn) (EarlierPortValues.portAlias n hn g p):=by
  have h:=run_ports n hn 1 (3*(n+1)-5) g p hp (by omega) (by omega) (SourceAuxBank.result n hn)
  apply mono h
  intro R hr
  apply GlobalPortValues.retained
  apply GlobalValueInduction.retained
  apply SharedValueBank.gamma_retained
  apply EarlierPortValues.unary_keep
  apply CofactorValueRows.unary_keep
  apply UnaryRelationBank.retains
  exact List.mem_append_left _ hr

#print axioms nonzero_ports
end L3Emitter.GlobalPortPairs

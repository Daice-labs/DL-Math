import L3FinalChains

namespace L3
open EREF EREF.GeneralRED

/-- Sum of the selector-case roots, with their common guard and EQ literal. -/
theorem selector_root_sum (α : Val) (guard : List Int) (q : Int) (xs : List Int)
    (hn : ∀x∈xs,x≠0) :
    ((xs.map fun x => clauseRow (guard ++ [-x,q])).map
      fun r => lsum α r.lits - (r.rhs : Int)).sum =
      (xs.length : Int) * (lsum α guard + lv α q) - lsum α xs := by
  induction xs with
  | nil => simp [lsum_nil]
  | cons x xs ih =>
    have hx := hn x (by simp)
    have ht : ∀y∈xs,y≠0 := fun y hy => hn y (by simp [hy])
    have hc := lv_neg_lit α x hx
    rw [List.map_cons,List.map_cons,List.sum_cons,ih ht]
    simp only [clauseRow,lsum_append,lsum_cons,lsum_nil,List.length_cons]
    rw [show ((xs.length+1 : Nat) : Int) = (xs.length : Int)+1 by omega,Int.add_mul]
    omega

/-- T5c: the symbolic selector sum closes the unselected-input cases.
    This is a linear-size fixed chain for any selector list, including empty. -/
theorem selector_coverage (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (guard : List Int) (sel q : Int) (xs : List Int)
    (hg : ∀l∈guard,l≠0) (hs : sel≠0) (hq : q≠0) (hx : ∀l∈xs,l≠0)
    (hroots : ∀x∈xs,(clauseRow (guard ++ [-x,q])).toE∈D)
    (hAL : (clauseRow (sel::xs)).toE∈D) :
    Refutation (D ++ [negate (clauseRow (guard ++ [sel,q])).toE]) := by
  apply weighted_clause_chain D _ xs.length
    ((xs.map fun x => clauseRow (guard ++ [-x,q])) ++ [clauseRow (sel::xs)]) hD
  · intro l hl
    rcases List.mem_append.mp hl with hl | hl
    · exact hg l hl
    · simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
      rcases hl with rfl | rfl <;> assumption
  · apply All.append
    · clear hAL
      induction xs with
      | nil => trivial
      | cons x xs ih =>
        exact ⟨hroots x (by simp),ih (fun l hl => hx l (by simp [hl]))
          (fun l hl => hroots l (by simp [hl]))⟩
    · exact ⟨hAL,trivial⟩
  · apply All.append
    · clear hAL
      induction xs with
      | nil => trivial
      | cons x xs ih =>
        refine ⟨?_,ih (fun l hl => hx l (by simp [hl]))
          (fun l hl => hroots l (by simp [hl]))⟩
        intro l hl
        rcases List.mem_append.mp hl with hl | hl
        · exact hg l hl
        · simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
          rcases hl with rfl | rfl
          · have := hx x (by simp); omega
          · exact hq
    · refine ⟨?_,trivial⟩
      intro l hl
      rcases List.mem_cons.mp hl with rfl | hl
      · exact hs
      · exact hx l hl
  · intro α
    rw [List.map_append,List.sum_append,selector_root_sum α guard q xs hx]
    simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      clauseRow,lsum_append,lsum_cons,lsum_nil]
    have hG := lsum_nonneg α guard
    have hQ := (lv_bounds α q).1
    have hS := (lv_bounds α sel).1
    have hprod : 0 ≤ (xs.length : Int)*lv α sel := Int.mul_nonneg (by omega) hS
    rw [show ((xs.length+1 : Nat) : Int) = (xs.length : Int)+1 by omega]
    simp only [Int.neg_mul,Int.add_mul,Int.mul_add,Int.one_mul]
    omega

#print axioms selector_root_sum
#print axioms selector_coverage
end L3

import NativeParserCheckedFile
namespace L3Emitter.NativeParserFormula
open EREF CanonicalByteFraming CanonicalLineEncoding NativeParserEventCoordinates

def allocate (names:List Nat):List Row→List Nat×List Row
 | []=>(names,[])
 | R::D=>
   let ns:=PinnedNameSequence.run names (rowNames R)
   let tail:=allocate ns D
   (tail.1,PinnedCoordinateChange.row (PinnedCoordinateChange.coordinate ns) R::tail.2)

theorem final_names (names:List Nat) (D:List Row):
 (allocate names D).1=PinnedNameSequence.run names (D.flatMap rowNames):=by
 induction D generalizing names with
 | nil=>rfl
 | cons R D ih=>simp only [allocate,List.flatMap_cons,sequence_append,ih]

theorem online_global (names:List Nat) (D:List Row):
 (allocate names D).2=D.map (PinnedCoordinateChange.row (PinnedCoordinateChange.coordinate (allocate names D).1)):=by
 induction D generalizing names with
 | nil=>rfl
 | cons R D ih=>
   simp only [allocate,List.map_cons]
   rw [ih]
   congr 1
   apply row_congr
   intro v hv
   rw [final_names]
   exact (coordinate_stable _ _ _ (PinnedNameSequence.inserted names (rowNames R) v hv)).symm

def readLines (names:List Nat):List Bytes→Option (List Nat×List Row)
 | []=>some (names,[])
 | l::ls=>do
   let middle←strip [] (ascii " ;") l
   let R←PinnedFieldReaders.row middle
   let ns:=PinnedNameSequence.run names (rowNames R)
   let tail←readLines ns ls
   return (tail.1,PinnedCoordinateChange.row (PinnedCoordinateChange.coordinate ns) R::tail.2)

def parse (names:List Nat) (bs:Bytes):Option (List Nat×List Row):=
 match (fileLines bs).reverse with
 | []::ls=>readLines names ls.reverse
 | _=>none

theorem lines_roundtrip (names:List Nat) (D:List Row) (hc:∀R∈D,Canonical R):
 readLines names (CanonicalByteAcceptance.formulaLines D)=some (allocate names D):=by
 induction D generalizing names with
 | nil=>rfl
 | cons R D ih=>
   have hh:=hc R (by simp)
   have ht:=ih (PinnedNameSequence.run names (rowNames R)) (fun R hR=>hc R (by simp [hR]))
   unfold CanonicalByteAcceptance.formulaLines at ht
   simp only [CanonicalByteAcceptance.formulaLines,List.map_cons,readLines]
   rw [show strip [] (ascii " ;") (emit (CanonicalScopedBytes.rowDoc R)++ascii " ;")=
      some (emit (CanonicalScopedBytes.rowDoc R)) by exact strip_roundtrip [] _ _]
   simp only [bind,Option.bind,PinnedFieldReaders.read_row R hh,ht,allocate,pure]

theorem roundtrip (names:List Nat) (D:List Row) (hc:∀R∈D,Canonical R):
 parse names (emit (CanonicalFormulaReadback.formulaDoc D))=some (allocate names D):=by
 rw [←CanonicalByteAcceptance.formula_lines_bytes,parse,split_lines]
 · simp only [List.reverse_append,List.reverse_cons,List.reverse_nil,List.nil_append,
      List.singleton_append,List.reverse_reverse]
   exact lines_roundtrip names D hc
 · intro l hl
   obtain ⟨R,hR,rfl⟩:=List.mem_map.mp hl
   simp only [List.mem_append,not_or]
   exact ⟨row_avoids (CanonicalScopedBytes.pbRow R) 10 (Or.inl rfl),by decide⟩

theorem later_names (names xs:List Nat) (D:List Row):
 (allocate names D).2=D.map (PinnedCoordinateChange.row
   (PinnedCoordinateChange.coordinate (PinnedNameSequence.run (allocate names D).1 xs))):=by
 rw [online_global]
 apply List.map_congr_left
 intro R hR
 apply row_congr
 intro v hv
 exact (coordinate_stable _ _ _ (by
   rw [final_names]
   exact PinnedNameSequence.inserted names _ v (List.mem_flatMap.mpr ⟨R,hR,hv⟩))).symm

/-- Original row parsing and online formula interning are stable under all
subsequent proof-variable allocations. No formula is evaluated at a size. -/
theorem family (n:Nat):
 parse [] (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n)))=
 some (allocate [] (NativeRecordedFamily.original n)):=
 roundtrip [] _ (OriginalEncoding.rows_canonical n (3*n-4))
#print axioms family
#print axioms later_names
end L3Emitter.NativeParserFormula

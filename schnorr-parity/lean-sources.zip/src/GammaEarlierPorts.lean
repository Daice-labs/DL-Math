import GammaPortHypotheses
namespace L3Emitter.GammaEarlierPorts
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
abbrev Job:=BetaPort.Job

def sourceRows (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))):=
  [GammaSourcePorts.firstRow n hn j i,GammaSourcePorts.row n hn j i false,GammaSourcePorts.row n hn j i true]
def sourceProgram (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (D:List Row):=
  [(GammaSourcePorts.firstRow n hn j i,GammaSourcePorts.firstTape n hn j i D)]++
    [false,true].map (fun side=>(GammaSourcePorts.row n hn j i side,
      GammaSourcePorts.tape n hn j i side (D++[GammaSourcePorts.firstRow n hn j i])))
theorem source_checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (D:List Row)
    (hd:∀R∈GammaComparisonBank.result n hn,R∈D):
    check D (sourceProgram n hn j i D)=some (D++sourceRows n hn j i):=by
  have h0:=GammaSourcePorts.first_check n hn j hj i D hd
  have h1:=IndependentProgram.check_base (D++[GammaSourcePorts.firstRow n hn j i])
    ([false,true].map fun side=>(GammaSourcePorts.row n hn j i side,
      GammaSourcePorts.tape n hn j i side (D++[GammaSourcePorts.firstRow n hn j i]))) (by
      intro cmd hc;obtain ⟨side,hs,rfl⟩:=List.mem_map.mp hc
      exact GammaSourcePorts.checks n hn j hj i side _ (fun R h=>List.mem_append_left _ (hd R h))
        (List.mem_append_right _ (List.mem_singleton_self _)))
  have hfirst:check D [(GammaSourcePorts.firstRow n hn j i,GammaSourcePorts.firstTape n hn j i D)]=some (D++[GammaSourcePorts.firstRow n hn j i]):=by
    simp only [check,h0,ite_true]
  simpa [sourceProgram,sourceRows,outputs,List.append_assoc] using check_append _ _ _ _ _ hfirst h1

def oneRows (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (z:Bool×Bool):=
  PortSelectorJoin.rows n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2++
    [GammaPreservation.hypothesis n hn j u z.1 z.2 (GammaPortHypotheses.frame n hn j i t u)]
def one (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (z:Bool×Bool) (D:List Row):=
  PortSelectorJoin.program n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2 D++
    [(GammaPreservation.hypothesis n hn j u z.1 z.2 (GammaPortHypotheses.frame n hn j i t u),
      GammaPortHypotheses.tape n hn j i t u z.1 z.2
        (D++PortSelectorJoin.rows n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2))]

def Inputs (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (D:List Row):Prop:=
  (∀R∈GammaComparisonBank.result n hn,R∈D) ∧
  (∀b,PortValueBank.Earlier n hn (GammaCofactorValue.g j) j.2 i t u b D) ∧
  (∀side,GammaSourcePorts.row n hn j i side∈D)
theorem inputs_mono (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) {D E:List Row}
    (hi:Inputs n hn j i t u D) (hk:∀R∈D,R∈E):Inputs n hn j i t u E:=
  ⟨fun R h=>hk R (hi.1 R h),fun b h hh=>hk _ (hi.2.1 b h hh),fun side=>hk _ (hi.2.2 side)⟩

theorem one_check (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (z:Bool×Bool) (D:List Row)
    (ht:∀a,a<n+1 → a≠0 → i.val=a-1 → t=PrimaryValueSeeds.truth (PrimaryAliasBank.cfg n hn) (PrimaryInputLinks.d n a j.2))
    (hi:Inputs n hn j i t u D):
    check D (one n hn j i t u z D)=some (D++oneRows n hn j i t u z):=by
  have hx: j.2<FamilyNamespace.truthRows n:=(BetaPort.valid_job n hn j hj).2.2.2
  have h0:=PortSelectorJoin.full_port_checks n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2
    j.1.2.parent.gamma_lt (by cases z.1 <;> decide) hx i t u z.2 D ht hi.1 (hi.2.1 z.2)
  have h1:=GammaPortHypotheses.checks n hn j hj i t u z.1 z.2
    (D++PortSelectorJoin.rows n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2)
    (List.mem_append_left _ (hi.2.2 z.1))
    (List.mem_append_right _ (List.mem_append_right _ (List.mem_singleton_self _)))
  have hlast:check (D++PortSelectorJoin.rows n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2)
      [(GammaPreservation.hypothesis n hn j u z.1 z.2 (GammaPortHypotheses.frame n hn j i t u),
        GammaPortHypotheses.tape n hn j i t u z.1 z.2 (D++PortSelectorJoin.rows n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2))]=
      some ((D++PortSelectorJoin.rows n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2)++
        [GammaPreservation.hypothesis n hn j u z.1 z.2 (GammaPortHypotheses.frame n hn j i t u)]):=by
    simp only [check,h1,ite_true]
  simpa only [one,oneRows,List.append_assoc] using check_append _ _ _ _ _ h0 hlast

def run (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (D:List Row):List (Bool×Bool)→Program
  | []=>[]
  | z::zs=>one n hn j i t u z D++run n hn j i t u (D++oneRows n hn j i t u z) zs
def body (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (zs:List (Bool×Bool)):=
  zs.flatMap (oneRows n hn j i t u)
theorem run_check (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (D:List Row) (zs:List (Bool×Bool))
    (ht:∀a,a<n+1 → a≠0 → i.val=a-1 → t=PrimaryValueSeeds.truth (PrimaryAliasBank.cfg n hn) (PrimaryInputLinks.d n a j.2))
    (hi:Inputs n hn j i t u D):
    check D (run n hn j i t u D zs)=some (D++body n hn j i t u zs):=by
  induction zs generalizing D with
  | nil=>simp [run,body,check]
  | cons z zs ih=>
    have h0:=one_check n hn j hj i t u z D ht hi
    have h1:=ih (D++oneRows n hn j i t u z) (inputs_mono n hn j i t u hi (fun R h=>List.mem_append_left _ h))
    simpa only [run,body,List.flatMap_cons,List.append_assoc] using check_append _ _ _ _ _ h0 h1
#print axioms source_checks
#print axioms one_check
#print axioms run_check
end L3Emitter.GammaEarlierPorts

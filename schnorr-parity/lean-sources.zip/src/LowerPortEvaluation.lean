import SelectedPortBindings
namespace L3Emitter.LowerPortEvaluation
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL AliasProgram ReferenceTransport ClauseTransport

def low (n:Nat) (r:RawLowerInputBank.Record n) (x:Nat):Bit:=r.2 x
def selectedUnary (n:Nat) (r:RawLowerInputBank.Record n) (b:Bool):Bit:=
  r.1.1.2.2 (UnarySnapshots.position (AliasAssembly.width (n+1)) b)
def upperUnary (n:Nat) (hn:2≤n) (r:RawLowerInputBank.Record n) (G:Nat) (b:Bool):Bit:=
  EarlierPortValues.portAlias n hn G r.1.1.2.1 (UnarySnapshots.position (AliasAssembly.width (n+1)) b)
def upperValue (n:Nat) (hn:2≤n) (r:RawLowerInputBank.Record n) (G x:Nat):Bit:=
  EarlierPortValues.portValue n hn G r.1.1.2.1 x

def mapped (D:List Row) (c a q:Int):Link:=.mapped a q (locate D (clause [-c,-a,q]))
def links (n:Nat) (hn:2≤n) (r:RawLowerInputBank.Record n) (G x:Nat) (b v:Bool) (D:List Row):List Link:=
  [.same (-sign b (low n r x)),
   mapped D (TopologyContext.guard n hn G r.1.1.1).val (-sign v (selectedUnary n r b)) (-sign v (upperUnary n hn r G b)),
   mapped D (TopologyContext.guard n hn G r.1.1.1).val (sign v (r.1.2 x)) (sign v (upperValue n hn r G x))]
def row (n:Nat) (hn:2≤n) (r:RawLowerInputBank.Record n) (G x:Nat) (b v:Bool):Row:=
  clause [-(TopologyContext.guard n hn G r.1.1.1).val,-sign b (low n r x),
    -sign v (upperUnary n hn r G b),sign v (upperValue n hn r G x)]
def tape (n:Nat) (hn:2≤n) (r:RawLowerInputBank.Record n) (G x:Nat) (b v:Bool) (D:List Row):List Tok:=
  ClauseTransport.tokens (locate D (RawUnaryTransport.row r.1.1.2.2 (low n r x) (r.1.2 x) b v))
    (-(TopologyContext.guard n hn G r.1.1.1).val) (links n hn r G x b v D)

theorem sign_not (v:Bool) (a:Bit):sign (!v) a= -sign v a:=by cases v <;> simp [sign]
theorem mapped_available (D:List Row) (c a q:Int) (ha:a≠0) (hq:q≠0) (hl:clause [-c,-a,q]∈D):
    (mapped D c a q).Available (dbOf D) (-c):=
  ⟨ha,hq,locate_correct D _ hl⟩

theorem checks (n:Nat) (hn:2≤n) (r:RawLowerInputBank.Record n) (hr:r∈(RawLowerInputBank.result n hn).2)
    (G:Nat) (hG:G∈RankZeroTransport.gates n) (ht:r.1.1.1<RankConstruction.width (n+1))
    (x:Nat) (hx:x<FamilyNamespace.truthRows n) (b v:Bool) (D:List Row)
    (hd:∀R∈LowerU2Bank.result n hn,R∈D):
    polEval (dbOf D) (tape n hn r G x b v D) []=some (row n hn r G x b v):=by
  have hu:=SelectedPortBindings.selected_unary_links n hn r hr G hG ht b
  have hv:=SelectedPortBindings.selected_value_links n hn r hr G hG ht x hx
  have hsu:=UnaryValueStep.conditional_link (LowerU2Bank.result n hn) (TopologyContext.guard n hn G r.1.1.1)
    (selectedUnary n r b) (upperUnary n hn r G b) (!v) hu.2 hu.1
  have hsv:=UnaryValueStep.conditional_link (LowerU2Bank.result n hn) (TopologyContext.guard n hn G r.1.1.1)
    (r.1.2 x) (upperValue n hn r G x) v hv.2 hv.1
  simp only [sign_not] at hsu
  have hs:=hd _ (SelectedPortBindings.raw_retained n hn _ (RawUnaryBank.all_rows n hn r hr x hx b v))
  have hl:∀p∈links n hn r G x b v D,p.Available (dbOf D) (-(TopologyContext.guard n hn G r.1.1.1).val):=by
    intro p hp
    simp only [links,List.mem_cons,List.not_mem_nil,or_false] at hp
    rcases hp with rfl|rfl|rfl
    · exact ⟨neg_ne_zero.mpr (sign_valid _ _),neg_ne_zero.mpr (sign_valid _ _),True.intro⟩
    · exact mapped_available D _ _ _ (neg_ne_zero.mpr (sign_valid _ _)) (neg_ne_zero.mpr (sign_valid _ _)) (hd _ hsu)
    · exact mapped_available D _ _ _ (sign_valid _ _) (sign_valid _ _) (hd _ hsv)
  have h:=ClauseTransport.succeeds (dbOf D) _ _ (neg_ne_zero.mpr (TopologyContext.guard n hn G r.1.1.1).property)
    (links n hn r G x b v D) (by simp [links]) (locate_correct D _ hs) hl
  rw [targetClause] at h
  simp only [links,List.map_cons,List.map_nil,Link.target,mapped] at h
  rw [ProjectionTrace.branch_clause _ (by simp [Valid,sign_valid]) _ (neg_ne_zero.mpr (TopologyContext.guard n hn G r.1.1.1).property)] at h
  exact h
#print axioms checks
end L3Emitter.LowerPortEvaluation

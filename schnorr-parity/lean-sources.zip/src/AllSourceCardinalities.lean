import GateOrderSources

namespace L3Emitter.AllSourceCardinalities
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot

def xs (n:Nat) (hn:2≤n) (j:Nat) :=sourceLiterals ((AliasAssembly.built n hn).1.2 j)
def ids (n:Nat) :=List.range (n+1+(3*(n+1)-4))
def body (n:Nat) (hn:2≤n) (js:List Nat) :=js.flatMap (fun j=>OneHotPOL.rows (xs n hn j))
def loop (n:Nat) (hn:2≤n) (D:List Row) :List Nat→Program
  | []=>[]
  | j::js=>OneHotPOL.program D (xs n hn j)++loop n hn (D++OneHotPOL.rows (xs n hn j)) js

theorem valid (n:Nat) (hn:2≤n) (j:Nat) :Valid (xs n hn j):=by
  intro x hx
  obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hx
  exact ((AliasAssembly.built n hn).1.2 j (position i)).property

theorem loop_check (n:Nat) (hn:2≤n) (js:List Nat) (hj:∀j∈js,j∈ids n)
    (D:List Row) (hd:∀R∈GateOrderSources.fullResult n hn,R∈D) :
    check D (loop n hn D js)=some (D++body n hn js) := by
  induction js generalizing D with
  | nil=>simp [loop,body,check]
  | cons j js ih=>
    have h:=GateOrderSources.all_source_rows n hn j (List.mem_range.mp (hj j (by simp)))
    have hp:(xs n hn j).Pairwise (fun x y=>Cardinality.pair x y∈D):=by
      apply List.pairwise_ofFn.mpr
      exact fun i l hil=>hd _ (h.2 i l hil)
    have h0:=OneHotPOL.checks D (xs n hn j) (valid n hn j) hp
    have h1:=ih (fun j h=>hj j (by simp [h])) (D++OneHotPOL.rows (xs n hn j))
      (fun R h=>List.mem_append_left _ (hd R h))
    simpa only [loop,body,List.flatMap_cons,List.append_assoc] using check_append _ _ _ _ _ h0 h1

def result (n:Nat) (hn:2≤n) :=GateOrderSources.fullResult n hn++body n hn (ids n)
def program (n:Nat) (hn:2≤n) :=loop n hn (GateOrderSources.fullResult n hn) (ids n)
theorem checks (n:Nat) (hn:2≤n) :check (GateOrderSources.fullResult n hn) (program n hn)=some (result n hn) :=
  loop_check n hn _ (fun j h=>h) _ (fun R h=>h)
theorem full_constraints (n:Nat) (hn:2≤n) (j:Nat) (hj:j<n+1+(3*(n+1)-4)) :
    clause (xs n hn j)∈result n hn ∧ Cardinality.amo (xs n hn j)∈result n hn := by
  refine ⟨List.mem_append_left _ (GateOrderSources.all_source_rows n hn j hj).1,?_⟩
  apply List.mem_append_right
  apply List.mem_flatMap.mpr
  refine ⟨j,List.mem_range.mpr hj,OneHotPOL.final_mem _ ?_⟩
  intro he
  have h:=congrArg List.length he
  simp [xs,sourceLiterals] at h
  unfold AliasAssembly.width RankConstruction.width at h
  omega

theorem original_to_cardinalities (n:Nat) (hn:2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (GateOrderSources.original_to_all_sources n hn) (check_trace _ _ _ (checks n hn))

#print axioms checks
#print axioms full_constraints
#print axioms original_to_cardinalities
end L3Emitter.AllSourceCardinalities

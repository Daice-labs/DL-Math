import FamilyReferenceWidths
namespace L3Emitter.ActualReferenceWidths
set_option maxRecDepth 2000
set_option maxHeartbeats 800000
open EREF EREF.GeneralRED NativeSparseStore

/-- Intermediate references are bounded by the actual final allocation counter,
without replacing it by a coarse polynomial envelope. -/
theorem actual (n : Nat) (hn : 2≤n) :
    ∀i∈FamilyReferenceWidths.familyRefs n,0 < i ∧ i < (NativeRecordedFamily.compiled n).store.next := by
  have hp:=(RecordedUniformFamily.recorded_refutation n hn).1
  have h:=ActionReferenceBounds.program 0 (RecordedUniformFamily.guard n) _ _
    (initial (NativeRecordedFamily.original n)) id _ (by change 0 < _+1;omega)
    (initial_embeds _) hp
  have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
    (initial (NativeRecordedFamily.original n)) id _ hp
  rw [←he] at h
  exact FamilyReferenceWidths.body _ _ _ _ _ h

theorem machine (n : Nat) (hn : 2≤n)
    (hlimit : (NativeRecordedFamily.compiled n).store.next≤CanonicalMachineReference.referenceLimit)
    (i : Nat) (hi : i∈FamilyReferenceWidths.familyRefs n) : (Int64.ofNat i).toInt=(i:Int) :=
  CanonicalMachineReference.positive_cast i (lt_of_lt_of_le (actual n hn i hi).2 hlimit)

/-- Unit: physical row-counter ceiling. This is a conservative symbolic base
bound, not a materialized proof or measured allocation count. -/
def baseBound : Nat :=4608+1+2*1000+1000*(4608+1000)*2109

theorem counter_bound (n : Nat) (hn : 2≤n) (P F : Nat)
    (hm : ConstructionAllocationEnvelope.mainCount n≤P)
    (hf : (OriginalEncoding.rows n (3*n-4)).length≤F) :
    (NativeRecordedFamily.compiled n).store.next≤F+1+2*P+P*(F+P)*(704*n+701) := by
  have ha:=ConstructionAllocationEnvelope.allocations n hn
  have hp:=Nat.mul_le_mul_right (704*n+701) (Nat.mul_le_mul hm (Nat.add_le_add hf hm))
  have hl:=Nat.mul_le_mul_left 2 hm
  have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
    (initial (NativeRecordedFamily.original n)) id _
    (RecordedUniformFamily.recorded_refutation n hn).1
  change (NativeRecordedFamily.compiled n).store.next=
    (OriginalEncoding.rows n (3*n-4)).length+1+
      NativeRecordedAllocation.program (RecordedUniformFamily.emitter n) at he
  change NativeRecordedAllocation.program (RecordedUniformFamily.emitter n)≤
    2*ConstructionAllocationEnvelope.mainCount n+
    ConstructionAllocationEnvelope.mainCount n*
      ((OriginalEncoding.rows n (3*n-4)).length+ConstructionAllocationEnvelope.mainCount n)*(704*n+701) at ha
  omega

theorem base_counter : (NativeRecordedFamily.compiled 2).store.next≤baseBound := by
  apply counter_bound 2 (by omega) 1000 4608
  · exact ConstructionCompleteCount.base
  · exact CanonicalFormulaEnvelope.original_rows 2

theorem base_in_range : baseBound≤CanonicalMachineReference.referenceLimit := by
  norm_num [baseBound,CanonicalMachineReference.referenceLimit]

/-- Nonvacuous base-case signed-reference theorem, proved without evaluating the
family. It covers references only, not native executable acceptance. -/
theorem base_machine (i : Nat) (hi : i∈FamilyReferenceWidths.familyRefs 2) :
    (Int64.ofNat i).toInt=(i:Int) := machine 2 (by omega) (base_counter.trans base_in_range) i hi

/-- The earlier polynomial ceiling is too coarse for native-range admission at
the base case. This says nothing about an actual overflow. -/
theorem coarse_base_exceeds_native : CanonicalMachineReference.referenceLimit <
    ConstructionClosedReference.nextBound 2 := by
  norm_num [CanonicalMachineReference.referenceLimit,ConstructionClosedReference.nextBound,
    ConstructionClosedAllocation.formulaBound,ConstructionClosedAllocation.allocationBound,
    ConstructionClosedAllocation.certificateBound,ConstructionCompleteCount.mainBound]
#print axioms actual
#print axioms base_machine
#print axioms coarse_base_exceeds_native
end L3Emitter.ActualReferenceWidths

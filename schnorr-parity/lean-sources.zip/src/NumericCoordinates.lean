import NumericSelectionRows
namespace L3Emitter.NumericCoordinates
open EREF EREF.GeneralRED SelectedCoordinateBank FieldLengthsFromIDs

def increment (K:Nat) (cs:List Int):Nat:=2*K+cs.length+2

theorem literal_max (K:Nat) (xs:List Int) (h:∀x∈xs,x.natAbs≤K):RawValueBank.literalMax xs≤K:=by
  apply RawBankSize.max_le
  intro a ha;obtain ⟨x,hx,rfl⟩:=List.mem_map.mp ha;exact h x hx

theorem start_bound (K H:Nat) (D:List Row) (cs:List Int) (f:Int→Nat→Int) (i:Nat)
    (hD:RowSupport.Bounded H D) (hc:∀c∈cs,c.natAbs≤K) (hf:∀c∈cs,(f c i).natAbs≤K):
    start D cs f i+cs.length+1≤H+increment K cs:=by
  have h1:=RawBankSize.ceiling_le D H hD
  have h2:=literal_max K cs hc
  have h3:=literal_max K (cs.map (fun c=>f c i)) (by intro l hl;obtain ⟨c,hc,rfl⟩:=List.mem_map.mp hl;exact hf c hc)
  unfold start increment;omega

theorem block_bound (K H:Nat) (D:List Row) (cs:List Int) (f:Int→Nat→Int) (i:Nat)
    (hD:RowSupport.Bounded H D) (hc:∀c∈cs,c.natAbs≤K) (hf:∀c∈cs,(f c i).natAbs≤K):
    RowSupport.Bounded (H+increment K cs) (block D cs f i):=by
  apply NumericSelectionRows.result
  · exact RowSupport.mono _ (by omega) hD
  · exact start_bound K H D cs f i hD hc hf
  · intro c hc';exact (hc c hc').trans (by unfold increment;omega)
  · intro c hc';exact (hf c hc').trans (by unfold increment;omega)

theorem run_bound (K H:Nat) (D:List Row) (cs:List Int) (f:Int→Nat→Int) (i m:Nat)
    (hH:1≤H) (hD:RowSupport.Bounded H D) (hc:∀c∈cs,c.natAbs≤K)
    (hf:∀ j, i ≤ j → j < i+m → ∀ c ∈ cs,(f c j).natAbs≤K):
    RowSupport.Bounded (H+m*increment K cs) (run cs f D i m).1 ∧
    ∀j,((run cs f D i m).2 j).val.natAbs≤H+m*increment K cs:=by
  induction m generalizing D H i with
  | zero=>
    simp only[run,Nat.zero_mul,Nat.add_zero,fallback,Int.natAbs_natCast]
    exact ⟨hD,fun _=>hH⟩
  | succ m ih=>
    have hfi:=hf i (by omega) (by omega)
    have hb:=block_bound K H D cs f i hD hc hfi
    have hs:=start_bound K H D cs f i hD hc hfi
    have ht:=ih (H+increment K cs) (block D cs f i) (i+1) (by omega) hb
      (fun j hj hji=>hf j (by omega) (by omega))
    have he:H+increment K cs+m*increment K cs=H+(m+1)*increment K cs:=by ring
    constructor
    · simpa only[run,he] using ht.1
    · intro j;by_cases hj:j=i
      · subst j;simp only[run,Function.update_self,out,Int.natAbs_natCast];nlinarith
      · simp only[run,Function.update_of_ne hj];exact (ht.2 j).trans (by omega)

theorem block_fields (M K H:Nat) (D:List Row) (cs:List Int) (f:Int→Nat→Int) (i:Nat)
    (hD:RowSupport.Bounded H D) (hc:∀c∈cs,c.natAbs≤K) (hf:∀c∈cs,(f c i).natAbs≤K)
    (hM:H+increment K cs≤M) (hw:14≤M) (hl:5+(cs.length+1)^2≤M):
    ∀c∈RecordedCoordinateBank.blockProgram D cs f i,Content M c:=by
  apply NumericSupportFields.program
  · exact (start_bound K H D cs f i hD hc hf).trans hM
  · intro c hc';exact (hc c hc').trans (by unfold increment at hM;omega)
  · intro c hc';exact (hf c hc').trans (by unfold increment at hM;omega)
  · exact hw
  · exact hl

theorem run_fields (M K H:Nat) (D:List Row) (cs:List Int) (f:Int→Nat→Int) (i m:Nat)
    (hD:RowSupport.Bounded H D) (hc:∀c∈cs,c.natAbs≤K)
    (hf:∀ j, i ≤ j → j < i+m → ∀ c ∈ cs,(f c j).natAbs≤K)
    (hM:H+m*increment K cs≤M) (hw:14≤M) (hl:5+(cs.length+1)^2≤M):
    ∀c∈RecordedCoordinateBank.program cs f D i m,Content M c:=by
  induction m generalizing D H i with
  | zero=>simp[RecordedCoordinateBank.program]
  | succ m ih=>
    have hfi:=hf i (by omega) (by omega)
    intro c hc';rcases List.mem_append.mp hc' with hc'|hc'
    · exact block_fields M K H D cs f i hD hc hfi (by nlinarith) hw hl c hc'
    · exact ih (H+increment K cs) (block D cs f i) (i+1)
        (block_bound K H D cs f i hD hc hfi)
        (fun j hj hji=>hf j (by omega) (by omega)) (by nlinarith) c hc'
#print axioms run_bound
#print axioms run_fields
end L3Emitter.NumericCoordinates

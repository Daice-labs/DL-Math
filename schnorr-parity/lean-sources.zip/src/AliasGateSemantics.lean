import PortSelection

namespace L3Emitter.AliasGateSemantics
open EREF EREF.GeneralRED REDWitness

def truth (α : Val) (l : Int) : Bool := decide (litVal α l = 1)

theorem truth_value (α : Val) (l : Int) : litVal α l = b2i (truth α l) := by
  have := litVal_nonneg α l
  have := litVal_le_one α l
  simp only [truth, b2i, decide_eq_true_eq]
  split <;> omega

theorem truth_neg (α : Val) (l : Int) (hl : l≠0) :
    truth α (-l) = !(truth α l) := by
  have h:=litVal_neg α l hl
  rw [truth_value α l,truth_value α (-l)] at h
  cases h1:truth α l <;> cases h2:truth α (-l) <;> simp_all [b2i]

theorem truth_nat (α : Val) (q : Nat) (hq : 0<q) :
    truth α (q:Int)=α q := by
  cases h:α q <;> simp [truth,litVal,hq,b2i,h]

theorem clause_sat (α : Val) (xs : List Int) (hv : Valid xs) :
    (clause xs).sat α ↔ ∃l∈xs,truth α l=true := by
  rw [Row.sat,val_clause xs hv]
  induction xs with
  | nil => simp [sum]
  | cons l ls ih =>
    rw [sum_cons]
    have ht:=ih (fun x hx=>hv x (by simp [hx]))
    have hn:=sum_nonneg α ls
    rw [truth_value α l]
    cases h:truth α l <;> simp_all [b2i]

def Models (α : Val) (D : List Row) := ∀R∈D,R.sat α

theorem models_mono (α : Val) (D E : List Row) (h : ∀R∈D,R∈E)
    (hs : Models α E) : Models α D := fun R hr=>hs R (h R hr)

theorem or_semantics (α : Val) (xs : List Int) (q : Nat) (hq : 0<q)
    (hv : Valid xs) (hs : Models α ((orGate xs).map (GateRow.row q))) :
    α q = xs.any (truth α) := by
  have up (x:Int) (hx:x∈xs) : truth α x=true → α q=true := by
    have h:=hs (clause [-x,(q:Int)]) (List.mem_map.mpr ⟨⟨[-x],true⟩,by simp [orGate,hx],rfl⟩)
    have ht:=(clause_sat α _ (by simp [Valid,hv x hx];omega)).mp h
    simp only [List.mem_cons,List.not_mem_nil,or_false] at ht
    intro he
    rcases ht with ⟨l,(rfl|rfl),hl⟩
    · rw [truth_neg α x (hv x hx),he] at hl;contradiction
    · simpa [truth_nat α q hq] using hl
  have down : α q=true → ∃x∈xs,truth α x=true := by
    have h:=hs (clause (xs++[-(q:Int)])) (List.mem_map.mpr ⟨⟨xs,false⟩,by simp [orGate],rfl⟩)
    have ht:=(clause_sat α _ (by
      intro l hl;rcases List.mem_append.mp hl with hl|hl
      · exact hv l hl
      · obtain rfl:=List.mem_singleton.mp hl;omega)).mp h
    intro he
    rcases ht with ⟨l,hl,ht⟩
    rcases List.mem_append.mp hl with hl|hl
    · exact ⟨l,hl,ht⟩
    · obtain rfl:=List.mem_singleton.mp hl
      rw [truth_neg α (q:Int) (by omega),truth_nat α q hq,he] at ht
      contradiction
  apply Bool.eq_iff_iff.mpr
  simpa only [List.any_eq_true] using ⟨down,fun ⟨x,hx,he⟩=>up x hx he⟩

theorem and_semantics (α : Val) (xs : List Int) (q : Nat) (hq : 0<q)
    (hv : Valid xs) (hs : Models α ((andGate xs).map (GateRow.row q))) :
    α q = xs.all (truth α) := by
  have down (x:Int) (hx:x∈xs) : α q=true → truth α x=true := by
    have h:=hs (clause [x,-(q:Int)]) (List.mem_map.mpr ⟨⟨[x],false⟩,by simp [andGate,hx],rfl⟩)
    have ht:=(clause_sat α _ (by simp [Valid,hv x hx];omega)).mp h
    intro he
    simp only [List.mem_cons,List.not_mem_nil,or_false] at ht
    rcases ht with ⟨l,(rfl|rfl),hl⟩
    · exact hl
    · rw [truth_neg α (q:Int) (by omega),truth_nat α q hq,he] at hl;contradiction
  have up (he:∀x∈xs,truth α x=true) : α q=true := by
    have h:=hs (clause (xs.map (-·)++[(q:Int)])) (List.mem_map.mpr ⟨⟨xs.map (-·),true⟩,by simp [andGate],rfl⟩)
    have ht:=(clause_sat α _ (by
      intro l hl;rcases List.mem_append.mp hl with hl|hl
      · obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hl;exact neg_ne_zero.mpr (hv x hx)
      · obtain rfl:=List.mem_singleton.mp hl;omega)).mp h
    rcases ht with ⟨l,hl,ht⟩
    rcases List.mem_append.mp hl with hl|hl
    · obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hl
      rw [truth_neg α x (hv x hx),he x hx] at ht;contradiction
    · obtain rfl:=List.mem_singleton.mp hl;simpa [truth_nat α q hq] using ht
  apply Bool.eq_iff_iff.mpr
  simpa only [List.all_eq_true] using ⟨fun h x hx=>down x hx h,up⟩

#print axioms clause_sat
#print axioms or_semantics
#print axioms and_semantics
end L3Emitter.AliasGateSemantics

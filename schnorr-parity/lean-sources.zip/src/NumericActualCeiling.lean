import NumericLowerComplete
import NumericClosedNamespace
import ActualTailOperandBounds
namespace L3Emitter.NumericActualCeiling
open EREF EREF.GeneralRED RecordedScopedTrace RecordedOperandFields FieldLengthsFromIDs

theorem ceiling (n:Nat) (hn:2≤n):
    ActualLowerComposition.ceiling n hn≤NumericClosedNamespace.envelope n:=
  (RawBankSize.ceiling_le _ _ (NumericLowerComplete.result n hn)).trans (NumericClosedNamespace.final n)

theorem inputs (n:Nat) (hn:2≤n):
    RowSupport.Bounded (NumericClosedNamespace.envelope n+FamilyNamespace.variableCount n (3*n-4))
      (ActualLowerComposition.inputs n hn):=by
  intro R hR
  have hr:=ActualLowerComposition.inputs_bound n hn R hR
  exact ⟨hr.1,fun t ht=>(hr.2 t ht).trans (Nat.add_le_add_right (ceiling n hn) _)⟩

theorem tail (n M A:Nat) (hn:2≤n) (p:Program) (h:∀c∈p,Content M c)
    (ha:∀R∈ActualLowerComposition.inputs n hn,ActualLowerComposition.amount R≤A):
    ∀c∈ActualRecordedTail.emit n hn (RecordedRecursiveStep.reserve n p)
      (RecordedRecursiveStep.shifted n hn p),
      Content (NumericClosedNamespace.envelope n+M+FamilyNamespace.variableCount n (3*n-4)+A+1) c:=by
  intro c hc
  apply RecursiveOperandBounds.content_mono _ c (ActualTailOperandBounds.tail n M A hn p h ha c hc)
  unfold ActualTailOperandBounds.tailBound
  have := ceiling n hn
  omega

#print axioms ceiling
#print axioms tail
end L3Emitter.NumericActualCeiling

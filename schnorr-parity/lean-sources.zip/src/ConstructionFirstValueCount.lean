import ConstructionValueBankCount

namespace L3Emitter.ConstructionFirstValueCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount

theorem hit_rows (n : Nat) (hn : 2≤n) (c : HitExclusions.Choice n) :
    (HitBranchBank.rows n hn c).length≤6*(n+1) := by
  have hg:(HitExclusions.gates n c).length≤c.gamma-1:=by
    exact (List.length_filter_le ..).trans_eq (by simp [List.length_map])
  have he:=congrArg List.length (HitSnapshots.properties n hn c.gamma c.gamma_lt).1
  simp only [List.length_map,HitSnapshots.inputs,HitSelectorRows.inputs,List.length_range] at he
  change (HitBranchBinding.es n hn c).length=c.gamma-1 at he
  simp only [HitBranchBank.rows,List.length_append,HitExclusions.rows,HitBranchBinding.cellRows,
    List.length_map,HitBranchBank.endRows,List.length_cons,List.length_nil,he]
  have hc:=c.gamma_lt
  omega

theorem hit (n : Nat) (hn : 2≤n) :
    (HitBranchBank.emitted n hn).length≤54*(n+1)^3 := by
  have he:=checked_body _ _ _ (HitBranchBank.loop_checks n hn _ (fun _ h=>h) _ (HitBranchBank.base_keeps n hn))
  rw [HitBranchBank.emitted,he]
  have h:=flat_bound (CategoryPrograms.choices n hn) (HitBranchBank.rows n hn) (6*(n+1)) (fun c hc=>hit_rows n hn c)
  have hc:=ForcingSize.chosen_bound (n+1) (by omega)
  change (CategoryPrograms.choices n hn).length≤9*(n+1)^2 at hc
  exact h.trans ((Nat.mul_le_mul_right (6*(n+1)) hc).trans_eq (by ring))

theorem receiving (n : Nat) (hn : 2≤n) :
    (ReceivingEdgeBank.emitted n hn).length≤18*(n+1)^2 := by
  have he:=checked_body _ _ _ (ReceivingEdgeBank.loop_checks n hn _ (fun _ h=>h) _ (fun _ h=>h))
  rw [ReceivingEdgeBank.emitted,he]
  change ((CategoryPrograms.choices n hn).flatMap (ReceivingEdgeBank.rows n hn)).length≤_
  rw [flat_exact _ _ 2 (by intro c hc;rfl)]
  have hc:=ForcingSize.chosen_bound (n+1) (by omega)
  change (CategoryPrograms.choices n hn).length≤9*(n+1)^2 at hc
  omega

theorem prepare (n : Nat) (hn : 2≤n) : (FirstValueBank.prepare n hn).length=10 := by
  simp only [FirstValueBank.prepare,List.length_append]
  rfl

theorem first_x (n : Nat) (hn : 2≤n) (x : Nat) : (FirstValueBank.xRows n hn x).length=17:=by
  rfl

theorem first (n : Nat) (hn : 2≤n) : (FirstValueBank.program n hn).length=17*2^n := by
  have he:=checked_body _ _ _ (FirstValueBank.checks n hn)
  rw [he]
  change ((List.range (FamilyNamespace.truthRows n)).flatMap (FirstValueBank.xRows n hn)).length=17*2^n
  rw [flat_exact _ _ 17 (by intro x hx;exact first_x n hn x),List.length_range]
  unfold FamilyNamespace.truthRows
  ring

theorem first_gate (n : Nat) (hn : 2≤n) :
    (FirstGateBase.program n hn).length≤16*(n+1)*2^n := by
  simp only [FirstGateBase.program,List.length_map,GlobalValueSize.jobs_count,FamilyNamespace.truthRows]
  have hw:AliasAssembly.width (n+1)≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);omega
  nlinarith [Nat.mul_le_mul_right (4*2^n) hw]

theorem global (n : Nat) (hn : 2≤n) :
    (GlobalValueInduction.program n hn).length≤85000*(n+1)^5*2^n := by
  have h:=GlobalValueSize.all_gate_commands_in_n n hn
  have hs:3*(n+1)-5≤3*(n+1):=Nat.sub_le ..
  have hw:4*n-4≤4*(n+1):=by omega
  have hj:(48*n+34)*(36*(n+1)^2)+1≤1729*(n+1)^3:=by
    have hh:=Nat.mul_le_mul_right (36*(n+1)^2) (show 48*n+34≤48*(n+1) by omega)
    nlinarith [Nat.one_le_pow (n+1) 3 (by omega)]
  have hp:=Nat.mul_le_mul hs (Nat.mul_le_mul hj (Nat.mul_le_mul_right 4 (Nat.mul_le_mul_left (2^n) hw)))
  exact h.trans (hp.trans (by nlinarith [Nat.zero_le ((n+1)^5*2^n)]))

#print axioms hit
#print axioms first
#print axioms global
end L3Emitter.ConstructionFirstValueCount

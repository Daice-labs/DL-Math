import FinalU2TapeBounds
import ConstructionFinalSmallCount
namespace L3Emitter.FinalSelectorTapeBounds
open EREF EREF.GeneralRED AliasNetwork AliasProgram U2ConstructionSize
open FinalOutputDefinitions

theorem guarded {ι : Type} (D : List Row) (g : Bit) (a q : ι→Bit) (ls : List (ι×Bool)) :
    (GuardedVectorTransport.tape D g a q ls).length=2+2*ls.length+2*ls.length^2 := by
  simp [GuardedVectorTransport.tape,GuardedTransport.tokens,GuardedTransport.padding,
    ClauseTransport.linkSteps,ClauseTransport.Link.tokens,GuardedVectorTransport.link,
    ClauseTransport.Link.target,ClauseTransport.padSteps,List.length_flatMap,
    List.length_flatten,List.map_map,Function.comp_def,List.sum_replicate,smul_eq_mul]
  ring

theorem unguarded {ι : Type} (D : List Row) (g : Bit) (a q : ι→Bit) (ls : List (ι×Bool)) :
    (GuardedVectorTransport.unguardedTape D g a q ls).length≤2+2*ls.length+2*ls.length^2 := by
  have h:=Nat.mul_le_mul_right ls.length (Nat.sub_le ls.length 1)
  simp [GuardedVectorTransport.unguardedTape,ClauseTransport.tokens,ClauseTransport.padding,
    ClauseTransport.linkSteps,ClauseTransport.Link.tokens,GuardedVectorTransport.link,
    ClauseTransport.Link.target,ClauseTransport.padSteps,List.length_flatMap,
    List.length_flatten,List.map_map,Function.comp_def,List.sum_replicate,smul_eq_mul]
  nlinarith

theorem mux {ι : Type} (D : List Row) (c : Bit) (a b q : ι→Bit) (ls : List (ι×Bool)) :
    tokens (MuxConditionalClause.program D c a b q ls)≤8+4*ls.length+4*ls.length^2 := by
  have h:=unguarded D (neg c) a q ls
  simp only [MuxConditionalClause.program,tokens_append]
  simp only [MuxConditionalClause.cases,tokens,List.map_cons,List.map_nil,List.sum_cons,
    List.sum_nil,guarded,Resolution.mergeTokens,List.length_cons,List.length_nil]
  nlinarith

theorem seed (n : Nat) (hn : 2≤n) (p : Fin 2) (ls : List (FinalSelectorSpecs.Lit n)) (D : List Row) :
    (FinalSelectorSeed.seedTape n hn p ls D).length≤2*ls.length+3 := by
  unfold FinalSelectorSeed.seedTape
  split
  · split <;> simp [ChoiceProjection.weakenTokens,ClauseTransport.padSteps]
  · have h:(((H n hn).val::GuardedVectorTransport.literals (FinalSelectorSeed.alternative n hn p) ls).erase
        (PrimaryAliasBank.cfg n hn).T.val).length≤ls.length+1 :=
      List.length_erase_le.trans_eq (by simp [GuardedVectorTransport.literals])
    simp [PrimaryAliasRows.unitTape,ChoiceProjection.weakenTokens,ClauseTransport.padSteps,
      List.length_flatMap,List.map_map,Function.comp_def,List.sum_replicate,smul_eq_mul]
    omega

theorem spec_length (n : Nat) (hn : 2≤n) (ls : List (FinalSelectorSpecs.Lit n))
    (hs : ls∈FinalSelectorSpecs.specs n) : ls.length≤4*(n+1) := by
  rcases FinalSelectorSpecs.spec_cases n ls hs with rfl|⟨i,j,hij,rfl⟩
  · simp [FinalSelectorSources.alo]
    unfold W AliasAssembly.width RankConstruction.width
    omega
  · simp [FinalSelectorSpecs.pair];omega

theorem leaf (n : Nat) (hn : 2≤n) (j : FinalSelectorBank.Job n)
    (hj : j.2∈FinalSelectorSpecs.specs n) (D : List Row) :
    tokens (FinalSelectorBank.leaf n hn j D)≤99*(n+1)^2 := by
  have hs:=seed n hn j.1 j.2 D
  have hm:=mux (D++[FinalSelectorSeed.seedRow n hn j.1 j.2]) (H n hn)
    (FinalSelectorSources.raw n hn j.1) (FinalSelectorSeed.alternative n hn j.1)
    (FinalSelectorSources.target n hn j.1) j.2
  have hl:=spec_length n hn j.2 hj
  have hsq:=Nat.pow_le_pow_left hl 2
  simp only [FinalSelectorBank.leaf,tokens_append]
  simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil]
  change (FinalSelectorSeed.seedTape n hn j.1 j.2 D).length+0+
    tokens (MuxConditionalClause.program _ _ _ _ _ _)≤_
  nlinarith

theorem selectors (n : Nat) (hn : 2≤n) :
    tokens (FinalSelectorBank.program n hn)≤4000*(n+1)^4 := by
  have h:=fold_tokens (FinalSelectorBank.leaf n hn) (FinalSelectorBank.rows n hn)
    (FinalSelectorBank.jobs n) (FinalSelectorSources.D n hn) (99*(n+1)^2)
    (by intro j hj D;exact leaf n hn j ((FinalSelectorBank.job_mem n j.1 j.2).mp hj) D)
  change tokens (FinalSelectorBank.program n hn)≤_ at h
  have hj:(FinalSelectorBank.jobs n).length=2*(FinalSelectorSpecs.specs n).length:=by
    simp [FinalSelectorBank.jobs,List.length_flatMap];omega
  have hw:W n-1≤4*(n+1):=by unfold W AliasAssembly.width RankConstruction.width;omega
  have hsq:=Nat.pow_le_pow_left hw 2
  have hs:=ConstructionFinalSmallCount.specs n
  have hc:(FinalSelectorBank.jobs n).length≤34*(n+1)^2:=by rw [hj];nlinarith
  exact h.trans ((Nat.mul_le_mul_right _ hc).trans (by nlinarith [sq_nonneg ((n+1)^2 : Int)]))

theorem cardinalities (n : Nat) (hn : 2≤n) :
    tokens (FinalSelectorCardinalities.program n hn)≤48*(n+1)^2 := by
  have h:=fold_tokens (FinalSelectorCardinalities.leaf n hn) (FinalSelectorCardinalities.rows n hn)
    (List.finRange 2) (FinalSelectorBank.result n hn) ((W n-1)^2+2*(W n-1)) (by
      intro p hp D;simpa only [FinalSelectorCardinalities.leaf,FinalSelectorCardinalities.xs,List.length_ofFn] using
        OneHotSize.tokens_bound D (FinalSelectorCardinalities.xs n hn p))
  change tokens (FinalSelectorCardinalities.program n hn)≤2*((W n-1)^2+2*(W n-1)) at h
  have hw:W n-1≤4*(n+1):=by unfold W AliasAssembly.width RankConstruction.width;omega
  have hsq:=Nat.pow_le_pow_left hw 2
  nlinarith
#print axioms selectors
#print axioms cardinalities
end L3Emitter.FinalSelectorTapeBounds

import CanonicalLineParser

set_option linter.unusedSimpArgs false
namespace L3Emitter.CanonicalFileGrammar
open EREF EREF.GeneralRED CanonicalScopeKernel CanonicalLineParser

/-- Parser states contain only previously parsed data, never expected commands. -/
inductive State where
  | main (rev : List CanonicalScopeKernel.Command)
  | consequence (rev : List CanonicalScopeKernel.Command) (R : EREF.Row) (tapes : List (List Tok))
  | red (rev : List CanonicalScopeKernel.Command) (R : EREF.Row) (w : FiniteWitness.Data) (goals : List Goal)
  | goal (rev : List CanonicalScopeKernel.Command) (R : EREF.Row) (w : FiniteWitness.Data)
      (goals : List Goal) (key : GoalKey) (tapes : List (List Tok))

def step : State→Event→Option State
  | .main cs,.pol ts=>some (.main (.pol ts::cs))
  | .main cs,.pbc R=>some (.consequence cs R [])
  | .main cs,.red R w=>some (.red cs R w [])
  | .consequence cs R ps,.pol ts=>some (.consequence cs R (ts::ps))
  | .consequence cs R ps,.close id=>some (.main (.consequence R ⟨ps.reverse,id⟩::cs))
  | .red cs R w gs,.goal key=>some (.goal cs R w gs key [])
  | .red cs R w gs,.endRed=>some (.main (.red R w gs.reverse::cs))
  | .goal cs R w gs key ps,.pol ts=>some (.goal cs R w gs key (ts::ps))
  | .goal cs R w gs key ps,.close id=>some (.red cs R w (⟨key,⟨ps.reverse,id⟩⟩::gs))
  | _,_=>none

def run (s : State) : List Event→Option State
  | []=>some s
  | e::es=>do run (←step s e) es

theorem run_append (s : State) (a b : List Event) :
    run s (a++b)=(run s a).bind (fun t=>run t b) := by
  induction a generalizing s with
  | nil=>rfl
  | cons a as ih=>
    simp only [List.cons_append,run,ih]
    cases step s a <;> rfl

def localEvents (p : LocalProof) := p.tapes.map Event.pol++[.close p.conclusion]
def goalEvents (g : Goal) := Event.goal g.key::localEvents g.proof

def commandEvents : CanonicalScopeKernel.Command→List Event
  | .pol ts=>[.pol ts]
  | .consequence R p=>.pbc R::localEvents p
  | .red R w gs=>.red R w::gs.flatMap goalEvents++[.endRed]

theorem consequence_tapes (cs : List CanonicalScopeKernel.Command) (R : EREF.Row) (rev ts : List (List Tok)) :
    run (.consequence cs R rev) (ts.map Event.pol)=some (.consequence cs R (ts.reverse++rev)) := by
  induction ts generalizing rev with
  | nil=>simp [run]
  | cons t ts ih=>simpa [run,step,List.reverse_cons,List.append_assoc] using ih (t::rev)

theorem goal_tapes (cs : List CanonicalScopeKernel.Command) (R : EREF.Row) (w : FiniteWitness.Data)
    (gs : List Goal) (key : GoalKey) (rev ts : List (List Tok)) :
    run (.goal cs R w gs key rev) (ts.map Event.pol)=some (.goal cs R w gs key (ts.reverse++rev)) := by
  induction ts generalizing rev with
  | nil=>simp [run]
  | cons t ts ih=>simpa [run,step,List.reverse_cons,List.append_assoc] using ih (t::rev)

theorem one_goal (cs : List CanonicalScopeKernel.Command) (R : EREF.Row) (w : FiniteWitness.Data)
    (gs : List Goal) (g : Goal) :
    run (.red cs R w gs) (goalEvents g)=some (.red cs R w (g::gs)) := by
  rcases g with ⟨key,⟨ts,id⟩⟩
  simp [goalEvents,localEvents,run,step,run_append,goal_tapes,bind,Option.bind]

theorem all_goals (cs : List CanonicalScopeKernel.Command) (R : EREF.Row) (w : FiniteWitness.Data)
    (rev gs : List Goal) :
    run (.red cs R w rev) (gs.flatMap goalEvents)=some (.red cs R w (gs.reverse++rev)) := by
  induction gs generalizing rev with
  | nil=>simp [run]
  | cons g gs ih=>
    simp only [List.flatMap_cons,run_append,one_goal,bind,Option.bind]
    simpa [List.reverse_cons,List.append_assoc] using ih (g::rev)

theorem one_command (cs : List CanonicalScopeKernel.Command) (c : CanonicalScopeKernel.Command) :
    run (.main cs) (commandEvents c)=some (.main (c::cs)) := by
  cases c with
  | pol ts=>rfl
  | consequence R p=>
    rcases p with ⟨ts,id⟩
    simp [commandEvents,localEvents,run,step,run_append,consequence_tapes,bind,Option.bind]
  | red R w gs=>
    simp only [commandEvents,List.cons_append,run,step,bind,Option.bind,run_append,all_goals,
      List.append_nil,List.reverse_reverse]

theorem all_commands (rev cs : List CanonicalScopeKernel.Command) :
    run (.main rev) (cs.flatMap commandEvents)=some (.main (cs.reverse++rev)) := by
  induction cs generalizing rev with
  | nil=>simp [run]
  | cons c cs ih=>
    simp only [List.flatMap_cons,run_append,one_command,bind,Option.bind]
    simpa [List.reverse_cons,List.append_assoc] using ih (c::rev)

def parse (es : List Event) : Option (List CanonicalScopeKernel.Command) := do
  match ←run (.main []) es with
  | .main cs=>some cs.reverse
  | _=>none

theorem commands_roundtrip (cs : List CanonicalScopeKernel.Command) :
    parse (cs.flatMap commandEvents)=some cs := by
  simp [parse,all_commands,bind,Option.bind]

#print axioms run_append
#print axioms commands_roundtrip
end L3Emitter.CanonicalFileGrammar

import GlobalPortValues
namespace L3Emitter.BaseTwo
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram

theorem small_prepared (F:L3.Fam) (hs:F.s=2) (t:L3.StI F.V):
    (F.preparedBank t).2=[]:=by
  simp [L3.Fam.preparedBank,L3.Fam.branchIndices,hs,L3.Fam.branchBank]

theorem small_stage7 (F:L3.Fam) (hs:F.s=2) (t:L3.StI F.V):
    F.stage7 t=(F.preparedBranches t).rup [((F.preparedBranches t).s.Bv:Int)]:=by
  simp [L3.Fam.stage7,L3.Fam.preparedBranches,L3.Fam.preparedBank,L3.Fam.branchIndices,hs,L3.Fam.branchBank]

def state (F:L3.Fam) (hs:1≤F.s):=F.stage6 (F.stage5 (F.V_pos hs) (F.t4 hs))
def root (F:L3.Fam) (hs:1≤F.s):=(F.preparedBranches (state F hs)).s.Bv

theorem state_good (F:L3.Fam) (hs:1≤F.s):F.Good3 (state F hs):=
  F.Good3_of_keeps2 (F.keeps2_stage6 _) (F.Good3_of_keeps2 (F.keeps2_stage5 _ _)
    (F.Good3_of_keeps2 (F.keeps2_stage4 _) (F.good3_stage3 hs)))

theorem both_rows (F:L3.Fam) (hs:F.s=2):
    clause [(root F (by omega):Int)]∈L3.exec F.db5 (F.frontendX (by omega)).s.cmds ∧
    clause [-(root F (by omega):Int)]∈L3.exec F.db5 (F.frontendX (by omega)).s.cmds:=by
  let t:=state F (by omega)
  let u:=F.preparedBranches t
  have hr:=F.prepared_ready t (state_good F (by omega))
  have he:(F.preparedBank t).2=[]:=small_prepared F hs t
  have ho:L3.Cmd.orDef u.s.Bv []∈u.s.cmds:=by simpa only [he] using hr.2.1
  have hb:L3.Bounded u.s.var [(u.s.Bv:Int)]:=by
    intro l hl;obtain rfl:=List.mem_singleton.mp hl
    simpa using And.intro hr.2.2.1 hr.2.2.2.1
  have hcmd:(F.frontendX (by omega)).s.cmds=u.s.cmds++[.rup [(u.s.Bv:Int)]]:=by
    change (F.stage7 t).s.cmds=_
    rw [small_stage7 F hs t,L3.StI.cmds_rup,L3.StI.chk_eq u _ hb]
  rw [hcmd]
  constructor
  · exact L3.rup_row_mem F.db5 _ _ (List.mem_append_right _ (List.mem_singleton_self _))
  · have h:=L3.orDef_row_down F.db5 (u.s.cmds++[.rup [(u.s.Bv:Int)]]) u.s.Bv [] (List.mem_append_left _ ho)
    simpa [L3.gateRow,L3.neg,L3.Row.toE,L3Emitter.REDWitness.clause] using h

def F:=FableEncoding.fam 2 2
def D:=L3.exec F.db5 (F.frontendX (by decide)).s.cmds

theorem frontend_trace:CheckedTrace (OriginalEncoding.rows 2 2) D:=by
  have hn:=FullNormalization.full_normalization_all 2 2 (by decide) (by decide)
  rw [←FableIntegration.final_rows_eq 2 2 (by decide)] at hn
  apply L3.Fam.checkedTrace_trans hn
  exact F.state_trace (by decide) (by decide) (F.frontendX (by decide)) (F.frontendX_obls (by decide) (by decide) rfl)

def program:Program:=[(clause [],CommonGuardResolve.tape D [] [] [] (root F (by decide):Int))]
def result:=D++[clause []]

theorem checks:check D program=some result:=by
  have h:=both_rows F rfl
  have hz:(root F (by decide):Int)≠0:=by
    have h:=(F.prepared_ready (state F (by decide)) (state_good F (by decide))).2.2.1
    change 1≤root F (by decide) at h
    omega
  have hp:=CommonGuardResolve.checks D [] [] [] (root F (by decide):Int)
    (by simp [Valid]) (by simp [Valid]) (by simp [Valid]) hz h.1 h.2
  change polEval (dbOf D) _ []=some (clause []) at hp
  simp only [program,check,hp,ite_true,result]

theorem original_to_contradiction:CheckedTrace (OriginalEncoding.rows 2 2) result:=
  L3.Fam.checkedTrace_trans frontend_trace (check_trace _ _ _ checks)
theorem empty_present:clause []∈result:=List.mem_append_right _ (List.mem_singleton_self _)
#print axioms original_to_contradiction
end L3Emitter.BaseTwo

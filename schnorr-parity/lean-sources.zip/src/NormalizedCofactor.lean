import FableIntegration
import CofactorSection

namespace L3Emitter.NormalizedCofactor
open EREF EREF.GeneralRED FamilyNamespace FamilyRows ReferenceTransport
open CofactorSemantics CofactorSection

theorem spec_bounded (k s : Nat) (r : Spec) (hr : r.valid k s) :
    RowSupport.Bounded (variableCount k s) [r.row k s] := by
  intro R hR
  have he := List.mem_singleton.mp hR
  subst R
  refine ⟨canonical_normalize _ _, RowSupport.normalize_bound _ _ _ ?_⟩
  intro t ht
  obtain ⟨l,hl,rfl⟩ := List.mem_map.mp ht
  have h := (encode_bounds k s l.1 (hr l hl)).2
  simp only [lit]
  split <;> simpa using h

theorem normalized_bounded (k s : Nat) (hk : 2≤k) (hs : 0<s) :
    RowSupport.Bounded (variableCount k s) (FullNormalization.finalRows k s) := by
  intro R hR
  rcases List.mem_append.mp hR with hR | hR
  · obtain ⟨r,hr,rfl⟩ := FullNormalization.projection_base_specs k s hk hs R hR
    exact spec_bounded k s r hr _ (by simp)
  · simp only [List.mem_cons,List.not_mem_nil,or_false] at hR
    rcases hR with rfl | rfl
    · exact spec_bounded k s (InputSwap.forbidden 0 3)
        (ProjectionNormalization.forbidden_valid k s 3 hs) _ (by simp)
    · exact spec_bounded k s (InputSwap.forbidden 0 12)
        (ProjectionNormalization.forbidden_valid k s 12 hs) _ (by simp)

theorem original_subset (k s : Nat) (R : Row) (hR : R∈OriginalEncoding.rows k s) :
    R∈FullNormalization.finalRows k s := by
  apply List.mem_append_left
  apply List.mem_append_left
  exact hR

def target (n s offset B : Nat) : List Row :=
  FullNormalization.finalRows (n+1) s++bank n s offset B

theorem database_subset (n s offset B : Nat) (R : Row)
    (hR : R∈database n s offset B) : R∈target n s offset B := by
  rcases List.mem_append.mp hR with hR | hR
  · exact List.mem_append_left _ (original_subset _ _ R hR)
  · exact List.mem_append_right _ hR

/-- Inserted normalization rows shift the bank's row references. Rebase every
    reference using its exact row in the new database, not a guessed offset. -/
def refMap (n s offset B i : Nat) : Nat :=
  locate (target n s offset B) ((dbOf (database n s offset B) i).getD contra)
def relocatedTape (n s offset B : Nat) (j : Job) : List Tok :=
  (resultTape n s offset B j).map (token (refMap n s offset B))

theorem relocated_succeeds (n s offset B : Nat) (hB : 0<B) (j : Job)
    (hj : j∈jobs n s) :
    polEval (dbOf (target n s offset B)) (relocatedTape n s offset B j) [] =
      some (resultRow n s offset j) := by
  have h := job_bounds n s j hj
  apply reindex (dbOf (database n s offset B)) _ (refMap n s offset B)
  · intro i R hi
    simp only [refMap,hi,Option.getD_some]
    exact locate_correct _ _ (database_subset _ _ _ _ R (dbOf_mem _ _ _ hi))
  · exact all_gate_semantics n s offset B j.1 j.2.1 hB h.1 h.2
      j.2.2.1 j.2.2.2.1 j.2.2.2.2

theorem relocated_trace (n s offset B : Nat) (hB : 0<B) (js : List Job)
    (hj : ∀ j∈js,j∈jobs n s) (pre : List Row) :
    CheckedTrace (target n s offset B++pre)
      ((target n s offset B++pre)++js.map (resultRow n s offset)) := by
  induction js generalizing pre with
  | nil => simpa using CheckedTrace.refl (target n s offset B++pre)
  | cons j js ih =>
    have he := relocated_succeeds n s offset B hB j (hj j (by simp))
    have hmono := polEval_mono _ _ (dbOf_ext_append (target n s offset B) pre)
      (relocatedTape n s offset B j) [] (resultRow n s offset j) he
    have ht := ih (by intro q hq; exact hj q (by simp [hq])) (pre++[resultRow n s offset j])
    have hc := CheckedTrace.cons (CheckedStep.pol _ _ _ hmono)
      (by simpa only [List.append_assoc] using ht)
    simpa only [List.map_cons,List.append_assoc,List.singleton_append] using hc

/-- One checked trace starts at the original formula, crosses Fable's exact
    normalization boundary, allocates the complete bank and checks all cofactor
    semantics tapes. This is still not the rank/alias/output transport. -/
theorem normalized_through_semantics (n offset B : Nat) (hn : 2≤n)
    (hV : variableCount (n+1) (3*(n+1)-4)≤offset) (hB : 0<B) (hBm : B≤offset) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4))
      (target n (3*(n+1)-4) offset B++
        (jobs n (3*(n+1)-4)).map (resultRow n (3*(n+1)-4) offset)) := by
  have hs : 0<3*(n+1)-4 := by omega
  have hnrm := FableIntegration.normalization_trace (n+1) (by omega)
  have hbounded := RowSupport.mono _ hV (normalized_bounded _ _ (by omega) hs)
  have hbank := (CofactorBank.bank_trace n (3*(n+1)-4) offset B hV hB hBm _ hbounded).1
  have hleaves := relocated_trace n (3*(n+1)-4) offset B hB
    (jobs n (3*(n+1)-4)) (by intros; assumption) []
  exact L3.Fam.checkedTrace_trans hnrm
    (L3.Fam.checkedTrace_trans hbank (by simpa [target] using hleaves))

theorem relocated_token_count (n s offset B : Nat) (j : Job) :
    (relocatedTape n s offset B j).length=70 := by
  simp only [relocatedTape,List.length_map,resultTape]
  exact tape_length ..

#print axioms normalized_through_semantics
#print axioms relocated_token_count
end L3Emitter.NormalizedCofactor

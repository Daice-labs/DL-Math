import FinalFunctionSlots
namespace L3Emitter.FunctionChainPOL
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL ReferenceTransport

def sourceGuards (f u:Bit) (r v:Bool):List Int:=[-sign r f,-sign v u]
def keptRows (f u h phase middle q:Bit) (r v side:Bool):List Row:=
  [guarded (sourceGuards f u r v++[-h.val]) (sign v middle),
   guarded ((sourceGuards f u r v++[-h.val])++[-sign side phase]) (sign (v^^side) q)]
def keptProgram (D:List Row) (f u h phase composed middle q:Bit) (r v side:Bool):Program:=
  let mid:=guarded (sourceGuards f u r v++[-h.val]) (sign v middle)
  [(mid,GuardedJoin.tape D (sourceGuards f u r v) [-h.val] (sign v composed) (sign v middle)),
   (guarded ((sourceGuards f u r v++[-h.val])++[-sign side phase]) (sign (v^^side) q),
     GuardedJoin.tape (D++[mid]) (sourceGuards f u r v++[-h.val]) [-sign side phase] (sign v middle) (sign (v^^side) q))]

theorem kept_check (D:List Row) (f u h phase composed middle q:Bit) (r v side:Bool)
    (hc:GuardedJoin.link [-sign r f] (sign v u) (sign v composed)∈D)
    (hm:GuardedJoin.link [-h.val] (sign v composed) (sign v middle)∈D)
    (hq:GuardedJoin.link [-sign side phase] (sign v middle) (sign (v^^side) q)∈D):
    check D (keptProgram D f u h phase composed middle q r v side)=some (D++keptRows f u h phase middle q r v side):=by
  have hs:guarded (sourceGuards f u r v) (sign v composed)∈D:=hc
  have hv:Valid (sourceGuards f u r v):=by simp [sourceGuards,Valid,sign_valid]
  have hh:Valid [-h.val]:=by simp [Valid,h.property]
  have hp:Valid [-sign side phase]:=by simp [Valid,sign_valid]
  have h0:=GuardedJoin.checks D _ _ _ _ hv hh (sign_valid _ _) (sign_valid _ _) hs hm
  let mid:=guarded (sourceGuards f u r v++[-h.val]) (sign v middle)
  have h1:=GuardedJoin.checks (D++[mid]) _ _ _ _ (EvaluationCaseSeeds.valid_join hv hh) hp
    (sign_valid _ _) (sign_valid _ _) (List.mem_append_right _ (List.mem_singleton_self _)) (List.mem_append_left _ hq)
  simp only [keptProgram,keptRows,check,h0,GuardedJoin.target,↓reduceIte] at *
  rw [h1]
  simp only [GuardedJoin.target,↓reduceIte,List.append_assoc,List.singleton_append]

def chosenRows (u h phase q:Bit) (v side:Bool):List Row:=
  [guarded ([h.val,-sign v u]++[-sign side phase]) (sign (v^^side) q)]
def chosenProgram (D:List Row) (u h phase middle q:Bit) (v side:Bool):Program:=
  [(guarded ([h.val,-sign v u]++[-sign side phase]) (sign (v^^side) q),
    GuardedJoin.tape D [h.val,-sign v u] [-sign side phase] (sign v middle) (sign (v^^side) q))]
theorem chosen_check (D:List Row) (u h phase middle q:Bit) (v side:Bool)
    (hm:GuardedJoin.link [h.val] (sign v u) (sign v middle)∈D)
    (hq:GuardedJoin.link [-sign side phase] (sign v middle) (sign (v^^side) q)∈D):
    check D (chosenProgram D u h phase middle q v side)=some (D++chosenRows u h phase q v side):=by
  have hh:=GuardedJoin.checks D [h.val,-sign v u] [-sign side phase] _ _
    (by simp [Valid,h.property,sign_valid]) (by simp [Valid,sign_valid]) (sign_valid _ _) (sign_valid _ _) hm hq
  simp only [chosenProgram,chosenRows,check,hh,GuardedJoin.target,↓reduceIte]

theorem phase_link (D:List Row) (j:RecordedExpressions.Job) (phase middle:Bit) (side v:Bool)
    (hc:j.c=phase) (ha:j.a=neg middle) (hb:j.b=middle)
    (hj:∀R∈RecordedExpressions.jobRows j,R∈D):
    GuardedJoin.link [-sign side phase] (sign v middle) (sign (v^^side) j.q)∈D:=by
  have h:=hj _ (UnaryValueStep.mux_link j side (v^^side))
  rw [hc,ha,hb] at h
  cases side <;> cases v <;> simpa [sign,neg] using h
#print axioms kept_check
#print axioms chosen_check
#print axioms phase_link
end L3Emitter.FunctionChainPOL

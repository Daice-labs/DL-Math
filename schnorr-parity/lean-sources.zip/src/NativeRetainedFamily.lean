import NativeParserRuntimeFields
import NativeRuntimeRangeClosure
namespace L3Emitter.NativeRetainedFamily
open EREF EREF.GeneralRED PinnedRetainedPacked PinnedRetainedStore NativeRuntimeSupport

def initial (D:List Row) (hc:∀R∈D,Canonical R):Store:=
 ⟨D.length+1,fun i=>match h:dbOf D i with
   | none=>none
   | some R=>some (pack R (hc R (dbOf_mem D i R h)))⟩

theorem initial_project (D:List Row) (hc:∀R∈D,Canonical R):project (initial D hc)=NativeSparseStore.initial D:=by
 unfold project initial NativeSparseStore.initial
 congr 1
 funext i
 dsimp only
 split
 · rename_i he;simp [he]
 · rename_i Q he;simp [he]

theorem initial_normal (D:List Row) (hc:∀R∈D,Canonical R):PinnedRetainedStore.Normal (initial D hc):=by
 intro i R hr
 unfold initial at hr
 dsimp only at hr
 split at hr
 · contradiction
 · have he:=Option.some.inj hr
   subst R
   simp [PinnedRetainedRED.Normal,pack,PinnedRetainedPacked.row,PinnedIntegerRepresentations.smallest_row]

theorem original_canonical (n:Nat):∀R∈(NativeParserBundle.parsed n).original,Canonical R:=by
 intro R hR
 obtain ⟨Q,hQ,rfl⟩:=List.mem_map.mp hR
 exact PinnedCoordinateChange.canonical _ (PinnedCoordinateChange.coordinate_pos _) Q

def start (n:Nat):Store:=initial (NativeParserBundle.parsed n).original (original_canonical n)

theorem initial_vars (K:Nat) (D:List Row) (hc:∀R∈D,Canonical R) (hb:∀R∈D,RowVars K R):
 StoreVars K (project (initial D hc)):=by
 rw [initial_project]
 intro i R hr
 have hm:=dbOf_mem D i R hr
 exact ⟨hc R hm,hb R hm⟩

/-- Retained-tag arithmetic, literal buffering, RED goals and physical scopes
execute the actual parsed command family. The only machine premise here is
native distinct-name count; reference parsing has its separate counter bound.
This is a source-aligned Lean runtime, not a compiled-binary theorem. -/
theorem execution (n:Nat) (hn:2≤n) (hK:(NativeParserBundle.names n).length<2^63):
 ∃q,PinnedRetainedScope.run (start n) (NativeParserBundle.parsed n).commands=some q ∧
 project q=PinnedCoordinateChange.store (PinnedCoordinateChange.coordinate (NativeParserBundle.names n))
   (NativeCompatibleFamily.compiled n).store ∧ PinnedRetainedStore.Normal q ∧
 ∃R,read q ((NativeParserBundle.parsed n).conclusion:Int)=some R ∧
 PinnedRetainedPacked.row R=REDWitness.clause []:=by
 have hs:project (start n)=NativeSparseStore.initial (NativeParserBundle.parsed n).original:=initial_project _ _
 have hx:=PinnedInternedFamily.physical (NativeParserBundle.names n) n hn
 change PinnedScopeExecution.run (NativeSparseStore.initial (NativeParserBundle.parsed n).original)
   (NativeParserBundle.parsed n).commands=some _ at hx
 rw [←hs] at hx
 obtain ⟨q,hq,hpq,hqn⟩:=retained_run (NativeParserBundle.names n).length (start n) _ _ hK
   (initial_normal _ _) (initial_vars _ _ _ (NativeParserRuntimeFields.family_original n))
   (NativeParserRuntimeFields.family_commands n hn) hx
 have hr:=read_project q ((NativeParserBundle.parsed n).conclusion:Int)
 change (read q (NativeCompatibleFamily.conclusion n:Int)).map PinnedRetainedPacked.row=
   NativeSparseStore.read (project q) (NativeCompatibleFamily.conclusion n:Int) at hr
 rw [hpq,PinnedInternedFamily.row_read,(NativeCompatibleFamily.execution n hn).2,
   Option.map_some,PinnedCoordinateChange.empty_clause] at hr
 exact ⟨q,hq,hpq,hqn,Option.map_eq_some_iff.mp hr⟩
#print axioms execution
end L3Emitter.NativeRetainedFamily

import ClauseTransport
import PolTapeBytes

/- Explicit POL transport through an OR of a subset of one-hot choices.
   The hypotheses name actual rows, not a proof-search or entailment oracle. -/
namespace L3Emitter.ChoiceProjection
open EREF EREF.GeneralRED REDWitness Resolution ReferenceTransport
open LocalCombination ClauseTransport CaseJoin

def exclusions (c : Int) (xs : List Int) : List Row :=
  xs.map (fun x => clause [-c,-x])

def padding (c q : Int) (xs : List Int) : List Int :=
  -c :: List.replicate xs.length (-q)

def excludedSum (c q : Int) (xs : List Int) : Row :=
  chain (chain (clause (-q::xs)) (exclusions c xs))
    ((padding c q xs).map litAxiom)

theorem exclusions_value (c : Int) (hc : c≠0) (xs : List Int)
    (hx : Valid xs) (α : Val) :
    ((exclusions c xs).map (fun R => R.val α)).sum =
      xs.length * litVal α (-c) - sum α xs := by
  induction xs with
  | nil => simp [exclusions]
  | cons x xs ih =>
    have hz := hx x (by simp)
    have ht := ih (by intro y hy; exact hx y (by simp [hy]))
    simp only [exclusions,List.map_cons,List.sum_cons,List.length_cons,
      Nat.cast_add,Nat.cast_one]
    rw [val_clause _ (by simp [Valid,hc,hz])]
    change _ + ((exclusions c xs).map (fun R => R.val α)).sum = _
    rw [ht]
    simp only [sum_cons,sum_nil,litVal_neg α x hz]
    ring

theorem literal_sum (xs : List Int) (hx : Valid xs) (α : Val) :
    ((xs.map litAxiom).map (fun R => R.val α)).sum = sum α xs := by
  simp only [List.map_map,sum]
  apply congrArg List.sum
  apply List.map_congr_left
  intro l hl
  exact val_litAxiom l (hx l hl) α

theorem padding_value (c q : Int) (xs : List Int) (α : Val) :
    sum α (padding c q xs) = litVal α (-c) + xs.length*litVal α (-q) := by
  simp [padding,sum_cons,sum,List.map_replicate,List.sum_replicate]

theorem excluded_scaled (c q : Int) (xs : List Int)
    (hc : c≠0) (hq : q≠0) (hx : Valid xs) :
    excludedSum c q xs = scaled (xs.length+1) (clause [-c,-q]) := by
  have hp : Valid (padding c q xs) := by
    intro l hl
    simp only [padding,List.mem_cons,List.mem_replicate] at hl
    rcases hl with rfl|⟨_,rfl⟩ <;> omega
  have hcan : ∀ R∈exclusions c xs,Canonical R := by
    intro R hR; obtain ⟨x,hx,rfl⟩ := List.mem_map.mp hR
    exact canonical_normalize _ _
  apply canonical_ext _ _
    (chain_canonical _ _ (chain_canonical _ _ (canonical_normalize _ _)))
    (canonical_scaled _ (by omega) _ (canonical_normalize _ _))
  intro α
  change (excludedSum c q xs).val α = (scaled (xs.length+1) (clause [-c,-q])).val α
  rw [excludedSum,chain_value (chain (clause (-q::xs)) (exclusions c xs))
    ((padding c q xs).map litAxiom) (chain_canonical _ _ (canonical_normalize _ _))
    (by intro R hR; obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hR; exact canonical_litAxiom _),
    chain_value (clause (-q::xs)) (exclusions c xs) (canonical_normalize _ _) hcan,
    literal_sum _ hp, padding_value,exclusions_value c hc xs hx,
    val_scaled]
  rw [val_clause (-q::xs) (by intro l hl; rcases List.mem_cons.mp hl with rfl|hl; omega; exact hx l hl),
    val_clause [-c,-q] (by simp [Valid,hc,hq])]
  simp only [sum_cons,sum_nil,Nat.cast_add,Nat.cast_one]
  ring

def excludeTokens (rows : List Row) (c q : Int) (xs : List Int) : List Tok :=
  [.ref (locate rows (clause (-q::xs)))] ++
    steps rows (exclusions c xs) ++ padSteps (padding c q xs) ++ [.div (xs.length+1)]

theorem exclude_succeeds (rows : List Row) (c q : Int) (xs : List Int)
    (hc : c≠0) (hq : q≠0) (hx : Valid xs)
    (hor : clause (-q::xs)∈rows)
    (hamo : ∀ x∈xs,clause [-c,-x]∈rows) :
    polEval (dbOf rows) (excludeTokens rows c q xs) [] = some (clause [-c,-q]) := by
  have hp : Valid (padding c q xs) := by
    intro l hl; simp only [padding,List.mem_cons,List.mem_replicate] at hl
    rcases hl with rfl|⟨_,rfl⟩ <;> omega
  have he := excluded_scaled c q xs hc hq hx
  simp only [excludeTokens,List.append_assoc,List.cons_append,List.nil_append,
    polEval,locate_correct rows _ hor]
  rw [steps_eval _ _ (by intro R hR; obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hR; exact hamo x hx),
    padSteps_eval _ _ hp]
  change some (divide (excludedSum c q xs) (xs.length+1)) = _
  rw [he,divide_scaled (xs.length+1) (by omega) (clause [-c,-q]) (canonical_normalize _ _)]

theorem exclude_token_count (rows : List Row) (c q : Int) (xs : List Int) :
    (excludeTokens rows c q xs).length = 4*xs.length+4 := by
  simp [excludeTokens,steps,exclusions,padSteps,padding,List.length_flatMap,
    List.map_map,Function.comp_def]
  omega

/-- Add explicit literal nonnegativity operands to an existing clause. -/
def weakenTokens (rows : List Row) (xs ys : List Int) : List Tok :=
  [.ref (locate rows (clause xs))] ++ padSteps ys

theorem weakened (xs ys : List Int) (hx : Valid xs) (hy : Valid ys) :
    chain (clause xs) (ys.map litAxiom) = clause (xs++ys) := by
  apply canonical_ext _ _ (chain_canonical _ _ (canonical_normalize _ _)) (canonical_normalize _ _)
  intro α
  rw [chain_value _ _ (canonical_normalize _ _)
    (by intro R hR; obtain ⟨y,hy,rfl⟩:=List.mem_map.mp hR; exact canonical_litAxiom _),
    literal_sum _ hy]
  change (clause xs).val α + sum α ys = (clause (xs++ys)).val α
  rw [val_clause xs hx,val_clause (xs++ys)
    (by intro l hl; rcases List.mem_append.mp hl with hl|hl; exact hx l hl; exact hy l hl),
    sum_append]
  ring

theorem weaken_succeeds (rows : List Row) (xs ys : List Int)
    (hx : Valid xs) (hy : Valid ys) (hrow : clause xs∈rows) :
    polEval (dbOf rows) (weakenTokens rows xs ys) [] = some (clause (xs++ys)) := by
  simp only [weakenTokens,List.cons_append,List.nil_append,polEval,locate_correct rows _ hrow]
  have he := padSteps_eval (dbOf rows) ys hy (clause xs) [] []
  simp only [List.append_nil,polEval] at he
  rw [he,weakened xs ys hx hy]

#print axioms exclude_succeeds
#print axioms exclude_token_count
#print axioms weaken_succeeds
end L3Emitter.ChoiceProjection

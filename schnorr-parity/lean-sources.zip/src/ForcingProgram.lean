import ForcingBinding

namespace L3Emitter.ForcingProgram
open EREF EREF.GeneralRED REDWitness RankProjection AliasProgram
open ForcingPOL ForcingDefinitions ForcingBinding

def eligibleRow (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) := clause [-c.lit,eligible k hk c]
def consumerRow (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) := clause [-c.lit,consumer k hk c]
def prepared (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) :=
  FrontendSelection.finalRows k hk++[eligibleRow k hk c,consumerRow k hk c]
def prepProgram (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) : Program :=
  [(eligibleRow k hk c,PriorityExclusive.tokens (FrontendSelection.finalRows k hk)
    c.lit (SelectedBranch.raw k hk c:Int) (eligible k hk c)),
   (consumerRow k hk c,PriorityExclusive.tokens
    (FrontendSelection.finalRows k hk++[eligibleRow k hk c]) c.lit (eligible k hk c) (consumer k hk c))]

theorem prep_check (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (hc : c∈BranchChoices.chosen k hk) :
    check (FrontendSelection.finalRows k hk) (prepProgram k hk c)=some (prepared k hk c) := by
  have he:=SelectedBranch.eligible_step k hk c hc
  have h:=consumer_rows k hk c
  have hf:=PriorityExclusive.succeeds (FrontendSelection.finalRows k hk++[eligibleRow k hk c])
    c.lit (eligible k hk c) (consumer k hk c) c.nonzero h.1 h.2.1
    (by simp [eligibleRow]) (List.mem_append_left _ h.2.2.1)
  simp only [prepProgram,check,eligibleRow,consumerRow,eligible] at he hf ⊢
  rw [if_pos he,if_pos hf]
  simp [check,prepared,eligibleRow,consumerRow,eligible,List.append_assoc]

def gate (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat) : Gate :=
  ⟨c.lit,consumer k hk c,(port k hk c 0 m).p,(port k hk c 1 (m+2)).p,
   (m+1:Int),(m+2:Int),(m+3:Int),(m+4:Int)⟩
def coverageRows (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat) : List Row :=
  [(port k hk c 0 m).target,(port k hk c 1 (m+2)).target,(gate k hk c m).target]
def program (D : List Row) (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat) : Program :=
  let p0:=port k hk c 0 m
  let p1:=port k hk c 1 (m+2)
  [(p0.target,p0.tokens D),
   (p1.target,p1.tokens (D++[p0.target])),
   ((gate k hk c m).target,(gate k hk c m).tokens (D++[p0.target,p1.target]))]

theorem port_check (D : List Row) (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (p m : Nat)
    (hp : p<2) (hD : ∀R∈FrontendSelection.finalRows k hk,R∈D)
    (h0 : clause [-c.lit,-(port k hk c p m).sel,-(port k hk c p m).e0,(m+1:Int)]∈D)
    (h1 : clause [-c.lit,-(port k hk c p m).sel,-(port k hk c p m).e1,(m+2:Int)]∈D) :
    polEval (dbOf D) ((port k hk c p m).tokens D) []=some (port k hk c p m).target := by
  have h:=port_old k hk c p m hp
  apply port_succeeds _ _ h.1 (hD _ h.2.1)
  intro R hR
  simp only [Port.rs,List.mem_cons,List.not_mem_nil,or_false] at hR
  rcases hR with rfl|rfl|rfl|rfl|rfl
  · exact hD _ h.2.1
  · exact hD _ h.2.2.1
  · exact hD _ h.2.2.2
  · exact h0
  · exact h1

theorem program_check (D : List Row) (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat)
    (hD : ∀R∈FrontendSelection.finalRows k hk,R∈D)
    (hC : consumerRow k hk c∈D)
    (hdefs : ∀R∈(input k hk c).rows m,R∈D) :
    check D (program D k hk c m)=some (D++coverageRows k hk c m) := by
  let p0:=port k hk c 0 m
  let p1:=port k hk c 1 (m+2)
  have hh:=back_rows [] (input k hk c) m
  simp only [List.nil_append] at hh
  have he0:=port_check D k hk c 0 m (by decide) hD (hdefs _ hh.1) (hdefs _ hh.2.1)
  have h10 : clause [-c.lit,-p1.sel,-p1.e0,(m+2+1:Int)]∈D := by
    simpa [p1,port,input,Nat.cast_add,Nat.cast_ofNat,add_assoc] using hdefs _ hh.2.2.1
  have h11 : clause [-c.lit,-p1.sel,-p1.e1,(m+2+2:Int)]∈D := by
    simpa [p1,port,input,Nat.cast_add,Nat.cast_ofNat,add_assoc] using hdefs _ hh.2.2.2
  have he1:=port_check (D++[p0.target]) k hk c 1 (m+2) (by decide)
    (by intro R hR;exact List.mem_append_left _ (hD R hR))
    (List.mem_append_left _ h10) (List.mem_append_left _ h11)
  have hg:=(consumer_rows k hk c)
  have hv0:=(port_old k hk c 0 m (by decide)).1
  have hv1:=(port_old k hk c 1 (m+2) (by decide)).1
  have hp0 : p0.p≠0 := hv0 _ (by simp [p0])
  have hp1 : p1.p≠0 := hv1 _ (by simp [p1])
  have hv : (gate k hk c m).valid := by
    change Valid [c.lit,consumer k hk c,p0.p,p1.p,(m+1:Int),(m+2:Int),(m+3:Int),(m+4:Int)]
    intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> try omega
    exact c.nonzero
  have he2:=gate_succeeds (D++[p0.target,p1.target]) (gate k hk c m) hv
    (List.mem_append_left _ hC) (by
      intro R hR
      simp only [Gate.rs,List.mem_cons,List.not_mem_nil,or_false] at hR
      rcases hR with rfl|rfl|rfl
      · exact List.mem_append_left _ (hD _ hg.2.2.2)
      · simp [gate,p0,Port.target,port]
      · simp [gate,p1,Port.target,port,Nat.cast_add,Nat.cast_ofNat,add_assoc])
  simp only [program,check,he0,↓reduceIte]
  change (if polEval (dbOf (D++[p0.target])) _ []=_ then _ else _)=_
  rw [if_pos he1]
  simp only [List.append_assoc,List.singleton_append]
  rw [if_pos he2]
  simp [check,coverageRows,p0,p1,List.append_assoc]

#print axioms prep_check
#print axioms program_check
end L3Emitter.ForcingProgram

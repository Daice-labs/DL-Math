import ForcingFamily

namespace L3Emitter.ForcingCandidates
open EREF EREF.GeneralRED REDWitness RankProjection
open ForcingBinding ForcingDefinitions ForcingProgram ForcingBounds ForcingConstruction

structure Candidate (s : Nat) where
  parent : Choice s
  port : Nat
  bit : Nat
  var : Nat

def fields (k : Nat) (hk : 3≤k) (z : Candidate (3*k-4)) : List Int :=
  [z.parent.lit,((FableEncoding.fam k (3*k-4)).sel z.parent.beta z.port 0:Int),
   ((FrontendSelection.front k hk).s.eqrow z.parent.beta z.port z.bit:Int)]
def four {s : Nat} (c : Choice s) (m : Nat) : List (Candidate s) :=
  [⟨c,0,0,m+1⟩,⟨c,0,1,m+2⟩,⟨c,1,0,m+3⟩,⟨c,1,1,m+4⟩]
def bank {s : Nat} (m : Nat) : List (Choice s)→List (Candidate s)
  | [] => []
  | c::cs => four c m++bank (m+4) cs

theorem raw_identity (k : Nat) (m : Nat) (cs : List (Choice (3*k-4))) :
    (bank m cs).map (fun z=>(z.var:Int))=ForcingJoin.literals (ForcingFamily.pairs k m cs) := by
  induction cs generalizing m with
  | nil => rfl
  | cons c cs ih => simp [bank,four,ForcingFamily.pairs,ForcingJoin.literals,ih]

theorem wellformed {s : Nat} (m : Nat) (cs : List (Choice s)) (z : Candidate s) (hz : z∈bank m cs) :
    z.parent∈cs ∧ z.port<2 ∧ z.bit<2 ∧ 0<z.var := by
  induction cs generalizing m with
  | nil => simp [bank] at hz
  | cons c cs ih =>
    rcases List.mem_append.mp hz with hz|hz
    · simp only [four,List.mem_cons,List.not_mem_nil,or_false] at hz
      rcases hz with rfl|rfl|rfl|rfl <;> simp <;> omega
    · have ht:=ih (m+4) hz;exact ⟨List.mem_cons_of_mem _ ht.1,ht.2⟩

theorem four_command (k : Nat) (hk : 3≤k) (c : Choice (3*k-4)) (m : Nat)
    (z : Candidate (3*k-4)) (hz : z∈four c m) :
    L3.Cmd.andDef z.var (fields k hk z)∈(input k hk c).cmds m := by
  simp only [four,List.mem_cons,List.not_mem_nil,or_false] at hz
  rcases hz with rfl|rfl|rfl|rfl <;> simp [fields,input,Input.cmds]

theorem source_rows (k : Nat) (hk : 3≤k) (m : Nat) (cs : List (Choice (3*k-4)))
    (z : Candidate (3*k-4)) (hz : z∈bank m cs) (x : Int) (hx : x∈fields k hk z)
    (hnz : x≠0) : clause [-(z.var:Int),x]∈ForcingFamily.bodies k hk m cs := by
  have hv:=(wellformed m cs z hz).2.2.2
  induction cs generalizing m with
  | nil => simp [bank] at hz
  | cons c cs ih =>
    rcases List.mem_append.mp hz with hz|hz
    · have hr:=L3.andDef_row_down [] ((input k hk c).cmds m) z.var (fields k hk z)
        (four_command k hk c m z hz) x hx
      change clause [x,-(z.var:Int)]∈L3.exec [] ((input k hk c).cmds m) at hr
      rw [exec_flat,List.nil_append,PriorityExclusive.clause_swap _ _ hnz (by omega)] at hr
      exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hr))
    · exact List.mem_append_right _ (ih (m+4) hz)

def candidates (k : Nat) (hk : 3≤k) := bank (ceiling k hk) (BranchChoices.chosen k hk)

theorem selected_source (k : Nat) (hk : 3≤k) (n : PriorityBank.Node)
    (hn : n∈PriorityBank.nodes (ForcingFamily.upper k hk+1) (ForcingFamily.raw k hk)) :
    ∃z∈candidates k hk,n.input=(z.var:Int) ∧ z.parent∈BranchChoices.chosen k hk ∧
      z.port<2 ∧ z.bit<2 ∧ clause [-(n.choice:Int),n.input]∈ForcingFamily.selected k hk := by
  have hi : n.input∈ForcingFamily.raw k hk := by
    rw [←PrioritySelection.inputs_nodes (ForcingFamily.upper k hk+1) (ForcingFamily.raw k hk)]
    exact List.mem_map.mpr ⟨n,hn,rfl⟩
  change n.input∈ForcingJoin.literals (ForcingFamily.pairs k (ceiling k hk) (BranchChoices.chosen k hk)) at hi
  rw [←raw_identity] at hi
  obtain ⟨z,hz,he⟩:=List.mem_map.mp hi
  have hw:=wellformed _ _ z hz
  refine ⟨z,hz,he.symm,hw.1,hw.2.1,hw.2.2.1,?_⟩
  exact PrioritySourceBinding.allocated_source_row _ _ _
    (L3.bounded_nz (ForcingFamily.raw_bounded k _ _)) n hn

theorem above {s : Nat} (m : Nat) (cs : List (Choice s)) (z : Candidate s) (hz : z∈bank m cs) : m<z.var := by
  induction cs generalizing m with
  | nil => simp [bank] at hz
  | cons c cs ih =>
    rcases List.mem_append.mp hz with hz|hz
    · simp only [four,List.mem_cons,List.not_mem_nil,or_false] at hz
      rcases hz with rfl|rfl|rfl|rfl <;> dsimp <;> omega
    · have:=ih (m+4) hz;omega

theorem bit_from_var {s : Nat} (m : Nat) (cs : List (Choice s)) (z : Candidate s) (hz : z∈bank m cs) :
    (z.var-(m+1))%2=z.bit := by
  induction cs generalizing m with
  | nil => simp [bank] at hz
  | cons c cs ih =>
    rcases List.mem_append.mp hz with hz|hz
    · simp only [four,List.mem_cons,List.not_mem_nil,or_false] at hz
      rcases hz with rfl|rfl|rfl|rfl <;> dsimp <;> omega
    · have h:=ih (m+4) hz;have:=above (m+4) cs z hz;omega

theorem fields_valid (k : Nat) (hk : 3≤k) (z : Candidate (3*k-4))
    (hz : z∈candidates k hk) : Valid (fields k hk z) := by
  have hw:=wellformed (ceiling k hk) (BranchChoices.chosen k hk) z hz
  have hp:=(ForcingBinding.port_old k hk z.parent z.port 0 hw.2.1).1
  have hb:z.bit=0 ∨ z.bit=1 := by omega
  have hs : ((FableEncoding.fam k (3*k-4)).sel z.parent.beta z.port 0:Int)≠0 :=
    hp _ (by simp [ForcingBinding.port])
  have he : ((FrontendSelection.front k hk).s.eqrow z.parent.beta z.port z.bit:Int)≠0 := by
    rcases hb with hb|hb <;> rw [hb]
    · exact hp _ (by simp [ForcingBinding.port])
    · exact hp _ (by simp [ForcingBinding.port])
  intro l hl;simp only [fields,List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl|rfl|rfl
  · exact z.parent.nonzero
  · exact hs
  · exact he

theorem retains_stage (k : Nat) (hk : 3≤k) (R : Row) (hR : R∈ForcingFamily.stage k hk) :
    R∈ForcingFamily.selected k hk := by
  apply PrioritySourceBinding.selected_retains
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hR))

/-- The selected forcing node implies its actual parent branch, selected input
    wire and equality-of-truth-table-row bit. Every input row is constructed. -/
theorem selected_fields (k : Nat) (hk : 3≤k) (n : PriorityBank.Node)
    (hn : n∈PriorityBank.nodes (ForcingFamily.upper k hk+1) (ForcingFamily.raw k hk)) :
    ∃z∈candidates k hk,n.input=(z.var:Int) ∧
      ∀x∈fields k hk z,polEval (dbOf (ForcingFamily.selected k hk))
        (PriorityExclusive.tokens (ForcingFamily.selected k hk) (n.choice:Int) n.input x) []=
          some (clause [-(n.choice:Int),x]) := by
  obtain ⟨z,hz,he,hp,hport,hbit,hsource⟩:=selected_source k hk n hn
  have hg:=PriorityPrefix.allocated_good (ForcingFamily.upper k hk+1) (ForcingFamily.raw k hk)
    (L3.bounded_nz (ForcingFamily.raw_bounded k _ _)) n hn
  refine ⟨z,hz,he,?_⟩
  intro x hx
  have hxs:=fields_valid k hk z hz x hx
  apply PriorityExclusive.succeeds _ _ _ _ (by have:=hg.2.1;omega) hg.1 hxs hsource
  rw [he]
  exact retains_stage k hk _ (List.mem_append_right _ (source_rows k hk _ _ z hz x hx hxs))

#print axioms selected_fields
#print axioms bit_from_var
#print axioms selected_source
#print axioms source_rows
end L3Emitter.ForcingCandidates

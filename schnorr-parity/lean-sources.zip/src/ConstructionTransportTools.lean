import ConstructionFoldBounds
import RecordedTransportPrefix
import RecordedCoordinateBank

namespace L3Emitter.ConstructionTransportTools
open EREF EREF.GeneralRED RecordedScopedTrace CanonicalReplayEnvelope
open ConstructionLocalTools ConstructionFreshBounds ConstructionFoldBounds

theorem blocks {ι : Type} (B : Nat) (rows : ι→List Row) (block : List Row→ι→Program)
    (D : List Row) (xs : List ι) (hb : ∀D i,BoundedProgram B (block D i)) :
    BoundedProgram B (RecordedBlocks.program rows block D xs) := by
  induction xs generalizing D with
  | nil=>exact empty B
  | cons x xs ih=>exact append B _ _ (hb D x) (ih _)

theorem allocation (B : Nat) (D : List Row) (rows : Nat→List Row) (block : Nat→List Row→Program)
    (n : Nat) (hb : ∀i D,BoundedProgram B (block i D)) :
    BoundedProgram B (RecordedAllocationLoop.program D rows block n) := by
  induction n with
  | zero=>exact empty B
  | succ n ih=>exact append B _ _ ih (hb _ _)

theorem onePol (B : Nat) (R : Row) (ts : List Tok) : BoundedProgram B (RecordedBlocks.pol R ts) :=
  ConstructionFoldBounds.singleton B _ (pol B R ts)

theorem caseALO {ι : Type} (B : Nat) (D : List Row) (is : List ι) (c owner : ι→Int) (qs : List Int) :
    BoundedProgram B (RecordedCaseProjection.aloProgram D is c owner qs) :=
  append B _ _ (blocks B _ _ _ _ (fun E i=>onePol B _ _)) (onePol B _ _)

theorem casePair (B : Nat) (D : List Row) (c q r : Int) (side : Bool) (xs ys : List Int) :
    BoundedProgram B (RecordedCaseProjection.pairProgram D c q r side xs ys) :=
  append B _ _ (onePol B _ _) (onePol B _ _)

theorem caseAMO {ι : Type} (B : Nat) (D : List Row) (is : List ι) (c : ι→Int)
    (q r : Int) (side : ι→Bool) (xs ys : List Int) :
    BoundedProgram B (RecordedCaseProjection.amoProgram D is c q r side xs ys) :=
  append B _ _ (blocks B _ _ _ _ (fun E i=>casePair B E _ q r _ xs ys)) (onePol B _ _)

theorem rank (B k : Nat) (hk : 3≤k) (D : List Row) :
    BoundedProgram B (RecordedRankAdmission.program k hk D) :=
  append B _ _ (append B _ _
    (blocks B _ _ _ _ (fun E i=>caseALO B E _ _ _ _))
    (blocks B _ _ _ _ (fun E i=>caseAMO B E _ _ _ _ _ _ _)))
    (blocks B _ _ _ _ (fun E i=>caseAMO B E _ _ _ _ _ _ _))

theorem priority (D : List Row) (m : Nat) (xs : List Int) :
    BoundedProgram 3 (RecordedPriority.program D m xs) := append 3 _ _ (defs _ _) (polProgram 3 _)

theorem selected (D : List Row) (m : Nat) (xs : List Int) (f : Int→Int) :
    BoundedProgram 3 (RecordedSelectedValue.program D m xs f) :=
  append 3 _ _ (append 3 _ _ (defs _ _) (definitions _ _ _)) (polProgram 3 _)

theorem onehot (D : List Row) (m : Nat) (xs : List Int) (f : Int→Bool) :
    BoundedProgram 3 (RecordedOneHotBit.program D m xs f) :=
  append 3 _ _ (definitions _ _ _) (polProgram 3 _)

theorem forcingStep (D : List Row) (k : Nat) (hk : 3≤k) (c : RankProjection.Choice (3*k-4)) (m : Nat) :
    BoundedProgram 3 (RecordedForcing.stepProgram D k hk c m) := append 3 _ _ (defs _ _) (polProgram 3 _)

theorem forcingRun (D : List Row) (k : Nat) (hk : 3≤k) (m : Nat) (cs : List (RankProjection.Choice (3*k-4))) :
    BoundedProgram 3 (RecordedForcing.stageProgram D k hk m cs) := by
  induction cs generalizing D m with
  | nil=>exact empty 3
  | cons c cs ih=>exact append 3 _ _ (forcingStep D k hk c m) (ih _ _)

theorem forcing (k : Nat) (hk : 3≤k) : BoundedProgram 3 (RecordedForcing.program k hk) :=
  append 3 _ _ (forcingRun _ k hk _ _) (onePol 3 _ _)

theorem cofactor (n s offset B : Nat) (D : List Row) :
    BoundedProgram 3 (RecordedCofactorBank.program n s offset B D) :=
  allocation 3 _ _ _ _ (fun g E=>allocation 3 _ _ _ _
    (fun p E'=>allocation 3 _ _ _ _ (fun x E''=>gateProgram E'' _ [] _)))

theorem coordinate (cs : List Int) (f : Int→Nat→Int) (D : List Row) (i n : Nat) :
    BoundedProgram 3 (RecordedCoordinateBank.program cs f D i n) := by
  induction n generalizing D i with
  | zero=>exact empty 3
  | succ n ih=>exact append 3 _ _ (selection D _ cs _) (ih _ _)

theorem rawRun (n : Nat) (hn : 2≤n) (D : List Row) (js : List RawValueBank.Job) :
    BoundedProgram 3 (RecordedRawValues.runProgram n hn D js) := by
  induction js generalizing D with
  | nil=>exact empty 3
  | cons j js ih=>exact append 3 _ _ (selection D _ _ _) (ih _)

#print axioms rank
#print axioms forcing
#print axioms cofactor
#print axioms coordinate
#print axioms rawRun
end L3Emitter.ConstructionTransportTools

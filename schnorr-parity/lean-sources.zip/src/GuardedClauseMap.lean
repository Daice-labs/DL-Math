import TableLookupBinding
namespace L3Emitter.GuardedClauseMap
open EREF EREF.GeneralRED REDWitness ReferenceTransport LocalCombination ClauseTransport CaseJoin
abbrev Pair:=Int×Int
def source (ps:List Pair):=ps.map Prod.fst
def target (ps:List Pair):=ps.map Prod.snd
def links (G:List Int) (ps:List Pair):=ps.map fun p=>clause (G++[-p.1,p.2])
def padding (ps:List Pair):=List.replicate (ps.length-1) (target ps) |>.flatten

theorem links_value (G:List Int) (ps:List Pair) (hg:Valid G)
    (hp:∀p∈ps,p.1≠0 ∧ p.2≠0) (α:Val):
    ((links G ps).map fun R=>R.val α).sum=ps.length*sum α G-sum α (source ps)+sum α (target ps):=by
  induction ps with
  | nil=>simp [links,source,target,sum_nil]
  | cons p ps ih=>
    have h:=hp p (by simp)
    have ht:=ih (fun q hq=>hp q (by simp [hq]))
    simp only [links,List.map_cons,List.sum_cons,List.length_cons,Nat.cast_add,Nat.cast_one]
    change (clause (G++[-p.1,p.2])).val α+((links G ps).map fun R=>R.val α).sum=_
    rw [val_clause _ (EvaluationCaseSeeds.valid_join hg (by simp [Valid,h.1,h.2])),ht]
    simp only [source,target,List.map_cons,sum_append,sum_cons,sum_nil,litVal_neg α p.1 h.1]
    ring

def combined (G:List Int) (ps:List Pair):=
  chain (chain (clause (source ps)) (links G ps)) ((padding ps).map litAxiom)
def tape (D:List Row) (G:List Int) (ps:List Pair):List Tok:=
  [.ref (locate D (clause (source ps)))]++steps D (links G ps)++padSteps (padding ps)++[.div ps.length]

theorem valid_source (ps:List Pair) (hp:∀p∈ps,p.1≠0 ∧ p.2≠0):Valid (source ps):=by
  intro l hl;obtain ⟨p,hp',rfl⟩:=List.mem_map.mp hl;exact (hp p hp').1
theorem valid_target (ps:List Pair) (hp:∀p∈ps,p.1≠0 ∧ p.2≠0):Valid (target ps):=by
  intro l hl;obtain ⟨p,hp',rfl⟩:=List.mem_map.mp hl;exact (hp p hp').2
theorem valid_pad (ps:List Pair) (hp:∀p∈ps,p.1≠0 ∧ p.2≠0):Valid (padding ps):=by
  intro l hl;obtain ⟨xs,hxs,hl⟩:=List.mem_flatten.mp hl
  have he:xs=target ps:=(List.mem_replicate.mp hxs).2
  subst xs;exact valid_target ps hp l hl

theorem combined_eq (G:List Int) (ps:List Pair) (hg:Valid G) (hp:∀p∈ps,p.1≠0 ∧ p.2≠0) (hne:ps≠[]):
    combined G ps=scaled ps.length (clause (G++target ps)):=by
  have hpos:0<ps.length:=List.length_pos_iff.mpr hne
  apply canonical_ext _ _ (chain_canonical _ _ (chain_canonical _ _ (canonical_normalize _ _)))
    (canonical_scaled _ hpos _ (canonical_normalize _ _))
  intro α
  change (combined G ps).val α=(scaled ps.length (clause (G++target ps))).val α
  rw [combined,chain_value (chain (clause (source ps)) (links G ps)) ((padding ps).map litAxiom) (chain_canonical _ _ (canonical_normalize _ _))
    (by intro R hr;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hr;exact canonical_litAxiom _),
    chain_value (clause (source ps)) (links G ps) (canonical_normalize _ _) (by intro R hr;obtain ⟨p,hp,rfl⟩:=List.mem_map.mp hr;exact canonical_normalize _ _),
    ChoiceProjection.literal_sum _ (valid_pad ps hp),links_value G ps hg hp,val_scaled]
  change (clause (source ps)).val α + _ + sum α (padding ps) = _
  rw [val_clause _ (valid_source ps hp),val_clause _ (EvaluationCaseSeeds.valid_join hg (valid_target ps hp)),sum_append]
  have he:sum α (padding ps)=(ps.length-1:Nat)*sum α (target ps):=by
    simp [padding,sum,List.map_flatten,List.sum_flatten,List.map_replicate,List.sum_replicate]
  rw [he]
  have hn:((ps.length-1:Nat):Int)=(ps.length:Int)-1:=by omega
  rw [hn];ring

theorem checks (D:List Row) (G:List Int) (ps:List Pair) (hg:Valid G) (hp:∀p∈ps,p.1≠0 ∧ p.2≠0) (hne:ps≠[])
    (hs:clause (source ps)∈D) (hl:∀R∈links G ps,R∈D):
    polEval (dbOf D) (tape D G ps) []=some (clause (G++target ps)):=by
  simp only [tape,List.append_assoc,List.cons_append,List.nil_append,polEval,locate_correct D _ hs]
  rw [steps_eval _ _ hl,padSteps_eval _ _ (valid_pad ps hp)]
  simp only [polEval,if_pos (List.length_pos_iff.mpr hne)]
  change some (divide (combined G ps) ps.length)=_
  rw [combined_eq G ps hg hp hne,divide_scaled ps.length (List.length_pos_iff.mpr hne) (clause (G++target ps)) (canonical_normalize _ _)]
#print axioms checks
end L3Emitter.GuardedClauseMap

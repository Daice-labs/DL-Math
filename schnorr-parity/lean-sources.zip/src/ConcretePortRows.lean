import ConcreteSelectionProgram

namespace L3Emitter.ConcretePortRows
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteSelection
variable {base : List Row}

structure Job where
  es : List Cell
  q : AliasNetwork.Bit

def Ready (D : List Row) (j : Job) :=
  ∀e∈j.es,AliasClauseTransport.BitInputs D e.choice.val (ConcreteSelection.bit j.es j.q e)

theorem Ready.mono {D E : List Row} {j : Job} (h : Ready D j)
    (hm : ∀R∈D,R∈E) : Ready E j := fun e he=>(h e he).mono hm

def job (xs : List (Bit×Bit)) (z : Net base) : Job := ⟨cells xs z,(select xs z).1⟩

/-- Allocation-preserving instrumentation of `tabulate select`: only proof
    metadata is added, with no new definitions and no change in identifiers. -/
def run : (n : Nat)→(Fin n→List (Bit×Bit))→StateM (Net base) (Fin n→Job)
  | 0,_ => pure (fun i=>Fin.elim0 i)
  | n+1,f => fun z=>
    let j:=job (f 0) z
    let r:=run n (fun i=>f i.succ) (select (f 0) z).2
    (Fin.cases j r.1,r.2)

theorem binding (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base) :
    ((fun i=>((run n f z).1 i).q),(run n f z).2)=
      tabulate n (fun i=>select (f i)) z := by
  induction n generalizing z with
  | zero => apply Prod.ext;funext i;exact Fin.elim0 i;rfl
  | succ n ih =>
    have h:=ih (fun i=>f i.succ) (select (f 0) z).2
    apply Prod.ext
    · funext i
      refine Fin.cases ?_ (fun i=>?_) i
      · rfl
      · exact congrFun (congrArg Prod.fst h) i
    · change (run n (fun i=>f i.succ) (select (f 0) z).2).2=
        (tabulate n (fun i=>select (f i.succ)) (select (f 0) z).2).2
      exact congrArg Prod.snd h

theorem retains (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base) :
    ∀R∈z.rows,R∈(run n f z).2.rows := by
  rw [congrArg Prod.snd (binding n f z)]
  exact tabulate_extends n _ (fun i=>select_extends _) z

def Choices (xs : List (Bit×Bit)) (D : List Row) :=
  (xs.map (fun p=>p.1.val)).Nodup ∧
  ∀a∈xs,∀b∈xs,a.1.val≠b.1.val→clause [-a.1.val,-b.1.val]∈D

theorem Choices.mono {xs : List (Bit×Bit)} {D E : List Row} (h : Choices xs D)
    (hm : ∀R∈D,R∈E) : Choices xs E := ⟨h.1,fun a ha b hb hn=>hm _ (h.2 a ha b hb hn)⟩

theorem ready (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base)
    (hf : ∀i,Choices (f i) z.rows) :
    ∀i,Ready (run n f z).2.rows ((run n f z).1 i) := by
  induction n generalizing z with
  | zero => intro i;exact Fin.elim0 i
  | succ n ih =>
    intro i
    refine Fin.cases ?_ (fun i=>?_) i
    · apply Ready.mono (D:=(select (f 0) z).2.rows)
      · intro e he
        simpa only [select_binding] using inputs (f 0) z (hf 0).1 (hf 0).2 e he
      · exact retains n (fun i=>f i.succ) (select (f 0) z).2
    · exact ih (fun i=>f i.succ) (select (f 0) z).2
        (fun i=>(hf i.succ).mono (select_extends (f 0) z)) i

def jobs (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base) : List Job :=
  List.ofFn (run n f z).1

def jobRows (j : Job) := ConcreteSelectionProgram.body j.es j.q j.es
def program (D : List Row) : List Job→AliasProgram.Program
  | []=>[]
  | j::js=>ConcreteSelectionProgram.program D j.es j.q j.es ++ program (D++jobRows j) js

theorem program_check (D : List Row) (js : List Job) (h : ∀j∈js,Ready D j) :
    AliasProgram.check D (program D js)=some (D++js.flatMap jobRows) := by
  induction js generalizing D with
  | nil=>simp [program,AliasProgram.check]
  | cons j js ih=>
    have h1:=ConcreteSelectionProgram.check_program D j.es j.es j.q (h j (by simp))
    have h2:=ih (D++jobRows j) (fun t ht=>(h t (by simp [ht])).mono
      (fun R hr=>List.mem_append_left _ hr))
    simpa [program,List.flatMap_cons,List.append_assoc] using AliasProgram.check_append _ _ _ _ _ h1 h2

def result (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base) :=
  (run n f z).2.rows++(jobs n f z).flatMap jobRows

theorem checked (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base)
    (hf : ∀i,Choices (f i) z.rows) :
    AliasProgram.check (run n f z).2.rows (program (run n f z).2.rows (jobs n f z))=
      some (result n f z) := by
  apply program_check
  intro j hj
  obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hj
  exact ready n f z hf i

theorem trace (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base)
    (hf : ∀i,Choices (f i) z.rows) : CheckedTrace base (result n f z) :=
  L3.Fam.checkedTrace_trans (run n f z).2.checked (AliasProgram.check_trace _ _ _ (checked n f z hf))

#print axioms binding
#print axioms ready
#print axioms program_check
#print axioms checked
#print axioms trace
end L3Emitter.ConcretePortRows

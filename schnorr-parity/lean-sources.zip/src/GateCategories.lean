import ContextRows

namespace L3Emitter.GateCategories
open EREF EREF.GeneralRED REDWitness RankProjection

inductive Category where
  | beta
  | gamma
  | rank : Nat→Category
  deriving DecidableEq

def categories (s:Nat) : List Category := .beta::.gamma::(List.range (s-3)).map Category.rank

def Active {s:Nat} (c:Choice s) (g:Nat) : Category→Prop
  | .beta=>c.beta=g
  | .gamma=>c.gamma=g
  | .rank t=>RankProjection.Active c g t

instance {s:Nat} (c:Choice s) (g:Nat) (q:Category) : Decidable (Active c g q) := by
  cases q <;> unfold Active <;> infer_instance

def owner {s:Nat} (g:Nat) (c:Choice s) : Category :=
  if c.beta=g then .beta else if c.gamma=g then .gamma else .rank (L3Uniform.Rank.rank c.beta c.gamma g)

theorem owner_active {s:Nat} (c:Choice s) (g:Nat) (hg:0<g) (hs:g<s) : Active c g (owner g c) := by
  unfold owner
  split_ifs with hb hc
  · exact hb
  · exact hc
  · exact ⟨⟨hs,by omega,by omega,by omega⟩,rfl⟩

theorem owner_mem {s:Nat} (c:Choice s) (g:Nat) (hg:0<g) (hs:g<s) : owner g c∈categories s := by
  unfold owner
  split_ifs with hb hc
  · simp [categories]
  · simp [categories]
  · have h:=L3Uniform.Rank.rank_lt c.beta_pos c.ordered c.gamma_lt
      (show L3Uniform.Rank.kept s c.beta c.gamma g from ⟨hs,by omega,by omega,by omega⟩)
    exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _
      (List.mem_map.mpr ⟨_,List.mem_range.mpr h,rfl⟩))

theorem active_unique {s:Nat} (c:Choice s) (g:Nat) (q r:Category)
    (hq:Active c g q) (hr:Active c g r) : q=r := by
  have hbg:=c.ordered
  cases q <;> cases r <;>
    simp only [Active,RankProjection.Active,L3Uniform.Rank.kept] at hq hr
  all_goals first | rfl | (exfalso;omega) | (congr 1;omega)

def support {s:Nat} (cs:List (Choice s)) (g:Nat) (q:Category) : List Int :=
  (cs.filter (fun c=>decide (Active c g q))).map Choice.lit

theorem support_mem {s:Nat} (cs:List (Choice s)) (g:Nat) (q:Category) (l:Int) :
    l∈support cs g q ↔ ∃c∈cs,Active c g q ∧ c.lit=l := by
  simp [support,List.mem_map,List.mem_filter,and_assoc]

theorem support_valid {s:Nat} (cs:List (Choice s)) (g:Nat) (q:Category) : Valid (support cs g q) := by
  intro l hl;obtain ⟨c,hc,ha,rfl⟩:=(support_mem cs g q l).mp hl;exact c.nonzero

def bit (n:Nat) (hn:2≤n) (g:Nat) : Category→AliasNetwork.Bit
  | .beta=>(PrimaryAliasBank.cfg n hn).beta g
  | .gamma=>(PrimaryAliasBank.cfg n hn).gamma g
  | .rank t=>AliasAssembly.rankBit (n+1) (by omega) g t

theorem beta_support (n:Nat) (hn:2≤n) (g:Nat) :
    support (BranchChoices.chosen (n+1) (by omega)) g .beta=
      (AliasAssembly.choiceSupport (n+1) (by omega) true g).map Subtype.val := by
  simp [support,Active,AliasAssembly.choiceSupport,List.map_map,Function.comp_def]
  rfl

theorem gamma_support (n:Nat) (hn:2≤n) (g:Nat) :
    support (BranchChoices.chosen (n+1) (by omega)) g .gamma=
      (AliasAssembly.choiceSupport (n+1) (by omega) false g).map Subtype.val := by
  simp [support,Active,AliasAssembly.choiceSupport,List.map_map,Function.comp_def]
  rfl

theorem rank_support {s:Nat} (cs:List (Choice s)) (g t:Nat) :
    support cs g (.rank t)=RankProjection.support cs g t := rfl

theorem rank_to_endpoint (n:Nat) (hn:2≤n) :
    ∀R∈RankConstruction.database (n+1) (by omega),R∈FirstPortOneHot.result n hn := by
  intro R hr
  have ho:R∈OutputBank.result n hn:=List.mem_append_left _ (List.mem_append_left _
    (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
      (ConstantAdmission.rank_present n hn R hr)))))
  have hp:R∈PrimaryAliasBank.result n hn:=List.mem_append_left _ (List.mem_append_left _
    (RankColumnOneHot.contains_output n hn R ho))
  exact FirstPortOneHot.block_retains n hn 1 _ R (FirstPortOneHot.block_retains n hn 0 _ R hp)

theorem backward (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (q:Category) (hq:q∈categories (3*(n+1)-4)) :
    clause (-(bit n hn g q).val::support (BranchChoices.chosen (n+1) (by omega)) g q)
      ∈FirstPortOneHot.result n hn := by
  cases q with
  | beta=>rw [beta_support n hn g];exact (ContextRows.beta_rows n hn g hs).2
  | gamma=>rw [gamma_support n hn g];exact (ContextRows.gamma_rows n hn g hs).2
  | rank t=>
    have ht:t<RankConstruction.width (n+1):=by simpa [categories,RankConstruction.width] using hq
    exact rank_to_endpoint n hn _ ((RankConstruction.inputs (n+1) (by omega)).backward g hg hs t ht)

theorem forward (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (q:Category) (hq:q∈categories (3*(n+1)-4)) (l:Int)
    (hl:l∈support (BranchChoices.chosen (n+1) (by omega)) g q) :
    clause [-l,(bit n hn g q).val]∈FirstPortOneHot.result n hn := by
  cases q with
  | beta=>
    rw [beta_support n hn g] at hl
    obtain ⟨a,ha,rfl⟩:=List.mem_map.mp hl
    exact (ContextRows.beta_rows n hn g hs).1 a ha
  | gamma=>
    rw [gamma_support n hn g] at hl
    obtain ⟨a,ha,rfl⟩:=List.mem_map.mp hl
    exact (ContextRows.gamma_rows n hn g hs).1 a ha
  | rank t=>
    have ht:t<RankConstruction.width (n+1):=by simpa [categories,RankConstruction.width] using hq
    exact rank_to_endpoint n hn _ ((RankConstruction.inputs (n+1) (by omega)).forward g hg hs t ht l hl)

#print axioms active_unique
#print axioms backward
#print axioms forward
end L3Emitter.GateCategories

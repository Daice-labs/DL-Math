import L3FinalChains
import L3Bits
import L3Split

namespace L3
open EREF EREF.GeneralRED
namespace Fam
variable (F : Fam)

def outGateRow (pol : Bool) (x port b u : Nat) : Row :=
  F.row4P pol (F.s-1) x (if port=0 then b else u) (if port=0 then u else b)

def outEqRow (e port b u : Nat) (pol : Bool) : Row :=
  let f0 := (F.fn (F.s-1) (eqPair port b).1 : Int)
  let f1 := (F.fn (F.s-1) (eqPair port b).2 : Int)
  if (u=0) = (pol=true) then gateRow [-f0,f1] e false
  else gateRow [f0,-f1] e false

def outLeaf (e x y port u v : Nat) : List Int :=
  [-(F.sel (F.s-1) port 0 : Int), -(e : Int),
   if u=1 then -(F.port (F.s-1) (1-port) x : Int)
     else (F.port (F.s-1) (1-port) x : Int),
   if v=1 then -(F.port (F.s-1) (1-port) y : Int)
     else (F.port (F.s-1) (1-port) y : Int)]

def outLeafRows (e x y port b u v : Nat) (pol : Bool) : List Row :=
  [F.row3i (F.s-1) port 0 x,F.row3i (F.s-1) port 0 y,
   F.row5 x,F.row5 y,F.outGateRow pol x port b u,
   F.outGateRow (!pol) y port b v] ++
  (if u=v then [] else [F.outEqRow e port b u pol])

/-- T6a's fixed leaf certificate, using two copies of the negated leaf.
    The inputs agree on the selected bit and the target outputs disagree. -/
theorem output_leaf (hk : 1 ≤ F.k) (hs : 1 ≤ F.s)
    (e x y port b u v : Nat) (pol : Bool)
    (he : 1 ≤ e) (hx : x<F.T) (hy : y<F.T)
    (hp : port<2) (hb : b<2) (hu : u<2) (hv : v<2)
    (hix : F.inputBit 0 x = decide (b=1))
    (hiy : F.inputBit 0 y = decide (b=1))
    (hox : F.b x = pol) (hoy : F.b y = !pol)
    (D : List EREF.Row) (hD : ∀ R∈D, Canonical R)
    (hrows : ∀ r∈F.rows, r.toE∈D)
    (hEq : (gateRow [(F.fn (F.s-1) (eqPair port b).1 : Int),
                     -(F.fn (F.s-1) (eqPair port b).2 : Int)] e false).toE∈D ∧
           (gateRow [-(F.fn (F.s-1) (eqPair port b).1 : Int),
                      (F.fn (F.s-1) (eqPair port b).2 : Int)] e false).toE∈D) :
    Refutation (D ++ [negate (clauseRow (F.outLeaf e x y port u v)).toE]) := by
  have hiX := F.row3i_mem (F.s-1) port 0 x (by omega) hp (by omega) hx
  have hiY := F.row3i_mem (F.s-1) port 0 y (by omega) hp (by omega) hy
  have hoX := F.row5_mem x hx
  have hoY := F.row5_mem y hy
  have hgX : F.outGateRow pol x port b u ∈ F.rows := by
    apply F.row4P_mem pol (F.s-1) x _ _ (by omega) hx <;> split <;> omega
  have hgY : F.outGateRow (!pol) y port b v ∈ F.rows := by
    apply F.row4P_mem (!pol) (F.s-1) y _ _ (by omega) hy <;> split <;> omega
  have henz : (F.outEqRow e port b u pol).nz := by
    by_cases hh : (u=0) = (pol=true) <;>
      simp only [outEqRow,hh,ite_true,ite_false,Row.nz,gateRow,pos,neg,
        Bool.false_eq_true,ite_false,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] <;>
      intro l hl <;> rcases hl with (rfl | rfl) | rfl <;>
      first | omega | (simp only [Fam.fn]; omega)
  apply weighted_clause_chain D _ 1 (F.outLeafRows e x y port b u v pol) hD
  · by_cases hu1 : u=1 <;> by_cases hv1 : v=1 <;>
      simp only [outLeaf,hu1,hv1,ite_true,ite_false,List.mem_cons,List.not_mem_nil,or_false] <;>
      intro l hl <;> rcases hl with rfl | rfl | rfl | rfl <;>
      first | omega | (simp only [Fam.sel,Fam.port]; omega)
  · apply All.append
    · exact ⟨hrows _ hiX,hrows _ hiY,hrows _ hoX,hrows _ hoY,
        hrows _ hgX,hrows _ hgY,trivial⟩
    · split
      · trivial
      · constructor
        · unfold outEqRow
          split
          · exact hEq.2
          · exact hEq.1
        · trivial
  · apply All.append
    · exact ⟨nz_of_wf _ _ (F.rows_wf hs _ hiX),nz_of_wf _ _ (F.rows_wf hs _ hiY),
        nz_of_wf _ _ (F.rows_wf hs _ hoX),nz_of_wf _ _ (F.rows_wf hs _ hoY),
        nz_of_wf _ _ (F.rows_wf hs _ hgX),nz_of_wf _ _ (F.rows_wf hs _ hgY),trivial⟩
    · split
      · trivial
      · exact ⟨henz,trivial⟩
  · intro α
    rcases (by omega : port=0 ∨ port=1) with rfl | rfl <;>
      rcases (by omega : b=0 ∨ b=1) with rfl | rfl <;>
      rcases (by omega : u=0 ∨ u=1) with rfl | rfl <;>
      rcases (by omega : v=0 ∨ v=1) with rfl | rfl <;>
      cases pol <;>
      simp [outLeafRows,outLeaf,outGateRow,outEqRow,row4P,row4,row4',row3i,row5,m1,m2,
        eqPair,gateRow,hix,hiy,hox,hoy,pos,neg,lsum_cons,lsum_nil,lsum_append] <;>
      lv_omega

#print axioms output_leaf
end Fam
end L3

import FableEncoding
import FullNormalizationBytes

namespace L3Emitter.FableIntegration
open FamilyRows FamilyNamespace InputSwap FableEncoding SelectorNormalization

theorem unit_eq (k s p j : Nat) :
    ((fam k s).unitNegSel p j).toE = unit k p j := by
  rw [←unit_binding k s p j]
  rfl

theorem code_eq (k s c : Nat) :
    ((fam k s).row2 0 c).toE = (forbidden 0 c).row k s := by
  unfold L3.Fam.row2 L3.Row.toE forbidden Spec.row
  simp only [List.map_map, Function.comp_def]
  congr 1
  apply List.map_congr_left
  intro ab _
  cases h : c.testBit (3-ab) <;> simp [L3.codeBit, h, lit, L3.pos, L3.neg]

theorem db2_eq (k s : Nat) (hk : 0<k) :
    (fam k s).db2 k = state k s (rightPrevious k k) := by
  unfold L3.Fam.db2 state rightPrevious leftPrevious
  rw [original_rows k s hk]
  simp only [show (fam k s).k=k from rfl, List.map_append, List.map_map,
    List.range'_eq_map_range, Function.comp_def, unit_eq, List.append_assoc]
  simp [Nat.add_comm]

/-- Both full normalization developments end at exactly the same ordered database. -/
theorem final_rows_eq (k s : Nat) (hk : 0<k) :
    (fam k s).db5 = FullNormalization.finalRows k s := by
  unfold L3.Fam.db5 L3.Fam.db4 L3.Fam.db3 FullNormalization.finalRows
  simp only [show (fam k s).k=k from rfl]
  rw [db2_eq k s hk, unit_eq, code_eq, code_eq]
  simp [ProjectionNormalization.base, ProjectionNormalization.units, state,
    List.append_assoc]

/-- Fable's theorem can directly fill v5's complete normalization trace interface. -/
theorem normalization_trace (k : Nat) (hk : 3≤k) :
    EREF.GeneralRED.CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (FullNormalization.finalRows k (3*k-4)) := by
  rw [← final_rows_eq k (3*k-4) (by omega)]
  exact fable_prefix_on_v5 k hk

/-- Integrates the independent trace with the existing actual serializer's bound.
    This remains the normalization prefix, not the complete refutation. -/
theorem normalization_and_bytes (k : Nat) (hk : 3≤k) :
    EREF.GeneralRED.CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (FullNormalization.finalRows k (3*k-4)) ∧
    (FullNormalization.commands k (3*k-4)).length=2*k ∧
    (emit (FullNormalization.document k (3*k-4))).length ≤ FullNormalization.boundInN k :=
  ⟨normalization_trace k hk, FullNormalization.command_count k _ (by omega),
    FullNormalization.normalization_size_in_n k hk⟩

#print axioms final_rows_eq
#print axioms normalization_trace
end L3Emitter.FableIntegration

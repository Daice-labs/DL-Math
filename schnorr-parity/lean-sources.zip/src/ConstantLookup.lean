import RankAdmission

namespace L3Emitter.ConstantLookup
open EREF REDWitness ForcingCandidates PriorityBank

theorem four_upper {s : Nat} (m : Nat) (c : RankProjection.Choice s) (z : Candidate s)
    (hz : z∈four c m) : z.var≤m+4 := by
  simp only [four,List.mem_cons,List.not_mem_nil,or_false] at hz
  rcases hz with rfl|rfl|rfl|rfl <;> dsimp <;> omega

theorem id_injective {s : Nat} (m : Nat) (cs : List (RankProjection.Choice s))
    (a b : Candidate s) (ha : a∈bank m cs) (hb : b∈bank m cs) (he : a.var=b.var) : a=b := by
  induction cs generalizing m with
  | nil => simp [bank] at ha
  | cons c cs ih =>
    rcases List.mem_append.mp ha with ha|ha <;> rcases List.mem_append.mp hb with hb|hb
    · simp only [four,List.mem_cons,List.not_mem_nil,or_false] at ha hb
      rcases ha with rfl|rfl|rfl|rfl <;> rcases hb with rfl|rfl|rfl|rfl <;> first | rfl | (dsimp at he;omega)
    · have:=four_upper m c a ha;have:=above (m+4) cs b hb;omega
    · have:=four_upper m c b hb;have:=above (m+4) cs a ha;omega
    · exact ih (m+4) ha hb

def index {s : Nat} (z : Candidate s) := if z.port=0 then 2*z.bit else z.bit
def literal (k : Nat) (z : Candidate (3*k-4)) : Int :=
  (FableEncoding.fam k (3*k-4)).fn z.parent.beta (index z)
def lookup (k : Nat) (q : Int) : List (Candidate (3*k-4))→Int
  | [] => 1
  | z::zs => if (z.var:Int)=q then literal k z else lookup k q zs

theorem lookup_correct (k : Nat) (zs : List (Candidate (3*k-4)))
    (hi : ∀a∈zs,∀b∈zs,a.var=b.var→a=b) (z : Candidate (3*k-4)) (hz : z∈zs) :
    lookup k (z.var:Int) zs=literal k z := by
  induction zs with
  | nil => simp at hz
  | cons a zs ih =>
    by_cases he : a.var=z.var
    · have heq:=hi a (by simp) z hz he;subst a;simp [lookup]
    · have hz':z∈zs := by rcases List.mem_cons.mp hz with hz|hz;subst z;contradiction;exact hz
      have ht:=ih (by intro a ha b hb he;exact hi a (by simp [ha]) b (by simp [hb]) he) hz'
      simpa [lookup,he] using ht

theorem literal_bound (k : Nat) (hk : 3≤k) (z : Candidate (3*k-4)) (hz : z∈candidates k hk) :
    1 ≤ (literal k z).natAbs ∧ (literal k z).natAbs≤(FableEncoding.fam k (3*k-4)).V := by
  have hw:=wellformed _ _ z hz
  let F:=FableEncoding.fam k (3*k-4)
  have hi : index z<4 := by unfold index;split <;> omega
  have hg : z.parent.beta<F.s := by have:=z.parent.ordered;have:=z.parent.gamma_lt;change z.parent.beta<3*k-4;omega
  have hp:=F.fn_pos z.parent.beta (index z)
  have hb:=Nat.le_trans (F.fn_le _ _ hg hi) F.S4_le_V
  exact ⟨hp,hb⟩

def ns (k : Nat) (hk : 3≤k) := nodes (ForcingFamily.upper k hk+1) (ForcingFamily.raw k hk)
def value (k : Nat) (hk : 3≤k) (c : Int) :=
  lookup k (RestrictionBit.lookup (ns k hk) c) (candidates k hk)

theorem selected_value (k : Nat) (hk : 3≤k) (n : Node) (hn : n∈ns k hk) :
    ∃z∈candidates k hk,n.input=(z.var:Int) ∧ value k hk (n.choice:Int)=literal k z := by
  obtain ⟨z,hz,he,hr⟩:=selected_source k hk n hn
  refine ⟨z,hz,he,?_⟩
  unfold value ns
  rw [RestrictionBit.lookup_node _ _ _ hn,he]
  exact lookup_correct k _ (by intro a ha b hb he;exact id_injective _ _ a b ha hb he) z hz

theorem choices_nodup (m : Nat) (xs : List Int) : (choices (nodes m xs)).Nodup := by
  induction xs generalizing m with
  | nil => simp [choices,nodes]
  | cons x xs ih =>
    change ((m+1:Int)::choices (nodes (m+2) xs)).Nodup
    refine List.nodup_cons.mpr ⟨?_,ih (m+2)⟩
    intro h
    obtain ⟨n,hn,he⟩:=List.mem_map.mp h
    have:=RestrictionBit.choice_above (m+2) xs n hn
    change (n.choice:Int)=(m+1:Int) at he
    omega

#print axioms selected_value
#print axioms literal_bound
end L3Emitter.ConstantLookup

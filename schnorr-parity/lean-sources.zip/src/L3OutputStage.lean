import L3OutputSplit
import L3ObligationFold

set_option maxHeartbeats 2000000

namespace L3
open EREF EREF.GeneralRED
namespace Fam
variable (F : Fam)
open StI

def splitPairs : List (Nat × Nat) := [(0,0),(0,1),(1,0),(1,1)]
def outputSplits (t : StI F.V) : StI F.V := splitPairs.foldl F.outSplit t
def OutputRoots (t : StI F.V) : Prop :=
  ∀ p b, p<2 → b<2 → Cmd.rup (F.outputC t p b) ∈ t.s.cmds

theorem outputC_keeps {t u : StI F.V} (h : Keeps2 t u) (p b : Nat) :
    F.outputC u p b = F.outputC t p b := by
  unfold outputC
  rw [h.2.2.1]

theorem OutputRoots_keeps {t u : StI F.V} (h : Keeps2 t u)
    (hr : F.OutputRoots t) : F.OutputRoots u := by
  intro p b hp hb
  rw [F.outputC_keeps h p b]
  exact mem_of_grows h.1 (hr p b hp hb)

theorem outputSplits_keeps (t : StI F.V) : Keeps2 t (F.outputSplits t) :=
  keeps2_foldl F.outSplit splitPairs F.keeps2_outSplit t

theorem splitPairs_mem (p b : Nat) : (p,b)∈splitPairs ↔ p<2 ∧ b<2 := by
  simp only [splitPairs,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq]
  omega

theorem outputSplits_roots (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (ht : F.Good3 t) : F.OutputRoots (F.outputSplits t) := by
  intro p b hp hb
  have hm := (splitPairs_mem p b).mpr ⟨hp,hb⟩
  obtain ⟨l1,l2,_,he⟩ := foldl_split F.outSplit splitPairs (p,b) hm
  unfold outputSplits
  rw [he t]
  apply foldl_pres (fun u => Cmd.rup (F.outputC u p b)∈u.s.cmds) F.outSplit l2
  · intro x _ u hu
    rw [F.outputC_keeps (F.keeps2_outSplit u x) p b]
    exact mem_of_grows (F.keeps2_outSplit u x).1 hu
  · have hpre := F.Good3_of_keeps2
      (keeps2_foldl F.outSplit l1 F.keeps2_outSplit t) ht
    rw [F.outputC_keeps (F.keeps2_outSplit _ (p,b)) p b,
      F.outSplit_commands hk hs _ hpre p b hp hb]
    exact List.mem_append_right _ (rup_mem_splitCmds _ _)

theorem outputSplits_obls (hk : 2 ≤ F.k) (hs : 2 ≤ F.s) (hpar : F.b=parityBit)
    (t : StI F.V) (ht : F.Good3 t) (hc : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.outputSplits t).s.cmds := by
  apply (fold_obligations F.db5 (fun u : StI F.V => u.s.cmds) F.outSplit
    (fun u pb => splitCmds (F.outputC u pb.1 pb.2) (F.outputVs pb.1 pb.2))
    F.Good3 splitPairs _ t ht hc).2
  intro u pb hpb hu
  obtain ⟨hp,hb⟩ := (splitPairs_mem pb.1 pb.2).mp hpb
  exact ⟨F.outSplit_commands hk hs u hu pb.1 pb.2 hp hb,
    F.Good3_of_keeps2 (F.keeps2_outSplit u pb) hu,
    F.output_split_obls hk hs hpar u hu pb.1 pb.2 hp hb⟩

def outputForceC (t : StI F.V) (p : Nat) : List Int :=
  [-(F.sel (F.s-1) p 0 : Int),-(t.s.force (F.s-1) p : Int)]
def outputP0C (t : StI F.V) (p : Nat) : List Int :=
  [-(t.s.p0force (F.s-1) p : Int)]

theorem output_rup_bounds (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (ht : F.Good3 t) (p : Nat) (hp : p<2) :
    Bounded t.s.var (F.outputForceC t p) ∧ Bounded t.s.var (F.outputP0C t p) := by
  have hg := ht.2.2.1 (F.s-1) p (by omega) (by omega) hp
  have hfL := hg.2.2.1.2.1
  have hfU := hg.2.2.1.2.2
  have hpL := hg.2.2.2.2.1
  have hpU := hg.2.2.2.2.2
  have hsel := F.sel_le_S (F.s-1) p 0 (by omega) (by omega) (by omega)
  have hselpos := F.sel_pos (F.s-1) p 0
  have hS := F.S_le_V
  have hV := t.var_ge
  constructor
  · intro l hl
    simp only [outputForceC,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> omega
  · intro l hl
    simp only [outputP0C,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl
    simp; omega

theorem outRup_commands (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (ht : F.Good3 t) (p : Nat) (hp : p<2) :
    (F.outRup t p).s.cmds =
      t.s.cmds ++ [Cmd.rup (F.outputForceC t p),Cmd.rup (F.outputP0C t p)] := by
  obtain ⟨hf,hp0⟩ := F.output_rup_bounds hk hs t ht p hp
  change (t.s.cmds ++ [.rup (t.s.chk (F.outputForceC t p))]) ++
    [.rup (t.s.chk (F.outputP0C t p))] = _
  rw [StI.chk_eq t _ hf,StI.chk_eq t _ hp0]
  simp only [List.append_assoc,List.singleton_append,List.nil_append]

theorem outRup_obls (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (ht : F.Good3 t) (hr : F.OutputRoots t)
    (p : Nat) (hp : p<2) :
    ObligationsChecked (exec F.db5 t.s.cmds)
      [Cmd.rup (F.outputForceC t p),Cmd.rup (F.outputP0C t p)] := by
  let D := exec F.db5 t.s.cmds
  have hDb := exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) (by omega)) t.inv.1
  have hD := hDb.canonical
  have hg := ht.2.2.1 (F.s-1) p (by omega) (by omega) hp
  have hf := hg.2.2.1
  have hp0 := hg.2.2.2
  have hfL := hf.2.1
  have hpL := hp0.2.1
  have he0 := hg.1.2.1
  have he1 := hg.2.1.2.1
  have hfirst : Refutation (D ++ [negate (clauseRow (F.outputForceC t p)).toE]) := by
    apply output_force_excluded D _ _ (t.s.eqrow (F.s-1) p 0) (t.s.eqrow (F.s-1) p 1)
    · exact F.sel_pos _ _ _
    · omega
    · omega
    · omega
    · exact hD
    · exact rup_row_mem F.db5 t.s.cmds _ (hr p 0 hp (by decide))
    · exact rup_row_mem F.db5 t.s.cmds _ (hr p 1 hp (by decide))
    · exact orDef_row_down F.db5 t.s.cmds _ _ hf.1
  have hsecond : Refutation ((D ++ [(clauseRow (F.outputForceC t p)).toE]) ++
      [negate (clauseRow (F.outputP0C t p)).toE]) := by
    apply output_p0_excluded _ (F.sel (F.s-1) p 0) (t.s.force (F.s-1) p)
    · exact F.sel_pos _ _ _
    · omega
    · omega
    · intro R hR
      rcases List.mem_append.mp hR with hR | hR
      · exact hD R hR
      · rw [List.mem_singleton.mp hR]; exact canonical_toE _
    · exact List.mem_append_left _ (andDef_row_down F.db5 t.s.cmds _ _ hp0.1 _ (by simp))
    · exact List.mem_append_left _ (andDef_row_down F.db5 t.s.cmds _ _ hp0.1 _ (by simp))
    · exact List.mem_append_right _ (by simp [outputForceC])
  intro o ho
  simp only [obls,List.mem_cons,List.not_mem_nil,or_false] at ho
  rcases ho with rfl | rfl
  · exact hfirst
  · exact hsecond

def outputRups (t : StI F.V) : StI F.V := [0,1].foldl F.outRup t

theorem outputRups_keeps (t : StI F.V) : Keeps2 t (F.outputRups t) :=
  keeps2_foldl F.outRup [0,1] F.keeps2_outRup t

theorem outputRups_obls (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (ht : F.Good3 t) (hr : F.OutputRoots t)
    (hc : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.outputRups t).s.cmds := by
  apply (fold_obligations F.db5 (fun u : StI F.V => u.s.cmds) F.outRup
    (fun u p => [Cmd.rup (F.outputForceC u p),Cmd.rup (F.outputP0C u p)])
    (fun u => F.Good3 u ∧ F.OutputRoots u) [0,1] _ t ⟨ht,hr⟩ hc).2
  intro u p hp hu
  have hp2 : p<2 := by simp only [List.mem_cons,List.not_mem_nil,or_false] at hp; omega
  have hk2 := F.keeps2_outRup u p
  exact ⟨F.outRup_commands hk hs u hu.1 p hp2,
    ⟨F.Good3_of_keeps2 hk2 hu.1,F.OutputRoots_keeps hk2 hu.2⟩,
    F.outRup_obls hk hs u hu.1 hu.2 p hp2⟩

theorem outputP0C_keeps {t u : StI F.V} (h : Keeps2 t u) (p : Nat) :
    F.outputP0C u p = F.outputP0C t p := by
  unfold outputP0C
  rw [h.2.2.2.2.1]

theorem outputRups_p0_roots (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (ht : F.Good3 t) :
    ∀ p, p<2 → Cmd.rup (F.outputP0C (F.outputRups t) p) ∈ (F.outputRups t).s.cmds := by
  intro p hp
  have hm : p ∈ ([0,1] : List Nat) := by simp; omega
  obtain ⟨l1,l2,_,he⟩ := foldl_split F.outRup [0,1] p hm
  unfold outputRups
  rw [he t]
  apply foldl_pres (fun u => Cmd.rup (F.outputP0C u p)∈u.s.cmds) F.outRup l2
  · intro x _ u hu
    rw [F.outputP0C_keeps (F.keeps2_outRup u x) p]
    exact mem_of_grows (F.keeps2_outRup u x).1 hu
  · have hpre := F.Good3_of_keeps2
      (keeps2_foldl F.outRup l1 F.keeps2_outRup t) ht
    rw [F.outputP0C_keeps (F.keeps2_outRup _ p) p,
      F.outRup_commands hk hs _ hpre p hp]
    exact List.mem_append_right _ (by simp)

theorem output_final_obl (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (ht : F.Good3 t)
    (hr : ∀ p, p<2 → Cmd.rup (F.outputP0C t p) ∈ t.s.cmds) :
    Refutation (exec F.db5 t.s.cmds ++
      [negate (clauseRow [-(t.s.eligible (F.s-1) : Int)]).toE]) := by
  obtain ⟨cons,hcons,helig,hcL,heL,_⟩ := ht.2.2.2.1 (F.s-1) (by omega) (by omega)
  have hp0 := (ht.2.2.1 (F.s-1) 0 (by omega) (by omega) (by decide)).2.2.2.2.1
  have hp1 := (ht.2.2.1 (F.s-1) 1 (by omega) (by omega) (by decide)).2.2.2.2.1
  apply output_eligible_excluded _ _ cons (t.s.p0force (F.s-1) 0) (t.s.p0force (F.s-1) 1)
  · omega
  · omega
  · omega
  · omega
  · exact (exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) (by omega)) t.inv.1).canonical
  · exact andDef_row_down F.db5 t.s.cmds _ _ helig _ (by simp)
  · exact orDef_row_down F.db5 t.s.cmds _ _ hcons
  · exact rup_row_mem F.db5 t.s.cmds _ (hr 0 (by decide))
  · exact rup_row_mem F.db5 t.s.cmds _ (hr 1 (by decide))

theorem output_final_obls (hk : 2 ≤ F.k) (hs : 2 ≤ F.s)
    (t : StI F.V) (ht : F.Good3 t)
    (hr : ∀ p, p<2 → Cmd.rup (F.outputP0C t p) ∈ t.s.cmds)
    (hc : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (t.rup [-(t.s.eligible (F.s-1) : Int)]).s.cmds := by
  obtain ⟨cons,hcons,helig,hcL,heL,heU⟩ := ht.2.2.2.1 (F.s-1) (by omega) (by omega)
  have hb : Bounded t.s.var [-(t.s.eligible (F.s-1) : Int)] := by
    intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl
    simp; omega
  rw [StI.cmds_rup,StI.chk_eq t _ hb]
  apply obligations_append _ _ _ hc
  intro o ho
  simp only [obls,List.mem_cons,List.not_mem_nil,or_false] at ho
  subst o
  exact F.output_final_obl hk hs t ht hr

/-- All actual stage-6 obligations; no stage-6 refutation is a premise. -/
theorem stage6_obls (hk : 2 ≤ F.k) (hs : 2 ≤ F.s) (hpar : F.b=parityBit)
    (t : StI F.V) (ht : F.Good3 t) (hc : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.stage6 t).s.cmds := by
  let u := F.outputSplits t
  have hu : F.Good3 u := F.Good3_of_keeps2 (F.outputSplits_keeps t) ht
  have huc : ObligationsChecked F.db5 u.s.cmds := F.outputSplits_obls hk hs hpar t ht hc
  have hur : F.OutputRoots u := F.outputSplits_roots hk hs t ht
  have huv : Keeps2 u (F.outputRups u) := F.outputRups_keeps u
  have hv : F.Good3 (F.outputRups u) := F.Good3_of_keeps2 huv hu
  have hvc := F.outputRups_obls hk hs u hu hur huc
  have hvr := F.outputRups_p0_roots hk hs u hu
  have hfinal := F.output_final_obls hk hs (F.outputRups u) hv hvr hvc
  exact hfinal

theorem state_trace (hk : 1 ≤ F.k) (hs : 1 ≤ F.s)
    (t : StI F.V) (hc : ObligationsChecked F.db5 t.s.cmds) :
    CheckedTrace F.db5 (exec F.db5 t.s.cmds) :=
  exec_trace F.db5 F.V t.s.cmds (F.db5_bounded hk hs) t.inv.1 hc

/-- Semantic-calculus trace for the actual emitted stage 6, composed after any
    checked preceding prefix satisfying the established Good3 definitions. -/
theorem stage6_trace (hk : 2 ≤ F.k) (hs : 2 ≤ F.s) (hpar : F.b=parityBit)
    (t : StI F.V) (ht : F.Good3 t) (hc : ObligationsChecked F.db5 t.s.cmds) :
    CheckedTrace F.db5 (exec F.db5 (F.stage6 t).s.cmds) :=
  F.state_trace (by omega) (by omega) (F.stage6 t) (F.stage6_obls hk hs hpar t ht hc)

#print axioms stage6_obls
#print axioms stage6_trace

#print axioms outputSplits_obls
#print axioms outputRups_obls
end Fam
end L3

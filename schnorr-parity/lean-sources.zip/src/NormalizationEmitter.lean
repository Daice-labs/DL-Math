import SelectorPrefixTrace
import WireEnumeration

namespace L3Emitter.NormalizationEmitter
open EREF EREF.GeneralRED FamilyNamespace FamilyRows InputSwap
open SelectorNormalization

def witnessPairs (k s a j : Nat) : List (Nat × Nat) :=
  WireEnumeration.pairs k s (wire k a j)

def pairWitness (ps : List (Nat × Nat)) : Witness := fun v =>
  if h : 0<WireEnumeration.lookup ps v then
    .literal (WireEnumeration.lookup ps v : Int) (by omega)
  else .constant false

theorem pairs_at (k s a j : Nat) (ha : a<k) (hj : j<k)
    (w : Wire) (hw : Valid k s w) (α : Val) :
    applyWitness (pairWitness (witnessPairs k s a j)) α (encode k s w) =
      α (encode k s (wire k a j w)) := by
  have hp := (encode_bounds k s _ (wire_valid k s a j ha hj w hw)).1
  simp only [applyWitness,pairWitness,witnessPairs,WireEnumeration.lookup_pairs k s _ w hw,
    hp,↓reduceDIte,Image.eval]
  simp [hp]

theorem named_subst_ext (k s : Nat) (r : Spec) (hr : r.valid k s)
    (w v : Witness) (he : ∀ u, Valid k s u → ∀ α,
      applyWitness w α (encode k s u)=applyWitness v α (encode k s u)) :
    substRow (r.row k s) w=substRow (r.row k s) v := by
  apply canonical_ext _ _ (canonical_substRow _ _) (canonical_substRow _ _)
  intro α
  rw [val_substRow,val_substRow,row_value _ _ _ hr,row_value _ _ _ hr]
  unfold REDWitness.sum
  congr 1
  congr 1
  apply List.map_congr_left
  intro l hl
  obtain ⟨u,hu,rfl⟩ := List.mem_map.mp hl
  unfold lit litVal
  have hu' := he u.1 (hr u hu) α
  cases hb : u.2 <;> simp [hb,hu']

theorem serialized_subst (k s a j : Nat) (ha : a<k) (hj : j<k)
    (r : Spec) (hr : r.valid k s) :
    substRow (r.row k s) (pairWitness (witnessPairs k s a j)) =
      substRow (r.row k s) (wireWitness k s (wire k a j) (wire_valid k s a j ha hj)) := by
  apply named_subst_ext k s r hr
  intro u hu α
  rw [pairs_at k s a j ha hj u hu,
    witness_at k s (wire k a j) (wire_valid k s a j ha hj) u hu]

theorem serialized_obligations (k s a j p : Nat) (hs : 0<s) (ha : a<k) (hj : j<k)
    (haj : a≠j) (hp : p<2) (previous : List (Nat × Nat))
    (hv : ∀ pj∈previous, pj.1<2 ∧ pj.2<k)
    (hclosed : ∀ pj∈previous, (pj.1,Equiv.swap a j pj.2)∈previous) :
    Obligations (state k s previous) (unit k p j) (pairWitness (witnessPairs k s a j)) := by
  have ho := selector_obligations k s a j p hs ha hj haj hp previous hv hclosed
  intro R hR
  have hex : ∃ r : Spec, r.valid k s ∧ r.row k s=R := by
    rcases List.mem_cons.mp hR with rfl | hR
    · exact ⟨unitSpec p j,unit_valid k s p j hs hp hj,unit_binding _ _ _ _⟩
    · rcases List.mem_append.mp hR with hR | hR
      · obtain ⟨r,hr,rfl⟩ := List.mem_map.mp hR
        exact ⟨r,original_valid k s r ((OriginalEncoding.spec_mem_iff k s hs r).mp hr),rfl⟩
      · obtain ⟨pj,hpj,rfl⟩ := List.mem_map.mp hR
        exact ⟨unitSpec pj.1 pj.2,unit_valid k s _ _ hs (hv pj hpj).1 (hv pj hpj).2,
          unit_binding _ _ _ _⟩
  obtain ⟨r,hr,rfl⟩ := hex
  rw [serialized_subst _ _ _ _ ha hj r hr]
  exact ho _ hR

def candidatePB (k p j : Nat) : PBRow :=
  ⟨[(1,⟨p*k+j+1,true⟩)],1⟩

def commandFor (k s p j : Nat) : Command :=
  .red (candidatePB k p j) ((witnessPairs k s p j).map
    fun xy => (xy.1,L3Emitter.Image.lit ⟨xy.2,false⟩))

def commandsAll (k s : Nat) : List Command :=
  (rightPrevious k k).map (fun pj => commandFor k s pj.1 pj.2)

def document (k s : Nat) : Doc := (commandsAll k s).flatMap command

theorem candidate_binding (k p j : Nat) : TemplateBytes.decodeRow (candidatePB k p j)=unit k p j := by
  simp [TemplateBytes.decodeRow,TemplateBytes.decodeLiteral,candidatePB,unit,
    selector,REDWitness.clause]

theorem prefix_count (k s : Nat) (hk : 2≤k) : (commandsAll k s).length=2*k-3 := by
  simp only [commandsAll,List.length_map,selector_prefix_count k hk]

#print axioms serialized_subst
#print axioms serialized_obligations
#print axioms candidate_binding
#print axioms prefix_count
end L3Emitter.NormalizationEmitter

import SelectedValueProgram
import ConstantLookup

namespace L3Emitter.ConstantConstruction
open EREF EREF.GeneralRED REDWitness PriorityBank ForcingCandidates

def m (k : Nat) (hk : 3≤k) := RestrictionBit.B k hk+RankConstruction.count k
def choices (k : Nat) (hk : 3≤k) := RestrictionBit.choices k hk
def C (k : Nat) (hk : 3≤k) := m k hk+(choices k hk).length+1
def result (k : Nat) (hk : 3≤k) := SelectedValueProgram.result (RankConstruction.database k hk)
  (m k hk) (choices k hk) (ConstantLookup.value k hk)

theorem original_bound (k : Nat) (hk : 3≤k) : (FableEncoding.fam k (3*k-4)).V≤m k hk := by
  have hv:=L3.varAfter_mono (FableEncoding.fam k (3*k-4)).V (FrontendSelection.front k hk).s.cmds
  rw [(FrontendSelection.front k hk).inv.2] at hv
  unfold m RestrictionBit.B RestrictionBit.upper ForcingFamily.upper ForcingBounds.ceiling
  omega

theorem choice_bounds (k : Nat) (hk : 3≤k) : L3.Bounded (m k hk) (choices k hk) := by
  intro l hl;have h:=RestrictionBit.choices_bounded k hk l hl
  exact ⟨h.1,by unfold m RestrictionBit.B;omega⟩

theorem value_bounds (k : Nat) (hk : 3≤k) : ∀x∈choices k hk,
    1 ≤ (ConstantLookup.value k hk x).natAbs ∧ (ConstantLookup.value k hk x).natAbs≤m k hk := by
  intro x hx;obtain ⟨n,hn,rfl⟩:=List.mem_map.mp hx
  obtain ⟨z,hz,he,hv⟩:=ConstantLookup.selected_value k hk n hn
  rw [hv]
  have hb:=ConstantLookup.literal_bound k hk z hz
  exact ⟨hb.1,le_trans hb.2 (original_bound k hk)⟩

theorem retains_forcing (k : Nat) (hk : 3≤k) (R : Row) (hR : R∈ForcingFamily.selected k hk) :
    R∈RankConstruction.database k hk :=
  L3.exec_mono _ _ _ (RestrictionBounds.retains_forcing k hk R hR)

theorem choice_amo (k : Nat) (hk : 3≤k) : ∀x∈choices k hk,∀y∈choices k hk,x≠y→
    clause [-x,-y]∈RankConstruction.database k hk := by
  intro x hx y hy hne
  exact retains_forcing k hk _ ((ForcingFamily.original_to_selected_forcing k hk).2.2 x hx y hy hne)

theorem original_to_constant (k : Nat) (hk : 3≤k) :
    CheckedTrace (OriginalEncoding.rows k (3*k-4)) (result k hk) ∧ L3.DBBounded (result k hk) (C k hk) := by
  have hb:=(RankConstruction.construction k hk).2
  have ht:=SelectedValueProgram.trace (RankConstruction.database k hk) (m k hk) (choices k hk)
    (ConstantLookup.value k hk) hb (choice_bounds k hk) (value_bounds k hk)
    (ConstantLookup.choices_nodup _ _) (choice_amo k hk)
  exact ⟨L3.Fam.checkedTrace_trans (RankConstruction.construction k hk).1 ht,
    SelectedValueProgram.result_bounded _ _ _ _ hb (choice_bounds k hk) (value_bounds k hk)⟩

theorem source_pair (k : Nat) (hk : 3≤k) (n : Node) (hn : n∈ConstantLookup.ns k hk) :
    ∃z∈candidates k hk,n.input=(z.var:Int) ∧
      clause [-(n.choice:Int),-ConstantLookup.literal k z,(C k hk:Int)]∈result k hk ∧
      clause [-(n.choice:Int),-(C k hk:Int),ConstantLookup.literal k z]∈result k hk := by
  obtain ⟨z,hz,he,hv⟩:=ConstantLookup.selected_value k hk n hn
  refine ⟨z,hz,he,?_⟩
  have hchoice : (n.choice:Int)∈choices k hk := List.mem_map.mpr ⟨n,hn,rfl⟩
  rw [←SelectedValue.cells_choices (m k hk) (ConstantLookup.value k hk) (choices k hk)] at hchoice
  obtain ⟨e,he',hc⟩:=List.mem_map.mp hchoice
  have hval:=(SelectedValue.cell_bounds _ _ _ e he').2.1
  rw [hc,hv] at hval
  have hrows : ∀R∈AliasClauseTransport.bitRows e.choice
      (SelectedValue.bit (SelectedValue.cells (m k hk) (ConstantLookup.value k hk) (choices k hk)) (C k hk) e),R∈result k hk := by
    intro R hR;exact List.mem_append_right _ (List.mem_flatMap.mpr ⟨e,he',hR⟩)
  constructor <;> apply hrows <;>
    simp [AliasClauseTransport.bitRows,SelectedValue.bit,hc,hval]

theorem retains_rank (k : Nat) (hk : 3≤k) (R : Row) (h : R∈RankConstruction.database k hk) : R∈result k hk :=
  List.mem_append_left _ (L3.exec_mono _ _ _ h)

#print axioms original_to_constant
#print axioms source_pair
end L3Emitter.ConstantConstruction

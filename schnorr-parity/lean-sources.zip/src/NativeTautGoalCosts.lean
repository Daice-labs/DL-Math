import NativeTautGoalLowering
import NumericFamilyClosed
namespace L3Emitter.NativeTautGoalCosts
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation NativeTautGoalLowering AuditLocalCosts

theorem goals_metric (f:Certificate→Nat)
 (hf:∀D G p,f (lowerLocal D G p)≤f p)
 (D:List Row) (C:Row) (w:FiniteWitness.Data) (rs:List Row) (ps:List Certificate):
 ((goals D C w rs ps).map f).sum≤(ps.map f).sum:=by
 induction rs generalizing ps with
 | nil=>simp [goals]
 | cons R rs ih=>
   cases ps with
   | nil=>simp [goals]
   | cons p ps=>
     simp only [goals,List.map_cons,List.sum_cons]
     exact Nat.add_le_add (hf _ _ _) (ih ps)

theorem step_metric (f:Certificate→Nat)
 (hf:∀D G p,f (lowerLocal D G p)≤f p) (D:List Row) (c:Step):
 ((certificates (step D c)).map f).sum≤((certificates c).map f).sum:=by
 cases c with
 | pol R ts=>rfl
 | consequence R p=>simpa [step,certificates] using hf D R p
 | red R w ps=>exact goals_metric f hf D R w (R::D) ps

theorem fold_metric (f:Step→Nat) (hf:∀D c,f (step D c)≤f c)
 (D:List Row) (p:Program):((program D p).map f).sum≤(p.map f).sum:=by
 induction p generalizing D with
 | nil=>rfl
 | cons c cs ih=>simp only [program,List.map_cons,List.sum_cons];exact Nat.add_le_add (hf D c) (ih _)

theorem main_length (D:List Row) (p:Program):(program D p).length=p.length:=by
 induction p generalizing D with
 | nil=>rfl
 | cons c cs ih=>simp only [program,List.length_cons,ih]

theorem main_tokens (D:List Row) (p:Program):
 MainTapeRecurrence.count (program D p)=MainTapeRecurrence.count p:=by
 induction p generalizing D with
 | nil=>rfl
 | cons c cs ih=>
   simp only [program,MainTapeRecurrence.count,List.map_cons,List.sum_cons]
   change MainTapeRecurrence.step (step D c)+MainTapeRecurrence.count (program (D++[c.row]) cs)=_
   rw [ih];cases c <;> rfl

theorem certs (D:List Row) (p:Program):certCount (program D p)≤certCount p:=by
 induction p generalizing D with
 | nil=>rfl
 | cons c cs ih=>
   simp only [program,certs_cons]
   apply Nat.add_le_add _ (ih _)
   simpa using step_metric (fun _=>1) (by intros;rfl) D c

theorem rows (D:List Row) (p:Program):localRowCount (program D p)≤localRowCount p:=by
 induction p generalizing D with
 | nil=>rfl
 | cons c cs ih=>
   simp only [program,rows_cons]
   exact Nat.add_le_add (step_metric (fun p=>p.program.length) local_count D c) (ih _)

theorem tokens (D:List Row) (p:Program):localTokenCount (program D p)≤localTokenCount p:=by
 induction p generalizing D with
 | nil=>rfl
 | cons c cs ih=>
   simp only [program,tokens_cons]
   exact Nat.add_le_add (step_metric RecordedReplayCost.tokens local_tokens D c) (ih _)

theorem allocation (D:List Row) (p:Program):
 NativeRecordedAllocation.program (program D p)≤NativeRecordedAllocation.program p:=by
 apply fold_metric
 intro D c
 cases c with
 | pol R ts=>rfl
 | consequence R q=>exact Nat.add_le_add_left (local_count D R q) 2
 | red R w ps=>
   exact Nat.add_le_add_left (goals_metric (fun p=>1+p.program.length)
    (by intro D G p;exact Nat.add_le_add_left (local_count D G p) 1) D R w (R::D) ps) 2

theorem local_fields (M:Nat) (D:List Row) (G:Row) (p:Certificate)
 (h:RecordedOperandFields.Local M p):RecordedOperandFields.Local M (lowerLocal D G p):=by
 unfold lowerLocal;split
 · simp [direct,RecordedOperandFields.Local]
 · exact h

theorem goals_fields (M:Nat) (D:List Row) (C:Row) (w:FiniteWitness.Data)
 (rs:List Row) (ps:List Certificate) (h:∀p∈ps,RecordedOperandFields.Local M p):
 ∀p∈goals D C w rs ps,RecordedOperandFields.Local M p:=by
 induction rs generalizing ps with
 | nil=>simp [goals]
 | cons R rs ih=>cases ps with
   | nil=>simp [goals]
   | cons p ps=>
     intro q hq
     rcases List.mem_cons.mp hq with rfl|hq
     · exact local_fields M _ _ p (h p (by simp))
     · exact ih ps (fun p hp=>h p (by simp [hp])) q hq

theorem step_content (M:Nat) (D:List Row) (c:Step) (h:FieldLengthsFromIDs.Content M c):
 FieldLengthsFromIDs.Content M (step D c):=by
 cases c with
 | pol R ts=>exact h
 | consequence R p=>exact ⟨h.1,local_fields M D R p h.2⟩
 | red R w ps=>exact ⟨h.1,h.2.1,goals_fields M D R w (R::D) ps h.2.2⟩

theorem content (M:Nat) (D:List Row) (p:Program) (h:∀c∈p,FieldLengthsFromIDs.Content M c):
 ∀c∈program D p,FieldLengthsFromIDs.Content M c:=by
 induction p generalizing D with
 | nil=>simp [program]
 | cons c cs ih=>
   intro q hq
   rcases List.mem_cons.mp hq with rfl|hq
   · exact step_content M D c (h c (by simp))
   · exact ih _ (fun c hc=>h c (by simp [hc])) q hq
#print axioms allocation
#print axioms tokens
#print axioms content
end L3Emitter.NativeTautGoalCosts

import FirstGateValue
namespace L3Emitter.FirstBaseLeaves
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL CofactorValueRows

def xs (n:Nat) (hn:2≤n) (x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):List Int:=
  [-(ValueBranchRows.q n hn 0 i).val,-sign b (SourceCoordinateValue.value n hn i x),
    -sign v (unary n hn 0 b),sign v (cofactor n hn 0 x)]

theorem source (n:Nat) (hn:2≤n) (i:Fin (AliasAssembly.width (n+1))):
    ValueBranchRows.q n hn 0 i=if i.val=0 then (PrimaryAliasBank.cfg n hn).T else (PrimaryAliasBank.cfg n hn).F:=by
  change (AliasAssembly.built n hn).1.2 (n+1) (SelectedVectorOneHot.position i)=_
  rw [FirstGateSource.built_zero_source]
  exact PrimaryAliasRows.coordinate _ 0 i

theorem zero_value (n:Nat) (hn:2≤n) (i:Fin (AliasAssembly.width (n+1))) (hi:i.val=0) (x:Nat):
    SourceCoordinateValue.value n hn i x=PrimaryValueSeeds.truth (PrimaryAliasBank.cfg n hn) (FirstCofactorRows.d n x):=by
  exact SourceCoordinateValue.primary n hn i x 1 (by omega) (by decide) (by omega)

def tape (n:Nat) (hn:2≤n) (x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):List Tok:=
  if i.val=0 ∧ b=FirstCofactorRows.d n x then
    ChoiceProjection.weakenTokens D [-sign v (unary n hn 0 b),sign v (cofactor n hn 0 x)]
      [-(ValueBranchRows.q n hn 0 i).val,-sign b (SourceCoordinateValue.value n hn i x)]
  else PrimaryAliasRows.unitTape D (PrimaryAliasBank.cfg n hn).T (xs n hn x i b v)

theorem checks (n:Nat) (hn:2≤n) (x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row)
    (hd:∀R∈SharedValueBank.result n hn,R∈D)
    (hv:∀v,FirstGateValue.target n hn x v∈D):
    polEval (dbOf D) (tape n hn x i b v D) []=
      some (ValueBranchRows.row n hn 0 x i (SourceCoordinateValue.value n hn i x) b v):=by
  by_cases h:i.val=0 ∧ b=FirstCofactorRows.d n x
  · rw [tape,if_pos h]
    have hm:clause [-sign v (unary n hn 0 b),sign v (cofactor n hn 0 x)]∈D:=h.2 ▸ hv v
    have hc:=ChoiceProjection.weaken_succeeds D [-sign v (unary n hn 0 b),sign v (cofactor n hn 0 x)]
      [-(ValueBranchRows.q n hn 0 i).val,-sign b (SourceCoordinateValue.value n hn i x)]
      (by simp [Valid,sign_valid]) (by simp [Valid,sign_valid,(ValueBranchRows.q n hn 0 i).property]) hm
    have he:clause ([-sign v (unary n hn 0 b),sign v (cofactor n hn 0 x)]++
      [-(ValueBranchRows.q n hn 0 i).val,-sign b (SourceCoordinateValue.value n hn i x)])=
        ValueBranchRows.row n hn 0 x i (SourceCoordinateValue.value n hn i x) b v:=by
      apply ProjectionTrace.clause_perm _ _
        (by simp [Valid,sign_valid,(ValueBranchRows.q n hn 0 i).property])
        (by simp [Valid,sign_valid,(ValueBranchRows.q n hn 0 i).property])
      exact List.perm_append_comm
    exact he ▸ hc
  · rw [tape,if_neg h]
    apply PrimaryAliasRows.unit_check D (PrimaryAliasBank.cfg n hn).T _
      (by simp [xs,Valid,sign_valid,(ValueBranchRows.q n hn 0 i).property]) _
      (hd _ (SharedValueBank.gamma_retained n hn _ (PrimaryInputLinks.true_present n hn)))
    by_cases hi:i.val=0
    · have hb:b≠FirstCofactorRows.d n x:=by tauto
      have he:=zero_value n hn i hi x
      have hf:=PrimaryAliasBank.false_bit n hn
      cases b <;> cases hh:FirstCofactorRows.d n x <;>
        simp_all [xs,PrimaryValueSeeds.truth,sign,neg]
    · simp [xs,source,hi,PrimaryAliasBank.false_bit,neg]

#print axioms source
#print axioms zero_value
#print axioms checks
end L3Emitter.FirstBaseLeaves

import ExpressionEvaluation

namespace L3Emitter.EvaluationCaseSeeds
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL

theorem valid_join {xs ys:List Int} (hx:Valid xs) (hy:Valid ys):Valid (xs++ys):=by
  intro x h;rcases List.mem_append.mp h with h|h
  · exact hx x h
  · exact hy x h
theorem valid_cons {x:Int} {xs:List Int} (hx:x≠0) (ht:Valid xs):Valid (x::xs):=by
  intro y h;rcases List.mem_cons.mp h with rfl|h
  · exact hx
  · exact ht y h

def pair (x:Int):=clause [x,-x]
def target (pre:List Int) (x:Int) (post:List Int):=guarded (pre++x::post) (-x)
def oneRows (pre:List Int) (x:Int) (post:List Int):=[pair x,target pre x post]
def one (D:List Row) (pre:List Int) (x:Int) (post:List Int):Program:=
  [(pair x,ComplementChoice.tautTokens x),
   (target pre x post,ChoiceProjection.weakenTokens (D++[pair x]) [x,-x] (pre++post))]

theorem target_eq (pre:List Int) (x:Int) (post:List Int) (hp:Valid pre) (hx:x≠0) (ht:Valid post):
    clause ([x,-x]++(pre++post))=target pre x post := by
  apply canonical_ext _ _ (canonical_normalize _ _) (canonical_normalize _ _)
  intro α
  change (clause ([x,-x]++(pre++post))).val α=(clause ((pre++x::post)++[-x])).val α
  rw [val_clause _ (valid_join (by simp [Valid,hx]) (valid_join hp ht)),
    val_clause _ (valid_join (valid_join hp (valid_cons hx ht)) (by simp [Valid,hx]))]
  simp only [sum_append,sum_cons,sum_nil]
  ring

theorem one_check (D:List Row) (pre:List Int) (x:Int) (post:List Int)
    (hp:Valid pre) (hx:x≠0) (ht:Valid post):
    check D (one D pre x post)=some (D++oneRows pre x post):=by
  have h0:=ComplementChoice.taut_pair_succeeds (dbOf D) x hx
  have h1:=ChoiceProjection.weaken_succeeds (D++[pair x]) [x,-x] (pre++post)
    (by simp [Valid,hx]) (valid_join hp ht) (List.mem_append_right _ (List.mem_singleton_self _))
  rw [target_eq pre x post hp hx ht] at h1
  simp only [one,check,h0,pair,↓reduceIte] at *
  rw [h1]
  simp [oneRows,pair,List.append_assoc]

def rows (pre:List Int):List Int→List Row
  | []=>[]
  | x::xs=>oneRows pre x xs++rows (pre++[x]) xs
def program (D:List Row) (pre:List Int):List Int→Program
  | []=>[]
  | x::xs=>one D pre x xs++program (D++oneRows pre x xs) (pre++[x]) xs

theorem checks (D:List Row) (pre xs:List Int) (hp:Valid pre) (hx:Valid xs):
    check D (program D pre xs)=some (D++rows pre xs):=by
  induction xs generalizing D pre with
  | nil=>simp [program,rows,check]
  | cons x xs ih=>
    have hz:=hx x (by simp)
    have ht:Valid xs:=fun y hy=>hx y (by simp [hy])
    have h0:=one_check D pre x xs hp hz ht
    have h1:=ih (D++oneRows pre x xs) (pre++[x]) (valid_join hp (by simp [Valid,hz])) ht
    simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h1

theorem contains (pre xs:List Int) (x:Int) (hx:x∈xs):guarded (pre++xs) (-x)∈rows pre xs:=by
  induction xs generalizing pre with
  | nil=>simp at hx
  | cons y ys ih=>
    rcases List.mem_cons.mp hx with rfl|ht
    · exact List.mem_append_left _ (List.mem_cons_of_mem _ (List.mem_singleton_self _))
    · have h:=ih (pre++[y]) ht
      simpa only [List.append_assoc,List.singleton_append] using List.mem_append_right (oneRows pre y ys) h

def guards (α:Val) (bs:List Bit):List Int:=bs.map (fun b=> -sign (eval α b) b)
theorem guards_valid (α:Val) (bs:List Bit):Valid (guards α bs):=by
  intro x hx;obtain ⟨b,hb,rfl⟩:=List.mem_map.mp hx
  exact neg_ne_zero.mpr (sign_valid _ _)
theorem input_present (α:Val) (bs:List Bit) (b:Bit) (hb:b∈bs):
    guarded (guards α bs) (sign (eval α b) b)∈rows [] (guards α bs):=by
  have h:=contains [] (guards α bs) (-sign (eval α b) b) (List.mem_map.mpr ⟨b,hb,rfl⟩)
  simpa using h

theorem commands_count (D:List Row) (pre xs:List Int):(program D pre xs).length=2*xs.length:=by
  induction xs generalizing D pre with
  | nil=>simp [program]
  | cons x xs ih=>simp [program,one,ih];omega

#print axioms checks
#print axioms input_present
#print axioms commands_count
end L3Emitter.EvaluationCaseSeeds

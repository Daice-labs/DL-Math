import RecordedAliasRun

namespace L3Emitter.ConcretePortCost
open EREF EREF.GeneralRED REDWitness AliasNetwork ConcreteSelection ConcretePortRows RecursiveAliases
variable {base : List Row} {w : Nat}

def mass (js : List Job) := (js.map (fun j=>j.es.length)).sum
theorem mass_append (xs ys : List Job) : mass (xs++ys)=mass xs+mass ys := by simp [mass]

theorem tabulate_mass (n : Nat) (f : Fin n→List (Bit×Bit)) (z : Net base)
    (P : Nat) (hf : ∀i,(f i).length=P) :
    mass (jobs n f z)=n*P := by
  induction n generalizing z with
  | zero=>simp [jobs,mass,List.ofFn_zero]
  | succ n ih=>
    have ht:=ih (fun i=>f i.succ) (select (f 0) z).2 (fun i=>hf i.succ)
    change mass (List.ofFn (ConcretePortRows.run (n+1) f z).1)=_
    rw [List.ofFn_succ]
    change (cells (f 0) z).length+mass (jobs n (fun i=>f i.succ) (select (f 0) z).2)=_
    rw [cells,cells_length,ht,hf 0]
    ring

theorem port_mass (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) (z : Net base) :
    mass (ConcreteOriginalPorts.recorded k g sel as z).1.2=(w+2)*(k+g) :=
  tabulate_mass _ _ z _ (fun i=>by simp [ConcreteOriginalPorts.portInputs])

theorem step_mass (c : Config Bit) (as : Nat→AliasBits w) (g : Nat) (z : Net base) :
    mass (RecordedAliasSteps.step c as g z).1.2=2*(w+2)*(c.k+g) := by
  change mass ((ConcreteOriginalPorts.recorded c.k g (c.sel g 0) as z).1.2++
    (ConcreteOriginalPorts.recorded c.k g (c.sel g 1) as
      (ConcreteOriginalPorts.recorded c.k g (c.sel g 0) as z).2).1.2)=_
  rw [mass_append,port_mass,port_mass]
  ring

theorem run_mass (c : Config Bit) (as : Nat→AliasBits w) (g m : Nat) (z : Net base) :
    mass (RecordedAliasRun.run c as g m z).1.2≤2*(w+2)*m*(c.k+g+m) := by
  induction m generalizing as g z with
  | zero=>simp [RecordedAliasRun.run,mass];rfl
  | succ m ih=>
    let a:=RecordedAliasSteps.step c as g z
    have ht:=ih (Function.update as (c.k+g) a.1.1) (g+1) a.2
    change mass (a.1.2++(RecordedAliasRun.run c (Function.update as (c.k+g) a.1.1) (g+1) m a.2).1.2)≤_
    rw [mass_append,step_mass]
    nlinarith

theorem program_count (D : List Row) (js : List Job) :
    (ConcretePortRows.program D js).length=2*mass js := by
  induction js generalizing D with
  | nil=>rfl
  | cons j js ih=>
    simp only [ConcretePortRows.program,List.length_append,ConcreteSelectionProgram.commands_count,ih]
    simp [mass];omega

theorem built_count (n : Nat) (hn : 2≤n) :
    (RecordedAliasRun.program n hn).length≤
      192*(n+1)^3+96*(n+1)^2 := by
  let k:=n+1
  let z:=initial (AliasAssembly.source n hn) (AliasAssembly.source_canonical n hn)
  let c:=AliasAssembly.context k (by omega) z
  have hm:=run_mass c.1 (AliasAssembly.inputAliases (AliasAssembly.width k) c.1) 0 (3*k-4) c.2
  have hk : c.1.k=k:=rfl
  rw [hk] at hm
  have hw:=AliasAssembly.width_bound k
  have hs : 3*k-4≤3*k:=Nat.sub_le _ _
  have hb : 2*(AliasAssembly.width k+2)*(3*k-4)*(k+0+(3*k-4))≤
      2*(4*k+2)*(3*k)*(4*k) :=
    Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left 2 hw) hs) (by omega)
  change (ConcretePortRows.program _ _).length≤_
  rw [program_count]
  change 2*mass (RecordedAliasRun.run c.1
    (AliasAssembly.inputAliases (AliasAssembly.width k) c.1) 0 (3*k-4) c.2).1.2≤_
  have h:=hm.trans hb
  change _≤192*k^3+96*k^2
  nlinarith

#print axioms tabulate_mass
#print axioms run_mass
#print axioms built_count
end L3Emitter.ConcretePortCost

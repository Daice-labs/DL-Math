import ValueInductionBranches
namespace L3Emitter.ForcingNodeSource
open EREF EREF.GeneralRED REDWitness AliasNetwork

def nodes (n:Nat) (hn:2≤n):=ConstantLookup.ns (n+1) (by omega)
def lookup (n:Nat) (hn:2≤n) (node:PriorityBank.Node):=
  (ForcingCandidates.candidates (n+1) (by omega)).find? fun z=>decide (node.input=(z.var:Int))

theorem present (n:Nat) (hn:2≤n) (node:PriorityBank.Node) (hnod:node∈nodes n hn):
    ∃z,lookup n hn node=some z:=by
  obtain ⟨z,hz,he,_⟩:=ConstantLookup.selected_value (n+1) (by omega) node hnod
  cases hh:lookup n hn node with
  | some a=>exact ⟨a,rfl⟩
  | none=>
    have h:=List.find?_eq_none.mp hh z hz
    simp [he] at h

theorem job_valid (n:Nat) (hn:2≤n) (node:PriorityBank.Node) (hnod:node∈nodes n hn)
    (z:ForcingCandidates.Candidate (3*(n+1)-4)) (he:lookup n hn node=some z):
    (node,z)∈ForcingFieldBank.jobs (n+1) (by omega):=by
  apply (ForcingFieldBank.job_mem _ _ _ _).mpr
  have hh:=List.find?_some he
  exact ⟨hnod,List.mem_of_find?_eq_some he,of_decide_eq_true hh⟩

theorem nonzero (n:Nat) (hn:2≤n) (node:PriorityBank.Node) (hnod:node∈nodes n hn):(node.choice:Int)≠0:=by
  have :=RestrictionBit.choice_above _ _ node hnod
  omega

def guards (n:Nat) (hn:2≤n):List Int:=(nodes n hn).map fun node=>(node.choice:Int)
theorem nonempty (n:Nat) (hn:2≤n):guards n hn≠[]:=by
  intro h
  have hh:=congrArg List.length h
  simp only [guards,List.length_map,nodes,ConstantLookup.ns,PriorityBank.nodes_length,List.length_nil] at hh
  exact ForcingFamily.raw_nonempty (n+1) (by omega) (List.length_eq_zero_iff.mp hh)

theorem alo (n:Nat) (hn:2≤n):clause (guards n hn)∈SharedValueBank.result n hn:=by
  have h:clause (guards n hn)∈ForcingFamily.selected (n+1) (by omega):=
    (ForcingFamily.original_to_selected_forcing (n+1) (by omega)).2.1
  exact SharedValueBank.gamma_retained n hn _ (PrimaryInputLinks.primary_keep n hn _
    (List.mem_append_left _ (List.mem_append_left _ (ForcingFieldBank.base_contains n hn _ h))))

#print axioms present
#print axioms job_valid
#print axioms nonempty
#print axioms alo
end L3Emitter.ForcingNodeSource

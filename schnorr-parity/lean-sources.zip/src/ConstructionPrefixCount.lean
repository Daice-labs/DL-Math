import ConstructionTransportCount
import ConstructionFormulaScale

set_option maxHeartbeats 800000

namespace L3Emitter.ConstructionPrefixCount
open EREF EREF.GeneralRED ConstructionCountTools

/-- Count of the complete recorded prefix through selector-row transport,
before the recursive alias network and subsequent lower-formula banks.
Unit: main commands, including every definition RED and consequence. -/
theorem before_aliases (n : Nat) (hn : 2≤n) :
    (RecordedTransportPrefix.selectorProgram n hn).length≤100000*(n+2)^5*2^n := by
  have hc:=ConstructionConstantCount.complete n hn
  have hr:=ConstructionRankCount.complete (n+1) (by omega) (BetaValue.result n hn)
  have hw:=ConstructionTransportCount.wire n hn
  have hg:=ConstructionTransportCount.gamma_jobs n hn
  have hi:=ConstructionTransportCount.input n hn
  have ho:=ConstructionTransportCount.output n hn
  have hv:=ConstructionTransportCount.raw n hn
  have hu:=ConstructionTransportCount.unary n hn
  have hs:=ConstructionTransportCount.selector n hn
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have p4:(n+2)^4≤(n+2)^5:=Nat.pow_le_pow_right (by omega) (by omega)
  have p2:(n+1)^2≤(n+2)^5:=by
    exact (Nat.pow_le_pow_left (by omega) 2).trans (Nat.pow_le_pow_right (by omega) (by omega))
  have p3:(n+1)^3≤(n+2)^5:=by
    exact (Nat.pow_le_pow_left (by omega) 3).trans (Nat.pow_le_pow_right (by omega) (by omega))
  have p5:(n+1)^5≤(n+2)^5:=Nat.pow_le_pow_left (by omega) 5
  let Q:=(n+2)^5*2^n
  have hc':(RecordedConstantTransport.program n hn).length≤12000*Q:=by
    exact hc.trans (by dsimp [Q];nlinarith [Nat.mul_le_mul_right (2^n) p4])
  have hr':(RecordedRankAdmission.program (n+1) (by omega) (BetaValue.result n hn)).length≤1100*Q:=by
    exact hr.trans (by dsimp [Q];nlinarith)
  have hw':(WireBank.program n hn).length≤36*Q:=by
    exact hw.trans (by dsimp [Q];nlinarith [Nat.mul_le_mul_right (2^n) p2])
  have hg':(GammaConstant.program n hn).length≤15552*Q:=by
    simp only [GammaConstant.program,List.length_map]
    exact hg.trans (by dsimp [Q];nlinarith [Nat.mul_le_mul_right (2^n) p5])
  have hi':(InputBank.program n hn).length≤6*Q:=by
    rw [hi]
    have hn1:n≤n+1:=by omega
    have hsn:3*(n+1)-4≤3*(n+1):=Nat.sub_le ..
    have hprod:=Nat.mul_le_mul hsn hn1
    have hfin:2*(3*(n+1)-4)*n≤6*(n+2)^5:=by nlinarith
    dsimp [Q];nlinarith [Nat.mul_le_mul_right (2^n) hfin]
  have ho':(OutputBank.program n hn).length≤2*Q:=by
    rw [ho];dsimp [Q];nlinarith [Nat.one_le_pow (n+2) 5 (by omega)]
  have hv':(RecordedRawValues.program n hn).length≤57*Q:=by
    exact hv.trans (by dsimp [Q];nlinarith [Nat.mul_le_mul_right (2^n) p2])
  have hu':(GammaUnary.program n hn).length≤62208*Q:=by
    exact hu.trans (by dsimp [Q];nlinarith [Nat.mul_le_mul_right (2^n) p5])
  have hs':(SelectorBank.program n hn).length≤96*Q:=by
    exact hs.trans (by dsimp [Q];nlinarith)
  unfold RecordedTransportPrefix.selectorProgram RecordedTransportPrefix.unaryProgram
    RecordedTransportPrefix.rawProgram RecordedTransportPrefix.outputProgram
    RecordedTransportPrefix.inputProgram RecordedTransportPrefix.gammaProgram
    RecordedTransportPrefix.wireProgram RecordedTransportPrefix.rankProgram
  simp only [List.length_append,polProgram_length]
  rw [Nat.mul_assoc]
  change _≤100000*Q
  omega

/-- The same actual prefix has polynomial length in the original encoded
formula's row count. This theorem does not count any later alias/lower bank. -/
theorem formula_polynomial (n : Nat) (hn : 2≤n) :
    (RecordedTransportPrefix.selectorProgram n hn).length≤
      3200000*(ConstructionFormulaScale.rows n)^6 := by
  have h:=before_aliases n hn
  have hp:(n+2)^5≤32*(n+1)^5:=by
    have hh:=Nat.pow_le_pow_left (show n+2≤2*(n+1) by omega) 5
    nlinarith
  have ht:=Nat.mul_le_mul_right (2^n) hp
  have hc:=ConstructionFormulaScale.monomial n 5 1 3200000 hn
  norm_num only [Nat.one_mul, Nat.reduceAdd] at hc
  exact h.trans (by nlinarith)

#print axioms before_aliases
#print axioms formula_polynomial
end L3Emitter.ConstructionPrefixCount

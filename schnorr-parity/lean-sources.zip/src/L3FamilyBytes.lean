/-
Exact ASCII length of the serialized ORIGINAL formula (`Fam.opb`) and an explicit
upper bound with concrete coefficients, for every k, s ≥ 1.

The serialized text is pure ASCII, so `String.length` (characters) equals the byte
count; the Python emitter encodes with `.encode("ascii")` and the four finite
cross-checks (k = 3..6) confirm equal byte counts and SHA-256 digests.

This covers only the ORIGINAL rows (obligation 6 asks for the whole proof, i.e. also
every RED/POL/RUP line emitted by frontend.py, cofactor.py, transport.py,
output.py and compose.py; those are not covered here).
-/
import L3FamilySer

namespace L3

/-- decimal width of n (`Nat.repr`, which is what `toString` uses) -/
def digits (n : Nat) : Nat := (Nat.repr n).length

theorem digits_pos (n : Nat) : 0 < digits n := Nat.length_repr_pos

theorem digits_mono {n m : Nat} (h : n ≤ m) : digits n ≤ digits m := by
  have hm : m < 10 ^ digits m :=
    (Nat.length_repr_le_iff (digits_pos m)).mp (Nat.le_refl _)
  exact (Nat.length_repr_le_iff (digits_pos m)).mpr (Nat.lt_of_le_of_lt h hm)

theorem length_toString_nat (n : Nat) : (toString n).length = digits n := rfl

/-- `"1 x7"` is 3 + digits, `"1 ~x7"` is 4 + digits -/
theorem length_litStr (l : Int) :
    (litStr l).length = (if l > 0 then 3 else 4) + digits l.natAbs := by
  unfold litStr
  split <;> simp only [String.length_append, length_toString_nat] <;> rfl

theorem length_litStr_le (l : Int) (V : Nat) (h : l.natAbs ≤ V) :
    (litStr l).length ≤ 4 + digits V := by
  rw [length_litStr]
  have := digits_mono h
  split <;> omega

/-- length of a space-separated list: the parts plus one space per gap -/
theorem length_intercalate_space (xs : List String) :
    (" ".intercalate xs).length = (xs.map String.length).sum + (xs.length - 1) := by
  induction xs with
  | nil => simp [String.intercalate_nil]
  | cons a as ih =>
    cases as with
    | nil => simp [String.intercalate_singleton]
    | cons b bs =>
      rw [String.intercalate_cons_of_ne_nil (by simp)]
      simp only [String.length_append, ih, List.map_cons, List.sum_cons, List.length_cons]
      have : (" ".length) = 1 := rfl
      omega

/-- exact length of one serialized row -/
theorem length_row_opb (r : Row) :
    (r.opb).length =
      (r.lits.map fun l => (if l > 0 then 3 else 4) + digits l.natAbs).sum
        + (r.lits.length - 1) + 7 + digits r.rhs := by
  unfold Row.opb
  simp only [String.length_append, length_intercalate_space, List.map_map, List.length_map,
    length_toString_nat]
  have h1 : (" >= ").length = 4 := rfl
  have h2 : (" ;\n").length = 3 := rfl
  simp only [Function.comp_def, length_litStr]
  omega

/-! ### Generic sum lemmas (core only) -/

theorem sum_map_le {α : Type} (l : List α) (f g : α → Nat) (h : ∀ a ∈ l, f a ≤ g a) :
    (l.map f).sum ≤ (l.map g).sum := by
  induction l with
  | nil => simp
  | cons a l ih =>
    simp only [List.map_cons, List.sum_cons]
    have := h a (by simp)
    have := ih (fun a' ha' => h a' (by simp [ha']))
    omega

theorem sum_map_const_le {α : Type} (l : List α) (f : α → Nat) (c : Nat) (h : ∀ a ∈ l, f a ≤ c) :
    (l.map f).sum ≤ l.length * c := by
  induction l with
  | nil => simp
  | cons a l ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons]
    have := h a (by simp)
    have := ih (fun a' ha' => h a' (by simp [ha']))
    rw [Nat.succ_mul]; omega

theorem sum_map_add {α : Type} (l : List α) (f g : α → Nat) :
    (l.map fun a => f a + g a).sum = (l.map f).sum + (l.map g).sum := by
  induction l with
  | nil => simp
  | cons a l ih => simp only [List.map_cons, List.sum_cons, ih]; omega

theorem sum_map_mul_const {α : Type} (l : List α) (f : α → Nat) (c : Nat) :
    (l.map fun a => f a * c).sum = (l.map f).sum * c := by
  induction l with
  | nil => simp
  | cons a l ih => simp only [List.map_cons, List.sum_cons, ih, Nat.add_mul]

theorem sum_map_const {α : Type} (l : List α) (c : Nat) :
    (l.map fun _ => c).sum = l.length * c := by
  induction l with
  | nil => simp
  | cons a l ih => simp only [List.map_cons, List.sum_cons, ih, List.length_cons]; rw [Nat.succ_mul]; omega

/-- per-row upper bound: `n` literals each ≤ 4 + digits V, at most n gaps, and the tail -/
theorem length_row_opb_le (r : Row) (V : Nat) (hr : r.wf V) :
    (r.opb).length ≤ r.lits.length * (5 + digits V) + (7 + digits r.rhs) := by
  rw [length_row_opb]
  have hsum := sum_map_const_le r.lits (fun l => (if l > 0 then 3 else 4) + digits l.natAbs)
    (4 + digits V) (by
      intro l hl
      have := digits_mono (hr l hl).2
      show (if l > 0 then 3 else 4) + digits l.natAbs ≤ 4 + digits V
      split <;> omega)
  have hmul : r.lits.length * (5 + digits V) = r.lits.length * (4 + digits V) + r.lits.length := by
    rw [show 5 + digits V = (4 + digits V) + 1 by omega, Nat.mul_add, Nat.mul_one]
  omega

/-- length of the whole text as a sum over rows -/
theorem length_opb (F : Fam) :
    (F.opb).length = (F.header).length + (F.rows.map fun r => (r.opb).length).sum := by
  unfold Fam.opb
  rw [String.length_append]
  congr 1
  rw [← String.length_toList, String.toList_join, List.length_flatMap]
  simp [List.map_map, Function.comp_def, String.length_toList]

theorem length_header (F : Fam) : (F.header).length = 28 + digits F.V + digits F.F := by
  unfold Fam.header
  simp only [String.length_append, length_toString_nat]
  have h1 : ("* #variable= ").length = 13 := rfl
  have h2 : (" #constraint= ").length = 14 := rfl
  have h3 : ("\n").length = 1 := rfl
  omega

/-! ### Literal counts per block -/

/-- Σ over a flatMap of a per-element constant -/
theorem sum_map_flatMap_const {α β : Type} (l : List α) (f : α → List β) (g : β → Nat) (c : Nat)
    (h : ∀ a ∈ l, ((f a).map g).sum = c) : ((l.flatMap f).map g).sum = l.length * c := by
  induction l with
  | nil => simp
  | cons a l ih =>
    simp only [List.flatMap_cons, List.map_append, List.sum_append, List.length_cons]
    rw [h a (by simp), ih (fun a' ha' => h a' (by simp [ha'])), Nat.succ_mul]
    omega

/-- Σ over a map of a per-element constant -/
theorem sum_map_map_const {α β : Type} (l : List α) (f : α → β) (g : β → Nat) (c : Nat)
    (h : ∀ a ∈ l, g (f a) = c) : ((l.map f).map g).sum = l.length * c := by
  induction l with
  | nil => simp
  | cons a l ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons]
    rw [h a (by simp), ih (fun a' ha' => h a' (by simp [ha'])), Nat.succ_mul]
    omega

namespace Fam

/-- number of literals in a row list -/
def litCount (rows : List Row) : Nat := (rows.map fun r => r.lits.length).sum

theorem litCount_append (a b : List Row) : litCount (a ++ b) = litCount a + litCount b := by
  simp [litCount]

/-- block 1 has 2(k+t) literals per (t, p): total 4·Σ_{t<s}(k+t) = 2S -/
theorem litCount_block1 (F : Fam) : litCount F.block1 = 2 * F.S := by
  unfold litCount block1
  have inner : ∀ t, (((List.range 2).flatMap fun p =>
      let n := F.k + t
      let ids := (List.range n).map fun j => F.sel t p j
      [ ({ lits := ids.map pos, rhs := 1 } : Row), { lits := ids.map neg, rhs := n - 1 } ]).map
        fun r => r.lits.length).sum = 2 * (2 * (F.k + t)) := by
    intro t
    rw [sum_map_flatMap_const _ _ _ (2 * (F.k + t))]
    · simp
    · intro p _; simp; omega
  have sum : ∀ s, (((List.range s).flatMap fun t =>
      (List.range 2).flatMap fun p =>
        let n := F.k + t
        let ids := (List.range n).map fun j => F.sel t p j
        [ ({ lits := ids.map pos, rhs := 1 } : Row), { lits := ids.map neg, rhs := n - 1 } ]).map
          fun r => r.lits.length).sum = 2 * (s * (2 * F.k + s - 1)) := by
    intro s
    induction s with
    | zero => simp
    | succ s ih =>
      rw [List.range_succ (n := s), List.flatMap_append, List.map_append, List.sum_append, ih]
      simp only [List.flatMap_cons, List.flatMap_nil, List.append_nil]
      rw [inner s]
      cases s with
      | zero => simp
      | succ s =>
        have h1 : 2 * F.k + (s + 1) - 1 = 2 * F.k + s := by omega
        have h2 : 2 * F.k + (s + 1 + 1) - 1 = 2 * F.k + s + 1 := by omega
        rw [h1, h2]; grind
  exact sum F.s

theorem litCount_block2 (F : Fam) : litCount F.block2 = 8 * F.s := by
  unfold litCount block2
  rw [sum_map_flatMap_const _ _ _ 8]
  · simp; omega
  · intro t _; simp

theorem litCount_inputRows (F : Fam) (t p j : Nat) : litCount (F.inputRows t p j) = 2 * F.T := by
  unfold litCount inputRows
  rw [sum_map_map_const _ _ _ 2]
  · simp; omega
  · intro x _; simp

theorem litCount_gateRows (F : Fam) (t p i : Nat) : litCount (F.gateRows t p i) = 6 * F.T := by
  unfold litCount gateRows
  rw [sum_map_flatMap_const _ _ _ 6]
  · simp; omega
  · intro x _; simp

/-- block 3: per (t, p), 2kT + 6tT literals; total 2·Σ_{t<s}(2kT + 6tT) = 2sT(2k + 3(s−1)) -/
theorem litCount_block3 (F : Fam) : litCount F.block3 = 2 * F.s * F.T * (2 * F.k + 3 * (F.s - 1)) := by
  unfold litCount block3
  have inner : ∀ t, (((List.range 2).flatMap fun p =>
      ((List.range F.k).flatMap fun j => F.inputRows t p j) ++
      ((List.range t).flatMap fun i => F.gateRows t p i)).map fun r => r.lits.length).sum
      = 2 * (F.k * (2 * F.T) + t * (6 * F.T)) := by
    intro t
    rw [sum_map_flatMap_const _ _ _ (F.k * (2 * F.T) + t * (6 * F.T))]
    · simp
    · intro p _
      rw [List.map_append, List.sum_append,
        sum_map_flatMap_const _ _ _ (2 * F.T) (fun j _ => F.litCount_inputRows t p j),
        sum_map_flatMap_const _ _ _ (6 * F.T) (fun i _ => F.litCount_gateRows t p i)]
      simp
  have sum : ∀ s, (((List.range s).flatMap fun t =>
      (List.range 2).flatMap fun p =>
        ((List.range F.k).flatMap fun j => F.inputRows t p j) ++
        ((List.range t).flatMap fun i => F.gateRows t p i)).map fun r => r.lits.length).sum
      = 2 * s * F.T * (2 * F.k + 3 * (s - 1)) := by
    intro s
    induction s with
    | zero => simp
    | succ s ih =>
      rw [List.range_succ (n := s), List.flatMap_append, List.map_append, List.sum_append, ih]
      simp only [List.flatMap_cons, List.flatMap_nil, List.append_nil]
      rw [inner s]
      cases s with
      | zero => simp; grind
      | succ s =>
        have h1 : s + 1 - 1 = s := by omega
        have h2 : s + 1 + 1 - 1 = s + 1 := by omega
        rw [h1, h2]; grind
  exact sum F.s

theorem litCount_block4 (F : Fam) : litCount F.block4 = 32 * F.s * F.T := by
  unfold litCount block4
  rw [sum_map_flatMap_const _ _ _ (32 * F.T)]
  · simp; grind
  · intro t _
    rw [sum_map_flatMap_const _ _ _ 32]
    · simp; grind
    · intro x _
      rw [sum_map_flatMap_const _ _ _ 16]
      · simp
      · intro a _
        rw [sum_map_flatMap_const _ _ _ 8]
        · simp
        · intro b _; simp

theorem litCount_block5 (F : Fam) : litCount F.block5 = F.T := by
  unfold litCount block5
  rw [sum_map_map_const _ _ _ 1]
  · simp
  · intro x _; simp

/-- total number of literals in the original formula -/
def L (F : Fam) : Nat :=
  2 * F.S + 8 * F.s + 2 * F.s * F.T * (2 * F.k + 3 * (F.s - 1)) + 32 * F.s * F.T + F.T

theorem litCount_rows (F : Fam) : litCount F.rows = F.L := by
  unfold rows L
  simp only [litCount_append, litCount_block1, litCount_block2, litCount_block3, litCount_block4,
    litCount_block5]

/-! ### Right-hand sides -/

theorem rhs_le (F : Fam) (hs : 1 ≤ F.s) : ∀ r ∈ F.rows, r.rhs ≤ F.k + F.s := by
  unfold rows block1 block2 block3 inputRows gateRows block4 block5
  intro r hr
  simp only [List.mem_append, List.mem_flatMap, List.mem_range, List.mem_map, List.mem_cons,
    List.not_mem_nil, or_false] at hr
  rcases hr with ((((⟨t, ht, p, hp, hr | hr⟩ | ⟨t, ht, c, hc, rfl⟩) | ⟨t, ht, p, hp, hr⟩) |
    ⟨t, ht, x, hx, a, ha, b, hb, hr | hr⟩) | ⟨x, hx, rfl⟩)
  · subst hr; simp; omega
  · subst hr; simp; omega
  · simp; omega
  · rcases hr with ⟨j, hj, ⟨x, hx, rfl⟩⟩ | ⟨i, hi, ⟨x, hx, hr | hr⟩⟩
    · simp; omega
    · subst hr; simp; omega
    · subst hr; simp; omega
  · subst hr; simp; omega
  · subst hr; simp; omega
  · simp; omega

/-! ### The bound -/

/-- Σ_{rows} (n_r (5 + dV) + 7 + d(rhs_r)) ≤ L (5 + dV) + F (7 + d(k+s)) -/
theorem sum_row_bounds (F : Fam) (hs : 1 ≤ F.s) :
    (F.rows.map fun r => (r.opb).length).sum
      ≤ F.L * (5 + digits F.V) + F.F * (7 + digits (F.k + F.s)) := by
  have hwf := F.rows_wf hs
  have hrhs := F.rhs_le hs
  have point : ∀ r ∈ F.rows, (r.opb).length
      ≤ r.lits.length * (5 + digits F.V) + (7 + digits (F.k + F.s)) := by
    intro r hr
    have h1 := length_row_opb_le r F.V (hwf r hr)
    have h2 := digits_mono (hrhs r hr)
    omega
  have h := sum_map_le F.rows _ _ point
  rw [sum_map_add, sum_map_mul_const, sum_map_const] at h
  have hc : (F.rows.map fun r => r.lits.length).sum = F.L := F.litCount_rows
  rw [hc, F.length_rows] at h
  exact h

/-- **Exact ASCII size bound of the serialized ORIGINAL formula**, all k, s ≥ 1:
    |opb| ≤ 28 + d(V) + d(F) + L·(5 + d(V)) + F·(7 + d(k+s)), where d = decimal width,
    L = 2S + 8s + 2sT(2k + 3(s−1)) + 32sT + T, F = (2s(k+s+3)+1)T + 6s. -/
theorem opb_length_le (F : Fam) (hs : 1 ≤ F.s) :
    (F.opb).length ≤ 28 + digits F.V + digits F.F
      + F.L * (5 + digits F.V) + F.F * (7 + digits (F.k + F.s)) := by
  rw [length_opb, length_header]
  have := F.sum_row_bounds hs
  omega

/-- the specialization used by the emitter: s = 3k − 4 (k ≥ 3) -/
theorem opb_length_le_emitter (k : Nat) (hk : 3 ≤ k) (b : Nat → Bool) :
    let F : Fam := { k := k, s := 3 * k - 4, b := b }
    (F.opb).length ≤ 28 + digits F.V + digits F.F
      + F.L * (5 + digits F.V) + F.F * (7 + digits (F.k + F.s)) :=
  opb_length_le _ (by simp; omega)

end Fam
end L3

#print axioms L3.Fam.opb_length_le
#print axioms L3.Fam.length_rows
#print axioms L3.Fam.rows_wf

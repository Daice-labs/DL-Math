import RankGateEvaluation
namespace L3Emitter.LowerGateEvaluation
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL AliasProgram

def body (n:Nat) (hn:2≤n) (t x:Nat) (a b w:Bool):=
  RetainedBlockFold.body (fun G=>RankGateEvaluation.rows n hn t G x a b w) (RankZeroTransport.gates n)
def rows (n:Nat) (hn:2≤n) (t x:Nat) (a b w:Bool):=
  body n hn t x a b w++[RankGateEvaluation.row n hn t x a b w]
def program (n:Nat) (hn:2≤n) (t x:Nat) (a b w:Bool) (D:List Row):Program:=
  RetainedBlockFold.run (fun G E=>RankGateEvaluation.program n hn t G x a b w E)
    (fun G=>RankGateEvaluation.rows n hn t G x a b w) (RankZeroTransport.gates n) D++
  [(RankGateEvaluation.row n hn t x a b w,ProjectionTrace.joinCaseTokens (D++body n hn t x a b w)
    (RankZeroTransport.gates n) (fun G=>(TopologyContext.guard n hn G t).val) (RankGateEvaluation.row n hn t x a b w))]

theorem rank_alo (n:Nat) (hn:2≤n) (t:Nat) (ht:t<RankConstruction.width (n+1)):
    clause ((RankZeroTransport.gates n).map fun G=>(TopologyContext.guard n hn G t).val)∈GateEvaluationBindings.base n hn:=by
  have hh:=RankFacts.alo n hn t ht
  have hk:=TopologyContext.global_kept n hn _ (RankPortSelection.output_keep n hn _ hh)
  apply GateEvaluationBindings.selector_keep
  apply LowerSelectorComplete.predecessor_kept n hn
  simpa only [RankZeroTransport.gates,List.map_map,Function.comp_def] using hk

theorem checks (n:Nat) (hn:2≤n) (t x:Nat) (ht:t<RankConstruction.width (n+1))
    (hx:x<FamilyNamespace.truthRows n) (a b w:Bool) (D:List Row)
    (hd:∀R∈GateEvaluationBindings.base n hn,R∈D):
    check D (program n hn t x a b w D)=some (D++rows n hn t x a b w):=by
  have h0:=RetainedBlockFold.checks (GateEvaluationBindings.base n hn)
    (fun G E=>RankGateEvaluation.program n hn t G x a b w E)
    (fun G=>RankGateEvaluation.rows n hn t G x a b w)
    (fun G=>G∈RankZeroTransport.gates n)
    (fun G hG E he=>RankGateEvaluation.checks n hn t G x ht hG hx a b w E he)
    (RankZeroTransport.gates n) (fun _ h=>h) D hd
  have hj:=ProjectionTrace.join_cases (D++body n hn t x a b w) (RankZeroTransport.gates n)
    (fun G=>(TopologyContext.guard n hn G t).val) (RankGateEvaluation.row n hn t x a b w)
    (canonical_normalize _ _) (by simp [RankZeroTransport.gates];omega)
    (fun G _=>(TopologyContext.guard n hn G t).property) (List.mem_append_left _ (hd _ (rank_alo n hn t ht)))
    (by
      intro G hG
      apply List.mem_append_right
      apply RetainedBlockFold.contains _ _ G hG
      exact List.mem_append_right _ (List.mem_singleton_self _))
  have h1:check (D++body n hn t x a b w)
    [(RankGateEvaluation.row n hn t x a b w,ProjectionTrace.joinCaseTokens (D++body n hn t x a b w)
      (RankZeroTransport.gates n) (fun G=>(TopologyContext.guard n hn G t).val) (RankGateEvaluation.row n hn t x a b w))]=
      some ((D++body n hn t x a b w)++[RankGateEvaluation.row n hn t x a b w]):=by
    simp only [check,hj,↓reduceIte]
  simpa only [program,rows,body,List.append_assoc] using check_append _ _ _ _ _ h0 h1

theorem final_mem (n:Nat) (hn:2≤n) (t x:Nat) (a b w:Bool):
    RankGateEvaluation.row n hn t x a b w∈rows n hn t x a b w:=by simp [rows]
#print axioms checks
end L3Emitter.LowerGateEvaluation

import LowerSelectorAMO
namespace L3Emitter.GuardedZeroSelection
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram
variable {ι:Type}
def row (b q:Bit):Row:=clause [-b.val,-q.val]
def caseRow (b q:Bit) (c:Bit):Row:=Resolution.branch (row b q) (-c.val)
def tape (D:List Row) (b q c a:Bit):List Tok:=
  CommonGuardResolve.tape D [] [-b.val] [-c.val,-q.val] (-a.val)

theorem leaf_check (D:List Row) (b q c a:Bit)
    (hz:row b a∈D) (hl:clause [-c.val,-q.val,a.val]∈D):
    polEval (dbOf D) (tape D b q c a) []=some (caseRow b q c):=by
  have hr:CommonGuardResolve.right [] [-c.val,-q.val] (-a.val)∈D:=by
    simp only [CommonGuardResolve.right,List.nil_append,List.cons_append,neg_neg]
    rw [ProjectionTrace.clause_perm [a.val,-c.val,-q.val] [-c.val,-q.val,a.val]
      (by simp [Valid,a.property,c.property,q.property])
      (by simp [Valid,a.property,c.property,q.property]) ((List.Perm.swap _ _ _).trans ((List.Perm.swap _ _ []).cons _))]
    exact hl
  have h:=CommonGuardResolve.checks D [] [-b.val] [-c.val,-q.val] (-a.val)
    (by simp [Valid]) (by simp [Valid,b.property]) (by simp [Valid,c.property,q.property])
    (neg_ne_zero.mpr a.property) hz hr
  rw [caseRow,row,ProjectionTrace.branch_clause _ (by simp [Valid,b.property,q.property]) _
    (neg_ne_zero.mpr c.property)]
  have he:CommonGuardResolve.target [] [-b.val] [-c.val,-q.val]=clause [-c.val,-b.val,-q.val]:=by
    exact ProjectionTrace.clause_perm _ _ (by simp [Valid,b.property,c.property,q.property])
      (by simp [Valid,b.property,c.property,q.property]) (List.Perm.swap ..)
  exact he ▸ h

def casesProgram (D:List Row) (is:List ι) (c a:ι→Bit) (b q:Bit):Program:=
  is.map fun i=>(caseRow b q (c i),tape D b q (c i) (a i))
def caseRows (is:List ι) (c:ι→Bit) (b q:Bit):=is.map fun i=>caseRow b q (c i)
def rows (is:List ι) (c:ι→Bit) (b q:Bit):=caseRows is c b q++[row b q]
def program (D:List Row) (is:List ι) (c a:ι→Bit) (b q:Bit):Program:=
  casesProgram D is c a b q++[(row b q,ProjectionTrace.joinCaseTokens
    (D++caseRows is c b q) is (fun i=>(c i).val) (row b q))]
theorem checks (D:List Row) (is:List ι) (c a:ι→Bit) (b q:Bit) (hne:is≠[])
    (ha:clause (is.map fun i=>(c i).val)∈D)
    (hz:∀i∈is,row b (a i)∈D)
    (hl:∀i∈is,clause [-(c i).val,-q.val,(a i).val]∈D):
    check D (program D is c a b q)=some (D++rows is c b q):=by
  have h0:=IndependentProgram.check_base D (casesProgram D is c a b q) (by
    intro cmd hc;obtain ⟨i,hi,rfl⟩:=List.mem_map.mp hc;exact leaf_check D b q (c i) (a i) (hz i hi) (hl i hi))
  have he:outputs (casesProgram D is c a b q)=caseRows is c b q:=by
    simp [outputs,casesProgram,caseRows,List.map_map]
  rw [he] at h0
  have hj:=ProjectionTrace.join_cases (D++caseRows is c b q) is (fun i=>(c i).val)
    (row b q) (canonical_normalize _ _) hne (fun i _=>(c i).property)
    (List.mem_append_left _ ha) (fun i hi=>List.mem_append_right _ (List.mem_map.mpr ⟨i,hi,rfl⟩))
  have h1:check (D++caseRows is c b q) [(row b q,ProjectionTrace.joinCaseTokens
      (D++caseRows is c b q) is (fun i=>(c i).val) (row b q))]=
      some ((D++caseRows is c b q)++[row b q]):=by simp only [check,hj,↓reduceIte]
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h1

theorem token_count (D:List Row) (b q c a:Bit):(tape D b q c a).length=10:=by
  rw [tape,CommonGuardResolve.token_count];rfl
theorem command_count (D:List Row) (is:List ι) (c a:ι→Bit) (b q:Bit):
    (program D is c a b q).length=is.length+1:=by simp [program,casesProgram]
#print axioms checks
end L3Emitter.GuardedZeroSelection

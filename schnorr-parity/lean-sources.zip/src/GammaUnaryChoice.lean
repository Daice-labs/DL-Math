import GammaCofactorValue
namespace L3Emitter.GammaUnaryChoice
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL CofactorValueRows
abbrev Job:=BetaPort.Job
def g {n:Nat} (j:Job n):Nat:=GammaCofactorValue.g j
def va (side a b:Bool):=if side then a else b
def vb (side a b:Bool):=if side then b else a
def K (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool):=
  UnaryValueStep.G n hn (g j) u side (va side a b) (vb side a b) v++UnaryValueStep.H n hn (g j) u side

def Q (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool):=
  K n hn j u side a b v++[sign v (unary n hn (g j) u)]
def row (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool):=
  CommonGuardResolve.target [] [-BetaAliasValue.choice j] (Q n hn j u side a b v)
def tape (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool) (D:List Row):=
  CommonGuardResolve.tape D [] [-BetaAliasValue.choice j] (Q n hn j u side a b v)
    ((PrimaryAliasBank.cfg n hn).gamma (g j)).val

theorem valid_K (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool):Valid (K n hn j u side a b v):=by
  simp [K,UnaryValueStep.G,UnaryValueStep.H,LookupEvaluation.guards,Valid,sign_valid]

theorem old_row (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool):
    UnaryValueStep.finalRow n hn (g j) u side (va side a b) (vb side a b) v=
      clause (K n hn j u side a b v++[-((PrimaryAliasBank.cfg n hn).gamma (g j)).val]++[sign v (unary n hn (g j) u)]):=by
  have hg:0<g j:=by change 0<j.1.2.parent.gamma; have:=j.1.2.parent.ordered; have:=j.1.2.parent.beta_pos;omega
  have ho:=UnarySnapshots.actual_output n hn (g j) hg j.1.2.parent.gamma_lt u
  have hc:=(UnarySnapshots.actual_category n hn (g j) u).2.1
  simp only [UnaryValueStep.finalRow,GuardedJoin.target,guarded,ho,hc,K,unary]

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (u side a b v:Bool)
    (D:List Row) (hd:∀R∈GammaChoiceBank.result n hn,R∈D):
    polEval (dbOf D) (tape n hn j u side a b v D) []=some (row n hn j u side a b v):=by
  have hg:0<g j:=by change 0<j.1.2.parent.gamma; have:=j.1.2.parent.ordered; have:=j.1.2.parent.beta_pos;omega
  have vk:=valid_K n hn j u side a b v
  have vq:Valid (Q n hn j u side a b v):=EvaluationCaseSeeds.valid_join vk (by simp [Valid,sign_valid])
  apply CommonGuardResolve.checks D [] [-BetaAliasValue.choice j] _ _ (by simp [Valid])
    (by simp [Valid,BetaAliasValue.choice_valid n hn j hj]) vq ((PrimaryAliasBank.cfg n hn).gamma (g j)).property
  · exact hd _ (GammaChoiceBank.gamma n hn j.1 (GammaCofactorValue.forcing_job n hn j hj))
  · have h:=hd _ (GammaCofactorValue.keeps_unary n hn _
      (UnaryValueBank.all_evaluations n hn (g j) hg j.1.2.parent.gamma_lt u side (va side a b) (vb side a b) v))
    rw [old_row] at h
    change clause ([-((PrimaryAliasBank.cfg n hn).gamma (g j)).val]++(K n hn j u side a b v++[sign v (unary n hn (g j) u)]))∈D
    rw [←List.append_assoc]
    have vg:Valid [-((PrimaryAliasBank.cfg n hn).gamma (g j)).val]:=by simp [Valid,((PrimaryAliasBank.cfg n hn).gamma (g j)).property]
    have vo:Valid [sign v (unary n hn (g j) u)]:=by simp [Valid,sign_valid]
    rw [ProjectionTrace.clause_perm _ _
      (EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join vg vk) vo)
      (EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join vk vg) vo)
      (List.perm_append_comm.append_right _)]
    exact h
#print axioms checks
end L3Emitter.GammaUnaryChoice

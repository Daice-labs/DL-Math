import ConstructionCofactorCount
import RecordedConstantTransport

namespace L3Emitter.ConstructionConstantCount
open EREF EREF.GeneralRED ConstructionCountTools ConstructionFrontendCountTools

theorem flat_count {A B : Type} (xs : List A) (f : A→List B) (M : Nat)
    (h : ∀x∈xs,(f x).length≤M) : (xs.flatMap f).length≤xs.length*M := by
  induction xs with
  | nil=>simp
  | cons x xs ih=>
    simp only [List.flatMap_cons,List.length_append,List.length_cons]
    have hh:=h x (by simp)
    have ht:=ih (by intro y hy;exact h y (by simp [hy]))
    nlinarith

theorem allocation_count (base : List Row) (rows : Nat→List Row)
    (block : Nat→List Row→RecordedScopedTrace.Program) (n M : Nat)
    (h : ∀i D,(block i D).length=M) :
    (RecordedAllocationLoop.program base rows block n).length=n*M := by
  induction n with
  | zero=>simp [RecordedAllocationLoop.program]
  | succ n ih=>rw [RecordedAllocationLoop.program,List.length_append,ih,h];ring

theorem cofactor_bank (n s offset B : Nat) (D : List Row) :
    (RecordedCofactorBank.program n s offset B D).length=12*s*2^n := by
  have hc:∀g p x D,(RecordedCofactorBank.cellProgram n s offset B g p x D).length=4 := by
    intros;rw [RecordedCofactorBank.cellProgram,gate_length];rfl
  have hp:∀g p D,(RecordedCofactorBank.portProgram n s offset B g p D).length=4*2^n := by
    intros;rw [RecordedCofactorBank.portProgram,allocation_count _ _ _ _ 4 (hc _ _)]
    simp [FamilyNamespace.truthRows,Nat.mul_comm]
  have hg:∀g D,(RecordedCofactorBank.gateProgram n s offset B g D).length=12*2^n := by
    intros;rw [RecordedCofactorBank.gateProgram,allocation_count _ _ _ _ (4*2^n) (hp _)]
    ring
  rw [RecordedCofactorBank.program,allocation_count _ _ _ _ (12*2^n) hg];ring

theorem cofactor (n : Nat) (hn : 2≤n) :
    (ConstantCofactor.program n hn).length=8*(3*(n+1)-4)*2^n := by
  simp [ConstantCofactor.program,ForcingSize.rebase_length,ConstantCofactor.sourceProgram,
    CofactorSection.jobs,List.length_flatMap,FamilyNamespace.truthRows,Nat.mul_comm,
    Nat.mul_left_comm,Nat.mul_assoc]

theorem candidates (k : Nat) (hk : 3≤k) :
    (ForcingCandidates.candidates k hk).length≤36*k^2 := by
  have h:=congrArg List.length (ForcingCandidates.raw_identity k (ForcingBounds.ceiling k hk)
    (BranchChoices.chosen k hk))
  simp only [List.length_map] at h
  change (ForcingCandidates.candidates k hk).length=(ForcingFamily.raw k hk).length at h
  rw [h];exact ConstructionSelectionCount.forcing_inputs k hk

theorem field_jobs (k : Nat) (hk : 3≤k) :
    (ForcingFieldBank.jobs k hk).length≤1296*k^4 := by
  have h:=flat_count (ConstantLookup.ns k hk) (fun n=>
    ((ForcingCandidates.candidates k hk).filter (fun z=>decide (n.input=(z.var:Int)))).map (n,·))
    (36*k^2) (by intro n hn;rw [List.length_map];exact (List.length_filter_le ..).trans (candidates k hk))
  have hn:(ConstantLookup.ns k hk).length≤36*k^2:=by
    simpa only [ConstantLookup.ns,PriorityBank.nodes_length] using ConstructionSelectionCount.forcing_inputs k hk
  change (ForcingFieldBank.jobs k hk).length≤_ at h
  nlinarith [Nat.mul_le_mul_right (36*k^2) hn]

theorem field_entries (k : Nat) (hk : 3≤k) :
    (ForcingFieldBank.entries k hk).length≤3888*k^4 := by
  have h: (ForcingFieldBank.entries k hk).length=3*(ForcingFieldBank.jobs k hk).length := by
    simp [ForcingFieldBank.entries,ForcingCandidates.fields,List.length_flatMap,Nat.mul_comm]
  rw [h];have hh:=field_jobs k hk;omega

theorem field_program (k : Nat) (hk : 3≤k) (D : List Row) :
    (ForcingFieldBank.program k hk D).length≤3888*k^4 := by
  simpa only [ForcingFieldBank.program,ForcingSize.rebase_length,ForcingFieldBank.sourceProgram,
    List.length_map] using field_entries k hk

theorem primary (n : Nat) (hn : 2≤n) :
    (PrimaryBank.program n hn).length=4*(3*(n+1)-4)*2^n := by
  simp [PrimaryBank.program,ForcingSize.rebase_length,PrimaryBank.sourceProgram,
    PrimaryBank.jobs,List.length_flatMap,FamilyNamespace.truthRows,Nat.mul_comm,
    Nat.mul_left_comm,Nat.mul_assoc] <;> ring

theorem beta_jobs (n : Nat) (hn : 2≤n) :
    (BetaPort.jobs n hn).length=(ForcingFieldBank.jobs (n+1) (by omega)).length*2^n := by
  simp [BetaPort.jobs,List.length_flatMap,FamilyNamespace.truthRows,Nat.mul_comm]

theorem beta_port (n : Nat) (hn : 2≤n) :
    (BetaPort.program n hn).length≤1296*(n+1)^4*2^n := by
  simp only [BetaPort.program,List.length_map,beta_jobs]
  exact Nat.mul_le_mul_right _ (field_jobs (n+1) (by omega))

theorem beta_value (n : Nat) (hn : 2≤n) :
    (BetaValue.program n hn).length≤2592*(n+1)^4*2^n := by
  have hb:=beta_port n hn
  simp only [BetaPort.program,List.length_map] at hb
  have hv:(BetaValue.program n hn).length=2*(BetaPort.jobs n hn).length:=by
    simp [BetaValue.program,BetaValue.jobs,List.length_flatMap,Nat.mul_comm]
  rw [hv];nlinarith

/-- Main commands for the actual constant/cofactor prefix. Includes definition
REDs, field transfers, primary links and both beta-value branches. -/
theorem complete (n : Nat) (hn : 2≤n) :
    (RecordedConstantTransport.program n hn).length≤12000*(n+2)^4*2^n := by
  have hs:=ConstructionCofactorCount.complete (n+1) (by omega)
  have hf:=field_program (n+1) (by omega) (ForcingFieldBank.base n hn)
  have hp:=beta_port n hn
  have hv:=beta_value n hn
  have h1:(n+1)^4≤(n+2)^4:=Nat.pow_le_pow_left (by omega) 4
  have h2:n+1≤(n+2)^4:=by
    have hh:(n+2)^1≤(n+2)^4:=Nat.pow_le_pow_right (by omega) (by omega)
    simpa only [pow_one] using (show n+1≤(n+2)^1 by simp).trans hh
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have hs':(RecordedCofactorSelection.program (n+1) (by omega)).length≤3500*(n+2)^4*2^n:=by
    exact hs.trans (by nlinarith)
  have hf':(ForcingFieldBank.program (n+1) (by omega) (ForcingFieldBank.base n hn)).length≤3888*(n+2)^4*2^n:=by
    exact hf.trans (by nlinarith)
  have hp':(BetaPort.program n hn).length≤1296*(n+2)^4*2^n:=hp.trans (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ h1))
  have hv':(BetaValue.program n hn).length≤2592*(n+2)^4*2^n:=hv.trans (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ h1))
  have hg:3*(n+1)-4≤3*(n+2)^4:=by omega
  have hgm:=Nat.mul_le_mul_right (2^n) hg
  simp only [RecordedConstantTransport.program,RecordedConstantTransport.betaPortProgram,
    RecordedConstantTransport.primaryProgram,RecordedConstantTransport.fieldsProgram,
    RecordedConstantTransport.cofactorProgram,RecordedConstantTransport.bankProgram,
    List.length_append,polProgram_length,cofactor_bank,cofactor,primary]
  nlinarith

#print axioms cofactor_bank
#print axioms field_jobs
#print axioms complete
end L3Emitter.ConstructionConstantCount

import NumericSourceRelations
namespace L3Emitter.NumericAuxRows
open EREF EREF.GeneralRED REDWitness AliasNetwork NumericNetwork SourceMixture

theorem constant_links (M:Nat) (s:Refs) (h:NumericMixtureRefs.Bounded M s) (c T:Bit)
    (hc:BitBound M c) (hT:BitBound M T) (b:Bool):RowSupport.Bounded M (RankConstantLinks.rows s c T b):=by
  apply RowSupport.append
  · apply RowSupport.append
    · apply NumericForcingFields.clause_rows
      intro l hl;simp only[List.mem_cons,List.not_mem_nil,or_false] at hl
      rcases hl with rfl|rfl <;> simpa using hc
    · apply NumericTreeRows.rows M _ (NumericTreeRows.mixture_trees M s h b).2.2
      intro l hl;obtain rfl:=List.mem_singleton.mp hl;simpa using hc
  · have hunit:BitBound M (RankConstantLinks.unitBit T b):=by
      cases b <;> simpa[RankConstantLinks.unitBit,AliasNetwork.neg,BitBound] using hT
    have hq:=h.2.2.2.2.2.2.2.2
    intro R hR
    simp only[RankConstantLinks.linkRows,List.mem_cons,List.not_mem_nil,or_false] at hR
    rcases hR with rfl|rfl <;> refine ⟨canonical_normalize _ _,RowSupport.clause_bound M _ ?_⟩ <;>
      intro l hl <;> simp only[List.mem_cons,List.not_mem_nil,or_false] at hl <;>
      rcases hl with rfl|rfl|rfl <;> simpa only[Int.natAbs_neg] using (by assumption : BitBound M _)

theorem rank (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1))) (t:Nat) (ht:t<RankConstruction.width (n+1)):
    RowSupport.Bounded (NumericValueClosed.bound n) (RankCoordinate.rows n hn g i t):=by
  have hcat:GateCategories.Category.rank t∈CategoryPrograms.cats n:=by
    simpa[CategoryPrograms.cats,GateCategories.categories,RankConstruction.width] using ht
  apply RowSupport.append
  · unfold RankCoordinate.prepRows;split
    · simp[RowSupport.Bounded]
    · exact NumericSourceRelations.exclusion n hn g hg hs i (.rank t) hcat
  · exact constant_links _ _ (NumericMixtureRefs.actual n hn g hg hs i) _ _
      (NumericCategoryRows.bit_bound n hn g hs (.rank t) hcat) (NumericValueClosed.config n hn).T _

theorem mux_dom {base:List Row} (c a b:Bit) (z:Net base):
    let j:RecordedExpressions.Job:=⟨c,a,b,(AND [c,a] z).1,(AND [neg c,b] (AND [c,a] z).2).1,(MUX c a b z).1⟩
    NumericLoggedExpressions.JobBound j.q.val.natAbs j:=by
  let y:=AND [c,a] z
  let v:=AND [neg c,b] y.2
  let q:=OR [y.1,v.1] v.2
  have hy:y.1.val.natAbs≤q.1.val.natAbs:=NumericMixtureRefs.input_le_output v.2 _ y.1 (by simp)
  have hv:v.1.val.natAbs≤q.1.val.natAbs:=NumericMixtureRefs.input_le_output v.2 _ v.1 (by simp)
  have hc:c.val.natAbs≤y.1.val.natAbs:=NumericMixtureRefs.input_le_output z _ c (by simp)
  have ha:a.val.natAbs≤y.1.val.natAbs:=NumericMixtureRefs.input_le_output z _ a (by simp)
  have hb:b.val.natAbs≤v.1.val.natAbs:=NumericMixtureRefs.input_le_output y.2 _ b (by simp)
  exact ⟨hc.trans hy,ha.trans hy,hb.trans hv,hy,hv,le_rfl⟩

theorem mux_actual (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1))):NumericLoggedExpressions.JobBound (NumericValueClosed.bound n) (SourceMuxSnapshots.actual n hn g i):=by
  have hq:BitBound (NumericValueClosed.bound n) (SourceMuxSnapshots.actual n hn g i).q:=by
    rw[SourceMuxSnapshots.output_binding]
    exact (NumericMixtureRefs.actual n hn g hg hs i).2.2.2.1
  apply NumericLoggedExpressions.job_mono hq
  exact mux_dom _ _ _ _

theorem result (n:Nat) (hn:2≤n):RowSupport.Bounded (NumericValueClosed.bound n) (SourceAuxBank.result n hn):=by
  apply RowSupport.append _ _ _ (NumericSourceRelations.unit_result n hn)
  intro R hR;obtain ⟨j,hj,hR⟩:=List.mem_flatMap.mp hR
  have h:=SourceAuxBank.valid n j hj
  cases j with
  | rank g i t=>exact rank n hn g h.1 h.2.1 i t h.2.2 R hR
  | mux g i=>exact NumericAliasRelationRows.expression_job _ _ (mux_actual n hn g h.1 h.2 i) R hR
#print axioms result
end L3Emitter.NumericAuxRows

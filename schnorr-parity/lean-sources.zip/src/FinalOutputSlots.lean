import FinalOutputRecorded
import LoggedMembership
import FinalOutputProjection
namespace L3Emitter.FinalOutputSlots
open EREF EREF.GeneralRED REDWitness AliasNetwork RecordedExpressions RecordedExpressionRun
open FinalOutputDefinitions
variable {base:List Row}
attribute [local irreducible] FinalOutputDefinitions.construction tabulate FinalOutputDefinitions.selector FinalOutputDefinitions.out FinalOutputDefinitions.port FinalOutputDefinitions.function

def outs (n:Nat) (hn:2≤n) (z:Net base):=(tabulate (T n) (out n hn) z)
def selectorStart (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (i:Fin (W n-1)):=
  CoordinateSnapshots.before (W n-1) (FinalOutputDefinitions.selector n hn p)
    (CoordinateSnapshots.before 2 (fun p=>tabulate (W n-1) (FinalOutputDefinitions.selector n hn p)) (outs n hn z).2 p) i

def alternative (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)):Bit:=
  if p.val=0 then source n hn (coord n i) else if i.val=0 then (PrimaryAliasBank.cfg n hn).T else (PrimaryAliasBank.cfg n hn).F

def selectorJob (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (i:Fin (W n-1)):=
  LookupEvaluation.job (H n hn) (LowerTransferImage.wire n hn (.sel (lastRank n) p.val i.val))
    (alternative n hn p i) (selectorStart n hn z p i)

theorem selector_member (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (i:Fin (W n-1)):
    selectorJob n hn z p i∈(FinalOutputRecorded.construction n hn z).1.2:=by
  unfold FinalOutputRecorded.construction
  apply LoggedMembership.bind_right
  apply LoggedMembership.bind_left
  apply LoggedMembership.tabulate_at 2
  apply LoggedMembership.tabulate_at (W n-1)
  have hstate:
    CoordinateSnapshots.before (W n-1) (fun i=>forget (FinalOutputRecorded.selector n hn p i))
      (CoordinateSnapshots.before 2 (fun p=>forget (tabulateLog (W n-1) (FinalOutputRecorded.selector n hn p)))
        (outs n hn z).2 p) i=selectorStart n hn z p i:=by
    simp only [tabulate_binding,FinalOutputRecorded.selector_binding,selectorStart]
  change selectorJob n hn z p i∈(FinalOutputRecorded.selector n hn p i _).1.2
  simp only [RecordedExpressions.lift] at *
  change selectorJob n hn z p i∈(FinalOutputRecorded.selector n hn p i
    (CoordinateSnapshots.before (W n-1) (fun i=>forget (FinalOutputRecorded.selector n hn p i))
      (CoordinateSnapshots.before 2 (fun p=>forget (tabulateLog (W n-1) (FinalOutputRecorded.selector n hn p))) (outs n hn z).2 p) i)).1.2
  rw [hstate]
  exact List.mem_singleton_self _

theorem selector_value (n:Nat) (hn:2≤n) (z:Net base) (p:Fin 2) (i:Fin (W n-1)):
    (selectorJob n hn z p i).q=(FinalOutputDefinitions.construction n hn z).1.sels p i:=by
  have hp:=CoordinateSnapshots.tabulate_at 2
    (fun p=>tabulate (W n-1) (FinalOutputDefinitions.selector n hn p)) (outs n hn z).2 p
  have hi:=CoordinateSnapshots.tabulate_at (W n-1) (FinalOutputDefinitions.selector n hn p)
    (CoordinateSnapshots.before 2 (fun p=>tabulate (W n-1) (FinalOutputDefinitions.selector n hn p)) (outs n hn z).2 p) i
  rw [FinalOutputProjection.selectors]
  simpa only [selectorJob,selectorStart,FinalOutputDefinitions.selector,alternative,outs,LookupEvaluation.job] using ((congrFun hp i).trans hi).symm

theorem selector_rows (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)):
    let q:=(FinalOutputDefinitions.built n hn).1.sels p i
    let a:=LowerTransferImage.wire n hn (.sel (lastRank n) p.val i.val)
    let b:=alternative n hn p i
    clause [-(H n hn).val,-a.val,q.val]∈FinalOutputRecorded.result n hn ∧
    clause [-(H n hn).val,-q.val,a.val]∈FinalOutputRecorded.result n hn ∧
    clause [(H n hn).val,-b.val,q.val]∈FinalOutputRecorded.result n hn ∧
    clause [(H n hn).val,-q.val,b.val]∈FinalOutputRecorded.result n hn:=by
  let j:=selectorJob n hn (initialNet n hn) p i
  have hj:j∈FinalOutputRecorded.jobs n hn:=selector_member n hn (initialNet n hn) p i
  have hq:j.q=(FinalOutputDefinitions.built n hn).1.sels p i:=by
    rw [FinalOutputDefinitions.built]
    exact selector_value n hn (initialNet n hn) p i
  have present:∀R∈RecordedExpressions.jobRows j,R∈FinalOutputRecorded.result n hn:=
    fun R hr=>List.mem_append_right _ (List.mem_flatMap.mpr ⟨j,hj,hr⟩)
  have h0:=present _ (List.mem_cons_self : clause [-j.c.val,-j.a.val,j.q.val]∈RecordedExpressions.jobRows j)
  have h1:=present (clause [-j.c.val,-j.q.val,j.a.val]) (List.mem_cons_of_mem _ (List.mem_cons_self))
  have h2:=present (clause [j.c.val,-j.b.val,j.q.val]) (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self)))
  have h3:=present (clause [j.c.val,-j.q.val,j.b.val]) (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_singleton_self _))))
  rw [hq] at h0 h1 h2 h3
  exact ⟨h0,h1,h2,h3⟩
#print axioms selector_value
#print axioms selector_rows
end L3Emitter.FinalOutputSlots

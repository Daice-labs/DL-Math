import AliasSerialization

namespace L3Emitter.ConcreteGateRows
open EREF EREF.GeneralRED REDWitness AliasNetwork
variable {base : List Row}

theorem fresh_rows (z : Net base) (b : Bool) (xs : List Bit) :
    ∀R∈(freshGate z b xs).rows,R∈(gate b xs z).2.rows := by
  intro R hr
  change R∈(push z b xs).rows
  rw [rows_push]
  exact List.mem_append_right _ hr

theorem and_up (z : Net base) (a b : Bit) :
    clause [-a.val,-b.val,(AND [a,b] z).1.val]∈(AND [a,b] z).2.rows := by
  apply fresh_rows z true [a,b]
  apply List.mem_map.mpr
  exact ⟨⟨[-a.val,-b.val],true⟩,List.mem_append_right _ (List.mem_singleton_self _),rfl⟩

theorem and_down (z : Net base) (xs : List Bit) (a : Bit) (ha : a∈xs) :
    clause [-(AND xs z).1.val,a.val]∈(AND xs z).2.rows := by
  have hr : clause [a.val,-(AND xs z).1.val]∈(AND xs z).2.rows := by
    apply fresh_rows z true xs
    apply List.mem_map.mpr
    refine ⟨⟨[a.val],false⟩,?_,?_⟩
    · exact List.mem_append_left _ (List.mem_map.mpr ⟨a.val,List.mem_map.mpr ⟨a,ha,rfl⟩,rfl⟩)
    · rfl
  rw [PriorityExclusive.clause_swap _ _ a.property (neg_ne_zero.mpr (AND xs z).1.property)] at hr
  exact hr

theorem or_up (z : Net base) (xs : List Bit) (a : Bit) (ha : a∈xs) :
    clause [-a.val,(OR xs z).1.val]∈(OR xs z).2.rows := by
  apply fresh_rows z false xs
  apply List.mem_map.mpr
  refine ⟨⟨[-a.val],true⟩,?_,rfl⟩
  exact List.mem_append_left _ (List.mem_map.mpr ⟨a.val,List.mem_map.mpr ⟨a,ha,rfl⟩,rfl⟩)

theorem or_down (z : Net base) (xs : List Bit) :
    clause (xs.map Subtype.val++[-(OR xs z).1.val])∈(OR xs z).2.rows := by
  apply fresh_rows z false xs
  apply List.mem_map.mpr
  exact ⟨⟨xs.map Subtype.val,false⟩,List.mem_append_right _ (List.mem_singleton_self _),rfl⟩

#print axioms and_up
#print axioms and_down
#print axioms or_up
#print axioms or_down
end L3Emitter.ConcreteGateRows

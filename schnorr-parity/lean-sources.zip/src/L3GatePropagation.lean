import L3FinalChains
import L3FrontendT2

namespace L3
open EREF EREF.GeneralRED
namespace Fam
variable (F : Fam)

def gateStepLeaf (g x y a cb live v : Nat) (u0 u1 w0 w1 pol : Bool) : List Int :=
  [(a : Int),-(cb : Int),-(live : Int),(v : Int),
    if u0 then -(F.port g 0 x : Int) else (F.port g 0 x : Int),
    if w0 then -(F.port g 0 y : Int) else (F.port g 0 y : Int),
    if u1 then -(F.port g 1 x : Int) else (F.port g 1 x : Int),
    if w1 then -(F.port g 1 y : Int) else (F.port g 1 y : Int),
    if pol then -(F.val g x : Int) else (F.val g x : Int)]

def changedPortRows (g p x y a cb live peq force entryFrom entryTo : Nat) (u pol : Bool) : List Row :=
  [gateRow [if u then -(F.port g p x : Int) else (F.port g p x : Int),
            if u then (F.port g p y : Int) else -(F.port g p y : Int)] peq false,
   clauseRow [(a : Int),-(cb : Int),-(live : Int),(F.sel g p 0 : Int),(peq : Int)],
   clauseRow [(a : Int),-(live : Int),-(F.sel g p 0 : Int),-(force : Int)],
   clauseRow [(force : Int),if pol then -(F.fn g entryFrom : Int) else (F.fn g entryFrom : Int),
     if pol then (F.fn g entryTo : Int) else -(F.fn g entryTo : Int)]]

def gateStepRows (g x y a cb live v q0 q1 f0 f1 : Nat)
    (u0 u1 w0 w1 pol : Bool) : List Row :=
  [F.row4P pol g x u0.toNat u1.toNat,
   F.row4P (!pol) g y w0.toNat w1.toNat,
   gateRow [if pol then -(F.val g x : Int) else (F.val g x : Int),
            if pol then -(F.val g y : Int) else (F.val g y : Int)] v true] ++
  (if u0=w0 then [] else F.changedPortRows g 0 x y a cb live q0 f0
    (2*u0.toNat+u1.toNat) (2*w0.toNat+u1.toNat) u0 pol) ++
  (if u1=w1 then [] else F.changedPortRows g 1 x y a cb live q1 f1
    (2*w0.toNat+u1.toNat) (2*w0.toNat+w1.toNat) u1 pol)

/-- T5e: a fixed POL chain for every one of the 32 gate-propagation leaves.
    The rows are explicitly named: two gate rows, one output EQ row, and
    at most four rows for each changed input port (including its stage-4 clause).
    No RUP-search-success premise is used. -/
theorem gate_propagation_leaf (g x y a cb live v q0 q1 f0 f1 : Nat)
    (u0 u1 w0 w1 pol : Bool)
    (ha : 1≤a) (hcb : 1≤cb) (hl : 1≤live) (hv : 1≤v)
    (hq0 : 1≤q0) (hq1 : 1≤q1) (hf0 : 1≤f0) (hf1 : 1≤f1)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hm : All (fun r => r.toE∈D) (F.gateStepRows g x y a cb live v q0 q1 f0 f1 u0 u1 w0 w1 pol)) :
    Refutation (D ++ [negate (clauseRow (F.gateStepLeaf g x y a cb live v u0 u1 w0 w1 pol)).toE]) := by
  have hp0x := F.port_pos g 0 x
  have hp0y := F.port_pos g 0 y
  have hp1x := F.port_pos g 1 x
  have hp1y := F.port_pos g 1 y
  have hvx := F.val_pos g x
  have hvy := F.val_pos g y
  have hs0 := F.sel_pos g 0 0
  have hs1 := F.sel_pos g 1 0
  have hn0 := F.fn_pos g 0
  have hn1 := F.fn_pos g 1
  have hn2 := F.fn_pos g 2
  have hn3 := F.fn_pos g 3
  apply weighted_clause_chain D _ 5 _ hD
  · cases u0 <;> cases u1 <;> cases w0 <;> cases w1 <;> cases pol <;>
      simp only [gateStepLeaf,Bool.false_eq_true,↓reduceIte] <;> nz_lits
  · exact hm
  · cases u0 <;> cases u1 <;> cases w0 <;> cases w1 <;> cases pol <;>
      simp only [gateStepRows,changedPortRows,row4P,row4,row4',m1,m2,
        Bool.toNat,Bool.cond_false,Bool.cond_true,Nat.reduceAdd,Nat.reduceMul,Bool.not_false,Bool.not_true,Bool.false_eq_true,Bool.true_eq_false,
        ↓reduceIte, List.cons_append,List.nil_append,List.append_nil,All]
    all_goals repeat' first | apply And.intro | exact True.intro
    all_goals nz_lits
  · intro α
    cases u0 <;> cases u1 <;> cases w0 <;> cases w1 <;> cases pol <;>
      simp [gateStepRows,changedPortRows,gateStepLeaf,row4P,row4,row4',m1,m2,
        gateRow,clauseRow,pos,neg,lsum_cons,lsum_nil,lsum_append] <;> lv_omega

#print axioms gate_propagation_leaf
end Fam
end L3

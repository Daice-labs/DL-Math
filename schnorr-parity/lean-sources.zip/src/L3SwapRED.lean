/-
The first- and right-selector normalization RED steps of frontend.py:

    for j in range(1,F.k): p.red([-F.sel(0,0,j)], swap(F,0,j))     -- loop 1
    for j in range(2,F.k): p.red([-F.sel(0,1,j)], swap(F,1,j))     -- loop 2

as `CheckedStep`s of the semantic calculus of EREF_CertifiedTrace, against the exact
evolving database (all original rows, then the units derived so far), for every k ≥ 2
and every s ≥ 1, under the one hypothesis that the target table is invariant under the
input-wire swaps (discharged for the parity table in L3Parity.lean).

Every RED obligation is discharged by an explicit POL certificate:
* an old row whose substituted image is an existing database row: `old_certificate`;
* the candidate: AMO(0,p) + ¬C + ¬(C|ω) is syntactically contradictory (`cand_certificate`).
-/
import L3SwapImages
import EREF_CertifiedTrace

namespace L3
open EREF EREF.GeneralRED

/-! ### Database id lemmas and the old-row certificate (transcribed from REDWitness.lean,
which cannot be imported here because it depends on Mathlib through Serialization.lean) -/

theorem db_neg_left (rows : List EREF.Row) (C G : EREF.Row) :
    dbOf (rows ++ [negate C, negate G]) (rows.length+1) = some (negate C) := by
  simp [dbOf]

theorem db_neg_right (rows : List EREF.Row) (C G : EREF.Row) :
    dbOf (rows ++ [negate C, negate G]) (rows.length+2) = some (negate G) := by
  simp [dbOf, List.getElem?_append]

theorem db_old (rows : List EREF.Row) (C G : EREF.Row) (i : Nat) (hi : i < rows.length) :
    dbOf (rows ++ [negate C, negate G]) (i+1) = some rows[i] := by
  simp [dbOf, hi, List.getElem?_append]

/-- An unchanged old row has the explicit POL contradiction R + not-R. -/
theorem old_certificate (rows : List EREF.Row) (C : EREF.Row) (i : Nat) (hi : i < rows.length)
    (hR : Canonical rows[i]) : LocalCertificate rows C rows[i] := by
  refine ⟨[.ref (i+1),.ref (rows.length+2),.add], add rows[i] (negate rows[i]), ?_, ?_⟩
  · simp [polEval, db_old rows C rows[i] i hi, db_neg_right]
  · apply (canonical_contra_iff _ (canonical_add _ _)).mpr
    intro α hs
    have hv := val_add rows[i] (negate rows[i]) hR (canonical_negate _) α
    rw [val_negate _ hR] at hv
    unfold Row.sat at hs
    omega

/-! ### Bridge: L3 rows as exact-checker rows -/

/-- the exact-checker row of an L3 row: unit coefficients, normalized -/
def Row.toE (r : Row) : EREF.Row := normalize (r.lits.map fun l => (1, l)) r.rhs

theorem canonical_toE (r : Row) : Canonical r.toE := canonical_normalize _ _

def Row.nz (r : Row) : Prop := ∀ l ∈ r.lits, l ≠ 0

theorem tvalZ_units (α : Val) (xs : List Int) :
    tvalZ α (xs.map fun l => ((1 : Int), l)) = lsum α xs := by
  induction xs with
  | nil => simp [tvalZ, lsum]
  | cons x xs ih =>
    simp only [List.map_cons, tvalZ, Int.one_mul, lsum_cons, lv_eq_litVal, ih]

theorem val_toE (r : Row) (hz : r.nz) (α : Val) : (r.toE).val α = lsum α r.lits - r.rhs := by
  unfold Row.toE
  rw [val_normalize]
  · rw [tvalZ_units]
  · intro t ht
    obtain ⟨l, hl, rfl⟩ := List.mem_map.mp ht
    exact hz l hl

theorem toE_of_equiv (r r' : Row) (hz : r.nz) (hz' : r'.nz) (h : r.equiv r') : r.toE = r'.toE := by
  apply canonical_ext _ _ (canonical_toE r) (canonical_toE r')
  intro α
  rw [val_toE r hz, val_toE r' hz', h.1, h.2 α]

/-- a well-formed row (ids in 1..V) has no zero literal -/
theorem nz_of_wf (r : Row) (V : Nat) (h : r.wf V) : r.nz := by
  intro l hl
  have := (h l hl).1
  omega

/-! ### Permutation witnesses -/

/-- the witness of an id map σ (σ v ≠ 0 on every id in use) -/
def permWitness (σ : Nat → Nat) : Witness := fun v =>
  if h : ((σ v : Nat) : Int) ≠ 0 then .literal (σ v) h else .constant false

theorem applyWitness_perm (σ : Nat → Nat) (α : Val) (v : Nat) (hv : 1 ≤ σ v) :
    applyWitness (permWitness σ) α v = α (σ v) := by
  unfold applyWitness permWitness
  split
  · simp only [Image.eval]
    have : (0 : Int) < (σ v : Nat) := by omega
    have h0 : ¬ σ v = 0 := by omega
    simp [this, h0]
  · rename_i h; exact absurd (by omega) h

theorem lv_image (σ : Nat → Nat) (α : Val) (l : Int) (hv : 1 ≤ σ l.natAbs) :
    lv (applyWitness (permWitness σ) α) l = lv α (mapLit σ l) := by
  unfold lv mapLit
  rw [applyWitness_perm σ α l.natAbs hv]
  have h0 : ¬ σ l.natAbs = 0 := by omega
  split
  · have : (0 : Int) < (σ l.natAbs : Nat) := by omega
    simp [this, h0]
  · have : ¬ (0 : Int) < -((σ l.natAbs : Nat) : Int) := by omega
    have h1 : ¬ ((σ l.natAbs : Nat) : Int) < 0 := by omega
    simp [this, h0, h1]

theorem lsum_image (σ : Nat → Nat) (α : Val) (xs : List Int) (hv : ∀ l ∈ xs, 1 ≤ σ l.natAbs) :
    lsum (applyWitness (permWitness σ) α) xs = lsum α (xs.map (mapLit σ)) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    simp only [lsum_cons, List.map_cons]
    rw [lv_image σ α x (hv x (by simp)), ih (fun l hl => hv l (by simp [hl]))]

/-- a row with nonzero literals keeps nonzero literals under a positive id map -/
theorem nz_imageRow (σ : Nat → Nat) (r : Row) (hv : ∀ l ∈ r.lits, 1 ≤ σ l.natAbs) :
    (imageRow σ r).nz := by
  intro l hl
  obtain ⟨l', hl', rfl⟩ := List.mem_map.mp hl
  have := hv l' hl'
  unfold mapLit; split <;> omega

/-- **substitution commutes with the bridge**: the exact-checker substitution of r.toE
    under the permutation witness is the bridge of the literal-wise image of r -/
theorem substRow_toE (σ : Nat → Nat) (r : Row) (hz : r.nz) (hv : ∀ l ∈ r.lits, 1 ≤ σ l.natAbs) :
    substRow r.toE (permWitness σ) = (imageRow σ r).toE := by
  apply canonical_ext _ _ (canonical_substRow _ _) (canonical_toE _)
  intro α
  rw [val_substRow, val_toE r hz, val_toE _ (nz_imageRow σ r hv)]
  unfold imageRow
  simp only
  rw [lsum_image σ α r.lits hv]

/-! ### Generic permutation RED step -/

/-- An old row is covered when its substituted image is already in the database. -/
theorem refutation_of_mem (D : List EREF.Row) (C G : EREF.Row) (hD : ∀ R ∈ D, Canonical R)
    (hG : G ∈ D) : Refutation (D ++ [negate C, negate G]) := by
  obtain ⟨i, hi, rfl⟩ := List.mem_iff_getElem.mp hG
  exact single_to_refutation D C D[i] (old_certificate D C i hi (hD _ (List.getElem_mem hi)))

/-- A RED step whose witness maps every database row to a database row needs only the
    candidate's own obligation. -/
theorem checkedStep_red_perm (D : List EREF.Row) (C : EREF.Row) (ω : Witness)
    (hD : ∀ R ∈ D, Canonical R) (hC : Canonical C)
    (hclosed : ∀ R ∈ D, substRow R ω ∈ D)
    (hcand : Refutation (D ++ [negate C, negate (substRow C ω)])) :
    CheckedStep D (D ++ [C]) := by
  apply CheckedStep.red D C ω hC
  intro R hR
  rcases List.mem_cons.mp hR with rfl | hR
  · exact hcand
  · exact refutation_of_mem D C _ hD (hclosed R hR)

/-! ### Bounded sums for the candidate certificate -/

theorem sumR_le (n : Nat) (g : Nat → Int) (hle : ∀ j, j < n → g j ≤ 1) : sumR n g ≤ n := by
  induction n with
  | zero => simp [sumR_zero]
  | succ n ih =>
    rw [sumR_succ]
    have := ih (fun j hj => hle j (by omega))
    have := hle n (by omega)
    push_cast; omega

theorem sumR_le_one (n c : Nat) (g : Nat → Int) (hc : c < n) (hle : ∀ j, j < n → g j ≤ 1) :
    sumR n g ≤ (n : Int) - 1 + g c := by
  induction n with
  | zero => omega
  | succ n ih =>
    rw [sumR_succ]
    by_cases h : n = c
    · subst h
      have := sumR_le n g (fun j hj => hle j (by omega))
      push_cast; omega
    · have := ih (by omega) (fun j hj => hle j (by omega))
      have := hle n (by omega)
      push_cast; omega

theorem sumR_le_two (n a b : Nat) (g : Nat → Int) (ha : a < n) (hb : b < n) (hab : a ≠ b)
    (hle : ∀ j, j < n → g j ≤ 1) : sumR n g ≤ (n : Int) - 2 + g a + g b := by
  induction n with
  | zero => omega
  | succ n ih =>
    rw [sumR_succ]
    by_cases hna : n = a
    · subst hna
      have := sumR_le_one n b g (by omega) (fun j hj => hle j (by omega))
      push_cast; omega
    · by_cases hnb : n = b
      · subst hnb
        have := sumR_le_one n a g (by omega) (fun j hj => hle j (by omega))
        push_cast; omega
      · have := ih (by omega) (by omega) (fun j hj => hle j (by omega))
        have := hle n (by omega)
        push_cast; omega

theorem lv_le_one (α : Val) (l : Int) : lv α l ≤ 1 := by
  unfold lv; split <;> cases α l.natAbs <;> simp [b2i]
theorem lv_nonneg (α : Val) (l : Int) : 0 ≤ lv α l := by
  unfold lv; split <;> cases α l.natAbs <;> simp [b2i]

namespace Fam

/-- the "at most one parent" row of gate 0, port p, as a sum over the k input wires -/
theorem lsum_row1'_zero (F : Fam) (p : Nat) (α : Val) :
    lsum α (F.row1' 0 p).lits = sumR F.k (fun j => lv α (neg (F.sel 0 p j))) := by
  unfold row1'
  simp only [Nat.add_zero, List.map_map]
  rw [lsum_map_range]
  rfl

/-- **Candidate obligation** of `red [¬sel(0,p,j)] ; swap(p-wire a ↔ j)`: with the AMO row of
    (gate 0, port p) in the database, AMO + ¬C + ¬(C|ω) is syntactically contradictory. -/
theorem cand_certificate (F : Fam) (hs : 1 ≤ F.s) (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R)
    (p a j : Nat) (hp : p < 2) (ha : a < F.k) (hj : j < F.k) (haj : a ≠ j)
    (hamo : (F.row1' 0 p).toE ∈ D) :
    Refutation (D ++ [negate (F.unitNegSel p j).toE, negate (F.unitNegSel p a).toE]) := by
  apply single_to_refutation
  obtain ⟨i, hi, hDi⟩ := List.mem_iff_getElem.mp hamo
  refine ⟨[.ref (i + 1), .ref (D.length + 1), .add, .ref (D.length + 2), .add],
    add (add D[i] (negate (F.unitNegSel p j).toE)) (negate (F.unitNegSel p a).toE), ?_, ?_⟩
  · simp [polEval, db_old D _ _ i hi, db_neg_left,
      db_neg_right]
  · apply (canonical_contra_iff _ (canonical_add _ _)).mpr
    intro α hs'
    have hcan_i : Canonical D[i] := hD _ (List.getElem_mem hi)
    have hv := val_add (add D[i] (negate (F.unitNegSel p j).toE)) (negate (F.unitNegSel p a).toE)
      (canonical_add _ _) (canonical_negate _) α
    rw [val_add _ _ hcan_i (canonical_negate _), val_negate _ (canonical_toE _),
      val_negate _ (canonical_toE _)] at hv
    have hwf1 : (F.row1' 0 p).nz := nz_of_wf _ F.V (F.rows_wf hs _ (F.row1'_mem 0 p hs hp))
    have hwfC : (F.unitNegSel p j).nz := by
      intro l hl; simp [unitNegSel] at hl; subst hl; have := F.sel_pos 0 p j; unfold neg; omega
    have hwfG : (F.unitNegSel p a).nz := by
      intro l hl; simp [unitNegSel] at hl; subst hl; have := F.sel_pos 0 p a; unfold neg; omega
    have hDv : D[i].val α = lsum α (F.row1' 0 p).lits - (F.row1' 0 p).rhs := by
      rw [hDi, val_toE _ hwf1]
    rw [hDv, val_toE _ hwfC, val_toE _ hwfG, lsum_row1'_zero] at hv
    have hk : 1 ≤ F.k := by omega
    have hr : ((F.row1' 0 p).rhs : Int) = (F.k : Int) - 1 := by simp [row1']; omega
    rw [hr] at hv
    have hu : ∀ q, lsum α (F.unitNegSel p q).lits = lv α (neg (F.sel 0 p q)) := by
      intro q; simp [unitNegSel]
    have hu' : ∀ q, ((F.unitNegSel p q).rhs : Int) = 1 := by intro q; rfl
    rw [hu, hu, hu', hu'] at hv
    have hb := sumR_le_two F.k a j (fun j' => lv α (neg (F.sel 0 p j'))) ha hj haj
      (fun j' _ => lv_le_one α _)
    simp only at hb
    unfold Row.sat at hs'
    omega

/-! ### The two normalization loops as checked steps -/

/-- loop 1, step j: database = originals ++ units ¬sel(0,0,1..j−1) -/
def db1 (F : Fam) (j : Nat) : List EREF.Row :=
  F.rows.map Row.toE ++ (List.range' 1 (j - 1)).map fun j' => (F.unitNegSel 0 j').toE

/-- loop 2, step j: database = originals ++ all loop-1 units ++ units ¬sel(0,1,2..j−1) -/
def db2 (F : Fam) (j : Nat) : List EREF.Row :=
  F.rows.map Row.toE ++ (List.range' 1 (F.k - 1)).map (fun j' => (F.unitNegSel 0 j').toE)
    ++ (List.range' 2 (j - 2)).map fun j' => (F.unitNegSel 1 j').toE

theorem db1_succ (F : Fam) (j : Nat) (hj : 1 ≤ j) :
    F.db1 (j + 1) = F.db1 j ++ [(F.unitNegSel 0 j).toE] := by
  unfold db1
  have : j + 1 - 1 = (j - 1) + 1 := by omega
  rw [this, List.range'_1_concat, List.map_append, List.append_assoc]
  have : 1 + (j - 1) = j := by omega
  simp [this]

theorem db2_succ (F : Fam) (j : Nat) (hj : 2 ≤ j) :
    F.db2 (j + 1) = F.db2 j ++ [(F.unitNegSel 1 j).toE] := by
  unfold db2
  have : j + 1 - 2 = (j - 2) + 1 := by omega
  rw [this, List.range'_1_concat, List.map_append, List.append_assoc]
  have : 2 + (j - 2) = j := by omega
  simp [this]

theorem db1_one (F : Fam) : F.db1 1 = F.rows.map Row.toE := by simp [db1]
theorem db2_two (F : Fam) : F.db2 2 = F.db1 F.k := by simp [db2, db1]

theorem canonical_db (D : List EREF.Row) (h : ∀ R ∈ D, ∃ r : Row, R = r.toE) : ∀ R ∈ D, Canonical R := by
  intro R hR; obtain ⟨r, rfl⟩ := h R hR; exact canonical_toE r

theorem db1_shape (F : Fam) (j : Nat) : ∀ R ∈ F.db1 j, ∃ r : Row, R = r.toE := by
  intro R hR
  unfold db1 at hR
  simp only [List.mem_append, List.mem_map] at hR
  rcases hR with ⟨r, _, rfl⟩ | ⟨j', _, rfl⟩
  · exact ⟨r, rfl⟩
  · exact ⟨_, rfl⟩

theorem db2_shape (F : Fam) (j : Nat) : ∀ R ∈ F.db2 j, ∃ r : Row, R = r.toE := by
  intro R hR
  unfold db2 at hR
  simp only [List.mem_append, List.mem_map] at hR
  rcases hR with (⟨r, _, rfl⟩ | ⟨j', _, rfl⟩) | ⟨j', _, rfl⟩
  · exact ⟨r, rfl⟩
  · exact ⟨_, rfl⟩
  · exact ⟨_, rfl⟩

/-- ids of every original row are positive and mapped to positive ids by σ -/
theorem rows_sigma_pos (F : Fam) (hs : 1 ≤ F.s) (a b : Nat) (r : Row) (hr : r ∈ F.rows) :
    ∀ l ∈ r.lits, 1 ≤ F.swapId a b l.natAbs := by
  intro l hl
  exact F.swapId_pos a b _ (F.rows_wf hs r hr l hl).1

theorem unit_nz (F : Fam) (p j : Nat) : (F.unitNegSel p j).nz := by
  intro l hl; simp [unitNegSel] at hl; subst hl; have := F.sel_pos 0 p j; unfold neg; omega

theorem unit_sigma_pos (F : Fam) (a b p j : Nat) : ∀ l ∈ (F.unitNegSel p j).lits, 1 ≤ F.swapId a b l.natAbs := by
  intro l hl; simp [unitNegSel] at hl; subst hl
  exact F.swapId_pos a b _ (by have := F.sel_pos 0 p j; unfold neg; simp; omega)

/-- substituted image of an original row under swap(a,b) is (the bridge of) an original row -/
theorem subst_original (F : Fam) (hs : 1 ≤ F.s) (a b : Nat) (ha : a < F.k) (hb : b < F.k) (hab : a ≠ b)
    (hinv : ∀ x, x < F.T → F.b (F.xm a b x) = F.b x) (r : Row) (hr : r ∈ F.rows) :
    ∃ r' ∈ F.rows, substRow r.toE (permWitness (F.swapId a b)) = r'.toE := by
  obtain ⟨r', hr', heq⟩ := F.image_rows a b ha hb hab hs hinv r hr
  refine ⟨r', hr', ?_⟩
  rw [substRow_toE _ r (nz_of_wf r F.V (F.rows_wf hs r hr)) (F.rows_sigma_pos hs a b r hr)]
  exact toE_of_equiv _ _ (nz_imageRow _ r (F.rows_sigma_pos hs a b r hr))
    (nz_of_wf r' F.V (F.rows_wf hs r' hr')) heq

theorem subst_unit (F : Fam) (hs : 1 ≤ F.s) (a b p j : Nat) (hp : p < 2) (hj : j < F.k) :
    substRow (F.unitNegSel p j).toE (permWitness (F.swapId a b)) = (F.unitNegSel p (jmap a b j)).toE := by
  rw [substRow_toE _ _ (F.unit_nz p j) (F.unit_sigma_pos a b p j), F.image_unitNegSel a b p j hs hp hj]

/-- **Loop 1, step j** (`p.red([-F.sel(0,0,j)], swap(F,0,j))`, 1 ≤ j < k) is a checked RED step
    against the exact database of that moment. -/
theorem step1 (F : Fam) (hs : 1 ≤ F.s) (j : Nat) (hj1 : 1 ≤ j) (hjk : j < F.k)
    (hinv : ∀ x, x < F.T → F.b (F.xm 0 j x) = F.b x) :
    CheckedStep (F.db1 j) (F.db1 (j + 1)) := by
  rw [F.db1_succ j hj1]
  have hk : 0 < F.k := by omega
  apply checkedStep_red_perm (F.db1 j) _ (permWitness (F.swapId 0 j))
    (canonical_db _ (F.db1_shape j)) (canonical_toE _)
  · intro R hR
    unfold db1 at hR ⊢
    simp only [List.mem_append, List.mem_map, List.mem_range'_1] at hR ⊢
    rcases hR with ⟨r, hr, rfl⟩ | ⟨j', hj', rfl⟩
    · obtain ⟨r', hr', heq⟩ := F.subst_original hs 0 j hk hjk (by omega) hinv r hr
      exact Or.inl ⟨r', hr', heq.symm⟩
    · rw [F.subst_unit hs 0 j 0 j' (by omega) (by omega), Fam.jmap_other 0 j j' (by omega) (by omega)]
      exact Or.inr ⟨j', hj', rfl⟩
  · rw [F.subst_unit hs 0 j 0 j (by omega) hjk, Fam.jmap_b]
    apply F.cand_certificate hs _ (canonical_db _ (F.db1_shape j)) 0 0 j (by omega) hk hjk (by omega)
    unfold db1
    exact List.mem_append_left _ (List.mem_map.mpr ⟨_, F.row1'_mem 0 0 hs (by omega), rfl⟩)

/-- **Loop 2, step j** (`p.red([-F.sel(0,1,j)], swap(F,1,j))`, 2 ≤ j < k). -/
theorem step2 (F : Fam) (hs : 1 ≤ F.s) (j : Nat) (hj2 : 2 ≤ j) (hjk : j < F.k)
    (hinv : ∀ x, x < F.T → F.b (F.xm 1 j x) = F.b x) :
    CheckedStep (F.db2 j) (F.db2 (j + 1)) := by
  rw [F.db2_succ j hj2]
  have hk : 1 < F.k := by omega
  apply checkedStep_red_perm (F.db2 j) _ (permWitness (F.swapId 1 j))
    (canonical_db _ (F.db2_shape j)) (canonical_toE _)
  · intro R hR
    unfold db2 at hR ⊢
    simp only [List.mem_append, List.mem_map, List.mem_range'_1] at hR ⊢
    rcases hR with (⟨r, hr, rfl⟩ | ⟨j', hj', rfl⟩) | ⟨j', hj', rfl⟩
    · obtain ⟨r', hr', heq⟩ := F.subst_original hs 1 j hk hjk (by omega) hinv r hr
      exact Or.inl (Or.inl ⟨r', hr', heq.symm⟩)
    · rw [F.subst_unit hs 1 j 0 j' (by omega) (by omega)]
      refine Or.inl (Or.inr ⟨jmap 1 j j', ?_, rfl⟩)
      unfold jmap; split <;> (try split) <;> omega
    · rw [F.subst_unit hs 1 j 1 j' (by omega) (by omega), Fam.jmap_other 1 j j' (by omega) (by omega)]
      exact Or.inr ⟨j', hj', rfl⟩
  · rw [F.subst_unit hs 1 j 1 j (by omega) hjk, Fam.jmap_b]
    apply F.cand_certificate hs _ (canonical_db _ (F.db2_shape j)) 1 1 j (by omega) hk hjk (by omega)
    unfold db2
    exact List.mem_append_left _ (List.mem_append_left _
      (List.mem_map.mpr ⟨_, F.row1'_mem 0 1 hs (by omega), rfl⟩))

/-! ### Composing the loops into one trace -/

theorem checkedTrace_trans {a b c : List EREF.Row} (h1 : CheckedTrace a b) (h2 : CheckedTrace b c) :
    CheckedTrace a c := by
  induction h1 with
  | refl => exact h2
  | cons step _ ih => exact CheckedTrace.cons step (ih h2)

theorem trace1 (F : Fam) (hs : 1 ≤ F.s)
    (hinv : ∀ j, 1 ≤ j → j < F.k → ∀ x, x < F.T → F.b (F.xm 0 j x) = F.b x) :
    ∀ m, 1 + m ≤ F.k → CheckedTrace (F.db1 1) (F.db1 (1 + m)) := by
  intro m
  induction m with
  | zero => intro _; exact CheckedTrace.refl _
  | succ m ih =>
    intro hm
    have t := ih (by omega)
    have st := F.step1 hs (1 + m) (by omega) (by omega) (hinv (1 + m) (by omega) (by omega))
    have : 1 + (m + 1) = 1 + m + 1 := by omega
    rw [this]
    exact checkedTrace_trans t (CheckedTrace.cons st (CheckedTrace.refl _))

theorem trace2 (F : Fam) (hs : 1 ≤ F.s)
    (hinv : ∀ j, 2 ≤ j → j < F.k → ∀ x, x < F.T → F.b (F.xm 1 j x) = F.b x) :
    ∀ m, 2 + m ≤ F.k → CheckedTrace (F.db2 2) (F.db2 (2 + m)) := by
  intro m
  induction m with
  | zero => intro _; exact CheckedTrace.refl _
  | succ m ih =>
    intro hm
    have t := ih (by omega)
    have st := F.step2 hs (2 + m) (by omega) (by omega) (hinv (2 + m) (by omega) (by omega))
    have : 2 + (m + 1) = 2 + m + 1 := by omega
    rw [this]
    exact checkedTrace_trans t (CheckedTrace.cons st (CheckedTrace.refl _))

/-- **The selector-normalization prefix of frontend.py is a checked trace, for every k ≥ 2 and
    s ≥ 1**: from the original rows to the database holding every unit ¬sel(0,0,j) (1 ≤ j < k)
    and ¬sel(0,1,j) (2 ≤ j < k), under the swap-invariance of the target table. -/
theorem normalization_prefix_trace (F : Fam) (hk : 2 ≤ F.k) (hs : 1 ≤ F.s)
    (hinv : ∀ a j, a < F.k → j < F.k → a ≠ j → ∀ x, x < F.T → F.b (F.xm a j x) = F.b x) :
    CheckedTrace (F.rows.map Row.toE) (F.db2 F.k) := by
  rw [← F.db1_one]
  have t1 := F.trace1 hs (fun j hj1 hjk => hinv 0 j (by omega) hjk (by omega)) (F.k - 1) (by omega)
  have t2 := F.trace2 hs (fun j hj2 hjk => hinv 1 j (by omega) hjk (by omega)) (F.k - 2) (by omega)
  have e1 : 1 + (F.k - 1) = F.k := by omega
  have e2 : 2 + (F.k - 2) = F.k := by omega
  rw [e1] at t1; rw [e2] at t2
  rw [F.db2_two] at t2
  exact checkedTrace_trans t1 t2

end Fam
end L3

#print axioms L3.Fam.normalization_prefix_trace

import GuardActivation
namespace L3Emitter.ActivatedReplay
open EREF EREF.GeneralRED REDWitness GuardedReplay

def frame (upper inputs:List Row) (a:Row→Nat) (q:Nat):List Row:=
  upper++GuardActivation.bank inputs a q++[GuardActivation.unit q]

theorem unit_fixed (q:Nat) (hq:0<q) (ω:Witness)
    (hf:∀α,applyWitness ω α q=α q):
    substRow (GuardActivation.unit q) ω=GuardActivation.unit q:=by
  apply canonical_ext _ _ (canonical_substRow _ _) (GuardActivation.unit_canonical q)
  intro α
  rw [val_substRow,GuardActivation.unit_value q hq,GuardActivation.unit_value q hq]
  simp only [litVal,Int.natAbs_natCast,hf]

theorem frame_canonical (upper inputs:List Row) (a:Row→Nat) (q:Nat)
    (hu:∀R∈upper,Canonical R):∀R∈frame upper inputs a q,Canonical R:=by
  intro R hr
  rcases List.mem_append.mp hr with hr|hr
  · exact GuardedReplay.frame_canonical upper inputs a (-(q:Int)) hu R hr
  · obtain rfl:=List.mem_singleton.mp hr
    exact GuardActivation.unit_canonical q

/-- The activation unit is retained and discharged explicitly. It is above
the upper namespace, so a below-M frame bound alone would not cover it. -/
theorem one_copy {M q:Nat} {D E:List Row} {m:Nat}
    (h:Scoped M (-(q:Int)) D E m) (hq:0<q)
    (upper inputs:List Row) (a:Row→Nat)
    (hu:RowSupport.Bounded M upper) (hi:∀R∈inputs,Canonical R)
    (ha:∀R∈inputs,0<a R) (hin:∀R∈inputs,R∈D):
    Counted (frame upper inputs a q++D) (frame upper inputs a q++E) m:=by
  induction h with
  | refl=>exact .refl _
  | @pol D E m C ts he tail ih=>
    obtain ⟨ts',he',_⟩:=ReferenceTransport.eval_subset D (frame upper inputs a q++D)
      (fun R hr=>List.mem_append_right _ hr) ts C he
    have s:=CheckedStep.pol (frame upper inputs a q++D) C ts' he'
    exact .cons (by simpa only [List.append_assoc] using s)
      (ih (fun R hr=>List.mem_append_left _ (hin R hr)))
  | @consequence D E m C hc cert tail ih=>
    have cert':Refutation ((frame upper inputs a q++D)++[negate C]):=by
      apply ReferenceTransport.refutation_subset _ _ _ cert
      intro R hr
      rcases List.mem_append.mp hr with hr|hr
      · exact List.mem_append_left _ (List.mem_append_right _ hr)
      · exact List.mem_append_right _ hr
    have s:=CheckedStep.consequence (frame upper inputs a q++D) C hc cert'
    exact .cons (by simpa only [List.append_assoc] using s)
      (ih (fun R hr=>List.mem_append_left _ (hin R hr)))
  | @red D E m C ω hc ho hm hguard tail ih=>
    have hclass:=GuardedFrame.guard_class D upper inputs a (-(q:Int)) ω hi ha
      (by omega) hin (REDFrame.bounded_fixed ω M upper hm hu) hguard
    have s:=GuardedFrame.lift D (frame upper inputs a q) C ω hc ho
      (frame_canonical upper inputs a q (fun R hr=>(hu R hr).1)) (by
        intro G hg
        rcases List.mem_append.mp hg with hg|hg
        · exact hclass G hg
        · obtain rfl:=List.mem_singleton.mp hg
          exact Or.inl (unit_fixed q hq ω (by simpa using hguard)))
    exact .cons s (ih (fun R hr=>List.mem_append_left _ (hin R hr)))

#print axioms one_copy
end L3Emitter.ActivatedReplay

import NumericCoveragePort
namespace L3Emitter.NumericCoverageGate
open EREF EREF.GeneralRED L3 L3.Fam StI RecordedScopedTrace RecordedOperandFields FieldLengthsFromIDs

theorem finish (M:Nat) (F:Fam) (hk:2≤F.k) (hs:1≤F.s) (hm:1≤F.V)
 (bit cb g:Nat) (u:StI F.V) (hu:F.Good3 u) (hb:bit<2) (hg:g<F.s)
 (hc:1≤cb ∧ cb≤u.s.var) (hv:1≤u.s.veq g bit ∧ u.s.veq g bit≤u.s.var)
 (hr:∀h<g,F.GateRecord bit cb h u)
 (hbudget:NumericFrontendBudget.Bound M (F.veqFinish hm bit cb g u)):
 ∀c∈RecordedGateStep.finish F hm bit cb g u,Content M c:=by
 have hU:=NumericFrontendBudget.mono (F.veqFinish_keeps hm bit cb g u).1 hbudget
 have hM:82≤M:=by have:=hU.2;omega
 by_cases hg0:g=0
 · subst g
   simpa only[RecordedGateStep.finish,↓reduceIte] using
     NumericCoverageLeaves.first M F hk hs u hu bit cb hb hc hv hM hU.1 (exec F.db5 u.s.cmds)
 · let u0:=F.portEqStep hm g bit cb u 0
   let u1:=F.portEqStep hm g bit cb u0 1
   have k0:Keeps2 u u0:=F.keeps2_portEqStep hm g bit cb u 0
   have k1:Keeps2 u0 u1:=F.keeps2_portEqStep hm g bit cb u0 1
   have k2:=keeps2_trans k0 k1
   have v0:u0.s.veq=u.s.veq:=F.portEqStep_veq hm g bit cb u 0
   have v1:u1.s.veq=u0.s.veq:=F.portEqStep_veq hm g bit cb u0 1
   have v2:u1.s.veq=u.s.veq:=v1.trans v0
   have root:F.gateRoot u1 bit cb g=F.gateRoot u bit cb g:=by
     simp only[gateRoot,v2,k2.2.1.1,k2.2.2.2.2.2]
   have fin:F.veqFinish hm bit cb g u=u1.split (F.gateRoot u1 bit cb g) (F.gateVs bit g):=by
     simp only[veqFinish,hg0,↓reduceIte,List.foldl_cons,List.foldl_nil,gateVs,root];rfl
   rw[fin] at hbudget
   have hU1:=NumericFrontendBudget.mono (keeps2_split u1 _ _).1 hbudget
   have hU0:=NumericFrontendBudget.mono k1.1 hU1
   have hu0:=F.Good3_of_keeps2 k0 hu
   have hu1:=F.Good3_of_keeps2 k2 hu
   have hc0:1≤cb ∧ cb≤u0.s.var:=⟨hc.1,hc.2.trans (var_le_of_grows k0.1)⟩
   have hc1:1≤cb ∧ cb≤u1.s.var:=⟨hc.1,hc.2.trans (var_le_of_grows k2.1)⟩
   have hr0:∀h<g,F.GateRecord bit cb h u0:=fun h hh=>F.GateRecord_keeps k0 bit cb h (by rw[v0]) (hr h hh)
   have hv1:1≤u1.s.veq g bit ∧ u1.s.veq g bit≤u1.s.var:=by
     rw[v2];exact ⟨hv.1,hv.2.trans (var_le_of_grows k2.1)⟩
   intro c hcs
   simp only[RecordedGateStep.finish,hg0,↓reduceIte] at hcs
   rcases List.mem_append.mp hcs with hcs|hcs
   · rcases List.mem_append.mp hcs with hcs|hcs
     · exact NumericCoveragePort.program M F hk hm u g 0 bit cb hu (by omega) hg (by decide) hb hc hr hU0 c hcs
     · exact NumericCoveragePort.program M F hk hm u0 g 1 bit cb hu0 (by omega) hg (by decide) hb hc0 hr0 hU1 c hcs
   · exact NumericCoverageLeaves.gate M F hk u1 hu1 g bit cb _ _ hg hb hc1 hv1 hM hU1.1 _ c hcs

theorem program (M:Nat) (F:Fam) (hk:2≤F.k) (hs:1≤F.s) (hm:1≤F.V)
 (bit cb g:Nat) (t:StI F.V) (ht:F.Good3 t) (hb:bit<2) (hg:g<F.s)
 (hc:1≤cb ∧ cb≤t.s.var) (hr:∀h<g,F.GateRecord bit cb h t)
 (hbudget:NumericFrontendBudget.Bound M (F.veqStep hm bit cb t g)):
 ∀c∈RecordedGateStep.program F hm bit cb t g,Content M c:=by
 rw[F.veqStep_factor] at hbudget
 let u:=F.veqStart hm bit t g
 have kk:=F.veqStart_keeps hm bit t g
 have hi:=F.veqStart_info hk hm bit t g hb hg
 have hhist:∀h<g,F.GateRecord bit cb h u:=by
   intro h hh
   apply F.GateRecord_keeps kk bit cb h _ (hr h hh)
   have hne:h≠g:=by omega
   simp[u,veqStart,StI.setVeq,StI.EQ,St.EQ,hne]
 have hu:=NumericFrontendBudget.mono (F.veqFinish_keeps hm bit cb g u).1 hbudget
 intro c hcs;rcases List.mem_append.mp hcs with hcs|hcs
 · exact NumericFrontendBudget.suffix F.db5 t u kk.1 hu c hcs
 · exact finish M F hk hs hm bit cb g u (F.Good3_of_keeps2 kk ht) hb hg
     ⟨hc.1,hc.2.trans (var_le_of_grows kk.1)⟩ ⟨by change 1≤(F.veqStart hm bit t g).s.veq g bit;have:=hi.2.1;omega,hi.2.2⟩ hhist hbudget c hcs

#print axioms program
end L3Emitter.NumericCoverageGate

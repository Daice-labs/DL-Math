import UniformSemanticReduction
import SemanticCircuitTransport

/- Circuit-to-original-encoding adequacy. This is a semantic bridge, not a
   substitute for a recorded emitter or native-checker correspondence. -/
namespace L3Emitter.CircuitEncoding
open Classical
set_option autoImplicit false
open EREF EREF.GeneralRED FamilyNamespace FamilyRows InputSwap
open L3Uniform.Circuit L3Uniform.Alias

noncomputable def assignment (k s : Nat) (v : Wire → Bool) : Val := fun i =>
  if h : ∃ w, Valid k s w ∧ encode k s w = i then v (Classical.choose h) else false

theorem assignment_at (k s : Nat) (v : Wire → Bool) (w : Wire) (hw : Valid k s w) :
    assignment k s v (encode k s w) = v w := by
  have he : ∃ u, Valid k s u ∧ encode k s u = encode k s w := ⟨w,hw,rfl⟩
  have hh : Classical.choose he = w :=
    encode_injective k s _ _ (Classical.choose_spec he).1 hw (Classical.choose_spec he).2
  simp only [assignment, dif_pos he, hh]

def score (v : Wire → Bool) (l : NamedLit) : Int := if v l.1 = l.2 then 1 else 0

theorem literal_value (k s : Nat) (v : Wire → Bool) (l : NamedLit)
    (hl : Valid k s l.1) : litVal (assignment k s v) (lit k s l) = score v l := by
  rcases l with ⟨w,b⟩
  have hp := (encode_bounds k s w hl).1
  have ha := assignment_at k s v w hl
  cases b <;> cases hv : v w <;>
    simp [lit, litVal, score, hp, ha, hv, b2i]

theorem row_value (k s : Nat) (v : Wire → Bool) (r : Spec) (hr : r.valid k s) :
    (r.row k s).val (assignment k s v) = (r.literals.map (score v)).sum - r.rhs := by
  rw [FamilyRows.row_value k s r hr]
  unfold REDWitness.sum
  rw [List.map_map]
  congr 2
  apply List.map_congr_left
  intro l hl
  exact literal_value k s v l (hr l hl)

def source (h : High) (t p : Nat) : Nat := if p=0 then h.left t else h.right t

def tableBit (t : Table) (ab : Nat) : Bool :=
  if ab=0 then t.f00 else if ab=1 then t.f01 else if ab=2 then t.f10 else t.f11

def values (h : High) (gates : Nat → Nat → Bool) : Wire → Bool
  | .sel t p j => decide (source h t p = j)
  | .fn t ab => tableBit (h.table t) ab
  | .port t p x => highValue h (bit h.k x) (gates x) (source h t p)
  | .val t x => gates x t

theorem tableBit_eval (t : Table) (a b : Bool) :
    tableBit t (2*a.toNat+b.toNat) = t.eval a b := by
  cases a <;> cases b <;> rfl

theorem indicator_sum (m j : Nat) :
    ((List.range m).map fun i => (if j=i then (1:Int) else 0)).sum =
      if j<m then 1 else 0 := by
  induction m with
  | zero => simp
  | succ m ih =>
    simp only [List.range_succ, List.map_append, List.map_singleton, List.sum_append,
      List.sum_singleton, ih]
    split_ifs <;> omega

theorem complement_sum (m j : Nat) :
    ((List.range m).map fun i => (if j=i then (0:Int) else 1)).sum =
      (m:Int) - (if j<m then 1 else 0) := by
  induction m with
  | zero => simp
  | succ m ih =>
    simp only [List.range_succ, List.map_append, List.map_singleton, List.sum_append,
      List.sum_singleton, ih]
    split_ifs <;> push_cast <;> omega

theorem oneHot_sum (h : High) (gs : Nat → Nat → Bool) (t p : Nat) (b : Bool)
    (bound : source h t p < h.k+t) :
    (((oneHot h.k t p b).literals).map (score (values h gs))).sum ≥
      (oneHot h.k t p b).rhs := by
  cases b
  · simp only [oneHot, List.map_map, Function.comp_def]
    have he : (fun i => score (values h gs) (Wire.sel t p i,false)) =
        (fun i => if source h t p=i then (0:Int) else 1) := by
      funext i; simp [score, values]
    rw [he, complement_sum]
    simp [bound]
  · simp only [oneHot, List.map_map, Function.comp_def]
    have he : (fun i => score (values h gs) (Wire.sel t p i,true)) =
        (fun i => if source h t p=i then (1:Int) else 0) := by
      funext i; simp [score, values]
    rw [he, indicator_sum]
    simp [bound]

theorem forbidden_sum (h : High) (gs : Nat → Nat → Bool) (t c : Nat)
    (allowed : (h.table t).allowed) (hc : c∈[6,9]) :
    (((forbidden t c).literals).map (score (values h gs))).sum ≥ 1 := by
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl | rfl
  all_goals
    rcases he : h.table t with ⟨a,b,c,d⟩
    simp only [forbidden, List.range_succ, List.range_zero, List.map_append, List.map_cons, List.map_nil, List.map_singleton, List.sum_append, List.sum_cons, List.sum_nil, List.sum_singleton, score, values, he] at ⊢
    rw [he] at allowed
    cases a <;> cases b <;> cases c <;> cases d <;>
      simp_all [Table.allowed, tableBit] <;> decide

/-- All row classes are satisfied by the truth table of a topologically ordered
    U2 circuit whose last gate is parity. The gate evaluations are explicit data. -/
theorem original_satisfied (h : High) (gs : Nat → Nat → Bool)
    (topo : ∀ t, t<h.s → h.left t<h.k+t ∧ h.right t<h.k+t)
    (allowed : ∀ t, t<h.s → (h.table t).allowed)
    (evals : ∀ x, x<truthRows h.k → Evaluates h (bit h.k x) (gs x))
    (output : ∀ x, x<truthRows h.k → gs x (h.s-1)=parity h.k x)
    (r : Spec) (hr : Original h.k h.s r) :
    (r.row h.k h.s).sat (assignment h.k h.s (values h gs)) := by
  change 0 ≤ (r.row h.k h.s).val _
  rw [row_value _ _ _ _ (original_valid _ _ _ hr)]
  cases hr with
  | oneHot t p b ht hp =>
    have hb : source h t p<h.k+t := by
      unfold source
      split
      · exact (topo t ht).left
      · exact (topo t ht).right
    have hv := oneHot_sum h gs t p b hb
    omega
  | forbidden t c ht hc =>
    have hv := forbidden_sum h gs t c (allowed t ht) hc
    simpa [forbidden] using sub_nonneg.mpr hv
  | input t p j x ht hp hj hx =>
    by_cases hs : source h t p=j
    · simp [inputTransfer,score,values,hs,highValue,hj]
    · simp [inputTransfer,score,values,hs]
      split_ifs <;> omega
  | gate t p g x b ht hp hg hx =>
    by_cases hs : source h t p=h.k+g
    · cases hb : gs x g <;> cases b <;>
        simp [gateTransfer,score,values,hs,highValue,hb]
    · simp [gateTransfer,score,values,hs]
      split_ifs <;> omega
  | semantics t x a b c ht hx =>
    have he := evals x hx t ht
    have hs0 : source h t 0=h.left t := by simp [source]
    have hs1 : source h t 1=h.right t := by simp [source]
    have hb := tableBit_eval (h.table t) a b
    simp only [semantics,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil]
    unfold score values
    simp only [hs0,hs1,hb]
    cases hl : highValue h (bit h.k x) (gs x) (h.left t) <;>
      cases hr : highValue h (bit h.k x) (gs x) (h.right t) <;>
      cases a <;> cases b <;> cases c <;>
      simp_all
    all_goals split_ifs <;> simp_all
  | output x hs hx => simp [outputRow,score,values,output x hx]

/-- Encoding adequacy in the direction needed to transfer UNSAT to circuits. -/
theorem model_of_circuit (h : High) (hs : 0<h.s) (gs : Nat → Nat → Bool)
    (topo : ∀ t, t<h.s → h.left t<h.k+t ∧ h.right t<h.k+t)
    (allowed : ∀ t, t<h.s → (h.table t).allowed)
    (evals : ∀ x, x<truthRows h.k → Evaluates h (bit h.k x) (gs x))
    (output : ∀ x, x<truthRows h.k → gs x (h.s-1)=parity h.k x) :
    Model (OriginalEncoding.rows h.k h.s) (assignment h.k h.s (values h gs)) := by
  intro R hR
  obtain ⟨r,hr,rfl⟩ := List.mem_map.mp hR
  exact ⟨canonical_normalize _ _, original_satisfied h gs topo allowed evals output r
    ((OriginalEncoding.spec_mem_iff _ _ hs r).mp hr)⟩

#print axioms model_of_circuit
end L3Emitter.CircuitEncoding

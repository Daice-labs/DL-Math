import InputBank

namespace L3Emitter.CanonicalTrace
open EREF EREF.GeneralRED

theorem pol (db : Nat→Option Row) (hd : ∀i R,db i=some R→Canonical R)
    (ts : List Tok) (st : List Row) (hs : ∀R∈st,Canonical R) (out : Row)
    (he : polEval db ts st=some out) : Canonical out := by
  induction ts generalizing st with
  | nil =>
    cases st with
    | nil => simp [polEval] at he
    | cons r rs =>
      cases rs with
      | nil => simp only [polEval,Option.some.injEq] at he;subst out;exact hs r (by simp)
      | cons r' rs => simp [polEval] at he
  | cons t ts ih =>
    cases t with
    | ref i =>
      simp only [polEval] at he
      split at he
      · rename_i r hr
        exact ih _ (by intro R hR;rcases List.mem_cons.mp hR with rfl|hR;exact hd i R hr;exact hs R hR) he
      · contradiction
    | lit l =>
      simp only [polEval] at he
      split at he
      · exact ih _ (by intro R hR;rcases List.mem_cons.mp hR with rfl|hR;exact canonical_litAxiom l;exact hs R hR) he
      · contradiction
    | add =>
      match st with
      | b::a::st =>
        apply ih _ _ he
        intro R hR;rcases List.mem_cons.mp hR with rfl|hR
        · exact canonical_add a b
        · exact hs R (by simp [hR])
      | [] => simp [polEval] at he
      | [_] => simp [polEval] at he
    | mul k =>
      match st with
      | a::st =>
        simp only [polEval] at he
        split at he
        · apply ih _ _ he
          intro R hR;rcases List.mem_cons.mp hR with rfl|hR
          · exact canonical_multiply a k
          · exact hs R (by simp [hR])
        · contradiction
      | [] => simp [polEval] at he
    | div k =>
      match st with
      | a::st =>
        simp only [polEval] at he
        split at he
        · apply ih _ _ he
          intro R hR;rcases List.mem_cons.mp hR with rfl|hR
          · exact canonical_divide a k
          · exact hs R (by simp [hR])
        · contradiction
      | [] => simp [polEval] at he
    | sat =>
      match st with
      | a::st =>
        apply ih _ _ he
        intro R hR;rcases List.mem_cons.mp hR with rfl|hR
        · exact canonical_saturate a
        · exact hs R (by simp [hR])
      | [] => simp [polEval] at he

theorem step {D E : List Row} (h : CheckedStep D E) (hc:∀R∈D,Canonical R) : ∀R∈E,Canonical R := by
  have addRow (C : Row) (hC:Canonical C) : ∀R∈D++[C],Canonical R := by
    intro R hR;rcases List.mem_append.mp hR with hR|hR
    · exact hc R hR
    · simpa only [List.mem_singleton.mp hR] using hC
  cases h with
  | pol C ts he => exact addRow C (pol (dbOf D) (fun i R hr=>hc R (dbOf_mem _ _ _ hr)) ts [] (by simp) C he)
  | consequence C hC _ => exact addRow C hC
  | red C _ hC _ => exact addRow C hC

theorem trace {D E : List Row} (h : CheckedTrace D E) (hc:∀R∈D,Canonical R) : ∀R∈E,Canonical R := by
  induction h with
  | refl => exact hc
  | cons h t ih => exact ih (step h hc)

def ceiling (D : List Row) : Nat := ((D.flatMap Row.terms).map (fun t=>t.2.natAbs)).foldr max 0

theorem fold_max_bound (xs : List Nat) (a : Nat) (ha:a∈xs) : a≤xs.foldr max 0 := by
  induction xs with
  | nil => simp at ha
  | cons x xs ih =>
    rcases List.mem_cons.mp ha with rfl|ha
    · exact Nat.le_max_left _ _
    · exact le_trans (ih ha) (Nat.le_max_right _ _)

theorem bounded (D : List Row) (hc:∀R∈D,Canonical R) : RowSupport.Bounded (ceiling D) D := by
  intro R hR;refine ⟨hc R hR,?_⟩
  intro t ht
  exact fold_max_bound _ _ (List.mem_map.mpr ⟨t,List.mem_flatMap.mpr ⟨R,hR,ht⟩,rfl⟩)

#print axioms trace
#print axioms bounded
end L3Emitter.CanonicalTrace

import BetaAliasValue
import GuardedValueComposition
namespace L3Emitter.BetaSelectedValue
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL CofactorValueRows BetaAliasValue

def beta (n:Nat) (hn:2≤n) (j:Job n):Bit:=(PrimaryAliasBank.cfg n hn).beta (gate j)
def parent {n:Nat} (j:Job n):Int:=j.1.2.parent.lit

theorem parent_row (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn):
    clause [-choice j,parent j]∈UnaryValueBank.result n hn:=by
  have h:=BetaPort.valid_job n hn j hj
  have hr:=ForcingFieldBank.field_present (n+1) (by omega) (ForcingFieldBank.base n hn)
    j.1.1 j.1.2 h.1 h.2.1 h.2.2.1 (parent j) (by simp [ForcingCandidates.fields,parent])
  apply beta_keep n hn
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hr))

theorem category_row (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn):
    clause [-parent j,(beta n hn j).val]∈UnaryValueBank.result n hn:=by
  have h:=BetaPort.valid_job n hn j hj
  have hp:=(ForcingCandidates.wellformed _ _ j.1.2 h.2.1).1
  have hg:=gate_bounds j
  have hr:=GateCategories.forward n hn (gate j) hg.1 hg.2 .beta (by simp [GateCategories.categories])
    (parent j) ((GateCategories.support_mem _ _ _ _).mpr ⟨j.1.2.parent,hp,rfl,rfl⟩)
  exact UnaryPortTransport.category_keep n hn _ (CategoryBank.retains n hn _ hr)

def choiceRow (n:Nat) (hn:2≤n) (j:Job n):=clause [-choice j,(beta n hn j).val]
def choiceTape (n:Nat) (hn:2≤n) (j:Job n) (D:List Row):=
  GuardedJoin.tape D [-choice j] [] (parent j) (beta n hn j).val

theorem choice_check (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn)
    (D:List Row) (hd:∀R∈UnaryValueBank.result n hn,R∈D):
    polEval (dbOf D) (choiceTape n hn j D) []=some (choiceRow n hn j):=by
  exact GuardedJoin.checks D [-choice j] [] (parent j) (beta n hn j).val
    (by simp [Valid,choice_valid n hn j hj]) (by simp [Valid]) j.1.2.parent.nonzero (beta n hn j).property
    (hd _ (parent_row n hn j hj)) (hd _ (category_row n hn j hj))

def middleRow (n:Nat) (hn:2≤n) (j:Job n) (b v:Bool):=
  GuardedValueComposition.row (choice j) (sign v (PrimaryAliasBank.cfg n hn).C) (sign v (unary n hn (gate j) b))
def middleTape (n:Nat) (hn:2≤n) (j:Job n) (b v:Bool) (D:List Row):=
  GuardedJoin.tape D [-choice j] [-sign v (PrimaryAliasBank.cfg n hn).C]
    (beta n hn j).val (sign v (unary n hn (gate j) b))

theorem middle_check (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (b v:Bool)
    (D:List Row) (hd:∀R∈UnaryValueBank.result n hn,R∈D) (hch:choiceRow n hn j∈D):
    polEval (dbOf D) (middleTape n hn j b v D) []=some (middleRow n hn j b v):=by
  have hg:=gate_bounds j
  have h:=UnaryRelationBank.beta_relations n hn (gate j) hg.1 hg.2 b
  have hl:=unary_keep n hn _ (UnaryValueStep.conditional_link _ (beta n hn j)
    (PrimaryAliasBank.cfg n hn).C (unary n hn (gate j) b) v h.1 h.2)
  have hp:GuardedJoin.link [-sign v (PrimaryAliasBank.cfg n hn).C]
      (beta n hn j).val (sign v (unary n hn (gate j) b))∈D:=by
    apply hd
    change clause [-sign v (PrimaryAliasBank.cfg n hn).C,-(beta n hn j).val,sign v (unary n hn (gate j) b)]∈_
    rw [ProjectionTrace.clause_perm _ _
      (by simp [Valid,sign_valid,(beta n hn j).property])
      (by simp [Valid,sign_valid,(beta n hn j).property]) (List.Perm.swap ..)]
    exact hl
  exact GuardedJoin.checks D _ _ _ _
    (by simp [Valid,choice_valid n hn j hj]) (by simp [Valid,sign_valid])
    (beta n hn j).property (sign_valid v _) hch hp

def finalRow (n:Nat) (hn:2≤n) (j:Job n) (b v:Bool):=
  GuardedValueComposition.row (choice j) (sign v (cofactor n hn (gate j) j.2)) (sign v (unary n hn (gate j) b))
def rows (n:Nat) (hn:2≤n) (j:Job n) (b v:Bool):=
  [choiceRow n hn j,middleRow n hn j b v,finalRow n hn j b v]
def program (n:Nat) (hn:2≤n) (j:Job n) (b v:Bool) (D:List Row):Program:=
  [(choiceRow n hn j,choiceTape n hn j D),
   (middleRow n hn j b v,middleTape n hn j b v (D++[choiceRow n hn j])),
   (finalRow n hn j b v,GuardedValueComposition.tape (D++[choiceRow n hn j,middleRow n hn j b v])
     (choice j) (sign v (cofactor n hn (gate j) j.2)) (sign v (PrimaryAliasBank.cfg n hn).C)
     (sign v (unary n hn (gate j) b)))]

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (b v:Bool)
    (D:List Row) (hd:∀R∈UnaryValueBank.result n hn,R∈D):
    check D (program n hn j b v D)=some (D++rows n hn j b v):=by
  have h0:=choice_check n hn j hj D hd
  have h1:=middle_check n hn j hj b v (D++[choiceRow n hn j])
    (fun R h=>List.mem_append_left _ (hd R h)) (List.mem_append_right _ (List.mem_singleton_self _))
  have h2:=GuardedValueComposition.checks (D++[choiceRow n hn j,middleRow n hn j b v]) (choice j)
    (sign v (cofactor n hn (gate j) j.2)) (sign v (PrimaryAliasBank.cfg n hn).C) (sign v (unary n hn (gate j) b))
    (choice_valid n hn j hj) (sign_valid v _) (sign_valid v _) (sign_valid v _)
    (List.mem_append_left _ (hd _ (constant_link n hn j hj v)))
    (List.mem_append_right _ (by simp [middleRow]))
  simp only [program,check,h0,↓reduceIte,h1,List.append_assoc,List.singleton_append] at *
  simp only [h2,↓reduceIte,finalRow,rows,List.append_assoc,List.singleton_append,List.nil_append,List.cons_append,check]

theorem count (n:Nat) (hn:2≤n) (j:Job n) (b v:Bool) (D:List Row):(program n hn j b v D).length=3:=rfl
#print axioms choice_check
#print axioms checks
end L3Emitter.BetaSelectedValue

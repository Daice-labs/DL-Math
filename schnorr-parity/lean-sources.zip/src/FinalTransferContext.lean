import FinalOutputLinks
import TransferMuxPOL
namespace L3Emitter.FinalTransferContext
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram FinalOutputDefinitions GuardedVectorTransport
attribute [local irreducible] FinalOutputDefinitions.base initialNet

def D (n:Nat) (hn:2≤n):=FinalOutputLinks.result n hn
def rawSelector (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)):=LowerTransferImage.wire n hn (.sel (lastRank n) p.val i.val)
def rawPort (n:Nat) (hn:2≤n) (p:Fin 2) (x:Fin (T n)):=LowerTransferImage.wire n hn (.port (lastRank n) p.val x.val)
def value (n:Nat) (hn:2≤n) (i:Fin (W n-1)) (x:Fin (T n)):=SourceCoordinateValue.value n hn (coord n i) x.val
def targetSelector (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)):=(built n hn).1.sels p i
def targetPort (n:Nat) (hn:2≤n) (p:Fin 2) (x:Fin (T n)):=(built n hn).1.ports p x
def altSelector (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)):=FinalOutputSlots.alternative n hn p i
def altPort (n:Nat) (hn:2≤n) (p:Fin 2) (x:Fin (T n)):=FinalPortSlots.alternative n hn (initialNet n hn) p x

theorem recorded_kept (n:Nat) (hn:2≤n):∀R∈FinalOutputRecorded.result n hn,R∈D n hn:=by
  intro R h
  apply FinalOutputLinks.retained
  apply List.mem_append_left
  exact List.mem_append_left _ h

theorem definitions_kept (n:Nat) (hn:2≤n):∀R∈FinalOutputDefinitions.result n hn,R∈D n hn:=
  fun R h=>recorded_kept n hn R (List.mem_append_left _ h)

theorem raw_kept (n:Nat) (hn:2≤n):∀R∈(RawLowerInputBank.result n hn).1,R∈D n hn:=by
  intro R h
  apply definitions_kept
  apply FinalOutputDefinitions.retains
  unfold FinalOutputDefinitions.base
  apply List.mem_append_left
  apply List.mem_append_left
  apply GateEvaluationBindings.selector_keep
  apply LowerSelectorComplete.predecessor_kept
  apply List.mem_append_left
  apply List.mem_append_left
  exact RawPrimaryTransferBank.raw_retained n hn R h

theorem raw_row (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)) (b:Bool):
    TransferMuxPOL.row (rawSelector n hn p i) (value n hn i x) (rawPort n hn p x) b∈D n hn:=by
  obtain ⟨r,he,heq⟩:=LowerTransferImage.port_exists n hn (lastRank n) p.val (by unfold lastRank RankConstruction.width;omega) p.isLt
  have h:=(RawLowerInputBank.original_to_raw_inputs n hn).2 r.val r.property x.val x.isLt (coord n i)
  apply raw_kept
  have hi:i.val<AliasAssembly.width (n+1):=(coord n i).isLt
  cases b
  · have hp:=ProjectionTrace.clause_perm [- (RawInputSelection.coordinate r.val.1.1.2.2 (coord n i)).val,(value n hn i x).val,-(r.val.2 x.val).val]
      [- (RawInputSelection.coordinate r.val.1.1.2.2 (coord n i)).val,-(r.val.2 x.val).val,(value n hn i x).val]
      (by simp [Valid,(value n hn i x).property,(r.val.2 x.val).property,(RawInputSelection.coordinate r.val.1.1.2.2 (coord n i)).property])
      (by simp [Valid,(value n hn i x).property,(r.val.2 x.val).property,(RawInputSelection.coordinate r.val.1.1.2.2 (coord n i)).property])
      (List.Perm.cons _ (List.Perm.swap ..))
    have hh:clause [- (RawInputSelection.coordinate r.val.1.1.2.2 (coord n i)).val,(value n hn i x).val,-(r.val.2 x.val).val]∈(RawLowerInputBank.result n hn).1:=by
      rw [hp];exact h.2
    simpa only [TransferMuxPOL.row,rawSelector,rawPort,LowerTransferImage.wire,he,dif_pos hi,coord,signed,Bool.false_eq_true,↓reduceIte,neg_neg] using hh
  · simpa only [TransferMuxPOL.row,rawSelector,rawPort,LowerTransferImage.wire,he,dif_pos hi,coord,value,signed,↓reduceIte] using h.1

attribute [local irreducible] D LowerTransferImage.wire

theorem raw_relations (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)):
    Relations (D n hn) (neg (H n hn))
      (TransferMuxPOL.vec (rawSelector n hn p i) (rawPort n hn p x))
      (TransferMuxPOL.vec (targetSelector n hn p i) (targetPort n hn p x)):=by
  intro t;cases t <;> simp only [TransferMuxPOL.vec,Bool.false_eq_true,↓reduceIte,rawSelector,rawPort,targetSelector,targetPort,altSelector,altPort,neg]
  · exact ⟨recorded_kept n hn _ (FinalOutputSlots.selector_rows n hn p i).1,recorded_kept n hn _ (FinalOutputSlots.selector_rows n hn p i).2.1⟩
  · exact ⟨recorded_kept n hn _ (FinalPortSlots.rows n hn p x).1,recorded_kept n hn _ (FinalPortSlots.rows n hn p x).2.1⟩

theorem alt_relations (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)):
    Relations (D n hn) (H n hn)
      (TransferMuxPOL.vec (altSelector n hn p i) (altPort n hn p x))
      (TransferMuxPOL.vec (targetSelector n hn p i) (targetPort n hn p x)):=by
  intro t;cases t <;> simp only [TransferMuxPOL.vec,Bool.false_eq_true,↓reduceIte,rawSelector,rawPort,targetSelector,targetPort,altSelector,altPort,neg]
  · exact ⟨recorded_kept n hn _ (FinalOutputSlots.selector_rows n hn p i).2.2.1,recorded_kept n hn _ (FinalOutputSlots.selector_rows n hn p i).2.2.2⟩
  · exact ⟨recorded_kept n hn _ (FinalPortSlots.rows n hn p x).2.2.1,recorded_kept n hn _ (FinalPortSlots.rows n hn p x).2.2.2⟩
#print axioms raw_row
#print axioms raw_relations
#print axioms alt_relations
end L3Emitter.FinalTransferContext

import NormalizedCofactor

namespace L3Emitter.NormalizedCofactorBytes
open EREF FamilyNamespace CofactorSemantics CofactorSection NormalizedCofactor
open CofactorBytes PolTapeBytes ClauseTransport CofactorClause FormulaSize

theorem normalized_length (k s : Nat) (hk : 2≤k) :
    (FullNormalization.finalRows k s).length=(OriginalEncoding.rows k s).length+2*k := by
  simp only [FullNormalization.finalRows,ProjectionNormalization.base,
    ProjectionNormalization.units,SelectorNormalization.state,
    SelectorNormalization.rightPrevious,SelectorNormalization.leftPrevious,
    List.length_append,List.length_map,List.length_range,List.length_cons,List.length_nil]
  omega

def refBound (n s : Nat) : Nat := rowBound (n+1) s+2*(n+1)+12*s*truthRows n+1
def width (n s offset B : Nat) : Nat := CofactorBytes.width n s offset B+refBound n s

theorem references_bounded (n s offset B i : Nat) (hn : 1≤n) :
    refMap n s offset B i≤refBound n s := by
  have h := List.idxOf_le_length
    (l := target n s offset B) (a := (dbOf (database n s offset B) i).getD contra)
  have ho := original_rows_bound (n+1) s
  have hb := bank_length_bound n s offset B
  have he := normalized_length (n+1) s (by omega : 2≤n+1)
  simp only [target,List.length_append,he] at h
  unfold refMap ReferenceTransport.locate refBound target
  omega

theorem source_tokens_bounded (n s offset B : Nat) (j : Job) (hj : j∈jobs n s) :
    ∀ t∈resultTape n s offset B j,Bounded (CofactorBytes.width n s offset B) t := by
  have h := job_bounds n s j hj
  let g := j.1
  let x := j.2.1
  let a := j.2.2.1
  let b := j.2.2.2.1
  let c := j.2.2.2.2
  have hs : ∀ side,sourceId n s offset B g x a b c side≤CofactorBytes.width n s offset B := by
    intro side
    have hid := locate_bound _ _ (original_in_database n s offset B g x h.1 h.2 a b c side)
    have hlen := database_length_bound n s offset B
    change ReferenceTransport.locate _ _≤_
    unfold CofactorBytes.width
    omega
  have hl := fun side => links_bound n s offset B g x h.1 h.2 a b c side
  change ∀ t∈tokensBoth (sourceId n s offset B g x a b c false)
    (sourceId n s offset B g x a b c true) B
    (links n s offset B g x a b c false) (links n s offset B g x a b c true),_
  intro t ht
  simp only [tokensBoth,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at ht
  rcases ht with (ht|ht)|(rfl|rfl)
  · exact tokens_bounded _ _ _ _ (hs false)
      (by simp only [Int.natAbs_natCast]; unfold CofactorBytes.width; omega)
      (by simp only [links,List.length_cons,List.length_nil]; unfold CofactorBytes.width; omega)
      (hl false) t ht
  · exact tokens_bounded _ _ _ _ (hs true)
      (by simp only [Int.natAbs_neg,Int.natAbs_natCast]; unfold CofactorBytes.width; omega)
      (by simp only [links,List.length_cons,List.length_nil]; unfold CofactorBytes.width; omega)
      (hl true) t ht
  · trivial
  · change 2≤_; unfold CofactorBytes.width; omega

theorem relocated_bounded (n s offset B : Nat) (hn : 1≤n) (j : Job) (hj : j∈jobs n s) :
    ∀ t∈relocatedTape n s offset B j,Bounded (width n s offset B) t := by
  intro t ht
  obtain ⟨u,hu,rfl⟩ := List.mem_map.mp ht
  have h := source_tokens_bounded n s offset B j hj u hu
  have hmono : CofactorBytes.width n s offset B≤width n s offset B := by unfold width; omega
  cases u with
  | ref i =>
    have hr := references_bounded n s offset B i hn
    change refMap n s offset B i≤_
    unfold width; omega
  | lit l => exact le_trans h hmono
  | mul m => exact le_trans h hmono
  | div d => exact le_trans h hmono
  | add => trivial
  | sat => trivial

def leafBound (n s offset B : Nat) : Nat := 7+70*(3+digits (width n s offset B))
def leavesDocument (n s offset B : Nat) : Doc :=
  (jobs n s).flatMap fun j => tapeDoc (relocatedTape n s offset B j)

theorem job_count (n s : Nat) : (jobs n s).length=8*s*truthRows n := by
  simp [jobs,List.length_flatMap,Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc]

theorem relocated_bytes (n s offset B : Nat) (hn : 1≤n) :
    (emit (leavesDocument n s offset B)).length≤8*s*truthRows n*leafBound n s offset B := by
  have h := document_flatMap_bound (jobs n s)
    (fun j => tapeDoc (relocatedTape n s offset B j)) (leafBound n s offset B) (by
      intro j hj
      have hl := tape_bound (width n s offset B) _ (relocated_bounded n s offset B hn j hj)
      simpa only [emit_length,relocated_token_count,leafBound] using hl)
  simpa only [leavesDocument,emit_length,job_count] using h

def document (n s offset B : Nat) : Doc :=
  FullNormalization.document (n+1) s++CofactorSection.bankDocument n s offset B++
    leavesDocument n s offset B

/-- Bound on this whole checked prefix, including references after normalization.
    Coverage, rank/alias, output, bank activation and the lower tail are not included. -/
theorem combined_bytes (n offset B : Nat) (hn : 2≤n)
    (hV : variableCount (n+1) (3*(n+1)-4)≤offset) (hB : 0<B) (hBm : B≤offset) :
    (emit (document n (3*(n+1)-4) offset B)).length≤
      FullNormalization.boundInN (n+1)+
      3*(3*(n+1)-4)*truthRows n*(134+16*digits (CofactorSection.maxVar n (3*(n+1)-4) offset))+
      8*(3*(n+1)-4)*truthRows n*leafBound n (3*(n+1)-4) offset B := by
  have hnrm := (FableIntegration.normalization_and_bytes (n+1) (by omega)).2.2
  have hbank := CofactorSection.bank_bytes n (3*(n+1)-4) offset B hV hB hBm
  have hleaves := relocated_bytes n (3*(n+1)-4) offset B (by omega)
  simp only [document,emit_length,exactBytes_append] at *
  omega

#print axioms combined_bytes
#print axioms references_bounded
end L3Emitter.NormalizedCofactorBytes

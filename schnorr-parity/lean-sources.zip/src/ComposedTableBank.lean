import RawUnaryBank
import LookupEvaluation
namespace L3Emitter.ComposedTableBank
open EREF EREF.GeneralRED REDWitness AliasNetwork
abbrev Job:=Nat×Bool×Bool

def originalFunction (n:Nat) (g:Nat):Bool→Bool→Bit:=AliasAssembly.functionBit (n+1) (3*(n+1)-4) g

def unary (n:Nat) (hn:2≤n) (g p:Nat) (b:Bool):Bit:=
  EarlierPortValues.portAlias n hn g p (UnarySnapshots.position (AliasAssembly.width (n+1)) b)

def entry {base:List Row} (n:Nat) (hn:2≤n) (j:Job) (z:Net base):Bit×Net base:=
  LookupEvaluation.result (originalFunction n j.1) (unary n hn j.1 0 j.2.1) (unary n hn j.1 1 j.2.2) z

abbrev Record (base:List Row):=Job×Net base

def run {base:List Row} (n:Nat) (hn:2≤n) (z:Net base):List Job→Net base×List (Record base)
  | []=>(z,[])
  | j::js=>let t:=run n hn (entry n hn j z).2 js
           (t.1,(j,z)::t.2)

theorem entry_retains {base:List Row} (n:Nat) (hn:2≤n) (j:Job) (z:Net base):∀R∈z.rows,R∈(entry n hn j z).2.rows:=
  by
    unfold entry
    rw [LookupEvaluation.compiled]
    exact Expr.extends _ z

theorem run_retains {base:List Row} (n:Nat) (hn:2≤n) (z:Net base) (js:List Job):∀R∈z.rows,R∈(run n hn z js).1.rows:=by
  induction js generalizing z with
  | nil=>exact fun _ h=>h
  | cons j js ih=>exact fun R h=>ih _ R (entry_retains n hn j z R h)

theorem record_retains {base:List Row} (n:Nat) (hn:2≤n) (z:Net base) (js:List Job):
    ∀r∈(run n hn z js).2,∀R∈(entry n hn r.1 r.2).2.rows,R∈(run n hn z js).1.rows:=by
  induction js generalizing z with
  | nil=>simp [run]
  | cons j js ih=>
    intro r hr
    rcases List.mem_cons.mp hr with rfl|hr
    · exact run_retains n hn _ js
    · exact ih _ r hr

def jobs (n:Nat):List Job:=(CategoryBank.gates n).flatMap fun g=>
  [(g,false,false),(g,false,true),(g,true,false),(g,true,true)]
def base (n:Nat) (hn:2≤n):=RawUnaryBank.result n hn

theorem base_canonical (n:Nat) (hn:2≤n):∀R∈base n hn,Canonical R:=
  CanonicalTrace.trace (RawUnaryBank.original_to_raw_unary n hn) (OriginalEncoding.rows_canonical _ _)

def built (n:Nat) (hn:2≤n):=run n hn (initial (base n hn) (base_canonical n hn)) (jobs n)
def value (n:Nat) (hn:2≤n) (r:Record (base n hn)):Bit:=(entry n hn r.1 r.2).1

theorem original_to_tables (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (built n hn).1.rows:=
  L3.Fam.checkedTrace_trans (RawUnaryBank.original_to_raw_unary n hn) (built n hn).1.checked

theorem records_cover {B:List Row} (n:Nat) (hn:2≤n) (z:Net B) (js:List Job):
    (run n hn z js).2.map Prod.fst=js:=by
  induction js generalizing z with
  | nil=>rfl
  | cons j js ih=>simp [run,ih]

theorem job_mem (n:Nat) (j:Job):j∈jobs n↔0<j.1 ∧ j.1<3*(n+1)-4:=by
  obtain ⟨g,a,b⟩:=j
  cases a <;> cases b <;> simp [jobs,CategoryBank.gate_mem]

theorem all_entries (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (a b:Bool):
    ∃r∈(built n hn).2,r.1=(g,a,b):=by
  have h:(g,a,b)∈(built n hn).2.map Prod.fst:=by
    rw [built,records_cover];exact (job_mem n _).mpr ⟨hg,hs⟩
  exact List.mem_map.mp h

abbrev Case (n:Nat) (hn:2≤n):=Record (base n hn)×Bool×Bool×Bool

def cases (n:Nat) (hn:2≤n):List (Case n hn):=
  (built n hn).2.flatMap fun r=>[false,true].flatMap fun a=>[false,true].flatMap fun b=>[false,true].map fun v=>(r,a,b,v)
def rows (n:Nat) (hn:2≤n) (c:Case n hn):=
  LookupEvaluation.rows (originalFunction n c.1.1.1) (unary n hn c.1.1.1 0 c.1.1.2.1)
    (unary n hn c.1.1.1 1 c.1.1.2.2) c.2.1 c.2.2.1 c.2.2.2 c.1.2

def leaf (n:Nat) (hn:2≤n) (c:Case n hn) (D:List Row):=
  LookupEvaluation.program (originalFunction n c.1.1.1) (unary n hn c.1.1.1 0 c.1.1.2.1)
    (unary n hn c.1.1.1 1 c.1.1.2.2) c.2.1 c.2.2.1 c.2.2.2 c.1.2 D

theorem case_mem (n:Nat) (hn:2≤n) (c:Case n hn):c∈cases n hn↔c.1∈(built n hn).2:=by
  obtain ⟨r,a,b,v⟩:=c
  cases a <;> cases b <;> cases v <;> simp [cases]

theorem leaf_check (n:Nat) (hn:2≤n) (c:Case n hn) (hc:c.1∈(built n hn).2) (D:List Row)
    (hd:∀R∈(built n hn).1.rows,R∈D):
    AliasProgram.check D (leaf n hn c D)=some (D++rows n hn c):=by
  apply (LookupEvaluation.checks _ _ _ _ _ _ _ D _).1
  exact fun R h=>hd R (record_retains n hn _ _ c.1 hc R h)

def program (n:Nat) (hn:2≤n):=
  RetainedBlockFold.run (leaf n hn) (rows n hn) (cases n hn) (built n hn).1.rows
def result (n:Nat) (hn:2≤n):=(built n hn).1.rows++RetainedBlockFold.body (rows n hn) (cases n hn)

theorem checks (n:Nat) (hn:2≤n):AliasProgram.check (built n hn).1.rows (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (fun c:Case n hn=>c.1∈(built n hn).2) (leaf_check n hn) _
    (fun c hc=>(case_mem n hn c).mp hc) _ (fun _ h=>h)

theorem original_to_table_rows (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (original_to_tables n hn) (AliasProgram.check_trace _ _ _ (checks n hn))

theorem evaluation_rows (n:Nat) (hn:2≤n) (r:Record (base n hn)) (hr:r∈(built n hn).2) (a b v:Bool):
    GuardedGatePOL.guarded (LookupEvaluation.guards (originalFunction n r.1.1)
      (unary n hn r.1.1 0 r.1.2.1) (unary n hn r.1.1 1 r.1.2.2) a b v)
      (GuardedGatePOL.sign v (value n hn r))∈result n hn:=by
  apply List.mem_append_right
  apply RetainedBlockFold.contains (rows n hn) (cases n hn) (r,a,b,v) ((case_mem n hn _).mpr hr)
  exact LookupEvaluation.output_rows _ _ _ _ _ _ _

#print axioms original_to_table_rows
#print axioms all_entries
#print axioms evaluation_rows
end L3Emitter.ComposedTableBank

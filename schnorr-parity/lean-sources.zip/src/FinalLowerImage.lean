import FinalOutputDefinitions
namespace L3Emitter.FinalLowerImage
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL FamilyNamespace FamilyRows

def finalValue (n:Nat) (hn:2≤n) (x:Nat):Bit:=
  if InputSwap.parity n x then (PrimaryAliasBank.cfg n hn).T else (PrimaryAliasBank.cfg n hn).F

def wire (n:Nat) (hn:2≤n) (w:Wire):Bit:=match w with
  | .sel t p j=>if t=FinalOutputDefinitions.lastRank n then
      if hp:p<2 then if hj:j<FinalOutputDefinitions.W n-1 then
        (FinalOutputDefinitions.built n hn).1.sels ⟨p,hp⟩ ⟨j,hj⟩ else SelectedCoordinateBank.fallback
      else SelectedCoordinateBank.fallback
    else LowerTransferImage.wire n hn w
  | .port t p x=>if t=FinalOutputDefinitions.lastRank n then
      if hp:p<2 then if hx:x<truthRows n then
        (FinalOutputDefinitions.built n hn).1.ports ⟨p,hp⟩ ⟨x,hx⟩ else SelectedCoordinateBank.fallback
      else SelectedCoordinateBank.fallback
    else LowerTransferImage.wire n hn w
  | .fn t ab=>if t=FinalOutputDefinitions.lastRank n then
      if hab:ab<4 then (FinalOutputDefinitions.built n hn).1.functions ⟨ab,hab⟩ else SelectedCoordinateBank.fallback
    else LowerTransferImage.wire n hn w
  | .val t x=>if t=FinalOutputDefinitions.lastRank n then finalValue n hn x else LowerTransferImage.wire n hn w

def image (n:Nat) (hn:2≤n) (r:Spec):Row:=normalize (r.literals.map fun l=>(1,sign l.2 (wire n hn l.1))) r.rhs

theorem true_present (n:Nat) (hn:2≤n):clause [(PrimaryAliasBank.cfg n hn).T.val]∈FinalOutputDefinitions.result n hn:=by
  apply FinalOutputDefinitions.retains
  apply List.mem_append_left
  apply List.mem_append_left
  apply GateEvaluationBindings.selector_keep
  apply LowerSelectorComplete.predecessor_kept
  exact TopologyContext.true_unit n hn

theorem signed_final_value (n:Nat) (hn:2≤n) (x:Nat):
    sign (InputSwap.parity n x) (finalValue n hn x)=(PrimaryAliasBank.cfg n hn).T.val:=by
  cases hp:InputSwap.parity n x <;> simp [finalValue,hp,sign,PrimaryAliasBank.false_bit,neg]

theorem output_image (n:Nat) (hn:2≤n) (x:Nat):
    image n hn (InputSwap.outputRow n (3*n-4) x)=clause [(PrimaryAliasBank.cfg n hn).T.val]:=by
  have ht:3*n-4-1=FinalOutputDefinitions.lastRank n:=by
    unfold FinalOutputDefinitions.lastRank RankConstruction.width;omega
  simp only [image,InputSwap.outputRow,List.map_cons,List.map_nil,wire,ht,↓reduceIte,signed_final_value,clause]

theorem all_output_images (n:Nat) (hn:2≤n) (r:Spec) (hr:r∈OriginalEncoding.outputsBlock n (3*n-4)):
    image n hn r∈FinalOutputDefinitions.result n hn:=by
  simp only [OriginalEncoding.outputsBlock,OriginalEncoding.mem_loop,List.mem_singleton] at hr
  obtain ⟨x,hx,rfl⟩:=hr
  rw [output_image]
  exact true_present n hn

-- This image changes the final gate. Existing raw last-gate selector,
-- transfer, forbidden and evaluation rows cannot be reused as its proof.
#print axioms output_image
#print axioms all_output_images
end L3Emitter.FinalLowerImage

import PinnedFileOnline
namespace L3Emitter.NativeParserStackShapes
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace CanonicalScopeKernel
open CanonicalFileGrammar CanonicalNativePOLShape

def LocalValid (p:LocalProof):Prop:=∀ts∈p.tapes,shape ts 0=some 1

def CommandValid : CanonicalScopeKernel.Command→Prop
 | .pol ts=>shape ts 0=some 1
 | .consequence _ p=>LocalValid p
 | .red _ _ gs=>∀g∈gs,LocalValid g.proof

theorem reference_shape (ids:Nat→Nat) (ts:List Tok) (d:Nat):
 shape (ts.map (ReferenceTransport.token ids)) d=shape ts d:=by
 induction ts generalizing d with
 | nil=>rfl
 | cons t ts ih=>cases t <;> simp only [List.map_cons,ReferenceTransport.token,shape,ih]

theorem relocated_shape (D:List Row) (ids:Nat→Nat) (ts:List Tok) (R:Row)
 (h:polEval (dbOf D) ts []=some R):shape (ts.map (ReferenceTransport.token ids)) 0=some 1:=by
 rw [reference_shape]
 exact CanonicalNativePOLShape.checked_shape _ _ [] _ h

theorem local_valid (D E : List Row) (s : Store) (ids : Nat→Nat)
    (hs : 0<s.next) (he : Embeds D s ids) (p : AliasProgram.Program)
    (hp : AliasProgram.check D p=some E) :
    ∀ts∈(NativeLocalProgram.compile D.length s ids p).tapes,shape ts 0=some 1 := by
  induction p generalizing D s ids with
  | nil=>simp [NativeLocalProgram.compile]
  | cons c p ih=>
    rcases c with ⟨R,ts⟩
    simp only [AliasProgram.check] at hp
    split at hp
    · rename_i hc
      have ht:=ih (D++[R]) (push s R) (extend ids D.length s.next)
        (by dsimp [push];omega) (push_embeds D s ids he hs R) hp
      intro tape hm
      simp only [NativeLocalProgram.compile,List.mem_cons] at hm
      rcases hm with rfl|hm
      · exact relocated_shape D ids ts R hc
      · exact ht tape (by simpa using hm)
    · contradiction

theorem scoped_valid (D : List Row) (s : Store) (ids : Nat→Nat) (G : Row)
    (hs : 0<s.next) (he : Embeds D s ids) (p : RecordedRefutation.Certificate)
    (hp : RecordedRefutation.accepts (D++[negate G]) p=true) :
    LocalValid (stripLocal (NativeScopedLocalGoal.compile D.length s ids G p)) := by
  have hp0:=hp
  unfold RecordedRefutation.accepts at hp0
  split at hp0
  · contradiction
  · rename_i E hE
    have hv:=local_valid (D++[negate G]) E (push s (negate G))
      (extend ids D.length s.next) (by change 0<s.next+1;omega) (push_embeds D s ids he hs _) p.program hE
    have hl:(D++[negate G]).length=D.length+1:=by simp
    rw [hl] at hv
    exact hv

theorem goals_valid (D : List Row) (C : Row) (w : FiniteWitness.Data)
    (s : Store) (ids : Nat→Nat) (rs : List Row) (ps : List RecordedRefutation.Certificate)
    (hs : 0<s.next) (he : Embeds (D++[negate C]) s ids)
    (hp : checkGoals D C w rs ps=true) :
    ∀b∈(NativeREDGoalSequence.compile D C w s ids rs ps).blocks,LocalValid (stripLocal b.2) := by
  induction rs generalizing ps s with
  | nil=>cases ps <;> simp_all [checkGoals,NativeREDGoalSequence.compile]
  | cons R rs ih=>
    cases ps with
    | nil=>simp [checkGoals] at hp
    | cons p ps=>
      obtain ⟨hh,ht⟩:=Bool.and_eq_true_iff.mp hp
      have hcert:RecordedRefutation.accepts ((D++[negate C])++[negate (substRow R (FiniteWitness.interpret w))]) p=true:=by
        simpa only [List.append_assoc,List.singleton_append] using hh
      have hv:=scoped_valid (D++[negate C]) s ids _ hs he p hcert
      have hc:=NativeScopedLocalGoal.correct (D++[negate C]) s ids _ hs he p hcert
      have hl:(D++[negate C]).length=D.length+1:=by simp
      rw [hl] at hv hc
      have hi:=ih (NativeScopedLocalGoal.compile (D.length+1) s ids (substRow R (FiniteWitness.interpret w)) p).closedStore ps
        (by rw [hc.2.2];omega) hc.2.1 ht
      intro b hb
      simp only [NativeREDGoalSequence.compile,List.mem_cons] at hb
      rcases hb with rfl|hb
      · exact hv
      · exact hi b hb

theorem packed_goals_valid (ids : Nat→Nat) (i : Nat) (bs : List (Row×NativeScopedLocalGoal.Built))
    (hv : ∀b∈bs,LocalValid (stripLocal b.2)) :
    ∀g∈packGoals ids i bs,LocalValid g.proof := by
  induction bs generalizing i with
  | nil=>simp [packGoals]
  | cons b bs ih=>
    intro g hg
    simp only [packGoals,List.mem_cons] at hg
    rcases hg with rfl|hg
    · exact hv b (by simp)
    · exact ih (i+1) (by intro b hb;exact hv b (by simp [hb])) g hg

theorem step_valid (M guard : Nat) (D : List Row) (s : Store) (ids : Nat→Nat)
    (c : Step) (hs : 0<s.next) (he : Embeds D s ids) (hc : c.accepts M guard D=true) :
    CommandValid (pack ids (NativeRecordedStep.compile D s ids c).action) := by
  cases c with
  | pol R ts=>exact relocated_shape D ids ts R (of_decide_eq_true hc)
  | consequence R p=>
    obtain ⟨hr,hp⟩:=Bool.and_eq_true_iff.mp hc
    exact scoped_valid D s ids R hs he p hp
  | red R w ps=>
    obtain ⟨hpre,hgoals⟩:=Bool.and_eq_true_iff.mp hc
    obtain ⟨hpre,_⟩:=Bool.and_eq_true_iff.mp hpre
    obtain ⟨hr,hw⟩:=Bool.and_eq_true_iff.mp hpre
    exact packed_goals_valid ids 0 _ (goals_valid D R w (push s (negate R))
      (extend ids D.length s.next) (R::D) ps (by change 0<s.next+1;omega)
      (push_embeds D s ids he hs _) hgoals)

theorem compile_valid (M guard : Nat) (D E : List Row) (s : Store) (ids : Nat→Nat)
    (p : Program) (hs : 0<s.next) (he : Embeds D s ids) (hp : check M guard D p=some E) :
    ∀c∈CanonicalScopeKernel.compile D s ids p,CommandValid c := by
  induction p generalizing D s ids with
  | nil=>simp [CanonicalScopeKernel.compile]
  | cons c cs ih=>
    simp only [check] at hp
    split at hp
    · rename_i hc
      have hn:=NativeRecordedStep.correct M guard D s ids c hs he hc
      have ht:=ih (D++[c.row]) _ _ hn.2.2 hn.2.1 hp
      intro x hx
      simp only [CanonicalScopeKernel.compile,List.mem_cons] at hx
      rcases hx with rfl|hx
      · exact step_valid M guard D s ids c hs he hc
      · exact ht x hx
    · contradiction

def EventValid : CanonicalLineParser.Event→Prop
 | .pol ts=>shape ts 0=some 1
 | _=>True

theorem local_events_valid (p:LocalProof) (hv:LocalValid p):
 ∀e∈localEvents p,EventValid e:=by
 intro e he
 simp only [localEvents,List.mem_append,List.mem_singleton] at he
 rcases he with he|rfl
 · obtain ⟨ts,ht,rfl⟩:=List.mem_map.mp he;exact hv ts ht
 · trivial

theorem events_valid (c:CanonicalScopeKernel.Command) (hv:CommandValid c):
 ∀e∈commandEvents c,EventValid e:=by
 cases c with
 | pol ts=>simpa [commandEvents,EventValid] using hv
 | consequence R p=>
   intro e he
   rcases List.mem_cons.mp he with rfl|he
   · trivial
   · exact local_events_valid p hv e he
 | red R w gs=>
   intro e he
   simp only [commandEvents,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at he
   rcases he with (rfl|he)|rfl
   · trivial
   · obtain ⟨g,hg,he⟩:=List.mem_flatMap.mp he
     rcases List.mem_cons.mp he with rfl|he
     · trivial
     · exact local_events_valid g.proof (hv g hg) e he
   · trivial

theorem family (n:Nat) (hn:2≤n):
 ∀e∈(NativeCompatibleFamily.commands n).flatMap commandEvents,EventValid e:=by
 have h:=compile_valid 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id (NativeCompatibleFamily.emitter n)
  (by change 0<_+1;omega) (initial_embeds _) (NativeCompatibleFamily.checked n hn)
 intro e he
 obtain ⟨c,hc,he⟩:=List.mem_flatMap.mp he
 exact events_valid c (h c hc) e he
#print axioms family
end L3Emitter.NativeParserStackShapes

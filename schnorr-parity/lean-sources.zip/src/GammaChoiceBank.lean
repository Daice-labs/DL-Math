import CommonGuardResolve
namespace L3Emitter.GammaChoiceBank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
abbrev Job (n:Nat):=ForcingFieldBank.Job (n+1)
def jobs (n:Nat) (hn:2≤n):=ForcingFieldBank.jobs (n+1) (by omega)
def betaJob {n:Nat} (j:Job n):BetaPort.Job n:=(j,0)
def choice {n:Nat} (j:Job n):Int:=j.1.choice
def hit (n:Nat) (hn:2≤n) (j:Job n):Bit:=HitBranchBinding.hit n hn j.2.parent
def port (n:Nat) (hn:2≤n) (j:Job n) (side:Bool):Bit:=ReceivingEdgeCover.port n hn j.2.parent (if side then 0 else 1)
def edgeRow (n:Nat) (hn:2≤n) (j:Job n) (side:Bool):=clause [-choice j,-sign side (hit n hn j),(port n hn j side).val]
def gammaRow (n:Nat) (hn:2≤n) (j:Job n):=SelectedCategoryRows.gammaRow n hn (betaJob j)

theorem beta_valid (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn):betaJob j∈BetaPort.jobs n hn:=
  List.mem_flatMap.mpr ⟨j,hj,List.mem_map.mpr ⟨0,List.mem_range.mpr (by unfold FamilyNamespace.truthRows;positivity),rfl⟩⟩
theorem parent_valid (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn):j.2.parent∈CategoryPrograms.choices n hn:=
  (ForcingCandidates.wellformed _ _ j.2 ((ForcingFieldBank.job_mem _ _ _ _).mp hj).2.1).1

def edgeTape (n:Nat) (hn:2≤n) (j:Job n) (side:Bool) (D:List Row):=
  CommonGuardResolve.tape D [] [-choice j] [-sign side (hit n hn j),(port n hn j side).val] j.2.parent.lit

theorem edge_check (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn) (side:Bool)
    (D:List Row) (hd:∀R∈ReceivingEdgeBank.result n hn,R∈D):
    polEval (dbOf D) (edgeTape n hn j side D) []=some (edgeRow n hn j side):=by
  have hj':=beta_valid n hn j hj
  have hc:choice j≠0:=BetaAliasValue.choice_valid n hn (betaJob j) hj'
  have hr:=ReceivingEdgeBank.both_ports n hn j.2.parent (parent_valid n hn j hj) side
  apply CommonGuardResolve.checks D [] [-choice j] [-sign side (hit n hn j),(port n hn j side).val] j.2.parent.lit
    (by simp [Valid]) (by simp [Valid,hc]) (by simp [Valid,sign_valid,(port n hn j side).property]) j.2.parent.nonzero
  · exact hd _ (ReceivingEdgeBank.retains n hn _ (HitBranchBank.retains n hn _ (BetaSelectedValue.parent_row n hn (betaJob j) hj')))
  · exact hd _ hr

def rows (n:Nat) (hn:2≤n) (j:Job n):=[gammaRow n hn j,edgeRow n hn j false,edgeRow n hn j true]
def program (n:Nat) (hn:2≤n) (j:Job n) (D:List Row):Program:=
  [(gammaRow n hn j,SelectedCategoryRows.gammaTape n hn (betaJob j) D),
   (edgeRow n hn j false,edgeTape n hn j false D),(edgeRow n hn j true,edgeTape n hn j true D)]

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn)
    (D:List Row) (hd:∀R∈ReceivingEdgeBank.result n hn,R∈D):
    check D (program n hn j D)=some (D++rows n hn j):=by
  have hg:=SelectedCategoryRows.gamma_check n hn (betaJob j) (beta_valid n hn j hj) D
    (fun R h=>hd R (ReceivingEdgeBank.retains n hn R (HitBranchBank.retains n hn R h)))
  have h0:=edge_check n hn j hj false D hd
  have h1:=edge_check n hn j hj true D hd
  have h:=IndependentProgram.check_base D (program n hn j D) (by
    intro cmd hm;simp only [program,List.mem_cons,List.not_mem_nil,or_false] at hm
    rcases hm with rfl|rfl|rfl;exact hg;exact h0;exact h1)
  simpa only [outputs,program,rows,List.map_cons,List.map_nil] using h

def body (n:Nat) (hn:2≤n):=(jobs n hn).flatMap (rows n hn)
def emitted (n:Nat) (hn:2≤n):=(jobs n hn).flatMap fun j=>program n hn j (ReceivingEdgeBank.result n hn)
def result (n:Nat) (hn:2≤n):=ReceivingEdgeBank.result n hn++body n hn

theorem emitted_check (n:Nat) (hn:2≤n):check (ReceivingEdgeBank.result n hn) (emitted n hn)=some (result n hn):=by
  have h:=IndependentProgram.check_base (ReceivingEdgeBank.result n hn) (emitted n hn) (by
    intro cmd hm
    obtain ⟨j,hj,hm⟩:=List.mem_flatMap.mp hm
    simp only [program,List.mem_cons,List.not_mem_nil,or_false] at hm
    rcases hm with rfl|rfl|rfl
    · exact SelectedCategoryRows.gamma_check n hn (betaJob j) (beta_valid n hn j hj) _
        (fun R h=>ReceivingEdgeBank.retains n hn R (HitBranchBank.retains n hn R h))
    · exact edge_check n hn j hj false _ (fun _ h=>h)
    · exact edge_check n hn j hj true _ (fun _ h=>h))
  simpa [emitted,result,body,outputs,program,rows,List.map_flatMap,Function.comp_def] using h

theorem original_to_gamma_choices (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (ReceivingEdgeBank.original_to_receiving n hn) (check_trace _ _ _ (emitted_check n hn))

theorem contains (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn):∀R∈rows n hn j,R∈result n hn:=
  fun R h=>List.mem_append_right _ (List.mem_flatMap.mpr ⟨j,hj,h⟩)
theorem receiving (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn) (side:Bool):edgeRow n hn j side∈result n hn:=by
  apply contains n hn j hj;cases side <;> simp [rows]
theorem gamma (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn):gammaRow n hn j∈result n hn:=contains n hn j hj _ (by simp [rows])

#print axioms original_to_gamma_choices
#print axioms receiving
end L3Emitter.GammaChoiceBank

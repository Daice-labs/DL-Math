import FinalTransferImage
namespace L3Emitter.FinalFunctionSlots
open EREF EREF.GeneralRED REDWitness AliasNetwork RecordedExpressions RecordedExpressionRun FinalOutputDefinitions
variable {base:List Row}
attribute [local irreducible] tabulate tabulateLog FinalOutputDefinitions.out FinalOutputRecorded.selector FinalOutputRecorded.port FinalOutputRecorded.function

def outputs (n:Nat) (hn:2≤n) (z:Net base):=(tabulate (T n) (FinalOutputDefinitions.out n hn) z)
def selectors (n:Nat) (hn:2≤n) (z:Net base):=tabulateLog 2 (fun p=>tabulateLog (W n-1) (FinalOutputRecorded.selector n hn p)) (outputs n hn z).2
def ports (n:Nat) (hn:2≤n) (z:Net base):=tabulateLog 2 (fun p=>tabulateLog (T n) (FinalOutputRecorded.port n hn (outputs n hn z).1 p)) (selectors n hn z).2
def start (n:Nat) (hn:2≤n) (z:Net base) (ab:Fin 4):=
  CoordinateSnapshots.before 4 (fun ab=>forget (FinalOutputRecorded.function n hn ab)) (ports n hn z).2 ab

def first (n:Nat) (hn:2≤n) (ab:Fin 4) (z:Net base):=
  LookupEvaluation.job (LowerTransferImage.wire n hn (.fn (lastRank n) ab.val)) (unary n hn true) (unary n hn false) z
def second (n:Nat) (hn:2≤n) (ab:Fin 4) (z:Net base):=
  LookupEvaluation.job (H n hn) (first n hn ab z).q (if ab.val/2=0 then unary n hn false else unary n hn true)
    (MUX (LowerTransferImage.wire n hn (.fn (lastRank n) ab.val)) (unary n hn true) (unary n hn false) z).2
def third (n:Nat) (hn:2≤n) (ab:Fin 4) (z:Net base):=
  LookupEvaluation.job (OutputPhaseRows.phase n hn) (neg (second n hn ab z).q) (second n hn ab z).q
    (MUX (H n hn) (first n hn ab z).q (if ab.val/2=0 then unary n hn false else unary n hn true)
      (MUX (LowerTransferImage.wire n hn (.fn (lastRank n) ab.val)) (unary n hn true) (unary n hn false) z).2).2

theorem local_members (n:Nat) (hn:2≤n) (ab:Fin 4) (z:Net base):
    first n hn ab z∈(FinalOutputRecorded.function n hn ab z).1.2 ∧
    second n hn ab z∈(FinalOutputRecorded.function n hn ab z).1.2 ∧
    third n hn ab z∈(FinalOutputRecorded.function n hn ab z).1.2:=by
  unfold FinalOutputRecorded.function
  constructor
  · apply LoggedMembership.bind_left;exact List.mem_singleton_self _
  constructor
  · apply LoggedMembership.bind_right;apply LoggedMembership.bind_left;exact List.mem_singleton_self _
  · apply LoggedMembership.bind_right;apply LoggedMembership.bind_right;exact List.mem_singleton_self _

theorem lift_member (n:Nat) (hn:2≤n) (ab:Fin 4) (z:Net base) (j:Job)
    (hj:j∈(FinalOutputRecorded.function n hn ab (start n hn z ab)).1.2):
    j∈(FinalOutputRecorded.construction n hn z).1.2:=by
  unfold FinalOutputRecorded.construction
  apply LoggedMembership.bind_right
  apply LoggedMembership.bind_right
  apply LoggedMembership.bind_right
  apply LoggedMembership.bind_left
  exact LoggedMembership.tabulate_at 4 _ (ports n hn z).2 ab j hj

theorem third_value (n:Nat) (hn:2≤n) (ab:Fin 4) (z:Net base):
    (third n hn ab z).q=(FinalOutputRecorded.function n hn ab z).1.1:=by
  unfold third second first FinalOutputRecorded.function
  rfl

theorem projection (n:Nat) (hn:2≤n) (z:Net base):
    (FinalOutputRecorded.construction n hn z).1.1.functions=
      (tabulateLog 4 (FinalOutputRecorded.function n hn) (ports n hn z).2).1.1:=by
  unfold FinalOutputRecorded.construction ports selectors outputs
  rfl

theorem final_value (n:Nat) (hn:2≤n) (ab:Fin 4):
    (third n hn ab (start n hn (initialNet n hn) ab)).q=(FinalOutputDefinitions.built n hn).1.functions ab:=by
  have hb:=congrArg Prod.fst (congrFun (FinalOutputRecorded.construction_binding n hn) (initialNet n hn))
  have hf:(FinalOutputRecorded.construction n hn (initialNet n hn)).1.1.functions=(FinalOutputDefinitions.built n hn).1.functions:=by
    simpa only [forget,FinalOutputDefinitions.built] using congrArg Data.functions hb
  rw [←hf,projection]
  have h:=CoordinateSnapshots.tabulate_at 4 (fun i=>forget (FinalOutputRecorded.function n hn i)) (ports n hn (initialNet n hn)).2 ab
  have hlog:=tabulate_binding (base:=FinalOutputDefinitions.base n hn) 4 (FinalOutputRecorded.function n hn)
  have hh:(tabulateLog 4 (FinalOutputRecorded.function n hn) (ports n hn (initialNet n hn)).2).1.1 ab=
      (FinalOutputRecorded.function n hn ab (start n hn (initialNet n hn) ab)).1.1:=by
    change (forget (tabulateLog 4 (FinalOutputRecorded.function n hn)) (ports n hn (initialNet n hn)).2).1 ab=_
    rw [hlog]
    exact h
  rw [hh]
  exact third_value n hn ab _

theorem ready (n:Nat) (hn:2≤n) (ab:Fin 4):
    let z:=start n hn (initialNet n hn) ab
    RecordedExpressions.Ready (FinalOutputDefinitions.result n hn) (first n hn ab z) ∧
    RecordedExpressions.Ready (FinalOutputDefinitions.result n hn) (second n hn ab z) ∧
    RecordedExpressions.Ready (FinalOutputDefinitions.result n hn) (third n hn ab z):=by
  have h:=local_members n hn ab (start n hn (initialNet n hn) ab)
  exact ⟨FinalOutputRecorded.jobs_ready n hn _ (lift_member n hn ab _ _ h.1),
    FinalOutputRecorded.jobs_ready n hn _ (lift_member n hn ab _ _ h.2.1),
    FinalOutputRecorded.jobs_ready n hn _ (lift_member n hn ab _ _ h.2.2)⟩
#print axioms final_value
#print axioms ready
end L3Emitter.FinalFunctionSlots

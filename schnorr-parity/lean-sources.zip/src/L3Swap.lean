/-
The input-wire swap witness `swap(F, a, b)` of `project/emitter/frontend.py` (ports=False):

    jmap(j) = b if j == a else a if j == b else j
    xm(x)   = x with bits (k-1-a) and (k-1-b) exchanged
    sel(t,p,j)  ↦ sel(t,p,jmap(j))      port(t,p,x) ↦ port(t,p,xm(x))
    val(t,x)    ↦ val(t,xm(x))          fn(t,ab)    ↦ fn(t,ab)   (unchanged)

as a total map on variable ids, defined by decoding the id (bounded search over the
index tables) so that it can be applied literally to every row of the database.
This file: the id-level map, the injectivity/decoding facts, and the bit facts of xm.
-/
import L3FamilyBytes

namespace L3
namespace Fam

/-! ### Index tables and decoding -/

def selIndex (F : Fam) : List (Nat × Nat × Nat) :=
  (List.range F.s).flatMap fun t => (List.range 2).flatMap fun p =>
    (List.range (F.k + t)).map fun j => (t, p, j)

def portIndex (F : Fam) : List (Nat × Nat × Nat) :=
  (List.range F.s).flatMap fun t => (List.range 2).flatMap fun p =>
    (List.range F.T).map fun x => (t, p, x)

def valIndex (F : Fam) : List (Nat × Nat) :=
  (List.range F.s).flatMap fun t => (List.range F.T).map fun x => (t, x)

theorem mem_selIndex (F : Fam) (t p j : Nat) :
    (t, p, j) ∈ F.selIndex ↔ t < F.s ∧ p < 2 ∧ j < F.k + t := by
  unfold selIndex
  simp only [List.mem_flatMap, List.mem_range, List.mem_map, Prod.mk.injEq]
  constructor
  · rintro ⟨t', ht', p', hp', j', hj', rfl, rfl, rfl⟩; exact ⟨ht', hp', hj'⟩
  · rintro ⟨ht, hp, hj⟩; exact ⟨t, ht, p, hp, j, hj, rfl, rfl, rfl⟩

theorem mem_portIndex (F : Fam) (t p x : Nat) :
    (t, p, x) ∈ F.portIndex ↔ t < F.s ∧ p < 2 ∧ x < F.T := by
  unfold portIndex
  simp only [List.mem_flatMap, List.mem_range, List.mem_map, Prod.mk.injEq]
  constructor
  · rintro ⟨t', ht', p', hp', x', hx', rfl, rfl, rfl⟩; exact ⟨ht', hp', hx'⟩
  · rintro ⟨ht, hp, hx⟩; exact ⟨t, ht, p, hp, x, hx, rfl, rfl, rfl⟩

theorem mem_valIndex (F : Fam) (t x : Nat) :
    (t, x) ∈ F.valIndex ↔ t < F.s ∧ x < F.T := by
  unfold valIndex
  simp only [List.mem_flatMap, List.mem_range, List.mem_map, Prod.mk.injEq]
  constructor
  · rintro ⟨t', ht', x', hx', rfl, rfl⟩; exact ⟨ht', hx'⟩
  · rintro ⟨ht, hx⟩; exact ⟨t, ht, x, hx, rfl, rfl⟩

/-- the selector block of gate t starts after `off t = 2tk + t(t−1)` ids -/
def off (F : Fam) (t : Nat) : Nat := 2 * t * F.k + t * (t - 1)

theorem sel_eq_off (F : Fam) (t p j : Nat) : F.sel t p j = F.off t + p * (F.k + t) + j + 1 := by
  unfold sel off; omega

theorem off_succ (F : Fam) (t : Nat) : F.off (t + 1) = F.off t + 2 * (F.k + t) := by
  unfold off
  cases t with
  | zero => simp
  | succ t => simp only [Nat.add_sub_cancel]; grind

theorem off_mono (F : Fam) (t t' : Nat) (h : t ≤ t') : F.off t ≤ F.off t' := by
  induction t' with
  | zero => have : t = 0 := by omega
            subst this; exact Nat.le_refl _
  | succ t' ih =>
    rcases Nat.lt_or_eq_of_le h with h | h
    · have := ih (by omega); rw [off_succ]; omega
    · subst h; exact Nat.le_refl _

theorem off_S (F : Fam) : F.off F.s = F.S := by
  unfold off S
  cases F.s with
  | zero => simp
  | succ s => simp only [Nat.add_sub_cancel]; grind

/-- sel is injective on the index table -/
theorem sel_inj (F : Fam) (t p j t' p' j' : Nat)
    (ht : t < F.s) (hp : p < 2) (hj : j < F.k + t)
    (ht' : t' < F.s) (hp' : p' < 2) (hj' : j' < F.k + t')
    (h : F.sel t p j = F.sel t' p' j') : t = t' ∧ p = p' ∧ j = j' := by
  rw [sel_eq_off, sel_eq_off] at h
  have hlo : p * (F.k + t) + j < 2 * (F.k + t) := by
    have : p * (F.k + t) ≤ 1 * (F.k + t) := Nat.mul_le_mul_right _ (by omega)
    omega
  have hlo' : p' * (F.k + t') + j' < 2 * (F.k + t') := by
    have : p' * (F.k + t') ≤ 1 * (F.k + t') := Nat.mul_le_mul_right _ (by omega)
    omega
  have htt : t = t' := by
    rcases Nat.lt_trichotomy t t' with hlt | heq | hgt
    · have h1 := F.off_succ t
      have h2 := F.off_mono (t + 1) t' hlt
      omega
    · exact heq
    · have h1 := F.off_succ t'
      have h2 := F.off_mono (t' + 1) t hgt
      omega
  subst htt
  have hpp : p = p' := by
    rcases Nat.lt_or_ge p 1 with hp0 | hp1 <;> rcases Nat.lt_or_ge p' 1 with hp0' | hp1'
    · omega
    · have : p = 0 := by omega
      have : p' = 1 := by omega
      subst_vars; simp at h; omega
    · have : p = 1 := by omega
      have : p' = 0 := by omega
      subst_vars; simp at h; omega
    · omega
  subst hpp
  exact ⟨rfl, rfl, by omega⟩

theorem port_inj (F : Fam) (t p x t' p' x' : Nat)
    (hp : p < 2) (hx : x < F.T) (hp' : p' < 2) (hx' : x' < F.T)
    (h : F.port t p x = F.port t' p' x') : t = t' ∧ p = p' ∧ x = x' := by
  unfold port at h
  have hq : 2 * t + p = 2 * t' + p' := by
    rcases Nat.lt_trichotomy (2 * t + p) (2 * t' + p') with hlt | heq | hgt
    · have : (2 * t + p + 1) * F.T ≤ (2 * t' + p') * F.T := Nat.mul_le_mul_right _ hlt
      rw [Nat.add_mul] at this; omega
    · exact heq
    · have : (2 * t' + p' + 1) * F.T ≤ (2 * t + p) * F.T := Nat.mul_le_mul_right _ hgt
      rw [Nat.add_mul] at this; omega
  have htt : t = t' := by omega
  subst htt
  have hpp : p = p' := by omega
  subst hpp
  exact ⟨rfl, rfl, by rw [hq] at h; omega⟩

theorem val_inj (F : Fam) (t x t' x' : Nat) (hx : x < F.T) (hx' : x' < F.T)
    (h : F.val t x = F.val t' x') : t = t' ∧ x = x' := by
  unfold val at h
  have htt : t = t' := by
    rcases Nat.lt_trichotomy t t' with hlt | heq | hgt
    · have : (t + 1) * F.T ≤ t' * F.T := Nat.mul_le_mul_right _ hlt
      rw [Nat.add_mul] at this; omega
    · exact heq
    · have : (t' + 1) * F.T ≤ t * F.T := Nat.mul_le_mul_right _ hgt
      rw [Nat.add_mul] at this; omega
  subst htt
  exact ⟨rfl, by omega⟩

/-! the four id kinds occupy disjoint ranges -/

theorem sel_range (F : Fam) (t p j : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k + t) :
    1 ≤ F.sel t p j ∧ F.sel t p j ≤ F.S :=
  ⟨F.sel_pos t p j, F.sel_le_S t p j ht (by omega) hj⟩

theorem fn_range (F : Fam) (t ab : Nat) (ht : t < F.s) (hab : ab < 4) :
    F.S + 1 ≤ F.fn t ab ∧ F.fn t ab ≤ F.S + 4 * F.s := by
  unfold fn; constructor
  · omega
  · exact F.fn_le t ab ht hab

theorem port_range (F : Fam) (t p x : Nat) (ht : t < F.s) (hp : p < 2) (hx : x < F.T) :
    F.S + 4 * F.s + 1 ≤ F.port t p x ∧ F.port t p x ≤ F.S + 4 * F.s + 2 * F.s * F.T := by
  constructor
  · unfold port; omega
  · exact F.port_le t p x ht (by omega) hx

theorem val_range (F : Fam) (t x : Nat) (ht : t < F.s) (hx : x < F.T) :
    F.S + 4 * F.s + 2 * F.s * F.T + 1 ≤ F.val t x ∧ F.val t x ≤ F.V := by
  constructor
  · unfold val; omega
  · exact F.val_le t x ht hx

/-- decode a selector id (first match in the table; unique by `sel_inj`) -/
def decodeSel (F : Fam) (v : Nat) : Option (Nat × Nat × Nat) :=
  F.selIndex.find? fun i => F.sel i.1 i.2.1 i.2.2 == v

def decodePort (F : Fam) (v : Nat) : Option (Nat × Nat × Nat) :=
  F.portIndex.find? fun i => F.port i.1 i.2.1 i.2.2 == v

def decodeVal (F : Fam) (v : Nat) : Option (Nat × Nat) :=
  F.valIndex.find? fun i => F.val i.1 i.2 == v

theorem decodeSel_sel (F : Fam) (t p j : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k + t) :
    F.decodeSel (F.sel t p j) = some (t, p, j) := by
  unfold decodeSel
  have hmem : (t, p, j) ∈ F.selIndex := (F.mem_selIndex t p j).mpr ⟨ht, hp, hj⟩
  have hsome : (F.selIndex.find? fun i => F.sel i.1 i.2.1 i.2.2 == F.sel t p j).isSome := by
    rw [List.find?_isSome]; exact ⟨(t, p, j), hmem, by simp⟩
  obtain ⟨⟨t', p', j'⟩, hfind⟩ := Option.isSome_iff_exists.mp hsome
  have hm' := List.mem_of_find?_eq_some hfind
  have hp' := List.find?_some hfind
  rw [F.mem_selIndex] at hm'
  simp only [beq_iff_eq] at hp'
  obtain ⟨rfl, rfl, rfl⟩ := F.sel_inj t' p' j' t p j hm'.1 hm'.2.1 hm'.2.2 ht hp hj hp'
  exact hfind

theorem decodePort_port (F : Fam) (t p x : Nat) (ht : t < F.s) (hp : p < 2) (hx : x < F.T) :
    F.decodePort (F.port t p x) = some (t, p, x) := by
  unfold decodePort
  have hmem : (t, p, x) ∈ F.portIndex := (F.mem_portIndex t p x).mpr ⟨ht, hp, hx⟩
  have hsome : (F.portIndex.find? fun i => F.port i.1 i.2.1 i.2.2 == F.port t p x).isSome := by
    rw [List.find?_isSome]; exact ⟨(t, p, x), hmem, by simp⟩
  obtain ⟨⟨t', p', x'⟩, hfind⟩ := Option.isSome_iff_exists.mp hsome
  have hm' := List.mem_of_find?_eq_some hfind
  have hp' := List.find?_some hfind
  rw [F.mem_portIndex] at hm'
  simp only [beq_iff_eq] at hp'
  obtain ⟨rfl, rfl, rfl⟩ := F.port_inj t' p' x' t p x hm'.2.1 hm'.2.2 hp hx hp'
  exact hfind

theorem decodeVal_val (F : Fam) (t x : Nat) (ht : t < F.s) (hx : x < F.T) :
    F.decodeVal (F.val t x) = some (t, x) := by
  unfold decodeVal
  have hmem : (t, x) ∈ F.valIndex := (F.mem_valIndex t x).mpr ⟨ht, hx⟩
  have hsome : (F.valIndex.find? fun i => F.val i.1 i.2 == F.val t x).isSome := by
    rw [List.find?_isSome]; exact ⟨(t, x), hmem, by simp⟩
  obtain ⟨⟨t', x'⟩, hfind⟩ := Option.isSome_iff_exists.mp hsome
  have hm' := List.mem_of_find?_eq_some hfind
  have hp' := List.find?_some hfind
  rw [F.mem_valIndex] at hm'
  simp only [beq_iff_eq] at hp'
  obtain ⟨rfl, rfl⟩ := F.val_inj t' x' t x hm'.2 hx hp'
  exact hfind

/-- a non-selector id (outside `1..S`) decodes to none -/
theorem decodeSel_none (F : Fam) (v : Nat) (hv : F.S < v) : F.decodeSel v = none := by
  unfold decodeSel
  rw [List.find?_eq_none]
  intro ⟨t, p, j⟩ hm
  rw [F.mem_selIndex] at hm
  have := F.sel_le_S t p j hm.1 (by omega) hm.2.2
  simp only [beq_iff_eq]; omega

theorem decodePort_none (F : Fam) (v : Nat) (hv : v ≤ F.S + 4 * F.s ∨ F.S + 4 * F.s + 2 * F.s * F.T < v) :
    F.decodePort v = none := by
  unfold decodePort
  rw [List.find?_eq_none]
  intro ⟨t, p, x⟩ hm
  rw [F.mem_portIndex] at hm
  have := F.port_range t p x hm.1 hm.2.1 hm.2.2
  simp only [beq_iff_eq]; omega

theorem decodeVal_none (F : Fam) (v : Nat) (hv : v ≤ F.S + 4 * F.s + 2 * F.s * F.T) :
    F.decodeVal v = none := by
  unfold decodeVal
  rw [List.find?_eq_none]
  intro ⟨t, x⟩ hm
  rw [F.mem_valIndex] at hm
  have := F.val_range t x hm.1 hm.2
  simp only [beq_iff_eq]; omega

/-! ### The bit swap xm and the index swap jmap -/

def jmap (a b j : Nat) : Nat := if j = a then b else if j = b then a else j

theorem jmap_jmap (a b j : Nat) : jmap a b (jmap a b j) = j := by
  unfold jmap; split <;> split <;> simp_all <;> omega

theorem jmap_lt (a b j n : Nat) (ha : a < n) (hb : b < n) (hj : j < n) : jmap a b j < n := by
  unfold jmap; split <;> (try split) <;> omega

theorem jmap_a (a b : Nat) : jmap a b a = b := by simp [jmap]
theorem jmap_b (a b : Nat) : jmap a b b = a := by
  unfold jmap; split <;> simp_all
theorem jmap_other (a b j : Nat) (h1 : j ≠ a) (h2 : j ≠ b) : jmap a b j = j := by
  simp [jmap, h1, h2]

/-- bit position of input wire j (Python `k-1-j`) -/
def bitPos (F : Fam) (j : Nat) : Nat := F.k - 1 - j

/-- `xm`: exchange the bits of wires a and b (the Python `x ^ ((va^vb)<<..) ^ ((va^vb)<<..)`) -/
def xm (F : Fam) (a b x : Nat) : Nat :=
  if x.testBit (F.bitPos a) = x.testBit (F.bitPos b) then x
  else x ^^^ 2 ^ F.bitPos a ^^^ 2 ^ F.bitPos b

theorem testBit_xm (F : Fam) (a b x i : Nat) :
    (F.xm a b x).testBit i =
      if i = F.bitPos a then x.testBit (F.bitPos b)
      else if i = F.bitPos b then x.testBit (F.bitPos a)
      else x.testBit i := by
  unfold xm
  split
  · rename_i heq
    split
    · subst_vars; exact heq
    · split
      · subst_vars; exact heq.symm
      · rfl
  · rename_i hne
    have hab : F.bitPos a ≠ F.bitPos b := fun h => hne (by rw [h])
    simp only [Nat.testBit_xor, Nat.testBit_two_pow]
    split
    · subst_vars
      simp only [decide_true, Ne.symm hab, decide_false]
      cases hx : x.testBit (F.bitPos a) <;> cases hy : x.testBit (F.bitPos b) <;> simp_all
    · split
      · subst_vars
        simp only [decide_true, hab, decide_false]
        cases hx : x.testBit (F.bitPos a) <;> cases hy : x.testBit (F.bitPos b) <;> simp_all
      · rename_i h1 h2
        simp [Ne.symm h1, Ne.symm h2]

theorem xm_lt (F : Fam) (a b x : Nat) (ha : a < F.k) (hb : b < F.k) (hx : x < F.T) :
    F.xm a b x < F.T := by
  unfold xm
  split
  · exact hx
  · unfold T at *
    apply Nat.xor_lt_two_pow (Nat.xor_lt_two_pow hx ?_) ?_
    · exact Nat.pow_lt_pow_right (by decide) (by unfold bitPos; omega)
    · exact Nat.pow_lt_pow_right (by decide) (by unfold bitPos; omega)

theorem xm_xm (F : Fam) (a b x : Nat) : F.xm a b (F.xm a b x) = x := by
  apply Nat.eq_of_testBit_eq
  intro i
  simp only [testBit_xm]
  by_cases hab : F.bitPos a = F.bitPos b
  · simp only [hab]
    by_cases h2 : i = F.bitPos b <;> simp [h2]
  · by_cases h1 : i = F.bitPos a <;> by_cases h2 : i = F.bitPos b <;>
      simp [h1, h2, hab, Ne.symm hab]

/-- the input bits of the swapped point are the swapped input bits -/
theorem inputBit_xm (F : Fam) (a b j x : Nat) (ha : a < F.k) (hb : b < F.k) (hj : j < F.k) :
    F.inputBit j (F.xm a b x) = F.inputBit (jmap a b j) x := by
  unfold inputBit
  rw [testBit_xm]
  unfold bitPos jmap
  by_cases h1 : j = a
  · subst h1; simp
  · by_cases h2 : j = b
    · subst h2; simp [h1]
      have : F.k - 1 - j ≠ F.k - 1 - a := by omega
      simp [this]
    · have e1 : F.k - 1 - j ≠ F.k - 1 - a := by omega
      have e2 : F.k - 1 - j ≠ F.k - 1 - b := by omega
      simp [h1, h2, e1, e2]

/-! ### The id map σ of swap(F, a, b) -/

def swapId (F : Fam) (a b : Nat) (v : Nat) : Nat :=
  match F.decodeSel v with
  | some (t, p, j) => F.sel t p (jmap a b j)
  | none =>
    match F.decodePort v with
    | some (t, p, x) => F.port t p (F.xm a b x)
    | none =>
      match F.decodeVal v with
      | some (t, x) => F.val t (F.xm a b x)
      | none => v

theorem swapId_sel (F : Fam) (a b t p j : Nat) (ht : t < F.s) (hp : p < 2) (hj : j < F.k + t) :
    F.swapId a b (F.sel t p j) = F.sel t p (jmap a b j) := by
  unfold swapId; rw [F.decodeSel_sel t p j ht hp hj]

theorem swapId_fn (F : Fam) (a b t ab : Nat) (ht : t < F.s) (hab : ab < 4) :
    F.swapId a b (F.fn t ab) = F.fn t ab := by
  unfold swapId
  have hr := F.fn_range t ab ht hab
  rw [F.decodeSel_none _ (by omega), F.decodePort_none _ (Or.inl (by omega)),
    F.decodeVal_none _ (by omega)]

theorem swapId_port (F : Fam) (a b t p x : Nat) (ht : t < F.s) (hp : p < 2) (hx : x < F.T) :
    F.swapId a b (F.port t p x) = F.port t p (F.xm a b x) := by
  unfold swapId
  have hr := F.port_range t p x ht hp hx
  rw [F.decodeSel_none _ (by omega), F.decodePort_port t p x ht hp hx]

theorem swapId_val (F : Fam) (a b t x : Nat) (ht : t < F.s) (hx : x < F.T) :
    F.swapId a b (F.val t x) = F.val t (F.xm a b x) := by
  unfold swapId
  have hr := F.val_range t x ht hx
  rw [F.decodeSel_none _ (by omega), F.decodePort_none _ (Or.inr (by omega)),
    F.decodeVal_val t x ht hx]

/-- σ never produces id 0 on a well-formed id -/
theorem swapId_pos (F : Fam) (a b v : Nat) (hv : 1 ≤ v) : 1 ≤ F.swapId a b v := by
  unfold swapId
  split
  · exact F.sel_pos _ _ _
  · split
    · exact F.port_pos _ _ _
    · split
      · exact F.val_pos _ _
      · exact hv

end Fam
end L3

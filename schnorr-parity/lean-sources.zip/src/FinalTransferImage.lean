import FinalPrimaryTransfers
namespace L3Emitter.FinalTransferImage
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL FamilyNamespace FamilyRows
open FinalOutputDefinitions FinalTransferContext
attribute [local irreducible] FinalPrimaryTransfers.result LowerTransferImage.wire

theorem primary (n:Nat) (hn:2≤n) (p j x:Nat) (hp:p<2) (hj:j<n) (hx:x<truthRows n):
    FinalLowerImage.image n hn (InputSwap.inputTransfer n (lastRank n) p j x)∈FinalPrimaryTransfers.result n hn:=by
  have hi:j<W n-1:=by unfold W AliasAssembly.width RankConstruction.width;omega
  have h:=FinalPrimaryTransfers.contains n hn ⟨p,hp⟩ ⟨j,hj⟩ ⟨x,hx⟩
  simpa only [FinalLowerImage.image,InputSwap.inputTransfer,List.map_cons,List.map_nil,FinalLowerImage.wire,
    ↓reduceIte,dif_pos hp,dif_pos hi,dif_pos hx,FinalPrimaryTransfers.row,RawLowerTransfers.primaryRow,
    targetSelector,targetPort,FinalPrimaryTransfers.index,FinalPrimaryTransfers.truth,PrimaryInputLinks.d,
    RemainingInput.value,Nat.add_sub_cancel,clause,sign,Bool.false_eq_true,↓reduceIte] using h

theorem gate (n:Nat) (hn:2≤n) (p g x:Nat) (hp:p<2) (hg:g<lastRank n) (hx:x<truthRows n) (b:Bool):
    FinalLowerImage.image n hn (InputSwap.gateTransfer n (lastRank n) p g x b)∈FinalPrimaryTransfers.result n hn:=by
  have hi:n+g<W n-1:=by rw [←FinalSelectorSources.width_binding n hn];omega
  have hw:n+g<AliasAssembly.width (n+1):=by unfold W at hi;omega
  have he:g≠lastRank n:=Nat.ne_of_lt hg
  have h:=FinalTransferBank.contains n hn ⟨p,hp⟩ ⟨n+g,hi⟩ ⟨x,hx⟩ b
  have h':FinalLowerImage.image n hn (InputSwap.gateTransfer n (lastRank n) p g x b)∈FinalTransferBank.result n hn:=by
    cases b <;> simpa only [FinalLowerImage.image,InputSwap.gateTransfer,List.map_cons,List.map_nil,
      FinalLowerImage.wire,↓reduceIte,dif_pos hp,dif_pos hi,dif_pos hx,if_neg he,LowerTransferImage.wire,dif_pos hw,
      TransferMuxPOL.row,targetSelector,targetPort,FinalTransferContext.value,coord,GuardedVectorTransport.signed,sign,
      Bool.false_eq_true,Bool.not_false,Bool.not_true,neg_neg,clause] using h
  unfold FinalPrimaryTransfers.result
  exact List.mem_append_left _ h'

theorem earlier_kept (n:Nat) (hn:2≤n):∀R∈FinalOutputDefinitions.result n hn,R∈FinalPrimaryTransfers.result n hn:=by
  unfold FinalPrimaryTransfers.result
  exact fun R h=>List.mem_append_left _ (FinalTransferBank.retained n hn R (definitions_kept n hn R h))

theorem all_transfer_images (n:Nat) (hn:2≤n) (r:Spec) (hr:r∈OriginalEncoding.transfersBlock n (3*n-4)):
    FinalLowerImage.image n hn r∈FinalPrimaryTransfers.result n hn:=by
  rcases (OriginalEncoding.transfers_mem ..).mp hr with ⟨t,p,j,x,ht,hp,hj,hx,rfl⟩|⟨t,p,g,x,b,ht,hp,hg,hx,rfl⟩
  · by_cases he:t=lastRank n
    · subst t;exact primary n hn p j x hp hj hx
    · apply earlier_kept
      apply FinalLowerEarlier.input_transfer n hn t p j x _ hp hj hx
      unfold lastRank RankConstruction.width at he ⊢;omega
  · by_cases he:t=lastRank n
    · subst t;exact gate n hn p g x hp hg hx b
    · apply earlier_kept
      apply FinalLowerEarlier.gate_transfer n hn t p g x b _ hp hg hx
      unfold lastRank RankConstruction.width at he ⊢;omega
#print axioms all_transfer_images
end L3Emitter.FinalTransferImage

import ConstructionFrontendDefinitionCount

namespace L3Emitter.ConstructionFrontendCoverageCount
open EREF EREF.GeneralRED L3 L3.Fam ConstructionFrontendCountTools

/-- Exact cost of the builder's split tree, including the joining line. -/
theorem split_cost {m : Nat} (t : StI m) (c vs : List Int) :
    state (t.split c vs)+1=state t+2^(vs.length+1) := by
  induction vs generalizing t c with
  | nil => change state (t.rup c)+1=_;rw [rup_cost];simp
  | cons v vs ih =>
    change state (((t.split (c++[v]) vs).split (c++[-v]) vs).rup c)+1=_
    rw [rup_cost]
    have h0:=ih t (c++[v])
    have h1:=ih (t.split (c++[v]) vs) (c++[-v])
    simp only [List.length_cons,pow_succ]
    simp only [pow_succ] at h0 h1
    omega

theorem split_bound {m : Nat} (t : StI m) (c vs : List Int) :
    state (t.split c vs)≤state t+2^(vs.length+1) := by
  have h:=split_cost t c vs;omega

theorem fold_on {S A : Type} (cost : S→Nat) (step : S→A→S) (xs : List A)
    (s : S) (B : Nat) (h : ∀s a,a∈xs→cost (step s a)≤cost s+B) :
    cost (xs.foldl step s)≤cost s+xs.length*B := by
  induction xs generalizing s with
  | nil => simp
  | cons a xs ih =>
    have ht:=ih (step s a) (fun t b hb=>h t b (by simp [hb]))
    simp only [List.foldl_cons,List.length_cons]
    exact ht.trans ((Nat.add_le_add_right (h s a (by simp)) _).trans_eq (by ring))

variable (F : Fam)

theorem port (hm : 1≤F.V) (g bit cb : Nat) (t : StI F.V) (p : Nat) :
    state (F.portEqStep hm g bit cb t p)≤state t+4*(F.k+g)+6 := by
  let q:=(t.EQ hm (F.port g p (F.bitX bit):Int) (F.port g p (F.bitY bit):Int)).1
  let u:=(t.EQ hm (F.port g p (F.bitX bit):Int) (F.port g p (F.bitY bit):Int)).2
  let guard : List Int := [(t.s.A:Int),-(cb:Int),-(t.s.live g:Int)]
  let step := fun v:StI F.V=>fun j:Nat=>v.split
    (guard++[-(F.sel g p j:Int),(q:Int)]) [(F.port g p (F.bitX bit):Int)]
  have h:=fold_cost state step (List.range' 1 (F.k+g-1)) u 4 (by
    intro v j
    simpa only [List.length_cons,List.length_nil] using split_bound v
      (guard++[-(F.sel g p j:Int),(q:Int)]) [(F.port g p (F.bitX bit):Int)])
  have he:state u=state t+4 := eq_cost hm t _ _
  change state ((((List.range' 1 (F.k+g-1)).foldl step u).rup _).rup _)≤_
  rw [rup_cost,rup_cost]
  simp only [List.length_range'] at h
  omega

def gateCap (F : Fam) := 8*(F.k+F.s)+80

theorem gate (hm : 1≤F.V) (bit cb : Nat) (t : StI F.V) (g : Nat) (hg : g<F.s) :
    state (F.veqStep hm bit cb t g)≤state t+gateCap F := by
  let e:=t.EQ hm (F.val g (F.bitX bit):Int) (F.val g (F.bitY bit):Int)
  let u:=e.2.setVeq (fun g' b'=>if g'=g ∧ b'=bit then e.1 else e.2.s.veq g' b')
  have he:state u=state t+4 := eq_cost hm t _ _
  unfold Fam.veqStep
  split
  · change state (u.split _ [(F.val g (F.bitX bit):Int)])≤_
    have h:=split_bound u [-(cb:Int),(e.1:Int)] [(F.val g (F.bitX bit):Int)]
    change state (u.split [-(cb:Int),(e.1:Int)] [(F.val g (F.bitX bit):Int)])≤_
    simp only [List.length_cons,List.length_nil] at h
    unfold gateCap;omega
  · let v:=([0,1]:List Nat).foldl (F.portEqStep hm g bit cb) u
    have h:=fold_cost state (F.portEqStep hm g bit cb) [0,1] u (4*(F.k+g)+6)
      (port F hm g bit cb)
    change state v≤state u+2*(4*(F.k+g)+6) at h
    let C:List Int := [(u.s.A:Int),-(cb:Int),-(u.s.live g:Int)]++[(e.1:Int)]
    let vs:List Int := [(F.port g 0 (F.bitX bit):Int),(F.port g 0 (F.bitY bit):Int),
      (F.port g 1 (F.bitX bit):Int),(F.port g 1 (F.bitY bit):Int),(F.val g (F.bitX bit):Int)]
    have hsp:=split_bound v C vs
    change state (v.split C vs)≤_
    change state (v.split C vs)≤state v+64 at hsp
    unfold gateCap
    omega

theorem bit (hm : 1≤F.V) (acc : StI F.V×List Int) (b : Nat) :
    state (F.bitStep hm acc b).1≤state acc.1+F.s*gateCap F+5 := by
  let e:=acc.1.EQ hm (F.fn 0 b:Int) (F.fn 0 (b+2):Int)
  let u:=(List.range F.s).foldl (F.veqStep hm b e.1) e.2
  have h:=fold_on state (F.veqStep hm b e.1) (List.range F.s) e.2 (gateCap F)
    (by intro t g hg;exact gate F hm b e.1 t g (List.mem_range.mp hg))
  have he:state e.2=state acc.1+4 := eq_cost hm acc.1 _ _
  change state (u.rup [(u.s.A:Int),-(e.1:Int)])≤_
  rw [rup_cost]
  simp only [List.length_range] at h
  change state u≤state e.2+F.s*gateCap F at h
  omega

theorem stage5 (hm : 1≤F.V) (t : StI F.V) :
    state (F.stage5 hm t)≤state t+2*F.s*gateCap F+18 := by
  let u:=([0,1]:List Nat).foldl (F.bitStep hm) (t,[])
  have h:=fold_cost (fun a:StI F.V×List Int=>state a.1) (F.bitStep hm)
    [0,1] (t,[]) (F.s*gateCap F+5) (fun a b=>by simpa only [Nat.add_assoc] using bit F hm a b)
  change state u.1≤state t+2*(F.s*gateCap F+5) at h
  have hsp:=split_bound u.1 u.2 [(F.fn 0 0:Int),(F.fn 0 1:Int)]
  change state ((u.1.split u.2 [(F.fn 0 0:Int),(F.fn 0 1:Int)]).rup _)≤_
  rw [rup_cost]
  have hx:=split_cost u.1 u.2 [(F.fn 0 0:Int),(F.fn 0 1:Int)]
  change state (u.1.split u.2 [(F.fn 0 0:Int),(F.fn 0 1:Int)])+1=state u.1+8 at hx
  nlinarith

#print axioms stage5
end L3Emitter.ConstructionFrontendCoverageCount

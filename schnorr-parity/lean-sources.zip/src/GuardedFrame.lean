import REDFrame
namespace L3Emitter.GuardedFrame
open EREF EREF.GeneralRED REDWitness

def weaken (R:Row) (a:Nat) (l:Int):Row:=add R (multiply (litAxiom l) a)

theorem canonical_weaken (R:Row) (a:Nat) (l:Int):Canonical (weaken R a l):=canonical_add _ _

theorem val_weaken (R:Row) (hR:Canonical R) (a:Nat) (l:Int) (hl:l≠0) (α:Val):
    (weaken R a l).val α=R.val α+(a:Int)*litVal α l:=by
  rw [weaken,val_add R _ hR (canonical_multiply _ _),val_multiply _ (canonical_litAxiom _) a α,val_litAxiom l hl]

theorem negate_cancel (R:Row) (hR:Canonical R) (a:Nat) (l:Int) (hl:l≠0):
    add (negate (weaken R a l)) (multiply (litAxiom l) a)=negate R:=by
  apply canonical_ext _ _ (canonical_add _ _) (canonical_negate _)
  intro α
  rw [val_add _ _ (canonical_negate _) (canonical_multiply _ _),
    val_negate (weaken R a l) (canonical_weaken R a l),val_weaken R hR a l hl,
    val_multiply _ (canonical_litAxiom _) a α,val_litAxiom l hl,val_negate R hR]
  ring

def cancelTokens (goal a:Nat) (l:Int):List Tok:=[.ref goal,.lit l,.mul a,.add]

theorem cancel_checks (db:Nat→Option Row) (goal a:Nat) (l:Int) (R:Row)
    (hR:Canonical R) (ha:0<a) (hl:l≠0) (hg:db goal=some (negate (weaken R a l))):
    polEval db (cancelTokens goal a l) []=some (negate R):=by
  simp only [cancelTokens,polEval,hg,if_pos hl,if_pos ha]
  rw [negate_cancel R hR a l hl]

theorem subst_weaken (R:Row) (hR:Canonical R) (ω:Witness) (a:Nat) (l:Int) (hl:l≠0)
    (hf:∀α,applyWitness ω α l.natAbs=α l.natAbs):
    substRow (weaken R a l) ω=weaken (substRow R ω) a l:=by
  apply canonical_ext _ _ (canonical_substRow _ _) (canonical_weaken _ _ _)
  intro α
  rw [val_substRow,val_weaken R hR a l hl,val_weaken _ (canonical_substRow _ _) a l hl,val_substRow]
  unfold litVal
  rw [hf α]

/-- Exactly four POL tokens turn the negation of a weakened goal into the
negation of the lower goal. The lower local refutation is then copied once. -/
theorem obligation (D frame:List Row) (C R G:Row) (ω:Witness) (a:Nat) (l:Int)
    (hr:R∈D) (ha:0<a) (hl:l≠0)
    (hg:substRow G ω=weaken (substRow R ω) a l) (ho:SequenceObligations D C ω):
    Refutation ((frame++D)++[negate C,negate (substRow G ω)]):=by
  let E:=(frame++D)++[negate C,negate (substRow G ω)]
  have hgoal:dbOf E ((frame++D).length+2)=some (negate (weaken (substRow R ω) a l)):=by
    rw [←hg]
    exact db_neg_right _ _ _
  have he:=cancel_checks (dbOf E) ((frame++D).length+2) a l (substRow R ω) (canonical_substRow _ _) ha hl hgoal
  apply ReferenceTransport.discharge E (negate (substRow R ω)) _ he
  apply ReferenceTransport.refutation_subset _ _ _ (ho R (List.mem_cons_of_mem _ hr))
  intro Q hq
  rcases List.mem_append.mp hq with hq|hq
  · exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ hq))
  · rcases List.mem_cons.mp hq with rfl|hq
    · exact List.mem_append_left _ (List.mem_append_right _ (by simp))
    · obtain rfl:=List.mem_singleton.mp hq
      exact List.mem_append_right _ (by simp)

/-- Classifying the complete retained frame as fixed or guarded input rows
suffices for replay. No semantic implication oracle is used. -/
theorem lift (D frame:List Row) (C:Row) (ω:Witness) (hc:Canonical C)
    (ho:SequenceObligations D C ω) (hframe:∀G∈frame,Canonical G)
    (hclass:∀G∈frame,substRow G ω=G ∨ ∃R∈D,∃a l,0<a ∧ l≠0 ∧ substRow G ω=weaken (substRow R ω) a l):
    CheckedStep (frame++D) (frame++(D++[C])):=by
  have h:=CheckedStep.red (frame++D) C ω hc (REDFrame.obligations D frame C ω ho (by
    intro G hg
    rcases hclass G hg with hf|⟨R,hr,a,l,ha,hl,he⟩
    · exact REDFrame.fixed_obligation D frame C G ω hg (hframe G hg) hf
    · exact obligation D frame C R G ω a l hr ha hl he ho))
  simpa only [List.append_assoc] using h

theorem guard_class (D upper inputs:List Row) (a:Row→Nat) (l:Int) (ω:Witness)
    (hc:∀R∈inputs,Canonical R) (ha:∀R∈inputs,0<a R) (hl:l≠0)
    (hin:∀R∈inputs,R∈D) (hu:∀R∈upper,substRow R ω=R)
    (hfix:∀α,applyWitness ω α l.natAbs=α l.natAbs):
    ∀G∈upper++inputs.map (fun R=>weaken R (a R) l),
      substRow G ω=G ∨ ∃R∈D,∃a l,0<a ∧ l≠0 ∧ substRow G ω=weaken (substRow R ω) a l:=by
  intro G hg
  rcases List.mem_append.mp hg with hg|hg
  · exact Or.inl (hu G hg)
  · obtain ⟨R,hr,rfl⟩:=List.mem_map.mp hg
    exact Or.inr ⟨R,hin R hr,a R,l,ha R hr,hl,subst_weaken R (hc R hr) ω (a R) l hl hfix⟩

#print axioms obligation
#print axioms lift
#print axioms guard_class
end L3Emitter.GuardedFrame

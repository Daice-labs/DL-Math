/-
The `split` trees of frontend.py (`Proof.split(c, vs)`): the leaves are the clauses
`c ++ signs` for every sign pattern of `vs`, each internal node is `rup c'` after both
children `c' ++ [v]` and `c' ++ [-v]` have been derived. The internal nodes are refuted
generically by the resolution chain 2·¬C + child₁ + child₂ (value −1), so a split
template is closed by its leaves alone (`split_obls`).
-/
import L3FrontendT2

namespace L3
open EREF EREF.GeneralRED

/-- the commands of `split c vs` (chk is the identity for bounded inputs) -/
def splitCmds (c : List Int) : List Int → List Cmd
  | [] => [.rup c]
  | v :: vs => splitCmds (c ++ [v]) vs ++ splitCmds (c ++ [-v]) vs ++ [.rup c]

theorem splitCmds_ne_nil (c : List Int) (vs : List Int) : splitCmds c vs ≠ [] := by
  cases vs <;> simp [splitCmds]

theorem splitCmds_getLast (c : List Int) (vs : List Int) :
    (splitCmds c vs).getLast (splitCmds_ne_nil c vs) = .rup c := by
  cases vs <;> simp [splitCmds]

theorem rup_mem_splitCmds (c : List Int) (vs : List Int) : Cmd.rup c ∈ splitCmds c vs := by
  cases vs <;> simp [splitCmds]

/-- the leaf clauses: `c ++ signs` over all sign patterns -/
def leaves (c : List Int) : List Int → List (List Int)
  | [] => [c]
  | v :: vs => leaves (c ++ [v]) vs ++ leaves (c ++ [-v]) vs

/-- a bounded literal list keeps its sign variants bounded -/
theorem Bounded.append_lit {m : Nat} {c : List Int} (hc : Bounded m c) {v : Int} (hv : 1 ≤ v.natAbs ∧ v.natAbs ≤ m) :
    Bounded m (c ++ [v]) := by
  intro l hl
  rcases List.mem_append.mp hl with hl | hl
  · exact hc l hl
  · rw [List.mem_singleton.mp hl]; exact hv

theorem Bounded.neg_lit {m : Nat} {v : Int} (hv : 1 ≤ v.natAbs ∧ v.natAbs ≤ m) :
    1 ≤ (-v).natAbs ∧ (-v).natAbs ≤ m := by simpa [Int.natAbs_neg] using hv

/-- the builder's `split` emits exactly `splitCmds` when every literal is bounded -/
theorem StI.split_cmds {m0 : Nat} (vs : List Int) : ∀ (t : StI m0) (c : List Int),
    Bounded t.s.var c → Bounded t.s.var vs →
    (t.split c vs).s.cmds = t.s.cmds ++ splitCmds c vs ∧ (t.split c vs).s.var = t.s.var := by
  induction vs with
  | nil =>
    intro t c hc _
    refine ⟨?_, rfl⟩
    show t.s.cmds ++ [.rup (t.s.chk c)] = t.s.cmds ++ [.rup c]
    rw [StI.chk_eq t c hc]
  | cons v vs ih =>
    intro t c hc hvs
    have hv := hvs v (by simp)
    have hvs' : Bounded t.s.var vs := fun l hl => hvs l (by simp [hl])
    obtain ⟨h1c, h1v⟩ := ih t (c ++ [v]) (hc.append_lit hv) hvs'
    have hc2 : Bounded (t.split (c ++ [v]) vs).s.var (c ++ [-v]) := by
      rw [h1v]; exact hc.append_lit (Bounded.neg_lit hv)
    have hvs2 : Bounded (t.split (c ++ [v]) vs).s.var vs := by rw [h1v]; exact hvs'
    obtain ⟨h2c, h2v⟩ := ih _ (c ++ [-v]) hc2 hvs2
    refine ⟨?_, ?_⟩
    · show (((t.split (c ++ [v]) vs).split (c ++ [-v]) vs).rup c).s.cmds = _
      rw [StI.cmds_rup, h2c, h1c]
      have hchk : ((t.split (c ++ [v]) vs).split (c ++ [-v]) vs).s.chk c = c := by
        apply StI.chk_eq; rw [h2v, h1v]; exact hc
      rw [hchk]; simp [splitCmds]
    · show (((t.split (c ++ [v]) vs).split (c ++ [-v]) vs).rup c).s.var = _
      show ((t.split (c ++ [v]) vs).split (c ++ [-v]) vs).s.var = _
      rw [h2v, h1v]

/-! ### The internal-node chain -/

/-- `rup c` is refuted once both `c ++ [v]` and `c ++ [-v]` are in the database -/
theorem resolution_node (D : List EREF.Row) (hD : ∀ R ∈ D, Canonical R) (c : List Int) (v : Int)
    (hc : ∀ l ∈ c, l ≠ 0) (hv : v ≠ 0)
    (h1 : (clauseRow (c ++ [v])).toE ∈ D) (h2 : (clauseRow (c ++ [-v])).toE ∈ D) :
    Refutation (D ++ [negate (clauseRow c).toE]) := by
  have hDc : ∀ R ∈ D ++ [negate (clauseRow c).toE], Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD R hR
    · rw [List.mem_singleton.mp hR]; exact canonical_negate _
  have hN : negate (clauseRow c).toE ∈ D ++ [negate (clauseRow c).toE] :=
    List.mem_append_right _ (List.mem_singleton.mpr rfl)
  obtain ⟨iN, hiN⟩ := Fam.dbOf_of_mem _ _ hN
  obtain ⟨i1, hi1⟩ := Fam.dbOf_of_mem _ _ (List.mem_append_left _ h1 : (clauseRow (c ++ [v])).toE ∈ D ++ [negate (clauseRow c).toE])
  obtain ⟨i2, hi2⟩ := Fam.dbOf_of_mem _ _ (List.mem_append_left _ h2 : (clauseRow (c ++ [-v])).toE ∈ D ++ [negate (clauseRow c).toE])
  let f : Nat → EREF.Row := fun j => (dbOf (D ++ [negate (clauseRow c).toE]) j).getD ⟨[], 0⟩
  have hf : ∀ j R, dbOf (D ++ [negate (clauseRow c).toE]) j = some R → f j = R := by intro j R h; simp [f, h]
  apply refutation_of_chain _ hDc f iN [iN, i1, i2]
  · rw [hf _ _ hiN]; exact hiN
  · intro j hj
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hj
    rcases hj with rfl | rfl | rfl
    · rw [hf _ _ hiN]; exact hiN
    · rw [hf _ _ hi1]; exact hi1
    · rw [hf _ _ hi2]; exact hi2
  · intro α
    rw [hf _ _ hiN]
    simp only [List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
    rw [hf _ _ hiN, hf _ _ hi1, hf _ _ hi2]
    have hnz : (clauseRow c).nz := hc
    have hnz1 : (clauseRow (c ++ [v])).nz := by
      intro l hl; unfold clauseRow at hl; rcases List.mem_append.mp hl with hl | hl
      · exact hc l hl
      · rw [List.mem_singleton.mp hl]; exact hv
    have hnz2 : (clauseRow (c ++ [-v])).nz := by
      intro l hl; unfold clauseRow at hl; rcases List.mem_append.mp hl with hl | hl
      · exact hc l hl
      · rw [List.mem_singleton.mp hl]; omega
    rw [val_negate _ (canonical_toE _), val_toE _ hnz, val_toE _ hnz1, val_toE _ hnz2]
    simp only [clauseRow, lsum_append, lsum_cons, lsum_nil]
    have := lv_neg_lit α v hv
    omega

/-! ### Obligations of a split tree -/

/-- every obligation of `splitCmds c vs` is a leaf obligation or an internal node -/
theorem split_obls (D : List EREF.Row) (m : Nat) (hD : DBBounded D m) (c : List Int) (vs : List Int)
    (hc : Bounded m c) (hvs : Bounded m vs)
    (hleaf : ∀ (D' : List EREF.Row), (∀ R ∈ D, R ∈ D') → (∀ R ∈ D', Canonical R) →
      ∀ lf ∈ leaves c vs, Refutation (D' ++ [negate (clauseRow lf).toE])) :
    ∀ o ∈ obls D (splitCmds c vs), Refutation (o.1 ++ [negate (clauseRow o.2).toE]) := by
  induction vs generalizing D c with
  | nil =>
    intro o ho
    simp only [splitCmds, obls, List.mem_cons, List.not_mem_nil, or_false] at ho
    subst ho
    exact hleaf D (fun R h => h) hD.canonical c (by simp [leaves])
  | cons v vs ih =>
    intro o ho
    have hv := hvs v (by simp)
    have hvs' : Bounded m vs := fun l hl => hvs l (by simp [hl])
    -- WF of the two subtrees (rup-only command lists with bounded clauses)
    have wfSplit : ∀ (c' : List Int) (vs' : List Int), Bounded m c' → Bounded m vs' → WF m (splitCmds c' vs') := by
      intro c' vs'
      induction vs' generalizing c' with
      | nil => intro hc' _; exact ⟨hc', trivial⟩
      | cons w ws ihw =>
        intro hc' hws
        have hw := hws w (by simp)
        have hws' : Bounded m ws := fun l hl => hws l (by simp [hl])
        simp only [splitCmds]
        rw [List.append_assoc]
        apply WF_append _ _ _ (ihw _ (hc'.append_lit hw) hws')
        rw [varAfter_rupOnly]
        apply WF_append _ _ _ (ihw _ (hc'.append_lit (Bounded.neg_lit hw)) hws')
        rw [varAfter_rupOnly]
        exact ⟨hc', trivial⟩
    simp only [splitCmds] at ho
    rw [obls_append, obls_append] at ho
    simp only [List.mem_append] at ho
    rcases ho with (ho | ho) | ho
    · exact ih D hD (c ++ [v]) (hc.append_lit hv) hvs'
        (fun D' hsub hcan lf hlf => hleaf D' hsub hcan lf (by simp [leaves, hlf])) o ho
    · have hD1 : DBBounded (exec D (splitCmds (c ++ [v]) vs)) m := by
        have := exec_bounded D m _ hD (wfSplit _ _ (hc.append_lit hv) hvs')
        rwa [varAfter_rupOnly] at this
      exact ih _ hD1 (c ++ [-v]) (hc.append_lit (Bounded.neg_lit hv)) hvs'
        (fun D' hsub hcan lf hlf => hleaf D' (fun R h => hsub R (exec_mono _ _ _ h)) hcan lf (by simp [leaves, hlf])) o ho
    · -- the internal node
      simp only [obls, List.mem_cons, List.not_mem_nil, or_false] at ho
      subst ho
      rw [exec_append]
      have hD2 : DBBounded (exec (exec D (splitCmds (c ++ [v]) vs)) (splitCmds (c ++ [-v]) vs)) m := by
        have h1 := exec_bounded D m _ hD (wfSplit _ _ (hc.append_lit hv) hvs')
        rw [varAfter_rupOnly] at h1
        have h2 := exec_bounded _ m _ h1 (wfSplit _ _ (hc.append_lit (Bounded.neg_lit hv)) hvs')
        rwa [varAfter_rupOnly] at h2
      apply resolution_node _ hD2.canonical c v (fun l hl => by have := (hc l hl).1; omega) (by omega)
      · exact exec_mono _ _ _ (mem_exec_of_cmd _ _ _ (rup_mem_splitCmds _ _) _ (by simp [Cmd.rows]))
      · exact mem_exec_of_cmd _ _ _ (rup_mem_splitCmds _ _) _ (by simp [Cmd.rows])
where
  varAfter_rupOnly : ∀ (m : Nat) (c' vs' : List Int), varAfter m (splitCmds c' vs') = m := by
    intro m c' vs'
    induction vs' generalizing c' with
    | nil => rfl
    | cons w ws ihw => simp only [splitCmds, varAfter_append, ihw]; rfl

end L3

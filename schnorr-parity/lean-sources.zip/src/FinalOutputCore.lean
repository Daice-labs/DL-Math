import OutputPhaseBank
namespace L3Emitter.FinalOutputDefinitions
set_option maxRecDepth 2000
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL
abbrev W (n:Nat):=AliasAssembly.width (n+1)
abbrev T (n:Nat):=FamilyNamespace.truthRows n
abbrev lastRank (n:Nat):=RankConstruction.width (n+1)-1

def coord (n:Nat) (i:Fin (W n-1)):Fin (W n):=⟨i.val,by have:=i.isLt;omega⟩
def lastCoord (n:Nat) (hn:2≤n):Fin (W n):=⟨W n-1,by unfold W AliasAssembly.width RankConstruction.width;omega⟩
def source (n:Nat) (hn:2≤n) (i:Fin (W n)):Bit:=ValueBranchRows.q n hn (OutputPhaseRows.lastGate n) i
def H (n:Nat) (hn:2≤n):Bit:=source n hn (lastCoord n hn)
def unary (n:Nat) (hn:2≤n) (b:Bool):Bit:=CofactorValueRows.unary n hn (OutputPhaseRows.lastGate n) b

def out {base:List Row} (n:Nat) (hn:2≤n) (x:Fin (T n)):StateM (Net base) Bit:=
  select ((List.finRange (W n-1)).map fun i=>(source n hn (coord n i),SourceCoordinateValue.value n hn (coord n i) x.val))
def selector {base:List Row} (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)):StateM (Net base) Bit:=
  MUX (H n hn) (LowerTransferImage.wire n hn (.sel (lastRank n) p.val i.val))
    (if p.val=0 then source n hn (coord n i) else if i.val=0 then (PrimaryAliasBank.cfg n hn).T else (PrimaryAliasBank.cfg n hn).F)
def port {base:List Row} (n:Nat) (hn:2≤n) (xs:Fin (T n)→Bit) (p:Fin 2) (x:Fin (T n)):StateM (Net base) Bit:=
  MUX (H n hn) (LowerTransferImage.wire n hn (.port (lastRank n) p.val x.val))
    (if p.val=0 then xs x else SourceCoordinateValue.value n hn ⟨0,by unfold AliasAssembly.width;omega⟩ x.val)
def function {base:List Row} (n:Nat) (hn:2≤n) (ab:Fin 4):StateM (Net base) Bit:=do
  let composed ← MUX (LowerTransferImage.wire n hn (.fn (lastRank n) ab.val)) (unary n hn true) (unary n hn false)
  let selected ← MUX (H n hn) composed (if ab.val/2=0 then unary n hn false else unary n hn true)
  MUX (OutputPhaseRows.phase n hn) (neg selected) selected

structure Data (n:Nat) where
  outs : Fin (T n)→Bit
  sels : Fin 2→Fin (W n-1)→Bit
  ports : Fin 2→Fin (T n)→Bit
  functions : Fin 4→Bit

def construction {base:List Row} (n:Nat) (hn:2≤n):StateM (Net base) (Data n):=do
  let xs ← tabulate (T n) (out n hn)
  let ss ← tabulate 2 (fun p=>tabulate (W n-1) (selector n hn p))
  let ps ← tabulate 2 (fun p=>tabulate (T n) (port n hn xs p))
  let fs ← tabulate 4 (function n hn)
  pure ⟨xs,ss,ps,fs⟩

theorem construction_extends {base:List Row} (n:Nat) (hn:2≤n):Extends (construction (base:=base) n hn):=by
  unfold construction
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>select_extends _))
  intro xs
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>tabulate_extends _ _ (fun _=>mux_extends _ _ _)))
  intro ss
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>tabulate_extends _ _ (fun _=>mux_extends _ _ _)))
  intro ps
  apply bind_extends _ _ (tabulate_extends _ _ (fun _=>bind_extends _ _ (mux_extends _ _ _)
    (fun _=>bind_extends _ _ (mux_extends _ _ _) (fun _=>mux_extends _ _ _))))
  exact fun _=>pure_extends _

theorem construction_cost {base:List Row} (n:Nat) (hn:2≤n):
    Cost (construction (base:=base) n hn) (T n*(W n+6)+6*(W n-1)+36):=by
  have h0:Cost (tabulate (T n) (out (base:=base) n hn)) (T n*W n):=by
    apply tabulate_cost
    intro x
    have h:=select_cost (base:=base) ((List.finRange (W n-1)).map fun i=>(source n hn (coord n i),SourceCoordinateValue.value n hn (coord n i) x.val))
    have hw:0<W n:=by unfold W AliasAssembly.width;omega
    simpa only [List.length_map,List.length_finRange,show W n-1+1=W n by omega] using h
  have h1:Cost (tabulate 2 (fun p=>tabulate (W n-1) (selector (base:=base) n hn p))) (2*((W n-1)*3)):=
    tabulate_cost _ _ _ (fun _=>tabulate_cost _ _ _ (fun _=>mux_cost _ _ _))
  have h2 (xs:Fin (T n)→Bit):Cost (tabulate 2 (fun p=>tabulate (T n) (port (base:=base) n hn xs p))) (2*(T n*3)):=
    tabulate_cost _ _ _ (fun _=>tabulate_cost _ _ _ (fun _=>mux_cost _ _ _))
  have h3:Cost (tabulate 4 (function (base:=base) n hn)) (4*9):=
    tabulate_cost _ _ _ (fun _=>bind_cost _ _ 3 6 (mux_cost _ _ _)
      (fun _=>bind_cost _ _ 3 3 (mux_cost _ _ _) (fun _=>mux_cost _ _ _)))
  have h : Cost (construction (base:=base) n hn)
      (T n*W n+(2*((W n-1)*3)+(2*(T n*3)+(4*9+0)))) :=
    bind_cost (base:=base) _ _ _ _ h0 (fun xs=>bind_cost _ _ _ _ h1
    (fun ss=>bind_cost _ _ _ _ (h2 xs) (fun ps=>bind_cost _ _ _ 0 h3 (fun fs=>pure_cost (Data.mk xs ss ps fs)))))
  apply cost_mono _ _ _ h
  exact (show _ = _ by ring).le


end L3Emitter.FinalOutputDefinitions

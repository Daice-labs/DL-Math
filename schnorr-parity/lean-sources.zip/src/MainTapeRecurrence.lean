import CanonicalFamilyEnvelope
namespace L3Emitter.MainTapeRecurrence
open EREF EREF.GeneralRED RecordedScopedTrace

/-- Main POL tokens only. Local proof tokens are counted separately. -/
def step : Step→Nat | .pol _ ts=>ts.length | _=>0
def count (p : Program) : Nat := (p.map step).sum

theorem append (p q : Program) : count (p++q)=count p+count q := by simp [count]
theorem pol_program (p : AliasProgram.Program) :
    count (RecordedBaseTwo.polProgram p)=(p.map (fun c=>c.2.length)).sum := by
  simp only [count,RecordedBaseTwo.polProgram,List.map_map,Function.comp_def,step]

theorem offset (M : Nat) (p : Program) : count (RecordedOffsetTrace.program M p)=count p := by
  unfold count RecordedOffsetTrace.program
  simp only [List.map_map]
  congr 2
  funext c
  cases c <;> simp [RecordedOffsetTrace.step,step]

theorem replay (D U I : List Row) (a : Row→Nat) (l : Int) (p : Program) :
    count (RecordedActivatedReplay.program D U I a l p)=count p := by
  induction p generalizing D with
  | nil => rfl
  | cons c cs ih =>
    simp only [RecordedActivatedReplay.program,count,List.map_cons,List.sum_cons]
    change step (RecordedActivatedReplay.step D U I a l c)+count
      (RecordedActivatedReplay.program (D++[c.row]) U I a l cs)=step c+count cs
    rw [ih]
    cases c <;> simp [RecordedActivatedReplay.step,ProgramRebase.tape,step]

theorem cancel (D inputs : List Row) (a : Row→Nat) (q : Nat) :
    count (RecordedActivation.cancel D a q inputs)=4*inputs.length := by
  induction inputs generalizing D with
  | nil => rfl
  | cons R rs ih =>
    simp only [RecordedActivation.cancel,count,List.map_cons,List.sum_cons]
    change 4+count (RecordedActivation.cancel (D++[R]) a q rs)=_
    rw [ih];simp [List.length_cons];omega

theorem bank (D inputs : List Row) (a : Row→Nat) (q : Nat) :
    count (RecordedGuardBank.program D a q inputs)=0 := by
  induction inputs generalizing D with
  | nil => rfl
  | cons R rs ih =>
    simp only [RecordedGuardBank.program,count,List.map_cons,List.sum_cons]
    change 0+count (RecordedGuardBank.program _ a q rs)=0
    rw [ih]

theorem activation (n : Nat) (hn : 2≤n) (N : Nat) :
    count (RecordedActualActivation.program n hn N)=4*(ActualLowerComposition.inputs n hn).length := by
  rw [RecordedActualActivation.program,append,append,cancel]
  rw [RecordedActualActivation.bankProgram,bank]
  simp only [count,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
    RecordedActivation.activate,step,Nat.zero_add]

/-- Actual prefix tape count is independent of the lower-tail reserve. -/
theorem prefix_tokens (i : Nat) : count (CanonicalCountRecurrence.levelPrefix i)=
    count (RecordedCompleteLower.program (i+2) (by omega))+
      4*(ActualLowerComposition.inputs (i+2) (by omega)).length := by
  unfold CanonicalCountRecurrence.levelPrefix RecordedActualActivation.fullProgram
  rw [append,activation]

theorem successor (m : Nat) : count (RecordedUniformFamily.family (m+1))=
    count (CanonicalCountRecurrence.levelPrefix m)+count (RecordedUniformFamily.family m) := by
  rw [RecordedUniformFamily.family,RecordedRecursiveStep.program,append]
  unfold ActualRecordedTail.emit RecordedRecursiveStep.shifted
  rw [replay,offset]
  rfl

def prefixSum : Nat→Nat | 0=>0 | m+1=>prefixSum m+count (CanonicalCountRecurrence.levelPrefix m)

theorem exact_count (m : Nat) : count (RecordedUniformFamily.family m)=
    count (RecordedUniformFamily.family 0)+prefixSum m := by
  induction m with
  | zero => simp [prefixSum]
  | succ m ih => rw [successor,ih,prefixSum];omega

theorem sum_bound (m A : Nat) (ha : ∀i<m,count (CanonicalCountRecurrence.levelPrefix i)≤A) :
    prefixSum m≤m*A := by
  induction m with
  | zero => simp [prefixSum]
  | succ m ih =>
    have ht:=ih (fun i hi=>ha i (by omega))
    have hh:=ha m (by omega)
    simp only [prefixSum,Nat.succ_mul];omega

/-- Conditional envelope. Its missing premise is a bound on actual reduction
POL tapes, not the already proved count of main commands. -/
theorem family_bound (m A : Nat) (ha : ∀i<m,count (CanonicalCountRecurrence.levelPrefix i)≤A) :
    count (RecordedUniformFamily.family m)≤count (RecordedUniformFamily.family 0)+m*A := by
  rw [exact_count];exact Nat.add_le_add_left (sum_bound m A ha) _

#print axioms prefix_tokens
#print axioms exact_count
#print axioms family_bound
end L3Emitter.MainTapeRecurrence

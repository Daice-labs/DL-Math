import FinalTransferContext
namespace L3Emitter.FinalTransferSeed
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram ReferenceTransport GuardedVectorTransport
open FinalOutputDefinitions FinalTransferContext
attribute [local irreducible] D

def tautProgram (E:List Row) (s v:Bit) (b:Bool):Program:=
  let A:=clause [-signed b v,signed b v]
  [(A,ComplementChoice.tautTokens (-signed b v)),
   (TransferMuxPOL.row s v v b,ChoiceProjection.weakenTokens (E++[A]) [-signed b v,signed b v] [-s.val])]

theorem taut_check (E:List Row) (s v:Bit) (b:Bool):
    check E (tautProgram E s v b)=some (E++[clause [-signed b v,signed b v],TransferMuxPOL.row s v v b]):=by
  let A:=clause [-signed b v,signed b v]
  have h0:polEval (dbOf E) (ComplementChoice.tautTokens (-signed b v)) []=some A:=by
    simpa only [neg_neg] using ComplementChoice.taut_pair_succeeds (dbOf E) (-signed b v) (neg_ne_zero.mpr (nonzero b v))
  have h1:=ChoiceProjection.weaken_succeeds (E++[A]) [-signed b v,signed b v] [-s.val]
    (by simp [Valid,nonzero b v]) (by simp [Valid,s.property]) (List.mem_append_right _ (List.mem_singleton_self _))
  have he:clause ([-signed b v,signed b v]++[-s.val])=TransferMuxPOL.row s v v b:=by
    apply ProjectionTrace.clause_perm
    · simp [Valid,nonzero b v,s.property]
    · simp [Valid,nonzero b v,s.property]
    · exact List.perm_append_comm
  rw [he] at h1
  dsimp only [A] at h0 h1
  simp only [tautProgram,check,h0,h1,↓reduceIte,List.append_assoc,List.singleton_append] 

def row (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)) (b:Bool):=
  TransferMuxPOL.row (altSelector n hn p i) (value n hn i x) (altPort n hn p x) b

def program (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)) (b:Bool) (E:List Row):Program:=
  if p.val=0 then [(row n hn p i x b,[.ref (locate E (row n hn p i x b))])]
  else if i.val=0 then tautProgram E (altSelector n hn p i) (value n hn i x) b
  else [(row n hn p i x b,PrimaryAliasRows.unitTape E (PrimaryAliasBank.cfg n hn).T
    [-(altSelector n hn p i).val,-signed b (value n hn i x),signed b (altPort n hn p x)])]
def rows (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)) (b:Bool):List Row:=
  if p.val≠0 ∧ i.val=0 then [clause [-signed b (value n hn i x),signed b (value n hn i x)],row n hn p i x b]
  else [row n hn p i x b]

theorem port_zero (n:Nat) (hn:2≤n) (p:Fin 2) (hp:p.val=0) (x:Fin (T n)):
    altPort n hn p x=(built n hn).1.outs x:=by
  simp only [altPort,FinalPortSlots.alternative,hp,↓reduceIte]
  rw [FinalOutputSelection.output_projection]
  rfl

theorem row_of_pair (E:List Row) (s v p:Bit) (b:Bool)
    (h:clause [-s.val,-v.val,p.val]∈E ∧ clause [-s.val,-p.val,v.val]∈E):
    TransferMuxPOL.row s v p b∈E:=by
  cases b
  · simp only [TransferMuxPOL.row,signed,Bool.false_eq_true,↓reduceIte,neg_neg]
    rw [ProjectionTrace.clause_perm _ [-s.val,-p.val,v.val]
      (by simp [Valid,s.property,v.property,p.property])
      (by simp [Valid,s.property,v.property,p.property])
      (List.Perm.cons _ (List.Perm.swap ..))]
    exact h.2
  · exact h.1

theorem alt_zero (n:Nat) (hn:2≤n) (p:Fin 2) (hp:p.val=0) (i:Fin (W n-1)) (x:Fin (T n)) (b:Bool):
    row n hn p i x b∈D n hn:=by
  have h:=row_of_pair (FinalOutputLinks.result n hn) (source n hn (coord n i))
    (SourceCoordinateValue.value n hn (coord n i) x.val) ((built n hn).1.outs x) b
    (FinalOutputLinks.relation n hn i x)
  unfold row
  rw [port_zero n hn p hp x]
  simpa only [D,altSelector,FinalOutputSlots.alternative,hp,↓reduceIte,value] using h

theorem checks (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)) (b:Bool)
    (E:List Row) (hk:∀R∈D n hn,R∈E):
    check E (program n hn p i x b E)=some (E++rows n hn p i x b):=by
  by_cases hp:p.val=0
  · have h:=locate_correct E _ (hk _ (alt_zero n hn p hp i x b))
    simp only [program,rows,hp,↓reduceIte,ne_eq,not_true_eq_false,false_and,polEval,check,h]
  · by_cases hi:i.val=0
    · have he:altPort n hn p x=value n hn i x:=by
        simp only [altPort,FinalPortSlots.alternative,hp,↓reduceIte,value]
        congr 1
        apply Fin.ext
        exact hi.symm
      simpa only [program,rows,hp,hi,↓reduceIte,ne_eq,not_false_eq_true,true_and,row,he] using taut_check E (altSelector n hn p i) (value n hn i x) b
    · have hs:-(altSelector n hn p i).val=(PrimaryAliasBank.cfg n hn).T.val:=by
        simp only [altSelector,FinalOutputSlots.alternative,hp,hi,↓reduceIte,PrimaryAliasBank.false_bit,neg,neg_neg]
      have ht:clause [(PrimaryAliasBank.cfg n hn).T.val]∈E:=hk _ (definitions_kept n hn _ (FinalLowerImage.true_present n hn))
      have h:=PrimaryAliasRows.unit_check E (PrimaryAliasBank.cfg n hn).T
        [-(altSelector n hn p i).val,-signed b (value n hn i x),signed b (altPort n hn p x)]
        (by simp [Valid,(altSelector n hn p i).property,nonzero])
        (by rw [hs];exact List.mem_cons_self) ht
      simp only [program,rows,hp,hi,↓reduceIte,ne_eq,not_false_eq_true,and_false,check]
      rw [h]
      simp only [row,TransferMuxPOL.row,↓reduceIte]

theorem contains (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin (W n-1)) (x:Fin (T n)) (b:Bool):
    row n hn p i x b∈rows n hn p i x b:=by
  unfold rows;split
  · exact List.mem_cons_of_mem _ (List.mem_singleton_self _)
  · exact List.mem_singleton_self _
#print axioms checks
end L3Emitter.FinalTransferSeed

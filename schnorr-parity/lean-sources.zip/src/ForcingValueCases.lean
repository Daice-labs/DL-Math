import ForcingRankBranch
namespace L3Emitter.ForcingValueCases
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram

def rank (g:Nat) {n:Nat} (j:BetaPort.Job n):=L3Uniform.Rank.rank j.1.2.parent.beta j.1.2.parent.gamma g
def target:=ForcingRankBranch.target

def rows (n:Nat) (hn:2≤n) (g:Nat) (j:BetaPort.Job n) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):List Row:=
  if g=j.1.2.parent.beta then [target n hn g j i b v]
  else if g=j.1.2.parent.gamma then GammaInductiveStep.rows n hn j i (SourceCoordinateValue.value n hn i j.2) b v
  else match SourceCoordinateValue.lookup n hn (rank g j) j.2 with
    | none=>[]
    | some r=>ForcingRankBranch.rows n hn g j r i b v

def program (n:Nat) (hn:2≤n) (g:Nat) (j:BetaPort.Job n) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):Program:=
  if g=j.1.2.parent.beta then [(target n hn g j i b v,ValueBranchRows.betaTape n hn j i (SourceCoordinateValue.value n hn i j.2) b v D)]
  else if g=j.1.2.parent.gamma then GammaInductiveStep.program n hn j i (SourceCoordinateValue.value n hn i j.2) b v D
  else match SourceCoordinateValue.lookup n hn (rank g j) j.2 with
    | none=>[]
    | some r=>ForcingRankBranch.program n hn g j r i b v D

theorem rank_bound (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (j:BetaPort.Job n)
    (hb:g≠j.1.2.parent.beta) (hc:g≠j.1.2.parent.gamma):rank g j<RankConstruction.width (n+1):=
  L3Uniform.Rank.rank_lt j.1.2.parent.beta_pos j.1.2.parent.ordered j.1.2.parent.gamma_lt ⟨hs,by omega,by omega,by omega⟩

theorem lookup_bounds (n:Nat) (hn:2≤n) (g:Nat) (j:BetaPort.Job n) (r:RankEvaluationBank.Ref n hn)
    (he:SourceCoordinateValue.lookup n hn (rank g j) j.2=some r):r.val.1=rank g j ∧ r.val.2.1=j.2:=by
  have h:=List.find?_some he
  exact of_decide_eq_true h

theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (j:BetaPort.Job n)
    (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row)
    (hd:∀R∈SharedValueBank.result n hn,R∈D) (hi:ValueInductionBranches.Before n hn g D):
    check D (program n hn g j i b v D)=some (D++rows n hn g j i b v):=by
  by_cases hb:g=j.1.2.parent.beta
  · rw [program,rows,if_pos hb,if_pos hb]
    have h:=ValueInductionBranches.beta n hn j hj i b v D hd
    have he:ValueBranchRows.guarded n hn (BetaAliasValue.gate j) j.2 i (SourceCoordinateValue.value n hn i j.2) b v
        ⟨BetaAliasValue.choice j,BetaAliasValue.choice_valid n hn j hj⟩=target n hn g j i b v:=by rw [hb];rfl
    rw [he] at h
    simp only [check,h,ite_true]
  · by_cases hc:g=j.1.2.parent.gamma
    · rw [program,rows,if_neg hb,if_neg hb,if_pos hc,if_pos hc]
      exact ValueInductionBranches.gamma n hn j hj i b v D hd (by change ValueInductionBranches.Before n hn j.1.2.parent.gamma D; rw [←hc]; exact hi)
    · rw [program,rows,if_neg hb,if_neg hb,if_neg hc,if_neg hc]
      obtain ⟨r,hr⟩:=SourceCoordinateValue.lookup_exists n hn (rank g j) j.2
        (rank_bound n hn g hg hs j hb hc) (BetaPort.valid_job n hn j hj).2.2.2
      rw [hr]
      have h:=lookup_bounds n hn g j r hr
      exact ForcingRankBranch.checks n hn g hg hs j hj r hb hc h.1 h.2 i b v D hd

theorem conclusion_present (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (j:BetaPort.Job n)
    (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):
    target n hn g j i b v∈rows n hn g j i b v:=by
  by_cases hb:g=j.1.2.parent.beta
  · simp only [rows,if_pos hb,List.mem_singleton]
  · by_cases hc:g=j.1.2.parent.gamma
    · rw [rows,if_neg hb,if_pos hc]
      have he:target n hn g j i b v=GammaInductiveStep.conclusion n hn j i (SourceCoordinateValue.value n hn i j.2) b v:=by
        rw [hc];rfl
      rw [he]
      exact GammaInductiveStep.conclusion_present n hn j i _ b v
    · rw [rows,if_neg hb,if_neg hc]
      obtain ⟨r,hr⟩:=SourceCoordinateValue.lookup_exists n hn (rank g j) j.2
        (rank_bound n hn g hg hs j hb hc) (BetaPort.valid_job n hn j hj).2.2.2
      rw [hr]
      exact ForcingRankBranch.target_present n hn g j r i b v

#print axioms checks
#print axioms conclusion_present
end L3Emitter.ForcingValueCases

import SelectedBranch

namespace L3Emitter.ConsumerLookup
open EREF EREF.GeneralRED REDWitness

def first (P : Nat→Prop) [DecidablePred P] : List Nat→Nat
  | [] => 0
  | q::qs => if P q then q else first P qs

theorem first_spec (P : Nat→Prop) [DecidablePred P] (qs : List Nat)
    (h : ∃q∈qs,P q) : P (first P qs) := by
  induction qs with
  | nil => simp at h
  | cons q qs ih =>
    simp only [first]
    split
    · assumption
    · apply ih
      obtain ⟨v,hv,hp⟩:=h
      simp only [List.mem_cons] at hv
      rcases hv with rfl|hv
      · contradiction
      · exact ⟨v,hv,hp⟩

def outputs (cs : List L3.Cmd) : List Nat := cs.filterMap fun c =>
  match c with
  | .orDef q _ => some q
  | _ => none

def criterion (F : L3.Fam) (t : L3.StI F.V) (g q : Nat) : Prop :=
  L3.Cmd.orDef q [(t.s.p0force g 0:Int),(t.s.p0force g 1:Int)]∈t.s.cmds ∧
  L3.Cmd.andDef (t.s.eligible g) [(t.s.live g:Int),(q:Int)]∈t.s.cmds ∧ F.V<q

instance (F : L3.Fam) (t : L3.StI F.V) (g : Nat) : DecidablePred (criterion F t g) :=
  fun _ => inferInstanceAs (Decidable (_∧_∧_))

def consumer (F : L3.Fam) (t : L3.StI F.V) (g : Nat) : Nat :=
  first (criterion F t g) (outputs t.s.cmds)

theorem consumer_spec (F : L3.Fam) (t : L3.StI F.V) (g : Nat)
    (h : F.PElig g t) : criterion F t g (consumer F t g) := by
  obtain ⟨q,hq,he,hp,rest⟩ := h
  apply first_spec
  refine ⟨q,?_,hq,he,hp⟩
  exact List.mem_filterMap.mpr ⟨.orDef q _,hq,rfl⟩

theorem frontend_consumer (k : Nat) (hk : 3≤k) (c : RankProjection.Choice (3*k-4)) :
    criterion (FableEncoding.fam k (3*k-4)) (FrontendSelection.front k hk) c.beta
      (consumer (FableEncoding.fam k (3*k-4)) (FrontendSelection.front k hk) c.beta) := by
  apply consumer_spec
  have hg := ((FableEncoding.fam k (3*k-4)).final_branch_ready
    (FrontendSelection.prior k hk) (FrontendSelection.prior_good k hk)).1
  exact hg.2.2.2.1 c.beta (by have:=c.beta_pos;omega)
    (by change c.beta<3*k-4;have:=c.ordered;have:=c.gamma_lt;omega)

#print axioms frontend_consumer
end L3Emitter.ConsumerLookup

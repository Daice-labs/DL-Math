import L3WireBinding

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def wireC (t : StI F.V) (g p j cb q : Nat) : List Int :=
  [(t.s.A : Int),-(cb : Int),-(t.s.live g : Int),-(F.sel g p j : Int),(q : Int)]
def wireVs (g p bit : Nat) : List Int := [(F.port g p (F.bitX bit) : Int)]

def WireInv (g p bit cb q : Nat) (t : StI F.V) : Prop :=
  F.Good3 t ∧ (∀h<g,F.GateRecord bit cb h t) ∧
  Cmd.eqDef q (F.port g p (F.bitX bit) : Int) (F.port g p (F.bitY bit) : Int)∈t.s.cmds ∧
  (1≤cb ∧ cb≤t.s.var) ∧ (1≤q ∧ q≤t.s.var)

theorem WireInv_keeps {t u : StI F.V} (g p bit cb q : Nat) (hk : Keeps2 t u)
    (hv : u.s.veq=t.s.veq) (hi : F.WireInv g p bit cb q t) : F.WireInv g p bit cb q u := by
  refine ⟨F.Good3_of_keeps2 hk hi.1,?_,mem_of_grows hk.1 hi.2.2.1,?_,?_⟩
  · intro h hh; exact F.GateRecord_keeps hk bit cb h (by rw [hv]) (hi.2.1 h hh)
  · exact ⟨hi.2.2.2.1.1,Nat.le_trans hi.2.2.2.1.2 (var_le_of_grows hk.1)⟩
  · exact ⟨hi.2.2.2.2.1,Nat.le_trans hi.2.2.2.2.2 (var_le_of_grows hk.1)⟩

theorem wireC_keeps {t u : StI F.V} (hk : Keeps2 t u) (g p j cb q : Nat) :
    F.wireC u g p j cb q=F.wireC t g p j cb q := by
  simp only [wireC,hk.2.1.1,hk.2.2.2.2.2.2]

theorem wire_bounds (hk : 2≤F.k) (t : StI F.V) (g p j bit cb q : Nat)
    (hg : g<F.s) (hp : p<2) (hj : j<F.k+g) (hb : bit<2)
    (hi : F.WireInv g p bit cb q t) :
    Bounded t.s.var (F.wireC t g p j cb q) ∧ Bounded t.s.var (F.wireVs g p bit) := by
  have hA0 := hi.1.2.2.2.2.2.1
  have hA1 := hi.1.2.2.2.2.2.2
  have hl := F.live_bound_of_good3 hi.1 g hg
  have hc := hi.2.2.2.1
  have hq := hi.2.2.2.2
  have hsel := F.sel_pos g p j
  have hselle := F.sel_le_S g p j hg (by omega) (by omega)
  have hS := F.S_le_V
  have hport := F.port_pos g p (F.bitX bit)
  have hportle := F.port_le g p _ hg (by omega) (F.bitX_lt hk bit hb)
  have hPV := F.port_bound_le_V
  have hV := t.var_ge
  constructor
  · intro l hh
    simp only [wireC,List.mem_cons,List.not_mem_nil,or_false] at hh
    rcases hh with rfl | rfl | rfl | rfl | rfl <;> simp <;> omega
  · intro l hh
    simp only [wireVs,List.mem_cons,List.not_mem_nil,or_false] at hh
    subst l; simp; omega

def wireSplit (g p bit cb q : Nat) (t : StI F.V) (j : Nat) : StI F.V :=
  t.split (F.wireC t g p j cb q) (F.wireVs g p bit)

theorem wireSplit_keeps (g p bit cb q : Nat) (t : StI F.V) (j : Nat) :
    Keeps2 t (F.wireSplit g p bit cb q t j) := keeps2_split _ _ _

theorem wireSplit_veq (g p bit cb q : Nat) (t : StI F.V) (j : Nat) :
    (F.wireSplit g p bit cb q t j).s.veq=t.s.veq := StI.veq_split _ _ _

theorem wireSplit_commands (hk : 2≤F.k) (t : StI F.V) (g p j bit cb q : Nat)
    (hg : g<F.s) (hp : p<2) (hj : j<F.k+g) (hb : bit<2)
    (hi : F.WireInv g p bit cb q t) :
    (F.wireSplit g p bit cb q t j).s.cmds=t.s.cmds ++ splitCmds (F.wireC t g p j cb q) (F.wireVs g p bit) :=
  (StI.split_cmds _ _ _ (F.wire_bounds hk t g p j bit cb q hg hp hj hb hi).1
    (F.wire_bounds hk t g p j bit cb q hg hp hj hb hi).2).1

theorem wireSplit_obls (hk : 2≤F.k) (hs : 1≤F.s) (t : StI F.V) (g p j bit cb q : Nat)
    (hg : g<F.s) (hp : p<2) (hj1 : 1≤j) (hj : j<F.k+g) (hb : bit<2)
    (hi : F.WireInv g p bit cb q t) :
    ObligationsChecked (exec F.db5 t.s.cmds)
      (splitCmds (F.wireC t g p j cb q) (F.wireVs g p bit)) := by
  have hDB := exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) hs) t.inv.1
  rw [t.inv.2] at hDB
  obtain ⟨hc,hv⟩ := F.wire_bounds hk t g p j bit cb q hg hp hj hb hi
  apply split_obls _ t.s.var hDB _ _ hc hv
  intro D hm hD lf hlf
  simp only [wireC,wireVs,leaves,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hlf
  rcases hlf with rfl | rfl
  · exact F.selected_wire_from_database hk hs t hi.1 g p j bit cb q hg hp hj1 hj hb
      hi.2.2.2.1.1 hi.2.2.2.2.1 hi.2.1 hi.2.2.1 D hD hm false
  · exact F.selected_wire_from_database hk hs t hi.1 g p j bit cb q hg hp hj1 hj hb
      hi.2.2.2.1.1 hi.2.2.2.2.1 hi.2.1 hi.2.2.1 D hD hm true

def wireSplits (g p bit cb q : Nat) (t : StI F.V) : StI F.V :=
  (List.range' 1 (F.k+g-1)).foldl (F.wireSplit g p bit cb q) t

theorem wireSplits_obls (hk : 2≤F.k) (hs : 1≤F.s) (t : StI F.V) (g p bit cb q : Nat)
    (hg : g<F.s) (hp : p<2) (hb : bit<2) (hi : F.WireInv g p bit cb q t)
    (hc : ObligationsChecked F.db5 t.s.cmds) :
    F.WireInv g p bit cb q (F.wireSplits g p bit cb q t) ∧
    ObligationsChecked F.db5 (F.wireSplits g p bit cb q t).s.cmds := by
  apply fold_obligations F.db5 (fun u : StI F.V => u.s.cmds) (F.wireSplit g p bit cb q)
    (fun u j => splitCmds (F.wireC u g p j cb q) (F.wireVs g p bit))
    (F.WireInv g p bit cb q) _ _ t hi hc
  intro u j hj hu
  have hj' := List.mem_range'_1.mp hj
  exact ⟨F.wireSplit_commands hk u g p j bit cb q hg hp (by omega) hb hu,
    F.WireInv_keeps g p bit cb q (F.wireSplit_keeps _ _ _ _ _ u j)
      (F.wireSplit_veq _ _ _ _ _ u j) hu,
    F.wireSplit_obls hk hs u g p j bit cb q hg hp hj'.1 (by omega) hb hu⟩

/-- Every selector root is present after the exact selector-loop order. -/
theorem wireSplits_roots (hk : 2≤F.k) (t : StI F.V) (g p bit cb q : Nat)
    (hg : g<F.s) (hp : p<2) (hb : bit<2) (hi : F.WireInv g p bit cb q t) :
    ∀j,1≤j → j<F.k+g → Cmd.rup (F.wireC (F.wireSplits g p bit cb q t) g p j cb q)
      ∈(F.wireSplits g p bit cb q t).s.cmds := by
  intro j hj1 hj
  have hmem : j∈List.range' 1 (F.k+g-1) := List.mem_range'_1.mpr ⟨hj1,by omega⟩
  obtain ⟨l1,l2,_,he⟩ := foldl_split (F.wireSplit g p bit cb q) _ j hmem
  unfold wireSplits
  rw [he t]
  apply foldl_pres (fun u => Cmd.rup (F.wireC u g p j cb q)∈u.s.cmds) _ l2
  · intro x _ u hu
    rw [F.wireC_keeps (F.wireSplit_keeps _ _ _ _ _ u x)]
    exact mem_of_grows (F.wireSplit_keeps _ _ _ _ _ u x).1 hu
  · have kk := keeps2_foldl _ l1 (F.wireSplit_keeps g p bit cb q) t
    have vv := StI.foldl_proj (fun (u : StI F.V) => u.s.veq) _ l1 (F.wireSplit_veq g p bit cb q) t
    have hpre := F.WireInv_keeps g p bit cb q kk vv hi
    rw [F.wireC_keeps (F.wireSplit_keeps _ _ _ _ _ _ j),
      F.wireSplit_commands hk _ g p j bit cb q hg hp hj hb hpre]
    exact List.mem_append_right _ (rup_mem_splitCmds _ _)

#print axioms wireSplit_obls
#print axioms wireSplits_obls
#print axioms wireSplits_roots
end L3.Fam

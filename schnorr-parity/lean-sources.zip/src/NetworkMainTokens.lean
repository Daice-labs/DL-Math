import FinalTransferTapeBounds
import ConstructionFinalLogCount
namespace L3Emitter.NetworkMainTokens
open EREF EREF.GeneralRED AliasNetwork AliasProgram U2ConstructionSize
open FinalOutputDefinitions

theorem mux (D : List Row) (j : RecordedExpressions.Job) :
    tokens (RecordedExpressions.jobProgram D j)=16 := by
  simp [RecordedExpressions.jobProgram,ConcreteMux.program,tokens,
    SelectedAlias.forwardTokens,ConcreteMux.backTape]

theorem expressions (D : List Row) (js : List RecordedExpressions.Job) :
    tokens (RecordedExpressions.program D js)=4*(RecordedExpressions.program D js).length := by
  induction js generalizing D with
  | nil=>rfl
  | cons j js ih=>
    simp only [RecordedExpressions.program,tokens_append,mux,List.length_append,ih]
    change 16+_=4*(4+_)
    omega

theorem final_mux (n : Nat) (hn : 2≤n) :
    tokens (FinalOutputRecorded.program n hn)≤400*(n+1)*2^n := by
  have h:=Nat.mul_le_mul_left 4 (ConstructionFinalLogCount.complete n hn)
  rw [FinalOutputRecorded.program,expressions]
  exact h.trans_eq (by ring)

theorem selection_leaf (D : List Row) (es : List ConcreteSelection.Cell) (q : Bit)
    (e : ConcreteSelection.Cell) :
    tokens (AliasProgram.bitProgram D e.choice.val (ConcreteSelection.bit es q e))≤8*es.length+9 := by
  have he: (es.erase e).length≤es.length:=List.length_erase_le
  simp [AliasProgram.bitProgram,tokens,SelectedAlias.forwardTokens,SelectedAlias.back_token_count,
    ConcreteSelection.bit,ConcreteSelection.others]
  omega

theorem selection (D : List Row) (es todo : List ConcreteSelection.Cell) (q : Bit) :
    tokens (ConcreteSelectionProgram.program D es q todo)≤todo.length*(8*es.length+9) := by
  induction todo generalizing D with
  | nil=>simp [ConcreteSelectionProgram.program,tokens]
  | cons e todo ih=>
    have hl:=selection_leaf D es q e
    have ht:=ih (D++AliasClauseTransport.bitRows e.choice.val (ConcreteSelection.bit es q e))
    simp only [ConcreteSelectionProgram.program,tokens_append,List.length_cons]
    nlinarith

/-- A loose polynomial bound that needs no maximum-job-size hypothesis. -/
theorem ports (D : List Row) (js : List ConcretePortRows.Job) :
    tokens (ConcretePortRows.program D js)≤8*(ConcretePortCost.mass js)^2+9*ConcretePortCost.mass js := by
  induction js generalizing D with
  | nil=>simp [ConcretePortRows.program,tokens,ConcretePortCost.mass]
  | cons j js ih=>
    have hl:=selection D j.es j.es j.q
    have ht:=ih (D++ConcretePortRows.jobRows j)
    simp only [ConcretePortRows.program,tokens_append]
    simp only [ConcretePortCost.mass,List.map_cons,List.sum_cons]
    change _≤8*(j.es.length+ConcretePortCost.mass js)^2+9*(j.es.length+ConcretePortCost.mass js)
    nlinarith

theorem final_links (n : Nat) (hn : 2≤n) :
    tokens (FinalOutputLinks.program n hn)≤164*(n+1)^2*(2^n)^2 := by
  have h:=ports (FinalSelectorCardinalities.result n hn) (FinalOutputLinks.jobs n hn)
  have hm:=ConcretePortCost.tabulate_mass (T n) (FinalOutputSelection.inputs n hn) (initialNet n hn)
    (W n-1) (by intro i;simp [FinalOutputSelection.inputs])
  change ConcretePortCost.mass (FinalOutputLinks.jobs n hn)=2^n*(W n-1) at hm
  rw [hm] at h
  have hw:W n-1≤4*(n+1):=by unfold W AliasAssembly.width RankConstruction.width;omega
  have hb:=Nat.mul_le_mul_left (2^n) hw
  have hs:=Nat.pow_le_pow_left hb 2
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  change tokens (FinalOutputLinks.program n hn)≤_ at h
  have hsmall:36*(n+1)*2^n≤36*(n+1)^2*(2^n)^2:=by
    have hprod:1≤(n+1)*2^n:=by nlinarith
    have hx:=Nat.mul_le_mul_left (36*(n+1)*2^n) hprod
    nlinarith
  nlinarith
#print axioms expressions
#print axioms ports
#print axioms final_mux
#print axioms final_links
end L3Emitter.NetworkMainTokens

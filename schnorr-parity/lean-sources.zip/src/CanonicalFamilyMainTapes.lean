import CompleteMainTapeEnvelope
import ConstructionCompleteCount
namespace L3Emitter.CanonicalFamilyMainTapes
set_option maxRecDepth 4096
set_option maxHeartbeats 800000
open EREF EREF.GeneralRED MainTapeRecurrence U2ConstructionSize

theorem base : count (RecordedUniformFamily.family 0)≤8000 := by
  have h:=FrontendMainTapeLength.parity 2 (by omega)
  have hb:tokens BaseTwo.program=4:=by
    simp [BaseTwo.program,tokens,CommonGuardResolve.token_count]
  rw [RecordedUniformFamily.family,RecordedBaseTwo.program,append,pol_program]
  change count (RecordedFrontendComplete.program 2 2 _)+tokens BaseTwo.program≤_
  rw [hb]
  norm_num only [Nat.reduceAdd,Nat.reducePow,Nat.reduceMul] at h
  omega

theorem level (i : Nat) : count (CanonicalCountRecurrence.levelPrefix i)≤7000000*(i+4)^8*(2^(i+2))^2 := by
  rw [prefix_tokens,ConstructionCompleteCount.input_length]
  have h:=CompleteMainTapeEnvelope.reduction (i+2) (by omega)
  have hf:=CanonicalFormulaEnvelope.original_rows (i+2)
  have hp:(i+2+1)^2≤(i+4)^8:=(Nat.pow_le_pow_left (by omega) 2).trans (Nat.pow_le_pow_right (by omega) (by omega))
  have ht:2^(i+2)≤(2^(i+2))^2:=by have h:=Nat.one_le_pow 2 (i+2) (by omega);nlinarith
  have hm:=Nat.mul_le_mul hp ht
  unfold CompleteMainTapeEnvelope.reductionBound at h
  have he:i+2+2=i+4:=by omega
  rw [he] at h
  nlinarith

def mainTokenBound (n : Nat):Nat:=8000000*(n+2)^9*(2^n)^2

/-- Bound on every main POL token of the actual recursive recorded emitter.
Local-certificate tokens remain separately counted by localTokenBound. -/
theorem main (n : Nat) (hn : 2≤n) : count (RecordedUniformFamily.emitter n)≤mainTokenBound n := by
  have hp:∀i<n-2,count (CanonicalCountRecurrence.levelPrefix i)≤7000000*(n+2)^8*(2^n)^2:=by
    intro i hi
    have h1:(i+4)^8≤(n+2)^8:=Nat.pow_le_pow_left (by omega) 8
    have h2:(2^(i+2))^2≤(2^n)^2:=Nat.pow_le_pow_left (Nat.pow_le_pow_right (by omega) (by omega)) 2
    exact (level i).trans (Nat.mul_le_mul (Nat.mul_le_mul_left 7000000 h1) h2)
  have h:=family_bound (n-2) (7000000*(n+2)^8*(2^n)^2) hp
  have hm:=Nat.mul_le_mul_right (7000000*(n+2)^8*(2^n)^2) (show n-2≤n+2 by omega)
  have ht:1≤(n+2)^9*(2^n)^2:=Nat.mul_pos (Nat.pow_pos (by omega)) (Nat.pow_pos (Nat.pow_pos (by omega)))
  change count (RecordedUniformFamily.family (n-2))≤_
  unfold mainTokenBound
  have hb:=base
  calc
    _ ≤ 8000+(n+2)*(7000000*(n+2)^8*(2^n)^2) := by omega
    _ = 8000+7000000*((n+2)^9*(2^n)^2) := by ring
    _ ≤ _ := by nlinarith

/-- POL TOKEN count, polynomial in encoded formula row count; not byte size. -/
theorem formula_polynomial (n : Nat) (hn : 2≤n) : count (RecordedUniformFamily.emitter n)≤
    4096000000*(ConstructionFormulaScale.rows n)^11 := by
  have h:=main n hn
  have hp:(n+2)^9≤512*(n+1)^9:=by
    have hh:=Nat.pow_le_pow_left (show n+2≤2*(n+1) by omega) 9
    nlinarith
  have hc:=ConstructionFormulaScale.monomial n 9 2 4096000000 hn
  rw [Nat.mul_comm 2 n,Nat.pow_mul] at hc
  unfold mainTokenBound at h
  norm_num only [Nat.reduceAdd] at hc
  apply h.trans
  apply le_trans _ hc
  have hh:=Nat.mul_le_mul_right ((2^n)^2) (Nat.mul_le_mul_left 8000000 hp)
  convert hh using 1 <;> ring
#print axioms base
#print axioms main
#print axioms formula_polynomial
end L3Emitter.CanonicalFamilyMainTapes

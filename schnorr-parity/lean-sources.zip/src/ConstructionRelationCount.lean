import ConstructionAliasPrefixCount
import ConstructionSourceCount
import OneHotSize

namespace L3Emitter.ConstructionRelationCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools

theorem flat_bound {A B : Type} (xs : List A) (f : A→List B) (N : Nat)
    (h : ∀a∈xs,(f a).length≤N) : (xs.flatMap f).length≤xs.length*N := by
  induction xs with
  | nil=>simp
  | cons a xs ih=>
    simp only [List.flatMap_cons,List.length_append,List.length_cons]
    exact (Nat.add_le_add (h a (by simp)) (ih (fun b hb=>h b (by simp [hb])))).trans_eq (by ring)

theorem flat_exact {A B : Type} (xs : List A) (f : A→List B) (N : Nat)
    (h : ∀a∈xs,(f a).length=N) : (xs.flatMap f).length=xs.length*N := by
  induction xs with
  | nil=>simp
  | cons a xs ih=>
    simp only [List.flatMap_cons,List.length_append,List.length_cons]
    rw [h a (by simp),ih (fun b hb=>h b (by simp [hb]))];ring

theorem gates (n : Nat) : (CategoryBank.gates n).length=3*(n+1)-5 := by
  simp [CategoryBank.gates]

theorem columns (n : Nat) (hn : 2≤n) :
    (RankColumnOneHot.emitted n hn).length≤9*(n+1)^2 := by
  have h:=OneHotSize.columns_commands n hn (RankColumnOneHot.source n hn) (RankColumnOneHot.columns n)
  simp only [RankColumnOneHot.columns,List.length_range] at h
  unfold RankConstruction.width at h
  exact h.trans (by nlinarith [Nat.sub_le (3*(n+1)-4) 3,Nat.sub_le (3*(n+1)) 4,Nat.sub_le (3*(n+1)) 5])

theorem category_rows (n : Nat) (hn : 2≤n) (g : Nat) :
    (CategoryPrograms.rows n hn g).length≤400*(n+1)^4 := by
  have hc:(CategoryPrograms.choices n hn).length≤9*(n+1)^2:=ForcingSize.chosen_bound _ (by omega)
  have hcat:(CategoryPrograms.cats n).length≤3*(n+1):=by
    simp only [CategoryPrograms.cats,GateCategories.categories,List.length_cons,List.length_map,List.length_range];omega
  have hp:(CategoryPrograms.pairs n).length≤(CategoryPrograms.cats n).length^2:=by
    unfold CategoryPrograms.pairs
    exact (flat_bound _ _ _ (fun q hq=>List.length_filterMap_le ..)).trans_eq (by ring)
  have hr (q r : GateCategories.Category) :
      (CategoryPrograms.pairRows n hn g q r).length=2*(CategoryPrograms.choices n hn).length+1:=by
    simp only [CategoryPrograms.pairRows,List.length_append,List.length_singleton,ProjectionTrace.pairBlocks]
    rw [flat_exact _ _ 2 (by intro a ha;cases CategoryPrograms.side g q a <;> rfl)];ring
  have hb:=flat_bound (CategoryPrograms.pairs n) (fun p=>CategoryPrograms.pairRows n hn g p.1 p.2)
    (2*(CategoryPrograms.choices n hn).length+1) (fun p hp=>(hr p.1 p.2).le)
  have hp':(CategoryPrograms.pairs n).length≤9*(n+1)^2:=by nlinarith
  have hb':(CategoryPrograms.pairBody n hn g (CategoryPrograms.pairs n)).length≤
      9*(n+1)^2*(18*(n+1)^2+1):=hb.trans (Nat.mul_le_mul hp' (by omega))
  simp only [CategoryPrograms.rows,List.length_append,CategoryPrograms.aloRows,
    ProjectionTrace.aloBlocks,List.length_map,List.length_singleton]
  nlinarith [Nat.pow_le_pow_right (show 1≤n+1 by omega) (show 2≤4 by omega),
    Nat.one_le_pow (n+1) 4 (by omega)]

theorem categories (n : Nat) (hn : 2≤n) :
    (CategoryBank.emitted n hn).length≤1200*(n+1)^5 := by
  have he:=checked_body _ _ _ (CategoryBank.checks n hn)
  rw [he]
  have h:=flat_bound (CategoryBank.gates n) (CategoryPrograms.rows n hn) (400*(n+1)^4)
    (fun g hg=>category_rows n hn g)
  rw [gates] at h
  exact h.trans ((Nat.mul_le_mul_right (400*(n+1)^4) (Nat.sub_le (3*(n+1)) 5)).trans_eq (by ring))

theorem mixture_rows (n : Nat) (hn : 2≤n) (g : Nat)
    (i : Fin (AliasAssembly.width (n+1))) (s : SourceMixture.Refs) :
    (CategoryMixtureProgram.rows n hn g i s).length≤60*(n+1) := by
  have h:=flat_exact (CategoryMixtureProgram.ranks n) (fun t=>MixtureRank.rows s (GateCategories.bit n hn g (.rank t))) 9
    (by intro t ht;rfl)
  simp only [CategoryMixtureProgram.ranks,List.length_range] at h
  simp only [CategoryMixtureProgram.rows,List.length_append]
  change 2+12+12+_≤60*(n+1)
  unfold CategoryMixtureProgram.rankRows CategoryMixtureProgram.ranks
  rw [h]
  unfold RankConstruction.width
  omega

theorem source_jobs (n : Nat) :
    (SourceRelationBank.jobs n).length=(3*(n+1)-5)*AliasAssembly.width (n+1) := by
  unfold SourceRelationBank.jobs
  rw [flat_exact _ _ _ (by intro g hg;exact List.length_ofFn),gates]

theorem source_relations (n : Nat) (hn : 2≤n) :
    (SourceRelationBank.program n hn).length≤1000*(n+1)^3 := by
  have he:=checked_body _ _ _ (SourceRelationBank.checks n hn)
  rw [he]
  have h:=flat_bound (SourceRelationBank.jobs n) (SourceRelationBank.jobRows n hn) (60*(n+1))
    (fun j hj=>mixture_rows n hn j.1 j.2 _)
  rw [source_jobs] at h
  have hw:=AliasAssembly.width_bound (n+1)
  have hg:3*(n+1)-5≤3*(n+1):=Nat.sub_le ..
  have hp:=Nat.mul_le_mul hg hw
  exact h.trans (by nlinarith [Nat.mul_le_mul_right (60*(n+1)) hp])

#print axioms columns
#print axioms categories
#print axioms source_relations
end L3Emitter.ConstructionRelationCount

import CofactorSelectionMainTapes
import GlobalExtensionMainTapes
namespace L3Emitter.ConstantMainTapes
open EREF EREF.GeneralRED MainTapeRecurrence U2ConstructionSize GlobalFixedMainTapes

theorem allocation_zero (base : List Row) (rows : Nat→List Row)
    (block : Nat→List Row→RecordedScopedTrace.Program) (n : Nat)
    (h : ∀i D,count (block i D)=0) :
    count (RecordedAllocationLoop.program base rows block n)=0 := by
  induction n with
  | zero=>rfl
  | succ n ih=>rw [RecordedAllocationLoop.program,append,ih,h]

theorem bank_zero (n s offset B : Nat) (D : List Row) :
    count (RecordedCofactorBank.program n s offset B D)=0 := by
  apply allocation_zero
  intro g D
  apply allocation_zero
  intro p D
  apply allocation_zero
  intro x D
  exact CompleteFinalRowTapes.gate_zero ..

theorem cofactor (n : Nat) (hn : 2≤n) : tokens (ConstantCofactor.program n hn)≤1680*(n+1)*2^n := by
  have h:=map_factor (CofactorSection.jobs n (3*(n+1)-4))
    (CofactorSection.resultRow n (3*(n+1)-4) (ConstantCofactor.offset n hn))
    (CofactorSection.resultTape n (3*(n+1)-4) (ConstantCofactor.offset n hn) (ConstantCofactor.B n hn))
    70 (by intro j hj;exact (CofactorSemantics.tape_length ..).le)
  have hl:=ConstructionConstantCount.cofactor n hn
  simp only [ConstantCofactor.program,ForcingSize.rebase_length,ConstantCofactor.sourceProgram,List.length_map] at hl
  change tokens (ConstantCofactor.sourceProgram n hn _)≤_ at h
  rw [ConstantCofactor.program,rebase]
  rw [hl] at h
  have hs:3*(n+1)-4≤3*(n+1):=Nat.sub_le ..
  nlinarith [Nat.mul_le_mul_right (2^n) hs]

theorem fields (k : Nat) (hk : 3≤k) (D : List Row) : tokens (ForcingFieldBank.program k hk D)≤11664*k^4 := by
  have h:=map_factor (ForcingFieldBank.entries k hk) ForcingFieldBank.row
    (ForcingFieldBank.tokens k hk) 3 (by intros;rfl)
  rw [ForcingFieldBank.program,rebase]
  change tokens (ForcingFieldBank.sourceProgram k hk _)≤_ at h
  exact h.trans (by have hc:=ConstructionConstantCount.field_entries k hk;omega)

theorem primary (n : Nat) (hn : 2≤n) : tokens (PrimaryBank.program n hn)≤36*(n+1)*2^n := by
  have h:tokens (PrimaryBank.sourceProgram n hn (PrimaryBank.jobs n (3*(n+1)-4)))≤
      3*(PrimaryBank.jobs n (3*(n+1)-4)).length:=map_factor _ _ _ 3 (by intros;rfl)
  have hl:=ConstructionConstantCount.primary n hn
  simp only [PrimaryBank.program,ForcingSize.rebase_length,PrimaryBank.sourceProgram,List.length_map] at hl
  rw [PrimaryBank.program,rebase]
  rw [hl] at h
  have hs:3*(n+1)-4≤3*(n+1):=Nat.sub_le ..
  nlinarith [Nat.mul_le_mul_right (2^n) hs]

theorem beta_port (n : Nat) (hn : 2≤n) : tokens (BetaPort.program n hn)≤10368*(n+1)^4*2^n := by
  have h:tokens (BetaPort.program n hn)≤8*(BetaPort.jobs n hn).length:=map_factor _ _ _ 8 (by intros;rfl)
  have hl:=ConstructionConstantCount.beta_port n hn
  simp only [BetaPort.program,List.length_map] at hl
  nlinarith

theorem beta_value (n : Nat) (hn : 2≤n) : tokens (BetaValue.program n hn)≤72576*(n+1)^4*2^n := by
  have h:tokens (BetaValue.program n hn)≤28*(BetaValue.jobs n hn).length:=
    map_factor _ _ _ 28 (by intro j hj;exact (ConstantLeaf.token_count ..).le)
  have hl:=ConstructionConstantCount.beta_value n hn
  simp only [BetaValue.program,List.length_map] at hl
  nlinarith

theorem complete (n : Nat) (hn : 2≤n) : count (RecordedConstantTransport.program n hn)≤500000*(n+2)^4*2^n := by
  have h0:=CofactorSelectionMainTapes.complete (n+1) (by omega)
  have h1:=cofactor n hn;have h2:=fields (n+1) (by omega) (ForcingFieldBank.base n hn)
  have h3:=primary n hn;have h4:=beta_port n hn;have h5:=beta_value n hn
  have p4:(n+1)^4≤(n+2)^4:=Nat.pow_le_pow_left (by omega) 4
  have p1:n+1≤(n+2)^4:=by
    have h:(n+2)^1≤(n+2)^4:=Nat.pow_le_pow_right (by omega) (by omega)
    simpa using (show n+1≤(n+2)^1 by simp).trans h
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have h14:=Nat.mul_le_mul_right (2^n) p4
  have h11:=Nat.mul_le_mul_right (2^n) p1
  have h4t:(n+2)^4≤(n+2)^4*2^n:=by nlinarith
  simp only [RecordedConstantTransport.program,RecordedConstantTransport.betaPortProgram,
    RecordedConstantTransport.primaryProgram,RecordedConstantTransport.fieldsProgram,
    RecordedConstantTransport.cofactorProgram,RecordedConstantTransport.bankProgram,
    append,bank_zero,pol_program]
  simp only [tokens] at h1 h2 h3 h4 h5
  nlinarith
#print axioms complete
end L3Emitter.ConstantMainTapes

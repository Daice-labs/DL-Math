/-
Obligation 2, mechanical half: the extension-variable definitions of frontend.py's
`Proof.OR / AND / EQ` (fresh-variable RED steps with witness `q -> bit`), a command
language mirroring `Proof` (definitions and `rup` lines), its execution into the
exact-checker database, and the theorem that executing any well-formed command list
is a checked trace provided each `rup` line has a refutation against the database of
that moment. The `rup` refutations are collected as an explicit obligation list.
-/
import L3PortsSwap

namespace L3
open EREF EREF.GeneralRED

/-! ### Gate rows and the fresh-variable witness -/

/-- the RED row `inputs ++ [q]` (bit = true) or `inputs ++ [¬q]` (bit = false) -/
def gateRow (inputs : List Int) (q : Nat) (bit : Bool) : Row :=
  { lits := inputs ++ [if bit then pos q else neg q], rhs := 1 }

/-- the witness `q -> bit` of frontend.py `red(c, {q: '1'/'0'})` -/
def gw (q : Nat) (b : Bool) : Witness := fun v => if v = q then .constant b else Fam.litImage v

theorem gw_at (q : Nat) (b : Bool) (α : Val) : applyWitness (gw q b) α q = b := by
  simp [applyWitness, gw, Image.eval]

theorem gw_else (q : Nat) (b : Bool) (α : Val) (v : Nat) (hv : 1 ≤ v) (hq : v ≠ q) :
    applyWitness (gw q b) α v = α v := by
  unfold applyWitness gw
  simp only [hq, ↓reduceIte]
  exact Fam.eval_litImage α v hv

/-- a list of literals: nonzero ids, all different from q -/
def Fresh (q : Nat) (xs : List Int) : Prop := ∀ l ∈ xs, 1 ≤ l.natAbs ∧ l.natAbs ≠ q

theorem lsum_gw_fresh (q : Nat) (b : Bool) (α : Val) (xs : List Int) (hf : Fresh q xs) :
    lsum (applyWitness (gw q b) α) xs = lsum α xs :=
  lsum_congr α _ xs (fun l hl => gw_else q b α l.natAbs (hf l hl).1 (hf l hl).2)

theorem lv_gw_out (q : Nat) (hq : 1 ≤ q) (b c : Bool) (α : Val) :
    lv (applyWitness (gw q b) α) (if c then pos q else neg q) = if b = c then 1 else 0 := by
  cases c
  · simp only [Bool.false_eq_true, ↓reduceIte]
    rw [lv_neg _ _ hq, gw_at]; cases b <;> simp [b2i]
  · simp only [↓reduceIte]
    rw [lv_pos _ _ hq, gw_at]; cases b <;> simp [b2i]

theorem gateRow_nz (inputs : List Int) (q : Nat) (hq : 1 ≤ q) (hin : Fresh q inputs) (bit : Bool) :
    (gateRow inputs q bit).nz := by
  intro l hl
  unfold gateRow at hl
  simp only [List.mem_append, List.mem_singleton] at hl
  rcases hl with hl | rfl
  · have := (hin l hl).1; omega
  · cases bit <;> simp [pos, neg] <;> omega

theorem lsum_gateRow (inputs : List Int) (q : Nat) (bit : Bool) (γ : Val) :
    lsum γ (gateRow inputs q bit).lits = lsum γ inputs + lv γ (if bit then pos q else neg q) := by
  unfold gateRow; simp [lsum_append, lsum_cons, lsum_nil]

theorem lsum_mem_le (α : Val) (x : Int) (xs : List Int) (h : x ∈ xs) : lv α x ≤ lsum α xs := by
  induction xs with
  | nil => simp at h
  | cons y ys ih =>
    rw [lsum_cons]
    rcases List.mem_cons.mp h with rfl | h
    · have := lsum_nonneg' α ys; omega
    · have := ih h; have := lv_nonneg α y; omega
where
  lsum_nonneg' (α : Val) (ys : List Int) : 0 ≤ lsum α ys := by
    induction ys with
    | nil => simp
    | cons z zs ih => rw [lsum_cons]; have := lv_nonneg α z; omega

theorem lsum_nonneg (α : Val) (xs : List Int) : 0 ≤ lsum α xs := lsum_mem_le.lsum_nonneg' α xs

theorem lv_pos_add_neg (α : Val) (v : Nat) (hv : 1 ≤ v) : lv α (pos v) + lv α (neg v) = 1 := by
  rw [lv_pos _ _ hv, lv_neg _ _ hv]; omega

/-- `lv α (-x) + lv α x = 1` for a nonzero literal -/
theorem lv_neg_lit (α : Val) (x : Int) (hx : x ≠ 0) : lv α (-x) + lv α x = 1 := by
  unfold lv
  rcases Int.lt_or_lt_of_ne hx with h | h
  · have h1 : ¬ 0 < x := by omega
    have h2 : 0 < -x := by omega
    simp only [h1, h2, ↓reduceIte, Int.natAbs_neg]; omega
  · have h2 : ¬ 0 < -x := by omega
    simp only [h, h2, ↓reduceIte, Int.natAbs_neg]; omega

/-! ### One gate-definition RED step -/

/-- a database bounded by m: every row is the bridge of a row with ids in 1..m -/
def DBBounded (D : List EREF.Row) (m : Nat) : Prop :=
  ∀ R ∈ D, ∃ r : Row, R = r.toE ∧ ∀ l ∈ r.lits, 1 ≤ l.natAbs ∧ l.natAbs ≤ m

theorem DBBounded.mono {D : List EREF.Row} {m m' : Nat} (h : DBBounded D m) (hm : m ≤ m') : DBBounded D m' := by
  intro R hR
  obtain ⟨r, rfl, hr⟩ := h R hR
  exact ⟨r, rfl, fun l hl => ⟨(hr l hl).1, Nat.le_trans (hr l hl).2 hm⟩⟩

theorem DBBounded.canonical {D : List EREF.Row} {m : Nat} (h : DBBounded D m) : ∀ R ∈ D, Canonical R := by
  intro R hR; obtain ⟨r, rfl, _⟩ := h R hR; exact canonical_toE r

theorem DBBounded.append {D : List EREF.Row} {m : Nat} (h : DBBounded D m) (r : Row)
    (hr : ∀ l ∈ r.lits, 1 ≤ l.natAbs ∧ l.natAbs ≤ m) : DBBounded (D ++ [r.toE]) m := by
  intro R hR
  rcases List.mem_append.mp hR with hR | hR
  · exact h R hR
  · exact ⟨r, List.mem_singleton.mp hR, hr⟩

/-- bounded ids below q are fresh for q -/
theorem fresh_of_bounded (q : Nat) (xs : List Int) (m : Nat) (hm : m < q)
    (h : ∀ l ∈ xs, 1 ≤ l.natAbs ∧ l.natAbs ≤ m) : Fresh q xs :=
  fun l hl => ⟨(h l hl).1, by have := (h l hl).2; omega⟩

/-- the previously emitted rows of the same definition -/
abbrev Defs := List (List Int × Bool)

def Defs.rows (prev : Defs) (q : Nat) : List EREF.Row := prev.map fun p => (gateRow p.1 q p.2).toE

/-- **one RED line of a definition**: candidate `inputs ++ [out q bit]`, witness `q -> bit` -/
theorem gate_step (D : List EREF.Row) (m q : Nat) (hq : q = m + 1) (hD : DBBounded D m)
    (prev : Defs) (hprev : ∀ p ∈ prev, Fresh q p.1)
    (inputs : List Int) (bit : Bool) (hin : Fresh q inputs)
    (hdis : ∀ p ∈ prev, p.2 ≠ bit → ∀ α, 1 ≤ lsum α p.1 + lsum α inputs) :
    CheckedStep (D ++ prev.rows q) (D ++ prev.rows q ++ [(gateRow inputs q bit).toE]) := by
  have hq1 : 1 ≤ q := by omega
  have hcanD : ∀ R ∈ D ++ prev.rows q, Canonical R := by
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact hD.canonical R hR
    · obtain ⟨p, _, rfl⟩ := List.mem_map.mp hR; exact canonical_toE _
  apply checkedStep_red_general _ _ (gw q bit) hcanD (canonical_toE _)
  · intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · -- old row: q-free, substitutes to itself
      obtain ⟨r, rfl, hr⟩ := hD R hR
      left
      refine Fam.fixed_mem _ _ r (fun l hl => by have := (hr l hl).1; omega)
        (List.mem_append_left _ hR) ?_
      intro α l hl
      exact gw_else q bit α _ (hr l hl).1 (by have := (hr l hl).2; omega)
    · obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hR
      have hnz : (gateRow p.1 q p.2).nz := gateRow_nz p.1 q hq1 (hprev p hp) p.2
      by_cases hb : p.2 = bit
      · -- same output polarity: the substituted row is a tautology
        right
        apply refutation_of_subst_taut _ _ _ _ hnz
        intro α
        rw [lsum_gateRow, lsum_gw_fresh q bit α p.1 (hprev p hp), lv_gw_out q hq1, hb]
        simp only [↓reduceIte]
        have := lsum_nonneg α p.1
        show (1 : Int) ≤ _
        omega
      · -- opposite polarity: covered together with the candidate
        right
        apply refutation_of_cover _ _ _ (canonical_toE _) (canonical_substRow _ _)
        intro α
        rw [val_substRow, val_toE _ hnz, val_toE _ (gateRow_nz inputs q hq1 hin bit),
          lsum_gateRow, lsum_gateRow, lsum_gw_fresh q bit α p.1 (hprev p hp), lv_gw_out q hq1]
        have hne : ¬ bit = p.2 := fun h => hb h.symm
        have hr1 : ((gateRow inputs q bit).rhs : Int) = 1 := rfl
        have hr2 : ((gateRow p.1 q p.2).rhs : Int) = 1 := rfl
        rw [hr1, hr2]
        simp only [hne, ↓reduceIte]
        have := hdis p hp hb α
        have := lv_nonneg α (if bit then pos q else neg q)
        show (-1 : Int) ≤ _
        omega
  · -- the candidate: its own output literal becomes the true constant
    apply refutation_of_subst_taut _ _ _ _ (gateRow_nz inputs q hq1 hin bit)
    intro α
    rw [lsum_gateRow, lsum_gw_fresh q bit α inputs hin, lv_gw_out q hq1]
    simp only [↓reduceIte]
    have := lsum_nonneg α inputs
    show (1 : Int) ≤ _
    omega

/-- a whole definition: the rows in order, each a RED step against the previous ones -/
theorem defs_trace (D : List EREF.Row) (m q : Nat) (hq : q = m + 1) (hD : DBBounded D m)
    (rows : Defs) (hrows : ∀ p ∈ rows, Fresh q p.1)
    (hdis : ∀ p ∈ rows, ∀ p' ∈ rows, p.2 ≠ p'.2 → ∀ α, 1 ≤ lsum α p.1 + lsum α p'.1) :
    CheckedTrace D (D ++ rows.rows q) := by
  -- generalize over the emitted prefix
  suffices h : ∀ (prev rest : Defs), prev ++ rest = rows →
      CheckedTrace (D ++ prev.rows q) (D ++ rows.rows q) by
    have := h [] rows rfl
    simpa [Defs.rows] using this
  intro prev rest
  induction rest generalizing prev with
  | nil => intro h; subst h; simp [Defs.rows]; exact CheckedTrace.refl _
  | cons p rest ih =>
    intro h
    have hp : p ∈ rows := by rw [← h]; simp
    have step := gate_step D m q hq hD prev (fun p' hp' => hrows p' (by rw [← h]; simp [hp']))
      p.1 p.2 (hrows p hp) (fun p' hp' hne α => hdis p' (by rw [← h]; simp [hp']) p hp hne α)
    have tail := ih (prev ++ [p]) (by rw [← h]; simp)
    have e : (prev ++ [p]).rows q = prev.rows q ++ [(gateRow p.1 q p.2).toE] := by simp [Defs.rows]
    rw [e, ← List.append_assoc] at tail
    exact CheckedTrace.cons step tail

/-- after a definition the database is bounded by q -/
theorem DBBounded_defs (D : List EREF.Row) (m q : Nat) (hq : q = m + 1) (hD : DBBounded D m)
    (rows : Defs) (hrows : ∀ p ∈ rows, ∀ l ∈ p.1, 1 ≤ l.natAbs ∧ l.natAbs ≤ m) :
    DBBounded (D ++ rows.rows q) q := by
  intro R hR
  rcases List.mem_append.mp hR with hR | hR
  · exact (hD.mono (by omega)) R hR
  · obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hR
    refine ⟨gateRow p.1 q p.2, rfl, ?_⟩
    intro l hl
    unfold gateRow at hl
    simp only [List.mem_append, List.mem_singleton] at hl
    rcases hl with hl | rfl
    · exact ⟨(hrows p hp l hl).1, by have := (hrows p hp l hl).2; omega⟩
    · cases p.2 <;> simp [pos, neg] <;> omega

/-! ### The three definition shapes of frontend.py -/

/-- `OR(xs)`: rows `[¬x, q]` for x ∈ xs (q -> 1), then `xs ++ [¬q]` (q -> 0) -/
def orDefs (xs : List Int) : Defs := (xs.map fun x => ([-x], true)) ++ [(xs, false)]
/-- `AND(xs)`: rows `[x, ¬q]` for x ∈ xs (q -> 0), then `¬xs ++ [q]` (q -> 1) -/
def andDefs (xs : List Int) : Defs := (xs.map fun x => ([x], false)) ++ [(xs.map (-·), true)]
/-- `EQ(a,b)`: rows `[a,b,q]`, `[a,¬b,¬q]`, `[¬a,b,¬q]`, `[¬a,¬b,q]` (itertools.product order) -/
def eqDefs (a b : Int) : Defs := [([a, b], true), ([a, -b], false), ([-a, b], false), ([-a, -b], true)]

/-- literal lists with ids in 1..m -/
def Bounded (m : Nat) (xs : List Int) : Prop := ∀ l ∈ xs, 1 ≤ l.natAbs ∧ l.natAbs ≤ m

theorem Bounded.neg {m : Nat} {xs : List Int} (h : Bounded m xs) : Bounded m (xs.map (-·)) := by
  intro l hl; obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hl
  simpa [Int.natAbs_neg] using h x hx

theorem or_trace (D : List EREF.Row) (m : Nat) (hD : DBBounded D m) (xs : List Int) (hxs : Bounded m xs) :
    CheckedTrace D (D ++ (orDefs xs).rows (m + 1)) := by
  apply defs_trace D m (m + 1) rfl hD
  · intro p hp
    unfold orDefs at hp
    simp only [List.mem_append, List.mem_map, List.mem_singleton] at hp
    rcases hp with ⟨x, hx, rfl⟩ | rfl
    · exact fresh_of_bounded _ _ m (by omega) (fun l hl => by
        simp at hl; subst hl; simpa [Int.natAbs_neg] using hxs x hx)
    · exact fresh_of_bounded _ _ m (by omega) hxs
  · intro p hp p' hp' hne α
    unfold orDefs at hp hp'
    simp only [List.mem_append, List.mem_map, List.mem_singleton] at hp hp'
    rcases hp with ⟨x, hx, rfl⟩ | rfl <;> rcases hp' with ⟨x', hx', rfl⟩ | rfl
    · simp at hne
    · simp only [lsum_cons, lsum_nil]
      have h1 := lsum_mem_le α x xs hx
      have h2 := lv_neg_lit α x (by have := (hxs x hx).1; omega)
      omega
    · simp only [lsum_cons, lsum_nil]
      have h1 := lsum_mem_le α x' xs hx'
      have h2 := lv_neg_lit α x' (by have := (hxs x' hx').1; omega)
      omega
    · simp at hne

theorem and_trace (D : List EREF.Row) (m : Nat) (hD : DBBounded D m) (xs : List Int) (hxs : Bounded m xs) :
    CheckedTrace D (D ++ (andDefs xs).rows (m + 1)) := by
  apply defs_trace D m (m + 1) rfl hD
  · intro p hp
    unfold andDefs at hp
    simp only [List.mem_append, List.mem_map, List.mem_singleton] at hp
    rcases hp with ⟨x, hx, rfl⟩ | rfl
    · exact fresh_of_bounded _ _ m (by omega) (fun l hl => by simp at hl; rw [hl]; exact hxs x hx)
    · exact fresh_of_bounded _ _ m (by omega) hxs.neg
  · intro p hp p' hp' hne α
    unfold andDefs at hp hp'
    simp only [List.mem_append, List.mem_map, List.mem_singleton] at hp hp'
    rcases hp with ⟨x, hx, rfl⟩ | rfl <;> rcases hp' with ⟨x', hx', rfl⟩ | rfl
    · simp at hne
    · simp only [lsum_cons, lsum_nil]
      have h1 := lsum_mem_le α (-x) (xs.map (-·)) (List.mem_map.mpr ⟨x, hx, rfl⟩)
      have h2 := lv_neg_lit α x (by have := (hxs x hx).1; omega)
      omega
    · simp only [lsum_cons, lsum_nil]
      have h1 := lsum_mem_le α (-x') (xs.map (-·)) (List.mem_map.mpr ⟨x', hx', rfl⟩)
      have h2 := lv_neg_lit α x' (by have := (hxs x' hx').1; omega)
      omega
    · simp at hne

theorem eq_trace (D : List EREF.Row) (m : Nat) (hD : DBBounded D m) (a b : Int)
    (ha : 1 ≤ a.natAbs ∧ a.natAbs ≤ m) (hb : 1 ≤ b.natAbs ∧ b.natAbs ≤ m) :
    CheckedTrace D (D ++ (eqDefs a b).rows (m + 1)) := by
  have ha0 : a ≠ 0 := by omega
  have hb0 : b ≠ 0 := by omega
  apply defs_trace D m (m + 1) rfl hD
  · intro p hp
    unfold eqDefs at hp
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hp
    rcases hp with rfl | rfl | rfl | rfl <;> intro l hl <;>
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hl <;>
      rcases hl with rfl | rfl <;> (try simp only [Int.natAbs_neg]) <;> omega
  · intro p hp p' hp' hne α
    unfold eqDefs at hp hp'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hp hp'
    have hA := lv_neg_lit α a ha0
    have hB := lv_neg_lit α b hb0
    have := lv_nonneg α a; have := lv_nonneg α b; have := lv_nonneg α (-a); have := lv_nonneg α (-b)
    rcases hp with rfl | rfl | rfl | rfl <;> rcases hp' with rfl | rfl | rfl | rfl <;>
      first | exact absurd rfl hne | (simp only [lsum_cons, lsum_nil]; omega)

end L3

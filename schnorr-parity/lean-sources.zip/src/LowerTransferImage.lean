import RawStageCounts
namespace L3Emitter.LowerTransferImage
open EREF REDWitness AliasNetwork GuardedGatePOL FamilyNamespace FamilyRows

def portLookup (n:Nat) (hn:2≤n) (t p:Nat):=
  (RawLowerInputBank.result n hn).2.attach.find? fun r=>decide ((r.val.1.1.1,r.val.1.1.2.1)=(t,p))

theorem port_jobs (n:Nat) (hn:2≤n):
    (RawLowerInputBank.result n hn).2.map (fun r=>(r.1.1.1,r.1.1.2.1))=RankPortBank.jobs n:=by
  have h0:=RawLowerInputBank.records_cover n hn (RankPortValueBank.result n hn).1 (RankPortValueBank.result n hn).2
  have h1:=RankPortValueBank.records_cover n hn (RankPortBank.result n hn).1 (RankPortBank.result n hn).2
  have h2:=RankPortBank.records_cover n hn (GlobalPortValues.result n hn) (RankPortBank.jobs n)
  have h:=congrArg (List.map (fun r:RankPortValueBank.Record n=>(r.1.1,r.1.2.1))) h0
  simp only [List.map_map,Function.comp_def] at h
  have hh:=congrArg (List.map (fun r:RankPortBank.Record n=>(r.1,r.2.1))) h1
  simp only [List.map_map,Function.comp_def] at hh
  exact h.trans (hh.trans h2)

theorem port_exists (n:Nat) (hn:2≤n) (t p:Nat) (ht:t<RankConstruction.width (n+1)) (hp:p<2):
    ∃r,portLookup n hn t p=some r ∧ (r.val.1.1.1,r.val.1.1.2.1)=(t,p):=by
  cases he:portLookup n hn t p with
  | some r=>
    have hh:=List.find?_some he
    exact ⟨r,rfl,of_decide_eq_true hh⟩
  | none=>
    have h:(t,p)∈(RawLowerInputBank.result n hn).2.map (fun r=>(r.1.1.1,r.1.1.2.1)):=by
      rw [port_jobs];exact (RankPortBank.job_mem n _).mpr ⟨ht,hp⟩
    obtain ⟨r,hr,heq⟩:=List.mem_map.mp h
    have hh:=List.find?_eq_none.mp he ⟨r,hr⟩ (by simp)
    simp [heq] at hh

def functionLookup (n:Nat) (hn:2≤n) (t:Nat):=
  (RankTableBank.result n hn).2.find? fun r=>r.1==t

def wire (n:Nat) (hn:2≤n):Wire→Bit
  | .sel t p j=>match portLookup n hn t p with
    | some r=>if h:j<AliasAssembly.width (n+1) then RawInputSelection.coordinate r.val.1.1.2.2 ⟨j,h⟩ else SelectedCoordinateBank.fallback
    | none=>SelectedCoordinateBank.fallback
  | .port t p x=>match portLookup n hn t p with
    | some r=>r.val.2 x
    | none=>SelectedCoordinateBank.fallback
  | .fn t ab=>match functionLookup n hn t with
    | some r=>r.2 (RankTableBank.args ab).1 (RankTableBank.args ab).2
    | none=>SelectedCoordinateBank.fallback
  | .val t x=>if h:n+t<AliasAssembly.width (n+1) then SourceCoordinateValue.value n hn ⟨n+t,h⟩ x else SelectedCoordinateBank.fallback

def image (n:Nat) (hn:2≤n) (r:Spec):Row:=
  normalize (r.literals.map fun l=>(1,sign l.2 (wire n hn l.1))) r.rhs

theorem primary_image (n:Nat) (hn:2≤n) (t p j x:Nat)
    (ht:t<RankConstruction.width (n+1)) (hp:p<2) (hj:j<n) (hx:x<truthRows n):
    image n hn (InputSwap.inputTransfer n t p j x)∈RawPrimaryTransferBank.result n hn:=by
  obtain ⟨r,he,heq⟩:=port_exists n hn t p ht hp
  have h:=RawPrimaryTransferBank.all_rows n hn r.val r.property ⟨j,hj⟩ x hx
  have hw:j<AliasAssembly.width (n+1):=by unfold AliasAssembly.width;omega
  simpa only [image,InputSwap.inputTransfer,List.map_cons,List.map_nil,wire,he,dif_pos hw,
    RawLowerTransfers.primaryRow,clause,RawPrimaryTransferBank.coordinate,
    PrimaryInputLinks.d,RemainingInput.value,Nat.add_sub_cancel,sign,Bool.false_eq_true,↓reduceIte]
    using h

theorem gate_image (n:Nat) (hn:2≤n) (t p g x:Nat)
    (ht:t<RankConstruction.width (n+1)) (hp:p<2) (hg:g<t) (hx:x<truthRows n) (b:Bool):
    image n hn (InputSwap.gateTransfer n t p g x b)∈RawPrimaryTransferBank.result n hn:=by
  obtain ⟨r,he,heq⟩:=port_exists n hn t p ht hp
  have hw:n+g<AliasAssembly.width (n+1):=by unfold AliasAssembly.width;omega
  have h:=(RawLowerInputBank.original_to_raw_inputs n hn).2 r.val r.property x hx ⟨n+g,hw⟩
  have hh:=RawUnaryTransport.raw_polarity _ (RawInputSelection.coordinate r.val.1.1.2.2 ⟨n+g,hw⟩)
    (r.val.2 x) (SourceCoordinateValue.value n hn ⟨n+g,hw⟩ x) b ⟨h.2,h.1⟩
  have hh':clause [-(RawInputSelection.coordinate r.val.1.1.2.2 ⟨n+g,hw⟩).val,
      sign (!b) (SourceCoordinateValue.value n hn ⟨n+g,hw⟩ x),sign b (r.val.2 x)]∈(RawLowerInputBank.result n hn).1:=by
    cases b <;> simpa [sign] using hh
  apply List.mem_append_left
  apply RawPrimaryTransferBank.raw_retained
  simpa only [image,InputSwap.gateTransfer,List.map_cons,List.map_nil,wire,he,dif_pos hw,
    clause,sign,Bool.false_eq_true,↓reduceIte] using hh'

theorem all_transfer_images (n:Nat) (hn:2≤n) (r:Spec)
    (hr:r∈OriginalEncoding.transfersBlock n (3*n-4)):
    image n hn r∈RawPrimaryTransferBank.result n hn:=by
  rcases (OriginalEncoding.transfers_mem n (3*n-4) r).mp hr with
    ⟨t,p,j,x,ht,hp,hj,hx,rfl⟩|⟨t,p,g,x,b,ht,hp,hg,hx,rfl⟩
  · exact primary_image n hn t p j x (by unfold RankConstruction.width;omega) hp hj hx
  · exact gate_image n hn t p g x (by unfold RankConstruction.width;omega) hp hg hx b
#print axioms all_transfer_images

#print axioms port_exists
#print axioms primary_image
#print axioms gate_image
end L3Emitter.LowerTransferImage

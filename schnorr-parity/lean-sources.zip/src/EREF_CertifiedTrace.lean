import EREF_GeneralRED

namespace EREF
namespace GeneralRED

/-- A finite sequence of explicitly evaluated POL rows preserves a model.
    The initial prefix is a hypothesis; every later row is certified by `Derived`. -/
theorem derived_sound (rows : List Row) (n : Nat) (α : Val)
    (hd : Derived n rows)
    (hbase : ∀ k, k < n → (hk : k < rows.length) → Canonical rows[k] ∧ rows[k].sat α) :
    ∀ R ∈ rows, Canonical R ∧ R.sat α := by
  have hall : ∀ k, (hk : k < rows.length) → Canonical rows[k] ∧ rows[k].sat α := by
    intro k
    induction k using Nat.strongRecOn with
    | ind k ih =>
      intro hk
      by_cases hkn : k < n
      · exact hbase k hkn hk
      · obtain ⟨toks, heval⟩ := hd k (by omega) hk
        apply polEval_sound (dbOf (rows.take k)) α _ toks [] (by simp) rows[k] heval
        intro i R hi
        have hm := dbOf_mem _ _ _ hi
        obtain ⟨j, hj, heq⟩ := List.mem_take_iff_getElem.mp hm
        rw [← heq]
        exact ih j (by omega) (by omega)
  intro R hR
  obtain ⟨k, hk, rfl⟩ := List.mem_iff_getElem.mp hR
  exact hall k hk

/-- Certificate sequences retain their complete initial database exactly. -/
def Refutation (base : List Row) : Prop :=
  ∃ suffix, Derived base.length (base ++ suffix) ∧
    ∃ out ∈ base ++ suffix, Contra out

theorem refutation_sound (base : List Row) (cert : Refutation base) (α : Val)
    (hbase : ∀ R ∈ base, Canonical R ∧ R.sat α) : False := by
  obtain ⟨suffix, hd, out, hm, hc⟩ := cert
  have hall := derived_sound (base ++ suffix) base.length α hd (by
    intro k hk hk'
    rw [List.getElem_append_left hk]
    exact hbase base[k] (List.getElem_mem hk))
  have hout := hall out hm
  exact (canonical_contra_iff out hout.1).mp hc α hout.2

theorem single_to_refutation (rows : List Row) (C G : Row) (h : LocalCertificate rows C G) :
    Refutation (rows ++ [negate C, negate G]) := by
  obtain ⟨toks, out, heval, hcontra⟩ := h
  refine ⟨[out], ?_, out, by simp, hcontra⟩
  apply derived_append _ _ (by intro k hk hklt; omega) out (Nat.le_refl _) toks heval

/-- Fable's RUP elaboration theorem supplies a refutation sequence. This bridge retains
    the exact initial list; the older theorem's weaker extensional prefix clause suffices
    because IDs 1..length recover every original row. -/
theorem rup_to_refutation (base : List Row) (hc : ∀ R ∈ base, Canonical R)
    (trail : List (Int × Nat)) (σ' : PAssign)
    (ht : Trail (dbOf base) (fun _ => none) trail σ')
    (kid : Nat) (K : Row) (hK : dbOf base kid = some K) (hconf : slack σ' K < 0) :
    Refutation base := by
  obtain ⟨rows, hlen, hext, hd, last, hlast, hcontra⟩ := rup_to_pol base hc trail σ' ht kid K hK hconf
  have hpre : rows.take base.length = base := by
    apply List.ext_getElem
    · simp; omega
    · intro i hi hi'
      have hb : dbOf base (i + 1) = some base[i] := by simp [dbOf, hi']
      have hr := hext (i + 1) base[i] hb
      simp only [dbOf, Nat.add_eq_zero_iff, Nat.one_ne_zero, and_false, ↓reduceIte,
        Nat.add_sub_cancel] at hr
      have hri : i < rows.length := by omega
      rw [List.getElem?_eq_getElem hri] at hr
      have heq := Option.some.inj hr
      simpa using heq
  have heq : base ++ rows.drop base.length = rows := by
    calc
      base ++ rows.drop base.length = rows.take base.length ++ rows.drop base.length :=
        congrArg (fun xs => xs ++ rows.drop base.length) hpre.symm
      _ = rows := List.take_append_drop base.length rows
  refine ⟨rows.drop base.length, ?_⟩
  rw [heq]
  exact ⟨hd, last, List.mem_of_getLast? hlast, hcontra⟩

/-- General local certificates may contain any finite POL chain, including expanded RUP. -/
def SequenceObligations (rows : List Row) (C : Row) (ω : Witness) : Prop :=
  ∀ R ∈ C :: rows, Refutation (rows ++ [negate C, negate (substRow R ω)])

theorem sequence_goal_sound (rows : List Row) (C G : Row)
    (hc : ∀ R ∈ rows, Canonical R) (hC : Canonical C) (hG : Canonical G)
    (cert : Refutation (rows ++ [negate C, negate G])) (α : Val)
    (hs : ∀ R ∈ rows, R.sat α) (hnC : ¬ C.sat α) : G.sat α := by
  classical
  apply Classical.byContradiction
  intro hnG
  apply refutation_sound _ cert α
  intro R hm
  simp only [List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at hm
  rcases hm with hm | rfl | rfl
  · exact ⟨hc R hm, hs R hm⟩
  · exact ⟨canonical_negate C, (sat_negate_iff C hC α).mpr hnC⟩
  · exact ⟨canonical_negate G, (sat_negate_iff G hG α).mpr hnG⟩

theorem red_sequence_preserves_model (rows : List Row) (C : Row) (ω : Witness)
    (hc : ∀ R ∈ rows, Canonical R) (hC : Canonical C)
    (ho : SequenceObligations rows C ω) (α : Val) (hs : ∀ R ∈ rows, R.sat α) :
    ∃ β : Val, ∀ R ∈ C :: rows, R.sat β := by
  classical
  by_cases h : C.sat α
  · exact ⟨α, by intro R hr; rcases List.mem_cons.mp hr with rfl | hr; exact h; exact hs R hr⟩
  · refine ⟨applyWitness ω α, ?_⟩
    intro R hr
    apply (sat_substRow R ω α).mp
    exact sequence_goal_sound rows C (substRow R ω) hc hC (canonical_substRow R ω) (ho R hr) α hs h

/-- The semantic calculus includes exact POL, RUP/local refutation, and general RED.
    This is an inductive specification, NOT a proof about the Python validator parser. -/
inductive CheckedStep : List Row → List Row → Prop
  | pol (rows : List Row) (C : Row) (ts : List Tok) :
      polEval (dbOf rows) ts [] = some C → CheckedStep rows (rows ++ [C])
  | consequence (rows : List Row) (C : Row) : Canonical C →
      Refutation (rows ++ [negate C]) → CheckedStep rows (rows ++ [C])
  | red (rows : List Row) (C : Row) (ω : Witness) : Canonical C →
      SequenceObligations rows C ω → CheckedStep rows (rows ++ [C])

def Model (rows : List Row) (α : Val) : Prop := ∀ R ∈ rows, Canonical R ∧ R.sat α

theorem checkedStep_sound {rows next : List Row} (step : CheckedStep rows next)
    (α : Val) (hm : Model rows α) : ∃ β, Model next β := by
  classical
  cases step with
  | pol C ts heval =>
    have hdb : GoodDb (dbOf rows) α := fun i R h => hm R (dbOf_mem rows i R h)
    have hC := polEval_sound _ α hdb ts [] (by simp) C heval
    exact ⟨α, by intro R hR; rcases List.mem_append.mp hR with hR | hR; exact hm R hR; have e := List.mem_singleton.mp hR; subst R; exact hC⟩
  | consequence C hc cert =>
    have hs : C.sat α := by
      apply Classical.byContradiction
      intro hn
      apply refutation_sound _ cert α
      intro R hR
      rcases List.mem_append.mp hR with hR | hR
      · exact hm R hR
      · have heq := List.mem_singleton.mp hR; subst R
        exact ⟨canonical_negate C, (sat_negate_iff C hc α).mpr hn⟩
    exact ⟨α, by intro R hR; rcases List.mem_append.mp hR with hR | hR; exact hm R hR; have e := List.mem_singleton.mp hR; subst R; exact ⟨hc,hs⟩⟩
  | red C ω hc ho =>
    obtain ⟨β,hβ⟩ := red_sequence_preserves_model rows C ω (fun R h => (hm R h).1)
      hc ho α (fun R h => (hm R h).2)
    refine ⟨β, ?_⟩
    intro R hR
    rcases List.mem_append.mp hR with hR | hR
    · exact ⟨(hm R hR).1, hβ R (List.mem_cons_of_mem _ hR)⟩
    · have e := List.mem_singleton.mp hR; subst R
      exact ⟨hc, hβ C (List.mem_cons_self ..)⟩

inductive CheckedTrace : List Row → List Row → Prop
  | refl (rows : List Row) : CheckedTrace rows rows
  | cons {a b c : List Row} : CheckedStep a b → CheckedTrace b c → CheckedTrace a c

theorem checkedTrace_sound {rows final : List Row} (trace : CheckedTrace rows final)
    (α : Val) (hm : Model rows α) : ∃ β, Model final β := by
  induction trace generalizing α with
  | refl => exact ⟨α,hm⟩
  | cons step tail ih =>
    obtain ⟨β,hβ⟩ := checkedStep_sound step α hm
    exact ih β hβ

/-- Arbitrarily long certified traces ending in a contradictory row refute every
    model of their original input rows. No finite test corpus is used in this theorem. -/
theorem checkedTrace_refutes {rows final : List Row} (trace : CheckedTrace rows final)
    (out : Row) (hout : out ∈ final) (hc : Contra out) : ∀ α, ¬ Model rows α := by
  intro α hm
  obtain ⟨β,hβ⟩ := checkedTrace_sound trace α hm
  have h := hβ out hout
  exact (canonical_contra_iff out h.1).mp hc β h.2

end GeneralRED
end EREF

#print axioms EREF.GeneralRED.rup_to_refutation
#print axioms EREF.GeneralRED.red_sequence_preserves_model
#print axioms EREF.GeneralRED.checkedTrace_refutes

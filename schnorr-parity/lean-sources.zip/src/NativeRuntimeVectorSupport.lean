import NativeRuntimeRangeClosure
namespace L3Emitter.NativeRuntimeSupport
open EREF PinnedRetainedPacked PinnedRetainedVector

def StackVars (K:Nat) (st:List Packed):Prop:=∀A∈st,RowVars K (PinnedRetainedPacked.row A)
def StateVars (K:Nat) (s:State):Prop:=StackVars K s.stack ∧ ∀t∈s.stash,t.2.natAbs≤K

theorem stash_vars (K:Nat) (ts:List (Nat×Int)) (h:∀t∈ts,t.2.natAbs≤K):RowVars K (PinnedRetainedPacked.row (PinnedRetainedPacked.stash ts)):=by
 rw [PinnedRetainedPacked.stash,pack_row]
 apply normalize_vars
 intro t ht;obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht;exact h u hu

theorem stack_cons (K:Nat) (A:Packed) (st:List Packed):
 StackVars K (A::st) ↔ RowVars K (PinnedRetainedPacked.row A) ∧ StackVars K st:=by simp [StackVars]

theorem core_vars (K:Nat) (db:Nat→Option Packed) (t:Tok) (st out:List Packed)
 (hd:∀i A,db i=some A→RowVars K (PinnedRetainedPacked.row A)) (ht:TapeVars K [t])
 (hs:StackVars K st) (h:core db t st=some out):StackVars K out:=by
 cases t with
 | ref i=>
   obtain ⟨A,hA,rfl⟩:=Option.map_eq_some_iff.mp h
   exact (stack_cons _ _ _).mpr ⟨hd i A hA,hs⟩
 | lit l=>
   by_cases hl:l≠0
   · simp only [core,if_pos hl,Option.some.injEq] at h;subst out
     exact (stack_cons _ _ _).mpr ⟨by simpa using literal_vars K l (ht l (by simp)),hs⟩
   · simp [core,hl] at h
 | add=>
   cases st with
   | nil=>simp [core] at h
   | cons B st=>cases st with
     | nil=>simp [core] at h
     | cons A st=>
       simp only [core,Option.some.injEq] at h;subst out
       have hb:=(stack_cons _ _ _).mp hs
       have ha:=(stack_cons _ _ _).mp hb.2
       exact (stack_cons _ _ _).mpr ⟨by simpa using add_vars K (PinnedRetainedPacked.row A) (PinnedRetainedPacked.row B) ha.1 hb.1,ha.2⟩
 | mul k=>
   cases st with
   | nil=>simp [core] at h
   | cons A st=>
     by_cases hk:0<k
     · simp only [core,if_pos hk,Option.some.injEq] at h;subst out
       have ha:=(stack_cons _ _ _).mp hs
       exact (stack_cons _ _ _).mpr ⟨by simpa using multiply_vars K (PinnedRetainedPacked.row A) k ha.1,ha.2⟩
     · simp [core,hk] at h
 | div k=>
   cases st with
   | nil=>simp [core] at h
   | cons A st=>
     by_cases hk:0<k
     · simp only [core,dif_pos hk,Option.some.injEq] at h;subst out
       have ha:=(stack_cons _ _ _).mp hs
       exact (stack_cons _ _ _).mpr ⟨by simpa using divide_vars K (PinnedRetainedPacked.row A) k ha.1,ha.2⟩
     · simp [core,hk] at h
 | sat=>
   cases st with
   | nil=>simp [core] at h
   | cons A st=>
     simp only [core,Option.some.injEq] at h;subst out
     have ha:=(stack_cons _ _ _).mp hs
     exact (stack_cons _ _ _).mpr ⟨by simpa using saturate_vars K (PinnedRetainedPacked.row A) ha.1,ha.2⟩

theorem clear_vars (K:Nat) (s q:State) (hs:StateVars K s) (h:clear s=some q):StateVars K q:=by
 rcases s with ⟨st,ts,b⟩
 rcases hs with ⟨hst,hts⟩
 cases ts with
 | nil=>simp only [clear,Option.some.injEq] at h;subst q;exact ⟨hst,by simp⟩
 | cons a ts=>
   have ht:=stash_vars K (a::ts) hts
   cases b with
   | false=>cases st with
     | nil=>simp [clear] at h
     | cons A st=>
       simp only [clear,Option.some.injEq] at h;subst q
       have ha:=(stack_cons _ _ _).mp hst
       exact ⟨(stack_cons _ _ _).mpr ⟨by simpa using add_vars K (PinnedRetainedPacked.row A) _ ha.1 ht,ha.2⟩,by simp⟩
   | true=>cases st with
     | nil=>simp [clear] at h
     | cons B st=>cases st with
       | nil=>simp [clear] at h
       | cons A st=>
         simp only [clear,Option.some.injEq] at h;subst q
         have hb:=(stack_cons _ _ _).mp hst
         have ha:=(stack_cons _ _ _).mp hb.2
         exact ⟨(stack_cons _ _ _).mpr ⟨hb.1,(stack_cons _ _ _).mpr
           ⟨by simpa using add_vars K (PinnedRetainedPacked.row A) _ ha.1 ht,ha.2⟩⟩,by simp⟩

 theorem cleared_core_vars (K:Nat) (db:Nat→Option Packed) (t:Tok) (s q:State)
 (hd:∀i A,db i=some A→RowVars K (PinnedRetainedPacked.row A)) (ht:TapeVars K [t]) (hs:StateVars K s)
 (h:(clear s).bind (fun r=>(core db t r.stack).map (fun st=>State.mk st [] false))=some q):StateVars K q:=by
 obtain ⟨r,hr,hq⟩:=Option.bind_eq_some_iff.mp h
 obtain ⟨st,hst,rfl⟩:=Option.map_eq_some_iff.mp hq
 exact ⟨core_vars K db t r.stack st hd ht (clear_vars K s r hs hr).1 hst,by simp⟩

 theorem step_vars (K:Nat) (db:Nat→Option Packed) (t:Tok) (s q:State)
 (hd:∀i A,db i=some A→RowVars K (PinnedRetainedPacked.row A)) (ht:TapeVars K [t])
 (hs:StateVars K s) (h:step db t s=some q):StateVars K q:=by
 cases t with
 | ref i | div i | sat=>exact cleared_core_vars K db _ s q hd ht hs h
 | lit l=>
   by_cases hl:l≠0
   · have hv:RowVars K (PinnedRetainedPacked.row (PinnedRetainedPacked.literal l)):=by simpa using literal_vars K l (ht l (by simp))
     by_cases hb:s.topLit=true
     · simp only [step,if_pos hl,if_pos hb] at h
       obtain ⟨r,hr,rfl⟩:=Option.map_eq_some_iff.mp h
       exact ⟨(stack_cons _ _ _).mpr ⟨hv,(clear_vars K s r hs hr).1⟩,by simp⟩
     · simp only [step,if_pos hl,if_neg hb,Option.some.injEq] at h;subst q
       exact ⟨(stack_cons _ _ _).mpr ⟨hv,hs.1⟩,hs.2⟩
   · simp [step,hl] at h
 | mul k=>
   by_cases hk:0<k
   · by_cases hb:s.topLit=true
     · cases he:s.stack with
       | nil=>simp [step,hk,hb,he] at h
       | cons A st=>
         simp only [step,if_pos hk,if_pos hb,he,Option.some.injEq] at h;subst q
         have ha:=(stack_cons _ _ _).mp (show StackVars K (A::st) by simpa [he] using hs.1)
         exact ⟨(stack_cons _ _ _).mpr ⟨by simpa using multiply_vars K (PinnedRetainedPacked.row A) k ha.1,ha.2⟩,hs.2⟩
     · simp only [step,if_pos hk,if_neg hb] at h
       obtain ⟨r,hr,hq⟩:=Option.bind_eq_some_iff.mp h
       have hv:=clear_vars K s r hs hr
       cases he:r.stack with
       | nil=>simp [he] at hq
       | cons A st=>
         simp only [he,Option.some.injEq] at hq;subst q
         have ha:=(stack_cons _ _ _).mp (show StackVars K (A::st) by simpa [he] using hv.1)
         exact ⟨(stack_cons _ _ _).mpr ⟨by simpa using multiply_vars K (PinnedRetainedPacked.row A) k ha.1,ha.2⟩,by simp⟩
   · simp [step,hk] at h
 | add=>
   by_cases hb:s.topLit=true
   · cases he:s.stack with
     | nil=>simp [step,hb,he] at h
     | cons B st=>cases st with
       | nil=>simp [step,hb,he] at h
       | cons A st=>
         have hh:=(stack_cons _ _ _).mp (show StackVars K (B::A::st) by simpa [he] using hs.1)
         cases hl:(PinnedRetainedPacked.row B).terms with
         | nil=>
           simp only [step,if_pos hb,he,hl,Option.some.injEq] at h;subst q
           exact ⟨hh.2,hs.2⟩
         | cons b bs=>
           simp only [step,if_pos hb,he,hl,Option.some.injEq] at h;subst q
           refine ⟨hh.2,?_⟩
           intro u hu;rcases List.mem_append.mp hu with hu|hu
           · exact hs.2 u hu
           · obtain rfl:=List.mem_singleton.mp hu
             exact hh.1 u (by simp [hl])
   · exact cleared_core_vars K db .add s q hd ht hs (by simpa only [step,if_neg hb] using h)

 theorem run_vars (K:Nat) (db:Nat→Option Packed) (ts:List Tok) (s q:State)
 (hd:∀i A,db i=some A→RowVars K (PinnedRetainedPacked.row A)) (ht:TapeVars K ts)
 (hs:StateVars K s) (h:run db ts s=some q):StateVars K q:=by
 induction ts generalizing s with
 | nil=>simp only [run,Option.some.injEq] at h;subst q;exact hs
 | cons t ts ih=>
   obtain ⟨r,hr,hq⟩:=Option.bind_eq_some_iff.mp h
   exact ih r (fun l hl=>ht l (by simp [hl]))
     (step_vars K db t s r hd (fun l hl=>ht l (by
       have he:=List.mem_singleton.mp hl
       simp [←he])) hs hr) hq

/-- Every retained intermediate stack PinnedRetainedPacked.row has a signed-64-safe PinnedRetainedPacked.literal count.
This covers Clause/Cardinality get_coeff_sum conversions inside POL arithmetic,
not only rows eventually inserted into the database. Raw PinnedRetainedPacked.stash coefficients
are BigInt; the normalized PinnedRetainedPacked.stash has the same variable support. -/
theorem intermediate_counts (K:Nat) (db:Nat→Option Packed) (ts:List Tok) (q:State)
 (hK:K<2^63) (hd:∀i A,db i=some A→RowVars K (PinnedRetainedPacked.row A)) (ht:TapeVars K ts)
 (h:run db ts ⟨[],[],false⟩=some q):
 (∀A∈q.stack,PinnedIntegerRepresentations.fits 64 (PinnedRetainedPacked.row A).terms.length) ∧
 PinnedIntegerRepresentations.fits 64 (PinnedRetainedPacked.row (PinnedRetainedPacked.stash q.stash)).terms.length:=by
 have hv:=run_vars K db ts _ q hd ht ⟨by simp [StackVars],by simp⟩ h
 exact ⟨fun A hA=>row_fits K (PinnedRetainedPacked.row A) (canonical A) (hv.1 A hA) hK,
   row_fits K _ (canonical _) (stash_vars K q.stash hv.2) hK⟩
#print axioms intermediate_counts
#print axioms step_vars
end L3Emitter.NativeRuntimeSupport

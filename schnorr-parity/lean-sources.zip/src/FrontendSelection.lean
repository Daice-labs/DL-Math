import PrioritySelection

set_option maxHeartbeats 2000000

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def branchList (t : StI F.V) := (F.preparedBank t).2

theorem final_branch_ready (t : StI F.V) (ht : F.Good3 t) :
    F.BranchReady (F.stage7 t) (F.branchList t) := by
  have hu := F.prepared_ready t ht
  have hv := F.BranchReady_keeps (F.branchRups_keeps F.branchIndices (F.preparedBranches t))
    (F.branchRups_B _ _) (F.branchList t) hu
  exact F.BranchReady_keeps (keeps2_rup _ _) rfl _ hv

theorem final_branch_unit (t : StI F.V) (ht : F.Good3 t) :
    Cmd.rup [((F.stage7 t).s.Bv:Int)]∈(F.stage7 t).s.cmds := by
  let v := F.branchRups F.branchIndices (F.preparedBranches t)
  have hv := F.BranchReady_keeps (F.branchRups_keeps F.branchIndices (F.preparedBranches t))
    (F.branchRups_B _ _) (F.branchList t) (F.prepared_ready t ht)
  have hb : Bounded v.s.var [(v.s.Bv:Int)] := by
    have hl := hv.2.2.1; have hu := hv.2.2.2.1
    intro l hlit; simp only [List.mem_cons,List.not_mem_nil,or_false] at hlit
    subst l; change 1≤v.s.Bv ∧ v.s.Bv≤v.s.var; exact ⟨hl,hu⟩
  change Cmd.rup [(v.s.Bv:Int)]∈v.s.cmds++[.rup (v.s.chk [(v.s.Bv:Int)])]
  rw [StI.chk_eq v _ hb]; simp

theorem branchList_bounded (t : StI F.V) : Bounded (F.stage7 t).s.var (F.branchList t) := by
  have hb := F.branchBank_bounded F.branchIndices (t,[]) (by simp [Bounded])
  have h1 := var_le_of_grows (keeps2_OR (F.preparedBank t).1 (F.branchList t)).1
  have h2 := var_le_of_grows (F.branchRups_keeps F.branchIndices (F.preparedBranches t)).1
  intro l hl
  have h := hb l hl
  refine ⟨h.1,?_⟩
  change l.natAbs ≤ (F.branchRups F.branchIndices (F.preparedBranches t)).s.var
  apply Nat.le_trans h.2
  exact Nat.le_trans h1 h2

theorem branchList_nonempty (hs : 3≤F.s) (t : StI F.V) (ht : F.Good3 t) : F.branchList t≠[] := by
  have hr := (F.final_branch_ready t ht).2.2.2.2 1
    (by apply List.mem_range'_1.mpr; constructor <;> omega) 2 (by omega) (by omega)
  obtain ⟨q,r,hq,hr,hmem,rest⟩ := hr
  intro he; rw [he] at hmem; simp at hmem

end L3.Fam

namespace L3Emitter.FrontendSelection
open EREF EREF.GeneralRED REDWitness ReferenceTransport PrioritySelection PriorityBank
open PriorityPOL PriorityReach FableEncoding

def prior (k : Nat) (hk : 3≤k) : L3.StI (fam k (3*k-4)).V :=
  let F := fam k (3*k-4)
  F.stage6 (F.stage5 (F.V_pos (by change 1≤3*k-4; omega)) (F.t4 (by change 1≤3*k-4; omega)))
def front (k : Nat) (hk : 3≤k) := (fam k (3*k-4)).stage7 (prior k hk)
def xs (k : Nat) (hk : 3≤k) := (fam k (3*k-4)).branchList (prior k hk)
def db (k : Nat) (hk : 3≤k) := L3.exec (fam k (3*k-4)).db5 (front k hk).s.cmds

theorem prior_good (k : Nat) (hk : 3≤k) : (fam k (3*k-4)).Good3 (prior k hk) := by
  let F := fam k (3*k-4)
  have h : F.Good3 (F.t4 (by change 1≤3*k-4; omega)) :=
    F.Good3_of_keeps2 (F.keeps2_stage4 _) (F.good3_stage3 (by change 1≤3*k-4; omega))
  exact F.Good3_of_keeps2 (F.keeps2_stage6 _)
    (F.Good3_of_keeps2 (F.keeps2_stage5 _ _) h)

theorem rotate_clause (l : Int) (ys : List Int) (hl : l≠0) (hy : Valid ys) :
    clause (ys++[l])=clause (l::ys) := by
  apply canonical_ext _ _ (canonical_normalize _ _) (canonical_normalize _ _)
  intro α
  change (clause (ys++[l])).val α = (clause (l::ys)).val α
  have hleft : Valid (ys++[l]) := by
    intro x hx
    rcases List.mem_append.mp hx with hx|hx
    · exact hy x hx
    · simpa only [List.mem_singleton.mp hx] using hl
  have hright : Valid (l::ys) := by
    intro x hx
    rcases List.mem_cons.mp hx with rfl|hx
    · exact hl
    · exact hy x hx
  rw [val_clause (ys++[l]) hleft,val_clause (l::ys) hright]
  simp only [sum_append,sum_cons,sum_nil]; ring

def coverageTokens (k : Nat) (hk : 3≤k) :=
  finishTokens (db k hk) ((front k hk).s.Bv:Int) (xs k hk)
def covered (k : Nat) (hk : 3≤k) := db k hk++[clause (xs k hk)]
def finalRows (k : Nat) (hk : 3≤k) := selected (covered k hk) (front k hk).s.var (xs k hk)

theorem coverage_succeeds (k : Nat) (hk : 3≤k) :
    polEval (dbOf (db k hk)) (coverageTokens k hk) []=some (clause (xs k hk)) := by
  let F := fam k (3*k-4)
  have hr := F.final_branch_ready (prior k hk) (prior_good k hk)
  have hb := F.branchList_bounded (prior k hk)
  have hv : Valid (xs k hk) := L3.bounded_nz hb
  have hz : ((front k hk).s.Bv:Int)≠0 := by have h:=hr.2.2.1; change 1≤(front k hk).s.Bv at h; omega
  apply finish_succeeds _ _ _ hz hv
  · exact L3.rup_row_mem F.db5 (front k hk).s.cmds _ (F.final_branch_unit _ (prior_good k hk))
  · have ho := L3.orDef_row_down F.db5 (front k hk).s.cmds _ _ hr.2.1
    change clause ((xs k hk)++[-((front k hk).s.Bv:Int)])∈db k hk at ho
    rw [rotate_clause _ _ (by omega) hv] at ho
    exact ho

/-- Exact original encoding to a constructed one-hot branch choice bank.
    This is the new explicit Lean selector, not a byte-refinement claim for
    Python's simplification cache and not the entire cofactor/transport proof. -/
theorem original_to_selected_branches (k : Nat) (hk : 3≤k) :
    CheckedTrace (OriginalEncoding.rows k (3*k-4)) (finalRows k hk) ∧
    clause (choices (nodes ((front k hk).s.var+1) (xs k hk)))∈finalRows k hk ∧
    (∀c∈choices (nodes ((front k hk).s.var+1) (xs k hk)),
     ∀d∈choices (nodes ((front k hk).s.var+1) (xs k hk)),c≠d →
      clause [-c,-d]∈finalRows k hk) := by
  let F := fam k (3*k-4)
  have hf : CheckedTrace (OriginalEncoding.rows k (3*k-4)) (db k hk) :=
    FableCoverageIntegration.frontend_from_original k hk
  have hp : CheckedTrace (db k hk) (covered k hk) :=
    .cons (.pol _ _ _ (coverage_succeeds k hk)) (.refl _)
  have hDb : L3.DBBounded (db k hk) (front k hk).s.var := by
    have h := L3.exec_bounded F.db5 F.V (front k hk).s.cmds
      (F.db5_bounded (by change 1≤k; omega) (by change 1≤3*k-4; omega)) (front k hk).inv.1
    rw [(front k hk).inv.2] at h; exact h
  have hx := F.branchList_bounded (prior k hk)
  have hs := selection_trace (covered k hk) (front k hk).s.var (xs k hk)
    (hDb.append (L3.clauseRow (xs k hk)) hx) hx
    (F.branchList_nonempty (by change 3≤3*k-4; omega) _ (prior_good k hk)) (by simp [covered])
  exact ⟨L3.Fam.checkedTrace_trans hf (L3.Fam.checkedTrace_trans hp hs.1),hs.2⟩

#print axioms coverage_succeeds
#print axioms original_to_selected_branches
end L3Emitter.FrontendSelection

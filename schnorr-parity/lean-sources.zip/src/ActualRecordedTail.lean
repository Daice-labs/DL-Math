import RecordedActivatedReplay

namespace L3Emitter.ActualRecordedTail
open EREF EREF.GeneralRED ActualLowerComposition RecordedScopedTrace

/-- Executable replay over the actual completed lower-formula image. The input
is recorded lower proof data, not a proof-valued Scoped argument. Construction
of that input by recursion on n remains a separate obligation. -/
def emit (n : Nat) (hn : 2 ≤ n) (N : Nat) (p : Program) : Program :=
  RecordedActivatedReplay.program (inputs n hn) (upper n hn) (inputs n hn) amount
    (-((ceiling n hn+N+1 : Nat) : Int)) p

theorem accepts (n : Nat) (hn : 2 ≤ n) (N : Nat) (p : Program) (E : List Row)
    (hp : check (ceiling n hn) (ceiling n hn+N+1) (inputs n hn) p = some E) :
    check (ceiling n hn) (ceiling n hn+N+1)
      (ActivatedReplay.frame (upper n hn) (inputs n hn) amount (ceiling n hn+N+1)++inputs n hn)
      (emit n hn N p) =
        some (ActivatedReplay.frame (upper n hn) (inputs n hn) amount (ceiling n hn+N+1)++E) := by
  have h := RecordedActivatedReplay.program_accepts (ceiling n hn) (ceiling n hn+N+1) (by omega)
    (inputs n hn) E (upper n hn) (inputs n hn) amount p (upper_bounded n hn)
    (inputs_canonical n hn) (fun _ h=>h) (fun R _=>amount_pos R) hp
  simpa only [emit,RecordedActivatedReplay.frame,ActivatedReplay.frame,
    GuardedReplay.frame,GuardActivation.bank,Int.natAbs_neg,Int.natAbs_natCast] using h

theorem original_to_replayed_result (n : Nat) (hn : 2 ≤ n) (N : Nat)
    (hN : FamilyNamespace.variableCount n (3*n-4) ≤ N) (p : Program) (E : List Row)
    (hp : check (ceiling n hn) (ceiling n hn+N+1) (inputs n hn) p = some E) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4))
      (ActivatedReplay.frame (upper n hn) (inputs n hn) amount (ceiling n hn+N+1)++E) :=
  original_to_single_tail n hn N hN E p.length
    (to_scoped (ceiling n hn) (ceiling n hn+N+1) (by omega) (inputs n hn) p E hp)

theorem one_main_copy (n : Nat) (hn : 2 ≤ n) (N : Nat) (p : Program) :
    (emit n hn N p).length = p.length := RecordedActivatedReplay.program_length _ _ _ _ _ p

#print axioms accepts
#print axioms original_to_replayed_result
#print axioms one_main_copy
end L3Emitter.ActualRecordedTail

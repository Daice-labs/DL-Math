import ConstructionCountTools

namespace L3Emitter.ConstructionFrontendCountTools
open EREF EREF.GeneralRED L3 L3.Fam

/-- Main commands after expanding extension definitions into RED rows. -/
def command : Cmd→Nat
  | .orDef _ xs => xs.length+1
  | .andDef _ xs => xs.length+1
  | .eqDef .. => 4
  | .rup _ => 1

def list (cs : List Cmd) := (cs.map command).sum
def state {m : Nat} (t : StI m) := list t.s.cmds

@[simp] theorem append (a b : List Cmd) : list (a++b)=list a+list b := by
  simp [list]

@[simp] theorem or_cost {m : Nat} (t : StI m) (xs : List Int) :
    state (t.OR xs).2≤state t+xs.length+1 := by
  have h:=List.length_filter_le (fun l:Int=>decide (1≤l.natAbs ∧ l.natAbs≤t.s.var)) xs
  simp only [state,StI.OR,St.OR,list,List.map_append,List.sum_append,List.map_cons,
    List.map_nil,List.sum_cons,List.sum_nil,command,St.chk]
  omega

@[simp] theorem and_cost {m : Nat} (t : StI m) (xs : List Int) :
    state (t.AND xs).2≤state t+xs.length+1 := by
  have h:=List.length_filter_le (fun l:Int=>decide (1≤l.natAbs ∧ l.natAbs≤t.s.var)) xs
  simp only [state,StI.AND,St.AND,list,List.map_append,List.sum_append,List.map_cons,
    List.map_nil,List.sum_cons,List.sum_nil,command,St.chk]
  omega

@[simp] theorem eq_cost {m : Nat} (hm : 1≤m) (t : StI m) (a b : Int) :
    state (t.EQ hm a b).2=state t+4 := by
  simp [state,StI.EQ,St.EQ,list,command]

@[simp] theorem rup_cost {m : Nat} (t : StI m) (c : List Int) :
    state (t.rup c)=state t+1 := by
  simp [state,StI.rup,St.rup,list,command]

/-- A fold with a state-independent per-step cost; the existing prefix is
counted once. -/
theorem fold_cost {S A : Type} (cost : S→Nat) (step : S→A→S) (xs : List A)
    (s : S) (B : Nat) (h : ∀s a,cost (step s a)≤cost s+B) :
    cost (xs.foldl step s)≤cost s+xs.length*B := by
  induction xs generalizing s with
  | nil => simp
  | cons a xs ih =>
    have ht:=ih (step s a)
    simp only [List.foldl_cons,List.length_cons]
    calc
      _ ≤ cost (step s a)+xs.length*B := ht
      _ ≤ (cost s+B)+xs.length*B := Nat.add_le_add_right (h s a) _
      _ = cost s+(xs.length+1)*B := by ring

theorem gate_length (D : List EREF.Row) (q : Nat) (rs done : List REDWitness.GateRow) :
    (RecordedGate.program D q done rs).length=rs.length := by
  induction rs generalizing done with
  | nil => rfl
  | cons r rs ih => simp only [RecordedGate.program,List.length_cons,ih]

theorem definitions (D : List EREF.Row) (cs : List Cmd) :
    (RecordedFrontendDefs.emit D cs).length=list cs := by
  induction cs generalizing D with
  | nil => rfl
  | cons c cs ih =>
    cases c <;> simp [RecordedFrontendDefs.emit,RecordedDefinitions.emit,gate_length,
      RecordedDefinitions.data,orDefs,andDefs,eqDefs,list,command,ih,List.length_map,Nat.add_comm]

#print axioms fold_cost
#print axioms definitions
end L3Emitter.ConstructionFrontendCountTools

import AliasNetwork

namespace L3Emitter.AliasNetwork
open EREF EREF.GeneralRED REDWitness AliasGateSemantics
variable {base : List Row} {A B : Type}

def Extends (p : StateM (Net base) A) :=
  ∀z,∀R∈z.rows,R∈(p z).2.rows

/-- Local definition semantics under any model of the emitted rows.
    This is deliberately separate from PB inference-leaf correctness. -/
def Spec (α : Val) (p : StateM (Net base) A) (Q : A→Prop) :=
  ∀z,Models α (p z).2.rows → Q (p z).1

theorem pure_extends (a : A) : Extends (pure a : StateM (Net base) A) := by
  intro z R hr;exact hr

theorem bind_extends (p : StateM (Net base) A) (f : A→StateM (Net base) B)
    (hp : Extends p) (hf : ∀a,Extends (f a)) : Extends (p >>= f) := by
  intro z R hr;exact hf (p z).1 (p z).2 R (hp z R hr)

theorem pure_spec (α : Val) (a : A) (Q : A→Prop) (hq : Q a) :
    Spec α (pure a : StateM (Net base) A) Q := fun _ _=>hq

theorem bind_spec (α : Val) (p : StateM (Net base) A) (f : A→StateM (Net base) B)
    (P : A→Prop) (Q : B→Prop) (hf : ∀a,Extends (f a))
    (hp : Spec α p P) (hq : ∀a,P a→Spec α (f a) Q) : Spec α (p >>= f) Q := by
  intro z hm
  have hmid:=models_mono α (p z).2.rows (f (p z).1 (p z).2).2.rows
    (hf (p z).1 (p z).2) hm
  exact hq (p z).1 (hp z hmid) (p z).2 hm

theorem spec_mono (α : Val) (p : StateM (Net base) A) (P Q : A→Prop)
    (hp : Spec α p P) (h : ∀a,P a→Q a) : Spec α p Q := fun z hm=>h _ (hp z hm)

theorem gate_extends (b : Bool) (xs : List Bit) : Extends (gate (base:=base) b xs) :=
  fun z=>push_retains z b xs

theorem and_spec (α : Val) (xs : List Bit) :
    Spec α (AND (base:=base) xs) (fun q=>eval α q=xs.all (eval α)) :=
  fun z hm=>gate_value z true xs α hm

theorem or_spec (α : Val) (xs : List Bit) :
    Spec α (OR (base:=base) xs) (fun q=>eval α q=xs.any (eval α)) :=
  fun z hm=>gate_value z false xs α hm

theorem mux_extends (c a b : Bit) : Extends (MUX (base:=base) c a b) := by
  apply bind_extends _ _ (gate_extends _ _)
  intro l
  exact bind_extends _ _ (gate_extends _ _) (fun r=>gate_extends _ _)

theorem eval_neg (α : Val) (a : Bit) : eval α (neg a)=!eval α a :=
  truth_neg α a.val a.property

theorem mux_spec (α : Val) (c a b : Bit) :
    Spec α (MUX (base:=base) c a b)
      (fun q=>eval α q=if eval α c then eval α a else eval α b) := by
  unfold MUX
  refine bind_spec α (AND [c,a]) (fun l=> do
    let r ← AND [neg c,b]
    OR [l,r]) _ _
    (fun l=>bind_extends _ _ (gate_extends _ _) (fun r=>gate_extends _ _))
    (and_spec α [c,a]) ?_
  intro l hl
  refine bind_spec α (AND [neg c,b]) (fun r=>OR [l,r]) _ _
    (fun r=>gate_extends _ _) (and_spec α [neg c,b]) ?_
  intro r hr
  refine spec_mono α (OR [l,r]) _ _ (or_spec α [l,r]) ?_
  intro q hq
  simp only [List.all_cons,List.all_nil,Bool.and_true] at hl hr
  simp only [List.any_cons,List.any_nil,Bool.or_false] at hq
  rw [hq,hl,hr,eval_neg]
  cases eval α c <;> simp

theorem map_extends (xs : List A) (f : A→StateM (Net base) B)
    (hf : ∀a∈xs,Extends (f a)) : Extends (xs.mapM f) := by
  induction xs with
  | nil => exact pure_extends []
  | cons a as ih =>
    simp only [List.mapM_cons]
    apply bind_extends _ _ (hf a (by simp))
    intro b
    apply bind_extends _ _ (ih (by intro a ha;exact hf a (by simp [ha])))
    intro bs;exact pure_extends _

theorem map_spec (α : Val) (xs : List A) (f : A→StateM (Net base) B) (R : A→B→Prop)
    (he : ∀a∈xs,Extends (f a)) (hf : ∀a∈xs,Spec α (f a) (R a)) :
    Spec α (xs.mapM f) (List.Forall₂ R xs) := by
  induction xs with
  | nil => exact pure_spec α [] _ .nil
  | cons a as ih =>
    simp only [List.mapM_cons]
    refine bind_spec α (f a) (fun b=> do
      let bs ← as.mapM f
      pure (b::bs)) (R a) _ (fun b=>
      bind_extends _ _ (map_extends as f (by intro a ha;exact he a (by simp [ha]))) (fun bs=>pure_extends _))
      (hf a (by simp)) ?_
    intro b hb
    refine bind_spec α (as.mapM f) (fun bs=>pure (b::bs)) _ _ (fun bs=>pure_extends _)
      (ih (by intro a ha;exact he a (by simp [ha])) (by intro a ha;exact hf a (by simp [ha]))) ?_
    intro bs hbs
    exact pure_spec α _ _ (.cons hb hbs)

theorem select_extends (xs : List (Bit×Bit)) : Extends (select (base:=base) xs) :=
  bind_extends _ _ (map_extends xs _ (fun _ _=>gate_extends _ _)) (fun _=>gate_extends _ _)

theorem forall2_any (xs : List A) (ys : List B) (f : A→Bool) (g : B→Bool)
    (h : List.Forall₂ (fun a b=>g b=f a) xs ys) : ys.any g=xs.any f := by
  induction h with
  | nil => rfl
  | cons h ht ih => simp only [List.any_cons];rw [h,ih]

theorem select_spec (α : Val) (xs : List (Bit×Bit)) :
    Spec α (select (base:=base) xs)
      (fun q=>eval α q=xs.any (fun p=>eval α p.1 && eval α p.2)) := by
  intro z hm
  let ts := (xs.mapM (fun p=>AND (base:=base) [p.1,p.2])) z
  have hmid : Models α ts.2.rows :=
    models_mono α _ _ (gate_extends false ts.1 ts.2) hm
  have hmap := map_spec (base:=base) α xs (fun p=>AND [p.1,p.2])
    (fun p t=>eval α t=(eval α p.1 && eval α p.2))
    (fun _ _=>gate_extends true _)
    (fun p _=>by simpa using and_spec (base:=base) α [p.1,p.2]) z hmid
  have hor := or_spec (base:=base) α ts.1 ts.2 hm
  exact hor.trans (forall2_any _ _ _ _ hmap)

#print axioms bind_spec
#print axioms mux_spec
#print axioms select_spec
end L3Emitter.AliasNetwork

import NumericCofactorNamespace
namespace L3Emitter.NumericClauseFields
open EREF EREF.GeneralRED REDWitness ByteOperandBounds

theorem insert_length (v:Nat) (xs:List Nat):(insertVar v xs).length≤xs.length+1:=by
  induction xs with
  | nil=>simp[insertVar]
  | cons x xs ih=>simp only[insertVar];split_ifs <;> simp only[List.length_cons] <;> omega

theorem vars_length (ts:List (Nat×Int)):(varsOf ts).length≤ts.length:=by
  induction ts with
  | nil=>simp[varsOf]
  | cons t ts ih=>
    change (insertVar t.2.natAbs (varsOf ts)).length≤ts.length+1
    exact (insert_length _ _).trans (by omega)

theorem sum_bounds (ts:List (Nat×Int)) (v:Nat):posSum v ts≤totalL ts ∧ negSum v ts≤totalL ts:=by
  induction ts with
  | nil=>simp[posSum,negSum,totalL]
  | cons t ts ih=>
    obtain ⟨a,l⟩:=t
    simp only[posSum,negSum,totalL];split_ifs <;> omega

theorem group_coefficient (ts:List (Nat×Int)) (v:Nat) (t:Nat×Int)
    (h:groupTerm ts v=some t):t.1≤totalL ts:=by
  have hs:=sum_bounds ts v
  dsimp only [groupTerm] at h
  split_ifs at h <;> (cases Option.some.inj h;dsimp;omega)

theorem cancel_bound (ts:List (Nat×Int)) (vs:List Nat):cancelSum ts vs≤vs.length*totalL ts:=by
  induction vs with
  | nil=>simp[cancelSum]
  | cons v vs ih=>
    have h: min (posSum v ts) (negSum v ts)≤totalL ts:=(Nat.min_le_left ..).trans (sum_bounds ts v).1
    simp only[cancelSum,List.length_cons,Nat.add_mul,Nat.one_mul]
    omega

theorem signFix_ones (ls:List Int):signFix (ls.map (fun l=>(1,l)))=(ls.map (fun l=>(1,l)),0):=by
  induction ls with
  | nil=>rfl
  | cons l ls ih=>simp[signFix,ih]

theorem total_ones (ls:List Int):totalL (ls.map (fun l=>(1,l)))=ls.length:=by
  induction ls <;> simp_all[totalL,Nat.add_comm]

/-- This counts numeric magnitudes, including the signed RHS after
normalization. It does not confuse the number of literals with a byte count. -/
theorem clause_fields (M:Nat) (ls:List Int) (hl:∀l∈ls,l.natAbs≤M)
    (hc:ls.length≤M) (hb:1+ls.length^2≤M):RowBound M (clause ls):=by
  have hf:=signFix_ones ls
  have hv:=vars_length (ls.map (fun l=>(1,l)))
  have ht:=total_ones ls
  have hcan:=cancel_bound (ls.map (fun l=>(1,l))) (varsOf (ls.map (fun l=>(1,l))))
  rw[ht] at hcan
  simp only[List.length_map] at hv
  have hcb:cancelSum (ls.map (fun l=>(1,l))) (varsOf (ls.map (fun l=>(1,l))))≤ls.length^2:=by
    have h:=Nat.mul_le_mul_right ls.length hv
    nlinarith
  constructor
  · intro t ht'
    constructor
    · change t∈(normalize (ls.map (fun l=>(1,l))) 1).terms at ht'
      simp only [EREF.normalize,hf] at ht'
      obtain ⟨v,hv,he⟩:=List.mem_filterMap.mp ht'
      exact (group_coefficient _ v t he).trans (ht ▸ hc)
    · exact RowSupport.clause_bound M ls hl t ht'
  · change (EREF.normalize (ls.map (fun l=>(1,l))) 1).bound.natAbs≤M
    simp only [EREF.normalize,hf,Int.sub_zero]
    omega

#print axioms clause_fields
end L3Emitter.NumericClauseFields

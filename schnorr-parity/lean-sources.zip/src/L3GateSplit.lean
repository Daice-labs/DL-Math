import L3GateBinding

namespace L3.Fam
open L3 EREF EREF.GeneralRED
variable (F : Fam)

theorem gateFinal_obls (hk : 2≤F.k) (hs : 1≤F.s) (t : StI F.V) (ht : F.Good3 t)
    (g bit cb q0 q1 : Nat) (hg1 : 1≤g) (hg : g<F.s) (hb : bit<2)
    (hc : 1≤cb ∧ cb≤t.s.var) (hv : 1≤t.s.veq g bit ∧ t.s.veq g bit≤t.s.var)
    (hf : F.ForceRecord t) (h0 : F.PortRecord g 0 bit cb q0 t) (h1 : F.PortRecord g 1 bit cb q1 t)
    (heq : Cmd.eqDef (t.s.veq g bit) (F.val g (F.bitX bit) : Int) (F.val g (F.bitY bit) : Int)∈t.s.cmds) :
    ObligationsChecked (exec F.db5 t.s.cmds) (splitCmds (F.gateRoot t bit cb g) (F.gateVs bit g)) := by
  have hDB := exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) hs) t.inv.1
  rw [t.inv.2] at hDB
  apply split_obls _ t.s.var hDB _ _ (F.gateRoot_bound t ht bit cb g hg hc hv) (F.gateVs_bound hk t bit g hb hg)
  intro D hm hD lf hlf
  have hg0 : ¬g=0 := by omega
  simp only [gateRoot,gateVs,hg0,↓reduceIte,leaves,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hlf
  rcases hlf with (((((rfl | rfl) | (rfl | rfl)) | ((rfl | rfl) | (rfl | rfl))) | (((rfl | rfl) | (rfl | rfl)) | ((rfl | rfl) | (rfl | rfl)))) | ((((rfl | rfl) | (rfl | rfl)) | ((rfl | rfl) | (rfl | rfl))) | (((rfl | rfl) | (rfl | rfl)) | ((rfl | rfl) | (rfl | rfl)))))
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false false false false false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false false false false true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false false false true false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false false false true true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false true false false false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false true false false true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false true false true false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false true false true true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false false true false false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false false true false true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false false true true false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false false true true true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false true true false false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false true true false true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false true true true false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm false true true true true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true false false false false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true false false false true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true false false true false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true false false true true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true true false false false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true true false false true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true true false true false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true true false true true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true false true false false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true false true false true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true false true true false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true false true true true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true true true false false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true true true false true
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true true true true false
  · exact F.gate_leaf_from_database hk t ht g bit cb (t.s.veq g bit) q0 q1 hg1 hg hb hc.1 hv.1 hf h0 h1 heq D hD hm true true true true true

theorem firstFinal_obls (hk : 2≤F.k) (hs : 1≤F.s) (t : StI F.V) (ht : F.Good3 t)
    (bit cb : Nat) (hb : bit<2) (hc : 1≤cb ∧ cb≤t.s.var)
    (hv : 1≤t.s.veq 0 bit ∧ t.s.veq 0 bit≤t.s.var)
    (hcb : Cmd.eqDef cb (F.fn 0 bit : Int) (F.fn 0 (bit+2) : Int)∈t.s.cmds)
    (heq : Cmd.eqDef (t.s.veq 0 bit) (F.val 0 (F.bitX bit) : Int) (F.val 0 (F.bitY bit) : Int)∈t.s.cmds) :
    ObligationsChecked (exec F.db5 t.s.cmds) (splitCmds (F.gateRoot t bit cb 0) (F.gateVs bit 0)) := by
  have hDB := exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) hs) t.inv.1
  rw [t.inv.2] at hDB
  apply split_obls _ t.s.var hDB _ _ (F.gateRoot_bound t ht bit cb 0 hs hc hv) (F.gateVs_bound hk t bit 0 hb hs)
  intro D hm hD lf hlf
  simp only [gateRoot,gateVs,↓reduceIte,leaves,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hlf
  rcases hlf with rfl | rfl
  · exact F.first_gate_from_database hk hs t bit cb (t.s.veq 0 bit) hb hc.1 hv.1 hcb heq D hD hm false
  · exact F.first_gate_from_database hk hs t bit cb (t.s.veq 0 bit) hb hc.1 hv.1 hcb heq D hD hm true

/-- Checked append for an actual bounded split. -/
theorem checked_split (t : StI F.V) (c vs : List Int)
    (hc : Bounded t.s.var c) (hv : Bounded t.s.var vs)
    (ho : ObligationsChecked F.db5 t.s.cmds)
    (hs : ObligationsChecked (exec F.db5 t.s.cmds) (splitCmds c vs)) :
    ObligationsChecked F.db5 (t.split c vs).s.cmds := by
  rw [(StI.split_cmds vs t c hc hv).1]
  exact obligations_append _ _ _ ho hs

#print axioms gateFinal_obls
#print axioms firstFinal_obls
end L3.Fam

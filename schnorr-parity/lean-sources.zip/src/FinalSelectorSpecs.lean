import FinalSelectorSources
namespace L3Emitter.FinalSelectorSpecs
open EREF EREF.GeneralRED REDWitness AliasNetwork FinalOutputDefinitions FinalSelectorSources
abbrev Lit (n:Nat):=Fin (W n-1)×Bool
def pair (n:Nat) (i j:Fin (W n-1)):List (Lit n):=[(i,false),(j,false)]
def specs (n:Nat):List (List (Lit n)):=alo n::(List.finRange (W n-1)).flatMap (fun i=>
  (List.finRange (W n-1)).filterMap (fun j=>if i<j then some (pair n i j) else none))
theorem spec_cases (n:Nat) (ls:List (Lit n)) (hs:ls∈specs n):
    ls=alo n ∨ ∃i j:Fin (W n-1),i<j ∧ ls=pair n i j:=by
  rcases List.mem_cons.mp hs with h|h
  · exact Or.inl h
  · obtain ⟨i,hi,h⟩:=List.mem_flatMap.mp h
    obtain ⟨j,hj,h⟩:=List.mem_filterMap.mp h
    split at h
    · rename_i hij;exact Or.inr ⟨i,j,hij,(Option.some.inj h).symm⟩
    · contradiction

theorem pair_mem (n:Nat) (i j:Fin (W n-1)) (h:i<j):pair n i j∈specs n:=by
  apply List.mem_cons_of_mem
  exact List.mem_flatMap.mpr ⟨i,by simp,List.mem_filterMap.mpr ⟨j,by simp,by simp [h]⟩⟩
theorem nonempty (n:Nat) (hn:2≤n) (ls:List (Lit n)) (hs:ls∈specs n):ls≠[]:=by
  rcases spec_cases n ls hs with rfl|⟨i,j,hij,rfl⟩
  · intro h;have hh:=congrArg List.length h;simp only [alo,List.length_ofFn,List.length_nil] at hh
    unfold W AliasAssembly.width RankConstruction.width at hh;omega
  · simp [pair]

theorem valid (n:Nat) (a:Fin (W n-1)→Bit) (ls:List (Lit n)):
    Valid (GuardedVectorTransport.literals a ls):=by
  intro l hl;obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hl;exact GuardedVectorTransport.nonzero _ _

theorem raw_pairs (n:Nat) (hn:2≤n) (p:Fin 2) (i j:Fin (W n-1)) (hij:i<j):
    GuardedVectorTransport.row (raw n hn p) (pair n i j)∈D n hn:=by
  have hp:=LowerSelectorAMO.pairs n hn (lastRank n) p.val (by unfold lastRank RankConstruction.width;omega) p.isLt
  have hw:=width_binding n hn
  rw [LowerSelectorAMO.xs,hw] at hp
  have h:=List.pairwise_ofFn.mp hp hij
  apply List.mem_append_left
  apply FinalOutputDefinitions.retains
  apply List.mem_append_left
  apply List.mem_append_left
  apply GateEvaluationBindings.selector_keep
  apply LowerSelectorComplete.predecessor_kept
  apply List.mem_append_left
  exact h

theorem raw_rows (n:Nat) (hn:2≤n) (p:Fin 2) (ls:List (Lit n)) (hs:ls∈specs n):
    GuardedVectorTransport.row (raw n hn p) ls∈D n hn:=by
  rcases spec_cases n ls hs with rfl|⟨i,j,hij,rfl⟩
  · exact raw_alo n hn p
  · exact raw_pairs n hn p i j hij

theorem terminal_pair (n:Nat) (hn:2≤n) (i j:Fin (W n-1)) (hij:i<j):
    clause [-(source n hn (coord n i)).val,-(source n hn (coord n j)).val]∈D n hn:=by
  apply source_keep
  exact (GateOrderSources.all_source_rows n hn (n+1+OutputPhaseRows.lastGate n)
    (by unfold OutputPhaseRows.lastGate;omega)).2 (coord n i) (coord n j) hij

theorem dummy_true (n:Nat) (hn:2≤n) (ls:List (Lit n)) (hs:ls∈specs n):
    (PrimaryAliasBank.cfg n hn).T.val∈GuardedVectorTransport.literals (FinalOutputSlots.alternative n hn (1:Fin 2)) ls:=by
  rcases spec_cases n ls hs with rfl|⟨i,j,hij,rfl⟩
  · apply List.mem_map.mpr
    let z:Fin (W n-1):=⟨0,by unfold W AliasAssembly.width RankConstruction.width;omega⟩
    refine ⟨(z,true),List.mem_ofFn.mpr ⟨z,rfl⟩,?_⟩
    simp [GuardedVectorTransport.signed,FinalOutputSlots.alternative,z]
  · have hj:j.val≠0:=by have hh:i.val<j.val:=hij;omega
    simp [GuardedVectorTransport.literals,pair,GuardedVectorTransport.signed,FinalOutputSlots.alternative,hj,PrimaryAliasBank.false_bit,neg]
#print axioms raw_rows
#print axioms dummy_true
end L3Emitter.FinalSelectorSpecs

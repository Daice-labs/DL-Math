import AliasAssembly

namespace L3Emitter.AliasNetwork
open EREF EREF.GeneralRED
variable {base : List Row} {A B : Type}

/-- Counts actual fresh definitions in the emitted network, not expression
    nodes supplied by an external estimate. -/
def Cost (p : StateM (Net base) A) (c : Nat) :=
  ∀z,(p z).2.gates.length≤z.gates.length+c

theorem cost_mono (p : StateM (Net base) A) (a b : Nat) (h : Cost p a) (hab : a≤b) :
    Cost p b := by intro z;have:=h z;omega

theorem pure_cost (a : A) : Cost (pure a : StateM (Net base) A) 0 := by
  intro z;exact Nat.le_refl _

theorem bind_cost (p : StateM (Net base) A) (f : A→StateM (Net base) B)
    (c d : Nat) (hp : Cost p c) (hf : ∀a,Cost (f a) d) : Cost (p >>= f) (c+d) := by
  intro z;have h1:=hp z;have h2:=hf (p z).1 (p z).2
  change (f (p z).1 (p z).2).2.gates.length≤_
  omega

theorem gate_cost (b : Bool) (xs : List Bit) : Cost (gate (base:=base) b xs) 1 := by
  intro z;exact (push_count z b xs).le

theorem mux_cost (c a b : Bit) : Cost (MUX (base:=base) c a b) 3 :=
  bind_cost _ _ 1 2 (gate_cost true _) (fun _=>
    bind_cost _ _ 1 1 (gate_cost true _) (fun _=>gate_cost false _))

theorem map_cost (xs : List A) (f : A→StateM (Net base) B) (c : Nat)
    (hf : ∀a∈xs,Cost (f a) c) : Cost (xs.mapM f) (xs.length*c) := by
  induction xs with
  | nil => simpa using pure_cost (base:=base) ([]:List B)
  | cons a as ih =>
    have h:=bind_cost (f a) (fun b=>do let bs ← as.mapM f;pure (b::bs))
      c (as.length*c+0) (hf a (by simp))
      (fun b=>bind_cost _ _ _ 0 (ih (by intro a ha;exact hf a (by simp [ha])))
        (fun bs=>pure_cost _))
    simpa [List.mapM_cons,Nat.add_mul,Nat.add_comm] using h

theorem select_cost (xs : List (Bit×Bit)) : Cost (select (base:=base) xs) (xs.length+1) := by
  simpa using bind_cost (xs.mapM (fun p=>AND [p.1,p.2])) OR _ 1
    (map_cost xs _ 1 (fun _ _=>gate_cost true _)) (fun _=>gate_cost false _)

theorem tabulate_cost (n : Nat) (f : Fin n→StateM (Net base) A) (c : Nat)
    (hf : ∀i,Cost (f i) c) : Cost (tabulate n f) (n*c) := by
  induction n with
  | zero => simpa [tabulate] using pure_cost (base:=base) (fun i:Fin 0=>Fin.elim0 i : Fin 0→A)
  | succ n ih =>
    have h:=bind_cost (f 0) (fun a=>do
      let as ← tabulate n (fun i=>f i.succ)
      pure (Fin.cases a as : Fin (n+1)→A)) c (n*c+0) (hf 0)
      (fun a=>bind_cost _ _ _ 0 (ih _ (fun i=>hf i.succ)) (fun as=>pure_cost _))
    simpa [tabulate,Nat.add_mul,Nat.add_comm] using h

def Expr.cost : Expr→Nat
  | .lit _ => 0
  | .and a b | .or a b => a.cost+b.cost+1
  | .mux c a b => c.cost+a.cost+b.cost+3

theorem Expr.compile_cost (e : Expr) : Cost (e.compile (base:=base)) e.cost := by
  induction e with
  | lit b => exact pure_cost _
  | and a b ha hb =>
    simpa [Expr.cost,Nat.add_assoc] using
      bind_cost a.compile _ a.cost (b.cost+1) ha
        (fun x=>bind_cost b.compile _ b.cost 1 hb (fun y=>gate_cost true _))
  | or a b ha hb =>
    simpa [Expr.cost,Nat.add_assoc] using
      bind_cost a.compile _ a.cost (b.cost+1) ha
        (fun x=>bind_cost b.compile _ b.cost 1 hb (fun y=>gate_cost false _))
  | mux c a b hc ha hb =>
    simpa [Expr.cost,Nat.add_assoc] using
      bind_cost c.compile _ c.cost (a.cost+(b.cost+3)) hc (fun x=>
        bind_cost a.compile _ a.cost (b.cost+3) ha (fun y=>
          bind_cost b.compile _ b.cost 3 hb (fun z=>mux_cost x y z)))

theorem port_cost {w : Nat} (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) :
    Cost (port (base:=base) k g sel as) ((w+2)*(k+g+1)) :=
  tabulate_cost _ _ _ (fun i=>by
    simpa using select_cost (base:=base) ((List.range (k+g)).map (fun j=>(sel j,as j i))))

end L3Emitter.AliasNetwork

namespace L3Emitter.RecursiveAliases
open EREF EREF.GeneralRED AliasNetwork
variable {base : List Row} {w : Nat}

theorem coordinate_cost (c : Config Bit) (g : Nat) (l r : AliasBits w) (i : Fin (w+2)) :
    (coordinate c g l r i).cost≤25 := by
  unfold coordinate
  split_ifs <;> simp [Expr.cost,lookup]

theorem step_cost (c : Config Bit) (as : Nat→AliasBits w) (g : Nat) :
    Cost (step (base:=base) c as g) ((w+2)*(2*(c.k+g+1)+25)) := by
  have h:=bind_cost (base:=base) (port c.k g (c.sel g 0) as) _
    ((w+2)*(c.k+g+1)) ((w+2)*(c.k+g+1)+(w+2)*25) (port_cost _ _ _ _)
    (fun l=>bind_cost (port c.k g (c.sel g 1) as) _
      ((w+2)*(c.k+g+1)) ((w+2)*25) (port_cost _ _ _ _) (fun r=>
        tabulate_cost (w+2) _ 25 (fun i=>
          cost_mono _ _ _ (Expr.compile_cost _) (coordinate_cost c g l r i))))
  convert h using 1 <;> ring

theorem run_cost (c : Config Bit) (as : Nat→AliasBits w) (g m : Nat) :
    Cost (run (base:=base) c as g m) (m*((w+2)*(2*(c.k+g+m)+25))) := by
  induction m generalizing as g with
  | zero => simpa using pure_cost (base:=base) as
  | succ m ih =>
    have h:=bind_cost (base:=base) (step c as g) (fun a=>run c (Function.update as (c.k+g) a) (g+1) m) ((w+2)*(2*(c.k+g+1)+25))
      (m*((w+2)*(2*(c.k+(g+1)+m)+25))) (step_cost c as g) (fun a=>ih _ (g+1))
    apply cost_mono _ _ _ h
    have hm: (w+2)*(2*(c.k+g+1)+25)≤(w+2)*(2*(c.k+g+(m+1))+25) :=
      Nat.mul_le_mul_left _ (by omega)
    nlinarith

#print axioms coordinate_cost
#print axioms step_cost
#print axioms run_cost
end L3Emitter.RecursiveAliases

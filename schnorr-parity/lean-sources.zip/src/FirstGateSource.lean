import FirstPortOneHot

namespace L3Emitter.FirstGateSource
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases SelectedVectorOneHot
variable {base:List Row} {A:Type} {w:Nat}

theorem tabulate_property (m:Nat) (f:Fin m→StateM (Net base) A)
    (P:Fin m→A→Prop) (hf:∀i z,P i (f i z).1) :
    ∀z i,P i ((tabulate m f z).1 i) := by
  induction m with
  | zero=>intro z i;exact Fin.elim0 i
  | succ m ih=>
    intro z i
    refine Fin.cases ?_ (fun j=>?_) i
    · exact hf 0 z
    · exact ih (fun j=>f j.succ) (fun j=>P j.succ) (fun j=>hf j.succ) (f 0 z).2 j

theorem step_zero_source (c:Config Bit) (as:Nat→AliasBits w) (z:Net base) (i:Fin w) :
    (RecursiveAliases.step c as 0 z).1 (position i)=if i.val=0 then c.T else c.F := by
  let l:=port c.k 0 (c.sel 0 0) as z
  let r:=port c.k 0 (c.sel 0 1) as l.2
  have h:=tabulate_property (w+2) (fun i=>(coordinate c 0 l.1 r.1 i).compile)
    (fun i q=>∀hi:i.val<w,q=if i.val=0 then c.T else c.F)
    (by intro i t hi;simp only [coordinate,if_pos rfl,if_pos hi,Expr.compile];rfl) r.2 (position i)
  exact h i.isLt

/-- Previously constructed aliases are literal references. The forward fold
    never overwrites an earlier source, including the shared gate-zero alias. -/
theorem run_earlier (c:Config Bit) (as:Nat→AliasBits w) (g m:Nat) (z:Net base)
    (j:Nat) (hj:j<c.k+g) : (RecursiveAliases.run c as g m z).1 j=as j := by
  induction m generalizing as g z with
  | zero=>rfl
  | succ m ih=>
    let a:=RecursiveAliases.step c as g z
    change (RecursiveAliases.run c (Function.update as (c.k+g) a.1) (g+1) m a.2).1 j=as j
    rw [ih _ _ _ (by omega)]
    exact Function.update_of_ne (by omega) _ _

theorem built_zero (n:Nat) (hn:2≤n) :
    (AliasAssembly.built n hn).1.2 (n+1)=
      (RecursiveAliases.step (PrimaryAliasBank.cfg n hn) (FirstPortRelations.initialAliases n hn)
        0 (PrimaryAliasBank.context n hn).2).1 := by
  let c:=PrimaryAliasBank.cfg n hn
  let as:=FirstPortRelations.initialAliases n hn
  let z:=(PrimaryAliasBank.context n hn).2
  have hc:c.k=n+1:=rfl
  have he:3*(n+1)-4=(3*(n+1)-5)+1:=by omega
  change (RecursiveAliases.run c as 0 (3*(n+1)-4) z).1 (n+1)=_
  rw [he]
  change (RecursiveAliases.run c (Function.update as (c.k+0)
    (RecursiveAliases.step c as 0 z).1) 1 (3*(n+1)-5) (RecursiveAliases.step c as 0 z).2).1 (n+1)=_
  rw [run_earlier c _ 1 _ _ (n+1) (by omega)]
  change Function.update as c.k (RecursiveAliases.step c as 0 z).1 (n+1)=_
  rw [hc]
  simp only [Function.update_apply,ite_true]
  rfl

theorem built_zero_source (n:Nat) (hn:2≤n) (i:Fin (AliasAssembly.width (n+1))) :
    (AliasAssembly.built n hn).1.2 (n+1) (position i)=
      FirstPortRelations.initialAliases n hn 0 (position i) := by
  rw [built_zero,step_zero_source]
  simp [FirstPortRelations.initialAliases,PrimaryAliasRows.coordinate]

theorem source_rows_congr {D:List Row} {a b:AliasBits w} (ha:SourceRows D a)
    (h:∀i:Fin w,b (position i)=a (position i)) : SourceRows D b := by
  have he:sourceLiterals b=sourceLiterals a:=by
    unfold sourceLiterals
    congr 1
    funext i
    rw [h i]
  constructor
  · rw [he];exact ha.1
  · intro i j hij;rw [h i,h j];exact ha.2 i j hij

theorem actual_first_gate_source_rows (n:Nat) (hn:2≤n) :
    SourceRows (FirstPortOneHot.result n hn) ((AliasAssembly.built n hn).1.2 (n+1)) := by
  have h:=PrimaryAliasBank.source_rows n hn 0 (by omega)
  have keep:∀R∈PrimaryAliasBank.result n hn,R∈FirstPortOneHot.result n hn := by
    intro R hr
    exact FirstPortOneHot.block_retains n hn 1 _ R (FirstPortOneHot.block_retains n hn 0 _ R hr)
  apply source_rows_congr (a:=FirstPortRelations.initialAliases n hn 0)
    ⟨keep _ h.1,fun i j hij=>keep _ (h.2 i j hij)⟩
  exact built_zero_source n hn

#print axioms run_earlier
#print axioms actual_first_gate_source_rows
end L3Emitter.FirstGateSource

import BetaPort

set_option maxHeartbeats 2000000
namespace L3Emitter.BetaValue
open EREF EREF.GeneralRED REDWitness ForcingCandidates PriorityBank CofactorSemantics
abbrev Job (n : Nat) := BetaPort.Job n × Bool

def jobs (n : Nat) (hn : 2≤n) : List (Job n) := (BetaPort.jobs n hn).flatMap fun j => [(j,false),(j,true)]
def s {n : Nat} (j : Job n) : Int := j.1.1.1.choice
def p (n : Nat) (hn : 2≤n) (j : Job n) := BetaPort.portLiteral n hn j.1.1.2 j.1.2
def q (n : Nat) (hn : 2≤n) (j : Job n) : Int :=
  low n (ConstantCofactor.offset n hn) j.1.1.2.parent.beta (1-j.1.1.2.port) j.1.2
def v (n : Nat) (hn : 2≤n) (j : Job n) :=
  output (low n (ConstantCofactor.offset n hn) j.1.1.2.parent.beta 2 j.1.2) j.2
def a (n : Nat) (j : Job n) := if j.2 then ConstantLookup.literal (n+1) j.1.1.2 else -ConstantLookup.literal (n+1) j.1.1.2
def b (n : Nat) (j : Job n) := if j.2 then ConstantSource.otherLiteral (n+1) j.1.1.2 else -ConstantSource.otherLiteral (n+1) j.1.1.2
def e (n : Nat) (hn : 2≤n) (j : Job n) := ConstantSource.eqBit (n+1) (by omega) j.1.1.2
def C (n : Nat) (hn : 2≤n) (j : Job n) := output (ConstantConstruction.C (n+1) (by omega)) j.2

theorem job_mem (n : Nat) (hn : 2≤n) (j : Job n) : j∈jobs n hn ↔ j.1∈BetaPort.jobs n hn := by
  obtain ⟨j,c⟩:=j;cases c <;> simp [jobs]

theorem constant_retained (n : Nat) (hn : 2≤n) (R:Row) (hR:R∈ConstantConstruction.result (n+1) (by omega)) :
    R∈BetaPort.result n hn := List.mem_append_left _ (PrimaryBank.constant_retained n hn R hR)

theorem semantics_present (n : Nat) (hn : 2≤n) (g x : Nat) (hg:g<3*(n+1)-4)
    (hx:x<FamilyNamespace.truthRows n) (aa bb cc : Bool) :
    goal n (3*(n+1)-4) (ConstantCofactor.offset n hn) g x aa bb cc∈BetaPort.result n hn := by
  have hj : (g,x,aa,bb,cc)∈CofactorSection.jobs n (3*(n+1)-4) := by
    cases aa <;> cases bb <;> cases cc <;> simp [CofactorSection.jobs,hg,hx]
  have hr : goal n (3*(n+1)-4) (ConstantCofactor.offset n hn) g x aa bb cc∈ConstantCofactor.result n hn :=
    List.mem_append_right _ (List.mem_map.mpr ⟨(g,x,aa,bb,cc),hj,rfl⟩)
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hr))

theorem nonzero (n : Nat) (hn : 2≤n) (j : Job n) (hj:j∈jobs n hn) :
    REDWitness.Valid [s j,p n hn j,q n hn j,v n hn j,a n j,b n j,e n hn j,C n hn j] := by
  have h:=BetaPort.valid_job n hn j.1 ((job_mem n hn j).mp hj)
  have hs:=RestrictionBit.choice_above _ _ j.1.1.1 h.1
  have ha:=ConstantLookup.literal_bound (n+1) (by omega) j.1.1.2 h.2.1
  have hb:=(FableEncoding.fam (n+1) (3*(n+1)-4)).fn_pos j.1.1.2.parent.beta (ConstantSource.otherIndex j.1.1.2)
  have he:=(ConstantSource.equality_rows (n+1) (by omega) j.1.1.2 h.2.1).1
  have hp:=output_nonzero _ (low_pos n (ConstantCofactor.offset n hn) j.1.1.2.parent.beta j.1.1.2.port j.1.2) (decide (j.1.1.2.bit=1))
  have hv:=output_nonzero _ (low_pos n (ConstantCofactor.offset n hn) j.1.1.2.parent.beta 2 j.1.2) j.2
  have hC:=output_nonzero (ConstantConstruction.C (n+1) (by omega)) (by unfold ConstantConstruction.C;omega) j.2
  have hq:=low_pos n (ConstantCofactor.offset n hn) j.1.1.2.parent.beta (1-j.1.1.2.port) j.1.2
  have ha' : ConstantLookup.literal (n+1) j.1.1.2≠0 := by intro h0;rw [h0] at ha;simp at ha
  have hb' : ConstantSource.otherLiteral (n+1) j.1.1.2≠0 := by
    change ((FableEncoding.fam (n+1) (3*(n+1)-4)).fn j.1.1.2.parent.beta (ConstantSource.otherIndex j.1.1.2):Int)≠0
    exact_mod_cast (Nat.ne_of_gt hb)
  have hh : a n j≠0 ∧ b n j≠0 := by cases hsign:j.2 <;> simp [a,b,hsign,ha',hb']
  intro l hl;simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · unfold s;omega
  · exact hp
  · unfold q;omega
  · exact hv
  · exact hh.1
  · exact hh.2
  · exact he
  · exact hC

theorem semantics_rows (n : Nat) (hn : 2≤n) (j : Job n) (hj:j∈jobs n hn) :
    clause [-p n hn j,q n hn j,-v n hn j,a n j]∈BetaPort.result n hn ∧
    clause [-p n hn j,-q n hn j,-v n hn j,b n j]∈BetaPort.result n hn := by
  have h:=BetaPort.valid_job n hn j.1 ((job_mem n hn j).mp hj)
  have hw:=wellformed _ _ j.1.1.2 h.2.1
  have hg:j.1.1.2.parent.beta<3*(n+1)-4:=by have:=j.1.1.2.parent.ordered;have:=j.1.1.2.parent.gamma_lt;omega
  have hp:j.1.1.2.port=0 ∨ j.1.1.2.port=1:=by omega
  have ht:j.1.1.2.bit=0 ∨ j.1.1.2.bit=1:=by omega
  have hz:=nonzero n hn j hj
  have perm (A B V F : Int) (hv:REDWitness.Valid [A,B,V,F]) :
      clause [A,B,V,F]=clause [B,A,V,F] :=
    ProjectionTrace.clause_perm _ _ hv (by intro l hl;exact hv l (by simpa [List.mem_cons,or_comm,or_left_comm,or_assoc] using hl))
      (List.Perm.swap ..)
  have hpz:=hz (p n hn j) (by simp)
  have hqz:=hz (q n hn j) (by simp)
  have hvz:=hz (v n hn j) (by simp)
  have haz:=hz (a n j) (by simp)
  have hbz:=hz (b n j) (by simp)
  rcases hp with hp|hp <;> rcases ht with ht|ht
  all_goals
    have h0:=semantics_present n hn j.1.1.2.parent.beta j.1.2 hg h.2.2.2
      (decide (if j.1.1.2.port=0 then j.1.1.2.bit=1 else False))
      (decide (if j.1.1.2.port=0 then False else j.1.1.2.bit=1)) j.2
    have h1:=semantics_present n hn j.1.1.2.parent.beta j.1.2 hg h.2.2.2
      (decide (if j.1.1.2.port=0 then j.1.1.2.bit=1 else True))
      (decide (if j.1.1.2.port=0 then True else j.1.1.2.bit=1)) j.2
    simp only [hp,ht] at h0 h1
    cases hsign:j.2
    all_goals
      simp [goal,fnLiteral,output,hsign] at h0 h1
      constructor
      all_goals
        first
        | simpa [p,q,v,a,b,BetaPort.portLiteral,ConstantLookup.literal,ConstantLookup.index,
            ConstantSource.otherLiteral,ConstantSource.otherIndex,output,hp,ht,hsign] using h0
        | simpa [p,q,v,a,b,BetaPort.portLiteral,ConstantLookup.literal,ConstantLookup.index,
            ConstantSource.otherLiteral,ConstantSource.otherIndex,output,hp,ht,hsign] using h1
        | (rw [perm (-p n hn j) (q n hn j) (-v n hn j) (a n j)
            (by simp [REDWitness.Valid,hpz,hqz,hvz,haz])]
           simpa [p,q,v,a,b,BetaPort.portLiteral,ConstantLookup.literal,ConstantLookup.index,
             ConstantSource.otherLiteral,ConstantSource.otherIndex,output,hp,ht,hsign] using h0)
        | (rw [perm (-p n hn j) (-q n hn j) (-v n hn j) (b n j)
            (by simp [REDWitness.Valid,hpz,hqz,hvz,hbz])]
           simpa [p,q,v,a,b,BetaPort.portLiteral,ConstantLookup.literal,ConstantLookup.index,
             ConstantSource.otherLiteral,ConstantSource.otherIndex,output,hp,ht,hsign] using h1)

theorem premise_rows (n : Nat) (hn : 2≤n) (j : Job n) (hj:j∈jobs n hn) :
    ∀R∈ConstantLeaf.premises (s j) (p n hn j) (q n hn j) (v n hn j)
      (a n j) (b n j) (e n hn j) (C n hn j),R∈BetaPort.result n hn := by
  have h:=BetaPort.valid_job n hn j.1 ((job_mem n hn j).mp hj)
  have hz:=nonzero n hn j hj
  have heq:=ConstantSource.equality_rows (n+1) (by omega) j.1.1.2 h.2.1
  have hsem:=semantics_rows n hn j hj
  have hE : clause [-e n hn j,-b n j,a n j]∈BetaPort.result n hn := by
    cases hsign:j.2
    · simpa [e,b,a,hsign] using constant_retained n hn _ heq.2.2
    · simpa [e,b,a,hsign] using constant_retained n hn _ heq.2.1
  have hSE : clause [-s j,e n hn j]∈BetaPort.result n hn := by
    exact List.mem_append_left _ (List.mem_append_left _
      (ForcingFieldBank.field_present (n+1) (by omega) _ j.1.1.1 j.1.1.2 h.1 h.2.1 h.2.2.1
        (e n hn j) (by simp [e,ConstantSource.eqBit,fields,ConstantSource.front])))
  have hSP : clause [-s j,p n hn j]∈BetaPort.result n hn :=
    List.mem_append_right _ (List.mem_map.mpr ⟨j.1,(job_mem n hn j).mp hj,rfl⟩)
  obtain ⟨z,hz',hid,hf,hb⟩:=ConstantConstruction.source_pair (n+1) (by omega) j.1.1.1 h.1
  have hequal:=ConstantLookup.id_injective _ _ z j.1.1.2 hz' h.2.1 (by omega)
  subst z
  have hc : clause [-s j,-a n j,C n hn j]∈BetaPort.result n hn := by
    cases hsign:j.2
    · have hr:=constant_retained n hn _ hb
      have hsn:=hz (s j) (by simp)
      have hln:=ConstantLookup.literal_bound (n+1) (by omega) j.1.1.2 h.2.1
      have hln' : ConstantLookup.literal (n+1) j.1.1.2≠0:=by intro h0;rw [h0] at hln;simp at hln
      have hcn : (ConstantConstruction.C (n+1) (by omega):Int)≠0 := by unfold ConstantConstruction.C;omega
      have hcnNat : ConstantConstruction.C (n+1) (by omega)≠0 := by exact_mod_cast hcn
      have hp : clause [-s j,-(ConstantConstruction.C (n+1) (by omega):Int),ConstantLookup.literal (n+1) j.1.1.2]=
          clause [-s j,ConstantLookup.literal (n+1) j.1.1.2,-(ConstantConstruction.C (n+1) (by omega):Int)] :=
        ProjectionTrace.clause_perm _ _ (by simp [REDWitness.Valid,hsn,hln',hcnNat])
          (by simp [REDWitness.Valid,hsn,hln',hcnNat]) (List.Perm.cons _ (List.Perm.swap ..))
      change clause [-s j,-(ConstantConstruction.C (n+1) (by omega):Int),ConstantLookup.literal (n+1) j.1.1.2]∈_ at hr
      rw [hp] at hr
      simpa [a,C,output,hsign] using hr
    · simpa [s,a,C,output,hsign] using constant_retained n hn _ hf
  intro R hR
  simp only [ConstantLeaf.premises,List.mem_cons,List.not_mem_nil,or_false] at hR
  rcases hR with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact hsem.1
  · exact hsem.2
  · exact hE
  · exact hSE
  · exact hSP
  · exact hSP
  · exact hc
  · exact hc

def row (n : Nat) (hn : 2≤n) (j : Job n) := clause [-s j,-v n hn j,C n hn j]
def tape (n : Nat) (hn : 2≤n) (j : Job n) := ConstantLeaf.tape (BetaPort.result n hn)
  (s j) (p n hn j) (q n hn j) (v n hn j) (a n j) (b n j) (e n hn j) (C n hn j)
def program (n : Nat) (hn : 2≤n) : AliasProgram.Program := (jobs n hn).map fun j => (row n hn j,tape n hn j)
def result (n : Nat) (hn : 2≤n) := BetaPort.result n hn++(jobs n hn).map (row n hn)

theorem succeeds (n : Nat) (hn : 2≤n) (j : Job n) (hj:j∈jobs n hn) :
    polEval (dbOf (BetaPort.result n hn)) (tape n hn j) []=some (row n hn j) :=
  ConstantLeaf.succeeds _ _ _ _ _ _ _ _ _ (nonzero n hn j hj) (premise_rows n hn j hj)

theorem program_check (n : Nat) (hn : 2≤n) :
    AliasProgram.check (BetaPort.result n hn) (program n hn)=some (result n hn) := by
  have h:=IndependentProgram.check_base (BetaPort.result n hn) (program n hn) (by
    intro c hc;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc;exact succeeds n hn j hj)
  simpa [program,result,AliasProgram.outputs,List.map_map] using h

/-- Both directions of the selected beta cofactor value equal the one allocated C.
The trace starts at the original formula and supplies every leaf premise. -/
theorem original_to_beta_value (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (BetaPort.original_to_beta_port n hn)
    (AliasProgram.check_trace _ _ _ (program_check n hn))

#print axioms original_to_beta_value
#print axioms program_check
#print axioms premise_rows
end L3Emitter.BetaValue

import EREF_Pol

/-!
# ER/EF Theorem 1 formalization — stage 4: Lemma 3, RUP produces an explicit bounded POL contradiction

`rup_to_cp.elaborate`: for a reason row R : Σ aⱼℓⱼ ≥ b and a partial assignment σ with slack
σ(R) = Σ_{ℓⱼ not false} aⱼ − b, the forced literal ℓ (weight a > σ ≥ 0, unassigned) is derived by

    ref(R); for every other literal ℓⱼ: (ref(unit ℓ̄ⱼ) if ℓⱼ is false else literal(ℓ̄ⱼ)), multiply(aⱼ), +;
    then divide(a)

and a conflicting reason (σ < 0) is refuted by the same elimination without a kept literal.

This file proves, against the exact algebra of `EREF_Rows` and the evaluator of `EREF_Pol`:

* `elim_unit`     — the elimination yields exactly the row `a·ℓ ≥ a − σ`;
* `rup_unit_step` — followed by `divide(a)` it yields exactly the unit row `ℓ ≥ 1`;
* `rup_conflict_step` — for a conflicting reason the elimination yields exactly `0 ≥ −σ`, a
  contradictory row.

The token count of each step is linear in the number of terms of the reason (`elimTokens_length`).
-/

namespace EREF

/-! ## Partial assignments, false literals, slack -/

abbrev PAssign := Nat → Option Bool

/-- `abs(l) in assignment and assignment[abs(l)] != (l > 0)` -/
def litFalse (σ : PAssign) (l : Int) : Bool :=
  match σ l.natAbs with
  | some b => b != decide (0 < l)
  | none => false

/-- Σ of the coefficients of the literals not false under σ -/
def nonFalseSum (σ : PAssign) : List (Nat × Int) → Nat
  | [] => 0
  | (a, l) :: ts => (if litFalse σ l then 0 else a) + nonFalseSum σ ts

/-- `slack = sum(a for a, l in row.terms if not false) - row.bound` -/
def slack (σ : PAssign) (R : Row) : Int := (nonFalseSum σ R.terms : Int) - R.bound

/-- the unit row ℓ ≥ 1, `normalize(((1, lit),), 1)` -/
def unitRow (l : Int) : Row := normalize [(1, l)] 1

theorem val_unitRow (l : Int) (hl : l ≠ 0) (α : Val) : (unitRow l).val α = litVal α l - 1 := by
  unfold unitRow; rw [val_normalize]
  · simp [tvalZ]
  · intro t ht; simp at ht; rw [ht]; exact hl

theorem canonical_unitRow (l : Int) : Canonical (unitRow l) := canonical_normalize _ _

/-! ## The elimination tokens -/

/-- for one other term: `ref(unit of ℓ̄)` if ℓ is false, else `literal(ℓ̄)`; then `multiply(a)`, `+` -/
def termTok (σ : PAssign) (unitId : Int → Nat) (t : Nat × Int) : List Tok :=
  (if litFalse σ t.2 then [Tok.ref (unitId (-t.2))] else [Tok.lit (-t.2)]) ++ [Tok.mul t.1, Tok.add]

/-- `eliminate(reason, kept)`: the reason, then every term whose literal is not the kept one -/
def elimTokens (σ : PAssign) (unitId : Int → Nat) (rid : Nat) (others : List (Nat × Int)) : List Tok :=
  Tok.ref rid :: others.flatMap (termTok σ unitId)

theorem elimTokens_length (σ : PAssign) (unitId : Int → Nat) (rid : Nat) (others : List (Nat × Int)) :
    (elimTokens σ unitId rid others).length = 1 + 3 * others.length := by
  unfold elimTokens
  induction others with
  | nil => simp
  | cons t ts ih =>
    rw [List.flatMap_cons, List.length_cons, List.length_append, List.length_cons]
    rw [List.length_cons] at ih
    have ht : (termTok σ unitId t).length = 3 := by unfold termTok; split <;> rfl
    omega

/-- the row pushed for one other term -/
def termRow (σ : PAssign) (t : Nat × Int) : Row :=
  if litFalse σ t.2 then unitRow (-t.2) else litAxiom (-t.2)

/-- the folded result of the elimination -/
def elimFold (σ : PAssign) (acc : Row) : List (Nat × Int) → Row
  | [] => acc
  | t :: ts => elimFold σ (add acc (multiply (termRow σ t) t.1)) ts

/-- the unit database is *complete* for σ when every false literal's complement has its unit row -/
def UnitsOk (db : Nat → Option Row) (σ : PAssign) (unitId : Int → Nat) : Prop :=
  ∀ l, litFalse σ l = true → db (unitId (-l)) = some (unitRow (-l))

theorem polEval_termTok (db : Nat → Option Row) (σ : PAssign) (unitId : Int → Nat)
    (hu : UnitsOk db σ unitId) (t : Nat × Int) (ht : 0 < t.1 ∧ t.2 ≠ 0)
    (rest : List Tok) (acc : Row) (st : List Row) :
    polEval db (termTok σ unitId t ++ rest) (acc :: st) =
      polEval db rest (add acc (multiply (termRow σ t) t.1) :: st) := by
  unfold termTok termRow
  by_cases hf : litFalse σ t.2 = true
  · simp only [hf, ↓reduceIte, List.cons_append, List.nil_append, polEval, hu t.2 hf, ht.1]
  · have hf' : litFalse σ t.2 = false := by simpa using hf
    have hnz : -t.2 ≠ 0 := by have := ht.2; omega
    simp only [hf', Bool.false_eq_true, ↓reduceIte, List.cons_append, List.nil_append, polEval, hnz,
      ne_eq, not_false_eq_true, ht.1]

theorem polEval_elim_aux (db : Nat → Option Row) (σ : PAssign) (unitId : Int → Nat)
    (hu : UnitsOk db σ unitId) (others : List (Nat × Int)) (hz : ∀ t ∈ others, 0 < t.1 ∧ t.2 ≠ 0)
    (rest : List Tok) (acc : Row) (st : List Row) :
    polEval db (others.flatMap (termTok σ unitId) ++ rest) (acc :: st) =
      polEval db rest (elimFold σ acc others :: st) := by
  induction others generalizing acc with
  | nil => simp [elimFold]
  | cons t ts ih =>
    simp only [List.flatMap_cons, List.append_assoc, elimFold]
    rw [polEval_termTok db σ unitId hu t (hz t (List.mem_cons_self ..)) _ acc st]
    exact ih (fun t ht => hz t (List.mem_cons_of_mem _ ht)) _

/-- the evaluator computes exactly the elimination fold -/
theorem polEval_elim (db : Nat → Option Row) (σ : PAssign) (unitId : Int → Nat)
    (hu : UnitsOk db σ unitId) (rid : Nat) (R : Row) (hR : db rid = some R)
    (others : List (Nat × Int)) (hz : ∀ t ∈ others, 0 < t.1 ∧ t.2 ≠ 0) (rest : List Tok) :
    polEval db (elimTokens σ unitId rid others ++ rest) [] = polEval db rest [elimFold σ R others] := by
  unfold elimTokens
  simp only [List.cons_append, polEval, hR]
  exact polEval_elim_aux db σ unitId hu others hz rest R []

/-! ## The value of the elimination fold -/

/-- the contribution of one other term: −aⱼ·ℓⱼ if false (unit ℓ̄ⱼ ≥ 1 scaled), aⱼ·(1 − ℓⱼ) otherwise -/
theorem val_termRow (σ : PAssign) (t : Nat × Int) (hz : t.2 ≠ 0) (α : Val) :
    (termRow σ t).val α = if litFalse σ t.2 then -(litVal α t.2) else 1 - litVal α t.2 := by
  unfold termRow
  have hnz : -t.2 ≠ 0 := by omega
  split
  · rw [val_unitRow _ hnz, litVal_neg _ _ hz]; omega
  · rw [val_litAxiom _ hnz, litVal_neg _ _ hz]

/-- Σ over the others of (aⱼ·ℓⱼ + contribution) = Σ of the non-false coefficients -/
theorem elim_contrib (σ : PAssign) (α : Val) (others : List (Nat × Int)) (hz : ∀ t ∈ others, t.2 ≠ 0) :
    tval α others + (others.map fun t => (t.1 : Int) * (termRow σ t).val α).sum = nonFalseSum σ others := by
  induction others with
  | nil => simp [tval, nonFalseSum]
  | cons t ts ih =>
    obtain ⟨a, l⟩ := t
    have hl : l ≠ 0 := hz (a, l) (List.mem_cons_self ..)
    simp only [tval, List.map_cons, List.sum_cons, nonFalseSum]
    rw [val_termRow σ (a, l) hl α]
    have ih' := ih (fun t ht => hz t (List.mem_cons_of_mem _ ht))
    simp only at ih' ⊢
    push_cast
    split
    · rw [Int.mul_neg]; omega
    · rw [Int.mul_sub, Int.mul_one]; omega

theorem canonical_elimFold (σ : PAssign) (acc : Row) (hacc : Canonical acc) (others : List (Nat × Int)) :
    Canonical (elimFold σ acc others) := by
  induction others generalizing acc with
  | nil => exact hacc
  | cons t ts ih => exact ih _ (canonical_add _ _)

theorem canonical_termRow (σ : PAssign) (t : Nat × Int) : Canonical (termRow σ t) := by
  unfold termRow; split
  · exact canonical_unitRow _
  · exact canonical_litAxiom _

theorem val_elimFold (σ : PAssign) (acc : Row) (hacc : Canonical acc) (others : List (Nat × Int)) (α : Val) :
    (elimFold σ acc others).val α = acc.val α + (others.map fun t => (t.1 : Int) * (termRow σ t).val α).sum := by
  induction others generalizing acc with
  | nil => simp [elimFold]
  | cons t ts ih =>
    simp only [elimFold, List.map_cons, List.sum_cons]
    rw [ih _ (canonical_add _ _), val_add _ _ hacc (canonical_multiply _ _),
        val_multiply _ (canonical_termRow σ t)]
    omega

/-! ## The two step theorems -/

/-- the terms of R other than the kept literal ℓ (`if lit == kept: continue`) -/
def others (R : Row) (l : Int) : List (Nat × Int) := R.terms.filter fun t => t.2 ≠ l

theorem tval_others (σ : PAssign) (α : Val) (R : Row) (hR : Canonical R) (a : Nat) (l : Int)
    (hmem : (a, l) ∈ R.terms) :
    tval α R.terms = (a : Int) * litVal α l + tval α (others R l) ∧
    nonFalseSum σ R.terms = (if litFalse σ l then 0 else a) + nonFalseSum σ (others R l) := by
  unfold others
  have hpw := hR.2
  clear hR
  generalize R.terms = ts at hmem hpw ⊢
  induction ts with
  | nil => simp at hmem
  | cons t ts ih =>
    obtain ⟨a', l'⟩ := t
    rw [List.pairwise_cons] at hpw
    rcases List.mem_cons.mp hmem with h | h
    · simp only [Prod.mk.injEq] at h; obtain ⟨rfl, rfl⟩ := h
      rw [List.filter_cons, if_neg (by simp)]
      -- l does not occur in ts (strictly increasing variables)
      have hself : ts.filter (fun t => decide (t.2 ≠ l)) = ts := by
        apply List.filter_eq_self.mpr
        intro t ht; have := hpw.1 t ht; simp only at this
        simp only [decide_eq_true_eq]; intro h; rw [h] at this; omega
      rw [hself]
      simp only [tval, nonFalseSum]
      exact ⟨trivial, trivial⟩
    · have hne : l' ≠ l := by
        intro heq; have := hpw.1 (a, l) h; simp only at this; rw [heq] at this; omega
      rw [List.filter_cons, if_pos (by simp [hne])]
      obtain ⟨ih1, ih2⟩ := ih h hpw.2
      simp only [tval, nonFalseSum]
      constructor
      · rw [ih1]; omega
      · rw [ih2]; omega

/-- **elimination**: for the forced literal ℓ with weight a, the elimination of all other
    literals yields exactly `a·ℓ ≥ a − σ(R)` -/
theorem elim_unit (db : Nat → Option Row) (σ : PAssign) (unitId : Int → Nat)
    (hu : UnitsOk db σ unitId) (rid : Nat) (R : Row) (hR : Canonical R) (hdb : db rid = some R)
    (a : Nat) (l : Int) (hmem : (a, l) ∈ R.terms) (hun : litFalse σ l = false) :
    polEval db (elimTokens σ unitId rid (others R l)) [] =
      some (Row.mk [(a, l)] ((a : Int) - slack σ R)) := by
  have hz : ∀ t ∈ others R l, 0 < t.1 ∧ t.2 ≠ 0 := fun t ht => hR.1 t (List.mem_filter.mp ht).1
  have := polEval_elim db σ unitId hu rid R hdb (others R l) hz []
  simp only [List.append_nil, polEval] at this
  rw [this]
  congr 1
  have ha := (hR.1 (a, l) hmem).1
  have hl := (hR.1 (a, l) hmem).2
  apply canonical_ext _ _ (canonical_elimFold σ R hR _)
  · unfold Canonical; simp; exact ⟨ha, hl⟩
  intro α
  rw [val_elimFold σ R hR _ α]
  have hc := elim_contrib σ α (others R l) (fun t ht => hz t ht |>.2)
  obtain ⟨h1, h2⟩ := tval_others σ α R hR a l hmem
  unfold Row.val slack at *
  rw [h1, h2, hun] at *
  simp only [tval, Bool.false_eq_true, ↓reduceIte] at *
  push_cast at *
  omega

/-- ⌈x/d⌉ = 1 for 0 < x ≤ d -/
theorem ceilDiv_eq_one (x : Int) (d : Nat) (h0 : 0 < x) (h1 : x ≤ d) : ceilDiv x d = 1 := by
  unfold ceilDiv ceilTerms.ceilDiv'
  have hd : (0 : Int) < d := by omega
  have hq1 := Int.ediv_mul_le (-x) (b := (d : Int)) (by omega)
  have hq2 := Int.lt_mul_ediv_self_add (x := -x) (k := (d : Int)) hd
  generalize hq : (-x) / (d : Int) = q at hq1 hq2
  rw [Int.mul_comm] at hq2
  -- q·d ≤ −x < q·d + d with −d ≤ −x < 0 forces q = −1
  rcases Int.lt_trichotomy q (-1) with hlt | heq | hgt
  · exfalso
    have : q * (d : Int) ≤ (-2) * (d : Int) := Int.mul_le_mul_of_nonneg_right (by omega) (by omega)
    omega
  · rw [heq]; rfl
  · exfalso
    have : 0 * (d : Int) ≤ q * (d : Int) := Int.mul_le_mul_of_nonneg_right (by omega) (by omega)
    omega

/-- **RUP unit step**: elimination followed by `divide(a)` yields exactly the unit row ℓ ≥ 1 -/
theorem rup_unit_step (db : Nat → Option Row) (σ : PAssign) (unitId : Int → Nat)
    (hu : UnitsOk db σ unitId) (rid : Nat) (R : Row) (hR : Canonical R) (hdb : db rid = some R)
    (a : Nat) (l : Int) (hmem : (a, l) ∈ R.terms) (hun : litFalse σ l = false)
    (hslack : 0 ≤ slack σ R) (hforce : slack σ R < a) :
    polEval db (elimTokens σ unitId rid (others R l) ++ [Tok.div a]) [] = some (unitRow l) := by
  have hz : ∀ t ∈ others R l, 0 < t.1 ∧ t.2 ≠ 0 := fun t ht => hR.1 t (List.mem_filter.mp ht).1
  have ha := (hR.1 (a, l) hmem).1
  have hl := (hR.1 (a, l) hmem).2
  rw [polEval_elim db σ unitId hu rid R hdb (others R l) hz]
  have hfold : elimFold σ R (others R l) = Row.mk [(a, l)] ((a : Int) - slack σ R) := by
    have := elim_unit db σ unitId hu rid R hR hdb a l hmem hun
    have e := polEval_elim db σ unitId hu rid R hdb (others R l) hz []
    simp only [List.append_nil, polEval] at e
    rw [e] at this; simpa using this
  rw [hfold]
  simp only [polEval, ha, ↓reduceIte]
  congr 1
  have e1 : ceilTerms.ceilDiv' (a : Int) a = 1 := ceilDiv_eq_one (a : Int) a (by omega) (by omega)
  have e2 : ceilDiv ((a : Int) - slack σ R) a = 1 := ceilDiv_eq_one _ a (by omega) (by omega)
  unfold divide ceilTerms unitRow
  simp only [List.map_cons, List.map_nil]
  rw [e1, e2]

/-- **RUP conflict step**: for a conflicting reason (σ(K) < 0) the elimination of every literal
    yields exactly `0 ≥ −σ(K)`, a contradictory row -/
theorem rup_conflict_step (db : Nat → Option Row) (σ : PAssign) (unitId : Int → Nat)
    (hu : UnitsOk db σ unitId) (kid : Nat) (K : Row) (hK : Canonical K) (hdb : db kid = some K)
    (hconf : slack σ K < 0) :
    polEval db (elimTokens σ unitId kid K.terms) [] = some (Row.mk [] (-(slack σ K))) ∧
    Contra (Row.mk [] (-(slack σ K))) := by
  have hz : ∀ t ∈ K.terms, 0 < t.1 ∧ t.2 ≠ 0 := fun t ht => hK.1 t ht
  constructor
  · have := polEval_elim db σ unitId hu kid K hdb K.terms hz []
    simp only [List.append_nil, polEval] at this
    rw [this]
    congr 1
    apply canonical_ext _ _ (canonical_elimFold σ K hK _)
    · unfold Canonical; simp
    intro α
    rw [val_elimFold σ K hK _ α]
    have hc := elim_contrib σ α K.terms (fun t ht => (hz t ht).2)
    unfold Row.val slack at *
    simp only [tval] at *
    omega
  · unfold Contra Row.total; simp [totalL]; omega

/-! ## Composition: the whole RUP elaboration is an explicit POL derivation -/

/-- the assignment after forcing literal l true -/
def assign (σ : PAssign) (l : Int) : PAssign :=
  fun v => if v = l.natAbs then some (decide (0 < l)) else σ v

/-- a database as a list of rows with ids 1..n -/
def dbOf (rows : List Row) : Nat → Option Row := fun i => if i = 0 then none else rows[i - 1]?

theorem dbOf_append_le (rows more : List Row) (i : Nat) (hi : i ≤ rows.length) :
    dbOf (rows ++ more) i = dbOf rows i := by
  unfold dbOf
  by_cases h0 : i = 0
  · simp [h0]
  · simp only [h0, ↓reduceIte]
    rw [List.getElem?_append_left (by omega)]

theorem dbOf_append_last (rows : List Row) (r : Row) : dbOf (rows ++ [r]) (rows.length + 1) = some r := by
  unfold dbOf; simp

theorem dbOf_mem (rows : List Row) (i : Nat) (R : Row) (h : dbOf rows i = some R) : R ∈ rows := by
  unfold dbOf at h
  split at h
  · simp at h
  · exact List.mem_of_getElem? h

/-- a valid propagation trail from σ: each step's literal is forced by its reason under the running
    assignment (`validation.propagate`: unassigned, slack ≥ 0, coefficient > slack) -/
inductive Trail (db : Nat → Option Row) : PAssign → List (Int × Nat) → PAssign → Prop
  | nil (σ : PAssign) : Trail db σ [] σ
  | step (σ : PAssign) (l : Int) (rid : Nat) (R : Row) (a : Nat) (rest : List (Int × Nat)) (σ'' : PAssign) :
      db rid = some R → (a, l) ∈ R.terms → σ l.natAbs = none →
      0 ≤ slack σ R → slack σ R < a →
      Trail db (assign σ l) rest σ'' → Trail db σ ((l, rid) :: rest) σ''

/-- every row appended beyond the first n is the evaluation of some POL token list against the rows
    before it -/
def Derived (n : Nat) (rows : List Row) : Prop :=
  ∀ k, n ≤ k → (hk : k < rows.length) →
    ∃ toks, polEval (dbOf (rows.take k)) toks [] = some rows[k]

theorem litFalse_of_unassigned (σ : PAssign) (l : Int) (h : σ l.natAbs = none) : litFalse σ l = false := by
  unfold litFalse; rw [h]

theorem polEval_mono (db db' : Nat → Option Row) (hext : ∀ i R, db i = some R → db' i = some R) :
    ∀ (toks : List Tok) (st : List Row) (out : Row), polEval db toks st = some out → polEval db' toks st = some out := by
  intro toks
  induction toks with
  | nil =>
    intro st out h
    match st with
    | [r] => exact h
    | [] => simp [polEval] at h
    | _ :: _ :: _ => simp [polEval] at h
  | cons t ts ih =>
    intro st out h
    cases t with
    | ref i =>
      simp only [polEval] at h ⊢
      split at h
      · rename_i r hr; rw [hext i r hr]; exact ih _ _ h
      · simp at h
    | lit l =>
      simp only [polEval] at h ⊢
      split at h
      · rename_i hl; rw [if_pos hl]; exact ih _ _ h
      · simp at h
    | add =>
      match st with
      | b :: a :: st => simp only [polEval] at h ⊢; exact ih _ _ h
      | [] => simp [polEval] at h
      | [_] => simp [polEval] at h
    | mul k =>
      match st with
      | a :: st =>
        simp only [polEval] at h ⊢
        split at h
        · rename_i hk; rw [if_pos hk]; exact ih _ _ h
        · simp at h
      | [] => simp [polEval] at h
    | div d =>
      match st with
      | a :: st =>
        simp only [polEval] at h ⊢
        split at h
        · rename_i hd; rw [if_pos hd]; exact ih _ _ h
        · simp at h
      | [] => simp [polEval] at h
    | sat =>
      match st with
      | a :: st => simp only [polEval] at h ⊢; exact ih _ _ h
      | [] => simp [polEval] at h

theorem dbOf_le_length (rows : List Row) (i : Nat) (R : Row) (h : dbOf rows i = some R) : i ≤ rows.length := by
  unfold dbOf at h
  split at h
  · simp at h
  · obtain ⟨hlt, _⟩ := List.getElem?_eq_some_iff.mp h; omega

theorem dbOf_ext_append (rows more : List Row) : ∀ i R, dbOf rows i = some R → dbOf (rows ++ more) i = some R := by
  intro i R h
  rw [dbOf_append_le rows more i (dbOf_le_length rows i R h)]; exact h

theorem unitsOk_mono (db db' : Nat → Option Row) (hext : ∀ i R, db i = some R → db' i = some R)
    (σ : PAssign) (unitId : Int → Nat) (hu : UnitsOk db σ unitId) : UnitsOk db' σ unitId :=
  fun l hf => hext _ _ (hu l hf)

theorem unitsOk_assign (db : Nat → Option Row) (σ : PAssign) (unitId : Int → Nat)
    (hu : UnitsOk db σ unitId) (l : Int) (hl : l ≠ 0) (hun : σ l.natAbs = none)
    (uid : Nat) (hdb : db uid = some (unitRow l)) :
    UnitsOk db (assign σ l) (fun l' => if l' = l then uid else unitId l') := by
  intro l' hf
  unfold litFalse assign at hf
  by_cases hv : l'.natAbs = l.natAbs
  · rw [if_pos hv] at hf
    have : l' = -l := by
      rcases Int.natAbs_eq_natAbs_iff.mp hv with h | h
      · exfalso; rw [h] at hf; simp at hf
      · exact h
    subst this
    simp only [Int.neg_neg, ↓reduceIte]
    exact hdb
  · rw [if_neg hv] at hf
    have hf' : litFalse σ l' = true := by unfold litFalse; exact hf
    have := hu l' hf'
    by_cases h' : -l' = l
    · exfalso
      have : l'.natAbs = l.natAbs := by rw [← h', Int.natAbs_neg]
      exact hv this
    · simp only [h', ↓reduceIte]; exact this

theorem derived_append (n : Nat) (rows : List Row) (hd : Derived n rows) (r : Row) (hn : n ≤ rows.length)
    (toks : List Tok) (h : polEval (dbOf rows) toks [] = some r) : Derived n (rows ++ [r]) := by
  intro k hk hklt
  rw [List.length_append, List.length_singleton] at hklt
  by_cases hkl : k < rows.length
  · obtain ⟨toks', h'⟩ := hd k hk hkl
    refine ⟨toks', ?_⟩
    rw [List.take_append_of_le_length (by omega), List.getElem_append_left hkl]
    exact h'
  · have hk' : k = rows.length := by omega
    subst hk'
    refine ⟨toks, ?_⟩
    rw [List.take_append_of_le_length (by omega), List.take_length, List.getElem_append_right (by omega)]
    simpa using h

/-- **Lemma 3, composed**: a valid trail from a canonical database extends it, by explicit POL steps,
    with the unit row of every propagated literal, keeping the unit map complete -/
theorem rup_chain (rows₀ : List Row) (trail : List (Int × Nat)) (σ σ' : PAssign)
    (ht : Trail (dbOf rows₀) σ trail σ') :
    ∀ (rows : List Row) (unitId : Int → Nat), rows₀.length ≤ rows.length →
      (∀ i, i ≤ rows₀.length → dbOf rows i = dbOf rows₀ i) →
      (∀ R ∈ rows, Canonical R) → UnitsOk (dbOf rows) σ unitId → Derived rows₀.length rows →
      ∃ rows' unitId', rows'.length = rows.length + 2 * trail.length ∧
        (∀ i R, dbOf rows i = some R → dbOf rows' i = some R) ∧
        (∀ R ∈ rows', Canonical R) ∧ UnitsOk (dbOf rows') σ' unitId' ∧ Derived rows₀.length rows' := by
  induction ht with
  | nil σ =>
    intro rows unitId hlen hpre hc hu hd
    exact ⟨rows, unitId, by simp, fun i R h => h, hc, hu, hd⟩
  | step σ l rid R a rest σ'' hdb hmem hun hs hf htail ih =>
    intro rows unitId hlen hpre hc hu hd
    have hrid : rid ≤ rows₀.length := dbOf_le_length rows₀ rid R hdb
    have hdbR : dbOf rows rid = some R := by rw [hpre rid hrid]; exact hdb
    have hR : Canonical R := hc R (dbOf_mem rows rid R hdbR)
    have hl : l ≠ 0 := (hR.1 (a, l) hmem).2
    have hunf : litFalse σ l = false := litFalse_of_unassigned σ l hun
    -- the two rows of this step
    have hE1 : polEval (dbOf rows) (elimTokens σ unitId rid (others R l)) [] =
        some (Row.mk [(a, l)] ((a : Int) - slack σ R)) :=
      elim_unit (dbOf rows) σ unitId hu rid R hR hdbR a l hmem hunf
    have hU1 : polEval (dbOf rows) (elimTokens σ unitId rid (others R l) ++ [Tok.div a]) [] = some (unitRow l) :=
      rup_unit_step (dbOf rows) σ unitId hu rid R hR hdbR a l hmem hunf hs hf
    generalize hE : Row.mk [(a, l)] ((a : Int) - slack σ R) = E at hE1
    have hEc : Canonical E := by rw [← hE]; unfold Canonical; simp; exact ⟨(hR.1 (a, l) hmem).1, hl⟩
    have hext₁ := dbOf_ext_append rows [E]
    have hext₂ := dbOf_ext_append (rows ++ [E]) [unitRow l]
    have hd₁ : Derived rows₀.length (rows ++ [E]) := derived_append _ rows hd E hlen _ hE1
    have hd₂ : Derived rows₀.length ((rows ++ [E]) ++ [unitRow l]) :=
      derived_append _ (rows ++ [E]) hd₁ (unitRow l) (by simp; omega) _
        (polEval_mono _ _ hext₁ _ _ _ hU1)
    have huid : dbOf ((rows ++ [E]) ++ [unitRow l]) ((rows ++ [E]).length + 1) = some (unitRow l) :=
      dbOf_append_last (rows ++ [E]) (unitRow l)
    have hu₂ : UnitsOk (dbOf ((rows ++ [E]) ++ [unitRow l])) (assign σ l)
        (fun l' => if l' = l then (rows ++ [E]).length + 1 else unitId l') :=
      unitsOk_assign _ σ unitId
        (unitsOk_mono _ _ (fun i R h => hext₂ i R (hext₁ i R h)) σ unitId hu) l hl hun _ huid
    have hc₂ : ∀ R ∈ (rows ++ [E]) ++ [unitRow l], Canonical R := by
      intro S hS
      simp only [List.mem_append, List.mem_singleton] at hS
      rcases hS with (hS | rfl) | rfl
      · exact hc S hS
      · exact hEc
      · exact canonical_unitRow l
    have hpre₂ : ∀ i, i ≤ rows₀.length → dbOf ((rows ++ [E]) ++ [unitRow l]) i = dbOf rows₀ i := by
      intro i hi
      rw [List.append_assoc, dbOf_append_le rows _ i (by omega)]
      exact hpre i hi
    obtain ⟨rows', unitId', hlen', hext', hc', hu', hd'⟩ :=
      ih ((rows ++ [E]) ++ [unitRow l]) _ (by simp; omega) hpre₂ hc₂ hu₂ hd₂
    refine ⟨rows', unitId', ?_, ?_, hc', hu', hd'⟩
    · rw [hlen']; simp; omega
    · intro i S h; exact hext' i S (hext₂ i S (hext₁ i S h))

/-- **Lemma 3**: a RUP step with a valid trail ending in a conflicting reason has an explicit POL
    refutation — a sequence of rows each evaluated from the rows before it, ending in a contradictory
    row — of length at most 2·(trail length) + 1 -/
theorem rup_to_pol (rows₀ : List Row) (h₀ : ∀ R ∈ rows₀, Canonical R)
    (trail : List (Int × Nat)) (σ' : PAssign) (ht : Trail (dbOf rows₀) (fun _ => none) trail σ')
    (kid : Nat) (K : Row) (hK : dbOf rows₀ kid = some K) (hconf : slack σ' K < 0) :
    ∃ rows', rows'.length = rows₀.length + 2 * trail.length + 1 ∧
      (∀ i R, dbOf rows₀ i = some R → dbOf rows' i = some R) ∧
      Derived rows₀.length rows' ∧ ∃ last, rows'.getLast? = some last ∧ Contra last := by
  have hu₀ : UnitsOk (dbOf rows₀) (fun _ => none) (fun _ => 0) := by
    intro l hf; unfold litFalse at hf; simp at hf
  obtain ⟨rows₁, unitId₁, hlen, hext, hc, hu, hd⟩ :=
    rup_chain rows₀ trail _ σ' ht rows₀ (fun _ => 0) (Nat.le_refl _) (fun i _ => rfl) h₀ hu₀
      (fun k hk hklt => absurd hklt (by omega))
  have hK₁ : dbOf rows₁ kid = some K := hext kid K hK
  have hKc : Canonical K := hc K (dbOf_mem rows₁ kid K hK₁)
  obtain ⟨hev, hcon⟩ := rup_conflict_step (dbOf rows₁) σ' unitId₁ hu kid K hKc hK₁ hconf
  refine ⟨rows₁ ++ [Row.mk [] (-(slack σ' K))], ?_, ?_, ?_, ?_⟩
  · simp; omega
  · intro i R h; exact dbOf_ext_append rows₁ _ i R (hext i R h)
  · exact derived_append _ rows₁ hd _ (by omega) _ hev
  · exact ⟨_, by simp, hcon⟩

end EREF

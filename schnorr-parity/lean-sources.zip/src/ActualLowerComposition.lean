import LowerActivationImage
import GuardIntroduction
namespace L3Emitter.ActualLowerComposition
open EREF EREF.GeneralRED FamilyNamespace GuardedReplay

def upper (n:Nat) (hn:2≤n):List Row:=FinalLowerComplete.result n hn
def ceiling (n:Nat) (hn:2≤n):Nat:=CanonicalTrace.ceiling (upper n hn)
def inputs (n:Nat) (hn:2≤n):List Row:=LowerActivationImage.inputs n (ceiling n hn)
def amount (R:Row):Nat:=R.bound.toNat+1

theorem upper_canonical (n:Nat) (hn:2≤n):∀R∈upper n hn,Canonical R:=
  CanonicalTrace.trace (FinalLowerComplete.original_to_complete_lower_image n hn)
    (OriginalEncoding.rows_canonical _ _)
theorem upper_bounded (n:Nat) (hn:2≤n):RowSupport.Bounded (ceiling n hn) (upper n hn):=
  CanonicalTrace.bounded _ (upper_canonical n hn)
theorem inputs_canonical (n:Nat) (hn:2≤n):∀R∈inputs n hn,Canonical R:=by
  intro R h;obtain ⟨r,hr,rfl⟩:=List.mem_map.mp h;exact canonical_normalize _ _
theorem amount_pos (R:Row):0<amount R:=by unfold amount;omega
theorem amount_bound (R:Row):R.bound≤(amount R:Int):=by unfold amount;omega

theorem inputs_bound (n:Nat) (hn:2≤n):
    RowSupport.Bounded (ceiling n hn+variableCount n (3*n-4)) (inputs n hn):=by
  intro R h;obtain ⟨r,hr,rfl⟩:=List.mem_map.mp h
  have hv:=InputSwap.original_valid _ _ r ((OriginalEncoding.spec_mem_iff _ _ (by omega) r).mp hr)
  refine ⟨canonical_normalize _ _,?_⟩
  apply RowSupport.normalize_bound
  intro t ht;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp ht
  have hb:=encode_bounds n (3*n-4) l.1 (hv l hl)
  unfold LowerActivationImage.shiftedLit
  split <;> simp only [Int.natAbs_neg,Int.natAbs_natCast] <;> omega

/-- Introduce the fresh guarded lower bank after the complete upper derivation.
Every old row is fixed; every introduced row becomes tautological with q=false. -/
theorem introduce_actual_bank (n:Nat) (hn:2≤n) (N:Nat) (hN:variableCount n (3*n-4)≤N):
    Counted (upper n hn)
      (upper n hn++GuardActivation.bank (inputs n hn) amount (ceiling n hn+N+1))
      (inputs n hn).length:=by
  apply GuardIntroduction.fresh_bank _ _ _ _ (by omega) (upper_canonical n hn) (inputs_canonical n hn)
  · intro R hr t ht
    have h: t.2.natAbs≤ceiling n hn:=(upper_bounded n hn R hr).2 t ht
    omega
  · intro R hr t ht
    have h: t.2.natAbs≤ceiling n hn+variableCount n (3*n-4):=(inputs_bound n hn R hr).2 t ht
    omega
  · intro R hr;exact amount_bound R

/-- The image and all retained-frame obligations are now instantiated with the
actual complete lower-row bank. A scoped recursive lower trace is still an
explicit premise; this theorem does not assert that the emitter constructs it. -/
theorem single_tail (n:Nat) (hn:2≤n) (N:Nat) (hN:variableCount n (3*n-4)≤N)
    (E:List Row) (m:Nat)
    (tail:Scoped (ceiling n hn) (-((ceiling n hn+N+1:Nat):Int)) (inputs n hn) E m):
    Counted (upper n hn)
      (ActivatedReplay.frame (upper n hn) (inputs n hn) amount (ceiling n hn+N+1)++E)
      ((inputs n hn).length+((inputs n hn).length+m+1)):=by
  have h:=ActivationNamespace.compose (ceiling n hn) (variableCount n (3*n-4)) N
    (LowerActivationImage.image n hn) (upper n hn) (inputs n hn) E amount m
    (upper_bounded n hn) (inputs_canonical n hn) (fun R _=>amount_pos R)
    (LowerActivationImage.all_activation_images n hn (ceiling n hn) N hN) tail
  exact SharedTailComposition.counted_trans (introduce_actual_bank n hn N hN) h

theorem original_to_single_tail (n:Nat) (hn:2≤n) (N:Nat) (hN:variableCount n (3*n-4)≤N)
    (E:List Row) (m:Nat)
    (tail:Scoped (ceiling n hn) (-((ceiling n hn+N+1:Nat):Int)) (inputs n hn) E m):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4))
      (ActivatedReplay.frame (upper n hn) (inputs n hn) amount (ceiling n hn+N+1)++E):=
  L3.Fam.checkedTrace_trans (FinalLowerComplete.original_to_complete_lower_image n hn)
    (counted_trace (single_tail n hn N hN E m tail))
#print axioms introduce_actual_bank
#print axioms original_to_single_tail
end L3Emitter.ActualLowerComposition

import RankU2Transport
namespace L3Emitter.LowerU2Bank
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL AliasProgram U2SourcePOL
abbrev Job:=Nat×Bool
def jobs (n:Nat):List Job:=(List.range (RankConstruction.width (n+1))).flatMap fun t=>[(t,false),(t,true)]
def leaf (n:Nat) (hn:2≤n) (j:Job) (D:List Row):=RankU2Transport.program n hn j.1 j.2 D
def rows (n:Nat) (hn:2≤n) (j:Job):=RankU2Transport.rows n hn j.1 j.2
def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n) (ComposedU2Bank.result n hn)
def result (n:Nat) (hn:2≤n):=ComposedU2Bank.result n hn++RetainedBlockFold.body (rows n hn) (jobs n)
theorem job_mem (n:Nat) (j:Job):j∈jobs n↔j.1<RankConstruction.width (n+1):=by
  obtain ⟨t,v⟩:=j;cases v <;> simp [jobs]
theorem checks (n:Nat) (hn:2≤n):check (ComposedU2Bank.result n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (fun j:Job=>j.1<RankConstruction.width (n+1))
    (fun j hj D hd=>RankU2Transport.checks n hn j.1 hj j.2 D hd) _
    (fun j hj=>(job_mem n j).mp hj) _ (fun _ h=>h)
theorem original_to_lower_U2 (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (ComposedU2Bank.original_to_composed_U2 n hn) (check_trace _ _ _ (checks n hn))
theorem all_rows (n:Nat) (hn:2≤n) (t:Nat) (ht:t<RankConstruction.width (n+1)) (phase:Bool):
    RankU2Transport.row n hn t phase∈result n hn:=by
  apply List.mem_append_right
  apply RetainedBlockFold.contains (rows n hn) (jobs n) (t,phase) ((job_mem n _).mpr ht)
  simp [rows,RankU2Transport.rows]
theorem image_eq (n:Nat) (hn:2≤n) (t:Nat) (phase:Bool):
    LowerTransferImage.image n hn (InputSwap.forbidden t (if phase then 6 else 9))=RankU2Transport.row n hn t phase:=by
  cases phase <;> simp [LowerTransferImage.image,InputSwap.forbidden,RankU2Transport.row,original,literals,identity,
    RankU2Transport.table,RankTableBank.code,sign,clause,List.range_succ] <;> rfl

theorem all_U2_images (n:Nat) (hn:2≤n) (r:FamilyRows.Spec) (hr:r∈OriginalEncoding.forbiddenBlock (3*n-4)):
    LowerTransferImage.image n hn r∈result n hn:=by
  obtain ⟨t,c,ht,hc,rfl⟩:=(OriginalEncoding.forbidden_mem _ r).mp hr
  have ht':t<RankConstruction.width (n+1):=by unfold RankConstruction.width;omega
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl|rfl
  · rw [show (6:Nat)=(if true then 6 else 9) from rfl,image_eq];exact all_rows n hn t ht' true
  · rw [show (9:Nat)=(if false then 6 else 9) from rfl,image_eq];exact all_rows n hn t ht' false

theorem selector_and_transfer_images (n:Nat) (hn:2≤n) (r:FamilyRows.Spec)
    (hr:r∈OriginalEncoding.selectorsBlock n (3*n-4) ∨ r∈OriginalEncoding.transfersBlock n (3*n-4)):
    LowerTransferImage.image n hn r∈result n hn:=by
  apply List.mem_append_left
  apply List.mem_append_left
  rcases hr with hr|hr
  · exact LowerSelectorComplete.all_selector_images n hn r hr
  · exact LowerSelectorComplete.all_transfer_images n hn r hr
#print axioms original_to_lower_U2
#print axioms all_U2_images
#print axioms selector_and_transfer_images
end L3Emitter.LowerU2Bank

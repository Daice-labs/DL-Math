import L3GateHistory

namespace L3.Fam
open L3 EREF EREF.GeneralRED
variable (F : Fam)

def predecessorActualRows (g p h x y a cb live liveh edge v q : Nat) (pol : Bool) : List L3.Row :=
  [gateRow [-(live : Int),-(F.sel g p (F.k+h) : Int)] edge true,
   gateRow [-(edge : Int)] liveh true,
   clauseRow (if h=0 then [-(cb : Int),(v : Int)] else [(a : Int),-(cb : Int),-(liveh : Int),(v : Int)]),
   if pol then F.row3g' g p h x else F.row3g g p h x,
   gateRow [if pol then -(F.val h x : Int) else (F.val h x : Int),
     if pol then (F.val h y : Int) else -(F.val h y : Int)] v false,
   if pol then F.row3g g p h y else F.row3g' g p h y,
   F.wireEqRow g p x y q pol]

/-- The predecessor chain also accepts the stronger gate-zero root actually
    emitted by the builder; no fictitious weakened row is inserted. -/
theorem predecessor_actual_leaf (g p h x y a cb live liveh edge v q : Nat) (pol : Bool)
    (ha : 1≤a) (hc : 1≤cb) (hl : 1≤live) (hlh : 1≤liveh)
    (he : 1≤edge) (hv : 1≤v) (hq : 1≤q)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hm : All (fun r => r.toE∈D) (F.predecessorActualRows g p h x y a cb live liveh edge v q pol)) :
    Refutation (D ++ [negate (clauseRow (F.wireLeaf g p (F.k+h) x a cb live q pol)).toE]) := by
  have hs := F.sel_pos g p (F.k+h)
  have hpx := F.port_pos g p x
  have hpy := F.port_pos g p y
  have hvx := F.val_pos h x
  have hvy := F.val_pos h y
  apply weighted_clause_chain D _ 5
    (F.predecessorActualRows g p h x y a cb live liveh edge v q pol) hD
  · cases pol <;> simp only [wireLeaf,Bool.false_eq_true,↓reduceIte] <;> nz_lits
  · exact hm
  · by_cases hh : h=0 <;> cases pol <;>
      simp only [predecessorActualRows,hh,wireEqRow,row3g,row3g',gateRow,pos,neg,Bool.false_eq_true,↓reduceIte,All]
    all_goals repeat' first | apply And.intro | exact True.intro
    all_goals simp only [hh] at hs hvx hvy
    all_goals nz_lits
  · intro α
    by_cases hh : h=0 <;> cases pol <;>
      simp [predecessorActualRows,hh,wireEqRow,row3g,row3g',gateRow,clauseRow,wireLeaf,pos,neg,lsum_cons,lsum_nil] <;> lv_omega

#print axioms predecessor_actual_leaf
end L3.Fam

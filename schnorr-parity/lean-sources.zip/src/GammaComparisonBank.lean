import GammaComparison
namespace L3Emitter.GammaComparisonBank
set_option maxHeartbeats 2000000
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
abbrev Job (n:Nat):=BetaPort.Job n×Bool×Bool×Bool×Bool×Bool
def cases {n:Nat} (j:BetaPort.Job n):List (Job n):=
  [false,true].flatMap fun u=>[false,true].flatMap fun side=>[false,true].flatMap fun a=>
  [false,true].flatMap fun b=>[false,true].map fun v=>(j,u,side,a,b,v)
def jobs (n:Nat) (hn:2≤n):=(BetaPort.jobs n hn).flatMap cases
-- Unary evaluations are independent of the truth row: one shared bank per forcing job.
def unaryJobs (n:Nat) (hn:2≤n):=(GammaChoiceBank.jobs n hn).flatMap fun j=>cases (GammaChoiceBank.betaJob j)
def jobRows (n:Nat) (hn:2≤n) (j:Job n):=GammaComparison.rows n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2
def unaryRow (n:Nat) (hn:2≤n) (j:Job n):=(jobRows n hn j).headD contra
def cofactorRow (n:Nat) (hn:2≤n) (j:Job n):=GammaCofactorValue.row n hn j.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2
def comparisonRow (n:Nat) (hn:2≤n) (j:Job n):=GammaComparison.row n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2

theorem case_mem {n:Nat} (j:BetaPort.Job n) (u side a b v:Bool):(j,u,side,a,b,v)∈cases j:=by
  cases u <;> cases side <;> cases a <;> cases b <;> cases v <;> simp [cases]
theorem first_of_case {n:Nat} (j:BetaPort.Job n) (r:Job n) (h:r∈cases j):r.1=j:=by
  simp only [cases,List.mem_flatMap,List.mem_map] at h
  obtain ⟨u,hu,side,hs,a,ha,b,hb,v,hv,he⟩:=h
  exact (congrArg Prod.fst he).symm
theorem job_valid (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn):j.1∈BetaPort.jobs n hn:=by
  obtain ⟨k,hk,hj⟩:=List.mem_flatMap.mp hj
  rw [first_of_case k j hj];exact hk
theorem unary_valid (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈unaryJobs n hn):j.1∈BetaPort.jobs n hn:=by
  obtain ⟨k,hk,hj⟩:=List.mem_flatMap.mp hj
  rw [first_of_case _ j hj];exact GammaChoiceBank.beta_valid n hn k hk

def base (n:Nat) (hn:2≤n):=GammaChoiceBank.result n hn
def first (n:Nat) (hn:2≤n):Program:=
  (unaryJobs n hn).map (fun j=>(unaryRow n hn j,GammaUnaryChoice.tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 (!j.2.2.2.2.2) (base n hn)))++
  (jobs n hn).map (fun j=>(cofactorRow n hn j,GammaCofactorValue.tape n hn j.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2 (base n hn)))
def middle (n:Nat) (hn:2≤n):=base n hn++(unaryJobs n hn).map (unaryRow n hn)++(jobs n hn).map (cofactorRow n hn)
def last (n:Nat) (hn:2≤n):Program:=(jobs n hn).map fun j=>
  (comparisonRow n hn j,GammaComparison.tape n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2 (middle n hn))
def result (n:Nat) (hn:2≤n):=middle n hn++(jobs n hn).map (comparisonRow n hn)
def emitted (n:Nat) (hn:2≤n):=first n hn++last n hn

theorem first_checks (n:Nat) (hn:2≤n):check (base n hn) (first n hn)=some (middle n hn):=by
  have h:=IndependentProgram.check_base (base n hn) (first n hn) (by
    intro cmd hc
    rcases List.mem_append.mp hc with hc|hc
    · obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
      exact GammaUnaryChoice.checks n hn j.1 (unary_valid n hn j hj) _ _ _ _ _ _ (fun _ h=>h)
    · obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
      exact GammaCofactorValue.checks n hn j.1 (job_valid n hn j hj) _ _ _ _ _ (fun _ h=>h))
  simpa [middle,first,outputs,List.map_append,List.map_map,List.append_assoc,Function.comp_def] using h

theorem unary_present (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn):unaryRow n hn j∈middle n hn:=by
  let z:Job n:=(GammaChoiceBank.betaJob j.1.1,j.2)
  have hcase:=case_mem (GammaChoiceBank.betaJob j.1.1) j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2
  have hf:=GammaCofactorValue.forcing_job n hn j.1 (job_valid n hn j hj)
  have hz:z∈unaryJobs n hn:=List.mem_flatMap.mpr ⟨j.1.1,hf,hcase⟩
  have he:unaryRow n hn z=unaryRow n hn j:=by
    unfold unaryRow jobRows GammaComparison.rows
    simp only [List.headD_cons]
    rfl
  exact List.mem_append_left _ (List.mem_append_right _ (List.mem_map.mpr ⟨z,hz,he⟩))
theorem cofactor_present (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈jobs n hn):cofactorRow n hn j∈middle n hn:=
  List.mem_append_right _ (List.mem_map.mpr ⟨j,hj,rfl⟩)

theorem last_checks (n:Nat) (hn:2≤n):check (middle n hn) (last n hn)=some (result n hn):=by
  have h:=IndependentProgram.check_base (middle n hn) (last n hn) (by
    intro cmd hc;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    have hv:=job_valid n hn j hj
    have hz:=BetaAliasValue.choice_valid n hn j.1 hv
    apply CommonGuardResolve.checks _ _ _ _ _
      (by simp [GammaComparison.G,Valid,hz,sign_valid])
      (by simp [GammaComparison.H,Valid,sign_valid])
      (by simp [GammaComparison.Q,Valid,sign_valid]) (sign_valid _ _)
    · have he:=GammaComparison.unary_binding n hn j.1 hv j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2
      exact he ▸ unary_present n hn j hj
    · have he:=GammaComparison.cofactor_binding n hn j.1 hv j.2.2.1 j.2.2.2.1 j.2.2.2.2.1 j.2.2.2.2.2
      exact he ▸ cofactor_present n hn j hj)
  simpa [last,outputs,result,List.map_map,Function.comp_def] using h

theorem checks (n:Nat) (hn:2≤n):check (base n hn) (emitted n hn)=some (result n hn):=
  check_append _ _ _ _ _ (first_checks n hn) (last_checks n hn)
theorem original_to_comparisons (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (GammaChoiceBank.original_to_gamma_choices n hn) (check_trace _ _ _ (checks n hn))
theorem all_comparisons (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (hj:j∈BetaPort.jobs n hn) (u side a b v:Bool):
    GammaComparison.row n hn j u side a b v∈result n hn:=
  List.mem_append_right _ (List.mem_map.mpr ⟨(j,u,side,a,b,v),List.mem_flatMap.mpr ⟨j,hj,case_mem ..⟩,rfl⟩)
#print axioms original_to_comparisons
#print axioms all_comparisons
end L3Emitter.GammaComparisonBank

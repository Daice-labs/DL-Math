import PrimaryAliasBank

namespace L3Emitter.FirstPortRelations
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases ConcretePortRows
open PrimaryAliasBank

def initialAliases (n:Nat) (hn:2≤n) := AliasAssembly.inputAliases (AliasAssembly.width (n+1)) (cfg n hn)
def left (n:Nat) (hn:2≤n) := ConcreteOriginalPorts.recorded (n+1) 0
  ((cfg n hn).sel 0 0) (initialAliases n hn) (context n hn).2
def right (n:Nat) (hn:2≤n) := ConcreteOriginalPorts.recorded (n+1) 0
  ((cfg n hn).sel 0 1) (initialAliases n hn) (left n hn).2

def portAt (n:Nat) (hn:2≤n) (p:Nat) := if p=0 then left n hn else right n hn

theorem first_jobs (n:Nat) (hn:2≤n) (j:Job)
    (hj:j∈(RecordedAliasSteps.step (cfg n hn) (initialAliases n hn) 0 (context n hn).2).1.2) :
    j∈(RecordedAliasRun.built n hn).1.2 := by
  have he:3*(n+1)-4=(3*(n+1)-5)+1:=by omega
  change j∈(RecordedAliasRun.run (cfg n hn) (initialAliases n hn) 0 (3*(n+1)-4) (context n hn).2).1.2
  rw [he]
  exact List.mem_append_left _ hj

theorem port_jobs (n:Nat) (hn:2≤n) (p:Nat) (hp:p<2) (j:Job)
    (hj:j∈(portAt n hn p).1.2) : j∈(RecordedAliasRun.built n hn).1.2 := by
  apply first_jobs
  change j∈(left n hn).1.2++(right n hn).1.2
  by_cases h:p=0
  · exact List.mem_append_left _ (by simpa [portAt,h] using hj)
  · exact List.mem_append_right _ (by simpa [portAt,h] using hj)

theorem source_contains_relations (n:Nat) (hn:2≤n) :
    ∀R∈RecordedAliasRun.result n hn,R∈PrimaryAliasBank.result n hn := by
  intro R hr
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ hr))

theorem left_cells (n:Nat) (hn:2≤n) (i:Fin (AliasAssembly.width (n+1)+2)) :
    (((ConcretePortRows.run _ (ConcreteOriginalPorts.portInputs (n+1) 0
      ((cfg n hn).sel 0 0) (initialAliases n hn)) (context n hn).2).1 i).es.map
        (fun e=>(e.choice,e.value)))=
      ConcreteOriginalPorts.portInputs (n+1) 0 ((cfg n hn).sel 0 0) (initialAliases n hn) i :=
  RecordedPortLinks.cell_pairs _ _ _ i

/-- One relation lookup works for each actual port's allocation, including the
    right port's different starting Net. -/
theorem local_relation {base:List Row} {w:Nat} (D:List Row) (k g:Nat) (sel:Nat→Bit)
    (as:Nat→AliasBits w) (z:Net base)
    (hm:∀j∈(ConcreteOriginalPorts.recorded k g sel as z).1.2,∀e∈j.es,
      clause [-e.choice.val,-e.value.val,j.q.val]∈D ∧ clause [-e.choice.val,-j.q.val,e.value.val]∈D)
    (j:Nat) (hj:j<k+g) (i:Fin (w+2)) :
    clause [-(sel j).val,-(as j i).val,((ConcreteOriginalPorts.recorded k g sel as z).1.1 i).val]∈D ∧
    clause [-(sel j).val,-((ConcreteOriginalPorts.recorded k g sel as z).1.1 i).val,(as j i).val]∈D := by
  let f:=ConcreteOriginalPorts.portInputs k g sel as
  let r:=ConcretePortRows.run (w+2) f z
  have he:=RecordedPortLinks.cell_pairs (w+2) f z i
  have hmem:(sel j,as j i)∈(r.1 i).es.map (fun e=>(e.choice,e.value)) := by
    rw [he];exact List.mem_map.mpr ⟨j,List.mem_range.mpr hj,rfl⟩
  obtain ⟨e,he,eq⟩:=List.mem_map.mp hmem
  have h:=hm (r.1 i) (List.mem_ofFn.mpr ⟨i,rfl⟩) e he
  have ec:e.choice=sel j:=congrArg Prod.fst eq
  have ev:e.value=as j i:=congrArg Prod.snd eq
  simpa only [ec,ev] using h

theorem relations (n:Nat) (hn:2≤n) (p:Nat) (hp:p<2) (j:Nat) (hj:j<n+1)
    (i:Fin (AliasAssembly.width (n+1)+2)) :
    clause [-((cfg n hn).sel 0 p j).val,-(initialAliases n hn j i).val,((portAt n hn p).1.1 i).val]
      ∈PrimaryAliasBank.result n hn ∧
    clause [-((cfg n hn).sel 0 p j).val,-((portAt n hn p).1.1 i).val,(initialAliases n hn j i).val]
      ∈PrimaryAliasBank.result n hn := by
  have hm (p:Nat) (hp:p<2) (t:Job) (ht:t∈(portAt n hn p).1.2) (e:ConcreteSelection.Cell) (he:e∈t.es) :=
    RecordedAliasRun.relation n hn t (port_jobs n hn p hp t ht) e he
  by_cases h:p=0
  · subst p
    apply local_relation _ (n+1) 0 ((cfg n hn).sel 0 0) (initialAliases n hn) (context n hn).2
      (fun t ht e he=>⟨source_contains_relations n hn _ (hm 0 (by omega) t ht e he).1,
        source_contains_relations n hn _ (hm 0 (by omega) t ht e he).2⟩) j (by omega) i
  · have he:p=1:=by omega
    subst p
    apply local_relation _ (n+1) 0 ((cfg n hn).sel 0 1) (initialAliases n hn) (left n hn).2
      (fun t ht e he=>⟨source_contains_relations n hn _ (hm 1 (by omega) t ht e he).1,
        source_contains_relations n hn _ (hm 1 (by omega) t ht e he).2⟩) j (by omega) i

#print axioms relations
end L3Emitter.FirstPortRelations

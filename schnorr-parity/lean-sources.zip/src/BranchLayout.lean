import FrontendSelection

/- Exact branch-list layout of the existing frontend. This records the
   allocator and loop order; it does not replace the forcing-port proof. -/
namespace L3.Fam
open L3 StI
variable (F : Fam)

def branchPairs (bs : List Nat) : List (Nat × Nat) :=
  bs.flatMap fun b => (List.range' (b+1) (F.s-1-b)).map fun g => (b,g)

def branchLits (m : Nat) : Nat → List Int
  | 0 => []
  | n+1 => ((m+2:Nat):Int)::branchLits (m+2) n

theorem branchLits_length (m n : Nat) : (branchLits m n).length=n := by
  induction n generalizing m with
  | zero => rfl
  | succ n ih => simp [branchLits,ih]

theorem branchLits_append (m n h : Nat) :
    branchLits m (n+h)=branchLits m n++branchLits (m+2*n) h := by
  induction n generalizing m with
  | zero => simp [branchLits]
  | succ n ih =>
    rw [show n+1+h=(n+h)+1 by omega]
    simp only [branchLits,ih,List.cons_append]
    rw [show m+2+2*n=m+2*(n+1) by omega]

theorem branchStep_var (b g : Nat) (a : StI F.V × List Int) :
    (F.branchStep b a g).1.s.var=a.1.s.var+2 := by
  change a.1.s.var+1+1=a.1.s.var+2
  omega

theorem branchFold_layout (b : Nat) (gs : List Nat) (a : StI F.V × List Int) :
    (gs.foldl (F.branchStep b) a).1.s.var=a.1.s.var+2*gs.length ∧
    (gs.foldl (F.branchStep b) a).2=a.2++branchLits a.1.s.var gs.length := by
  induction gs generalizing a with
  | nil => simp [branchLits]
  | cons g gs ih =>
    have h := ih (F.branchStep b a g)
    simp only [List.foldl_cons,List.length_cons]
    rw [F.branchStep_var] at h
    constructor
    · rw [h.1]; omega
    · rw [h.2,F.branchStep_list]
      simp [branchLits,List.append_assoc]

theorem branchBank_layout (bs : List Nat) (a : StI F.V × List Int) :
    (F.branchBank bs a).1.s.var=a.1.s.var+2*(F.branchPairs bs).length ∧
    (F.branchBank bs a).2=a.2++branchLits a.1.s.var (F.branchPairs bs).length := by
  induction bs generalizing a with
  | nil => simp [branchBank,branchPairs,branchLits]
  | cons b bs ih =>
    have h := ih (F.bStep a b)
    have hf := F.branchFold_layout b (List.range' (b+1) (F.s-1-b)) a
    change (F.bStep a b).1.s.var=_ ∧ (F.bStep a b).2=_ at hf
    simp only [List.length_range'] at hf
    change (F.branchBank bs (F.bStep a b)).1.s.var=_ ∧
      (F.branchBank bs (F.bStep a b)).2=_
    simp only [branchPairs,List.flatMap_cons,List.length_append,List.length_map,
      List.length_range']
    constructor
    · rw [h.1,hf.1]; simp only [branchPairs]; omega
    · rw [h.2,hf.1,hf.2]
      rw [branchLits_append]
      simp [List.append_assoc,branchPairs]

theorem branchPairs_valid (b g : Nat) (h : (b,g)∈F.branchPairs F.branchIndices) :
    0<b ∧ b<g ∧ g<F.s := by
  obtain ⟨j,hj,hpair⟩ := List.mem_flatMap.mp h
  obtain ⟨i,hi,he⟩ := List.mem_map.mp hpair
  cases he
  have h1 := List.mem_range'_1.mp hj
  have h2 := List.mem_range'_1.mp hi
  omega

theorem frontend_branch_layout (t : StI F.V) :
    F.branchList t=branchLits t.s.var (F.branchPairs F.branchIndices).length := by
  have h := (F.branchBank_layout F.branchIndices (t,[])).2
  simpa only [branchList,preparedBank,List.nil_append] using h

#print axioms branchBank_layout
#print axioms frontend_branch_layout
end L3.Fam

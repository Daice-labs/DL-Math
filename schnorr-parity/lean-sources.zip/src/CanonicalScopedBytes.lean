import CompactTapeBytes
import NativeRecordedFamily
import NativeRecordedAllocation

namespace L3Emitter.CanonicalScopedBytes
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

/-- The new stream is an explicit-scope projection of the frozen recorded
family. No local refutation is silently replaced by an unproved RUP claim. -/
def pbRow (R : EREF.Row) : PBRow :=
  ⟨R.terms.map (fun t=>(t.1,TemplateBytes.signedLiteral t.2)),R.bound⟩
def rowDoc (R : EREF.Row) := row (pbRow R)
def closeDoc (conclusion : Nat) := fixed "qed : " ++ number conclusion ++ fixed " ;\n"
def tapesDoc (ts : List (List Tok)) := ts.flatMap CompactTapeBytes.line

def goalKey (ids : Nat→Nat) (i : Nat) : Doc :=
  if i=0 then fixed "#1" else number (ids i)
def goalDoc (ids : Nat→Nat) (i : Nat) (b : NativeScopedLocalGoal.Built) : Doc :=
  fixed "proofgoal " ++ goalKey ids i ++ fixed "\n" ++ tapesDoc b.tapes ++ closeDoc b.conclusion

def goalsDoc (ids : Nat→Nat) (i : Nat) : List (EREF.Row×NativeScopedLocalGoal.Built)→Doc
  | []=>[]
  | (_,b)::bs=>goalDoc ids i b ++ goalsDoc ids (i+1) bs

def actionDoc (ids : Nat→Nat) : NativeRecordedStep.Action→Doc
  | .pol ts=>CompactTapeBytes.line ts
  | .consequence R b=>fixed "pbc " ++ rowDoc R ++ fixed " : subproof\n" ++
      tapesDoc b.tapes ++ closeDoc b.conclusion
  | .red R w bs=>fixed "red " ++ rowDoc R ++ fixed " : " ++ witness w ++
      fixed " : subproof\n" ++ goalsDoc ids 0 bs ++ fixed "qed ;\n"

def body (D : List EREF.Row) (s : Store) (ids : Nat→Nat) : Program→Doc
  | []=>[]
  | c::cs=>
    let b:=NativeRecordedStep.compile D s ids c
    actionDoc ids b.action ++ body (D++[c.row]) b.store b.ids cs

def header (F : Nat) := fixed "pseudo-Boolean proof version 3.0\nf " ++ number F ++ fixed " ;\n"
def footer (conclusion : Nat) := fixed "output NONE ;\nconclusion UNSAT : " ++ number conclusion ++
  fixed " ;\nend pseudo-Boolean proof ;\n"
def proof (D : List EREF.Row) (p : Program) (conclusion : Nat) :=
  header D.length ++ body D (initial D) id p ++ footer conclusion

def familyDoc (n : Nat) := proof (NativeRecordedFamily.original n)
  (RecordedUniformFamily.emitter n) (NativeRecordedFamily.conclusion n)
def familyBytes (n : Nat) := emit (familyDoc n)

/-- Byte cost of each emitted POL line, including all decimal operands. -/
def tapeCost (ts : List Tok) := 7+(ts.length-1)+
  CompactReferenceWidths.referenceDigitBytes ts+CompactTapeBytes.otherBytes ts

def tapesCost (ts : List (List Tok)) := (ts.map tapeCost).sum

def keyCost (ids : Nat→Nat) (i : Nat) := if i=0 then 2 else digits (ids i)
def goalCost (ids : Nat→Nat) (i : Nat) (b : NativeScopedLocalGoal.Built) :=
  20+keyCost ids i+tapesCost b.tapes+digits b.conclusion

def goalsCost (ids : Nat→Nat) (i : Nat) : List (EREF.Row×NativeScopedLocalGoal.Built)→Nat
  | []=>0
  | (_,b)::bs=>goalCost ids i b + goalsCost ids (i+1) bs

def actionCost (ids : Nat→Nat) : NativeRecordedStep.Action→Nat
  | .pol ts=>tapeCost ts
  | .consequence R b=>25+exactBytes (rowDoc R)+tapesCost b.tapes+digits b.conclusion
  | .red R w bs=>25+exactBytes (rowDoc R)+exactBytes (witness w)+goalsCost ids 0 bs

def bodyCost (D : List EREF.Row) (s : Store) (ids : Nat→Nat) : Program→Nat
  | []=>0
  | c::cs=>
    let b:=NativeRecordedStep.compile D s ids c
    actionCost ids b.action + bodyCost (D++[c.row]) b.store b.ids cs

theorem tapes_exact (ts : List (List Tok)) : exactBytes (tapesDoc ts)=tapesCost ts := by
  simp only [tapesDoc,TemplateBytes.flatMap_bytes,tapesCost]
  congr 1
  apply List.map_congr_left
  intro t ht
  exact (emit_length _).symm.trans (CompactTapeBytes.line_exact t)

theorem close_exact (c : Nat) : exactBytes (closeDoc c)=9+digits c := by
  simp only [closeDoc,exactBytes_append,TemplateBytes.fixed_bytes,TemplateBytes.number_bytes]
  change 6+digits c+3=_
  omega

theorem key_exact (ids : Nat→Nat) (i : Nat) : exactBytes (goalKey ids i)=keyCost ids i := by
  unfold goalKey keyCost
  split <;> rfl

theorem goal_exact (ids : Nat→Nat) (i : Nat) (b : NativeScopedLocalGoal.Built) :
    exactBytes (goalDoc ids i b)=goalCost ids i b := by
  simp only [goalDoc,exactBytes_append,key_exact,tapes_exact,close_exact,TemplateBytes.fixed_bytes,goalCost]
  change 10+keyCost ids i+1+tapesCost b.tapes+(9+digits b.conclusion)=_
  omega

theorem goals_exact (ids : Nat→Nat) (i : Nat) (bs : List (EREF.Row×NativeScopedLocalGoal.Built)) :
    exactBytes (goalsDoc ids i bs)=goalsCost ids i bs := by
  induction bs generalizing i with
  | nil=>rfl
  | cons b bs ih=>simp only [goalsDoc,goalsCost,exactBytes_append,goal_exact,ih]

theorem action_exact (ids : Nat→Nat) (a : NativeRecordedStep.Action) :
    exactBytes (actionDoc ids a)=actionCost ids a := by
  cases a with
  | pol ts=>exact (emit_length _).symm.trans (CompactTapeBytes.line_exact ts)
  | consequence R b=>
    simp only [actionDoc,actionCost,exactBytes_append,tapes_exact,close_exact,TemplateBytes.fixed_bytes]
    change 4+exactBytes (rowDoc R)+12+tapesCost b.tapes+(9+digits b.conclusion)=_
    omega
  | red R w bs=>
    simp only [actionDoc,actionCost,exactBytes_append,goals_exact,TemplateBytes.fixed_bytes]
    change 4+exactBytes (rowDoc R)+3+exactBytes (witness w)+12+goalsCost ids 0 bs+6=_
    omega

theorem body_exact (D : List EREF.Row) (s : Store) (ids : Nat→Nat) (p : Program) :
    exactBytes (body D s ids p)=bodyCost D s ids p := by
  induction p generalizing D s ids with
  | nil=>rfl
  | cons c cs ih=>simp only [body,bodyCost,exactBytes_append,action_exact,ih]

/-- Exact count in BYTES of the entire document. It includes every stored
local POL certificate, every scope and every physical row reference. This
identity is not a closed polynomial bound in the arity. -/
theorem proof_exact (D : List EREF.Row) (p : Program) (c : Nat) :
    (emit (proof D p c)).length=exactBytes (header D.length)+
      bodyCost D (initial D) id p+exactBytes (footer c) := by
  simp only [emit_length,proof,exactBytes_append,body_exact]

theorem family_exact (n : Nat) :
    (familyBytes n).length=exactBytes (header (NativeRecordedFamily.original n).length)+
      bodyCost (NativeRecordedFamily.original n) (initial (NativeRecordedFamily.original n)) id
        (RecordedUniformFamily.emitter n)+exactBytes (footer (NativeRecordedFamily.conclusion n)) :=
  proof_exact ..

#print axioms tapes_exact
#print axioms goal_exact
#print axioms goals_exact
#print axioms action_exact
#print axioms body_exact
#print axioms proof_exact
#print axioms family_exact
end L3Emitter.CanonicalScopedBytes

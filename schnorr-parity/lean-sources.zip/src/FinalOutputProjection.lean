import FinalOutputDefinitions
namespace L3Emitter.FinalOutputProjection
open EREF EREF.GeneralRED REDWitness AliasNetwork FinalOutputDefinitions
variable {base:List Row}

def stages (n:Nat) (P:StateM (Net base) (Fin (T n)→Bit))
    (S:StateM (Net base) (Fin 2→Fin (W n-1)→Bit))
    (Q:(Fin (T n)→Bit)→StateM (Net base) (Fin 2→Fin (T n)→Bit))
    (F:StateM (Net base) (Fin 4→Bit)):StateM (Net base) (Data n):=do
  let xs←P;let ss←S;let ps←Q xs;let fs←F;pure ⟨xs,ss,ps,fs⟩

theorem stage_selectors (n:Nat) (P:StateM (Net base) (Fin (T n)→Bit))
    (S:StateM (Net base) (Fin 2→Fin (W n-1)→Bit))
    (Q:(Fin (T n)→Bit)→StateM (Net base) (Fin 2→Fin (T n)→Bit))
    (F:StateM (Net base) (Fin 4→Bit)) (z:Net base):
    (stages n P S Q F z).1.sels=(S (P z).2).1:=rfl

attribute [local irreducible] construction tabulate out selector FinalOutputDefinitions.port function

theorem selectors (n:Nat) (hn:2≤n) (z:Net base):
    (construction (base:=base) n hn z).1.sels=
      (tabulate 2 (fun p=>tabulate (W n-1) (selector n hn p)) (tabulate (T n) (out n hn) z).2).1:=by
  unfold construction
  rfl
#print axioms selectors
end L3Emitter.FinalOutputProjection

import AliasSelectorMainTapes
import CompleteLowerRowTapes
namespace L3Emitter.CompleteMainTapeEnvelope
set_option maxHeartbeats 800000
open EREF EREF.GeneralRED MainTapeRecurrence U2ConstructionSize

def Q (n : Nat):Nat:=(n+2)^7*2^n

theorem lift (n c p : Nat) (hp:p≤7) : c*(n+1)^p≤c*Q n := by
  have h: (n+1)^p≤(n+2)^7 := (Nat.pow_le_pow_left (by omega) p).trans (Nat.pow_le_pow_right (by omega) hp)
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  unfold Q
  have hq:(n+2)^7≤(n+2)^7*2^n:=calc
    _ = (n+2)^7*1 := by omega
    _ ≤ _ := Nat.mul_le_mul_left _ ht
  exact Nat.mul_le_mul_left c (h.trans hq)

theorem lift_t (n c p : Nat) (hp:p≤7) : c*(n+1)^p*2^n≤c*Q n := by
  have h: (n+1)^p≤(n+2)^7 := (Nat.pow_le_pow_left (by omega) p).trans (Nat.pow_le_pow_right (by omega) hp)
  unfold Q;nlinarith [Nat.mul_le_mul_right (2^n) h]

theorem transport (n : Nat) (hn : 2≤n) : count (RecordedTransportPrefix.program n hn)≤1000000*Q n := by
  have hc:=ConstantMainTapes.complete n hn
  have hr:=RecordedProjectionMainTapes.complete (n+1) (by omega) (BetaValue.result n hn)
  have hw:tokens (WireBank.program n hn)≤1512*Q n:=(TransportBankMainTapes.wire n hn).trans (lift_t n 1512 2 (by omega))
  have hg:tokens (GammaConstant.program n hn)≤46656*Q n:=(TransportBankMainTapes.gamma n hn).trans (lift_t n 46656 5 (by omega))
  have hi:tokens (InputBank.program n hn)≤132*Q n:=(TransportBankMainTapes.input n hn).trans (lift_t n 132 2 (by omega))
  have ho:tokens (OutputBank.program n hn)≤6*Q n:=(TransportBankMainTapes.output n hn).trans (by simpa using lift_t n 6 0 (by omega))
  have hv:count (RecordedRawValues.program n hn)≤225*Q n:=(TransportBankMainTapes.raw n hn).trans (lift_t n 225 3 (by omega))
  have hu:tokens (GammaUnary.program n hn)≤186624*Q n:=(TransportBankMainTapes.unary n hn).trans (lift_t n 186624 5 (by omega))
  have hs:tokens (SelectorBank.program n hn)≤864*Q n:=(AliasSelectorMainTapes.selectors n hn).trans (lift n 864 4 (by omega))
  have ha:count (RecordedAliasBanks.program n hn)≤200000*Q n:=(AliasSelectorMainTapes.aliases n hn).trans (lift n 200000 6 (by omega))
  have hp:(n+2)^4≤(n+2)^7:=Nat.pow_le_pow_right (by omega) (by omega)
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have hc':count (RecordedConstantTransport.program n hn)≤500000*Q n:=hc.trans (by unfold Q;nlinarith [Nat.mul_le_mul_right (2^n) hp])
  have hr':count (RecordedRankAdmission.program (n+1) (by omega) (BetaValue.result n hn))≤23000*Q n:=hr.trans (by unfold Q;nlinarith)
  simp only [RecordedTransportPrefix.program,RecordedTransportPrefix.selectorProgram,
    RecordedTransportPrefix.unaryProgram,RecordedTransportPrefix.rawProgram,
    RecordedTransportPrefix.outputProgram,RecordedTransportPrefix.inputProgram,
    RecordedTransportPrefix.gammaProgram,RecordedTransportPrefix.wireProgram,
    RecordedTransportPrefix.rankProgram,append,pol_program]
  simp only [tokens] at hw hg hi ho hu hs
  omega

def reductionBound (n : Nat):Nat:=6000000*(n+2)^8*(2^n)^2

theorem reduction (n : Nat) (hn : 2≤n) : count (RecordedCompleteLower.program n hn)≤reductionBound n := by
  have hp:=transport n hn
  have hg:=GlobalExtensionMainTapes.complete n hn
  have ht:=CompleteTableTapes.complete n hn
  have hl:=CompleteLowerRowTapes.complete n hn
  have hf:=CompleteFinalRowTapes.complete n hn
  unfold GlobalExtensionMainTapes.Q at hg
  unfold CompleteTableTapes.Q at ht
  unfold CompleteFinalRowTapes.Q at hf
  have p7:(n+2)^7≤(n+2)^8:=Nat.pow_le_pow_right (by omega) (by omega)
  have p8:(n+1)^8≤(n+2)^8:=Nat.pow_le_pow_left (by omega) 8
  have p6:(n+1)^6≤(n+2)^8:=(Nat.pow_le_pow_left (by omega) 6).trans (Nat.pow_le_pow_right (by omega) (by omega))
  have p4:(n+1)^4≤(n+2)^8:=(Nat.pow_le_pow_left (by omega) 4).trans (Nat.pow_le_pow_right (by omega) (by omega))
  have p7':(n+1)^7≤(n+2)^8:=(Nat.pow_le_pow_left (by omega) 7).trans p7
  have hpow:2^n≤(2^n)^2:=by have h:=Nat.one_le_pow 2 n (by omega);nlinarith
  have q1:=Nat.mul_le_mul p7 hpow
  have q2:=Nat.mul_le_mul p7' hpow
  have q3:=Nat.mul_le_mul p6 hpow
  have q4:=Nat.mul_le_mul p8 hpow
  have q5:=Nat.mul_le_mul_right ((2^n)^2) p4
  let K:=(n+2)^8*(2^n)^2
  have hh0:count (RecordedTransportPrefix.program n hn)≤1000000*K:=hp.trans (Nat.mul_le_mul_left _ q1)
  have hh1:count (RecordedGlobalValues.program n hn)≤5000000*K:=by
    have hq:=Nat.mul_le_mul_left 4000000 q2
    change _≤4000000*K at hq
    omega
  have hh2:count (RecordedTableTransport.program n hn)≤60000*K:=ht.trans (by
    have hq:=Nat.mul_le_mul_left 60000 q3
    simpa only [Nat.mul_assoc] using hq)
  have hh3:count (RecordedLowerRows.program n hn)≤150000*K:=hl.trans (by
    have hq:=Nat.mul_le_mul_left 150000 q4
    simpa only [Nat.mul_assoc] using hq)
  have hh4:count (RecordedFinalRows.program n hn)≤10000*K:=hf.trans (by
    have hq:=Nat.mul_le_mul_left 10000 q5
    simpa only [Nat.mul_assoc] using hq)
  rw [RecordedCompleteLower.program,append,append,append]
  unfold reductionBound
  rw [Nat.mul_assoc]
  change _≤6000000*K
  omega
#print axioms transport
#print axioms reduction
end L3Emitter.CompleteMainTapeEnvelope

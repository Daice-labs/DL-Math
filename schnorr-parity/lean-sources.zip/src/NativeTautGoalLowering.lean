import CanonicalScopeKernel
namespace L3Emitter.NativeTautGoalLowering
open EREF EREF.GeneralRED RecordedScopedTrace

/-- Direct proof from the just-opened negated goal. It allocates no POL
rows. This is a lowering of recorded lowerLocal certificates, not a modification
of the frozen mathematical family. -/
def direct (len:Nat):RecordedRefutation.Certificate:=⟨[],len+1⟩

theorem neg_trivial (G:Row) (hc:Canonical G) (hb:G.bound≤0):Contra (negate G):=by
 apply (canonical_contra_iff (negate G) (canonical_negate G)).mpr
 intro a
 unfold Row.sat
 rw [val_negate G hc]
 have ht:=tval_nonneg a G.terms
 unfold Row.val at *
 omega

theorem direct_accepts (D:List Row) (G:Row) (hc:Canonical G) (hb:G.bound≤0):
 RecordedRefutation.accepts (D++[negate G]) (direct D.length)=true:=by
 have h:=neg_trivial G hc hb
 simpa [RecordedRefutation.accepts,direct,AliasProgram.check,dbOf,Contra] using h

def lowerLocal (D:List Row) (G:Row) (p:RecordedRefutation.Certificate):RecordedRefutation.Certificate:=
 if G.bound≤0 then direct D.length else p

theorem local_accepts (D:List Row) (G:Row) (p:RecordedRefutation.Certificate)
 (hc:Canonical G) (hp:RecordedRefutation.accepts (D++[negate G]) p=true):
 RecordedRefutation.accepts (D++[negate G]) (lowerLocal D G p)=true:=by
 unfold lowerLocal;split
 · exact direct_accepts D G hc ‹_›
 · exact hp

theorem local_count (D:List Row) (G:Row) (p:RecordedRefutation.Certificate):
 (lowerLocal D G p).program.length≤p.program.length:=by unfold lowerLocal;split <;> simp [direct]

theorem local_tokens (D:List Row) (G:Row) (p:RecordedRefutation.Certificate):
 ((lowerLocal D G p).program.map (fun c=>c.2.length)).sum≤(p.program.map (fun c=>c.2.length)).sum:=by
 unfold lowerLocal;split <;> simp [direct]

def goals (D:List Row) (C:Row) (w:FiniteWitness.Data):
 List Row→List RecordedRefutation.Certificate→List RecordedRefutation.Certificate
 | R::rs,p::ps=>lowerLocal (D++[negate C]) (substRow R (FiniteWitness.interpret w)) p::goals D C w rs ps
 | _,_=>[]

theorem goals_accepts (D:List Row) (C:Row) (w:FiniteWitness.Data)
 (rs:List Row) (ps:List RecordedRefutation.Certificate)
 (h:checkGoals D C w rs ps=true):checkGoals D C w rs (goals D C w rs ps)=true:=by
 induction rs generalizing ps with
 | nil=>cases ps <;> simp_all [checkGoals,goals]
 | cons R rs ih=>
   cases ps with
   | nil=>simp [checkGoals] at h
   | cons p ps=>
     obtain ⟨hp,ht⟩:=Bool.and_eq_true_iff.mp h
     have hh:=local_accepts (D++[negate C]) (substRow R (FiniteWitness.interpret w)) p
      (canonical_substRow ..) (by simpa only [List.append_assoc,List.singleton_append] using hp)
     simp only [goals,checkGoals]
     exact Bool.and_eq_true_iff.mpr ⟨by simpa only [List.append_assoc,List.singleton_append] using hh,ih ps ht⟩

def step (D:List Row):Step→Step
 | .pol R ts=>.pol R ts
 | .consequence R p=>.consequence R (lowerLocal D R p)
 | .red R w ps=>.red R w (goals D R w (R::D) ps)

theorem step_row (D:List Row) (c:Step):(step D c).row=c.row:=by cases c <;> rfl

theorem step_accepts (M guard:Nat) (D:List Row) (c:Step)
 (h:c.accepts M guard D=true):(step D c).accepts M guard D=true:=by
 cases c with
 | pol R ts=>exact h
 | consequence R p=>
   obtain ⟨hr,hp⟩:=Bool.and_eq_true_iff.mp h
   exact Bool.and_eq_true_iff.mpr ⟨hr,local_accepts D R p (of_decide_eq_true hr) hp⟩
 | red R w ps=>
   obtain ⟨hp,hg⟩:=Bool.and_eq_true_iff.mp h
   exact Bool.and_eq_true_iff.mpr ⟨hp,goals_accepts D R w (R::D) ps hg⟩

def program (D:List Row):Program→Program
 | []=>[]
 | c::cs=>step D c::program (D++[c.row]) cs

theorem program_accepts (M guard:Nat) (D E:List Row) (p:Program)
 (h:check M guard D p=some E):check M guard D (program D p)=some E:=by
 induction p generalizing D with
 | nil=>exact h
 | cons c cs ih=>
   simp only [check] at h
   split at h
   · rename_i hc
     simpa only [program,check,step_accepts M guard D c hc,if_true,step_row] using ih (D++[c.row]) h
   · contradiction
#print axioms program_accepts
#print axioms local_tokens
end L3Emitter.NativeTautGoalLowering

import CofactorSemantics

namespace L3Emitter.FormulaSize
open FamilyNamespace OriginalEncoding

theorem flatMap_bound {α β : Type} (xs : List α) (f : α → List β) (B : Nat)
    (hf : ∀ x∈xs,(f x).length≤B) : (xs.flatMap f).length≤xs.length*B := by
  induction xs with
  | nil => simp
  | cons x xs ih =>
    have h := hf x (by simp)
    have ht := ih (by intro y hy; exact hf y (by simp [hy]))
    simp only [List.flatMap_cons,List.length_append,List.length_cons]
    nlinarith

theorem loop_bound {α : Type} (n : Nat) (f : Nat → List α) (B : Nat)
    (hf : ∀ i<n,(f i).length≤B) : (loop n f).length≤n*B := by
  simpa [loop] using flatMap_bound (List.range n) f B
    (by intro i hi; exact hf i (List.mem_range.mp hi))

def rowBound (k s : Nat) : Nat := 6*s+(4*s*(k+s)+8*s+1)*truthRows k

theorem original_rows_bound (k s : Nat) : (rows k s).length≤rowBound k s := by
  have hsel : (selectorsBlock k s).length≤4*s := by
    have h := loop_bound s (fun t => loop 2 fun p =>
      [InputSwap.oneHot k t p true,InputSwap.oneHot k t p false]) 4 (by
        intro t ht; exact loop_bound _ _ 2 (by intros; simp))
    simpa [selectorsBlock,Nat.mul_comm] using h
  have hfor : (forbiddenBlock s).length≤2*s := by
    have h := loop_bound s (fun t => [InputSwap.forbidden t 6,InputSwap.forbidden t 9]) 2
      (by intros; simp)
    simpa [forbiddenBlock,Nat.mul_comm] using h
  have htrans : (transfersBlock k s).length≤4*s*(k+s)*truthRows k := by
    let portRows := fun t p =>
      (loop k fun j => loop (truthRows k) fun x => [InputSwap.inputTransfer k t p j x]) ++
      (loop t fun g => loop (truthRows k) fun x =>
        [InputSwap.gateTransfer k t p g x true,InputSwap.gateTransfer k t p g x false])
    have h := loop_bound s (fun t => loop 2 (portRows t)) (4*(k+s)*truthRows k) (by
      intro t ht
      have hp := loop_bound 2 (portRows t) (2*(k+s)*truthRows k) (by
        intro p hp
        have hi := loop_bound k (fun j => loop (truthRows k) fun x =>
          [InputSwap.inputTransfer k t p j x]) (truthRows k) (by
            intro j hj
            simpa using loop_bound (truthRows k) _ 1 (by intros; simp))
        have hg := loop_bound t (fun g => loop (truthRows k) fun x =>
          [InputSwap.gateTransfer k t p g x true,InputSwap.gateTransfer k t p g x false])
          (2*truthRows k) (by
            intro g hg
            simpa [Nat.mul_comm] using loop_bound (truthRows k) _ 2 (by intros; simp))
        simp only [portRows,List.length_append]
        have hts : t*truthRows k≤s*truthRows k := Nat.mul_le_mul_right _ (by omega)
        nlinarith)
      convert hp using 1 <;> ring)
    change (transfersBlock k s).length≤_ at h
    nlinarith
  have hsem : (semanticsBlock k s).length≤8*s*truthRows k := by
    have h := loop_bound s (fun t => loop (truthRows k) fun x =>
      [false,true].flatMap fun a => [false,true].flatMap fun b =>
        [InputSwap.semantics t x a b true,InputSwap.semantics t x a b false])
      (8*truthRows k) (by
        intro t ht
        simpa [Nat.mul_comm] using loop_bound (truthRows k) _ 8 (by intros; simp))
    change (semanticsBlock k s).length≤_ at h
    nlinarith
  have hout : (outputsBlock k s).length≤truthRows k := by
    simpa [outputsBlock] using loop_bound (truthRows k)
      (fun x => [InputSwap.outputRow k s x]) 1 (by intros; simp)
  simp only [rows,List.length_map,specs,List.length_append,rowBound]
  nlinarith

theorem bank_length_bound (n s offset B : Nat) :
    (CofactorSemantics.bank n s offset B).length≤12*s*truthRows n := by
  unfold CofactorSemantics.bank
  have h := flatMap_bound (List.range s) (fun g => (List.range 3).flatMap fun p =>
    (List.range (truthRows n)).flatMap (CofactorSemantics.cellRows n s offset B g p))
    (12*truthRows n) (by
    intro g hg
    have hp := flatMap_bound (List.range 3) (fun p =>
      (List.range (truthRows n)).flatMap (CofactorSemantics.cellRows n s offset B g p))
      (4*truthRows n) (by
      intro p hp
      have hx := flatMap_bound (List.range (truthRows n))
        (CofactorSemantics.cellRows n s offset B g p) 4 (by
          intro x hx
          simp [CofactorSemantics.cellRows,REDWitness.muxGate])
      simpa [Nat.mul_comm] using hx)
    simpa [←Nat.mul_assoc] using hp)
  simpa [Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm] using h

def databaseBound (n s : Nat) : Nat := rowBound (n+1) s+12*s*truthRows n

theorem database_length_bound (n s offset B : Nat) :
    (CofactorSemantics.database n s offset B).length≤databaseBound n s := by
  have h0 := original_rows_bound (n+1) s
  have h1 := bank_length_bound n s offset B
  simp only [CofactorSemantics.database,List.length_append,databaseBound]
  omega

#print axioms original_rows_bound
#print axioms database_length_bound
end L3Emitter.FormulaSize

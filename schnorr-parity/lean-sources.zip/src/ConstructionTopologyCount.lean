import ConstructionTableCount
namespace L3Emitter.ConstructionTopologyCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount

theorem port (n : Nat) (hn : 2≤n) (G t g p : Nat) (u : Fin (RankConstruction.width (n+1))) (D : List Row) :
    (TopologyPort.program n hn G t g p u D).length=n+g+2 := by
  simp [TopologyPort.program,GuardedZeroSelection.command_count,TopologyPort.choices];omega

theorem mux (n : Nat) (hn : 2≤n) (G t g : Nat) (u : Fin (RankConstruction.width (n+1))) (D : List Row) :
    (TopologyMux.program n hn G t g u D).length=4 := by
  simp [TopologyMux.program,MuxSourceStep.seed,GuardedZeroSelection.command_count]

theorem category (n : Nat) (hn : 2≤n) (G t g : Nat) (u : Fin (RankConstruction.width (n+1))) (D : List Row) :
    (TopologyCategory.program n hn G t g u D).length≤3*(n+1)+3 := by
  simp [TopologyCategory.program,TopologyCategory.casesProgram,CategoryPrograms.cats,GateCategories.categories]
  omega

theorem step (n : Nat) (hn : 2≤n) (G t g : Nat) (u : Fin (RankConstruction.width (n+1))) (D : List Row) :
    (TopologyInduction.stepProgram n hn G t g u D).length≤5*n+2*g+15 := by
  have hc:=category n hn G t g u (TopologyInduction.mux n hn G t g u D)
  simp only [TopologyInduction.stepProgram,List.length_append,port,mux]
  omega

theorem run (n : Nat) (hn : 2≤n) (G t : Nat) (u : Fin (RankConstruction.width (n+1))) (g m : Nat) (D : List Row) :
    (TopologyInduction.program n hn G t u g D m).length≤m*(5*n+2*(g+m)+15) := by
  induction m generalizing g D with
  | zero=>simp [TopologyInduction.program]
  | succ m ih=>
    have hs:=step n hn G t g u D
    have hh:=ih (g+1) (D++TopologyInduction.stepRows n hn G t g u)
    simp only [TopologyInduction.program,List.length_append]
    nlinarith

theorem leaf (n : Nat) (hn : 2≤n) (j : TopologyBank.Job n) (hj : TopologyBank.ValidJob n j) (D : List Row) :
    (TopologyBank.leaf n hn j D).length≤150*(n+1)^2 := by
  have hh:=run n hn j.1 j.2.1 j.2.2 1 (j.1-1) (TopologyBank.start n hn j D)
  have hg:j.1≤3*(n+1):=by have:=hj.2.1;omega
  have hp:j.1-1≤3*(n+1):=by omega
  have hb:5*n+2*(1+(j.1-1))+15≤30*(n+1):=by omega
  have hm:=Nat.mul_le_mul hp hb
  simp only [TopologyBank.leaf,List.length_append,port]
  change 1+_+(n+j.1+2)+(n+j.1+2)≤_
  nlinarith

theorem jobs (n : Nat) : (TopologyBank.jobs n).length≤27*(n+1)^3 := by
  unfold TopologyBank.jobs
  have h:=flat_bound (List.range (3*(n+1)-4)) (fun G=>(List.finRange (RankConstruction.width (n+1))).flatMap fun u=>(List.range (u.val+1)).flatMap fun t=>if 0<G then [(G,t,u)] else []) ((RankConstruction.width (n+1))^2) (by
    intro G hG
    have hu:=flat_bound (List.finRange (RankConstruction.width (n+1))) (fun u=>(List.range (u.val+1)).flatMap fun t=>if 0<G then [(G,t,u)] else []) (RankConstruction.width (n+1)) (by
      intro u hu
      have ht:=flat_bound (List.range (u.val+1)) (fun t=>if 0<G then [(G,t,u)] else []) 1 (by
        intro t ht;dsimp only;split <;> simp)
      simp only [List.length_range,Nat.mul_one] at ht
      exact ht.trans (by have:=u.isLt;omega))
    simpa only [List.length_finRange,pow_two] using hu)
  simp only [List.length_range] at h
  have hw:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hm:=Nat.mul_le_mul (Nat.sub_le (3*(n+1)) 4) (Nat.pow_le_pow_left hw 2)
  exact h.trans (hm.trans_eq (by ring))

theorem complete (n : Nat) (hn : 2≤n) : (TopologyBank.program n hn).length≤4050*(n+1)^5 := by
  have h:=retained_fold (TopologyBank.leaf n hn) (TopologyBank.rows n hn) (TopologyBank.jobs n)
    (TopologyContext.base n hn) (150*(n+1)^2)
    (by intro j hj D;exact leaf n hn j ((TopologyBank.job_mem n j).mp hj) D)
  change (TopologyBank.program n hn).length≤_ at h
  exact h.trans ((Nat.mul_le_mul_right _ (jobs n)).trans_eq (by ring))
#print axioms complete
end L3Emitter.ConstructionTopologyCount

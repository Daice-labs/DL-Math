import RankOrderTapeBounds
namespace L3Emitter.CompleteLowerRowTapes
open EREF EREF.GeneralRED U2ConstructionSize MainTapeRecurrence

def scale (n : Nat) :=(n+1)^8*2^n

theorem lift_plain (n C a : Nat) (ha : a≤8) : C*(n+1)^a≤C*scale n := by
  have hp:(n+1)^a≤(n+1)^8:=Nat.pow_le_pow_right (by omega) ha
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have hm:=Nat.mul_le_mul hp ht
  exact (Nat.mul_le_mul_left C (by simpa using hm)).trans_eq (by unfold scale;ring)

theorem lift_power (n C a : Nat) (ha : a≤8) : C*(n+1)^a*2^n≤C*scale n := by
  exact (Nat.mul_le_mul_right (2^n) (Nat.mul_le_mul_left C (Nat.pow_le_pow_right (by omega) ha))).trans_eq (by unfold scale;ring)

/-- Every main POL tape in the actual lower-row stage: rank order, primary
transfers, selector AMO/ALO, topology/zero, U2, ports, evaluation and phase.
The predecessor/global/table/final-output stages are separate. Unit: tokens. -/
theorem complete (n : Nat) (hn : 2≤n) :
    count (RecordedLowerRows.program n hn)≤150000*scale n := by
  have h0:= (RankOrderTapeBounds.complete n hn).trans (lift_plain n 40500 8 (by omega))
  have h1:= (LowerSelectorTapeBounds.primary n hn).trans (lift_power n 18 2 (by omega))
  have h2:= (LowerSelectorTapeBounds.amo n hn).trans (lift_plain n 144 3 (by omega))
  have h3:= (TopologyTapeBounds.complete n hn).trans (lift_plain n 81000 5 (by omega))
  have h4:= (LowerSelectorTapeBounds.zero n hn).trans (lift_plain n 468 3 (by omega))
  have h5:= (LowerSelectorTapeBounds.alo n hn).trans (lift_plain n 54 2 (by omega))
  have h6:= (LowerEvaluationTapeBounds.combined n hn).trans (lift_power n 18000 2 (by omega))
  simp only [RecordedLowerRows.program,RecordedLowerRows.p10,RecordedLowerRows.p9,
    RecordedLowerRows.p8,RecordedLowerRows.p7,RecordedLowerRows.p6,RecordedLowerRows.p5,
    RecordedLowerRows.p4,RecordedLowerRows.p3,RecordedLowerRows.p2,RecordedLowerRows.p1,
    RecordedLowerRows.p0,append,pol_program]
  change tokens (RankOrderExclusion.emitted n hn)+tokens (RawPrimaryTransferBank.program n hn)+
    tokens (LowerSelectorAMO.program n hn)+tokens (TopologyBank.program n hn)+
    tokens (LowerTopologyBank.program n hn)+tokens (LowerSelectorALO.program n hn)+
    tokens (ComposedU2Bank.program n hn)+tokens (LowerU2Bank.program n hn)+
    tokens (LowerPortEvalBank.program n hn)+tokens (LowerGateBank.program n hn)+
    tokens (OutputPhaseBank.program n hn)≤_
  omega

/-- This component is polynomial in the number of actual encoded formula rows;
no instantiated proof is constructed to establish the inequality. -/
theorem in_formula (n : Nat) (hn : 2≤n) :
    count (RecordedLowerRows.program n hn)≤150000*(ConstructionFormulaScale.rows n)^9 := by
  have ha:=ConstructionFormulaScale.arity n hn
  have ht:=ConstructionFormulaScale.truth_table n hn
  have hm:=Nat.mul_le_mul (Nat.pow_le_pow_left ha 8) ht
  exact (complete n hn).trans ((Nat.mul_le_mul_left 150000 hm).trans_eq (by ring))
#print axioms complete
#print axioms in_formula
end L3Emitter.CompleteLowerRowTapes

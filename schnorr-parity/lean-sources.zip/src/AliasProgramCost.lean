import AliasCost

namespace L3Emitter.AliasAssembly
open EREF AliasNetwork RecursiveAliases
variable {base : List Row}

theorem context_cost (k : Nat) (hk : 3≤k) :
    Cost (context (base:=base) k hk) (1+3*(3*k-4)+(3*k-4)^2) := by
  unfold context
  refine cost_mono _ (1+((3*k-4)+((3*k-4)+((3*k-4)+((3*k-4)*(3*k-4)+0))))) _ ?_ ?_
  · exact bind_cost (base:=base) (AND []) _ 1
      ((3*k-4)+((3*k-4)+((3*k-4)+((3*k-4)*(3*k-4)+0))))
      (gate_cost true _) (fun T=>
        bind_cost _ _ (3*k-4) ((3*k-4)+((3*k-4)+((3*k-4)*(3*k-4)+0)))
          (by simpa using tabulate_cost (base:=base) (3*k-4) _ 1 (fun _=>gate_cost false _))
          (fun beta=>bind_cost _ _ (3*k-4) ((3*k-4)+((3*k-4)*(3*k-4)+0))
            (by simpa using tabulate_cost (base:=base) (3*k-4) _ 1 (fun _=>gate_cost false _))
            (fun gamma=>bind_cost _ _ (3*k-4) ((3*k-4)*(3*k-4)+0)
              (by simpa using tabulate_cost (base:=base) (3*k-4) _ 1 (fun _=>gate_cost false _))
              (fun kept=>bind_cost _ _ ((3*k-4)*(3*k-4)) 0
                (tabulate_cost _ _ (3*k-4) (fun g=>by
                  apply cost_mono _ _ _ (select_cost _)
                  simp only [List.length_map,List.length_range]
                  have:=g.isLt
                  omega))
                (fun hit=>pure_cost _)))))
  · ring_nf
    exact Nat.le_refl _

theorem context_k (k : Nat) (hk : 3≤k) (z : Net base) :
    (context k hk z).1.k=k := rfl

def aliasGateBound (k : Nat) : Nat :=
  1+3*(3*k-4)+(3*k-4)^2+
    (3*k-4)*((width k+2)*(2*(k+(3*k-4))+25))

/-- Bound for the actual complete alias-definition program, including its
    once-allocated choice context. This is not a bound for missing PB leaves. -/
theorem program_cost (k : Nat) (hk : 3≤k) :
    Cost (program (base:=base) k hk) (aliasGateBound k) := by
  intro z
  have h1:=context_cost (base:=base) k hk z
  have h2:=run_cost (base:=base) (context k hk z).1
    (inputAliases (width k) (context k hk z).1) 0 (3*k-4) (context k hk z).2
  rw [context_k] at h2
  change (RecursiveAliases.run (context k hk z).1
    (inputAliases (width k) (context k hk z).1) 0 (3*k-4) (context k hk z).2).2.gates.length≤_
  unfold aliasGateBound
  simp only [Nat.add_zero] at h2
  omega

theorem width_bound (k : Nat) : width k+2≤4*k+2 := by
  unfold width RankConstruction.width
  omega

theorem aliasGateBound_polynomial (k : Nat) :
    aliasGateBound k≤96*k^3+357*k^2+159*k+1 := by
  have hs : 3*k-4≤3*k:=Nat.sub_le _ _
  have hw:=width_bound k
  have hsq : (3*k-4)^2≤(3*k)^2:=Nat.pow_le_pow_left hs 2
  have hprod : (3*k-4)*((width k+2)*(2*(k+(3*k-4))+25))≤
      (3*k)*((4*k+2)*(8*k+25)) :=
    Nat.mul_le_mul hs (Nat.mul_le_mul hw (by omega))
  unfold aliasGateBound
  nlinarith

theorem built_gate_count (n : Nat) (hn : 2≤n) :
    (built n hn).2.gates.length≤96*(n+1)^3+357*(n+1)^2+159*(n+1)+1 := by
  have h:=program_cost (n+1) (by omega)
    (initial (source n hn) (source_canonical n hn))
  have hp:=aliasGateBound_polynomial (n+1)
  simp only [initial,List.length_nil,Nat.zero_add] at h
  exact h.trans hp

#print axioms context_cost
#print axioms program_cost
#print axioms built_gate_count
end L3Emitter.AliasAssembly

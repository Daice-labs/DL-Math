import NativeParserLiteralTraversal
import PinnedWitnessBits
namespace L3Emitter.NativeParserNameRanges
open EREF CanonicalFileGrammar NativeParserEventCoordinates PinnedCoordinateChange

def formulaNames (n:Nat):List Nat:=(NativeRecordedFamily.original n).flatMap rowNames
def proofNames (n:Nat):List Nat:=((NativeCompatibleFamily.commands n).flatMap commandEvents).flatMap eventNames

theorem full_names (n:Nat):NativeParserBundle.names n=
 PinnedNameSequence.run [] (formulaNames n++proofNames n):=by
 unfold NativeParserBundle.names NativeParserCheckedFile.names NativeParserBundle.formulaNames
 rw [NativeParserEventCoordinates.final_names,NativeParserFormula.final_names,sequence_append]
 rfl

theorem present (n v:Nat) (h:v∈formulaNames n++proofNames n):v∈NativeParserBundle.names n:=by
 rw [full_names]
 exact PinnedNameSequence.inserted [] _ v h

theorem coordinate_bound (n v:Nat) (h:v∈formulaNames n++proofNames n):
 0 < coordinate (NativeParserBundle.names n) v ∧
 coordinate (NativeParserBundle.names n) v ≤ (NativeParserBundle.names n).length:=by
 have hp:=present n v h
 rw [encountered _ _ hp]
 have hi:=List.idxOf_lt_length_of_mem hp
 omega

theorem formula_field (n:Nat) (R:Row) (hR:R∈NativeRecordedFamily.original n)
 (t:Nat×Int) (ht:t∈R.terms):
 0 < coordinate (NativeParserBundle.names n) t.2.natAbs ∧
 coordinate (NativeParserBundle.names n) t.2.natAbs≤(NativeParserBundle.names n).length:=by
 apply coordinate_bound n _
 apply List.mem_append_left
 exact List.mem_flatMap.mpr ⟨R,hR,List.mem_map.mpr ⟨t,ht,rfl⟩⟩

theorem event_field (n:Nat) (e:CanonicalLineParser.Event)
 (he:e∈(NativeCompatibleFamily.commands n).flatMap commandEvents)
 (v:Nat) (hv:v∈eventNames e):
 0 < coordinate (NativeParserBundle.names n) v ∧
 coordinate (NativeParserBundle.names n) v≤(NativeParserBundle.names n).length:=by
 apply coordinate_bound n _
 apply List.mem_append_right
 exact List.mem_flatMap.mpr ⟨e,he,hv⟩

/-- A nonvacuous actual-name-count condition discharges the native packed
literal range for every emitted literal field, independently of coarse M(n). -/
theorem event_literal_range (n:Nat) (e:CanonicalLineParser.Event)
 (he:e∈(NativeCompatibleFamily.commands n).flatMap commandEvents)
 (l:Int) (hl:l∈NativeParserLiteralTraversal.literals e)
 (hm:(NativeParserBundle.names n).length<2^63):
 0 < (lit (coordinate (NativeParserBundle.names n)) l).natAbs ∧
 (lit (coordinate (NativeParserBundle.names n)) l).natAbs<2^63:=by
 have hv:l.natAbs∈eventNames e:=by
   rw [←NativeParserLiteralTraversal.names]
   exact List.mem_map.mpr ⟨l,hl,rfl⟩
 have hb:=event_field n e he l.natAbs hv
 rw [lit_abs]
 exact ⟨hb.1,lt_of_le_of_lt hb.2 hm⟩
#print axioms event_literal_range
end L3Emitter.NativeParserNameRanges

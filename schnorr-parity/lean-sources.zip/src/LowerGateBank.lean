import LowerGateEvaluation
namespace L3Emitter.LowerGateBank
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL AliasProgram
abbrev Job:=Nat×Nat×Bool×Bool×Bool
def jobs (n:Nat):List Job:=(List.range (RankConstruction.width (n+1))).flatMap fun t=>
  (List.range (FamilyNamespace.truthRows n)).flatMap fun x=>[false,true].flatMap fun a=>[false,true].flatMap fun b=>[false,true].map fun w=>(t,x,a,b,w)
def ValidJob (n:Nat) (j:Job):Prop:=j.1<RankConstruction.width (n+1) ∧ j.2.1<FamilyNamespace.truthRows n

theorem job_mem (n:Nat) (j:Job):j∈jobs n↔ValidJob n j:=by
  obtain ⟨t,x,a,b,w⟩:=j;cases a <;> cases b <;> cases w <;> simp [jobs,ValidJob]

def leaf (n:Nat) (hn:2≤n) (j:Job):List Row→Program:=
  LowerGateEvaluation.program n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2
def rows (n:Nat) (hn:2≤n) (j:Job):=
  LowerGateEvaluation.rows n hn j.1 j.2.1 j.2.2.1 j.2.2.2.1 j.2.2.2.2
def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n) (GateEvaluationBindings.base n hn)
def result (n:Nat) (hn:2≤n):=GateEvaluationBindings.base n hn++RetainedBlockFold.body (rows n hn) (jobs n)

theorem checks (n:Nat) (hn:2≤n):check (GateEvaluationBindings.base n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (ValidJob n)
    (fun j hj D hd=>LowerGateEvaluation.checks n hn j.1 j.2.1 hj.1 hj.2 j.2.2.1 j.2.2.2.1 j.2.2.2.2 D hd)
    _ (fun j hj=>(job_mem n j).mp hj) _ (fun _ h=>h)

theorem original_to_gate_evaluations (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (LowerPortEvalBank.original_to_port_evaluations n hn) (check_trace _ _ _ (checks n hn))

theorem all_rows (n:Nat) (hn:2≤n) (t x:Nat) (ht:t<RankConstruction.width (n+1))
    (hx:x<FamilyNamespace.truthRows n) (a b w:Bool):
    RankGateEvaluation.row n hn t x a b w∈result n hn:=
  List.mem_append_right _ (RetainedBlockFold.contains _ _ (t,x,a,b,w) ((job_mem n _).mpr ⟨ht,hx⟩) _
    (LowerGateEvaluation.final_mem n hn t x a b w))

theorem image_eq (n:Nat) (hn:2≤n) (t x:Nat) (a b w:Bool):
    LowerTransferImage.image n hn (InputSwap.semantics t x a b (!w))=RankGateEvaluation.row n hn t x a b w:=by
  have hp:=ProjectionTrace.clause_perm
    [-sign a (LowerTransferImage.wire n hn (.port t 0 x)),-sign b (LowerTransferImage.wire n hn (.port t 1 x)),
      sign w (LowerTransferImage.wire n hn (.val t x)),-sign w (LowerTransferImage.wire n hn (.fn t (RankTableBank.code a b)))]
    (RankGateEvaluation.literals n hn t x a b w)
    (by simp [Valid,sign_valid]) (by simp [RankGateEvaluation.literals,Valid,sign_valid])
    (List.Perm.cons _ (List.Perm.cons _ (List.Perm.swap ..)))
  have he:LowerTransferImage.image n hn (InputSwap.semantics t x a b (!w))=
    clause [-sign a (LowerTransferImage.wire n hn (.port t 0 x)),-sign b (LowerTransferImage.wire n hn (.port t 1 x)),
      sign w (LowerTransferImage.wire n hn (.val t x)),-sign w (LowerTransferImage.wire n hn (.fn t (RankTableBank.code a b)))]:=by
    simp only [LowerTransferImage.image,InputSwap.semantics,List.map_cons,List.map_nil,LowerPortEvaluation.sign_not,Bool.not_not,clause]
    rfl
  exact he.trans hp

theorem all_semantics_images (n:Nat) (hn:2≤n) (r:FamilyRows.Spec)
    (hr:r∈OriginalEncoding.semanticsBlock n (3*n-4)):
    LowerTransferImage.image n hn r∈result n hn:=by
  obtain ⟨t,x,a,b,c,ht,hx,rfl⟩:=(OriginalEncoding.semantics_mem _ _ r).mp hr
  have ht':t<RankConstruction.width (n+1):=by unfold RankConstruction.width;omega
  have h:=all_rows n hn t x ht' hx a b (!c)
  rw [←image_eq] at h
  simpa only [Bool.not_not] using h

theorem all_nonoutput_images (n:Nat) (hn:2≤n) (r:FamilyRows.Spec)
    (hr:r∈OriginalEncoding.selectorsBlock n (3*n-4) ∨ r∈OriginalEncoding.forbiddenBlock (3*n-4) ∨
        r∈OriginalEncoding.transfersBlock n (3*n-4) ∨ r∈OriginalEncoding.semanticsBlock n (3*n-4)):
    LowerTransferImage.image n hn r∈result n hn:=by
  rcases hr with h|h|h|h
  · exact List.mem_append_left _ (List.mem_append_left _ (LowerU2Bank.selector_and_transfer_images n hn r (Or.inl h)))
  · exact List.mem_append_left _ (List.mem_append_left _ (LowerU2Bank.all_U2_images n hn r h))
  · exact List.mem_append_left _ (List.mem_append_left _ (LowerU2Bank.selector_and_transfer_images n hn r (Or.inr h)))
  · exact all_semantics_images n hn r h
#print axioms original_to_gate_evaluations
#print axioms all_semantics_images
#print axioms all_nonoutput_images
end L3Emitter.LowerGateBank

import ConstructionFrontendCoverageCount

namespace L3Emitter.ConstructionFrontendCount
open EREF EREF.GeneralRED L3 L3.Fam ConstructionFrontendCountTools
open ConstructionFrontendCoverageCount
variable (F : Fam)

theorem force (t : StI F.V) (gp : Nat×Nat) : state (F.forceRups t gp)=state t+4 := by
  obtain ⟨g,p⟩:=gp
  by_cases h:p=0 <;> simp [Fam.forceRups,h,List.foldl_cons,List.foldl_nil,rup_cost]

theorem stage4 (t : StI F.V) : state (F.stage4 t)≤state t+8*F.s := by
  have h:=fold_cost state F.forceRups
    ((List.range' 1 (F.s-1)).flatMap fun g=>[(g,0),(g,1)]) t 4
    (fun u gp=>(force F u gp).le)
  have hl:((List.range' 1 (F.s-1)).flatMap fun g=>[(g,0),(g,1)]).length=2*(F.s-1) := by
    simp [List.length_flatMap,Nat.mul_comm]
  rw [hl] at h
  exact h.trans (by omega)

theorem out_split (t : StI F.V) (p : Nat×Nat) : state (F.outSplit t p)=state t+7 := by
  have h:=split_cost t [-(F.sel (F.s-1) p.1 0:Int),-(t.s.eqrow (F.s-1) p.1 p.2:Int)]
    [(F.port (F.s-1) (1-p.1) (F.outX p.2):Int),(F.port (F.s-1) (1-p.1) (F.outY p.2):Int)]
  change state (F.outSplit t p)+1=state t+8 at h
  omega

theorem out_rup (t : StI F.V) (p : Nat) : state (F.outRup t p)=state t+2 := by
  simp only [Fam.outRup,rup_cost]

theorem stage6 (t : StI F.V) : state (F.stage6 t)=state t+33 := by
  simp only [Fam.stage6,List.flatMap_cons,List.flatMap_nil,List.cons_append,List.nil_append,
    List.foldl_cons,List.foldl_nil,out_split,out_rup,rup_cost]

def potential (t : StI F.V×List Int) := state t.1+t.2.length

theorem branch (b : Nat) (acc : StI F.V×List Int) (g : Nat) :
    potential F (F.branchStep b acc g)≤potential F acc+7 := by
  let u:=acc.1.OR [(acc.1.s.edges b g 0:Int),(acc.1.s.edges b g 1:Int)]
  have ho:=or_cost acc.1 [(acc.1.s.edges b g 0:Int),(acc.1.s.edges b g 1:Int)]
  have ha:=and_cost u.2 [(u.2.s.eligible b:Int),(u.1:Int)]
  change state (u.2.AND [(u.2.s.eligible b:Int),(u.1:Int)]).2+(acc.2++[_]).length≤_
  change state u.2≤state acc.1+2+1 at ho
  simp only [List.length_cons,List.length_nil] at ha
  simp only [List.length_append,List.length_cons,List.length_nil,potential]
  omega

theorem branch_group (acc : StI F.V×List Int) (b : Nat) :
    potential F (F.bStep acc b)≤potential F acc+7*F.s := by
  have h:=fold_cost (potential F) (F.branchStep b) (List.range' (b+1) (F.s-1-b)) acc 7 (branch F b)
  simp only [List.length_range'] at h
  exact h.trans (by omega)

theorem stage7 (t : StI F.V) : state (F.stage7 t)≤state t+7*F.s^2+F.s+2 := by
  let u:=(List.range' 1 (F.s-2)).foldl F.bStep (t,[])
  have h:=fold_cost (potential F) F.bStep (List.range' 1 (F.s-2)) (t,[]) (7*F.s) (branch_group F)
  change state u.1+u.2.length≤state t+0+(List.range' 1 (F.s-2)).length*(7*F.s) at h
  simp only [List.length_range'] at h
  have hh:(F.s-2)*(7*F.s)≤F.s*(7*F.s):=Nat.mul_le_mul_right _ (Nat.sub_le ..)
  have ho:=or_cost u.1 u.2
  let v:=(u.1.OR u.2).2.setB (u.1.OR u.2).1
  have hv:state v=state (u.1.OR u.2).2:=rfl
  have hr:=fold_cost state F.bRup (List.range' 1 (F.s-2)) v 1 (by
    intro w b;exact (rup_cost w [(w.s.Bv:Int),-(w.s.eligible b:Int)]).le)
  change state (((List.range' 1 (F.s-2)).foldl F.bRup v).rup _)≤_
  rw [rup_cost]
  simp only [List.length_range',mul_one] at hr
  have hs:F.s-2≤F.s:=Nat.sub_le ..
  nlinarith

theorem state_frontend (k s : Nat) (hs : 1≤s) :
    state ((FableEncoding.fam k s).frontendX hs)≤32*s^2+16*s*k+210*s+64 := by
  let F:=FableEncoding.fam k s
  let u:=F.t3 hs
  have h0:=ConstructionFrontendDefinitionCount.definition_prefix k s hs
  rw [RecordedFrontendDefs.stage3,definitions] at h0
  change state u≤8*s^2+37*s+4 at h0
  have h4:=stage4 F u
  have h5:=ConstructionFrontendCoverageCount.stage5 F (F.V_pos hs) (F.stage4 u)
  have h6:=stage6 F (F.stage5 (F.V_pos hs) (F.stage4 u))
  have h7:=stage7 F (F.stage6 (F.stage5 (F.V_pos hs) (F.stage4 u)))
  change state (F.stage7 (F.stage6 (F.stage5 (F.V_pos hs) (F.stage4 u))))≤_
  change state (F.stage4 u)≤state u+8*s at h4
  change state (F.stage5 (F.V_pos hs) (F.stage4 u))≤state (F.stage4 u)+2*s*(8*(k+s)+80)+18 at h5
  change state (F.stage7 (F.stage6 (F.stage5 (F.V_pos hs) (F.stage4 u))))≤
    state (F.stage6 (F.stage5 (F.V_pos hs) (F.stage4 u)))+7*s^2+s+2 at h7
  nlinarith

theorem exec_length (D : List EREF.Row) (cs : List Cmd) :
    (exec D cs).length=D.length+list cs := by
  induction cs generalizing D with
  | nil => rfl
  | cons c cs ih =>
    rw [exec,ih]
    cases c <;> simp [List.length_append,Cmd.rows,Defs.rows,orDefs,andDefs,eqDefs,
      list,ConstructionFrontendCountTools.command,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm]

theorem recorded_length (k s : Nat) (hk : 2≤k) (hs : 2≤s) :
    (RecordedFrontendComplete.program k s (by omega)).length=
      2*k+state ((FableEncoding.fam k s).frontendX (by change 1≤s;omega)) := by
  let F:=FableEncoding.fam k s
  let t:=F.frontendX (by change 1≤s;omega)
  have h:=RecordedFrontendComplete.accepts k s (t.s.var+1) hk hs (by change t.s.var<t.s.var+1;omega)
  have hl:=CanonicalPrefixEnvelope.checked_length 0 (t.s.var+1) _ _ _ h
  rw [exec_length,FableIntegration.final_rows_eq k s (by omega),
    NormalizedCofactorBytes.normalized_length k s hk] at hl
  change (OriginalEncoding.rows k s).length+2*k+state t=
    (OriginalEncoding.rows k s).length+(RecordedFrontendComplete.program k s _).length at hl
  change (RecordedFrontendComplete.program k s _).length=2*k+state t
  omega

/-- Actual complete frontend, including normalization, coverage, output and
branch selection. Unit: MAIN COMMANDS (not proof bytes). -/
theorem recorded (k s : Nat) (hk : 2≤k) (hs : 2≤s) :
    (RecordedFrontendComplete.program k s (by omega)).length≤
      2*k+32*s^2+16*s*k+210*s+64 := by
  rw [recorded_length k s hk hs]
  have h:=state_frontend k s (by omega)
  omega

theorem parity (k : Nat) (hk : 2≤k) :
    (RecordedFrontendComplete.program k (3*k-4) (by omega)).length≤800*(k+1)^2 := by
  have h:=recorded k (3*k-4) hk (by omega)
  have hs:3*k-4≤3*k:=Nat.sub_le ..
  have hp:=Nat.mul_le_mul hs hs
  have hm:=Nat.mul_le_mul_right k hs
  nlinarith

#print axioms recorded_length
#print axioms recorded
#print axioms parity
end L3Emitter.ConstructionFrontendCount

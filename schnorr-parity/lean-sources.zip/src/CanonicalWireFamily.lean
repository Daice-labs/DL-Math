import CanonicalScopeKernel

namespace L3Emitter.CanonicalWireFamily
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace CanonicalScopeKernel

def keyDoc : GoalKey→Doc
  | .candidate=>fixed "#1"
  | .database i=>number i

def goalDoc (g : Goal) := fixed "proofgoal " ++ keyDoc g.key ++ fixed "\n" ++
  CanonicalScopedBytes.tapesDoc g.proof.tapes ++ CanonicalScopedBytes.closeDoc g.proof.conclusion

def commandDoc : CanonicalScopeKernel.Command→Doc
  | .pol ts=>CompactTapeBytes.line ts
  | .consequence R p=>fixed "pbc " ++ CanonicalScopedBytes.rowDoc R ++ fixed " : subproof\n" ++
    CanonicalScopedBytes.tapesDoc p.tapes ++ CanonicalScopedBytes.closeDoc p.conclusion
  | .red R w gs=>fixed "red " ++ CanonicalScopedBytes.rowDoc R ++ fixed " : " ++ witness w ++
    fixed " : subproof\n" ++ gs.flatMap goalDoc ++ fixed "qed ;\n"

theorem key_doc (ids : Nat→Nat) (i : Nat) : keyDoc (keyAt ids i)=CanonicalScopedBytes.goalKey ids i := by
  unfold keyAt CanonicalScopedBytes.goalKey
  split <;> rfl

theorem goals_doc (ids : Nat→Nat) (i : Nat) (bs : List (EREF.Row×NativeScopedLocalGoal.Built)) :
    (packGoals ids i bs).flatMap goalDoc=CanonicalScopedBytes.goalsDoc ids i bs := by
  induction bs generalizing i with
  | nil=>rfl
  | cons b bs ih=>
    simp only [packGoals,List.flatMap_cons,goalDoc,key_doc,CanonicalScopedBytes.goalsDoc,
      CanonicalScopedBytes.goalDoc,stripLocal,ih]

theorem command_doc (ids : Nat→Nat) (a : NativeRecordedStep.Action) :
    commandDoc (pack ids a)=CanonicalScopedBytes.actionDoc ids a := by
  cases a with
  | pol ts=>rfl
  | consequence R b=>rfl
  | red R w bs=>simp only [pack,commandDoc,goals_doc,CanonicalScopedBytes.actionDoc]

theorem compiled_doc (D : List EREF.Row) (s : Store) (ids : Nat→Nat) (p : Program) :
    (CanonicalScopeKernel.compile D s ids p).flatMap commandDoc=CanonicalScopedBytes.body D s ids p := by
  induction p generalizing D s ids with
  | nil=>rfl
  | cons c cs ih=>simp only [CanonicalScopeKernel.compile,List.flatMap_cons,command_doc,
      CanonicalScopedBytes.body,ih]

def commands (n : Nat) := CanonicalScopeKernel.compile (NativeRecordedFamily.original n)
  (initial (NativeRecordedFamily.original n)) id (RecordedUniformFamily.emitter n)
def document (n : Nat) := CanonicalScopedBytes.header (NativeRecordedFamily.original n).length ++
  (commands n).flatMap commandDoc ++ CanonicalScopedBytes.footer (NativeRecordedFamily.conclusion n)

/-- Same bytes from the minimal wire command datatype and the audited full
projection: no cached checked stores or expected local output rows are emitted. -/
theorem document_eq (n : Nat) : document n=CanonicalScopedBytes.familyDoc n := by
  simp only [document,commands,compiled_doc,CanonicalScopedBytes.familyDoc,CanonicalScopedBytes.proof]

theorem bytes_eq (n : Nat) : emit (document n)=CanonicalScopedBytes.familyBytes n :=
  congrArg emit (document_eq n)

/-- All-arity execution in the formal strict fragment. Native parser and
arithmetic correspondence, and a closed size bound, are separate obligations. -/
theorem family_execution (n : Nat) (hn : 2≤n) :
    CanonicalScopeKernel.run (NativeRecordedFamily.original n)
      (initial (NativeRecordedFamily.original n)) id (commands n)=some (NativeRecordedFamily.compiled n).store ∧
    read (NativeRecordedFamily.compiled n).store (NativeRecordedFamily.conclusion n:Int)=
      some (REDWitness.clause []) := by
  have hp:=RecordedUniformFamily.recorded_refutation n hn
  have h:=CanonicalScopeKernel.correct 0 (RecordedUniformFamily.guard n)
    (NativeRecordedFamily.original n) (RecordedUniformFamily.finalRows n)
    (initial (NativeRecordedFamily.original n)) id (RecordedUniformFamily.emitter n)
    (by change 0<_+1;omega) (initial_embeds _) hp.1
  exact ⟨h,(NativeRecordedFamily.physical_refutation n hn).2⟩

#print axioms key_doc
#print axioms goals_doc
#print axioms command_doc
#print axioms compiled_doc
#print axioms document_eq
#print axioms bytes_eq
#print axioms family_execution
end L3Emitter.CanonicalWireFamily

import FinalEvaluationContext
import GuardedTwoPortPOL
namespace L3Emitter.FinalKeptEvaluation
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions FinalEvaluationContext
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def port (n:Nat) (hn:2≤n) (x:Fin (T n)) (p:Fin 2):=(built n hn).1.ports p x
def rawPort (n:Nat) (hn:2≤n) (x:Fin (T n)) (p:Fin 2):=LowerTransferImage.wire n hn (.port (lastRank n) p.val x.val)
def row (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):=
  clause [-(H n hn).val,-sign side (OutputPhaseRows.phase n hn),-sign a (port n hn x 0),-sign b (port n hn x 1),qlit n hn x a b]

theorem recorded_kept (n:Nat) (hn:2≤n):∀R∈FinalOutputRecorded.result n hn,R∈D n hn:=by
  intro R h
  apply FinalU2Image.retained
  apply List.mem_append_left
  apply List.mem_append_left
  apply FinalTransferBank.retained
  exact FinalTransferContext.recorded_kept n hn R h

theorem port_link (n:Nat) (hn:2≤n) (x:Fin (T n)) (p:Fin 2) (a:Bool):
    clause [-(H n hn).val,-(-sign a (rawPort n hn x p)),-sign a (port n hn x p)]∈D n hn:=by
  have h:=FinalPortSlots.rows n hn p x
  have hh:=RawUnaryTransport.raw_polarity (D n hn) (H n hn) (port n hn x p) (rawPort n hn x p) (!a)
    ⟨recorded_kept n hn _ h.2.1,recorded_kept n hn _ h.1⟩
  simpa only [LowerPortEvaluation.sign_not,neg_neg] using hh

def coreRows (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):=
  GateUnaryCompositionPOL.rows (G n hn side) (P n hn x a b) (output n hn x) (FinalU2Bank.f n hn a b) (qlit n hn x a b)
def coreProgram (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row):=
  GateUnaryCompositionPOL.program E (G n hn side) (P n hn x a b) (output n hn x) (FinalU2Bank.f n hn a b) (u n hn x side) (qlit n hn x a b)
def transportTape (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row):=
  GuardedTwoPortPOL.tape E (-(H n hn).val) (-sign side (OutputPhaseRows.phase n hn))
    (-sign a (rawPort n hn x 0)) (-sign b (rawPort n hn x 1)) (-sign a (port n hn x 0)) (-sign b (port n hn x 1)) (qlit n hn x a b)
def rows (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):=coreRows n hn x a b side++[row n hn x a b side]
def program (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row):=
  coreProgram n hn x a b side E++[(row n hn x a b side,transportTape n hn x a b side (E++coreRows n hn x a b side))]
theorem checks (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row) (he:∀R∈D n hn,R∈E):
    check E (program n hn x a b side E)=some (E++rows n hn x a b side):=by
  have h0:=GateUnaryCompositionPOL.checks E (G n hn side) (P n hn x a b) (output n hn x) (FinalU2Bank.f n hn a b) (u n hn x side) (qlit n hn x a b)
    (by simp [G,Valid,sign_valid,(H n hn).property]) (by simp [P,Valid,sign_valid]) (fun r=>sign_valid _ _) (sign_valid _ _)
    (fun r=>he _ (phase_row n hn x side r)) (fun r=>he _ (function_row n hn x a b side r)) (fun r=>he _ (gate_row n hn x a b r))
  let E1:=E++coreRows n hn x a b side
  have hs:GuardedTwoPortPOL.source (-(H n hn).val) (-sign side (OutputPhaseRows.phase n hn))
      (-sign a (rawPort n hn x 0)) (-sign b (rawPort n hn x 1)) (qlit n hn x a b)∈E1:=by
    apply List.mem_append_right
    simp [coreRows,GateUnaryCompositionPOL.rows,GateUnaryCompositionPOL.finalRow,G,P,rawPort,GuardedTwoPortPOL.source]
  have h1:=GuardedTwoPortPOL.checks E1 (-(H n hn).val) (-sign side (OutputPhaseRows.phase n hn))
    (-sign a (rawPort n hn x 0)) (-sign b (rawPort n hn x 1)) (-sign a (port n hn x 0)) (-sign b (port n hn x 1)) (qlit n hn x a b)
    (neg_ne_zero.mpr (H n hn).property) (neg_ne_zero.mpr (sign_valid _ _)) (neg_ne_zero.mpr (sign_valid _ _))
    (neg_ne_zero.mpr (sign_valid _ _)) (neg_ne_zero.mpr (sign_valid _ _)) (neg_ne_zero.mpr (sign_valid _ _)) (sign_valid _ _) hs
    (List.mem_append_left _ (he _ (port_link n hn x 0 a))) (List.mem_append_left _ (he _ (port_link n hn x 1 b)))
  have h2:check E1 [(row n hn x a b side,transportTape n hn x a b side E1)]=some (E1++[row n hn x a b side]):=by
    simp only [check,transportTape,h1,GuardedTwoPortPOL.target,row,↓reduceIte]
  simpa only [program,rows,coreProgram,E1,List.append_assoc] using check_append _ _ _ _ _ h0 h2
#print axioms checks
end L3Emitter.FinalKeptEvaluation

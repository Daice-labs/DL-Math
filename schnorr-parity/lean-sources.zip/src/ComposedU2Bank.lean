import U2ComposedPOL
namespace L3Emitter.ComposedU2Bank
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL AliasProgram U2SourcePOL

def base (n:Nat) (hn:2≤n):=LowerSelectorALO.result n hn
def table (n:Nat) (hn:2≤n) (g:Nat):Table:=RankTableBank.table n hn g
def unary (n:Nat) (hn:2≤n) (g p:Nat):Bool→Bit:=ComposedTableBank.unary n hn g p

theorem original_eq (n g:Nat) (phase:Bool):
    original (ComposedTableBank.originalFunction n g) phase=
    (InputSwap.forbidden g (if phase then 6 else 9)).row (n+1) (3*(n+1)-4):=by
  cases phase <;> simp [original,literals,identity,ComposedTableBank.originalFunction,AliasAssembly.functionBit,
    InputSwap.forbidden,FamilyRows.Spec.row,FamilyRows.lit,sign,clause,List.range_succ] <;> rfl

theorem original_mem (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4) (phase:Bool):
    original (ComposedTableBank.originalFunction n g) phase∈base n hn:=by
  rw [original_eq]
  apply SelectorBank.trace_retains (LowerSelectorALO.original_to_selector_ALO n hn)
  apply List.mem_map.mpr
  refine ⟨InputSwap.forbidden g (if phase then 6 else 9),?_,rfl⟩
  apply (OriginalEncoding.spec_mem_iff _ _ (by omega) _).mpr
  exact InputSwap.Original.forbidden _ _ hg (by cases phase <;> simp)

theorem composed_retained (n:Nat) (hn:2≤n):∀R∈ComposedTableBank.result n hn,R∈base n hn:=by
  intro R hr
  exact TableLookupBinding.retained n hn R (RankTableBank.run_retains n hn _ _ R hr)

theorem lookup_rows (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (a b:Unary) (x y v:Bool):
    clause (U2LookupLink.short (ComposedTableBank.originalFunction n g) (unary n hn g 0) (unary n hn g 1) a b (table n hn g) x y v)∈base n hn:=by
  obtain ⟨r,hr,he,ht⟩:=RankTableBank.table_record n hn g hg hs x y
  have h:=ComposedTableBank.evaluation_rows n hn r hr (a x) (b y) v
  rw [he] at h
  apply composed_retained n hn
  simpa only [U2LookupLink.short,LookupEvaluation.guards,guarded,table,ht,unary] using h

abbrev Job:=Nat×Bool
def jobs (n:Nat):List Job:=(CategoryBank.gates n).flatMap fun g=>[(g,false),(g,true)]
def leaf (n:Nat) (hn:2≤n) (j:Job) (D:List Row):=
  U2ComposedPOL.program D (ComposedTableBank.originalFunction n j.1) (unary n hn j.1 0) (unary n hn j.1 1) (table n hn j.1) j.2
def rows (n:Nat) (hn:2≤n) (j:Job):=
  U2ComposedPOL.rows (ComposedTableBank.originalFunction n j.1) (unary n hn j.1 0) (unary n hn j.1 1) (table n hn j.1) j.2

theorem job_mem (n:Nat) (j:Job):j∈jobs n↔0<j.1 ∧ j.1<3*(n+1)-4:=by
  obtain ⟨g,v⟩:=j;cases v <;> simp [jobs,CategoryBank.gate_mem]
theorem leaf_check (n:Nat) (hn:2≤n) (j:Job) (hj:0<j.1 ∧ j.1<3*(n+1)-4)
    (D:List Row) (hd:∀R∈base n hn,R∈D):check D (leaf n hn j D)=some (D++rows n hn j):=
  U2ComposedPOL.checks D _ _ _ _ _ (fun v=>hd _ (original_mem n hn j.1 hj.2 v))
    (fun a b x y v=>hd _ (lookup_rows n hn j.1 hj.1 hj.2 a b x y v))

def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n) (base n hn)
def result (n:Nat) (hn:2≤n):=base n hn++RetainedBlockFold.body (rows n hn) (jobs n)
theorem checks (n:Nat) (hn:2≤n):check (base n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (fun j:Job=>0<j.1 ∧ j.1<3*(n+1)-4) (leaf_check n hn) _
    (fun j hj=>(job_mem n j).mp hj) _ (fun _ h=>h)
theorem original_to_composed_U2 (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (LowerSelectorALO.original_to_selector_ALO n hn) (check_trace _ _ _ (checks n hn))
theorem all_rows (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (phase:Bool):
    original (table n hn g) phase∈result n hn:=
  List.mem_append_right _ (RetainedBlockFold.contains _ _ (g,phase) ((job_mem n _).mpr ⟨hg,hs⟩) _
    (U2ComposedPOL.final_mem _ _ _ _ _))
#print axioms original_to_composed_U2
#print axioms all_rows
end L3Emitter.ComposedU2Bank

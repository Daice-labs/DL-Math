import L3BitCoverage

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def BitRecord (bit cb : Nat) (t : StI F.V) : Prop :=
  Cmd.eqDef cb (F.fn 0 bit : Int) (F.fn 0 (bit+2) : Int)∈t.s.cmds ∧
  Cmd.rup (F.bitRoot t cb)∈t.s.cmds ∧ 1≤cb ∧ cb≤t.s.var

theorem BitRecord_keeps {t u : StI F.V} (hk : Keeps2 t u) (bit cb : Nat)
    (hr : F.BitRecord bit cb t) : F.BitRecord bit cb u := by
  refine ⟨mem_of_grows hk.1 hr.1,?_,hr.2.2.1,Nat.le_trans hr.2.2.2 (var_le_of_grows hk.1)⟩
  have he : F.bitRoot u cb=F.bitRoot t cb := by simp only [bitRoot,hk.2.2.2.2.2.2]
  rw [he]; exact mem_of_grows hk.1 hr.2.1

theorem bitStep_record (hk : 2≤F.k) (hs : 2≤F.s) (hm : 1≤F.V)
    (t : StI F.V) (C : List Int) (ht : F.Good3 t) (bit : Nat) (hb : bit<2) :
    F.BitRecord bit (t.s.var+1) (F.bitStep hm (t,C) bit).1 := by
  let u := F.cbStart hm bit t
  let cb := t.s.var+1
  have ku : Keeps2 t u := keeps2_EQ _ hm _ _
  have hu := F.Good3_of_keeps2 ku ht
  have hc : 1≤cb ∧ cb≤u.s.var := by change 1≤t.s.var+1 ∧ t.s.var+1≤t.s.var+1; omega
  let v := (List.range F.s).foldl (F.veqStep hm bit cb) u
  have kv : Keeps2 u v := keeps2_foldl _ _ (F.keeps2_veqStep hm bit cb) u
  have hv := F.Good3_of_keeps2 kv hu
  have hcv : 1≤cb ∧ cb≤v.s.var := ⟨hc.1,Nat.le_trans hc.2 (var_le_of_grows kv.1)⟩
  change F.BitRecord bit cb (v.rup (F.bitRoot v cb))
  refine ⟨?_,?_,hc.1,hcv.2⟩
  · exact mem_of_grows (keeps2_rup v _).1
      (mem_of_grows kv.1 (F.cbStart_info (by omega) hm bit hb t))
  · change Cmd.rup (F.bitRoot v cb)∈(v.rup (F.bitRoot v cb)).s.cmds
    rw [StI.cmds_rup,StI.chk_eq v _ (F.bitRoot_bound v hv cb hcv)]
    simp

theorem cb_forbidden_mem (hs : 1≤F.s) (a b : Bool) : (F.row2 0 (cbCode a b)).toE∈F.db5 := by
  cases a <;> cases b
  · change (F.row2 0 3).toE∈F.db4 ++ [(F.row2 0 12).toE]
    exact List.mem_append_left _ (List.mem_append_right _ (by simp))
  · exact F.row2_mem_db5 hs 0 6 hs (Or.inl rfl)
  · exact F.row2_mem_db5 hs 0 9 hs (Or.inr rfl)
  · exact List.mem_append_right _ (by simp [cbCode])

theorem cbSplit_obls (hk : 2≤F.k) (hs : 1≤F.s) (t : StI F.V) (c0 c1 : Nat)
    (r0 : F.BitRecord 0 c0 t) (r1 : F.BitRecord 1 c1 t) :
    ObligationsChecked (exec F.db5 t.s.cmds)
      (splitCmds [(c0 : Int),(c1 : Int)] [(F.fn 0 0 : Int),(F.fn 0 1 : Int)]) := by
  have hDB := exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded (by omega) hs) t.inv.1
  rw [t.inv.2] at hDB
  have hc : Bounded t.s.var [(c0 : Int),(c1 : Int)] := by
    intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> have := r0.2.2 <;> have := r1.2.2 <;> omega
  have hv : Bounded t.s.var [(F.fn 0 0 : Int),(F.fn 0 1 : Int)] := by
    have h0 := F.fn_pos 0 0
    have h1 := F.fn_pos 0 1
    have hl0 := F.fn_le 0 0 hs (by decide)
    have hl1 := F.fn_le 0 1 hs (by decide)
    have hV := t.var_ge
    have hS := F.S4_le_V
    intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> omega
  apply split_obls _ t.s.var hDB _ _ hc hv
  intro D hm hD lf hlf
  have e0 := eqDef_rows F.db5 t.s.cmds _ _ _ r0.1
  have e1 := eqDef_rows F.db5 t.s.cmds _ _ _ r1.1
  have hleaf : ∀a b,Refutation (D ++ [negate (clauseRow (F.cbLeaf c0 c1 a b)).toE]) := by
    intro a b
    apply F.cb_leaf D hD c0 c1 r0.2.2.1 r1.2.2.1 a b
    · cases a
      · exact hm _ e0.1
      · exact hm _ e0.2.2.2
    · cases b
      · exact hm _ e1.1
      · exact hm _ e1.2.2.2
    · exact hm _ (exec_mono _ _ _ (F.cb_forbidden_mem hs a b))
  simp only [leaves,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hlf
  rcases hlf with (rfl | rfl) | (rfl | rfl)
  · exact hleaf false false
  · exact hleaf false true
  · exact hleaf true false
  · exact hleaf true true

#print axioms bitStep_record
#print axioms cbSplit_obls
end L3.Fam

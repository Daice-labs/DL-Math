import ConstructionLocalTools
import RecordedNetwork
import RecordedSupportSelection
import RecordedGuardBank

namespace L3Emitter.ConstructionFreshBounds
open EREF EREF.GeneralRED RecordedScopedTrace CanonicalReplayEnvelope
open ConstructionLocalTools

theorem definitions (D : List Row) (q : Nat) (defs : L3.Defs) :
    BoundedProgram 3 (RecordedDefinitions.emit D q defs) := gateProgram D q [] _

theorem networkGate (D : List Row) (g : AliasNetwork.Gate) :
    BoundedProgram 3 (RecordedNetwork.gateProgram D g) := gateProgram D g.q [] _

theorem network (D : List Row) (gs : List AliasNetwork.Gate) :
    BoundedProgram 3 (RecordedNetwork.program D gs) := by
  induction gs generalizing D with
  | nil=>simp [RecordedNetwork.program,BoundedProgram]
  | cons g gs ih=>exact append 3 _ _ (networkGate D g) (ih (D++g.rows))

theorem selectionGate (D : List Row) (m : Nat) (b : Bool) (xs : List Int) :
    BoundedProgram 3 (RecordedSupportSelection.gate D m b xs) := gateProgram D (m+1) [] _

theorem selectionAnds (D : List Row) (m : Nat) (f : Int→Int) (xs : List Int) :
    BoundedProgram 3 (RecordedSupportSelection.ands D m f xs) := by
  induction xs generalizing D m with
  | nil=>simp [RecordedSupportSelection.ands,BoundedProgram]
  | cons x xs ih=>exact append 3 _ _ (selectionGate D m true _) (ih _ _)

theorem selectionDefs (D : List Row) (m : Nat) (xs : List Int) (f : Int→Int) :
    BoundedProgram 3 (RecordedSupportSelection.definitions D m xs f) :=
  append 3 _ _ (selectionAnds D m f xs) (selectionGate _ _ false _)

theorem selection (D : List Row) (m : Nat) (xs : List Int) (f : Int→Int) :
    BoundedProgram 3 (RecordedSupportSelection.program D m xs f) :=
  append 3 _ _ (selectionDefs D m xs f) (polProgram 3 _)

theorem guardStep (D : List Row) (G : Row) (q : Nat) :
    BoundedGoals 3 (AuditLocalCosts.certificates (RecordedGuardBank.step D G q)) :=
  redMap _ _ _ _ _ (by intros;exact gateGoal ..)

theorem guardBank (D inputs : List Row) (a : Row→Nat) (q : Nat) :
    BoundedProgram 3 (RecordedGuardBank.program D a q inputs) := by
  induction inputs generalizing D with
  | nil=>simp [RecordedGuardBank.program,BoundedProgram]
  | cons R rs ih=>
    intro c hc
    rcases List.mem_cons.mp hc with rfl|hc
    · exact guardStep D _ q
    · exact ih _ c hc

/-- Main RED commands, distinct from the nested certificates per command. -/
theorem selectionGate_length (D : List Row) (m : Nat) (b : Bool) (xs : List Int) :
    (RecordedSupportSelection.gate D m b xs).length=xs.length+1 := by
  unfold RecordedSupportSelection.gate
  rw [RecordedGate.length]
  cases b <;> simp [REDWitness.andGate,REDWitness.orGate]

theorem selectionAnds_length (D : List Row) (m : Nat) (f : Int→Int) (xs : List Int) :
    (RecordedSupportSelection.ands D m f xs).length=3*xs.length := by
  induction xs generalizing D m with
  | nil=>rfl
  | cons x xs ih=>simp only [RecordedSupportSelection.ands,List.length_append,
      selectionGate_length,List.length_cons,List.length_nil,ih];omega

theorem selectionDefs_length (D : List Row) (m : Nat) (xs : List Int) (f : Int→Int) :
    (RecordedSupportSelection.definitions D m xs f).length=4*xs.length+1 := by
  simp only [RecordedSupportSelection.definitions,List.length_append,
    selectionAnds_length,selectionGate_length]
  have h : (SelectedValue.cells m f xs).length=xs.length := by
    induction xs generalizing m with
    | nil=>rfl
    | cons x xs ih=>simp [SelectedValue.cells,ih]
  simp only [SelectedValue.terms,List.length_map,h]
  omega

#print axioms network
#print axioms selection
#print axioms guardBank
#print axioms selectionDefs_length
end L3Emitter.ConstructionFreshBounds

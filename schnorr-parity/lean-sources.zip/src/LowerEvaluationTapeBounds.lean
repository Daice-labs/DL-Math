import ConstructionLowerEvaluationCount
import MainTapeRecurrence
namespace L3Emitter.LowerEvaluationTapeBounds
open EREF EREF.GeneralRED AliasProgram U2ConstructionSize ConstructionLowerBasicCount

theorem map_tokens {α : Type} (js : List α) (row : α→Row) (tape : α→List Tok) (K : Nat)
    (h : ∀j∈js,(tape j).length≤K) :
    tokens (js.map (fun j=>(row j,tape j)))≤js.length*K := by
  induction js with
  | nil => simp [tokens]
  | cons j js ih =>
    have hh:=h j (by simp)
    have ht:=ih (fun i hi=>h i (by simp [hi]))
    simp only [tokens,List.map_cons,List.sum_cons,List.length_cons] at *
    nlinarith

theorem composed (n : Nat) (hn : 2≤n) : tokens (ComposedU2Bank.program n hn)≤6504*(n+1) := by
  have h:=fold_tokens (ComposedU2Bank.leaf n hn) (ComposedU2Bank.rows n hn)
    (ComposedU2Bank.jobs n) (ComposedU2Bank.base n hn) 1084
    (by intro j hj D;exact composed_tokens ..)
  change tokens (ComposedU2Bank.program n hn)≤_ at h
  have hj:(ComposedU2Bank.jobs n).length=(3*(n+1)-5)*2:=by
    unfold ComposedU2Bank.jobs
    rw [ConstructionRelationCount.flat_exact _ _ 2 (by intros;rfl),ConstructionRelationCount.gates]
  rw [hj] at h;omega

theorem u2_leaf (n : Nat) (hn : 2≤n) (t : Nat) (phase : Bool) (D : List Row) :
    tokens (RankU2Transport.program n hn t phase D)=36*(3*(n+1)-5)+2 := by
  have hcase:tokens (RankU2Transport.casesProgram n hn t phase D)=34*(RankZeroTransport.gates n).length:=by
    unfold RankU2Transport.casesProgram tokens
    have ht:∀G,(RankU2Transport.tape n hn t phase G D).length=34:=by
      intro G;rw [RankU2Transport.tape,clause_map_count];rfl
    simp only [List.map_map,Function.comp_def,ht,List.map_const',List.sum_replicate,smul_eq_mul]
    omega
  simp only [RankU2Transport.program,tokens_append,hcase]
  simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
    ProjectionTrace.joinCaseTokens,CaseJoin.join_token_count,List.length_map,
    RankZeroTransport.gates,List.length_range]
  omega

theorem u2 (n : Nat) (hn : 2≤n) : tokens (LowerU2Bank.program n hn)≤660*(n+1)^2 := by
  have h:=fold_tokens (LowerU2Bank.leaf n hn) (LowerU2Bank.rows n hn)
    (LowerU2Bank.jobs n) (ComposedU2Bank.result n hn) (110*(n+1)) (by
      intro j hj D
      unfold LowerU2Bank.leaf
      rw [u2_leaf];omega)
  change tokens (LowerU2Bank.program n hn)≤_ at h
  have hj:(LowerU2Bank.jobs n).length=2*RankConstruction.width (n+1):=by
    simp [LowerU2Bank.jobs,List.length_flatMap];ring
  rw [hj] at h
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 2 (width n))).trans_eq (by ring))

theorem port_leaf (n : Nat) (hn : 2≤n) (r : RawLowerInputBank.Record n)
    (G x : Nat) (b v : Bool) (D : List Row) :
    (LowerPortEvaluation.tape n hn r G x b v D).length=20 := by
  simp [LowerPortEvaluation.tape,LowerPortEvaluation.links,LowerPortEvaluation.mapped,
    ClauseTransport.tokens,ClauseTransport.linkSteps,ClauseTransport.Link.tokens,
    ClauseTransport.padding,ClauseTransport.padSteps]

theorem ports (n : Nat) (hn : 2≤n) : tokens (LowerPortEvalBank.program n hn)≤1440*(n+1)^2*2^n := by
  have he:tokens (LowerPortEvalBank.program n hn)=20*(LowerPortEvalBank.program n hn).length:=by
    simp [LowerPortEvalBank.program,tokens,port_leaf,List.map_map,Function.comp_def,
      List.map_const',List.sum_replicate,Nat.mul_comm]
  rw [he]
  exact (Nat.mul_le_mul_left 20 (ConstructionLowerEvaluationCount.ports n hn)).trans_eq (by ring)

theorem evaluation (n : Nat) (hn : 2≤n) : tokens (LowerGateBank.program n hn)≤8976*(n+1)^2*2^n := by
  have h:=GateEvaluationSize.bank_tokens n hn
  change _≤RankConstruction.width (n+1)*2^n*8*(124*(3*(n+1)-5)+2) at h
  have hm:=Nat.mul_le_mul (Nat.mul_le_mul_right 8 (Nat.mul_le_mul_right (2^n) (width n)))
    (show 124*(3*(n+1)-5)+2≤374*(n+1) by omega)
  exact h.trans (hm.trans_eq (by ring))

theorem phase_leaf (n : Nat) (hn : 2≤n) (x : Nat) (i : Fin (AliasAssembly.width (n+1)))
    (b side : Bool) (D : List Row) : (OutputPhaseRows.tape n hn x i b side D).length=12 := by
  simp [OutputPhaseRows.tape,CommonGuardResolve.token_count,OutputPhaseRows.guards]

theorem phase (n : Nat) (hn : 2≤n) : tokens (OutputPhaseBank.program n hn)≤192*(n+1)*2^n := by
  have he:tokens (OutputPhaseBank.program n hn)=12*(OutputPhaseBank.program n hn).length:=by
    simp [OutputPhaseBank.program,tokens,phase_leaf,List.map_map,Function.comp_def,
      List.map_const',List.sum_replicate,Nat.mul_comm]
  rw [he]
  exact (Nat.mul_le_mul_left 12 (ConstructionLowerEvaluationCount.phase n hn)).trans_eq (by ring)

/-- Main POL tokens in the U2, port, gate-evaluation and output-phase banks;
selector/topology banks are deliberately not included. -/
theorem combined (n : Nat) (hn : 2≤n) :
    tokens (ComposedU2Bank.program n hn)+tokens (LowerU2Bank.program n hn)+
    tokens (LowerPortEvalBank.program n hn)+tokens (LowerGateBank.program n hn)+
    tokens (OutputPhaseBank.program n hn)≤18000*(n+1)^2*2^n := by
  have h0:=composed n hn;have h1:=u2 n hn;have h2:=ports n hn
  have h3:=evaluation n hn;have h4:=phase n hn
  have hp:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have hn2:n+1≤(n+1)^2:=by nlinarith
  have a:=Nat.mul_le_mul_right (2^n) (Nat.mul_le_mul_left 192 hn2)
  have b:=Nat.mul_le_mul_right (2^n) (Nat.mul_le_mul_left 6504 hn2)
  have c:=Nat.mul_le_mul_left (6504*(n+1)) hp
  have d:=Nat.mul_le_mul_left (660*(n+1)^2) hp
  nlinarith
#print axioms combined
end L3Emitter.LowerEvaluationTapeBounds

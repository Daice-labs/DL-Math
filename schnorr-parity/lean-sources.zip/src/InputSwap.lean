import FamilyRows
import TruthTranspose

namespace L3Emitter.InputSwap
open FamilyNamespace FamilyRows TruthTranspose

def truthSwap (k a b x : Nat) : Nat :=
  (msbTranspose (BitVec.ofNat k x) a b).toNat

theorem truthSwap_bound (k a b x : Nat) : truthSwap k a b x<truthRows k :=
  (msbTranspose (BitVec.ofNat k x) a b).isLt

theorem ofNat_truthSwap (k a b x : Nat) :
    BitVec.ofNat k (truthSwap k a b x) = msbTranspose (BitVec.ofNat k x) a b := by
  simp [truthSwap]

theorem truthSwap_twice (k a b x : Nat) (ha : a<k) (hb : b<k) (hab : a≠b)
    (hx : x<truthRows k) : truthSwap k a b (truthSwap k a b x)=x := by
  unfold truthSwap
  simp only [BitVec.ofNat_toNat, BitVec.setWidth_eq]
  rw [msbTranspose, msbTranspose, transpose_twice _ _ _ (by omega) (by omega) (by omega)]
  exact Nat.mod_eq_of_lt hx

theorem swap_lt (a b j m : Nat) (ha : a<m) (hb : b<m) (hj : j<m) :
    Equiv.swap a b j<m := by
  by_cases hja : j=a
  · subst j; simpa using hb
  · by_cases hjb : j=b
    · subst j; simpa using ha
    · simpa [Equiv.swap_apply_of_ne_of_ne hja hjb] using hj

def wire (k a b : Nat) : Wire → Wire
  | .sel t p j => .sel t p (Equiv.swap a b j)
  | .fn t ab => .fn t ab
  | .port t p x => .port t p (truthSwap k a b x)
  | .val t x => .val t (truthSwap k a b x)

theorem wire_valid (k s a b : Nat) (ha : a<k) (hb : b<k)
    (w : Wire) (hw : Valid k s w) : Valid k s (wire k a b w) := by
  cases w with
  | sel t p j => exact ⟨hw.1,hw.2.1,swap_lt a b j (k+t) (by omega) (by omega) hw.2.2⟩
  | fn t ab => exact hw
  | port t p x => exact ⟨hw.1,hw.2.1,truthSwap_bound _ _ _ _⟩
  | val t x => exact ⟨hw.1,truthSwap_bound _ _ _ _⟩

theorem wire_twice (k s a b : Nat) (ha : a<k) (hb : b<k) (hab : a≠b)
    (w : Wire) (hw : Valid k s w) : wire k a b (wire k a b w)=w := by
  cases w with
  | sel t p j => simp [wire]
  | fn t ab => rfl
  | port t p x => simp only [wire, truthSwap_twice _ _ _ _ ha hb hab hw.2.2]
  | val t x => simp only [wire, truthSwap_twice _ _ _ _ ha hb hab hw.2]

def bit (k x j : Nat) : Bool := (BitVec.ofNat k x).getMsbD j
def parity (k x : Nat) : Bool := decide (weight (BitVec.ofNat k x)%2=1)

theorem bit_swap (k a b x j : Nat) (ha : a<k) (hb : b<k) (hab : a≠b) (hj : j<k) :
    bit k (truthSwap k a b x) (Equiv.swap a b j)=bit k x j := by
  unfold bit
  rw [ofNat_truthSwap, msb_bit_transpose _ _ _ _ ha hb (swap_lt a b j k ha hb hj) hab]
  simp

theorem parity_swap (k a b x : Nat) (ha : a<k) (hb : b<k) (hab : a≠b) :
    parity k (truthSwap k a b x)=parity k x := by
  unfold parity
  rw [ofNat_truthSwap, msb_transpose_weight _ _ _ ha hb hab]

def oneHot (k t p : Nat) (positive : Bool) : Spec :=
  ⟨(List.range (k+t)).map (fun j => (.sel t p j,positive)),
    if positive then 1 else (k+t:Int)-1⟩

def forbidden (t c : Nat) : Spec :=
  ⟨(List.range 4).map (fun ab => (.fn t ab, !(c.testBit (3-ab)))),1⟩

def inputTransfer (k t p j x : Nat) : Spec :=
  ⟨[(.sel t p j,false),(.port t p x,bit k x j)],1⟩

def gateTransfer (k t p g x : Nat) (positive : Bool) : Spec :=
  ⟨[(.sel t p (k+g),false),(.val g x,!positive),(.port t p x,positive)],1⟩

def semantics (t x : Nat) (a b positive : Bool) : Spec :=
  ⟨[(.port t 0 x,!a),(.port t 1 x,!b),(.val t x,!positive),
    (.fn t (2*a.toNat+b.toNat),positive)],1⟩

def outputRow (k s x : Nat) : Spec := ⟨[(.val (s-1) x,parity k x)],1⟩

/-- The five row blocks of family.py. The two transfer subfamilies are
    separated only to make the original input/gate branch explicit. -/
inductive Original (k s : Nat) : Spec → Prop
  | oneHot (t p : Nat) (b : Bool) : t<s → p<2 → Original k s (oneHot k t p b)
  | forbidden (t c : Nat) : t<s → c∈[6,9] → Original k s (forbidden t c)
  | input (t p j x : Nat) : t<s → p<2 → j<k → x<truthRows k →
      Original k s (inputTransfer k t p j x)
  | gate (t p g x : Nat) (b : Bool) : t<s → p<2 → g<t → x<truthRows k →
      Original k s (gateTransfer k t p g x b)
  | semantics (t x : Nat) (a b c : Bool) : t<s → x<truthRows k →
      Original k s (semantics t x a b c)
  | output (x : Nat) : 0<s → x<truthRows k → Original k s (outputRow k s x)

theorem original_valid (k s : Nat) (r : Spec) (hr : Original k s r) : r.valid k s := by
  cases hr with
  | oneHot t p b ht hp =>
    intro l hl
    obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hl
    exact ⟨ht,hp,List.mem_range.mp hj⟩
  | forbidden t c ht hc =>
    intro l hl
    obtain ⟨ab,hab,rfl⟩ := List.mem_map.mp hl
    exact ⟨ht,List.mem_range.mp hab⟩
  | input t p j x ht hp hj hx =>
    intro l hl
    simp only [inputTransfer, List.mem_cons, List.not_mem_nil, or_false] at hl
    rcases hl with rfl | rfl
    · exact ⟨ht,hp,by omega⟩
    · exact ⟨ht,hp,hx⟩
  | gate t p g x b ht hp hg hx =>
    intro l hl
    simp only [gateTransfer, List.mem_cons, List.not_mem_nil, or_false] at hl
    rcases hl with rfl | rfl | rfl
    · exact ⟨ht,hp,by omega⟩
    · exact ⟨by omega,hx⟩
    · exact ⟨ht,hp,hx⟩
  | semantics t x a b c ht hx =>
    intro l hl
    simp only [semantics, List.mem_cons, List.not_mem_nil, or_false] at hl
    rcases hl with rfl | rfl | rfl | rfl
    · exact ⟨ht,by decide,hx⟩
    · exact ⟨ht,by decide,hx⟩
    · exact ⟨ht,hx⟩
    · exact ⟨ht,by cases a <;> cases b <;> decide⟩
  | output x hs hx =>
    intro l hl
    simp only [outputRow, List.mem_cons, List.not_mem_nil, or_false] at hl
    subst l
    exact ⟨by omega,hx⟩

theorem range_swap_perm (a b m : Nat) (ha : a<m) (hb : b<m) :
    ((List.range m).map (Equiv.swap a b)).Perm (List.range m) := by
  apply (List.perm_ext_iff_of_nodup ((List.nodup_range (n := m)).map (Equiv.swap a b).injective)
    (List.nodup_range (n := m))).mpr
  intro j
  constructor
  · intro hj
    obtain ⟨i,hi,rfl⟩ := List.mem_map.mp hj
    exact List.mem_range.mpr (swap_lt a b i m ha hb (List.mem_range.mp hi))
  · intro hj
    exact List.mem_map.mpr ⟨Equiv.swap a b j,
      List.mem_range.mpr (swap_lt a b j m ha hb (List.mem_range.mp hj)),by simp⟩

/-- Every original row's image is another original row, modulo ordering of
    summands. This supplies the old-row preservation obligation, rather than
    taking invariance of the formula as an assumption. -/
theorem original_image (k s a b : Nat) (ha : a<k) (hb : b<k) (hab : a≠b)
    (r : Spec) (hr : Original k s r) :
    ∃ q, Original k s q ∧ (r.rename (wire k a b)).literals.Perm q.literals ∧
      (r.rename (wire k a b)).rhs=q.rhs := by
  cases hr with
  | oneHot t p c ht hp =>
    refine ⟨oneHot k t p c,Original.oneHot t p c ht hp,?_,rfl⟩
    have hh := (range_swap_perm a b (k+t) (by omega) (by omega)).map
      (fun j => (Wire.sel t p j,c))
    simpa [oneHot,Spec.rename,wire,List.map_map,Function.comp_def] using hh
  | forbidden t c ht hc =>
    refine ⟨forbidden t c,Original.forbidden t c ht hc,?_,rfl⟩
    simp [forbidden,Spec.rename,wire,List.map_map,Function.comp_def]
  | input t p j x ht hp hj hx =>
    refine ⟨inputTransfer k t p (Equiv.swap a b j) (truthSwap k a b x),
      Original.input _ _ _ _ ht hp (swap_lt a b j k ha hb hj) (truthSwap_bound _ _ _ _),?_,rfl⟩
    simp [inputTransfer,Spec.rename,wire,bit_swap _ _ _ _ _ ha hb hab hj]
  | gate t p g x c ht hp hg hx =>
    refine ⟨gateTransfer k t p g (truthSwap k a b x) c,
      Original.gate _ _ _ _ _ ht hp hg (truthSwap_bound _ _ _ _),?_,rfl⟩
    simp [gateTransfer,Spec.rename,wire,Equiv.swap_apply_of_ne_of_ne
      (show k+g≠a by omega) (show k+g≠b by omega)]
  | semantics t x c d e ht hx =>
    refine ⟨semantics t (truthSwap k a b x) c d e,
      Original.semantics _ _ _ _ _ ht (truthSwap_bound _ _ _ _),?_,rfl⟩
    simp [semantics,Spec.rename,wire]
  | output x hs hx =>
    refine ⟨outputRow k s (truthSwap k a b x),
      Original.output _ hs (truthSwap_bound _ _ _ _),?_,rfl⟩
    simp [outputRow,Spec.rename,wire,parity_swap _ _ _ _ ha hb hab]

/-- Exact PB preservation, not just equivalence of satisfying assignments. -/
theorem original_row_image (k s a b : Nat) (ha : a<k) (hb : b<k) (hab : a≠b)
    (r : Spec) (hr : Original k s r) :
    ∃ q, Original k s q ∧
      EREF.GeneralRED.substRow (r.row k s)
        (wireWitness k s (wire k a b) (wire_valid k s a b ha hb)) = q.row k s := by
  obtain ⟨q,hq,hp,he⟩ := original_image k s a b ha hb hab r hr
  refine ⟨q,hq,?_⟩
  rw [subst_row _ _ _ _ _ (original_valid k s r hr)]
  exact row_of_perm _ _ _ _ (rename_valid k s (wire k a b) (wire_valid k s a b ha hb) r (original_valid k s r hr))
    (original_valid k s q hq) hp he

#print axioms truthSwap_twice
#print axioms original_valid
#print axioms original_image
#print axioms original_row_image
end L3Emitter.InputSwap

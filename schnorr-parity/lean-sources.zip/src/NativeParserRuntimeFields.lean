import NativeParserVariableSupport
import NativeRuntimeSupport
namespace L3Emitter.NativeParserRuntimeFields
open EREF CanonicalLineParser CanonicalScopeKernel CanonicalFileGrammar NativeParserEventCoordinates NativeRuntimeSupport

def EventVars (K:Nat) (e:Event):Prop:=∀v∈eventNames e,v≤K

theorem tape (K:Nat) (ts:List Tok) (h:EventVars K (.pol ts)):TapeVars K ts:=by
 intro l hl
 exact h l.natAbs (List.mem_flatMap.mpr ⟨.lit l,hl,by simp [tokenNames]⟩)

theorem row (K:Nat) (R:Row) (h:∀v∈rowNames R,v≤K):RowVars K R:=by
 intro t ht
 exact h t.2.natAbs (List.mem_map.mpr ⟨t,ht,rfl⟩)

theorem witness (K:Nat) (w:FiniteWitness.Data) (h:∀v∈witnessNames w,v≤K):WitnessVars K w:=by
 intro p hp
 cases hx:p.2 with
 | bit b=>trivial
 | lit l=>
   exact h l.varId (List.mem_flatMap.mpr ⟨p,hp,by simp [hx,imageNames]⟩)

theorem local_tape_event (p:LocalProof) (ts:List Tok) (ht:ts∈p.tapes):Event.pol ts∈localEvents p:=by
 exact List.mem_append_left _ (List.mem_map.mpr ⟨ts,ht,rfl⟩)

theorem command (K:Nat) (c:CanonicalScopeKernel.Command)
 (h:∀e∈commandEvents c,EventVars K e):CommandVars K c:=by
 cases c with
 | pol ts=>exact tape K ts (h _ (by simp [commandEvents]))
 | consequence R p=>
   refine ⟨row K R (h (.pbc R) (by simp [commandEvents])),?_⟩
   intro ts ht
   exact tape K ts (h _ (List.mem_cons_of_mem _ (local_tape_event p ts ht)))
 | red R w gs=>
   have hh:=h (.red R w) (by simp [commandEvents])
   refine ⟨row K R (fun v hv=>hh v (List.mem_append_left _ hv)),
     witness K w (fun v hv=>hh v (List.mem_append_right _ hv)),?_⟩
   intro g hg ts ht
   apply tape K ts
   apply h
   apply List.mem_append_left
   apply List.mem_cons_of_mem
   exact List.mem_flatMap.mpr ⟨g,hg,List.mem_cons_of_mem _ (local_tape_event g.proof ts ht)⟩

theorem family_commands (n:Nat) (hn:2≤n):
 ∀c∈(NativeParserBundle.parsed n).commands,CommandVars (NativeParserBundle.names n).length c:=by
 intro c hc
 apply command
 intro e he
 exact NativeParserVariableSupport.parsed_events n hn e (List.mem_flatMap.mpr ⟨c,hc,he⟩)

theorem family_original (n:Nat):
 ∀R∈(NativeParserBundle.parsed n).original,RowVars (NativeParserBundle.names n).length R:=
 NativeParserVariableSupport.parsed_original n
#print axioms family_commands
#print axioms family_original
end L3Emitter.NativeParserRuntimeFields

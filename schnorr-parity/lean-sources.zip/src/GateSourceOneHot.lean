import MuxSourceStep

namespace L3Emitter.GateSourceOneHot
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot GateCategories

def unit (n:Nat) (hn:2≤n) (j:Nat) :=AliasAssembly.inputAliases (AliasAssembly.width (n+1)) (PrimaryAliasBank.cfg n hn) (j+1)
def inputs (n:Nat) (hn:2≤n) (g:Nat) : Category→AliasBits (AliasAssembly.width (n+1))
  | .beta=>unit n hn 0
  | .gamma=>MuxSourceStep.vector n hn g
  | .rank t=>unit n hn (n+t)
def target (n:Nat) (hn:2≤n) (g:Nat) :=(AliasAssembly.built n hn).1.2 (n+1+g)
def program (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=
  IndexedSourceOneHot.program D (CategoryPrograms.cats n) (bit n hn g) (inputs n hn g) (target n hn g)
def result (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=
  IndexedSourceOneHot.result D (CategoryPrograms.cats n) (bit n hn g) (target n hn g)

theorem links (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (cat:Category) (hc:cat∈CategoryPrograms.cats n) :
    SourceOnlyTransport.Links (SourceAuxBank.result n hn) (bit n hn g cat) (inputs n hn g cat) (target n hn g) := by
  intro i
  have keep:∀R∈SourceRelationBank.result n hn,R∈SourceAuxBank.result n hn:=
    fun R h=>SourceAuxBank.retains n hn R (UnitAliasBank.retains n hn R h)
  cases cat with
  | beta=>
    have h:=SourceRelationBank.beta_relations n hn g hg hs i
    have he:(GateSnapshots.refs n hn g i).u=unit n hn 0 (position i):=by
      rw [unit,PrimaryAliasRows.coordinate]
      rfl
    dsimp only at h
    rw [he] at h
    exact ⟨keep _ h.1,keep _ h.2⟩
  | gamma=>
    have h:=SourceRelationBank.gamma_relations n hn g hg hs i
    have he:(GateSnapshots.refs n hn g i).m=MuxSourceStep.vector n hn g (position i):=by
      rw [←SourceMuxSnapshots.output_binding]
      simp [MuxSourceStep.vector,position,i.isLt]
    dsimp only at h
    rw [he] at h
    exact ⟨keep _ h.1,keep _ h.2⟩
  | rank t=>
    have ht:t<RankConstruction.width (n+1):=by simpa [CategoryPrograms.cats,categories,RankConstruction.width] using hc
    exact SourceAuxBank.rank_links n hn g hg hs i t ht

theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (D:List Row) (hd:∀R∈SourceAuxBank.result n hn,R∈D) (hm:SourceRows D (MuxSourceStep.vector n hn g)) :
    check D (program n hn g D)=some (result n hn g D) := by
  apply IndexedSourceOneHot.checks
  · unfold AliasAssembly.width RankConstruction.width;omega
  · simp [CategoryPrograms.cats,categories]
  · exact hd _ (SourceAuxBank.contains_category n hn _ (CategoryBank.alo n hn g hg hs))
  · intro cat hc
    have hu (j:Nat) (hj:j<AliasAssembly.width (n+1)) :SourceRows D (unit n hn j):=by
      have h:=UnitAliasBank.source_rows n hn j hj
      exact ⟨hd _ (SourceAuxBank.retains n hn _ h.1),fun i l hil=>hd _ (SourceAuxBank.retains n hn _ (h.2 i l hil))⟩
    cases cat with
    | beta=>exact hu 0 (by unfold AliasAssembly.width RankConstruction.width;omega)
    | gamma=>exact hm
    | rank t=>
      have ht:t<RankConstruction.width (n+1):=by simpa [CategoryPrograms.cats,categories,RankConstruction.width] using hc
      exact hu (n+t) (by unfold AliasAssembly.width;omega)
  · intro cat hc i
    exact ⟨hd _ (links n hn g hg hs cat hc i).1,hd _ (links n hn g hg hs cat hc i).2⟩

theorem source_rows (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) : SourceRows (result n hn g D) (target n hn g) :=
  IndexedSourceOneHot.source_rows _ _ _ _
theorem retains (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :∀R∈D,R∈result n hn g D:=
  fun R h=>List.mem_append_left _ h

#print axioms checks
#print axioms source_rows
end L3Emitter.GateSourceOneHot

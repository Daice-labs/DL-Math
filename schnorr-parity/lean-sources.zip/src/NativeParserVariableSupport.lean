import NativeParserNameRanges
namespace L3Emitter.NativeParserVariableSupport
open EREF CanonicalLineParser CanonicalFileGrammar NativeParserEventCoordinates PinnedCoordinateChange

theorem coord_bound (names:List Nat) (v:Nat) (h:v∈names):coordinate names v≤names.length:=by
 rw [encountered _ _ h]
 exact Nat.succ_le_of_lt (List.idxOf_lt_length_of_mem h)

theorem row_support (names:List Nat) (R:Row) (hc:Canonical R)
 (h:∀v∈rowNames R,v∈names):
 ∀t∈(PinnedCoordinateChange.row (coordinate names) R).terms,t.2.natAbs≤names.length:=by
 have hp:=(PinnedCoordinateChange.fields (coordinate names) (coordinate_injective names) R hc).1
 intro t ht
 obtain ⟨q,hq,rfl⟩:=List.mem_map.mp (hp.mem_iff.mp ht)
 simp only [term,lit_abs]
 exact coord_bound names _ (h _ (List.mem_map.mpr ⟨q,hq,rfl⟩))

theorem witness_support (names:List Nat) (w:FiniteWitness.Data)
 (h:∀v∈witnessNames w,v∈names):
 ∀v∈witnessNames (PinnedCoordinateChange.witness (coordinate names) w),v≤names.length:=by
 intro v hv
 obtain ⟨e,he,hv⟩:=List.mem_flatMap.mp hv
 obtain ⟨q,hq,rfl⟩:=List.mem_map.mp he
 rcases List.mem_cons.mp hv with rfl|hv
 · exact coord_bound names _ (h _ (List.mem_flatMap.mpr ⟨q,hq,by simp⟩))
 · cases hx:q.2 with
   | bit b=>simp [hx,PinnedCoordinateChange.image,imageNames] at hv
   | lit l=>
     simp only [hx,PinnedCoordinateChange.image,imageNames,List.mem_singleton] at hv
     subst v
     apply coord_bound names
     apply h
     exact List.mem_flatMap.mpr ⟨q,hq,by simp [hx,imageNames]⟩

theorem event_support (names:List Nat) (e:Event) (hc:CanonicalLineParser.Valid e)
 (h:∀v∈eventNames e,v∈names):
 ∀v∈eventNames (event (coordinate names) e),v≤names.length:=by
 cases e with
 | pol ts=>
   intro v hv
   obtain ⟨t,ht,hv⟩:=List.mem_flatMap.mp hv
   obtain ⟨q,hq,rfl⟩:=List.mem_map.mp ht
   cases q with
   | lit l=>
     have hz:l≠0:=hc (.lit l) hq
     simp only [token,if_neg hz,tokenNames,List.mem_singleton,lit_abs] at hv
     subst v
     exact coord_bound names _ (h _ (List.mem_flatMap.mpr ⟨.lit l,hq,by simp [tokenNames]⟩))
   | ref _ | mul _ | div _ | add | sat=>simp [token,tokenNames] at hv
 | pbc R=>
   intro v hv'
   obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hv'
   exact row_support names R hc h t ht
 | red R w=>
   intro v hv'
   rcases List.mem_append.mp hv' with hv'|hv'
   · obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hv'
     exact row_support names R hc.1 (fun v hv=>h v (List.mem_append_left _ hv)) t ht
   · exact witness_support names w (fun v hv=>h v (List.mem_append_right _ hv)) v hv'
 | goal _ | close _ | endRed=>simp [event,eventNames]

/-- Every variable field in the parsed native command sequence is bounded
by the actual number of interned names, including all local proof tapes. -/
theorem parsed_events (n:Nat) (hn:2≤n):
 ∀e∈(NativeParserBundle.parsed n).commands.flatMap commandEvents,
 ∀v∈eventNames e,v≤(NativeParserBundle.names n).length:=by
 change ∀e∈((NativeCompatibleFamily.commands n).map
   (PinnedCoordinateChange.command (coordinate (NativeParserBundle.names n)))).flatMap commandEvents, _
 rw [commands_events]
 intro e he
 obtain ⟨q,hq,rfl⟩:=List.mem_map.mp he
 apply event_support _ q (NativeCompatibleFamily.valid n hn q hq)
 intro v hv
 apply NativeParserNameRanges.present n v
 exact List.mem_append_right _ (List.mem_flatMap.mpr ⟨q,hq,hv⟩)

theorem parsed_original (n:Nat):
 ∀R∈(NativeParserBundle.parsed n).original,
 ∀t∈R.terms,t.2.natAbs≤(NativeParserBundle.names n).length:=by
 intro R hR
 obtain ⟨Q,hQ,rfl⟩:=List.mem_map.mp hR
 apply row_support _ Q (OriginalEncoding.rows_canonical n (3*n-4) Q hQ)
 intro v hv
 apply NativeParserNameRanges.present n v
 exact List.mem_append_left _ (List.mem_flatMap.mpr ⟨Q,hQ,hv⟩)
#print axioms parsed_events
#print axioms parsed_original
end L3Emitter.NativeParserVariableSupport

import FirstUnaryMux
namespace L3Emitter.FirstValueCore
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram

theorem perm3 (a b c:Int) (ha:a≠0) (hb:b≠0) (hc:c≠0):
    clause [a,b,c]=clause [a,c,b]:=ProjectionTrace.clause_perm _ _
      (by simp [Valid,ha,hb,hc]) (by simp [Valid,ha,hb,hc]) (List.Perm.cons _ (List.Perm.swap ..))
theorem rotate4 (a b c d:Int) (ha:a≠0) (hb:b≠0) (hc:c≠0) (hd:d≠0):
    clause [a,b,c,d]=clause [b,a,c,d]:=ProjectionTrace.clause_perm _ _
      (by simp [Valid,ha,hb,hc,hd]) (by simp [Valid,ha,hb,hc,hd]) (List.Perm.swap ..)

def r1 (B a b q f u:Bit):=clause [-B.val,-b.val,q.val,-f.val]
def r2 (B a b q f u:Bit):=clause [-B.val,q.val,-f.val]
def target (B a b q f u:Bit):=clause [-B.val,-u.val,q.val]
def rows (B a b q f u:Bit):=[r1 B a b q f u,r2 B a b q f u,target B a b q f u]
def program (B a b q f u:Bit) (D:List Row):Program:=
  [(r1 B a b q f u,CommonGuardResolve.tape D [] [-B.val] [-b.val,q.val,-f.val] a.val),
   (r2 B a b q f u,CommonGuardResolve.tape (D++[r1 B a b q f u]) [] [] [-B.val,q.val,-f.val] b.val),
   (target B a b q f u,CommonGuardResolve.tape (D++[r1 B a b q f u,r2 B a b q f u]) [-B.val] [-u.val] [q.val] f.val)]

theorem checks (B a b q f u:Bit) (D:List Row)
    (h0:clause [-B.val,a.val]∈D) (h1:clause [b.val]∈D)
    (hs:clause [-a.val,-b.val,q.val,-f.val]∈D)
    (hm:clause [-B.val,-u.val,f.val]∈D):
    check D (program B a b q f u D)=some (D++rows B a b q f u):=by
  have e0:=CommonGuardResolve.checks D [] [-B.val] [-b.val,q.val,-f.val] a.val
    (by simp [Valid]) (by simp [Valid,B.property]) (by simp [Valid,b.property,q.property,f.property]) a.property h0 hs
  have hh:CommonGuardResolve.right [] [-B.val,q.val,-f.val] b.val∈D++[r1 B a b q f u]:=by
    change clause [-b.val,-B.val,q.val,-f.val]∈_
    rw [rotate4 _ _ _ _ (neg_ne_zero.mpr b.property) (neg_ne_zero.mpr B.property) q.property (neg_ne_zero.mpr f.property)]
    exact List.mem_append_right _ (List.mem_singleton_self _)
  have e1:=CommonGuardResolve.checks (D++[r1 B a b q f u]) [] [] [-B.val,q.val,-f.val] b.val
    (by simp [Valid]) (by simp [Valid]) (by simp [Valid,B.property,q.property,f.property]) b.property
    (List.mem_append_left _ h1) hh
  have hh2:CommonGuardResolve.right [-B.val] [q.val] f.val∈D++[r1 B a b q f u,r2 B a b q f u]:=by
    change clause [-B.val,-f.val,q.val]∈_
    rw [perm3 _ _ _ (neg_ne_zero.mpr B.property) (neg_ne_zero.mpr f.property) q.property]
    exact List.mem_append_right _ (by simp [r2])
  have e2:=CommonGuardResolve.checks (D++[r1 B a b q f u,r2 B a b q f u]) [-B.val] [-u.val] [q.val] f.val
    (by simp [Valid,B.property]) (by simp [Valid,u.property]) (by simp [Valid,q.property]) f.property
    (List.mem_append_left _ hm) hh2
  change polEval (dbOf D) _ []=some (r1 B a b q f u) at e0
  change polEval (dbOf (D++[r1 B a b q f u])) _ []=some (r2 B a b q f u) at e1
  change polEval (dbOf (D++[r1 B a b q f u,r2 B a b q f u])) _ []=some (target B a b q f u) at e2
  simp only [program,check,e0,↓reduceIte,e1,List.append_assoc,List.singleton_append] at *
  simp only [e2,↓reduceIte,rows,List.append_assoc,List.singleton_append,List.nil_append,List.cons_append,check]

#print axioms checks
end L3Emitter.FirstValueCore

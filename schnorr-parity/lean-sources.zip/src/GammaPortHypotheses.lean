import GammaSourcePorts
namespace L3Emitter.GammaPortHypotheses
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
abbrev Job:=BetaPort.Job

def frame (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool):=
  [-(GammaSourcePorts.q n hn j i).val,-sign u t]
def H (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (side:Bool):=
  [-BetaAliasValue.choice j,-(GammaSourcePorts.q n hn j i).val,-sign side (GammaChoiceBank.hit n hn j.1)]
def Q (n:Nat) (hn:2≤n) (j:Job n) (t:Bit) (u side b:Bool):=
  [-sign u t,-sign b (GammaComparison.otherUnary n hn j u side),sign b (GammaCofactorValue.other n hn j side)]
def tape (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u side b:Bool) (D:List Row):=
  CommonGuardResolve.tape D [] (H n hn j i side) (Q n hn j t u side b) (GammaSourcePorts.port n hn j i side).val

theorem unary_binding (n:Nat) (hn:2≤n) (j:Job n) (u side:Bool):
    EarlierPortValues.portAlias n hn (GammaCofactorValue.g j) (if side then 1 else 0)
      (UnarySnapshots.position (AliasAssembly.width (n+1)) u)=GammaComparison.otherUnary n hn j u side:=by
  cases side
  · exact congrFun (GammaSourcePorts.left_binding n hn (GammaCofactorValue.g j)) _
  · exact congrFun (GammaSourcePorts.right_binding n hn (GammaCofactorValue.g j)) _

theorem port_binding (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u side b:Bool):
    PortValueBank.target n hn (GammaCofactorValue.g j) (if side then 1 else 0) j.2 i t u b=
      CommonGuardResolve.right [] (Q n hn j t u side b) (GammaSourcePorts.port n hn j i side).val:=by
  unfold PortValueBank.target PortValueTransfer.invariant
  rw [unary_binding]
  rfl

theorem target_binding (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u side b:Bool):
    CommonGuardResolve.target [] (H n hn j i side) (Q n hn j t u side b)=
      GammaPreservation.hypothesis n hn j u side b (frame n hn j i t u):=by
  have hc:=BetaAliasValue.choice_valid n hn j hj
  apply ProjectionTrace.clause_perm _ _
    (by simp [H,Q,Valid,hc,sign_valid,(GammaSourcePorts.q n hn j i).property])
    (by simp [GammaPreservation.guards,frame,Valid,hc,sign_valid,(GammaSourcePorts.q n hn j i).property])
  apply List.perm_iff_count.mpr
  intro z
  simp only [CommonGuardResolve.target,H,Q,GammaPreservation.hypothesis,GammaValueJoin.inductionRow,
    GammaPreservation.guards,frame,List.count_append,List.count_cons,List.count_nil]
  omega

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u side b:Bool) (D:List Row)
    (hs:GammaSourcePorts.row n hn j i side∈D)
    (hp:PortValueBank.target n hn (GammaCofactorValue.g j) (if side then 1 else 0) j.2 i t u b∈D):
    polEval (dbOf D) (tape n hn j i t u side b D) []=some
      (GammaPreservation.hypothesis n hn j u side b (frame n hn j i t u)):=by
  have hc:=BetaAliasValue.choice_valid n hn j hj
  have he:=CommonGuardResolve.checks D [] (H n hn j i side) (Q n hn j t u side b)
    (GammaSourcePorts.port n hn j i side).val (by simp [Valid])
    (by simp [H,Valid,hc,sign_valid,(GammaSourcePorts.q n hn j i).property])
    (by simp [Q,Valid,sign_valid]) (GammaSourcePorts.port n hn j i side).property hs
    ((port_binding n hn j i t u side b) ▸ hp)
  rw [target_binding n hn j hj i t u side b] at he
  exact he
#print axioms unary_binding
#print axioms port_binding
#print axioms checks
end L3Emitter.GammaPortHypotheses

import L3BranchBinding

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def branchIndices : List Nat := List.range' 1 (F.s-2)
def preparedBank (t : StI F.V) : StI F.V × List Int := F.branchBank F.branchIndices (t,[])
def preparedBranches (t : StI F.V) : StI F.V :=
  let p := F.preparedBank t
  let v := p.1.OR p.2
  v.2.setB v.1

def BranchReady (t : StI F.V) (brs : List Int) : Prop :=
  F.Good3 t ∧ Cmd.orDef t.s.Bv brs∈t.s.cmds ∧ 1≤t.s.Bv ∧ t.s.Bv≤t.s.var ∧
  (∀b∈F.branchIndices,∀g,b<g → g<F.s → F.BranchRecord b g t brs)

theorem prepared_keeps (t : StI F.V) : Keeps2 t (F.preparedBranches t) :=
  keeps2_trans (F.branchBank_keeps _ _) (keeps2_trans (keeps2_OR _ _) (keeps2_setB _ _))

theorem prepared_ready (t : StI F.V) (ht : F.Good3 t) :
    F.BranchReady (F.preparedBranches t) (F.preparedBank t).2 := by
  let p := F.preparedBank t
  have kp : Keeps2 t p.1 := F.branchBank_keeps _ _
  have ku : Keeps2 p.1 (F.preparedBranches t) := keeps2_trans (keeps2_OR _ _) (keeps2_setB _ _)
  have hbound : Bounded p.1.s.var p.2 := F.branchBank_bounded _ _ (by simp [Bounded])
  refine ⟨F.Good3_of_keeps2 (F.prepared_keeps t) ht,?_,?_,?_,?_⟩
  · change Cmd.orDef (p.1.s.var+1) p.2∈p.1.s.cmds++[.orDef (p.1.s.var+1) (p.1.s.chk p.2)]
    rw [StI.chk_eq p.1 _ hbound]; simp
  · change 1≤p.1.s.var+1; omega
  · change p.1.s.var+1≤p.1.s.var+1; omega
  · intro b hb g hbg hg
    apply F.BranchRecord_keeps ku (fun _ h => h) b g
    exact F.branchBank_records _ (t,[]) ht
      (fun b hb => (List.mem_range'_1.mp hb).1) b hb g hbg hg

theorem prepared_obls (t : StI F.V) (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.preparedBranches t).s.cmds := by
  change ObligationsChecked F.db5 ((F.preparedBank t).1.s.cmds++[.orDef _ _])
  apply obligations_append _ _ _ (F.branchBank_obls _ _ ho)
  intro o ho; simp [obls] at ho

theorem BranchReady_keeps {t u : StI F.V} (hk : Keeps2 t u) (hB : u.s.Bv=t.s.Bv)
    (brs : List Int) (hr : F.BranchReady t brs) : F.BranchReady u brs := by
  refine ⟨F.Good3_of_keeps2 hk hr.1,?_,?_,?_,?_⟩
  · rw [hB]; exact mem_of_grows hk.1 hr.2.1
  · rw [hB]; exact hr.2.2.1
  · rw [hB]; exact Nat.le_trans hr.2.2.2.1 (var_le_of_grows hk.1)
  · intro b hb g hbg hg
    exact F.BranchRecord_keeps hk (fun _ h => h) b g (hr.2.2.2.2 b hb g hbg hg)

def branchC (t : StI F.V) (b : Nat) : List Int := [(t.s.Bv:Int),-(t.s.eligible b:Int)]

theorem branchC_bound (t : StI F.V) (brs : List Int) (hr : F.BranchReady t brs)
    (b : Nat) (hb : b∈F.branchIndices) : Bounded t.s.var (F.branchC t b) := by
  have hbi := List.mem_range'_1.mp hb
  obtain ⟨c,hc,he,hcl,hel,heu⟩ := hr.1.2.2.2.1 b hbi.1 (by omega)
  have hbL := hr.2.2.1; have hbU := hr.2.2.2.1
  intro l hl; simp only [branchC,List.mem_cons,List.not_mem_nil,or_false] at hl
  rcases hl with rfl | rfl <;> simp <;> omega

theorem bRup_obls (hk : 1≤F.k) (hs : 1≤F.s) (t : StI F.V) (brs : List Int)
    (hr : F.BranchReady t brs) (b : Nat) (hb : b∈F.branchIndices)
    (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.bRup t b).s.cmds := by
  change ObligationsChecked F.db5 (t.s.cmds++[.rup (t.s.chk (F.branchC t b))])
  rw [StI.chk_eq t _ (F.branchC_bound t brs hr b hb)]
  apply obligations_append _ _ _ ho
  intro o ho
  simp only [obls,List.mem_cons,List.not_mem_nil,or_false] at ho
  subst o
  have hbi := List.mem_range'_1.mp hb
  exact F.branch_from_database hk hs t hr.1 b t.s.Bv brs hbi.1 (by omega)
    hr.2.2.1 hr.2.1 (hr.2.2.2.2 b hb)

#print axioms prepared_ready
#print axioms bRup_obls
end L3.Fam

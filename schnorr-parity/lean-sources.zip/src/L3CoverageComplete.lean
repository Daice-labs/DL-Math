import L3CoverageMerge
import L3V7OutputIntegration

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

theorem merge_finish_obls (hk : 2≤F.k) (hs : 1≤F.s) (t : StI F.V) (ht : F.Good3 t)
    (c0 c1 : Nat) (r0 : F.BitRecord 0 c0 t) (r1 : F.BitRecord 1 c1 t)
    (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5
      ((t.split [(c0 : Int),(c1 : Int)] [(F.fn 0 0 : Int),(F.fn 0 1 : Int)]).rup [(t.s.A : Int)]).s.cmds := by
  have hc : Bounded t.s.var [(c0 : Int),(c1 : Int)] := by
    have h0 := r0.2.2
    have h1 := r1.2.2
    intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> omega
  have hv : Bounded t.s.var [(F.fn 0 0 : Int),(F.fn 0 1 : Int)] := by
    have h0 := F.fn_pos 0 0
    have h1 := F.fn_pos 0 1
    have hl0 := F.fn_le 0 0 hs (by decide)
    have hl1 := F.fn_le 0 1 hs (by decide)
    have hS := F.S4_le_V
    have hV := t.var_ge
    intro l hl
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl | rfl <;> simp <;> omega
  let u := t.split [(c0 : Int),(c1 : Int)] [(F.fn 0 0 : Int),(F.fn 0 1 : Int)]
  have ku : Keeps2 t u := keeps2_split _ _ _
  have hou : ObligationsChecked F.db5 u.s.cmds := F.checked_split t _ _ hc hv ho (F.cbSplit_obls hk hs t c0 c1 r0 r1)
  have hu := F.Good3_of_keeps2 ku ht
  have ha0 := ht.2.2.2.2.2.1
  have ha1 := ht.2.2.2.2.2.2
  have hA : Bounded u.s.var [(t.s.A : Int)] := by
    have hle := var_le_of_grows ku.1
    intro l hl; simp only [List.mem_cons,List.not_mem_nil,or_false] at hl
    subst l; simp; omega
  change ObligationsChecked F.db5 (u.rup [(t.s.A : Int)]).s.cmds
  rw [StI.cmds_rup,StI.chk_eq u _ hA]
  apply obligations_append _ _ _ hou
  intro o ho
  simp only [obls,List.mem_cons,List.not_mem_nil,or_false] at ho
  subst o
  apply coverage_merge _ t.s.A c0 c1 (by omega) r0.2.2.1 r1.2.2.1
    (exec_bounded F.db5 F.V u.s.cmds (F.db5_bounded (by omega) hs) u.inv.1).canonical
  · exact rup_row_mem F.db5 u.s.cmds _ (mem_of_grows ku.1 r0.2.1)
  · exact rup_row_mem F.db5 u.s.cmds _ (mem_of_grows ku.1 r1.2.1)
  · exact rup_row_mem F.db5 u.s.cmds _ (StI.split_root_mem t _ _ hc hv)

/-- Full stage-5 coverage for the actual frontend command sequence. Both
    bit cases, every gate and selector split, and the final merge are proved. -/
theorem stage5_obls (hk : 2≤F.k) (hs : 2≤F.s) (hpar : F.b=parityBit) (hm : 1≤F.V)
    (t : StI F.V) (ht : F.Good3 t) (hf : F.ForceRecord t)
    (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.stage5 hm t).s.cmds := by
  let u0 := (F.bitStep hm (t,[]) 0).1
  let c0 := t.s.var+1
  let u1 := (F.bitStep hm (u0,[(c0 : Int)]) 1).1
  let c1 := u0.s.var+1
  have k0 : Keeps2 t u0 := F.keeps2_bitStep hm (t,[]) 0
  have k1 : Keeps2 u0 u1 := F.keeps2_bitStep hm (u0,[(c0 : Int)]) 1
  have h0 := F.Good3_of_keeps2 k0 ht
  have h1 := F.Good3_of_keeps2 k1 h0
  have ho0 : ObligationsChecked F.db5 u0.s.cmds := F.bitStep_obls hk hs hpar hm t [] ht hf 0 (by decide) ho
  have ho1 : ObligationsChecked F.db5 u1.s.cmds := F.bitStep_obls hk hs hpar hm u0 [(c0 : Int)] h0
    (F.ForceRecord_keeps k0 hf) 1 (by decide) ho0
  have r0 : F.BitRecord 0 c0 u0 := F.bitStep_record hk hs hm t [] ht 0 (by decide)
  have r1 : F.BitRecord 1 c1 u1 := F.bitStep_record hk hs hm u0 [(c0 : Int)] h0 1 (by decide)
  have r0' := F.BitRecord_keeps k1 0 c0 r0
  change ObligationsChecked F.db5 ((u1.split [(c0 : Int),(c1 : Int)]
    [(F.fn 0 0 : Int),(F.fn 0 1 : Int)]).rup [(u1.s.A : Int)]).s.cmds
  exact F.merge_finish_obls hk (by omega) u1 h1 c0 c1 r0' r1 ho1

/-- No stage-5 proof premise: the original stages 0--4 supply the entire
    checked prefix and all force rows used by the coverage induction. -/
theorem t5_obls (hk : 2≤F.k) (hs : 2≤F.s) (hpar : F.b=parityBit) :
    ObligationsChecked F.db5 (F.stage5 (F.V_pos (by omega)) (F.t4 (by omega))).s.cmds := by
  apply F.stage5_obls hk hs hpar (F.V_pos (by omega)) (F.t4 (by omega))
  · exact F.Good3_of_keeps2 (F.keeps2_stage4 (F.t3 (by omega))) (F.good3_stage3 (by omega))
  · exact F.t4_forceRecord (by omega)
  · exact F.obls_t4 (by omega) (by omega)

/-- Coverage and output exclusion both hold in their actual order. -/
theorem t6_obls (hk : 2≤F.k) (hs : 2≤F.s) (hpar : F.b=parityBit) :
    ObligationsChecked F.db5
      (F.stage6 (F.stage5 (F.V_pos (by omega)) (F.t4 (by omega)))).s.cmds := by
  apply F.stage6_obls hk hs hpar
  · apply F.Good3_of_keeps2 (F.keeps2_stage5 _ _)
    exact F.Good3_of_keeps2 (F.keeps2_stage4 (F.t3 (by omega))) (F.good3_stage3 (by omega))
  · exact F.t5_obls hk hs hpar

#print axioms stage5_obls
#print axioms t5_obls
#print axioms t6_obls
end L3.Fam

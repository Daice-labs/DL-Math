import Mathlib.Tactic

/- The numeric variable layout of emitter/family.py, for every k and s.
   No finite-instance evaluation is used in these proofs. -/
namespace L3Emitter.FamilyNamespace

def selectorStart (k t : Nat) : Nat := 2*t*k+t*(t-1)
def selectors (k s : Nat) : Nat := s*(2*k+s-1)
def truthRows (k : Nat) : Nat := 2^k
def variableCount (k s : Nat) : Nat := selectors k s+4*s+3*s*truthRows k

inductive Wire where
  | sel (t p j : Nat)
  | fn (t ab : Nat)
  | port (t p x : Nat)
  | val (t x : Nat)
  deriving DecidableEq, Repr

def Valid (k s : Nat) : Wire → Prop
  | .sel t p j => t<s ∧ p<2 ∧ j<k+t
  | .fn t ab => t<s ∧ ab<4
  | .port t p x => t<s ∧ p<2 ∧ x<truthRows k
  | .val t x => t<s ∧ x<truthRows k

def encode (k s : Nat) : Wire → Nat
  | .sel t p j => selectorStart k t+p*(k+t)+j+1
  | .fn t ab => selectors k s+4*t+ab+1
  | .port t p x => selectors k s+4*s+(2*t+p)*truthRows k+x+1
  | .val t x => selectors k s+4*s+2*s*truthRows k+t*truthRows k+x+1

theorem start_succ (k t : Nat) :
    selectorStart k (t+1) = selectorStart k t+2*(k+t) := by
  cases t with
  | zero => simp [selectorStart]
  | succ t => simp [selectorStart]; ring

theorem start_eq_selectors (k t : Nat) : selectorStart k t = selectors k t := by
  cases t with
  | zero => simp [selectorStart, selectors]
  | succ t => simp [selectorStart, selectors]; ring

theorem start_mono (k : Nat) : Monotone (selectorStart k) := by
  apply monotone_nat_of_le_succ
  intro t
  rw [start_succ]
  omega

theorem truthRows_pos (k : Nat) : 0 < truthRows k := by
  exact pow_pos (by decide) _

theorem selector_interval (k s t p j : Nat) (h : Valid k s (.sel t p j)) :
    selectorStart k t < encode k s (.sel t p j) ∧
      encode k s (.sel t p j) ≤ selectorStart k (t+1) := by
  rcases h with ⟨ht,hp,hj⟩
  simp only [encode, start_succ]
  have hp' : p≤1 := by omega
  have hm : p*(k+t) ≤ k+t := by nlinarith
  omega

theorem selector_block (k s t p j : Nat) (h : Valid k s (.sel t p j)) :
    0 < encode k s (.sel t p j) ∧ encode k s (.sel t p j) ≤ selectors k s := by
  have hi := selector_interval k s t p j h
  have hm := start_mono k (show t+1≤s from h.1)
  rw [start_eq_selectors k s] at hm
  omega

theorem fn_block (k s t ab : Nat) (h : Valid k s (.fn t ab)) :
    selectors k s < encode k s (.fn t ab) ∧
      encode k s (.fn t ab) ≤ selectors k s+4*s := by
  rcases h with ⟨ht,ha⟩
  simp only [encode]
  omega

theorem port_block (k s t p x : Nat) (h : Valid k s (.port t p x)) :
    selectors k s+4*s < encode k s (.port t p x) ∧
      encode k s (.port t p x) ≤ selectors k s+4*s+2*s*truthRows k := by
  rcases h with ⟨ht,hp,hx⟩
  have htp : 2*t+p+1≤2*s := by omega
  have hh := Nat.mul_le_mul_right (truthRows k) htp
  simp only [encode]
  constructor <;> nlinarith

theorem val_block (k s t x : Nat) (h : Valid k s (.val t x)) :
    selectors k s+4*s+2*s*truthRows k < encode k s (.val t x) ∧
      encode k s (.val t x) ≤ variableCount k s := by
  rcases h with ⟨ht,hx⟩
  have hh := Nat.mul_le_mul_right (truthRows k) (show t+1≤s from ht)
  simp only [encode, variableCount]
  constructor <;> nlinarith

theorem encode_bounds (k s : Nat) (w : Wire) (h : Valid k s w) :
    0 < encode k s w ∧ encode k s w ≤ variableCount k s := by
  cases w with
  | sel t p j => have hh := selector_block k s t p j h; unfold variableCount; omega
  | fn t ab => have hh := fn_block k s t ab h; unfold variableCount; omega
  | port t p x =>
    have hh := port_block k s t p x h
    unfold variableCount
    constructor
    · omega
    · nlinarith
  | val t x => have hh := val_block k s t x h; omega

theorem selector_injective (k s t p j u q l : Nat)
    (h : Valid k s (.sel t p j)) (g : Valid k s (.sel u q l))
    (he : encode k s (.sel t p j) = encode k s (.sel u q l)) :
    t=u ∧ p=q ∧ j=l := by
  have hi := selector_interval k s t p j h
  have gi := selector_interval k s u q l g
  have htu : t=u := by
    by_contra hn
    rcases lt_or_gt_of_ne hn with hl | hl
    · have hm := start_mono k (show t+1≤u from hl); omega
    · have hm := start_mono k (show u+1≤t from hl); omega
  subst u
  have hp := h.2.1
  have hq := g.2.1
  have hj := h.2.2
  have hl := g.2.2
  simp only [encode] at he
  have hpq : p=q := by
    interval_cases p <;> interval_cases q <;> simp_all <;> omega
  subst q
  exact ⟨rfl,rfl,by omega⟩

theorem product_injective (a b c d m : Nat) (hb : b<m) (hd : d<m)
    (h : a*m+b=c*m+d) : a=c ∧ b=d := by
  have hac : a=c := by
    by_contra hn
    rcases lt_or_gt_of_ne hn with hl | hl
    · have hh := Nat.mul_le_mul_right m (show a+1≤c from hl); nlinarith
    · have hh := Nat.mul_le_mul_right m (show c+1≤a from hl); nlinarith
  subst c
  exact ⟨rfl,by omega⟩

theorem encode_injective (k s : Nat) (w v : Wire)
    (hw : Valid k s w) (hv : Valid k s v) (he : encode k s w = encode k s v) : w=v := by
  cases w <;> cases v
  case sel.sel t p j u q l =>
    obtain ⟨rfl,rfl,rfl⟩ := selector_injective k s t p j u q l hw hv he
    rfl
  case fn.fn t ab u cd =>
    have hh : t*4+ab=u*4+cd := by simp only [encode] at he; omega
    obtain ⟨rfl,rfl⟩ := product_injective t ab u cd 4 hw.2 hv.2 hh
    rfl
  case port.port t p x u q y =>
    have hh : (2*t+p)*truthRows k+x=(2*u+q)*truthRows k+y := by
      simp only [encode] at he
      omega
    obtain ⟨hh,rfl⟩ := product_injective _ x _ y _ hw.2.2 hv.2.2 hh
    have hh' : t*2+p=u*2+q := by nlinarith
    obtain ⟨rfl,rfl⟩ := product_injective t p u q 2 hw.2.1 hv.2.1 hh'
    rfl
  case val.val t x u y =>
    have hh : t*truthRows k+x=u*truthRows k+y := by
      simp only [encode] at he
      omega
    obtain ⟨rfl,rfl⟩ := product_injective t x u y _ hw.2 hv.2 hh
    rfl
  all_goals
    first
    | have ha := selector_block _ _ _ _ _ hw
      first
      | have hb := fn_block _ _ _ _ hv; omega
      | have hb := port_block _ _ _ _ _ hv; omega
      | have hb := val_block _ _ _ _ hv; omega
    | have ha := fn_block _ _ _ _ hw
      first
      | have hb := selector_block _ _ _ _ _ hv; omega
      | have hb := port_block _ _ _ _ _ hv; omega
      | have hb := val_block _ _ _ _ hv; omega
    | have ha := port_block _ _ _ _ _ hw
      first
      | have hb := selector_block _ _ _ _ _ hv; omega
      | have hb := fn_block _ _ _ _ hv; omega
      | have hb := val_block _ _ _ _ hv; omega
    | have ha := val_block _ _ _ _ hw
      first
      | have hb := selector_block _ _ _ _ _ hv; omega
      | have hb := fn_block _ _ _ _ hv; omega
      | have hb := port_block _ _ _ _ _ hv; omega

#print axioms encode_bounds
#print axioms encode_injective
end L3Emitter.FamilyNamespace

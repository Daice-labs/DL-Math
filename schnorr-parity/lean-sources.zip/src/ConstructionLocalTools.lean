import CanonicalFamilyEnvelope
import RecordedGate
import RecordedActivation

namespace L3Emitter.ConstructionLocalTools
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation AuditLocalCosts CanonicalReplayEnvelope RecordedReplayCost

theorem fromTape (D : List Row) (ts : List Tok) :
    tokens (RecordedLocal.fromTape D ts)=ts.length := by simp [tokens,RecordedLocal.fromTape]
theorem old (D : List Row) (C G : Row) : tokens (RecordedLocal.old D C G)=3 := by
  simp [RecordedLocal.old,fromTape,RecordedLocal.oldTape]
theorem taut (D : List Row) (C G : Row) : tokens (RecordedLocal.taut D C G)=1 := by
  simp [RecordedLocal.taut,fromTape]
theorem cover (D : List Row) (C G : Row) : tokens (RecordedLocal.cover D C G)=3 := by
  simp [RecordedLocal.cover,fromTape]

theorem append (B : Nat) (p q : Program) (hp : BoundedProgram B p) (hq : BoundedProgram B q) :
    BoundedProgram B (p++q) := by
  intro c hc
  rcases List.mem_append.mp hc with hc|hc
  · exact hp c hc
  · exact hq c hc

theorem pol (B : Nat) (R : Row) (ts : List Tok) : BoundedGoals B (certificates (.pol R ts)) := by
  simp [BoundedGoals,certificates]
theorem polProgram (B : Nat) (p : AliasProgram.Program) : BoundedProgram B (RecordedBaseTwo.polProgram p) := by
  intro c hc
  obtain ⟨d,hd,rfl⟩:=List.mem_map.mp hc
  exact pol B d.1 d.2

theorem consequence (B : Nat) (R : Row) (p : Certificate) (hp : tokens p≤B) :
    BoundedGoals B (certificates (.consequence R p)) := by
  intro q hq
  have he:q=p:=List.mem_singleton.mp hq
  subst q
  exact hp

theorem redMap {α : Type} (B : Nat) (C : Row) (w : FiniteWitness.Data)
    (xs : List α) (f : α→Certificate) (hf : ∀x∈xs,tokens (f x)≤B) :
    BoundedGoals B (certificates (.red C w (xs.map f))) := by
  intro p hp
  obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hp
  exact hf x hx

/-- Every fresh gate's RED goal has at most THREE POL TOKENS, even though
there is one explicit certificate per retained database row. -/
theorem gateGoal (D : List Row) (C : Row) (q : Nat) (b : Bool) (R : Row) :
    tokens (RecordedGate.goal D C q b R)≤3 := by
  unfold RecordedGate.goal
  dsimp only
  split
  · rw [old]
  · split
    · rw [taut];omega
    · rw [cover]

theorem gateStep (D : List Row) (ps : List REDWitness.GateRow) (g : REDWitness.GateRow) (q : Nat) :
    BoundedGoals 3 (certificates (RecordedGate.step D ps g q)) :=
  redMap _ _ _ _ _ (by intros;exact gateGoal ..)

theorem gateProgram (D : List Row) (q : Nat) (ps gs : List REDWitness.GateRow) :
    BoundedProgram 3 (RecordedGate.program D q ps gs) := by
  induction gs generalizing ps with
  | nil=>simp [RecordedGate.program,BoundedProgram]
  | cons g gs ih=>
    intro c hc
    rcases List.mem_cons.mp hc with rfl|hc
    · exact gateStep D ps g q
    · exact ih (ps++[g]) c hc

theorem activationGoal (D : List Row) (C : Row) (w : FiniteWitness.Data) (R : Row) :
    tokens (RecordedActivation.goal D C w R)≤3 := by
  unfold RecordedActivation.goal
  dsimp only
  split
  · rw [old]
  · rw [taut];omega

theorem activation (D inputs : List Row) (a : Row→Nat) (q : Nat) (w : FiniteWitness.Data) :
    BoundedGoals 3 (certificates (RecordedActivation.activate D inputs a q w)) :=
  redMap _ _ _ _ _ (by intros;exact activationGoal ..)

theorem cancel (B : Nat) (D inputs : List Row) (a : Row→Nat) (q : Nat) :
    BoundedProgram B (RecordedActivation.cancel D a q inputs) := by
  induction inputs generalizing D with
  | nil=>simp [RecordedActivation.cancel,BoundedProgram]
  | cons R rs ih=>
    intro c hc
    rcases List.mem_cons.mp hc with rfl|hc
    · exact pol B R _
    · exact ih (D++[R]) c hc

#print axioms gateProgram
#print axioms activation
#print axioms cancel
end L3Emitter.ConstructionLocalTools

import ValueInductionBranches
import FirstGateSource
namespace L3Emitter.FirstUnaryMux
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases RecordedExpressions
variable {base:List Row} {w:Nat}

def job (c a b:Bit) (z:Net base):RecordedExpressions.Job :=
  ⟨c,a,b,(AND [c,a] z).1,(AND [neg c,b] (AND [c,a] z).2).1,(MUX c a b z).1⟩

def snapshot (c:Config Bit) (as:Nat→AliasBits w) (z:Net base) (b:Bool):RecordedExpressions.Job :=
  job c.B (c.fn 0 true b) (c.fn 0 false b)
    (CoordinateSnapshots.start c as 0 z (UnarySnapshots.position w b))

theorem coordinate_binding (c:Config Bit) (l r:AliasBits w) (b:Bool) (z:Net base):
    (coordinate c 0 l r (UnarySnapshots.position w b)).compile z=
      MUX c.B (c.fn 0 true b) (c.fn 0 false b) z := by
  cases b <;> simp [coordinate,UnarySnapshots.position,Expr.compile]

theorem output_binding (c:Config Bit) (as:Nat→AliasBits w) (z:Net base) (b:Bool):
    (snapshot c as z b).q=(step c as 0 z).1 (UnarySnapshots.position w b) := by
  have h:=CoordinateSnapshots.tabulate_at (w+2)
    (fun j=>(coordinate c 0 (CoordinateSnapshots.left c as 0 z).1 (CoordinateSnapshots.right c as 0 z).1 j).compile)
    (CoordinateSnapshots.right c as 0 z).2 (UnarySnapshots.position w b)
  rw [coordinate_binding] at h
  exact h.symm

theorem ready (c:Config Bit) (as:Nat→AliasBits w) (z:Net base) (b:Bool):
    Ready (step c as 0 z).2.rows (snapshot c as z b) := by
  have h:Ready (MUX c.B (c.fn 0 true b) (c.fn 0 false b)
      (CoordinateSnapshots.start c as 0 z (UnarySnapshots.position w b))).2.rows (snapshot c as z b):=
    ConcreteMux.actual_inputs _ _ _ _
  apply h.mono
  rw [←coordinate_binding c (CoordinateSnapshots.left c as 0 z).1 (CoordinateSnapshots.right c as 0 z).1 b]
  exact CoordinateSnapshots.tabulate_after _ _ (fun j=>Expr.extends _) _ _

def actual (n:Nat) (hn:2≤n) (b:Bool):=snapshot (PrimaryAliasBank.cfg n hn)
  (FirstPortRelations.initialAliases n hn) (PrimaryAliasBank.context n hn).2 b

theorem actual_output (n:Nat) (hn:2≤n) (b:Bool):
    (actual n hn b).q=CofactorValueRows.unary n hn 0 b := by
  unfold CofactorValueRows.unary
  simp only [Nat.add_zero]
  rw [FirstGateSource.built_zero]
  exact output_binding _ _ _ b

theorem actual_ready (n:Nat) (hn:2≤n) (b:Bool):Ready (SharedValueBank.result n hn) (actual n hn b):=by
  have h:=ready (PrimaryAliasBank.cfg n hn) (FirstPortRelations.initialAliases n hn)
    (PrimaryAliasBank.context n hn).2 b
  apply h.mono
  intro R hr
  apply SharedValueBank.gamma_retained n hn
  apply EarlierPortValues.unary_keep n hn
  apply CofactorValueRows.alias_keep n hn
  exact GateSnapshots.rows_retained n hn 0 (by omega) R hr

def program (n:Nat) (hn:2≤n) (D:List Row):=RecordedExpressions.program D [actual n hn false,actual n hn true]
def rows (n:Nat) (hn:2≤n):=[actual n hn false,actual n hn true].flatMap RecordedExpressions.jobRows

theorem checks (n:Nat) (hn:2≤n) (D:List Row) (hd:∀R∈SharedValueBank.result n hn,R∈D):
    AliasProgram.check D (program n hn D)=some (D++rows n hn):=by
  apply RecordedExpressions.checks
  intro j hj
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hj
  rcases hj with rfl|rfl <;> exact (actual_ready n hn _).mono hd

#print axioms actual_output
#print axioms actual_ready
#print axioms checks
end L3Emitter.FirstUnaryMux

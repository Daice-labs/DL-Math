import ConstructionFrontendBounds
import ConstructionTransportTools

namespace L3Emitter.ConstructionTransportBounds
open EREF EREF.GeneralRED RecordedScopedTrace CanonicalReplayEnvelope
open ConstructionLocalTools ConstructionFreshBounds ConstructionFoldBounds ConstructionTransportTools

def cap (k : Nat) := 700*(k+1)

theorem lift3 (k : Nat) (p : Program) (h : BoundedProgram 3 p) : BoundedProgram (cap k) p :=
  CanonicalFamilyEnvelope.bounded_mono _ _ _ (by unfold cap;omega) h

theorem branch (k : Nat) (hk : 3≤k) : BoundedProgram (cap k) (RecordedBranchSelection.program k hk) := by
  apply append
  · apply append
    · exact CanonicalFamilyEnvelope.bounded_mono _ _ _ (by unfold cap;omega)
        (ConstructionFrontendBounds.frontend k (3*k-4) (by omega) (by omega))
    · exact onePol _ _ _
  · exact lift3 k _ (priority _ _ _)

theorem cofactorSelection (k : Nat) (hk : 3≤k) :
    BoundedProgram (cap k) (RecordedCofactorSelection.program k hk) := by
  apply append
  · apply append
    · apply append
      · apply append
        · exact append _ _ _ (branch k hk) (lift3 k _ (forcing k hk))
        · exact lift3 k _ (priority _ _ _)
      · exact lift3 k _ (onehot _ _ _ _)
    · exact lift3 k _ (defs _ _)
  · exact lift3 k _ (selected _ _ _ _)

theorem constant (n : Nat) (hn : 2≤n) :
    BoundedProgram (cap (n+1)) (RecordedConstantTransport.program n hn) := by
  unfold RecordedConstantTransport.program RecordedConstantTransport.betaPortProgram
    RecordedConstantTransport.primaryProgram RecordedConstantTransport.fieldsProgram
    RecordedConstantTransport.cofactorProgram RecordedConstantTransport.bankProgram
  exact (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (cofactorSelection (n+1) (by omega)) (lift3 (n+1) _ (cofactor _ _ _ _ _))) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _))

theorem aliases (n : Nat) (hn : 2≤n) : BoundedProgram 3 (RecordedAliasBanks.program n hn) :=
  append 3 _ _ (append 3 _ _ (network _ _) (polProgram 3 _)) (polProgram 3 _)

theorem transport (n : Nat) (hn : 2≤n) :
    BoundedProgram (cap (n+1)) (RecordedTransportPrefix.program n hn) := by
  unfold RecordedTransportPrefix.program RecordedTransportPrefix.selectorProgram
    RecordedTransportPrefix.unaryProgram RecordedTransportPrefix.rawProgram
    RecordedTransportPrefix.outputProgram RecordedTransportPrefix.inputProgram
    RecordedTransportPrefix.gammaProgram RecordedTransportPrefix.wireProgram RecordedTransportPrefix.rankProgram
  exact (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (append _ _ _ (constant n hn) (rank _ _ _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (polProgram _ _)) (lift3 (n+1) _ (rawRun n hn _ _))) (polProgram _ _)) (polProgram _ _)) (lift3 (n+1) _ (aliases n hn)))

#print axioms cofactorSelection
#print axioms transport
end L3Emitter.ConstructionTransportBounds

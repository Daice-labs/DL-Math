import NativeScopedLocalGoal
import RecordedScopedTrace
namespace L3Emitter.NativeREDGoalSequence
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

structure Built where
  store : Store
  blocks : List (Row×NativeScopedLocalGoal.Built)

def compile (base : List Row) (C : Row) (w : FiniteWitness.Data)
    (s : Store) (ids : Nat→Nat) : List Row→List RecordedRefutation.Certificate→Built
  | R::rs,p::ps=>
    let G:=substRow R (FiniteWitness.interpret w)
    let block:=NativeScopedLocalGoal.compile (base.length+1) s ids G p
    let rest:=compile base C w block.closedStore ids rs ps
    ⟨rest.store,(G,block)::rest.blocks⟩
  | _,_=>⟨s,[]⟩

def execute (s : Store) : List (Row×NativeScopedLocalGoal.Built)→Option Store
  | []=>some s
  | (G,b)::rest=>do
    let t ← NativeScopedLocalGoal.execute s G b
    execute t rest

theorem correct (base : List Row) (C : Row) (w : FiniteWitness.Data)
    (s : Store) (ids : Nat→Nat) (rs : List Row) (ps : List RecordedRefutation.Certificate)
    (hs : 0<s.next) (he : Embeds (base++[negate C]) s ids)
    (hp : checkGoals base C w rs ps=true) :
    execute s (compile base C w s ids rs ps).blocks=some (compile base C w s ids rs ps).store ∧
    Embeds (base++[negate C]) (compile base C w s ids rs ps).store ids ∧
    s.next≤(compile base C w s ids rs ps).store.next ∧
    (compile base C w s ids rs ps).blocks.length=rs.length := by
  induction rs generalizing ps s with
  | nil=>cases ps <;> simp_all [checkGoals,compile,execute]
  | cons R rs ih=>
    cases ps with
    | nil=>simp [checkGoals] at hp
    | cons p ps=>
      obtain ⟨hhead,htail⟩:=Bool.and_eq_true_iff.mp hp
      have hh:=NativeScopedLocalGoal.correct (base++[negate C]) s ids
        (substRow R (FiniteWitness.interpret w)) hs he p (by simpa only [List.append_assoc,List.singleton_append] using hhead)
      have hl : (base++[negate C]).length=base.length+1:=by simp
      rw [hl] at hh
      have hi:=ih (NativeScopedLocalGoal.compile (base.length+1) s ids (substRow R (FiniteWitness.interpret w)) p).closedStore ps
        (by rw [hh.2.2];omega) hh.2.1 htail
      refine ⟨?_,hi.2.1,?_,?_⟩
      · simp only [compile,execute,hh.1,bind,Option.bind]
        exact hi.1
      · change s.next≤(compile base C w
          (NativeScopedLocalGoal.compile (base.length+1) s ids (substRow R (FiniteWitness.interpret w)) p).closedStore ids rs ps).store.next
        have h:=hi.2.2.1
        rw [hh.2.2] at h
        omega
      · simpa only [compile,List.length_cons] using congrArg (fun x=>x+1) hi.2.2.2

/-- Close the outer RED subproof and allocate the new row after all local
physical IDs. The outer embedding survives the holes left by scope closure. -/
def finish (base : List Row) (C : Row) (w : FiniteWitness.Data) (s : Store)
    (ids : Nat→Nat) (ps : List RecordedRefutation.Certificate) : Store :=
  let start:=push s (negate C)
  let goals:=compile base C w start (extend ids base.length s.next) (C::base) ps
  push (closeFrom goals.store s.next) C

def finishedIds (base : List Row) (C : Row) (w : FiniteWitness.Data) (s : Store)
    (ids : Nat→Nat) (ps : List RecordedRefutation.Certificate) : Nat→Nat :=
  let start:=push s (negate C)
  let goals:=compile base C w start (extend ids base.length s.next) (C::base) ps
  extend ids base.length goals.store.next

theorem finished_embedding (base : List Row) (C : Row) (w : FiniteWitness.Data)
    (s : Store) (ids : Nat→Nat) (ps : List RecordedRefutation.Certificate)
    (hs : 0<s.next) (he : Embeds base s ids)
    (hp : checkGoals base C w (C::base) ps=true) :
    Embeds (base++[C]) (finish base C w s ids ps) (finishedIds base C w s ids ps) := by
  have hh:=correct base C w (push s (negate C)) (extend ids base.length s.next) (C::base) ps
    (by dsimp [push];omega) (push_embeds base s ids he hs (negate C)) hp
  have old : Embeds base (compile base C w (push s (negate C)) (extend ids base.length s.next) (C::base) ps).store ids := by
    intro i R hR
    have hi:=dbOf_le_length base i R hR
    have hr:dbOf (base++[negate C]) i=some R:=by rw [dbOf_append_le base [negate C] i hi];exact hR
    have ho:=hh.2.1 i R hr
    simpa only [extend,if_neg (show i≠base.length+1 by omega)] using ho
  have closed:=close_preserves base _ ids old s.next (fun i R hR=>(he i R hR).2.1)
  exact push_embeds base _ ids closed (lt_of_lt_of_le (show 0<(push s (negate C)).next from by change 0<s.next+1;omega) hh.2.2.1) C

#print axioms correct
#print axioms finished_embedding
end L3Emitter.NativeREDGoalSequence

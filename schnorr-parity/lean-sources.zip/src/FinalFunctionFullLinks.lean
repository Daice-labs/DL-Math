import FinalFunctionCases
namespace L3Emitter.FinalFunctionFullLinks
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire
abbrev Case:=Bool×Bool×Bool×Bool
-- unary(0), unary(1), retained-last-coordinate, output phase
def uv (c:Case) (r:Bool):Bool:=if r then c.2.1 else c.1
def predicted (c:Case) (a r:Bool):Bool:=(uv c (if c.2.2.1 then r else a))^^c.2.2.2
def guards (n:Nat) (hn:2≤n) (c:Case):List Int:=
  [-sign c.1 (unary n hn false),-sign c.2.1 (unary n hn true),
   -sign c.2.2.1 (H n hn),-sign c.2.2.2 (OutputPhaseRows.phase n hn)]
def input (ab:Fin 4):Bool:=decide (ab.val/2≠0)
def raw (n:Nat) (hn:2≤n) (ab:Fin 4):=FinalFunctionCases.raw n hn ab
def q (n:Nat) (hn:2≤n) (ab:Fin 4):=(built n hn).1.functions ab
def short (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool):List Int:=
  if c.2.2.1 then
    [-sign r (raw n hn ab),-sign (uv c r) (unary n hn r),-(H n hn).val,
     -sign c.2.2.2 (OutputPhaseRows.phase n hn),sign (predicted c (input ab) r) (q n hn ab)]
  else [(H n hn).val,-sign (uv c (input ab)) (unary n hn (input ab)),
     -sign c.2.2.2 (OutputPhaseRows.phase n hn),sign (predicted c (input ab) r) (q n hn ab)]
def extra (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool):List Int:=
  if c.2.2.1 then [-sign (uv c (!r)) (unary n hn (!r))]
  else [-sign (uv c (!(input ab))) (unary n hn (!(input ab))),-sign r (raw n hn ab)]
def row (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool):Row:=
  clause (guards n hn c++[-sign r (raw n hn ab),sign (predicted c (input ab) r) (q n hn ab)])

theorem guards_valid (n:Nat) (hn:2≤n) (c:Case):Valid (guards n hn c):=by simp [guards,Valid,sign_valid]
theorem short_valid (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool):Valid (short n hn c ab r):=by
  unfold short;split <;> simp [Valid,sign_valid,(H n hn).property]
theorem extra_valid (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool):Valid (extra n hn c ab r):=by
  unfold extra;split <;> simp [Valid,sign_valid]
theorem weakened (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool):
    clause (short n hn c ab r++extra n hn c ab r)=row n hn c ab r:=by
  apply canonical_ext _ _ (canonical_normalize _ _) (canonical_normalize _ _)
  intro α
  change (clause _).val α=(clause _).val α
  rw [val_clause _ (EvaluationCaseSeeds.valid_join (short_valid n hn c ab r) (extra_valid n hn c ab r)),
    val_clause _ (EvaluationCaseSeeds.valid_join (guards_valid n hn c) (by simp [Valid,sign_valid]))]
  cases hk:c.2.2.1 <;> cases ha:input ab <;> cases r <;>
    simp only [short,extra,guards,predicted,uv,hk,ha,sign,Bool.false_eq_true,↓reduceIte,Bool.not_false,Bool.not_true,
      sum_append,sum_cons,sum_nil] <;> ring

theorem job_mem (ab:Fin 4) (keep r v side:Bool) (hr : keep = false → r = false):
    (ab,keep,r,v,side)∈FinalFunctionCases.jobs:=by
  cases keep <;> cases r <;> cases v <;> cases side <;> simp_all [FinalFunctionCases.jobs]
theorem short_present (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool):
    clause (short n hn c ab r)∈FinalFunctionCases.result n hn:=by
  have add (j:FinalFunctionCases.Job) (hj:j∈FinalFunctionCases.jobs) (R:Row) (hR:R∈FinalFunctionCases.rows n hn j):
      R∈FinalFunctionCases.result n hn:=
    List.mem_append_right _ (RetainedBlockFold.contains _ _ j hj R hR)
  cases hk:c.2.2.1
  · have h:=add (ab,false,false,uv c (input ab),c.2.2.2) (job_mem ab false false _ _ (by simp)) _
      (List.mem_singleton_self _)
    have he:FinalFunctionCases.alternative n hn ab=unary n hn (input ab):=by
      unfold FinalFunctionCases.alternative input
      split <;> simp_all
    simpa only [FinalFunctionCases.rows,Bool.false_eq_true,↓reduceIte,FunctionChainPOL.chosenRows,guarded,
      List.cons_append,List.nil_append,he,short,hk,predicted,q] using h
  · have h:=add (ab,true,r,uv c r,c.2.2.2) (job_mem ab true r _ _ (by simp)) _ (List.mem_cons_of_mem _ (List.mem_singleton_self _))
    simpa only [FinalFunctionCases.rows,↓reduceIte,FunctionChainPOL.keptRows,FunctionChainPOL.sourceGuards,
      guarded,List.cons_append,List.nil_append,short,hk,predicted,q,raw] using h

def tape (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool) (D:List Row):=
  ChoiceProjection.weakenTokens D (short n hn c ab r) (extra n hn c ab r)
theorem checks (n:Nat) (hn:2≤n) (c:Case) (ab:Fin 4) (r:Bool) (D:List Row)
    (hd:∀R∈FinalFunctionCases.result n hn,R∈D):
    polEval (dbOf D) (tape n hn c ab r D) []=some (row n hn c ab r):=by
  have h:=ChoiceProjection.weaken_succeeds D _ _ (short_valid n hn c ab r) (extra_valid n hn c ab r) (hd _ (short_present n hn c ab r))
  rw [weakened] at h
  exact h
#print axioms checks
end L3Emitter.FinalFunctionFullLinks

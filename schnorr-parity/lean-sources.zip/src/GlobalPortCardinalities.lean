import GlobalPortValues
namespace L3Emitter.GlobalPortCardinalities
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot

def Constraints (D:List Row) {w:Nat} (a:AliasBits w):Prop:=
  clause (sourceLiterals a)∈D ∧ Cardinality.amo (sourceLiterals a)∈D

theorem mono {D E:List Row} {w:Nat} {a:AliasBits w} (h:Constraints D a)
    (he:∀R∈D,R∈E):Constraints E a:=⟨he _ h.1,he _ h.2⟩

theorem result_retains (n:Nat) (hn:2≤n) (g m:Nat) (D:List Row):
    ∀R∈D,R∈GateOrderSources.result n hn g D m:=by
  induction m generalizing g D with
  | zero=>exact fun _ h=>h
  | succ m ih=>exact fun R h=>ih (g+1) _ R (GateOrderSources.step_retains n hn g D R h)

theorem step_ports (n:Nat) (hn:2≤n) (g p:Nat) (hp:p<2) (D:List Row):
    Constraints (GateOrderSources.stepResult n hn g D) (EarlierPortValues.portAlias n hn g p):=by
  have hw:0<AliasAssembly.width (n+1):=by unfold AliasAssembly.width RankConstruction.width;omega
  have hm:=MuxSourceStep.retains n hn g (GateOrderSources.afterRight n hn g D)
  have ht:=GateSourceOneHot.retains n hn g (GateOrderSources.afterMux n hn g D)
  by_cases h:p=0
  · subst p
    have hc:=SelectedVectorOneHot.final_rows D (GatePortOneHot.cs n hn g 0) (GatePortOneHot.target n hn g 0) hw
    exact mono hc (fun R hr=>ht R (hm R (GatePortOneHot.retains n hn g 1 _ R hr)))
  · have h1:p=1:=by omega
    subst p
    have hc:=SelectedVectorOneHot.final_rows (GateOrderSources.afterLeft n hn g D)
      (GatePortOneHot.cs n hn g 1) (GatePortOneHot.target n hn g 1) hw
    exact mono hc (fun R hr=>ht R (hm R hr))

theorem run_ports (n:Nat) (hn:2≤n) (g m target p:Nat) (hp:p<2) (hg:g≤target) (ht:target<g+m) (D:List Row):
    Constraints (GateOrderSources.result n hn g D m) (EarlierPortValues.portAlias n hn target p):=by
  induction m generalizing g D with
  | zero=>omega
  | succ m ih=>
    by_cases he:target=g
    · subst target
      exact mono (step_ports n hn g p hp D) (result_retains n hn (g+1) m _)
    · exact ih (g+1) (by omega) (by omega) (GateOrderSources.stepResult n hn g D)

theorem first_binding (n:Nat) (hn:2≤n) (p:Nat):
    EarlierPortValues.portAlias n hn 0 p=FirstPortOneHot.target n hn p:=rfl

theorem all_ports (n:Nat) (hn:2≤n) (g p:Nat) (hg:g<3*(n+1)-4) (hp:p<2):
    Constraints (GlobalPortValues.result n hn) (EarlierPortValues.portAlias n hn g p):=by
  have keep:∀R∈AllSourceCardinalities.result n hn,R∈GlobalPortValues.result n hn:=by
    intro R h
    apply GlobalPortValues.retained n hn
    apply GlobalValueInduction.retained n hn
    apply SharedValueBank.gamma_retained n hn
    apply EarlierPortValues.unary_keep n hn
    apply CofactorValueRows.unary_keep n hn
    exact UnaryRelationBank.retains n hn R h
  by_cases hz:g=0
  · subst g
    rw [first_binding]
    have h:=FirstPortOneHot.full_constraints n hn p hp
    apply mono h
    intro R hr
    apply keep
    apply List.mem_append_left
    apply result_retains
    exact SourceAuxBank.contains_category n hn R (CategoryBank.retains n hn R hr)
  · have h:=run_ports n hn 1 (3*(n+1)-5) g p hp (by omega) (by omega) (SourceAuxBank.result n hn)
    exact mono h (fun R hr=>keep R (List.mem_append_left _ hr))
#print axioms all_ports
end L3Emitter.GlobalPortCardinalities

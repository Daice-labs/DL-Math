import AliasClauseTransport
import ProjectionBytes

namespace L3Emitter.AliasBytes
open EREF REDWitness ReferenceTransport SelectedAlias AliasClauseTransport
open ClauseTransport PolTapeBytes ProjectionBytes

def bitDoc (rows : List Row) (c : Int) (b : Bit) : Doc :=
  tapeDoc (forwardTokens rows c b.source b.term b.target) ++
  tapeDoc (backTokens (rows++[clause [-c,-b.source,b.target]]) c b.source b.term b.target b.others)

def bitsDoc (rows : List Row) (c : Int) : List Bit → Doc
  | [] => []
  | b::bs => bitDoc rows c b ++ bitsDoc (rows++bitRows c b) c bs

def caseDoc (rows : List Row) (c : Int) (bs : List SignedBit) : Doc :=
  bitsDoc rows c (bs.map SignedBit.bit) ++ tapeDoc (caseTokens (rows++body c bs) c bs)

def BitBound (M P : Nat) (b : Bit) : Prop :=
  b.source.natAbs≤M ∧ b.target.natAbs≤M ∧ b.others.length≤P

theorem bit_bytes (M P : Nat) (rows : List Row) (c : Int) (b : Bit)
    (hrows : rows.length+2≤M) (hc : c.natAbs≤M) (hb : BitBound M P b) (hp : P+1≤M) :
    (emit (bitDoc rows c b)).length ≤ 14+(8*P+9)*(3+digits M) := by
  have hf := alias_forward_bytes M rows c b.source b.term b.target (by omega)
  have hr := alias_back_bytes M (rows++[clause [-c,-b.source,b.target]]) c b.source b.term b.target
    b.others (by simpa using hrows) hc hb.1 hb.2.1 (by have := hb.2.2; omega)
  have hl : (emit (bitDoc rows c b)).length =
      (emit (tapeDoc (forwardTokens rows c b.source b.term b.target))).length +
      (emit (tapeDoc (backTokens (rows++[clause [-c,-b.source,b.target]]) c b.source b.term b.target b.others))).length := by
    simp [bitDoc,emit]
  rw [hl]
  have hn := hb.2.2
  nlinarith

theorem bits_bytes (M P : Nat) (rows : List Row) (c : Int) (bs : List Bit)
    (hrows : rows.length+2*bs.length+1≤M) (hc : c.natAbs≤M)
    (hb : ∀b∈bs,BitBound M P b) (hp : P+1≤M) :
    (emit (bitsDoc rows c bs)).length ≤ bs.length*(14+(8*P+9)*(3+digits M)) := by
  induction bs generalizing rows with
  | nil => simp [bitsDoc,emit]
  | cons b bs ih =>
    have hh := bit_bytes M P rows c b (by simp only [List.length_cons] at hrows; omega)
      hc (hb b (by simp)) hp
    have ht := ih (rows++bitRows c b)
      (by simp only [List.length_append,bitRows,List.length_cons,List.length_nil] at *; omega)
      (by intro a ha; exact hb a (by simp [ha]))
    have he : (emit (bitsDoc rows c (b::bs))).length =
        (emit (bitDoc rows c b)).length+(emit (bitsDoc (rows++bitRows c b) c bs)).length := by
      simp [bitsDoc,emit]
    rw [he]
    simp only [List.length_cons]
    nlinarith

theorem body_length (c : Int) (bs : List SignedBit) : (body c bs).length=2*bs.length := by
  simp [body,bitBody,bitRows,List.length_flatMap,List.map_map,Function.comp_def]
  omega

theorem case_tape_count (rows : List Row) (c : Int) (bs : List SignedBit) :
    (caseTokens rows c bs).length ≤ 2+2*bs.length^2 := by
  rw [caseTokens,ClauseTransport.token_count]
  simp only [links,List.length_map]
  cases h : bs.length with
  | zero => simp
  | succ n => simp [pow_two]; ring_nf; omega

theorem case_tape_bytes (M : Nat) (rows : List Row) (c : Int) (bs : List SignedBit)
    (hrows : rows.length+1≤M) (hc : c.natAbs≤M) (hn : bs.length≤M)
    (hb : ∀b∈bs,b.bit.target.natAbs≤M) :
    (emit (tapeDoc (caseTokens rows c bs))).length ≤
      7+(2+2*bs.length^2)*(3+digits M) := by
  have ht : ∀t∈caseTokens rows c bs,Bounded M t := by
    apply tokens_bounded M _ (-c) (links rows c bs)
    · exact le_trans (locate_bound rows _) hrows
    · simpa using hc
    · simpa [links] using hn
    · intro p hp
      obtain ⟨b,hb',rfl⟩:=List.mem_map.mp hp
      constructor
      · have h := hb b hb'
        dsimp [LinkBound,link,Link.target,SignedBit.target]
        split <;> simpa using h
      · exact le_trans (locate_bound rows _) hrows
  have htape := tape_bound M _ ht
  have hn' := case_tape_count rows c bs
  nlinarith

/-- Actual emitted bytes for all two-direction alias links and the following
    clause-transport POL line. Reference widths include all newly added rows.
    This is a component bound, not the still-open full family recurrence. -/
theorem case_bytes (M P : Nat) (rows : List Row) (c : Int) (bs : List SignedBit)
    (hrows : rows.length+2*bs.length+1≤M) (hc : c.natAbs≤M) (hn : bs.length≤M)
    (hb : ∀b∈bs,BitBound M P b.bit) (hp : P+1≤M) :
    (emit (caseDoc rows c bs)).length ≤
      bs.length*(14+(8*P+9)*(3+digits M)) + 7+(2+2*bs.length^2)*(3+digits M) := by
  have hbits := bits_bytes M P rows c (bs.map SignedBit.bit) (by simpa using hrows) hc
    (by intro b hb'; obtain ⟨a,ha,rfl⟩:=List.mem_map.mp hb'; exact hb a ha) hp
  have hcase := case_tape_bytes M (rows++body c bs) c bs
    (by simpa [body_length] using hrows) hc hn (by intro b hb'; exact (hb b hb').2.1)
  have he : (emit (caseDoc rows c bs)).length =
      (emit (bitsDoc rows c (bs.map SignedBit.bit))).length+
      (emit (tapeDoc (caseTokens (rows++body c bs) c bs))).length := by simp [caseDoc,emit]
  rw [he]
  simp only [List.length_map] at hbits
  omega

#print axioms case_tape_count
#print axioms case_bytes
end L3Emitter.AliasBytes

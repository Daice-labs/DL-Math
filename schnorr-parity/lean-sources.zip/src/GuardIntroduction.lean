import GuardActivation
namespace L3Emitter.GuardIntroduction
open EREF EREF.GeneralRED REDWitness

def OldCovered (D:List Row) (ω:Witness):Prop:=
  ∀R∈D,Canonical R ∧ (substRow R ω=R ∨ ∀α,(substRow R ω).sat α)

/-- The actual q := false introduction witness makes every guarded input
tautological; no assumption that the lower formula is satisfiable is used. -/
theorem guard_off (R:Row) (hR:Canonical R) (a q:Nat) (hq:0<q)
    (hf:∀t∈R.terms,t.2.natAbs≠q) (ha:R.bound≤(a:Int)):
    ∀α,(substRow (GuardedFrame.weaken R a (-(q:Int))) (REDWitness.witness q false)).sat α:=by
  intro α
  unfold Row.sat
  rw [val_substRow,GuardedFrame.val_weaken R hR a _ (by omega)]
  have hfixed:=subst_old q false R hR hf
  have hv: R.val (applyWitness (REDWitness.witness q false) α)=R.val α:=by
    rw [←val_substRow,hfixed]
  rw [hv]
  have hneg:litVal (applyWitness (REDWitness.witness q false) α) (-(q:Int))=1:=by
    simp [litVal,apply_at,b2i]
  rw [hneg]
  have ht:=tval_nonneg α R.terms
  unfold Row.val
  omega

theorem step (D:List Row) (G:Row) (ω:Witness) (hc:Canonical G)
    (hd:OldCovered D ω) (ht:∀α,(substRow G ω).sat α):
    CheckedStep D (D++[G]):=by
  apply CheckedStep.red _ _ ω hc
  intro R hr
  rcases List.mem_cons.mp hr with rfl|hr
  · exact single_to_refutation _ _ _ (taut_certificate _ _ _ (canonical_substRow _ _) ht)
  · rcases (hd R hr).2 with he|he
    · rw [he]
      exact GuardActivation.member_certificate D _ R hr (hd R hr).1
    · exact single_to_refutation _ _ _ (taut_certificate _ _ _ (canonical_substRow _ _) he)

theorem covered_append (D:List Row) (G:Row) (ω:Witness) (hc:Canonical G)
    (hd:OldCovered D ω) (ht:∀α,(substRow G ω).sat α):OldCovered (D++[G]) ω:=by
  intro R hr
  rcases List.mem_append.mp hr with hr|hr
  · exact hd R hr
  · obtain rfl:=List.mem_singleton.mp hr
    exact ⟨hc,Or.inr ht⟩

theorem introduce (D inputs:List Row) (a:Row→Nat) (q:Nat) (ω:Witness)
    (hd:OldCovered D ω)
    (ht:∀R∈inputs,∀α,(substRow (GuardedFrame.weaken R (a R) (-(q:Int))) ω).sat α):
    GuardedReplay.Counted D (D++GuardActivation.bank inputs a q) inputs.length:=by
  induction inputs generalizing D with
  | nil=>simpa [GuardActivation.bank] using GuardedReplay.Counted.refl D
  | cons R rs ih=>
    let G:=GuardedFrame.weaken R (a R) (-(q:Int))
    have hc:Canonical G:=GuardedFrame.canonical_weaken _ _ _
    have hgt:∀α,(substRow G ω).sat α:=ht R (by simp)
    have tail:=ih (D++[G]) (covered_append D G ω hc hd hgt)
      (fun Q hQ=>ht Q (by simp [hQ]))
    simpa only [GuardActivation.bank,List.map_cons,List.length_cons,List.append_assoc,List.singleton_append]
      using GuardedReplay.Counted.cons (step D G ω hc hd hgt) tail

theorem fresh_bank (D inputs:List Row) (a:Row→Nat) (q:Nat) (hq:0<q)
    (hd:∀R∈D,Canonical R) (hi:∀R∈inputs,Canonical R)
    (hdf:∀R∈D,∀t∈R.terms,t.2.natAbs≠q)
    (hif:∀R∈inputs,∀t∈R.terms,t.2.natAbs≠q)
    (ha:∀R∈inputs,R.bound≤(a R:Int)):
    GuardedReplay.Counted D (D++GuardActivation.bank inputs a q) inputs.length:=by
  apply introduce D inputs a q (REDWitness.witness q false)
  · intro R hr
    exact ⟨hd R hr,Or.inl (subst_old q false R (hd R hr) (hdf R hr))⟩
  · intro R hr
    exact guard_off R (hi R hr) (a R) q hq (hif R hr) (ha R hr)

#print axioms fresh_bank
end L3Emitter.GuardIntroduction

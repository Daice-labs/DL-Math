import FinalLowerComplete
import ActivationNamespace
import WireEnumeration
namespace L3Emitter.LowerActivationImage
open EREF EREF.GeneralRED FamilyNamespace FamilyRows AliasNetwork GuardedGatePOL

/-- Finite executable lookup; no choice or search over proofs. -/
def lookup (k s:Nat) (f:Wire→Bit) (v:Nat):List Wire→Bit
  | []=>SelectedCoordinateBank.fallback
  | w::ws=>if encode k s w=v then f w else lookup k s f v ws

theorem lookup_at (k s:Nat) (f:Wire→Bit) (w:Wire) (hw:FamilyNamespace.Valid k s w)
    (ws:List Wire) (hm:w∈ws) (hv:∀u∈ws,FamilyNamespace.Valid k s u):
    lookup k s f (encode k s w) ws=f w:=by
  induction ws with
  | nil=>simp at hm
  | cons u us ih=>
    by_cases he:encode k s u=encode k s w
    · have e:=encode_injective k s u w (hv u (by simp)) hw he
      subst u;simp [lookup]
    · simp only [lookup,if_neg he]
      apply ih
      · rcases List.mem_cons.mp hm with h|h
        · subst u;exact False.elim (he rfl)
        · exact h
      · intro v h;exact hv v (by simp [h])

def image (n:Nat) (hn:2≤n) (v:Nat):Bit:=
  lookup n (3*n-4) (FinalLowerImage.wire n hn) v (WireEnumeration.all n (3*n-4))
theorem image_at (n:Nat) (hn:2≤n) (w:Wire) (hw:FamilyNamespace.Valid n (3*n-4) w):
    image n hn (encode n (3*n-4) w)=FinalLowerImage.wire n hn w:=
  lookup_at _ _ _ w hw _ ((WireEnumeration.mem_all ..).mpr hw)
    (fun u h=>(WireEnumeration.mem_all ..).mp h)

/-- Actual offset encoding uses M+v; positivity is supplied by valid original IDs. -/
def shiftedLit (M k s:Nat) (l:NamedLit):Int:=
  if l.2 then ((M+encode k s l.1:Nat):Int) else -((M+encode k s l.1:Nat):Int)
def shiftedRow (M k s:Nat) (r:Spec):Row:=normalize (r.literals.map fun l=>(1,shiftedLit M k s l)) r.rhs

theorem shifted_nonzero (M k s:Nat) (l:NamedLit) (hl:FamilyNamespace.Valid k s l.1):shiftedLit M k s l≠0:=by
  have h:0<encode k s l.1:=(encode_bounds k s _ hl).1
  unfold shiftedLit;split <;> omega

theorem shifted_value (M k s:Nat) (r:Spec) (hr:r.valid k s) (α:Val):
    (shiftedRow M k s r).val α=REDWitness.sum α (r.literals.map (shiftedLit M k s))-r.rhs:=by
  unfold shiftedRow
  rw [val_normalize]
  · have h:∀ls:List NamedLit,tvalZ α (ls.map fun l=>(1,shiftedLit M k s l))=REDWitness.sum α (ls.map (shiftedLit M k s)):=by
      intro ls;induction ls with
      | nil=>rfl
      | cons l ls ih=>simp [tvalZ,REDWitness.sum,ih]
    rw [h]
  · intro t ht;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp ht
    exact shifted_nonzero M k s l (hr l hl)

theorem literal_image (n:Nat) (hn:2≤n) (M N:Nat) (hN:variableCount n (3*n-4)≤N)
    (l:NamedLit) (hl:FamilyNamespace.Valid n (3*n-4) l.1) (α:Val):
    litVal (applyWitness (ActivationNamespace.witness M (variableCount n (3*n-4)) N (image n hn)) α)
      (shiftedLit M n (3*n-4) l)=litVal α (sign l.2 (FinalLowerImage.wire n hn l.1)):=by
  have hb:=encode_bounds n (3*n-4) l.1 hl
  have hw:=ActivationNamespace.lower_image M (variableCount n (3*n-4)) N (encode n (3*n-4) l.1) (image n hn) hb.1 hb.2 hN
  rw [image_at n hn l.1 hl] at hw
  rcases l with ⟨w,b⟩
  dsimp only at hb hw
  have hp:(0:Int)<((M+encode n (3*n-4) w:Nat):Int):=by omega
  have he:litVal (applyWitness (ActivationNamespace.witness M (variableCount n (3*n-4)) N (image n hn)) α)
      ((M+encode n (3*n-4) w:Nat):Int)=litVal α (FinalLowerImage.wire n hn w).val:=by
    conv_lhs => unfold litVal
    rw [if_pos hp,Int.natAbs_natCast]
    change b2i ((ActivationNamespace.witness M (variableCount n (3*n-4)) N (image n hn) (M+encode n (3*n-4) w)).eval α)=_
    rw [hw]
    exact eval_literal α _ _
  cases b <;> simp only [shiftedLit,Bool.false_eq_true,↓reduceIte,sign]
  · rw [litVal_neg _ _ (by omega),litVal_neg _ _ (FinalLowerImage.wire n hn w).property,he]
  · exact he

theorem image_value (n:Nat) (hn:2≤n) (r:Spec) (α:Val):
    (FinalLowerImage.image n hn r).val α=
      REDWitness.sum α (r.literals.map fun l=>sign l.2 (FinalLowerImage.wire n hn l.1))-r.rhs:=by
  unfold FinalLowerImage.image
  rw [val_normalize]
  · have h:∀ls:List NamedLit,tvalZ α (ls.map fun l=>(1,sign l.2 (FinalLowerImage.wire n hn l.1)))=REDWitness.sum α (ls.map fun l=>sign l.2 (FinalLowerImage.wire n hn l.1)):=by
      intro ls;induction ls with
      | nil=>rfl
      | cons l ls ih=>simp [tvalZ,REDWitness.sum,ih]
    rw [h]
  · intro t ht;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp ht;exact sign_valid _ _

theorem subst_shifted_row (n:Nat) (hn:2≤n) (M N:Nat) (hN:variableCount n (3*n-4)≤N)
    (r:Spec) (hr:r.valid n (3*n-4)):
    substRow (shiftedRow M n (3*n-4) r)
      (ActivationNamespace.witness M (variableCount n (3*n-4)) N (image n hn))=
      FinalLowerImage.image n hn r:=by
  apply canonical_ext _ _ (canonical_substRow _ _) (canonical_normalize _ _)
  intro α
  change (substRow (shiftedRow M n (3*n-4) r) _).val α=(FinalLowerImage.image n hn r).val α
  rw [val_substRow,shifted_value _ _ _ _ hr,image_value]
  unfold REDWitness.sum
  simp only [List.map_map,Function.comp_def]
  congr 2
  apply List.map_congr_left
  intro l hl;exact literal_image n hn M N hN l (hr l hl) α

def inputs (n:Nat) (M:Nat):List Row:=(OriginalEncoding.specs n (3*n-4)).map (shiftedRow M n (3*n-4))
theorem all_activation_images (n:Nat) (hn:2≤n) (M N:Nat) (hN:variableCount n (3*n-4)≤N):
    ∀R∈inputs n M,substRow R (ActivationNamespace.witness M (variableCount n (3*n-4)) N (image n hn))∈FinalLowerComplete.result n hn:=by
  intro R h;obtain ⟨r,hr,rfl⟩:=List.mem_map.mp h
  rw [subst_shifted_row n hn M N hN r (InputSwap.original_valid _ _ _ ((OriginalEncoding.spec_mem_iff _ _ (by omega) r).mp hr))]
  exact FinalLowerComplete.every_original_row_image n hn r hr
#print axioms subst_shifted_row
#print axioms all_activation_images
end L3Emitter.LowerActivationImage

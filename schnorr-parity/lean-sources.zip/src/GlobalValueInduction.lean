import ExhaustiveValueJoin
import FirstGateBase
namespace L3Emitter.GlobalValueInduction
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram
abbrev Job:=FirstGateBase.Job

def stepRows (n:Nat) (hn:2≤n) (g:Nat):=(FirstGateBase.jobs n).flatMap fun j=>ExhaustiveValueJoin.rows n hn g j.1 j.2.1 j.2.2.1 j.2.2.2
def step (n:Nat) (hn:2≤n) (g:Nat) (D:List Row):Program:=RetainedBlockFold.run
  (fun j:Job n=>ExhaustiveValueJoin.program n hn g j.1 j.2.1 j.2.2.1 j.2.2.2)
  (fun j:Job n=>ExhaustiveValueJoin.rows n hn g j.1 j.2.1 j.2.2.1 j.2.2.2) (FirstGateBase.jobs n) D

theorem step_checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) (D:List Row)
    (hd:∀R∈SharedValueBank.result n hn,R∈D) (hi:ValueInductionBranches.Before n hn g D):
    check D (step n hn g D)=some (D++stepRows n hn g):=by
  apply RetainedBlockFold.checks D _ _ (fun j:Job n=>j.1<FamilyNamespace.truthRows n) _ _
    (fun j hj=>(FirstGateBase.job_mem _ _).mp hj) D (fun _ h=>h)
  intro j hj E hE
  exact ExhaustiveValueJoin.checks n hn g hg hs j.1 hj j.2.1 j.2.2.1 j.2.2.2 E
    (fun R h=>hE R (hd R h)) (ValueInductionBranches.before_mono n hn g hi hE)

theorem step_before (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) (hi:ValueInductionBranches.Before n hn g D):
    ValueInductionBranches.Before n hn (g+1) (D++stepRows n hn g):=by
  intro h hh x hx i b v
  by_cases hg:h<g
  · exact List.mem_append_left _ (hi h hg x hx i b v)
  · have he:h=g:=by omega
    subst h
    apply List.mem_append_right
    exact List.mem_flatMap.mpr ⟨(x,i,b,v),(FirstGateBase.job_mem _ _).mpr hx,List.mem_append_right _ (List.mem_singleton_self _)⟩

def rows (n:Nat) (hn:2≤n) (g:Nat):Nat→List Row
  | 0=>[]
  | m+1=>stepRows n hn g++rows n hn (g+1) m
def run (n:Nat) (hn:2≤n) (g:Nat):Nat→List Row→Program
  | 0,_=>[]
  | m+1,D=>step n hn g D++run n hn (g+1) m (D++stepRows n hn g)

theorem run_checks (n:Nat) (hn:2≤n) (g m:Nat) (hg:0<g) (hs:g+m≤3*(n+1)-4) (D:List Row)
    (hd:∀R∈SharedValueBank.result n hn,R∈D) (hi:ValueInductionBranches.Before n hn g D):
    check D (run n hn g m D)=some (D++rows n hn g m) ∧
      ValueInductionBranches.Before n hn (g+m) (D++rows n hn g m):=by
  induction m generalizing g D with
  | zero=>simp only [run,rows,check,List.append_nil,Nat.add_zero]; exact ⟨True.intro,hi⟩
  | succ m ih=>
    have h0:=step_checks n hn g hg (by omega) D hd hi
    have h1:=ih (g+1) (by omega) (by omega) (D++stepRows n hn g)
      (fun R h=>List.mem_append_left _ (hd R h)) (step_before n hn g D hi)
    constructor
    · simpa only [run,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h1.1
    · simpa only [rows,List.append_assoc,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using h1.2

def program (n:Nat) (hn:2≤n):=run n hn 1 (3*(n+1)-5) (FirstGateBase.result n hn)
def result (n:Nat) (hn:2≤n):=FirstGateBase.result n hn++rows n hn 1 (3*(n+1)-5)

theorem checks (n:Nat) (hn:2≤n):check (FirstGateBase.result n hn) (program n hn)=some (result n hn):=
  (run_checks n hn 1 (3*(n+1)-5) (by decide) (by omega) _ (FirstGateBase.retained n hn) (FirstGateBase.first_gate_base n hn)).1

theorem global_value_induction (n:Nat) (hn:2≤n):ValueInductionBranches.Before n hn (3*(n+1)-4) (result n hn):=by
  have h:=(run_checks n hn 1 (3*(n+1)-5) (by decide) (by omega) _ (FirstGateBase.retained n hn) (FirstGateBase.first_gate_base n hn)).2
  have he:1+(3*(n+1)-5)=3*(n+1)-4:=by omega
  simpa only [he] using h

theorem retained (n:Nat) (hn:2≤n):∀R∈SharedValueBank.result n hn,R∈result n hn:=
  fun R h=>List.mem_append_left _ (FirstGateBase.retained n hn R h)

theorem original_to_global_values (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FirstGateBase.original_to_base n hn) (check_trace _ _ _ (checks n hn))

#print axioms run_checks
#print axioms global_value_induction
#print axioms original_to_global_values
end L3Emitter.GlobalValueInduction

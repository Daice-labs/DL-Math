import ForcingFamily

namespace L3Emitter.ForcingSize
open EREF REDWitness AliasProgram PrioritySize
open ForcingBinding ForcingProgram ForcingConstruction ForcingFamily

theorem rebase_length (src dst : List Row) (p : Program) : (ProgramRebase.program src dst p).length=p.length := by
  have h:=congrArg List.length (ProgramRebase.outputs_preserved src dst p)
  simpa [outputs] using h

theorem derived_lines (D : List Row) (k : Nat) (hk : 3≤k) (c : RankProjection.Choice (3*k-4)) (m : Nat) :
    (derivedProgram D k hk c m).length=5 := by
  simp [derivedProgram,rebase_length,prepProgram,ForcingProgram.program]

theorem derived_tokens (D : List Row) (k : Nat) (hk : 3≤k) (c : RankProjection.Choice (3*k-4)) (m : Nat) :
    tokensCount (derivedProgram D k hk c m)=74 := by
  unfold derivedProgram
  rw [tokens_append]
  have hr:=ProgramRebase.tokens_preserved (FrontendSelection.finalRows k hk)
    (D++(input k hk c).rows m) (prepProgram k hk c)
  change tokensCount _=tokensCount _ at hr
  rw [hr]
  simp [tokensCount,prepProgram,PriorityExclusive.tokens,ForcingProgram.program,
    ForcingPOL.port_token_count,ForcingPOL.gate_token_count]

def pols (D : List Row) (k : Nat) (hk : 3≤k) (m : Nat) : List (RankProjection.Choice (3*k-4))→Program
  | [] => []
  | c::cs => derivedProgram D k hk c m ++ pols (step D k hk c m) k hk (m+4) cs

/-- These count the POL subsequence; definitions are serialized between its
    blocks. The concatenation is not asserted to execute without definitions. -/
theorem family_pol_lines (D : List Row) (k : Nat) (hk : 3≤k) (m : Nat) (cs : List (RankProjection.Choice (3*k-4))) :
    (pols D k hk m cs).length=5*cs.length := by
  induction cs generalizing D m with
  | nil => rfl
  | cons c cs ih => simp [pols,derived_lines,ih];omega

theorem family_pol_tokens (D : List Row) (k : Nat) (hk : 3≤k) (m : Nat) (cs : List (RankProjection.Choice (3*k-4))) :
    tokensCount (pols D k hk m cs)=74*cs.length := by
  induction cs generalizing D m with
  | nil => rfl
  | cons c cs ih => simp [pols,derived_tokens,ih];omega

theorem pair_count (F : L3.Fam) (bs : List Nat) : (F.branchPairs bs).length≤bs.length*F.s := by
  induction bs with
  | nil => simp [L3.Fam.branchPairs]
  | cons b bs ih =>
    simp only [L3.Fam.branchPairs,List.flatMap_cons,List.length_append,List.length_map,List.length_range',List.length_cons] at ih ⊢
    have h : F.s-1-b≤F.s := by omega
    nlinarith

theorem chosen_bound (k : Nat) (hk : 3≤k) : (BranchChoices.chosen k hk).length≤9*k^2 := by
  have he:=congrArg List.length (BranchChoices.labels (3*k-4)
    ((FrontendSelection.front k hk).s.var+1) (BranchChoices.pairs k) (BranchChoices.pairs_valid k))
  simp only [List.length_map] at he
  change (BranchChoices.chosen k hk).length=(BranchChoices.pairs k).length at he
  rw [he]
  have hp:=pair_count (FableEncoding.fam k (3*k-4)) (FableEncoding.fam k (3*k-4)).branchIndices
  simp only [L3.Fam.branchIndices,List.length_range'] at hp
  change (BranchChoices.pairs k).length≤((3*k-4)-2)*(3*k-4) at hp
  have h1 : 3*k-4≤3*k := by omega
  have h2 : (3*k-4)-2≤3*k := by omega
  nlinarith

theorem raw_length (k : Nat) (m : Nat) (cs : List (RankProjection.Choice (3*k-4))) :
    (ForcingJoin.literals (pairs k m cs)).length=4*cs.length := by
  induction cs generalizing m with
  | nil => rfl
  | cons c cs ih =>
    change ([(m+1:Int),(m+2:Int),(m+3:Int),(m+4:Int)]++ForcingJoin.literals (pairs k (m+4) cs)).length=_
    rw [List.length_append,ih];simp;omega

theorem coverage_rows_in_n (k : Nat) (hk : 3≤k) :
    (bodies k hk (ForcingBounds.ceiling k hk) (BranchChoices.chosen k hk)).length≤189*k^2 := by
  rw [body_count];have:=chosen_bound k hk;nlinarith

theorem coverage_tokens_in_n (k : Nat) (hk : 3≤k) :
    tokensCount (pols (FrontendSelection.finalRows k hk) k hk (ForcingBounds.ceiling k hk)
      (BranchChoices.chosen k hk))≤666*k^2 := by
  rw [family_pol_tokens];have:=chosen_bound k hk;nlinarith

#print axioms derived_tokens
#print axioms coverage_tokens_in_n
end L3Emitter.ForcingSize

import FunctionChainPOL
namespace L3Emitter.FinalFunctionCases
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def z (n:Nat) (hn:2≤n) (ab:Fin 4):=FinalFunctionSlots.start n hn (initialNet n hn) ab
def j0 (n:Nat) (hn:2≤n) (ab:Fin 4):=FinalFunctionSlots.first n hn ab (z n hn ab)
def j1 (n:Nat) (hn:2≤n) (ab:Fin 4):=FinalFunctionSlots.second n hn ab (z n hn ab)
def j2 (n:Nat) (hn:2≤n) (ab:Fin 4):=FinalFunctionSlots.third n hn ab (z n hn ab)
def raw (n:Nat) (hn:2≤n) (ab:Fin 4):=LowerTransferImage.wire n hn (.fn (lastRank n) ab.val)
def alternative (n:Nat) (hn:2≤n) (ab:Fin 4):=if ab.val/2=0 then unary n hn false else unary n hn true

theorem present (n:Nat) (hn:2≤n) (ab:Fin 4):
    (∀R∈RecordedExpressions.jobRows (j0 n hn ab),R∈FinalPrimaryTransfers.result n hn) ∧
    (∀R∈RecordedExpressions.jobRows (j1 n hn ab),R∈FinalPrimaryTransfers.result n hn) ∧
    (∀R∈RecordedExpressions.jobRows (j2 n hn ab),R∈FinalPrimaryTransfers.result n hn):=by
  have h:=FinalFunctionSlots.local_members n hn ab (z n hn ab)
  have all (j:RecordedExpressions.Job) (hj:j∈FinalOutputRecorded.jobs n hn):∀R∈RecordedExpressions.jobRows j,R∈FinalPrimaryTransfers.result n hn:=by
    intro R hR
    apply List.mem_append_left
    apply FinalTransferBank.retained
    apply FinalTransferContext.recorded_kept
    exact List.mem_append_right _ (List.mem_flatMap.mpr ⟨j,hj,hR⟩)
  exact ⟨all _ (FinalFunctionSlots.lift_member n hn ab _ _ h.1),
    all _ (FinalFunctionSlots.lift_member n hn ab _ _ h.2.1),all _ (FinalFunctionSlots.lift_member n hn ab _ _ h.2.2)⟩

theorem initial_link (n:Nat) (hn:2≤n) (ab:Fin 4) (r v:Bool):
    GuardedJoin.link [-sign r (raw n hn ab)] (sign v (unary n hn r)) (sign v (j0 n hn ab).q)∈FinalPrimaryTransfers.result n hn:=by
  have h:=(present n hn ab).1 _ (UnaryValueStep.mux_link (j0 n hn ab) r v)
  cases r <;> simpa only [j0,FinalFunctionSlots.first,LookupEvaluation.job,raw,↓reduceIte,Bool.false_eq_true] using h

theorem kept_link (n:Nat) (hn:2≤n) (ab:Fin 4) (v:Bool):
    GuardedJoin.link [-(H n hn).val] (sign v (j0 n hn ab).q) (sign v (j1 n hn ab).q)∈FinalPrimaryTransfers.result n hn:=by
  have h:=(present n hn ab).2.1 _ (UnaryValueStep.mux_link (j1 n hn ab) true v)
  simpa only [j1,FinalFunctionSlots.second,LookupEvaluation.job,sign,↓reduceIte,j0] using h

theorem chosen_link (n:Nat) (hn:2≤n) (ab:Fin 4) (v:Bool):
    GuardedJoin.link [(H n hn).val] (sign v (alternative n hn ab)) (sign v (j1 n hn ab).q)∈FinalPrimaryTransfers.result n hn:=by
  have h:=(present n hn ab).2.1 _ (UnaryValueStep.mux_link (j1 n hn ab) false v)
  simpa only [j1,FinalFunctionSlots.second,LookupEvaluation.job,sign,↓reduceIte,Bool.false_eq_true,neg_neg,alternative] using h

theorem phase_link (n:Nat) (hn:2≤n) (ab:Fin 4) (v side:Bool):
    GuardedJoin.link [-sign side (OutputPhaseRows.phase n hn)] (sign v (j1 n hn ab).q)
      (sign (v^^side) ((built n hn).1.functions ab))∈FinalPrimaryTransfers.result n hn:=by
  have h:=FunctionChainPOL.phase_link (FinalPrimaryTransfers.result n hn) (j2 n hn ab) (OutputPhaseRows.phase n hn)
    (j1 n hn ab).q side v rfl rfl rfl (present n hn ab).2.2
  rw [show (j2 n hn ab).q=(built n hn).1.functions ab from FinalFunctionSlots.final_value n hn ab] at h
  exact h

abbrev Job:=Fin 4×Bool×Bool×Bool×Bool
-- retained branch, raw table value, unary value, phase value
-- The selected branch ignores the raw table value; its duplicate is omitted.
def jobs:List Job:=(List.finRange 4).flatMap fun ab=>
  [false,true].flatMap fun keep=>(if keep then [false,true] else [false]).flatMap fun r=>
    [false,true].flatMap fun v=>[false,true].map fun side=>(ab,keep,r,v,side)
def leaf (n:Nat) (hn:2≤n) (j:Job) (E:List Row):Program:=
  if j.2.1 then
    FunctionChainPOL.keptProgram E (raw n hn j.1) (unary n hn j.2.2.1) (H n hn) (OutputPhaseRows.phase n hn)
      (j0 n hn j.1).q (j1 n hn j.1).q ((built n hn).1.functions j.1) j.2.2.1 j.2.2.2.1 j.2.2.2.2
  else FunctionChainPOL.chosenProgram E (alternative n hn j.1) (H n hn) (OutputPhaseRows.phase n hn)
    (j1 n hn j.1).q ((built n hn).1.functions j.1) j.2.2.2.1 j.2.2.2.2
def rows (n:Nat) (hn:2≤n) (j:Job):List Row:=
  if j.2.1 then
    FunctionChainPOL.keptRows (raw n hn j.1) (unary n hn j.2.2.1) (H n hn) (OutputPhaseRows.phase n hn)
      (j1 n hn j.1).q ((built n hn).1.functions j.1) j.2.2.1 j.2.2.2.1 j.2.2.2.2
  else FunctionChainPOL.chosenRows (alternative n hn j.1) (H n hn) (OutputPhaseRows.phase n hn)
    ((built n hn).1.functions j.1) j.2.2.2.1 j.2.2.2.2

theorem leaf_check (n:Nat) (hn:2≤n) (j:Job) (E:List Row) (he:∀R∈FinalPrimaryTransfers.result n hn,R∈E):
    check E (leaf n hn j E)=some (E++rows n hn j):=by
  unfold leaf rows;split
  · exact FunctionChainPOL.kept_check E _ _ _ _ _ _ _ _ _ _ (he _ (initial_link n hn j.1 j.2.2.1 j.2.2.2.1))
      (he _ (kept_link n hn j.1 j.2.2.2.1)) (he _ (phase_link n hn j.1 j.2.2.2.1 j.2.2.2.2))
  · exact FunctionChainPOL.chosen_check E _ _ _ _ _ _ _ (he _ (chosen_link n hn j.1 j.2.2.2.1))
      (he _ (phase_link n hn j.1 j.2.2.2.1 j.2.2.2.2))
def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) jobs (FinalPrimaryTransfers.result n hn)
def result (n:Nat) (hn:2≤n):=FinalPrimaryTransfers.result n hn++RetainedBlockFold.body (rows n hn) jobs
theorem checks (n:Nat) (hn:2≤n):check (FinalPrimaryTransfers.result n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (fun _=>True) (fun j _=>leaf_check n hn j) _ (by simp) _ (fun _ h=>h)
theorem original_to_function_cases (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalPrimaryTransfers.original_to_primary_transfers n hn) (check_trace _ _ _ (checks n hn))
#print axioms original_to_function_cases
#print axioms phase_link
end L3Emitter.FinalFunctionCases

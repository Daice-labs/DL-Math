import CanonicalPOLParser

namespace L3Emitter.CanonicalCheckedPOL
open EREF EREF.GeneralRED NativeSparseStore CanonicalPOLParser

theorem evaluated_valid (db : Nat→Option Row) (h0 : db 0=none)
    (ts : List Tok) (st : List Row) (R : Row) (h : polEval db ts st=some R) :
    ∀t∈ts,Valid t := by
  induction ts generalizing st with
  | nil=>simp
  | cons t ts ih=>
    cases t with
    | ref i=>
      simp only [polEval] at h
      split at h
      · rename_i Q hQ
        have hi : 0 < i := by
          by_contra hn
          have hz:i=0:=by omega
          simp [hz,h0] at hQ
        have ht:=ih _ h
        simpa [Valid,hi] using ht
      · contradiction
    | lit l=>
      simp only [polEval] at h
      split at h
      · rename_i hl
        simpa [Valid,hl] using ih _ h
      · contradiction
    | add=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        cases st with
        | nil=>simp [polEval] at h
        | cons b st=>simpa [Valid] using ih _ h
    | mul k=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        simp only [polEval] at h
        split at h
        · rename_i hk
          simpa [Valid,hk] using ih _ h
        · contradiction
    | div k=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>
        simp only [polEval] at h
        split at h
        · rename_i hk
          simpa [Valid,hk] using ih _ h
        · contradiction
    | sat=>
      cases st with
      | nil=>simp [polEval] at h
      | cons a st=>simpa [Valid] using ih _ h

theorem relocated_valid (D : List Row) (s : Store) (ids : Nat→Nat)
    (he : Embeds D s ids) (ts : List Tok) (R : Row)
    (h : polEval (dbOf D) ts []=some R) :
    ∀t∈ts.map (ReferenceTransport.token ids),Valid t := by
  have hv:=evaluated_valid (dbOf D) (by simp [dbOf]) ts [] R h
  intro t ht
  obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht
  cases u with
  | ref i=>
    obtain ⟨Q,hQ⟩:=CompactReferenceWidths.referenced_rows _ ts [] R h i hu
    exact (he i Q hQ).1
  | lit l=>exact hv _ hu
  | add=>trivial
  | mul n=>exact hv _ hu
  | div n=>exact hv _ hu
  | sat=>trivial

/-- The roundtrip's validity premises follow from checked POL execution and
the physical-reference embedding; they are not independent assumptions. -/
theorem relocated_roundtrip (D : List Row) (s : Store) (ids : Nat→Nat)
    (he : Embeds D s ids) (ts : List Tok) (R : Row)
    (h : polEval (dbOf D) ts []=some R) :
    CanonicalPOLParser.parse (emit (separated (fixed " ")
      ((ts.map (ReferenceTransport.token ids)).map (fun t=>polToken (CompactTapeBytes.token t)))))=
      some (ts.map (ReferenceTransport.token ids)) :=
  tape_roundtrip _ (relocated_valid D s ids he ts R h)

theorem local_valid (D E : List Row) (s : Store) (ids : Nat→Nat)
    (hs : 0<s.next) (he : Embeds D s ids) (p : AliasProgram.Program)
    (hp : AliasProgram.check D p=some E) :
    ∀ts∈(NativeLocalProgram.compile D.length s ids p).tapes,∀t∈ts,Valid t := by
  induction p generalizing D s ids with
  | nil=>simp [NativeLocalProgram.compile]
  | cons c p ih=>
    rcases c with ⟨R,ts⟩
    simp only [AliasProgram.check] at hp
    split at hp
    · rename_i hc
      have ht:=ih (D++[R]) (push s R) (extend ids D.length s.next)
        (by dsimp [push];omega) (push_embeds D s ids he hs R) hp
      intro tape hm
      simp only [NativeLocalProgram.compile,List.mem_cons] at hm
      rcases hm with rfl|hm
      · exact relocated_valid D s ids he ts R hc
      · exact ht tape (by simpa using hm)
    · contradiction

def parseAndEvaluate (db : Nat→Option Row) (bs : Bytes) : Option Row := do
  let ts←CanonicalPOLParser.parse bs
  polEval db ts []

theorem checked_bytes (db : Nat→Option Row) (h0 : db 0=none) (ts : List Tok) (R : Row)
    (h : polEval db ts []=some R) :
    parseAndEvaluate db (emit (separated (fixed " ")
      (ts.map (fun t=>polToken (CompactTapeBytes.token t)))))=some R := by
  rw [parseAndEvaluate,tape_roundtrip ts (evaluated_valid db h0 ts [] R h)]
  exact h

#print axioms evaluated_valid
#print axioms relocated_valid
#print axioms relocated_roundtrip
#print axioms local_valid
#print axioms checked_bytes
end L3Emitter.CanonicalCheckedPOL

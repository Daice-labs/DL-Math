import CategoryMixtureProgram

namespace L3Emitter.KeptCategoryRows
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GateCategories CategoryPrograms

def ranks (n:Nat) (hn:2≤n) (g:Nat) := (List.range (RankConstruction.width (n+1))).map
  (AliasAssembly.rankBit (n+1) (by omega) g)

theorem kept_rows (n:Nat) (hn:2≤n) (g:Nat) (hs:g<3*(n+1)-4) :
    ContextRows.OrRows (CategoryBank.result n hn) (ranks n hn g) ((PrimaryAliasBank.cfg n hn).kept g) := by
  have h:=ContextRows.tabulate_or (3*(n+1)-4)
    (fun j=> (List.range (RankConstruction.width (n+1))).map
      (AliasAssembly.rankBit (n+1) (by omega) j.val)) (ContextRows.gammaRun n hn).2 ⟨g,hs⟩
  have he:(PrimaryAliasBank.cfg n hn).kept g=(ContextRows.keptRun n hn).1 ⟨g,hs⟩:=by
    change AliasAssembly.refAt _ (ContextRows.keptRun n hn).1 g=_
    simp only [AliasAssembly.refAt,dif_pos hs]
  rw [he]
  exact h.mono (fun R hr=>CategoryBank.retains n hn R
    (ContextRows.context_to_endpoint n hn R (ContextRows.kept_to_context n hn R hr)))

def row (n:Nat) (hn:2≤n) (g:Nat) (c:Category) :=
  clause [-(bit n hn g c).val,-((PrimaryAliasBank.cfg n hn).kept g).val]
def tape (n:Nat) (hn:2≤n) (g:Nat) (c:Category) (D:List Row) :=
  ChoiceProjection.excludeTokens D (bit n hn g c).val ((PrimaryAliasBank.cfg n hn).kept g).val
    ((ranks n hn g).map Subtype.val)

theorem tape_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (c:Category) (hc:c=.beta ∨ c=.gamma) (D:List Row) (hd:CategorySourceInputs.Keep n hn D) :
    polEval (dbOf D) (tape n hn g c D) []=some (row n hn g c) := by
  apply ChoiceProjection.exclude_succeeds
  · exact (bit n hn g c).property
  · exact ((PrimaryAliasBank.cfg n hn).kept g).property
  · intro l hl;obtain ⟨b,hb,rfl⟩:=List.mem_map.mp hl;exact b.property
  · exact hd _ (kept_rows n hn g hs).2
  · intro l hl
    obtain ⟨b,hb,rfl⟩:=List.mem_map.mp hl
    obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hb
    have hm:Category.rank t∈cats n:=by
      simpa [cats,categories,RankConstruction.width] using ht
    have hcm:c∈cats n:=by rcases hc with rfl|rfl <;> simp [cats,categories]
    have hne:c≠.rank t:=by rcases hc with rfl|rfl <;> simp
    exact hd _ (CategoryBank.exclusion n hn g hg hs c (.rank t) hcm hm hne)

def rows (n:Nat) (hn:2≤n) (g:Nat) :=[row n hn g .beta,row n hn g .gamma]
def program (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) : Program :=
  [(row n hn g .beta,tape n hn g .beta D),(row n hn g .gamma,tape n hn g .gamma D)]
theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (D:List Row) (hd:CategorySourceInputs.Keep n hn D) :
    check D (program n hn g D)=some (D++rows n hn g) := by
  apply IndependentProgram.check_base
  intro cmd hc
  simp only [program,List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl|rfl
  · exact tape_check n hn g hg hs .beta (Or.inl rfl) D hd
  · exact tape_check n hn g hg hs .gamma (Or.inr rfl) D hd

theorem rank_implies_kept (n:Nat) (hn:2≤n) (g:Nat) (hs:g<3*(n+1)-4)
    (t:Nat) (ht:t<RankConstruction.width (n+1)) :
    clause [-(AliasAssembly.rankBit (n+1) (by omega) g t).val,((PrimaryAliasBank.cfg n hn).kept g).val]
      ∈CategoryBank.result n hn := by
  exact (kept_rows n hn g hs).1 _ (List.mem_map.mpr ⟨t,List.mem_range.mpr ht,rfl⟩)

theorem token_count (n:Nat) (hn:2≤n) (g:Nat) (c:Category) (D:List Row) :
    (tape n hn g c D).length=4*(RankConstruction.width (n+1))+4 := by
  rw [tape,ChoiceProjection.exclude_token_count]
  simp [ranks]

#print axioms kept_rows
#print axioms checks
#print axioms rank_implies_kept
#print axioms token_count
end L3Emitter.KeptCategoryRows

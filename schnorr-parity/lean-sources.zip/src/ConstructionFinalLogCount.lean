import ConstructionTableCount
namespace L3Emitter.ConstructionFinalLogCount
open EREF EREF.GeneralRED AliasNetwork RecordedExpressions RecordedExpressionCost FinalOutputDefinitions
variable {base : List Row}

theorem construction (n : Nat) (hn : 2≤n) : LogCost
    (FinalOutputRecorded.construction (base:=base) n hn) (2*(W n-1)+2*T n+12) := by
  have hs:LogCost (RecordedExpressionRun.tabulateLog 2 (fun p=>RecordedExpressionRun.tabulateLog (W n-1)
      (FinalOutputRecorded.selector (base:=base) n hn p))) (2*((W n-1)*1)):=
    RecordedExpressionCost.tabulate_cost _ _ _ (fun _=>RecordedExpressionCost.tabulate_cost _ _ _ (fun _=>RecordedExpressionCost.mux_cost _ _ _))
  have hp (xs:Fin (T n)→Bit):LogCost (RecordedExpressionRun.tabulateLog 2 (fun p=>RecordedExpressionRun.tabulateLog (T n)
      (FinalOutputRecorded.port (base:=base) n hn xs p))) (2*(T n*1)):=
    RecordedExpressionCost.tabulate_cost _ _ _ (fun _=>RecordedExpressionCost.tabulate_cost _ _ _ (fun _=>RecordedExpressionCost.mux_cost _ _ _))
  have hf:LogCost (RecordedExpressionRun.tabulateLog 4 (FinalOutputRecorded.function (base:=base) n hn)) (4*3):=
    RecordedExpressionCost.tabulate_cost _ _ _ (fun _=>seq_cost _ _ 1 2 (RecordedExpressionCost.mux_cost _ _ _)
      (fun _=>seq_cost _ _ 1 1 (RecordedExpressionCost.mux_cost _ _ _) (fun _=>RecordedExpressionCost.mux_cost _ _ _)))
  have h:=seq_cost (base:=base) _ _ 0 _ (lift_cost (tabulate (T n) (out n hn))) (fun xs=>seq_cost _ _ _ _ hs
    (fun ss=>seq_cost _ _ _ _ (hp xs) (fun ps=>seq_cost _ _ _ _ hf (fun fs=>lift_cost (pure (⟨xs,ss,ps,fs⟩:Data n))))))
  convert h using 1 <;> ring

theorem complete (n : Nat) (hn : 2≤n) : (FinalOutputRecorded.program n hn).length≤100*(n+1)*2^n := by
  rw [FinalOutputRecorded.program,RecordedExpressionCost.program_count]
  have h:=construction n hn (initialNet n hn)
  change (FinalOutputRecorded.jobs n hn).length≤2*(W n-1)+2*2^n+12 at h
  have hw:W n-1≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);unfold W;omega
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have hm:=Nat.mul_le_mul_left (8*(n+1)+12) ht
  nlinarith

theorem output_links (n : Nat) (hn : 2≤n) : (FinalOutputLinks.program n hn).length≤8*(n+1)*2^n := by
  rw [FinalOutputLinks.program,ConcretePortCost.program_count]
  have h:=ConcretePortCost.tabulate_mass (T n) (FinalOutputSelection.inputs n hn) (initialNet n hn)
    (W n-1) (by intro i;simp [FinalOutputSelection.inputs])
  change ConcretePortCost.mass (FinalOutputLinks.jobs n hn)=2^n*(W n-1) at h
  rw [h]
  have hw:W n-1≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);unfold W;omega
  exact (Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left (2^n) hw)).trans_eq (by ring)
#print axioms complete
#print axioms output_links
end L3Emitter.ConstructionFinalLogCount

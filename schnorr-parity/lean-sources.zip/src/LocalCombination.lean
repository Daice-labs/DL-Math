import SelectorNormalization

namespace L3Emitter.LocalCombination
open EREF EREF.GeneralRED REDWitness ReferenceTransport

def chain (R : Row) : List Row → Row
  | [] => R
  | Q::qs => chain (add R Q) qs

def steps (rows : List Row) (rs : List Row) : List Tok :=
  rs.flatMap (fun R => [.ref (locate rows R),.add])

theorem chain_canonical (R : Row) (rs : List Row) (hc : Canonical R) :
    Canonical (chain R rs) := by
  induction rs generalizing R with
  | nil => exact hc
  | cons Q qs ih => exact ih (add R Q) (canonical_add _ _)

theorem chain_value (R : Row) (rs : List Row) (hc : Canonical R)
    (hr : ∀ Q∈rs, Canonical Q) (α : Val) :
    (chain R rs).val α = R.val α+(rs.map (fun Q => Q.val α)).sum := by
  induction rs generalizing R with
  | nil => simp [chain]
  | cons Q qs ih =>
    rw [chain, ih _ (canonical_add _ _) (by intro T ht; exact hr T (by simp [ht])),
      val_add _ _ hc (hr Q (by simp))]
    simp; ring

theorem steps_eval (rows rs : List Row) (hr : ∀ Q∈rs,Q∈rows)
    (R : Row) (st : List Row) (tail : List Tok) :
    polEval (dbOf rows) (steps rows rs ++ tail) (R::st) =
      polEval (dbOf rows) tail (chain R rs::st) := by
  induction rs generalizing R with
  | nil => rfl
  | cons Q qs ih =>
    simp only [steps,List.flatMap_cons,List.cons_append,List.nil_append,polEval,
      locate_correct rows Q (hr Q (by simp))]
    exact ih (by intro T ht; exact hr T (by simp [ht])) _

/-- A concrete linear POL certificate with at most 2*rs.length+3 tokens.
    The list can include the temporary negated candidate. No proof-search
    hypothesis or arbitrary local refutation is taken as input. -/
theorem certificate (rows : List Row) (C G R : Row) (rs : List Row)
    (hR : R∈rows++[negate C]) (hr : ∀ Q∈rs,Q∈rows++[negate C])
    (hc : Canonical R) (hcs : ∀ Q∈rs,Canonical Q) (hg : Canonical G)
    (hv : ∀ α, R.val α+(rs.map (fun Q => Q.val α)).sum ≤ G.val α) :
    LocalCertificate rows C G := by
  let db := rows++[negate C,negate G]
  have sub : ∀ Q∈rows++[negate C],Q∈db := by
    intro Q h
    rcases List.mem_append.mp h with h | h
    · exact List.mem_append_left _ h
    · exact List.mem_append_right _ (by simp only [List.mem_singleton] at h; simp [h])
  let out := add (chain R rs) (negate G)
  refine ⟨[.ref (locate db R)]++steps db rs++[.ref (rows.length+2),.add],out,?_,?_⟩
  · change polEval (dbOf db) _ []=some out
    simp only [List.append_assoc,List.cons_append,List.nil_append,polEval,
      locate_correct db R (sub R hR)]
    rw [steps_eval _ _ (by intro Q h; exact sub Q (hr Q h))]
    simp [polEval,db,db_neg_right,out]
  · apply (canonical_contra_iff _ (canonical_add _ _)).mpr
    intro α hs
    have h := hv α
    have ho : out.val α = R.val α+(rs.map (fun Q => Q.val α)).sum-G.val α-1 := by
      rw [show out=add (chain R rs) (negate G) from rfl,
        val_add _ _ (chain_canonical R rs hc) (canonical_negate _),
        chain_value R rs hc hcs, val_negate G hg]
      ring
    unfold Row.sat at hs
    rw [ho] at hs
    omega

#print axioms certificate
end L3Emitter.LocalCombination

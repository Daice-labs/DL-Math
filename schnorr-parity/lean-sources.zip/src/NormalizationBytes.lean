import NormalizationEmitter

namespace L3Emitter.NormalizationEmitter
open FamilyNamespace InputSwap SelectorNormalization TemplateBytes

theorem separated_bound (sep : Doc) (ds : List Doc) :
    exactBytes (separated sep ds) ≤
      (ds.map exactBytes).sum + ds.length*exactBytes sep := by
  cases ds with
  | nil => simp [separated,exactBytes]
  | cons d ds => rw [separated_bytes]; simp; nlinarith

theorem sum_bound {α : Type} (xs : List α) (f : α → Nat) (m : Nat)
    (h : ∀ x∈xs, f x≤m) : (xs.map f).sum≤xs.length*m := by
  induction xs with
  | nil => simp
  | cons x xs ih =>
    have hx := h x (by simp)
    have hh := ih (by intro y hy; exact h y (by simp [hy]))
    simp only [List.map_cons,List.sum_cons,List.length_cons]
    nlinarith

theorem positive_witness_bound (ps : List (Nat × Nat)) (M : Nat)
    (h : ∀ xy∈ps, xy.1≤M ∧ xy.2≤M) :
    exactBytes (L3Emitter.witness (ps.map fun xy => (xy.1,Image.lit ⟨xy.2,false⟩))) ≤
      ps.length*(7+2*digits M) := by
  unfold L3Emitter.witness
  have hh := separated_bound (fixed " ") ((ps.map fun xy => (xy.1,Image.lit ⟨xy.2,false⟩)).map
    (fun t => literal ⟨t.1,false⟩ ++ fixed " -> " ++ image t.2))
  have hs : ∀ xy : Nat × Nat,
      exactBytes (literal ⟨xy.1,false⟩ ++ fixed " -> " ++ image (Image.lit ⟨xy.2,false⟩)) =
        6+digits xy.1+digits xy.2 := by
    intro xy
    simp only [literal,image,exactBytes_append,fixed_bytes,number_bytes]
    change 1+digits xy.1+4+(1+digits xy.2)=_
    omega
  simp only [List.map_map,Function.comp_def,hs,List.length_map,fixed_bytes] at hh
  have ht := sum_bound ps (fun xy => 6+digits xy.1+digits xy.2) (6+2*digits M) (by
    intro xy hxy
    have ha := digits_mono (h xy hxy).1
    have hb := digits_mono (h xy hxy).2
    dsimp only
    omega)
  simp only [List.map_map,Function.comp_def]
  change _ ≤ ps.length*(7+2*digits M)
  change _ ≤ (ps.map fun xy => 6+digits xy.1+digits xy.2).sum+ps.length*1 at hh
  nlinarith

theorem single_command_bytes (k s p j : Nat) :
    exactBytes (command (commandFor k s p j)) =
      19+digits (p*k+j+1)+
      exactBytes (L3Emitter.witness ((witnessPairs k s p j).map
        fun xy => (xy.1,Image.lit ⟨xy.2,false⟩))) := by
  simp only [commandFor,command,candidatePB,row,separated,List.map_cons,List.map_nil,
    List.flatMap_nil,List.append_nil,literal,integer,show ¬(1:Int)<0 by omega,
    ↓reduceIte,exactBytes_append,number_bytes,fixed_bytes]
  change 4+(1+1+(2+digits (p*k+j+1))+4+1)+3+_+3=19+digits (p*k+j+1)+_
  omega

def stepByteBound (k s : Nat) : Nat :=
  19+digits (variableCount k s)+variableCount k s*(7+2*digits (variableCount k s))

theorem command_bound (k s p j : Nat) (hs : 0<s) (hp : p<2) (hpk : p<k) (hj : j<k) :
    exactBytes (command (commandFor k s p j)) ≤ stepByteBound k s := by
  rw [single_command_bytes]
  have hc : p*k+j+1≤variableCount k s := by
    have hh := (encode_bounds k s (.sel 0 p j) ⟨hs,hp,by simpa⟩).2
    simpa [encode,selectorStart] using hh
  have hw := positive_witness_bound (witnessPairs k s p j) (variableCount k s) (by
    intro xy hxy
    have hh := WireEnumeration.pairs_bounds k s (wire k p j) (wire_valid k s p j hpk hj) xy hxy
    exact ⟨hh.2.1,hh.2.2.2⟩)
  have hn := WireEnumeration.pairs_length k s (wire k p j)
  have hd := digits_mono hc
  unfold stepByteBound
  dsimp only [witnessPairs] at hw ⊢
  nlinarith

/-- An explicit bound in k and s for bytes of the executable normalization
    prefix, including variable digits and the simultaneous witness lists.
    This is NOT the bound for the still-incomplete full family certificate. -/
theorem document_bound (k s : Nat) (hk : 2≤k) (hs : 0<s) :
    (emit (document k s)).length ≤ (2*k-3)*stepByteBound k s := by
  rw [emit_length]
  unfold document commandsAll
  rw [flatMap_bytes]
  simp only [List.map_map,Function.comp_def]
  have hh := sum_bound (rightPrevious k k) (fun pj => exactBytes (command (commandFor k s pj.1 pj.2)))
    (stepByteBound k s) (by
      intro pj hpj
      rcases (right_mem k k pj.1 pj.2).mp hpj with ⟨hp,hl,hj⟩ | ⟨hp,hl,hj⟩
      · exact command_bound k s _ _ hs (by omega) (by omega) hj
      · exact command_bound k s _ _ hs (by omega) (by omega) hj)
  simpa only [selector_prefix_count k hk] using hh

def parityGateCount (n : Nat) : Nat := 3*n-4
def normalizationBound (n : Nat) : Nat := (2*n-3)*stepByteBound n (parityGateCount n)

theorem parity_document_bound (n : Nat) (hn : 3≤n) :
    (emit (document n (parityGateCount n))).length≤normalizationBound n := by
  exact document_bound n _ (by omega) (by unfold parityGateCount; omega)

#print axioms document_bound
#print axioms parity_document_bound
end L3Emitter.NormalizationEmitter

import RankValueMainTapes
namespace L3Emitter.GlobalFixedMainTapes
open EREF EREF.GeneralRED AliasProgram U2ConstructionSize

theorem map_factor {A : Type} (js : List A) (r : A→Row) (t : A→List Tok) (K : Nat)
    (h : ∀j∈js,(t j).length≤K) : tokens (js.map fun j=>(r j,t j))≤K*js.length := by
  exact (LowerEvaluationTapeBounds.map_tokens js r t K h).trans_eq (by ring)

theorem flat_factor {A : Type} (js : List A) (f : A→Program) (K : Nat)
    (h : ∀j∈js,tokens (f j)≤K*(f j).length) : tokens (js.flatMap f)≤K*(js.flatMap f).length := by
  induction js with
  | nil=>simp [tokens]
  | cons j js ih=>
    have hl:=h j (by simp)
    have ht:=ih (fun q hq=>h q (by simp [hq]))
    simp only [List.flatMap_cons,tokens_append,List.length_append]
    nlinarith

theorem beta_loop (n : Nat) (hn : 2≤n) (js : List (BetaValueBank.Job n)) (D : List Row) :
    tokens (BetaValueBank.loop n hn D js)≤5*(BetaValueBank.loop n hn D js).length := by
  induction js generalizing D with
  | nil=>simp [BetaValueBank.loop,tokens]
  | cons j js ih=>
    have hl:tokens (BetaValueBank.jobProgram n hn j D)=14:=by
      simp [BetaValueBank.jobProgram,BetaSelectedValue.program,tokens,BetaSelectedValue.choiceTape,
        BetaSelectedValue.middleTape,GuardedJoin.tape,GuardedValueComposition.tape]
    have hlen:(BetaValueBank.jobProgram n hn j D).length=3:=rfl
    have ht:=ih (D++BetaValueBank.jobRows n hn j)
    simp only [BetaValueBank.loop,tokens_append,List.length_append,hl,hlen]
    omega

theorem beta (n : Nat) (hn : 2≤n) : tokens (BetaValueBank.program n hn)≤77760*(n+1)^4*2^n := by
  have h:=beta_loop n hn (BetaValueBank.jobs n hn) (UnaryValueBank.result n hn)
  change tokens (BetaValueBank.program n hn)≤5*(BetaValueBank.program n hn).length at h
  exact h.trans ((Nat.mul_le_mul_left 5 (ConstructionValueBankCount.beta n hn)).trans_eq (by ring))

theorem rank_factor (n : Nat) (hn : 2≤n) : tokens (RankValueBank.program n hn)≤6*(RankValueBank.program n hn).length := by
  apply (map_factor (RankValueBank.jobs n) (RankValueBank.jobRow n hn)
    (fun j=>RankUnaryValue.tape n hn j.1 j.2.1 j.2.2 (BetaValueBank.result n hn)) 6 _).trans_eq
  · simp [RankValueBank.program]
  · intro j hj;dsimp only [RankUnaryValue.tape];split <;> simp [GuardedPropagation.tape,GuardedJoin.tape]

theorem rank (n : Nat) (hn : 2≤n) : tokens (RankValueBank.program n hn)≤108*(n+1)^2 :=
  (rank_factor n hn).trans ((Nat.mul_le_mul_left 6 (ConstructionValueBankCount.rank n hn)).trans_eq (by ring))

theorem evaluation_factor (n : Nat) (hn : 2≤n) : tokens (RankEvaluationBank.program n hn)≤5*(RankEvaluationBank.program n hn).length := by
  apply (map_factor (RankEvaluationBank.jobs n hn) (RankEvaluationBank.jobRow n hn)
    (fun j=>RankEvaluation.tape n hn j.1 j.2.1.val j.2.1.property j.2.2.1 j.2.2.2 (RankValueBank.result n hn)) 5 _).trans_eq
  · simp [RankEvaluationBank.program]
  · intro j hj;dsimp only [RankEvaluation.tape];split <;> simp [ChoiceProjection.weakenTokens,ClauseTransport.padSteps]

theorem evaluation (n : Nat) (hn : 2≤n) : tokens (RankEvaluationBank.program n hn)≤180*(n+1)^2*2^n :=
  (evaluation_factor n hn).trans ((Nat.mul_le_mul_left 5 (ConstructionValueBankCount.rank_eval n hn)).trans_eq (by ring))

theorem rebase (src dst : List Row) (p : Program) : tokens (ProgramRebase.program src dst p)=tokens p :=
  ProgramRebase.tokens_preserved src dst p

theorem shared (n : Nat) (hn : 2≤n) : tokens (SharedValueBank.program n hn)≤80000*(n+1)^4*2^n := by
  have hb:=beta n hn
  have hr:=rank n hn
  have he:=evaluation n hn
  have hp:(n+1)^2≤(n+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have ht:1≤2^n:=Nat.one_le_pow _ _ (by omega)
  have hm:=Nat.mul_le_mul_right (2^n) hp
  have hr2:(n+1)^2≤(n+1)^4*2^n:=(hp.trans (by nlinarith [Nat.mul_le_mul_left ((n+1)^4) ht]))
  simp only [SharedValueBank.program,SharedValueBank.betaProgram,SharedValueBank.rankProgram,
    SharedValueBank.evaluationProgram,tokens_append,rebase]
  nlinarith

#print axioms beta
#print axioms rank
#print axioms evaluation
#print axioms shared
end L3Emitter.GlobalFixedMainTapes

import NumericSelectionTapes
namespace L3Emitter.NumericClauseTapes
open EREF EREF.GeneralRED RecordedOperandFields ClauseTransport

theorem links (M:Nat) (g:Int) (ls:List Link) (hg:g.natAbs≤M):Tape M (linkSteps g ls):=by
  intro t ht;obtain ⟨l,hl,ht⟩:=List.mem_flatMap.mp ht
  cases l <;> simp only[Link.tokens,List.mem_cons,List.not_mem_nil,or_false] at ht
  all_goals rcases ht with rfl|rfl
  all_goals first | exact hg | trivial

theorem padding_fields (M:Nat) (ls:List Link) (h:∀l∈ls,l.target.natAbs≤M):
    ∀x∈padding ls,x.natAbs≤M:=by
  intro x hx;obtain ⟨xs,hxs,hx⟩:=List.mem_flatten.mp hx
  obtain ⟨_,rfl⟩:=List.mem_replicate.mp hxs
  obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hx;exact h l hl

theorem tokens (M i:Nat) (g:Int) (ls:List Link) (hg:g.natAbs≤M)
    (h:∀l∈ls,l.target.natAbs≤M) (hl:ls.length≤M):Tape M (ClauseTransport.tokens i g ls):=by
  apply NumericSelectionTapes.append
  · apply NumericSelectionTapes.append
    · apply NumericSelectionTapes.append
      · intro t ht;obtain rfl:=List.mem_singleton.mp ht;trivial
      · exact links M g ls hg
    · exact NumericSelectionTapes.pad M _ (padding_fields M ls h)
  · intro t ht;obtain rfl:=List.mem_singleton.mp ht;exact hl

theorem join (M i:Nat) (is:List Nat) (h:is.length≤M):Tape M (CaseJoin.joinTokens i is):=by
  apply NumericSelectionTapes.append
  · apply NumericSelectionTapes.append
    · intro t ht;obtain rfl:=List.mem_singleton.mp ht;trivial
    · intro t ht;obtain ⟨j,hj,ht⟩:=List.mem_flatMap.mp ht
      simp only[List.mem_cons,List.not_mem_nil,or_false] at ht
      rcases ht with rfl|rfl <;> trivial
  · intro t ht;obtain rfl:=List.mem_singleton.mp ht;exact h
#print axioms tokens
#print axioms join
end L3Emitter.NumericClauseTapes

import DefinitionNetworkBridge
namespace L3Emitter.FinalOutputDefinitions
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL
def base (n:Nat) (hn:2≤n):=OutputPhaseBank.result n hn
theorem base_canonical (n:Nat) (hn:2≤n):∀R∈base n hn,Canonical R:=
  CanonicalTrace.trace (OutputPhaseBank.original_to_output_phase n hn) (OriginalEncoding.rows_canonical _ _)
def initialNet (n:Nat) (hn:2≤n):Net (base n hn):=initial (base n hn) (base_canonical n hn)
@[irreducible] def built (n:Nat) (hn:2≤n):Data n × Net (base n hn):=construction n hn (initialNet n hn)
def result (n:Nat) (hn:2≤n):=(built n hn).2.rows

theorem original_to_definitions (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=by
  unfold result built
  exact L3.Fam.checkedTrace_trans (OutputPhaseBank.original_to_output_phase n hn) (DefinitionNetworkBridge.checked (base:=base n hn) (base_canonical n hn) (construction (base:=base n hn) n hn))

theorem retains (n:Nat) (hn:2≤n):∀R∈base n hn,R∈result n hn:=by
  unfold result built
  exact DefinitionNetworkBridge.retains (base:=base n hn) (base_canonical n hn) (construction (base:=base n hn) n hn) (construction_extends n hn)

theorem construction_bound {base:List Row} (n:Nat) (hn:2≤n):
    Cost (construction (base:=base) n hn) ((4*n+2)*2^n+24*n+6):=by
  apply cost_mono _ _ _ (construction_cost n hn)
  have hw:W n=4*n-4:=by unfold W AliasAssembly.width RankConstruction.width;omega
  rw [hw]
  have h1:4*n-4+6=4*n+2:=by omega
  have h2:6*(4*n-4-1)+36=24*n+6:=by omega
  rw [h1,Nat.add_assoc,h2]
  unfold T FamilyNamespace.truthRows
  rw [Nat.mul_comm]
  omega


theorem fresh_definition_bound (n:Nat) (hn:2≤n):
    (built n hn).2.gates.length≤(4*n+2)*2^n+24*n+6:=by
  unfold built initialNet
  exact DefinitionNetworkBridge.cost (base:=base n hn) (base_canonical n hn) (construction (base:=base n hn) n hn) ((4*n+2)*2^n+24*n+6) (construction_bound (base:=base n hn) n hn)
#print axioms original_to_definitions
#print axioms fresh_definition_bound
end L3Emitter.FinalOutputDefinitions

import FinalEvaluationJoin
namespace L3Emitter.FinalEvaluationBank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions FinalEvaluationContext
abbrev Job (n:Nat):=Fin (T n)×Bool×Bool
def jobs (n:Nat):List (Job n):=(List.finRange (T n)).flatMap fun x=>[false,true].flatMap fun a=>[false,true].map fun b=>(x,a,b)
def leaf (n:Nat) (hn:2≤n) (j:Job n):=FinalEvaluationJoin.program n hn j.1 j.2.1 j.2.2
def rows (n:Nat) (hn:2≤n) (j:Job n):=FinalEvaluationJoin.rows n hn j.1 j.2.1 j.2.2
def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n) (D n hn)
def result (n:Nat) (hn:2≤n):=D n hn++RetainedBlockFold.body (rows n hn) (jobs n)
theorem checks (n:Nat) (hn:2≤n):check (D n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (fun _=>True) (fun j _=>FinalEvaluationJoin.checks n hn j.1 j.2.1 j.2.2) _ (by simp) _ (fun _ h=>h)
theorem original_to_replacement_evaluation (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalU2Bank.original_to_replacement_U2 n hn) (check_trace _ _ _ (checks n hn))
theorem contains (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b:Bool):
    FinalEvaluationJoin.row n hn x a b∈result n hn:=
  List.mem_append_right _ (RetainedBlockFold.contains (rows n hn) (jobs n) (x,a,b)
    (by cases a <;> cases b <;> simp [jobs]) _ (List.mem_append_right _ (List.mem_singleton_self _)))
#print axioms original_to_replacement_evaluation
#print axioms contains
end L3Emitter.FinalEvaluationBank

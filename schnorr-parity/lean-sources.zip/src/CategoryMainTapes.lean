import ProjectionMainTapes
namespace L3Emitter.CategoryMainTapes
open EREF EREF.GeneralRED U2ConstructionSize GateCategories

theorem choices (n : Nat) (hn : 2≤n) : (CategoryPrograms.choices n hn).length≤9*(n+1)^2 :=
  ForcingSize.chosen_bound (n+1) (by omega)
theorem cats (n : Nat) : (CategoryPrograms.cats n).length≤3*(n+1) := by
  simp only [CategoryPrograms.cats,categories,List.length_cons,List.length_map,List.length_range];omega

theorem alo (n : Nat) (hn : 2≤n) (g : Nat) (D : List Row) :
    tokens (CategoryPrograms.aloProgram n hn g D)≤83*(n+1)^3 := by
  have h:=ProjectionMainTapes.alo D (CategoryPrograms.choices n hn) RankProjection.Choice.lit
    (fun c=>CategoryPrograms.value n hn g (owner g c)) (CategoryPrograms.vars n hn g)
  have hc:=choices n hn;have hq:=cats n
  have hv:(CategoryPrograms.vars n hn g).length=(CategoryPrograms.cats n).length:=by simp [CategoryPrograms.vars]
  rw [hv] at h
  have hm:=Nat.mul_le_mul hc (show 1+2*(CategoryPrograms.cats n).length≤7*(n+1) by omega)
  have hp:1≤(n+1)^3:=Nat.one_le_pow _ _ (by omega)
  have h23:(n+1)^2≤(n+1)^3:=Nat.pow_le_pow_right (by omega) (by omega)
  exact h.trans (by nlinarith)

theorem pair (n : Nat) (hn : 2≤n) (g : Nat) (q r : Category) (D : List Row) :
    tokens (CategoryPrograms.pairProgram n hn g q r D)≤410*(n+1)^4 := by
  have h:=ProjectionMainTapes.pair D (CategoryPrograms.choices n hn) RankProjection.Choice.lit
    (CategoryPrograms.value n hn g q) (CategoryPrograms.value n hn g r) (CategoryPrograms.side g q)
    (support (CategoryPrograms.choices n hn) g q) (support (CategoryPrograms.choices n hn) g r)
    (CategoryPrograms.choices n hn).length
    (by simp only [support,List.length_map];exact List.length_filter_le ..)
    (by simp only [support,List.length_map];exact List.length_filter_le ..)
  have hc:=choices n hn
  have hb:4*(CategoryPrograms.choices n hn).length+7≤43*(n+1)^2:=by nlinarith
  have hm:=Nat.mul_le_mul hc hb
  have h24:(n+1)^2≤(n+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have hp:1≤(n+1)^4:=Nat.one_le_pow _ _ (by omega)
  exact h.trans (by nlinarith)

theorem pair_loop (n : Nat) (hn : 2≤n) (g : Nat) (ps : List (Category×Category)) (D : List Row) :
    tokens (CategoryPrograms.pairLoop n hn g D ps)≤ps.length*(410*(n+1)^4) := by
  induction ps generalizing D with
  | nil=>simp [CategoryPrograms.pairLoop,tokens]
  | cons p ps ih=>
    have h:=pair n hn g p.1 p.2 D
    have ht:=ih (D++CategoryPrograms.pairRows n hn g p.1 p.2)
    rw [CategoryPrograms.pairLoop,tokens_append,List.length_cons,Nat.succ_mul];omega

theorem gate (n : Nat) (hn : 2≤n) (g : Nat) (D : List Row) :
    tokens (CategoryPrograms.program n hn g D)≤3800*(n+1)^6 := by
  have h0:=alo n hn g D
  have h1:=pair_loop n hn g (CategoryPrograms.pairs n) (D++CategoryPrograms.aloRows n hn g)
  have hp:(CategoryPrograms.pairs n).length≤(CategoryPrograms.cats n).length^2:=by
    unfold CategoryPrograms.pairs
    exact (ConstructionRelationCount.flat_bound _ _ _ (fun q hq=>List.length_filterMap_le ..)).trans_eq (by ring)
  have hc:=Nat.pow_le_pow_left (cats n) 2
  have hpair:(CategoryPrograms.pairs n).length≤9*(n+1)^2:=by nlinarith
  have hm:=Nat.mul_le_mul_right (410*(n+1)^4) hpair
  have h36:(n+1)^3≤(n+1)^6:=Nat.pow_le_pow_right (by omega) (by omega)
  rw [CategoryPrograms.program,tokens_append];nlinarith

theorem loop (n : Nat) (hn : 2≤n) (gs : List Nat) (D : List Row) :
    tokens (CategoryBank.loop n hn D gs)≤gs.length*(3800*(n+1)^6) := by
  induction gs generalizing D with
  | nil=>simp [CategoryBank.loop,tokens]
  | cons g gs ih=>
    have h:=gate n hn g D;have ht:=ih (D++CategoryPrograms.rows n hn g)
    rw [CategoryBank.loop,tokens_append,List.length_cons,Nat.succ_mul];omega

theorem complete (n : Nat) (hn : 2≤n) : tokens (CategoryBank.emitted n hn)≤11400*(n+1)^7 := by
  have h:=loop n hn (CategoryBank.gates n) (CategoryPrograms.base n hn)
  rw [ConstructionRelationCount.gates] at h
  exact h.trans ((Nat.mul_le_mul_right _ (Nat.sub_le (3*(n+1)) 5)).trans_eq (by ring))
#print axioms complete
end L3Emitter.CategoryMainTapes

import AliasNetworkRules

namespace L3Emitter.AliasNetwork
open EREF EREF.GeneralRED AliasGateSemantics
variable {base : List Row} {A : Type}

/-- Finite coordinate allocation, with every source and both unary bits
    represented. No default or missing-coordinate value is used. -/
def tabulate : (n : Nat) → (Fin n→StateM (Net base) A) →
    StateM (Net base) (Fin n→A)
  | 0,_ => pure (fun i=>Fin.elim0 i)
  | n+1,f => do
    let a ← f 0
    let as ← tabulate n (fun i=>f i.succ)
    pure (Fin.cases a as : Fin (n+1)→A)

theorem tabulate_extends (n : Nat) (f : Fin n→StateM (Net base) A)
    (hf : ∀i,Extends (f i)) : Extends (tabulate n f) := by
  induction n with
  | zero => exact pure_extends _
  | succ n ih =>
    exact bind_extends (f 0) _
      (hf 0) (fun a=>bind_extends (tabulate n (fun i=>f i.succ)) _
        (ih _ (fun i=>hf i.succ)) (fun as=>pure_extends _))

theorem tabulate_spec (α : Val) (n : Nat) (f : Fin n→StateM (Net base) A)
    (P : Fin n→A→Prop) (he : ∀i,Extends (f i))
    (hf : ∀i,Spec α (f i) (P i)) :
    Spec α (tabulate n f) (fun as=>∀i,P i (as i)) := by
  induction n with
  | zero => exact pure_spec α _ _ (fun i=>Fin.elim0 i)
  | succ n ih =>
    refine bind_spec α (f 0) (fun a=>do
      let as ← tabulate n (fun i=>f i.succ)
      pure (Fin.cases a as : Fin (n+1)→A)) (P 0) _
      (fun a=>bind_extends _ _ (tabulate_extends n _ (fun i=>he i.succ))
        (fun as=>pure_extends _)) (hf 0) ?_
    intro a ha
    refine bind_spec α (tabulate n (fun i=>f i.succ)) (fun as=>pure (Fin.cases a as : Fin (n+1)→A)) _ _
      (fun as=>pure_extends _) (ih _ _ (fun i=>he i.succ) (fun i=>hf i.succ)) ?_
    intro as has
    exact pure_spec α _ _ (Fin.cases ha (fun i=>has i))

abbrev AliasBits (w : Nat) := Fin (w+2)→Bit
abbrev AliasValues (w : Nat) := Fin (w+2)→Bool
def view {w : Nat} (α : Val) (a : AliasBits w) : AliasValues w := fun i=>eval α (a i)

def port {w : Nat} (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) :
    StateM (Net base) (AliasBits w) :=
  tabulate (w+2) (fun i=>select ((List.range (k+g)).map (fun j=>(sel j,as j i))))

def portValues {w : Nat} (k g : Nat) (sel : Nat→Bool) (as : Nat→AliasValues w) :
    AliasValues w :=
  fun i=>(List.range (k+g)).any (fun j=>sel j && as j i)

theorem port_extends {w : Nat} (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) :
    Extends (port (base:=base) k g sel as) :=
  tabulate_extends _ _ (fun i=>select_extends _)

theorem port_spec {w : Nat} (α : Val) (k g : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w) :
    Spec α (port (base:=base) k g sel as)
      (fun a=>view α a=portValues k g (fun j=>eval α (sel j)) (fun j=>view α (as j))) := by
  have ht:=tabulate_spec (base:=base) α (w+2)
    (fun i=>select ((List.range (k+g)).map (fun j=>(sel j,as j i))))
    (fun i q=>eval α q=(List.range (k+g)).any (fun j=>eval α (sel j) && eval α (as j i)))
    (fun _=>select_extends _)
    (fun i=>by simpa using select_spec (base:=base) α ((List.range (k+g)).map (fun j=>(sel j,as j i))))
  exact spec_mono α _ _ _ ht (fun a h=>funext h)

theorem portValues_onehot {w : Nat} (k g j : Nat) (sel : Nat→Bool) (as : Nat→AliasValues w)
    (hj : j<k+g) (hs : ∀i<k+g,sel i=decide (i=j)) :
    portValues k g sel as=as j := by
  funext c
  apply Bool.eq_iff_iff.mpr
  simp only [portValues,List.any_eq_true,Bool.and_eq_true,List.mem_range]
  constructor
  · rintro ⟨i,hi,hsel,hval⟩
    rw [hs i hi] at hsel
    have hij : i=j:=of_decide_eq_true hsel
    simpa [hij] using hval
  · intro h
    exact ⟨j,hj,by simp [hs j hj],h⟩

theorem selected_port {w : Nat} (α : Val) (k g j : Nat) (sel : Nat→Bit) (as : Nat→AliasBits w)
    (hj : j<k+g) (hs : ∀i<k+g,eval α (sel i)=decide (i=j)) :
    Spec α (port (base:=base) k g sel as) (fun a=>view α a=view α (as j)) := by
  exact spec_mono α _ _ _ (port_spec α k g sel as) (fun a h=>
    h.trans (portValues_onehot k g j _ _ hj hs))

#print axioms tabulate_spec
#print axioms port_spec
#print axioms selected_port
end L3Emitter.AliasNetwork

/-
The frontend builder again (frontend.py lines 57–127), written as explicit folds over
the loop ranges so that its emitted commands and its name maps can be characterized by
induction. It produces exactly the same command list as `Fam.frontend` (checked by
evaluation, `frontendX_eq_frontend`) and the same lines as the Python frontend.
-/
import L3Frontend

namespace L3
namespace Fam

variable (F : Fam)

/-- stage 0 (line 57–58): `unused_false = OR([])`, `rup [¬unused_false]`, `live[s-1] = AND([])` -/
def stage0 : StI F.V :=
  let t := StI.init F.V
  let (q0, t) := t.OR []
  let t := t.rup [-(q0 : Int)]
  let (qL, t) := t.AND []
  t.setLive fun g => if g = F.s - 1 then qL else t.s.live g

/-- one edge definition `edge{g}-{h}-{port} = AND([live[h], sel(h,port,k+g)])` -/
def edgeStep (g : Nat) (acc : StI F.V × List Int) (hp : Nat × Nat) : StI F.V × List Int :=
  let (t, terms) := acc
  let (h, port) := hp
  let (e, t') := t.AND [(t.s.live h : Int), (F.sel h port (F.k + g) : Int)]
  (t'.setEdges fun g' h' p' => if g' = g ∧ h' = h ∧ p' = port then e else t'.s.edges g' h' p',
   terms ++ [(e : Int)])

/-- the (h, port) pairs of gate g, in loop order -/
def edgePairs (g : Nat) : List (Nat × Nat) :=
  (List.range' (g + 1) (F.s - 1 - g)).flatMap fun h => [(h, 0), (h, 1)]

/-- gate g of the edges loop: its edges, then `live[g] = OR(edges)` -/
def gateStep (t : StI F.V) (g : Nat) : StI F.V :=
  let (t', terms) := (F.edgePairs g).foldl (F.edgeStep g) (t, [])
  let (l, t'') := t'.OR terms
  t''.setLive fun g' => if g' = g then l else t''.s.live g'

/-- stage 1 (lines 59–65): g = s−2 down to 0 -/
def stage1 (t : StI F.V) : StI F.V := ((List.range (F.s - 1)).reverse).foldl F.gateStep t

/-- the (a, d) function-entry pairs of a port -/
def eqPair (port b : Nat) : Nat × Nat := if port = 0 then (2 * b, 2 * b + 1) else (b, b + 2)

/-- one `forceeq{g}-{port}-{b} = EQ(fn(g,a), fn(g,d))` -/
def eqStep (hm : 1 ≤ F.V) (g port : Nat) (acc : StI F.V × List Int) (b : Nat) : StI F.V × List Int :=
  let (t, eqs) := acc
  let (a, d) := eqPair port b
  let (e, t') := t.EQ hm (F.fn g a : Int) (F.fn g d : Int)
  (t'.setEqrow fun g' p' b' => if g' = g ∧ p' = port ∧ b' = b then e else t'.s.eqrow g' p' b',
   eqs ++ [(e : Int)])

/-- one port of gate g: eqrows, `force = OR(eqs)`, `p0force = AND([sel(g,port,0), force])` -/
def portStep (hm : 1 ≤ F.V) (g : Nat) (acc : StI F.V × List Int) (port : Nat) : StI F.V × List Int :=
  let (t, ports) := acc
  let (t', eqs) := [0, 1].foldl (F.eqStep hm g port) (t, [])
  let (f, t'') := t'.OR eqs
  let t'' := t''.setForce fun g' p' => if g' = g ∧ p' = port then f else t''.s.force g' p'
  let (pf, t3) := t''.AND [(F.sel g port 0 : Int), (f : Int)]
  (t3.setP0force fun g' p' => if g' = g ∧ p' = port then pf else t3.s.p0force g' p',
   ports ++ [(pf : Int)])

/-- gate g of the eligibility loop -/
def eligStep (hm : 1 ≤ F.V) (t : StI F.V) (g : Nat) : StI F.V :=
  let (t', ports) := [0, 1].foldl (F.portStep hm g) (t, [])
  let (cons, t'') := t'.OR ports
  let (el, t3) := t''.AND [(t''.s.live g : Int), (cons : Int)]
  t3.setEligible fun g' => if g' = g then el else t3.s.eligible g'

/-- stage 2 (lines 66–77): g = 1..s−1 -/
def stage2 (hm : 1 ≤ F.V) (t : StI F.V) : StI F.V := (List.range' 1 (F.s - 1)).foldl (F.eligStep hm) t

/-- stage 3 (line 78): `A = OR(eligible[1..s-1])` -/
def stage3 (t : StI F.V) : StI F.V :=
  let (a, t') := t.OR ((List.range' 1 (F.s - 1)).map fun g => (t.s.eligible g : Int))
  t'.setA a

/-- stage 4 (lines 81–87): non-forcing ports are ignored -/
def forceRups (t : StI F.V) (gp : Nat × Nat) : StI F.V :=
  let (g, port) := gp
  let f := (t.s.force g port : Int)
  let pairs : List (Nat × Nat) := if port = 0 then [(0, 2), (1, 3)] else [(0, 1), (2, 3)]
  pairs.foldl (fun t ab =>
    let (a, b) := ab
    (t.rup [f, -(F.fn g a : Int), (F.fn g b : Int)]).rup [f, (F.fn g a : Int), -(F.fn g b : Int)]) t

def stage4 (t : StI F.V) : StI F.V :=
  ((List.range' 1 (F.s - 1)).flatMap fun g => [(g, 0), (g, 1)]).foldl F.forceRups t

/-- stage 5 (lines 89–108): x0 = 0 vs x0 = 1 at each value of x1 -/
def bitX (bit : Nat) : Nat := (F.T / 4) * bit
def bitY (bit : Nat) : Nat := F.bitX bit + F.T / 2

def portEqStep (hm : 1 ≤ F.V) (g bit : Nat) (cb : Nat) (t : StI F.V) (port : Nat) : StI F.V :=
  let x := F.bitX bit; let y := F.bitY bit
  let guard : List Int := [(t.s.A : Int), -(cb : Int), -(t.s.live g : Int)]
  let (q, t') := t.EQ hm (F.port g port x : Int) (F.port g port y : Int)
  let t'' := (List.range' 1 (F.k + g - 1)).foldl (fun t j =>
    t.split (guard ++ [-(F.sel g port j : Int), (q : Int)]) [(F.port g port x : Int)]) t'
  let t3 := t''.rup (guard ++ [(F.sel g port 0 : Int), (q : Int)])
  t3.rup [(t3.s.A : Int), -(t3.s.live g : Int), -(F.sel g port 0 : Int), -(t3.s.force g port : Int)]

def veqStep (hm : 1 ≤ F.V) (bit cb : Nat) (t : StI F.V) (g : Nat) : StI F.V :=
  let x := F.bitX bit; let y := F.bitY bit
  let (v, t') := t.EQ hm (F.val g x : Int) (F.val g y : Int)
  let t' := t'.setVeq fun g' b' => if g' = g ∧ b' = bit then v else t'.s.veq g' b'
  if g = 0 then
    t'.split [-(cb : Int), (v : Int)] [(F.val g x : Int)]
  else
    let guard : List Int := [(t'.s.A : Int), -(cb : Int), -(t'.s.live g : Int)]
    let t'' := [0, 1].foldl (F.portEqStep hm g bit cb) t'
    t''.split (guard ++ [(v : Int)])
      [(F.port g 0 x : Int), (F.port g 0 y : Int), (F.port g 1 x : Int), (F.port g 1 y : Int), (F.val g x : Int)]

def bitStep (hm : 1 ≤ F.V) (acc : StI F.V × List Int) (bit : Nat) : StI F.V × List Int :=
  let (t, C) := acc
  let (cb, t') := t.EQ hm (F.fn 0 bit : Int) (F.fn 0 (bit + 2) : Int)
  let t'' := (List.range F.s).foldl (F.veqStep hm bit cb) t'
  (t''.rup [(t''.s.A : Int), -(cb : Int)], C ++ [(cb : Int)])

def stage5 (hm : 1 ≤ F.V) (t : StI F.V) : StI F.V :=
  let (t', C) := [0, 1].foldl (F.bitStep hm) (t, [])
  (t'.split C [(F.fn 0 0 : Int), (F.fn 0 1 : Int)]).rup [(t'.s.A : Int)]

/-- stage 6 (lines 111–119): the output gate is not eligible -/
def outX (b : Nat) : Nat := (F.T / 2) * b
def outY (b : Nat) : Nat := F.outX b + F.T / 4

def outSplit (t : StI F.V) (pb : Nat × Nat) : StI F.V :=
  let (port, b) := pb
  t.split [-(F.sel (F.s - 1) port 0 : Int), -(t.s.eqrow (F.s - 1) port b : Int)]
    [(F.port (F.s - 1) (1 - port) (F.outX b) : Int), (F.port (F.s - 1) (1 - port) (F.outY b) : Int)]

def outRup (t : StI F.V) (port : Nat) : StI F.V :=
  (t.rup [-(F.sel (F.s - 1) port 0 : Int), -(t.s.force (F.s - 1) port : Int)]).rup
    [-(t.s.p0force (F.s - 1) port : Int)]

def stage6 (t : StI F.V) : StI F.V :=
  let t1 := ([0, 1].flatMap fun port => [(port, 0), (port, 1)]).foldl F.outSplit t
  let t2 := [0, 1].foldl F.outRup t1
  t2.rup [-(t2.s.eligible (F.s - 1) : Int)]

/-- stage 7 (lines 120–127): three-gate reductions -/
def branchStep (b : Nat) (acc : StI F.V × List Int) (g : Nat) : StI F.V × List Int :=
  let (t, brs) := acc
  let (succ, t') := t.OR [(t.s.edges b g 0 : Int), (t.s.edges b g 1 : Int)]
  let (br, t'') := t'.AND [(t'.s.eligible b : Int), (succ : Int)]
  (t''.setBranches fun b' g' => if b' = b ∧ g' = g then br else t''.s.branches b' g', brs ++ [(br : Int)])

def bStep (acc : StI F.V × List Int) (b : Nat) : StI F.V × List Int :=
  (List.range' (b + 1) (F.s - 1 - b)).foldl (F.branchStep b) acc

def bRup (t : StI F.V) (b : Nat) : StI F.V := t.rup [(t.s.Bv : Int), -(t.s.eligible b : Int)]

def stage7 (t : StI F.V) : StI F.V :=
  let (t', brs) := (List.range' 1 (F.s - 2)).foldl F.bStep (t, [])
  let (bB, t'') := t'.OR brs
  let t3 := t''.setB bB
  let t4 := (List.range' 1 (F.s - 2)).foldl F.bRup t3
  t4.rup [(t4.s.Bv : Int)]

/-- the whole frontend after the prefix -/
def frontendX (hs : 1 ≤ F.s) : StI F.V :=
  let hm := F.V_pos hs
  F.stage7 (F.stage6 (F.stage5 hm (F.stage4 (F.stage3 (F.stage2 hm (F.stage1 F.stage0))))))

end Fam
end L3

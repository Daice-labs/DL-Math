import CanonicalFamilyEnvelope
import NativeRecordedFamily
import Init.Data.SInt.Lemmas

namespace L3Emitter.CanonicalMachineReference
open EREF NativeSparseStore CanonicalFamilyEnvelope CanonicalReplayEnvelope CanonicalCountRecurrence

/-- Positive row references on the pinned aarch64 executable pass through
signed 64-bit integers. This proves the integer representation obligation;
it is not a proof of the Rust lexer or its complete implementation. -/
def referenceLimit : Nat := 2^63

theorem positive_cast (i : Nat) (hi : i<referenceLimit) :
    (Int64.ofNat i).toInt=(i:Int) := Int64.toInt_ofNat_of_lt hi

theorem resolved_positive_cast (s : Store) (i : Nat) (hi : i<referenceLimit) :
    read s (Int64.ofNat i).toInt=read s (i:Int) := by rw [positive_cast i hi]

def nextBound (m A B C : Nat) :=
  128*(m+3)^2*2^(m+2)+1+allocationBound m A B C

theorem next_bound (m A B C : Nat)
    (h0 : BoundedProgram C (RecordedUniformFamily.family 0))
    (ha : ∀i<m,(levelPrefix i).length≤A)
    (hb : ∀i<m,BoundedProgram B (levelPrefix i)) :
    (NativeRecordedFamily.compiled (m+2)).store.next≤nextBound m A B C := by
  have ht:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard (m+2))
    _ _ (initial (NativeRecordedFamily.original (m+2))) id _
    (RecordedUniformFamily.recorded_refutation (m+2) (by omega)).1
  have he:RecordedUniformFamily.emitter (m+2)=RecordedUniformFamily.family m:=by
    simp [RecordedUniformFamily.emitter]
  change (NativeRecordedFamily.compiled (m+2)).store.next=_ at ht
  rw [he] at ht
  have ha':=allocations m A B C h0 ha hb
  have hf:=CanonicalFormulaEnvelope.original_rows (m+2)
  simp only [initial,NativeRecordedFamily.original] at ht
  unfold nextBound
  rw [ht]
  have hr: (OriginalEncoding.rows (m+2) (3*(m+2)-4)).length≤128*(m+3)^2*2^(m+2):=by
    simpa only [Nat.add_assoc] using hf
  omega

theorem read_id_below_next (s : Store) (i : Nat) (R : Row)
    (h : read s (i:Int)=some R) : i<s.next := by
  unfold NativeSparseStore.read NativeReference.resolve NativeReference.normalize at h
  simp only [show ¬(i:Int)<0 by omega,↓reduceIte] at h
  split at h
  · rename_i hi;omega
  · simp at h

/-- The final contradiction's row ID survives the machine cast whenever
this stated allocation envelope fits. The envelope's prefix hypotheses are
still explicit, and this does not replace all intermediate-ID obligations. -/
theorem conclusion_cast (m A B C : Nat)
    (h0 : BoundedProgram C (RecordedUniformFamily.family 0))
    (ha : ∀i<m,(levelPrefix i).length≤A)
    (hb : ∀i<m,BoundedProgram B (levelPrefix i))
    (hlimit : nextBound m A B C≤referenceLimit) :
    read (NativeRecordedFamily.compiled (m+2)).store
      (Int64.ofNat (NativeRecordedFamily.conclusion (m+2))).toInt=some (REDWitness.clause []) := by
  have href:=(NativeRecordedFamily.physical_refutation (m+2) (by omega)).2
  have hi:=read_id_below_next _ _ _ href
  have hn:=next_bound m A B C h0 ha hb
  rw [positive_cast _ (by omega)]
  exact href

#print axioms positive_cast
#print axioms next_bound
#print axioms conclusion_cast
end L3Emitter.CanonicalMachineReference

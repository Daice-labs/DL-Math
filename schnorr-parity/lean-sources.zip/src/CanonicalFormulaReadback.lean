import CanonicalFieldCosts
import SignedSerialization

namespace L3Emitter.CanonicalFormulaReadback
open EREF TemplateBytes CanonicalScopedBytes

def fields (R : EREF.Row) : SignedNative.Row :=
  ⟨R.terms.map (fun t => ((t.1:Int),signedLiteral t.2)),R.bound⟩

theorem signed_id (l : Int) : SignedNative.litId (signedLiteral l)=l := by
  cases l <;> simp [SignedNative.litId,signedLiteral] <;> omega

theorem fields_terms (R : EREF.Row) : (fields R).termsZ=R.toSigned := by
  simp [fields,SignedNative.Row.termsZ,Row.toSigned,signed_id]

theorem fields_valid (R : EREF.Row) (hR : Canonical R) : (fields R).valid := by
  intro t ht
  obtain ⟨u,hu,rfl⟩ := List.mem_map.mp ht
  have hz := (hR.1 u hu).2
  change 0<u.2.natAbs
  exact Int.natAbs_pos.mpr hz

/-- Parsed signed fields reconstruct exactly the canonical original row, not
merely an equisatisfiable replacement. Lexing these fields is a separate link. -/
theorem normalized_fields (R : EREF.Row) (hR : Canonical R) :
    (fields R).normalized=R := by
  apply canonical_ext _ _ (SignedNative.normalized_canonical _) hR
  intro α
  rw [SignedNative.normalized_value _ (fields_valid R hR),fields_terms,tvalZ_toSigned]
  rfl

theorem positive_integer (n : Nat) : integer (n:Int)=number n := by
  simp [integer]

theorem field_document (R : EREF.Row) : SignedNative.row (fields R)=rowDoc R := by
  simp [SignedNative.row,fields,rowDoc,pbRow,row,List.map_map,Function.comp_def,positive_integer]

def formulaDoc (D : List EREF.Row) : Doc :=
  D.flatMap (fun R => rowDoc R++fixed " ;\n")

theorem formula_cost (D : List EREF.Row) :
    (emit (formulaDoc D)).length=
      (D.map CanonicalFieldCosts.rowBytes).sum+3*D.length := by
  rw [emit_length]
  simp only [formulaDoc,flatMap_bytes,exactBytes_append,CanonicalFieldCosts.row_exact,
    TemplateBytes.fixed_bytes]
  change (D.map (fun R=>CanonicalFieldCosts.rowBytes R+3)).sum=_
  induction D with
  | nil=>rfl
  | cons R D ih=>
    simp only [List.map_cons,List.sum_cons,List.length_cons] at *
    omega

theorem original_fields (n s : Nat) :
    ((OriginalEncoding.rows n s).map fields).map SignedNative.Row.normalized=
      OriginalEncoding.rows n s := by
  simp only [List.map_map]
  conv_rhs => rw [←List.map_id (OriginalEncoding.rows n s)]
  apply List.map_congr_left
  intro R hR
  exact normalized_fields R (OriginalEncoding.rows_canonical n s R hR)

#print axioms signed_id
#print axioms fields_valid
#print axioms normalized_fields
#print axioms field_document
#print axioms formula_cost
#print axioms original_fields
end L3Emitter.CanonicalFormulaReadback

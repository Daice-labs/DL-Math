import NumericActivationInputs
import NumericGuardFields
namespace L3Emitter.NumericActualActivation
open EREF EREF.GeneralRED RecordedScopedTrace RecordedOperandFields FieldLengthsFromIDs ByteOperandBounds
open ActualLowerComposition

def levelCost (n:Nat):Nat:=NumericClosedNamespace.envelope n+1+
  NumericGuardFields.rowCost (NumericActivationInputs.inputCost n+1)+NumericActivationInputs.inputCost n+3

def bound (n N:Nat):Nat:=N+levelCost n

theorem q_bound (n N:Nat) (hn:2≤n):RecordedActualActivation.q n hn N≤bound n N:=by
  have h:=NumericActualCeiling.ceiling n hn
  unfold RecordedActualActivation.q bound levelCost
  omega

theorem witness (n N:Nat) (hn:2≤n) (hN:FamilyNamespace.variableCount n (3*n-4)≤N):
    WitnessBound (bound n N) (RecordedActualActivation.witness n hn N):=by
  apply NumericActivationImages.entries
  · exact q_bound n N hn
  · exact hN
  · intro v
    have h:=(NumericActivationImages.image n hn v).trans (NumericClosedNamespace.final n)
    unfold bound levelCost
    exact h.trans (by omega)

theorem bank (n N:Nat) (hn:2≤n):
    ∀c∈RecordedActualActivation.bankProgram n hn N,Content (bound n N) c:=by
  have hq:0<RecordedActualActivation.q n hn N:=by unfold RecordedActualActivation.q;omega
  have hb:=NumericGuardFields.bank (NumericActivationInputs.inputCost n+1) (RecordedActualActivation.q n hn N)
    (upper n hn) (inputs n hn) amount (RecordedActualActivation.q n hn N) hq (by omega)
    (by
      intro R hr
      exact ⟨inputs_canonical n hn R hr,RecursiveOperandBounds.row_mono (by omega) R (NumericActivationInputs.inputs n hn R hr)⟩)
    (by intro R hr;exact ⟨amount_pos R,NumericActivationInputs.amount n hn R hr⟩)
  intro c hc
  apply RecursiveOperandBounds.content_mono _ c (hb c hc)
  apply max_le
  · exact q_bound n N hn
  · unfold bound levelCost;omega

theorem program (n N:Nat) (hn:2≤n) (hN:FamilyNamespace.variableCount n (3*n-4)≤N):
    ∀c∈RecordedActualActivation.program n hn N,Content (bound n N) c:=by
  intro c hc
  rcases List.mem_append.mp hc with hc|hc
  · rcases List.mem_append.mp hc with hc|hc
    · exact bank n N hn c hc
    · obtain rfl:=List.mem_singleton.mp hc
      exact NumericGuardFields.activate _ _ _ _ _ _ (q_bound n N hn)
        (by unfold bound levelCost;omega) (witness n N hn hN)
  · apply NumericGuardFields.cancel _ _ _ _ _ _ c hc
    intro R hr
    have hh:=NumericActivationInputs.amount n hn R hr
    unfold bound levelCost
    omega

/-- Instantiated activation fields, including every local RED certificate.
The accumulated tail affects only the additive reserve term M. -/
theorem reserved (n M:Nat) (hn:2≤n) (p:Program) (h:∀c∈p,Content M c):
    ∀c∈RecordedActualActivation.program n hn (RecordedRecursiveStep.reserve n p),
      Content (M+FamilyNamespace.variableCount n (3*n-4)+levelCost n) c:=by
  have hg:=ActualTailOperandBounds.guard_keys M p h
  have hN:FamilyNamespace.variableCount n (3*n-4)≤RecordedRecursiveStep.reserve n p:=by
    unfold RecordedRecursiveStep.reserve;omega
  have hN':RecordedRecursiveStep.reserve n p≤FamilyNamespace.variableCount n (3*n-4)+M:=by
    unfold RecordedRecursiveStep.reserve;omega
  intro c hc
  exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c
    (program n _ hn hN c hc)

#print axioms witness
#print axioms program
#print axioms reserved
end L3Emitter.NumericActualActivation

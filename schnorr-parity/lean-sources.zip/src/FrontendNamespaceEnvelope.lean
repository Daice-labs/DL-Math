import CanonicalCompleteTokenBudget
namespace L3Emitter.FrontendNamespaceEnvelope
open EREF EREF.GeneralRED L3 ConstructionFrontendCountTools

theorem var_after (m : Nat) (cs : List Cmd) : varAfter m cs≤m+list cs := by
  induction cs generalizing m with
  | nil=>simp [varAfter,list]
  | cons c cs ih=>
    cases c <;> simp only [varAfter,list,List.map_cons,List.sum_cons,ConstructionFrontendCountTools.command] <;>
      have h1:=ih (m+1) <;> have h0:=ih m <;> unfold list at h1 h0 <;> omega

theorem state_var {m : Nat} (t : StI m) : t.s.var≤m+state t := by
  rw [←t.inv.2]
  exact var_after m t.s.cmds

def scale (k : Nat):Nat:=(k+1)^2*2^k

theorem original (k : Nat) : FamilyNamespace.variableCount k (3*k-4)≤36*scale k := by
  have hs:3*k-4≤3*k:=Nat.sub_le ..
  have hp:=Nat.mul_le_mul hs (show 2*k+(3*k-4)-1≤5*k by omega)
  have ht:1≤2^k:=Nat.one_le_pow _ _ (by omega)
  have hk:k≤(k+1)^2:=by nlinarith
  have hk2:k^2≤(k+1)^2:=Nat.pow_le_pow_left (by omega) 2
  have hkm:=Nat.mul_le_mul_right (2^k) hk
  have hk2m:=Nat.mul_le_mul_right (2^k) hk2
  have hsT:=Nat.mul_le_mul_right (2^k) hs
  have hkT:=Nat.mul_le_mul_left k ht
  have hk2T:=Nat.mul_le_mul_left (k^2) ht
  unfold FamilyNamespace.variableCount FamilyNamespace.selectors FamilyNamespace.truthRows scale
  nlinarith

theorem frontend (k : Nat) (hk : 2≤k) :
    ((FableEncoding.fam k (3*k-4)).frontendX (by change 1≤3*k-4; omega)).s.var≤1000*scale k := by
  have hv:=state_var ((FableEncoding.fam k (3*k-4)).frontendX (by change 1≤3*k-4; omega))
  have hr:=ConstructionFrontendCount.recorded_length k (3*k-4) hk (by omega)
  have hl:=ConstructionFrontendCount.parity k hk
  have ho:=original k
  have ht:1≤2^k:=Nat.one_le_pow _ _ (by omega)
  have hs:800*(k+1)^2≤800*scale k:=by
    unfold scale
    have h:=Nat.mul_le_mul_left (800*(k+1)^2) ht
    nlinarith
  have he:=FableEncoding.variables_eq k (3*k-4)
  omega

theorem forcing_ceiling (k : Nat) (hk : 3≤k) : ForcingBounds.ceiling k hk≤1100*scale k := by
  have h:=frontend k (by omega)
  have hx:=ConstructionSelectionCount.branch_inputs k hk
  have hk2:k^2≤scale k:=by
    have h1:=Nat.pow_le_pow_left (show k≤k+1 by omega) 2
    have ht:1≤2^k:=Nat.one_le_pow _ _ (by omega)
    exact h1.trans (by unfold scale;exact Nat.le_mul_of_pos_right _ ht)
  have hpos:1≤scale k:=Nat.mul_pos (Nat.pow_pos (by omega)) (Nat.pow_pos (by omega))
  change (FrontendSelection.front k hk).s.var≤1000*scale k at h
  unfold ForcingBounds.ceiling
  change _+1+2*(FrontendSelection.xs k hk).length≤_
  omega

theorem forcing_upper (k : Nat) (hk : 3≤k) : ForcingFamily.upper k hk≤1200*scale k := by
  have h:=forcing_ceiling k hk
  have hc:=ForcingSize.chosen_bound k hk
  have ht:1≤2^k:=Nat.one_le_pow _ _ (by omega)
  have hk2:k^2≤scale k:=(Nat.pow_le_pow_left (show k≤k+1 by omega) 2).trans
    (by unfold scale;exact Nat.le_mul_of_pos_right _ ht)
  unfold ForcingFamily.upper
  omega

theorem restriction (k : Nat) (hk : 3≤k) : RestrictionBit.B k hk≤1400*scale k := by
  have h:=forcing_upper k hk
  have hx:=ConstructionSelectionCount.forcing_inputs k hk
  have ht:1≤2^k:=Nat.one_le_pow _ _ (by omega)
  have hk2:k^2≤scale k:=(Nat.pow_le_pow_left (show k≤k+1 by omega) 2).trans
    (by unfold scale;exact Nat.le_mul_of_pos_right _ ht)
  have hpos:1≤scale k:=Nat.mul_pos (Nat.pow_pos (by omega)) (Nat.pow_pos (by omega))
  unfold RestrictionBit.B RestrictionBit.upper
  omega

theorem constant (k : Nat) (hk : 3≤k) : ConstantConstruction.C k hk≤1500*scale k := by
  have h:=restriction k hk
  have hc:=SelectedValueSize.choice_count k hk
  have hs:3*k-4≤3*k:=Nat.sub_le ..
  have hw:RankConstruction.width k≤3*k:=by unfold RankConstruction.width;omega
  have hcount:RankConstruction.count k≤9*k^2:=by
    unfold RankConstruction.count
    nlinarith [Nat.mul_le_mul hs hw]
  have ht:1≤2^k:=Nat.one_le_pow _ _ (by omega)
  have hk2:k^2≤scale k:=(Nat.pow_le_pow_left (show k≤k+1 by omega) 2).trans
    (by unfold scale;exact Nat.le_mul_of_pos_right _ ht)
  have hpos:1≤scale k:=Nat.mul_pos (Nat.pow_pos (by omega)) (Nat.pow_pos (by omega))
  unfold ConstantConstruction.C ConstantConstruction.m
  omega
#print axioms frontend
#print axioms forcing_ceiling
#print axioms constant
end L3Emitter.FrontendNamespaceEnvelope

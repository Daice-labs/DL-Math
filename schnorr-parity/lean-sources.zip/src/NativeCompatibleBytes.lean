import NativeCompatibleFamily
import CanonicalPolynomialBytes
namespace L3Emitter.NativeCompatibleFamily
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace CanonicalScopedBytes

theorem rendered (n:Nat):bytes n=emit (CanonicalScopedBytes.proof (NativeRecordedFamily.original n) (emitter n) (conclusion n)):=by
 rw [bytes,CanonicalWholeFile.render,CanonicalWholeFile.join_append,CanonicalWholeFile.join_append,
  CanonicalWholeFile.prefix_bytes,CanonicalWholeFile.suffix_bytes]
 change emit (header (NativeRecordedFamily.original n).length)++
  CanonicalLineEncoding.eventBytes ((commands n).flatMap CanonicalFileGrammar.commandEvents)++emit (footer (conclusion n))=_
 rw [←CanonicalLineEncoding.commands_bytes]
 simp only [commands,CanonicalWireFamily.compiled_doc,CanonicalScopedBytes.proof,emit_append]

theorem serialized_bytes (n:Nat) (hn:2≤n):(bytes n).length≤NumericFamilyClosed.bytes n:=by
 let M:=NumericFamilyClosed.fields n
 have h:=WholeFileByteBudget.body_token_bytes M (M+1) (M+1) 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id (emitter n) (checked n hn) (fields n hn)
 have hp:(emitter n).length≤ConstructionCompleteCount.mainBound n:=by
  rw [emitter,NativeTautGoalCosts.main_length];exact ConstructionCompleteCount.main n hn
 have hc:AuditLocalCosts.certCount (emitter n)≤ConstructionClosedAllocation.certificateBound n:=
  (NativeTautGoalCosts.certs _ _).trans (ConstructionClosedAllocation.certificates n hn)
 have hl:AuditLocalCosts.localTokenCount (emitter n)≤ConstructionClosedAllocation.localTokenBound n:=
  (NativeTautGoalCosts.tokens _ _).trans (ConstructionClosedAllocation.local_tokens n hn)
 have ht:MainTapeRecurrence.count (emitter n)≤CanonicalFamilyMainTapes.mainTokenBound n:=by
  rw [emitter,NativeTautGoalCosts.main_tokens];exact CanonicalFamilyMainTapes.main n hn
 have h1:=Nat.mul_le_mul_left (SerializedActionBudget.overhead M (M+1) (M+1)+7) hp
 have h2:=Nat.mul_le_mul_left (22+2*digits M) hc
 have h3:=Nat.mul_le_mul_left (10+digits M) hl
 have h4:=Nat.mul_le_mul_left (3+digits M) ht
 have ha:ConstructionClosedReference.nextBound n≤M:=by unfold M NumericFamilyClosed.fields;omega
 have hf:(NativeRecordedFamily.original n).length≤M:=by
  have hfo:=CanonicalFormulaEnvelope.original_rows n
  unfold ConstructionClosedReference.nextBound ConstructionClosedAllocation.formulaBound at ha
  change (OriginalEncoding.rows n (3*n-4)).length≤M
  omega
 have hcon:=CanonicalMachineReference.read_id_below_next _ _ _ (execution n hn).2
 have hid:conclusion n≤M:=by have:=allocation n hn;omega
 have hd1:=digits_mono hf
 have hd2:=digits_mono hid
 rw [rendered,proof_exact,WholeFileByteBudget.header_bytes,WholeFileByteBudget.footer_bytes]
 change _≤CanonicalCompleteTokenBudget.byteEnvelope n M
 unfold WholeFileByteBudget.tokenBudget at h
 unfold CanonicalCompleteTokenBudget.byteEnvelope
 omega

theorem polynomial_bytes (n:Nat) (hn:2≤n):
 (bytes n).length≤CanonicalPolynomialBytes.polynomial (ConstructionFormulaScale.rows n):=by
 have hp:=NumericPolynomialFields.positive n hn
 have h2:NumericPolynomialFields.envelope n+1≤2*NumericPolynomialFields.envelope n:=by omega
 have h:1000*(NumericPolynomialFields.envelope n+1)^3≤1000*(2*NumericPolynomialFields.envelope n)^3:=Nat.mul_le_mul_left _ (Nat.pow_le_pow_left h2 3)
 apply (serialized_bytes n hn).trans ((CanonicalPolynomialBytes.envelope_bound n hn).trans (h.trans _))
 unfold NumericPolynomialFields.envelope CanonicalPolynomialBytes.polynomial
 calc
  1000*(2*(10^50*(ConstructionFormulaScale.rows n)^40))^3 = (8000*10^150)*(ConstructionFormulaScale.rows n)^120 := by ring
  _ ≤ _ := Nat.mul_le_mul_right _ (by decide)

/-- Native-compatible trivial-goal lowering has formal whole-file acceptance
and the SAME closed bound in ASCII BYTES. Native implementation correspondence
is still a distinct theorem. No family instances are evaluated here. -/
theorem accepted_and_bounded (n:Nat) (hn:2≤n):
 CanonicalByteAcceptance.check (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n))) (bytes n)=true ∧
 (bytes n).length≤NumericFamilyClosed.bytes n ∧
 (bytes n).length≤CanonicalPolynomialBytes.polynomial (ConstructionFormulaScale.rows n):=
 ⟨accepted n hn,serialized_bytes n hn,polynomial_bytes n hn⟩
#print axioms accepted_and_bounded
end L3Emitter.NativeCompatibleFamily

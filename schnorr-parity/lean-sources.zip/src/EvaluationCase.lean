import EvaluationCaseSeeds

namespace L3Emitter.EvaluationCase
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
variable {base:List Row}

def guards (α:Val) (e:Expr):=EvaluationCaseSeeds.guards α (ExpressionEvaluation.leaves e)
def seedRows (α:Val) (e:Expr):=EvaluationCaseSeeds.rows [] (guards α e)
def rows (α:Val) (e:Expr) (z:Net base):=seedRows α e++(ExpressionEvaluation.build α e z).1.rows (guards α e)
def program (α:Val) (e:Expr) (z:Net base) (D:List Row):=
  EvaluationCaseSeeds.program D [] (guards α e)++
    (ExpressionEvaluation.build α e z).1.program (guards α e) (D++seedRows α e)

theorem checks (α:Val) (e:Expr) (z:Net base) (D:List Row)
    (hd:∀R∈(e.compile z).2.rows,R∈D):
    check D (program α e z D)=some (D++rows α e z) ∧
    guarded (guards α e) (sign (e.value α) (e.compile z).1)∈D++rows α e z := by
  have hg:=EvaluationCaseSeeds.guards_valid α (ExpressionEvaluation.leaves e)
  have h0:=EvaluationCaseSeeds.checks D [] (guards α e) (by simp [Valid]) hg
  have h1:=ExpressionEvaluation.checks α e z (D++seedRows α e) (guards α e) hg
    (fun R h=>List.mem_append_left _ (hd R h))
    (fun b hb=>List.mem_append_right _ (EvaluationCaseSeeds.input_present α _ b hb))
  constructor
  · simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h1.1
  · simpa only [rows,List.append_assoc] using h1.2

/-- Count proof commands, including repeated test subtrees, rather than only network gates. -/
def cost:Expr→Nat
  | .lit _=>0
  | .and a b | .or a b=>cost a+cost b+1
  | .mux c a b=>2*cost c+cost a+cost b+3

theorem tree_count (α:Val) (e:Expr) (z:Net base):(ExpressionEvaluation.build α e z).1.count=cost e:=by
  induction e generalizing z with
  | lit b=>rfl
  | and a b ha hb=>simp [ExpressionEvaluation.build,EvaluationTree.Tree.count,cost,ha,hb]
  | or a b ha hb=>simp [ExpressionEvaluation.build,EvaluationTree.Tree.count,cost,ha,hb]
  | mux c a b hc ha hb=>simp [ExpressionEvaluation.build,EvaluationTree.Tree.count,cost,hc,ha,hb];omega

theorem commands_count (α:Val) (e:Expr) (z:Net base) (D:List Row):
    (program α e z D).length=2*(ExpressionEvaluation.leaves e).length+cost e:=by
  rw [program,List.length_append,EvaluationCaseSeeds.commands_count,EvaluationTree.Tree.commands_count,tree_count]
  simp [guards,EvaluationCaseSeeds.guards]

#print axioms checks
#print axioms commands_count
end L3Emitter.EvaluationCase

import GammaComparisonBank
import GammaValueJoin
namespace L3Emitter.GammaPreservation
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL CofactorValueRows
abbrev Job:=BetaPort.Job
def guards (n:Nat) (hn:2≤n) (j:Job n) (side:Bool) (frame:List Int):=
  [-BetaAliasValue.choice j,-sign side (GammaChoiceBank.hit n hn j.1)]++frame
def out (n:Nat) (hn:2≤n) (j:Job n) (u v:Bool):=sign v (unary n hn (GammaCofactorValue.g j) u)
def target (n:Nat) (hn:2≤n) (j:Job n) (v:Bool):=sign v (cofactor n hn (GammaCofactorValue.g j) j.2)
def leafLits (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool):=
  GammaComparison.G n hn j side a++GammaComparison.H n hn j u side b v++GammaComparison.Q n hn j side b v

def cmp (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool) (frame:List Int):=
  GammaValueJoin.comparison (guards n hn j side frame) (PrimaryAliasBank.cfg n hn).C
    (GammaComparison.otherUnary n hn j u side) (GammaCofactorValue.other n hn j side) (out n hn j u v) (target n hn j v) a b
def hypothesis (n:Nat) (hn:2≤n) (j:Job n) (u side b:Bool) (frame:List Int):=
  GammaValueJoin.inductionRow (guards n hn j side frame) (GammaComparison.otherUnary n hn j u side) (GammaCofactorValue.other n hn j side) b

theorem valid_guards (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (side:Bool) (frame:List Int) (hf:Valid frame):
    Valid (guards n hn j side frame):=
  EvaluationCaseSeeds.valid_join (by simp [Valid,BetaAliasValue.choice_valid n hn j hj,sign_valid]) hf

theorem weakened_binding (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (u side a b v:Bool) (frame:List Int) (hf:Valid frame):
    clause (leafLits n hn j u side a b v++frame)=cmp n hn j u side a b v frame:=by
  have hc:=BetaAliasValue.choice_valid n hn j hj
  apply ProjectionTrace.clause_perm _ _
    (EvaluationCaseSeeds.valid_join (by simp [leafLits,GammaComparison.G,GammaComparison.H,GammaComparison.Q,Valid,hc,sign_valid]) hf)
    (EvaluationCaseSeeds.valid_join (valid_guards n hn j hj side frame hf) (by simp [out,target,Valid,sign_valid]))
  apply List.perm_iff_count.mpr
  intro z
  simp only [leafLits,GammaComparison.G,GammaComparison.H,GammaComparison.Q,guards,out,target,
    List.count_append,List.count_cons,List.count_nil]
  omega

def pairs:List (Bool×Bool):=[(false,false),(false,true),(true,false),(true,true)]
def prepared (n:Nat) (hn:2≤n) (j:Job n) (u side v:Bool) (frame:List Int):=
  pairs.map fun ab=>cmp n hn j u side ab.1 ab.2 v frame
def prep (n:Nat) (hn:2≤n) (j:Job n) (u side v:Bool) (frame:List Int) (D:List Row):Program:=
  pairs.map fun ab=>(cmp n hn j u side ab.1 ab.2 v frame,ChoiceProjection.weakenTokens D (leafLits n hn j u side ab.1 ab.2 v) frame)

theorem prep_check (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (u side v:Bool) (frame:List Int) (hf:Valid frame)
    (D:List Row) (hd:∀R∈GammaComparisonBank.result n hn,R∈D):
    check D (prep n hn j u side v frame D)=some (D++prepared n hn j u side v frame):=by
  have h:=IndependentProgram.check_base D (prep n hn j u side v frame D) (by
    intro cmd hc;obtain ⟨ab,ha,rfl⟩:=List.mem_map.mp hc
    have hh:=ChoiceProjection.weaken_succeeds D (leafLits n hn j u side ab.1 ab.2 v) frame
      (by simp [leafLits,GammaComparison.G,GammaComparison.H,GammaComparison.Q,Valid,BetaAliasValue.choice_valid n hn j hj,sign_valid]) hf
      (hd _ (GammaComparisonBank.all_comparisons n hn j hj u side ab.1 ab.2 v))
    rw [weakened_binding n hn j hj u side ab.1 ab.2 v frame hf] at hh
    exact hh)
  simpa [prep,prepared,outputs,List.map_map,Function.comp_def] using h

def suffix (n:Nat) (hn:2≤n) (j:Job n) (u side v:Bool) (frame:List Int) (D:List Row):=
  GammaValueJoin.program D (guards n hn j side frame) (PrimaryAliasBank.cfg n hn).C
    (GammaComparison.otherUnary n hn j u side) (GammaCofactorValue.other n hn j side) (out n hn j u v) (target n hn j v)
def suffixRows (n:Nat) (hn:2≤n) (j:Job n) (u side v:Bool) (frame:List Int):=
  GammaValueJoin.rows (guards n hn j side frame) (PrimaryAliasBank.cfg n hn).C
    (GammaComparison.otherUnary n hn j u side) (out n hn j u v) (target n hn j v)
def program (n:Nat) (hn:2≤n) (j:Job n) (u side v:Bool) (frame:List Int) (D:List Row):=
  prep n hn j u side v frame D++suffix n hn j u side v frame (D++prepared n hn j u side v frame)
def rows (n:Nat) (hn:2≤n) (j:Job n) (u side v:Bool) (frame:List Int):=
  prepared n hn j u side v frame++suffixRows n hn j u side v frame

-- The induction premises are concrete rows. Their construction through earlier
-- source coordinates is deliberately not assumed to have been completed.
theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (u side v:Bool) (frame:List Int) (hf:Valid frame)
    (D:List Row) (hd:∀R∈GammaComparisonBank.result n hn,R∈D)
    (hi:∀b,hypothesis n hn j u side b frame∈D):
    check D (program n hn j u side v frame D)=some (D++rows n hn j u side v frame):=by
  have h0:=prep_check n hn j hj u side v frame hf D hd
  have h1:=GammaValueJoin.checks (D++prepared n hn j u side v frame)
    (guards n hn j side frame) (PrimaryAliasBank.cfg n hn).C (GammaComparison.otherUnary n hn j u side)
    (GammaCofactorValue.other n hn j side) (out n hn j u v) (target n hn j v)
    (valid_guards n hn j hj side frame hf) (sign_valid _ _) (sign_valid _ _)
    (fun b=>List.mem_append_left _ (hi b)) (by
      intro a b;apply List.mem_append_right
      apply List.mem_map.mpr;refine ⟨(a,b),?_,rfl⟩
      cases a <;> cases b <;> simp [pairs])
  simpa only [program,rows,suffix,suffixRows,List.append_assoc] using check_append _ _ _ _ _ h0 h1

theorem conclusion_present (n:Nat) (hn:2≤n) (j:Job n) (u side v:Bool) (frame:List Int):
    clause (guards n hn j side frame++[-out n hn j u v,target n hn j v])∈rows n hn j u side v frame:=by
  apply List.mem_append_right
  apply List.mem_append_right
  simp [GammaValueJoin.final]

theorem command_count (n:Nat) (hn:2≤n) (j:Job n) (u side v:Bool) (frame:List Int) (D:List Row):
    (program n hn j u side v frame D).length=11:=by
  simp [program,prep,pairs,suffix,GammaValueJoin.command_count]
#print axioms checks
#print axioms conclusion_present
end L3Emitter.GammaPreservation

import NativeParserFormula
namespace L3Emitter.NativeParserBundle
open EREF CanonicalFileGrammar NativeParserEventCoordinates PinnedCoordinateChange

structure Parsed where
 names:List Nat
 original:List Row
 commands:List CanonicalScopeKernel.Command
 conclusion:Nat

def parse (formula proof:Bytes):Option Parsed:=do
 let (initial,D)←NativeParserFormula.parse [] formula
 let (last,f)←NativeParserCheckedFile.parse initial proof
 if f.formulaRows=D.length then return ⟨last,D,f.commands,f.conclusion⟩ else none

def formulaNames (n:Nat):List Nat:=(NativeParserFormula.allocate [] (NativeRecordedFamily.original n)).1

def names (n:Nat):List Nat:=NativeParserCheckedFile.names (formulaNames n) n

def parsed (n:Nat):Parsed:=
 ⟨names n,(NativeRecordedFamily.original n).map (PinnedCoordinateChange.row (coordinate (names n))),
 (NativeCompatibleFamily.commands n).map (PinnedCoordinateChange.command (coordinate (names n))),
 NativeCompatibleFamily.conclusion n⟩

theorem original_rows (n:Nat):
 (NativeParserFormula.allocate [] (NativeRecordedFamily.original n)).2=
 (NativeRecordedFamily.original n).map (PinnedCoordinateChange.row (coordinate (names n))):=by
 unfold names NativeParserCheckedFile.names
 rw [NativeParserEventCoordinates.final_names]
 exact NativeParserFormula.later_names [] _ _

/-- Formula and proof bytes jointly parse to the single encounter-order
coordinate system used by the physical runtime theorem. The premise is the
actual allocation counter, so a sharp base witness is possible. -/
theorem family (n:Nat) (hn:2≤n)
 (hm:(NativeCompatibleFamily.compiled n).store.next≤CanonicalMachineReference.referenceLimit):
 parse (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n)))
   (NativeCompatibleFamily.bytes n)=some (parsed n):=by
 rw [parse,NativeParserFormula.family]
 simp only [bind,Option.bind]
 rw [NativeParserCheckedFile.family _ n hn hm]
 simp only [bind,Option.bind,NativeParserCheckedFile.file]
 rw [original_rows,List.length_map,if_pos rfl]
 rfl

/-- Combined parser/runtime projection result. The remaining compiled-Rust
simulation is deliberately not asserted by this theorem. -/
theorem parsed_execution (n:Nat) (hn:2≤n)
 (hm:(NativeCompatibleFamily.compiled n).store.next≤CanonicalMachineReference.referenceLimit):
 parse (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n)))
   (NativeCompatibleFamily.bytes n)=some (parsed n) ∧
 ∃q,PinnedTaggedScope.run (PinnedInternedFamily.initial (names n) n) (parsed n).commands=some q ∧
 ∃R,PinnedTaggedStore.read q ((parsed n).conclusion:Int)=some R ∧
 PinnedPackedArithmetic.row R=REDWitness.clause []:=by
 obtain ⟨q,hq,hproj,hr⟩:=PinnedInternedFamily.execution (names n) n hn
 exact ⟨family n hn hm,q,hq,hr⟩
#print axioms family
#print axioms parsed_execution
end L3Emitter.NativeParserBundle

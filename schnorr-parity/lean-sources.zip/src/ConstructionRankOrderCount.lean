import ConstructionTableCount
namespace L3Emitter.ConstructionRankOrderCount
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount

theorem pair_cases {A : Type} (D : List Row) (is : List A) (c : A→Int) (q r : Int)
    (side : A→Bool) (xs ys : List Int) :
    (ProjectionPrograms.pairCases D c q r side xs ys is).length=2*is.length := by
  induction is generalizing D with
  | nil=>rfl
  | cons i is ih=>
    simp only [ProjectionPrograms.pairCases,List.length_append,ih,List.length_cons]
    have h:(ProjectionPrograms.pairCase D (c i) q r (side i) xs ys).length=2:=by
      unfold ProjectionPrograms.pairCase;split <;> rfl
    rw [h];omega

theorem leaf (n : Nat) (hn : 2≤n) (j : RankOrderExclusion.Job) (D : List Row) :
    (RankOrderExclusion.leaf n hn j D).length≤19*(n+1)^2 := by
  have h:=ForcingSize.chosen_bound (n+1) (by omega)
  simp only [RankOrderExclusion.leaf,RankOrderExclusion.program,ProjectionPrograms.pair,
    List.length_append,pair_cases,List.length_cons,List.length_nil]
  nlinarith [Nat.one_le_pow 2 (n+1) (by omega)]

theorem jobs (n : Nat) : (RankOrderExclusion.jobs n).length≤81*(n+1)^4 := by
  unfold RankOrderExclusion.jobs
  have h:=flat_bound (List.range (3*(n+1)-4)) (fun g=>(List.range (3*(n+1)-4)).flatMap fun h=>(List.range (RankConstruction.width (n+1))).flatMap fun t=>(List.range (t+1)).flatMap fun u=>if 0<g ∧ g<h then [(g,h,t,u)] else []) ((3*(n+1)-4)*(RankConstruction.width (n+1))^2) (by
    intro g hg
    have hh:=flat_bound (List.range (3*(n+1)-4)) (fun h=>(List.range (RankConstruction.width (n+1))).flatMap fun t=>(List.range (t+1)).flatMap fun u=>if 0<g ∧ g<h then [(g,h,t,u)] else []) ((RankConstruction.width (n+1))^2) (by
      intro h hh
      have ht:=flat_bound (List.range (RankConstruction.width (n+1))) (fun t=>(List.range (t+1)).flatMap fun u=>if 0<g ∧ g<h then [(g,h,t,u)] else []) (RankConstruction.width (n+1)) (by
        intro t ht
        have hu:=flat_bound (List.range (t+1)) (fun u=>if 0<g ∧ g<h then [(g,h,t,u)] else []) 1 (by intro u hu;dsimp only;split <;> simp)
        simp only [List.length_range,Nat.mul_one] at hu
        exact hu.trans (by have:=List.mem_range.mp ht;omega))
      simpa only [List.length_range,pow_two] using ht)
    simpa only [List.length_range] using hh)
  simp only [List.length_range] at h
  have hw:RankConstruction.width (n+1)≤3*(n+1):=by unfold RankConstruction.width;omega
  have hm:=Nat.mul_le_mul (Nat.sub_le (3*(n+1)) 4)
    (Nat.mul_le_mul (Nat.sub_le (3*(n+1)) 4) (Nat.pow_le_pow_left hw 2))
  exact h.trans (hm.trans_eq (by ring))

theorem complete (n : Nat) (hn : 2≤n) : (RankOrderExclusion.emitted n hn).length≤1539*(n+1)^6 := by
  have h:=retained_fold (RankOrderExclusion.leaf n hn) (RankOrderExclusion.leafRows n hn)
    (RankOrderExclusion.jobs n) (RankTableBank.result n hn).1 (19*(n+1)^2)
    (by intro j hj D;exact leaf n hn j D)
  change (RankOrderExclusion.emitted n hn).length≤_ at h
  exact h.trans ((Nat.mul_le_mul_right _ (jobs n)).trans_eq (by ring))
#print axioms complete
end L3Emitter.ConstructionRankOrderCount

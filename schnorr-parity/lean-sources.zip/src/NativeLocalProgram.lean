import NativeSparseStore
import RecordedRefutation

namespace L3Emitter.NativeLocalProgram
open EREF EREF.GeneralRED NativeSparseStore
structure Built where
  store : Store
  ids : Nat → Nat
  tapes : List (List Tok)

def compile (len : Nat) (s : Store) (ids : Nat → Nat) : AliasProgram.Program → Built
  | [] => ⟨s,ids,[]⟩
  | (R,ts)::ps =>
    let rest := compile (len+1) (push s R) (extend ids len s.next) ps
    ⟨rest.store,rest.ids,ts.map (ReferenceTransport.token ids)::rest.tapes⟩

def execute (s : Store) : List (List Tok) → Option Store
  | [] => some s
  | ts::tss => match polEval s.rows ts [] with
    | none => none
    | some R => execute (push s R) tss

theorem correct (D E : List Row) (s : Store) (ids : Nat → Nat)
    (hs : 0 < s.next) (he : Embeds D s ids) (p : AliasProgram.Program)
    (hp : AliasProgram.check D p = some E) :
    execute s (compile D.length s ids p).tapes = some (compile D.length s ids p).store ∧
    Embeds E (compile D.length s ids p).store (compile D.length s ids p).ids ∧
    (compile D.length s ids p).store.next = s.next+p.length := by
  induction p generalizing D s ids with
  | nil =>
    simp only [AliasProgram.check,Option.some.injEq] at hp
    subst E
    exact ⟨rfl,he,by simp [compile]⟩
  | cons c p ih =>
    rcases c with ⟨R,ts⟩
    simp only [AliasProgram.check] at hp
    split at hp
    · rename_i hpol
      have hn := pol_reindex D s ids he ts [] R hpol
      have hh := ih (D++[R]) (push s R) (extend ids D.length s.next)
        (by dsimp [push];omega) (push_embeds D s ids he hs R) hp
      have hl : (D++[R]).length=D.length+1 := by simp
      rw [hl] at hh
      refine ⟨?_,hh.2.1,?_⟩
      · simpa only [compile,execute,hn] using hh.1
      · change (compile (D.length+1) (push s R) (extend ids D.length s.next) p).store.next = _
        rw [hh.2.2]
        change s.next+1+p.length=s.next+(p.length+1)
        omega
    · contradiction

theorem tapes_count (len : Nat) (s : Store) (ids : Nat → Nat) (p : AliasProgram.Program) :
    (compile len s ids p).tapes.length=p.length := by
  induction p generalizing len s ids with
  | nil => rfl
  | cons c p ih => simp [compile,ih]

theorem tokens_count (len : Nat) (s : Store) (ids : Nat → Nat) (p : AliasProgram.Program) :
    ((compile len s ids p).tapes.map List.length).sum=(p.map (fun x=>x.2.length)).sum := by
  induction p generalizing len s ids with
  | nil => rfl
  | cons c p ih => simp [compile,ih]

/-- Refutation conclusion survives physical-ID allocation with deletion holes.
 This remains a POL-store theorem, not parser or full native-checker refinement. -/
theorem conclusion (D : List Row) (s : Store) (ids : Nat → Nat)
    (hs : 0 < s.next) (he : Embeds D s ids) (p : RecordedRefutation.Certificate)
    (hp : RecordedRefutation.accepts D p=true) :
    ∃ R, read (compile D.length s ids p.program).store
      ((compile D.length s ids p.program).ids p.conclusion : Int)=some R ∧ Contra R := by
  unfold RecordedRefutation.accepts at hp
  split at hp
  · contradiction
  · rename_i E hE
    split at hp
    · contradiction
    · rename_i R hR
      have hc : Contra R := by unfold Contra; exact of_decide_eq_true hp
      have hh := correct D E s ids hs he p.program hE
      exact ⟨R,read_absolute E _ _ hh.2.1 p.conclusion R hR,hc⟩

#print axioms correct
#print axioms tapes_count
#print axioms tokens_count
#print axioms conclusion
end L3Emitter.NativeLocalProgram

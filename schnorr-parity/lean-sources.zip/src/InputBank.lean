import GammaConstant
import RemainingInput

namespace L3Emitter.InputBank
open EREF EREF.GeneralRED REDWitness CofactorSemantics FamilyNamespace
abbrev Job := Nat × Nat × Nat × Nat

def jobs (n s : Nat) : List Job := (List.range s).flatMap fun g => (List.range 2).flatMap fun p =>
  (List.range n).flatMap fun j => (List.range (truthRows n)).map fun x => (g,p,j+1,x)

theorem job_mem (n s : Nat) (q : Job) : q∈jobs n s ↔
    q.1<s ∧ q.2.1<2 ∧ 0<q.2.2.1 ∧ q.2.2.1<n+1 ∧ q.2.2.2<truthRows n := by
  obtain ⟨g,p,j,x⟩:=q
  simp only [jobs,List.mem_flatMap,List.mem_range,List.mem_map,Prod.mk.injEq]
  constructor
  · rintro ⟨g,hg,p,hp,j,hj,x,hx,hg',hp',hj',hx'⟩
    simp_all;omega
  · rintro ⟨hg,hp,hj,hjn,hx⟩
    exact ⟨g,hg,p,hp,j-1,by omega,x,hx,rfl,rfl,by omega,rfl⟩

def row (n : Nat) (hn : 2≤n) (j : Job) := RemainingInput.goal n (3*(n+1)-4)
  (ConstantCofactor.offset n hn) j.1 j.2.1 j.2.2.1 j.2.2.2

def sourceProgram (n : Nat) (hn : 2≤n) : AliasProgram.Program :=
  (jobs n (3*(n+1)-4)).map fun j => (row n hn j,
    RemainingInput.tape n (3*(n+1)-4) (ConstantCofactor.offset n hn) (ConstantCofactor.B n hn)
      j.1 j.2.1 j.2.2.1 j.2.2.2)

def base (n : Nat) (hn : 2≤n) := GammaConstant.result n hn

theorem source_subset (n : Nat) (hn : 2≤n) (R:Row) (hR:R∈ConstantCofactor.source n hn) : R∈base n hn :=
  List.mem_append_left _ (List.mem_append_left _ (WireBank.source_subset n hn R hR))

def program (n : Nat) (hn : 2≤n) := ProgramRebase.program (ConstantCofactor.source n hn) (base n hn)
  (sourceProgram n hn)
def result (n : Nat) (hn : 2≤n) := base n hn++(jobs n (3*(n+1)-4)).map (row n hn)

theorem program_check (n : Nat) (hn : 2≤n) :
    AliasProgram.check (base n hn) (program n hn)=some (result n hn) := by
  have hs:=IndependentProgram.check_base (ConstantCofactor.source n hn) (sourceProgram n hn) (by
    intro c hc
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hc
    have h:=(job_mem _ _ j).mp hj
    exact RemainingInput.succeeds n (3*(n+1)-4) (ConstantCofactor.offset n hn)
      (ConstantCofactor.B n hn) j.1 j.2.1 j.2.2.1 j.2.2.2
      (by unfold ConstantCofactor.B RestrictionBit.B;omega) h.1 h.2.1 h.2.2.1 h.2.2.2.1 h.2.2.2.2)
  have h:=ProgramRebase.program_check _ _ (source_subset n hn) _ _ hs
  simpa [program,result,sourceProgram,AliasProgram.outputs,List.map_map] using h

theorem original_to_all_inputs (n : Nat) (hn : 2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (GammaConstant.original_to_gamma_inputs n hn)
    (AliasProgram.check_trace _ _ _ (program_check n hn))

#print axioms program_check
#print axioms original_to_all_inputs
end L3Emitter.InputBank

import NumericPortBank
import NumericProgramFields
import NumericAliasClosed
namespace L3Emitter.NumericAliasTapes
open EREF EREF.GeneralRED RecordedOperandFields FieldLengthsFromIDs AliasNetwork

theorem selected (M:Nat) (D:List Row) (es todo:List ConcreteSelection.Cell) (q:Bit)
 (hc:∀e∈todo,NumericLoggedPorts.CellBound M e) (hq:q.val.natAbs≤M) (hl:es.length+1≤M):
 NumericProgramFields.Bounded M (ConcreteSelectionProgram.program D es q todo):=by
 induction todo generalizing D with
 | nil=>simp [ConcreteSelectionProgram.program,NumericProgramFields.Bounded]
 | cons e rest ih=>
   intro z hz;rcases List.mem_append.mp hz with hz|hz
   · apply NumericSelectionTapes.bit M D e.choice.val (ConcreteSelection.bit es q e)
       (hc e (by simp)).1 (hc e (by simp)).2.1 hq ?_ z hz
     simp only [ConcreteSelection.bit,ConcreteSelection.others,List.length_map]
     have hlen:(es.erase e).length≤es.length:=List.length_erase_le;omega
   · exact ih _ (by intro e he;exact hc e (by simp [he])) z hz

theorem ports (M:Nat) (D:List Row) (js:List ConcretePortRows.Job)
 (h:∀j∈js,NumericLoggedPorts.JobBound M j) (hl:∀j∈js,j.es.length+1≤M):
 NumericProgramFields.Bounded M (ConcretePortRows.program D js):=by
 induction js generalizing D with
 | nil=>simp [ConcretePortRows.program,NumericProgramFields.Bounded]
 | cons j js ih=>
   intro z hz;rcases List.mem_append.mp hz with hz|hz
   · exact selected M D j.es j.es j.q (h j (by simp)).2 (h j (by simp)).1 (hl j (by simp)) z hz
   · exact ih _ (by intro j hj;exact h j (by simp [hj])) (by intro j hj;exact hl j (by simp [hj])) z hz

theorem back (M:Nat) (D:List Row) (c a y v q:Bit):Tape M (ConcreteMux.backTape D c a y v q):=by
 intro t ht;simp only [ConcreteMux.backTape,List.mem_cons,List.not_mem_nil,or_false] at ht
 rcases ht with rfl|rfl|rfl|rfl|rfl <;> trivial

theorem mux (M:Nat) (D:List Row) (c a b y v q:Bit):
 NumericProgramFields.Bounded M (ConcreteMux.program D c a b y v q):=by
 intro z hz;simp only [ConcreteMux.program,List.mem_cons,List.not_mem_nil,or_false] at hz
 rcases hz with rfl|rfl|rfl|rfl
 · exact NumericSelectionTapes.forward M _ _ _ _ _
 · exact back M _ _ _ _ _ _
 · exact NumericSelectionTapes.forward M _ _ _ _ _
 · exact back M _ _ _ _ _ _

theorem expressions (M:Nat) (D:List Row) (js:List RecordedExpressions.Job):
 NumericProgramFields.Bounded M (RecordedExpressions.program D js):=by
 induction js generalizing D with
 | nil=>simp [RecordedExpressions.program,NumericProgramFields.Bounded]
 | cons j js ih=>
   intro z hz;rcases List.mem_append.mp hz with hz|hz
   · exact mux M _ _ _ _ _ _ _ z hz
   · exact ih _ z hz

def bound (n:Nat):Nat:=NumericValueClosed.bound n+NumericAliasClosed.bound n+145*(n+1)^3+1

theorem actual_ports (n:Nat) (hn:2≤n):
 NumericProgramFields.Bounded (bound n) (RecordedAliasRun.program n hn):=by
 apply ports
 · intro j hj;exact NumericLoggedPorts.job_mono (by unfold bound;omega) j (NumericPortBank.actual n hn j hj)
 · intro j hj
   have hm:=ConcretePortCost.built_count n hn
   rw [RecordedAliasRun.program,ConcretePortCost.program_count] at hm
   have h2:(n+1)^2≤(n+1)^3:=Nat.pow_le_pow_right (by omega) (by omega)
   have hlen:j.es.length≤ConcretePortCost.mass (RecordedAliasRun.built n hn).1.2:=by
     exact List.single_le_sum (fun _ _=>Nat.zero_le _) j.es.length (List.mem_map.mpr ⟨j,hj,rfl⟩)
   unfold bound;nlinarith

theorem program (n:Nat) (hn:2≤n):
 ∀c∈RecordedAliasBanks.program n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · rcases List.mem_append.mp hc with hc|hc
   · exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c (NumericAliasClosed.fields n hn c hc)
   · exact NumericProgramFields.pol (bound n) _ (actual_ports n hn) c hc
 · exact NumericProgramFields.pol (bound n) _ (expressions (bound n) _ _) c hc
#print axioms program
end L3Emitter.NumericAliasTapes

import NumericRestrictionSelection
import NumericRankDefinitions
import NumericSelectedValue
namespace L3Emitter.NumericCofactorSelection
open EREF EREF.GeneralRED FieldLengthsFromIDs

theorem program (k:Nat) (hk:3≤k):
 ∀c∈RecordedCofactorSelection.program k hk,Content (NumericRestrictionSelection.bound k) c:=by
 let M:=NumericRestrictionSelection.bound k
 have hC:ConstantConstruction.C k hk≤M:=by
   have h:=FrontendNamespaceEnvelope.constant k hk
   unfold M NumericRestrictionSelection.bound;omega
 have hw:26+((ConstantConstruction.choices k hk).length+2)^2≤M:=by
   have h:=SelectedValueSize.choice_count k hk
   have hh:=Nat.pow_le_pow_left (show (ConstantConstruction.choices k hk).length+2≤36*k^2+2 by omega) 2
   unfold M NumericRestrictionSelection.bound;omega
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · rcases List.mem_append.mp hc with hc|hc
   · exact NumericRestrictionSelection.program k hk c hc
   · apply NumericRankDefinitions.program M k hk ?_ ?_ c hc
     · unfold ConstantConstruction.C ConstantConstruction.m at hC;omega
     · have h:=ForcingSize.chosen_bound k hk
       have hh:=Nat.pow_le_pow_left (show (BranchChoices.chosen k hk).length+2≤36*k^2+2 by omega) 2
       unfold M NumericRestrictionSelection.bound;omega
 · exact NumericSelectedValue.program M _ _ _ _ (ConstantConstruction.choice_bounds k hk)
     (ConstantConstruction.value_bounds k hk) hC hw c hc
#print axioms program
end L3Emitter.NumericCofactorSelection

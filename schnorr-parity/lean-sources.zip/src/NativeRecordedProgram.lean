import NativeRecordedStep
namespace L3Emitter.NativeRecordedProgram
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

/- The executable physical-store projection of a complete recorded program.
The shadow database is reconstructed from the last physical row, not supplied
as the expected output. Full native syntax/implementation refinement is separate. -/
structure Built where
  store : Store
  ids : Nat→Nat
  actions : List NativeRecordedStep.Action

def compile (D : List Row) (s : Store) (ids : Nat→Nat) : Program→Built
  | [] => ⟨s,ids,[]⟩
  | c::cs =>
    let b := NativeRecordedStep.compile D s ids c
    let rest := compile (D++[c.row]) b.store b.ids cs
    ⟨rest.store,rest.ids,b.action::rest.actions⟩

def execute (D : List Row) (s : Store) : List NativeRecordedStep.Action→Option Store
  | [] => some s
  | a::rest => do
    let t ← NativeRecordedStep.execute D s a
    let R ← t.rows (t.next-1)
    execute (D++[R]) t rest

theorem last_row (D : List Row) (s : Store) (ids : Nat→Nat) (c : Step) :
    (NativeRecordedStep.compile D s ids c).store.rows
      ((NativeRecordedStep.compile D s ids c).store.next-1)=some c.row := by
  cases c <;> simp [NativeRecordedStep.compile,push,Step.row]

theorem correct (M guard : Nat) (D E : List Row) (s : Store) (ids : Nat→Nat)
    (p : Program) (hs : 0<s.next) (he : Embeds D s ids)
    (hp : check M guard D p=some E) :
    execute D s (compile D s ids p).actions=some (compile D s ids p).store ∧
    Embeds E (compile D s ids p).store (compile D s ids p).ids ∧
    0<(compile D s ids p).store.next := by
  induction p generalizing D s ids with
  | nil =>
    simp only [check,Option.some.injEq] at hp
    subst E
    exact ⟨rfl,he,hs⟩
  | cons c p ih =>
    simp only [check] at hp
    split at hp
    · rename_i hc
      have hh := NativeRecordedStep.correct M guard D s ids c hs he hc
      have ht := ih (D++[c.row]) (NativeRecordedStep.compile D s ids c).store
        (NativeRecordedStep.compile D s ids c).ids hh.2.2 hh.2.1 hp
      refine ⟨?_,ht.2⟩
      simp only [compile,execute,hh.1,bind,Option.bind,last_row]
      exact ht.1
    · contradiction

theorem action_count (D : List Row) (s : Store) (ids : Nat→Nat) (p : Program) :
    (compile D s ids p).actions.length=p.length := by
  induction p generalizing D s ids with
  | nil => rfl
  | cons c p ih => simp only [compile,List.length_cons,ih]

#print axioms correct
#print axioms last_row
#print axioms action_count
end L3Emitter.NativeRecordedProgram

import GlobalPortTapeBounds
namespace L3Emitter.GlobalValueTokenEnvelope
open EREF U2ConstructionSize

theorem closed (n : Nat) (hn : 2≤n) :
    tokens (GlobalValueInduction.program n hn)≤1500000*(n+1)^5*2^n := by
  have h:=GlobalMainTapeBounds.all_gate_tokens n hn
  have hb:(832*n+256)*(36*(n+1)^2)+2≤30000*(n+1)^3:=by
    have hm:=Nat.mul_le_mul_right (36*(n+1)^2) (show 832*n+256≤832*(n+1) by omega)
    have hp:1≤(n+1)^3:=Nat.one_le_pow _ _ (by omega)
    nlinarith
  have hm:=Nat.mul_le_mul (Nat.sub_le (3*(n+1)) 5)
    (Nat.mul_le_mul (Nat.mul_le_mul_right 4 (Nat.mul_le_mul_left (2^n) (show 4*n-4≤4*(n+1) by omega))) hb)
  exact h.trans (hm.trans (by nlinarith [Nat.zero_le ((n+1)^5*2^n)]))

theorem in_formula (n : Nat) (hn : 2≤n) :
    tokens (GlobalValueInduction.program n hn)≤1500000*(ConstructionFormulaScale.rows n)^6 := by
  exact (closed n hn).trans (by simpa using ConstructionFormulaScale.monomial n 5 1 1500000 hn)
#print axioms closed
#print axioms in_formula
end L3Emitter.GlobalValueTokenEnvelope

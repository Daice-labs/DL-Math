import AliasProgramCost
import AliasOutput

namespace L3Emitter.AliasNetwork
open EREF EREF.GeneralRED REDWitness
variable {base : List Row}

def Gate.pattern (g : Gate) :=
  (if g.isAnd then andGate else orGate) (g.xs.map Subtype.val)

def Gate.commands (g : Gate) : List Command :=
  g.pattern.map (TemplateBytes.gateCommand g.q)

def Net.commands (z : Net base) : List Command := z.gates.flatMap Gate.commands
def Net.document (z : Net base) : Doc := z.gates.flatMap Gate.document

theorem gate_document_binding (g : Gate) :
    g.document=g.commands.flatMap command := by
  simp [Gate.document,Gate.commands,Gate.pattern,TemplateBytes.gateDoc,List.flatMap_map]

theorem network_document_binding (z : Net base) :
    z.document=z.commands.flatMap command := by
  simp only [Net.document,Net.commands,List.flatMap_assoc]
  congr 1
  funext g
  exact gate_document_binding g

/-- Rows extracted from the exact RED commands, including their witness.
    This binds the Lean syntax tree. It is not a theorem about the native
    executable's text parser. -/
theorem command_binding (g : Gate) :
    g.commands = g.pattern.map (fun r=>
      Command.red (TemplateBytes.gatePB g.q r) [(g.q,.bit r.bit)]) := rfl

theorem gate_rows_binding (g : Gate) :
    (g.pattern.map (TemplateBytes.gatePB g.q)).map TemplateBytes.decodeRow=g.rows := by
  simpa [Gate.pattern,Gate.rows] using
    TemplateBytes.serialized_gate_rows_binding g.q g.pattern

theorem network_rows_binding (z : Net base) :
    base++z.gates.flatMap (fun g=>
      (g.pattern.map (TemplateBytes.gatePB g.q)).map TemplateBytes.decodeRow)=z.rows := by
  simp only [gate_rows_binding,Net.rows]

theorem serialized_rows_checked (z : Net base) :
    CheckedTrace base (base++z.gates.flatMap (fun g=>
      (g.pattern.map (TemplateBytes.gatePB g.q)).map TemplateBytes.decodeRow)) := by
  rw [network_rows_binding]
  exact z.checked

def Gate.byteCount (g : Gate) : Nat :=
  (if g.isAnd then 24+34*g.xs.length else 25+33*g.xs.length)+
  2*(g.xs.map (fun l=>digits l.val.natAbs)).sum+
  2*(g.xs.length+1)*digits g.q

theorem gate_exact_bytes (g : Gate) (hq : 0<g.q) :
    (emit g.document).length=g.byteCount := by
  have hv : Valid (g.xs.map Subtype.val) := by
    intro l hl
    obtain ⟨b,hb,rfl⟩:=List.mem_map.mp hl
    exact b.property
  cases h:g.isAnd
  · simpa [Gate.document,Gate.byteCount,h,List.map_map] using
      TemplateBytes.or_exact_bytes g.q hq (g.xs.map Subtype.val) hv
  · simpa [Gate.document,Gate.byteCount,h,List.map_map] using
      TemplateBytes.and_exact_bytes g.q hq (g.xs.map Subtype.val) hv

theorem network_exact_bytes (z : Net base) (hq : ∀g∈z.gates,0<g.q) :
    (emit z.document).length=(z.gates.map Gate.byteCount).sum := by
  rw [emit_length,Net.document,TemplateBytes.flatMap_bytes]
  congr 1
  apply List.map_congr_left
  intro g hg
  exact (emit_length g.document).symm.trans (gate_exact_bytes g (hq g hg))

def Gate.ids (g : Gate) : List Nat := g.q::g.xs.map (fun l=>l.val.natAbs)
def Net.maximumId (z : Net base) := (z.gates.flatMap Gate.ids).foldr max 0
def Net.inputCount (z : Net base) := (z.gates.map (fun g=>g.xs.length)).sum

theorem gate_bytes_bound (g : Gate) (M : Nat)
    (hq : 0<g.q) (hm : ∀i∈g.ids,i≤M) :
    (emit g.document).length≤25+34*g.xs.length+(4*g.xs.length+2)*digits M := by
  have hv : Valid (g.xs.map Subtype.val) := by
    intro l hl;obtain ⟨b,hb,rfl⟩:=List.mem_map.mp hl;exact b.property
  have hqM:=hm g.q (by simp [Gate.ids])
  have hin : ∀l∈g.xs.map Subtype.val,l.natAbs≤M := by
    intro l hl
    obtain ⟨b,hb,rfl⟩:=List.mem_map.mp hl
    exact hm b.val.natAbs
      (List.mem_cons_of_mem _ (List.mem_map.mpr ⟨b,hb,rfl⟩))
  cases h:g.isAnd
  · have ht:=TemplateBytes.or_bytes_bound g.q M hq hqM (g.xs.map Subtype.val) hv hin
    simp only [List.length_map] at ht
    change (emit (TemplateBytes.gateDoc g.q _)).length≤_
    simp only [h,Bool.false_eq_true,↓reduceIte]
    omega
  · have ht:=TemplateBytes.and_bytes_bound g.q M hq hqM (g.xs.map Subtype.val) hv hin
    simp only [List.length_map] at ht
    change (emit (TemplateBytes.gateDoc g.q _)).length≤_
    simp only [h,↓reduceIte]
    omega

theorem gate_sum_bound (gs : List Gate) (M : Nat)
    (hq : ∀g∈gs,0<g.q) (hm : ∀g∈gs,∀i∈g.ids,i≤M) :
    (gs.map (fun g=>(emit g.document).length)).sum≤
      25*gs.length+34*(gs.map (fun g=>g.xs.length)).sum+
      (4*(gs.map (fun g=>g.xs.length)).sum+2*gs.length)*digits M := by
  induction gs with
  | nil => simp
  | cons g gs ih =>
    have hh:=gate_bytes_bound g M (hq g (by simp)) (hm g (by simp))
    have ht:=ih (by intro g hg;exact hq g (by simp [hg]))
      (by intro g hg;exact hm g (by simp [hg]))
    simp only [List.map_cons,List.sum_cons,List.length_cons]
    nlinarith

/-- Actual decimal serialization bound; the input and ID measures are
    computed from the emitted list, rather than assumed allocator bounds. -/
theorem network_bytes_bound (z : Net base) (hq : ∀g∈z.gates,0<g.q) :
    (emit z.document).length≤25*z.gates.length+34*z.inputCount+
      (4*z.inputCount+2*z.gates.length)*digits z.maximumId := by
  have hm : ∀g∈z.gates,∀i∈g.ids,i≤z.maximumId := by
    intro g hg i hi
    exact CanonicalTrace.fold_max_bound _ i (List.mem_flatMap.mpr ⟨g,hg,hi⟩)
  have h:=gate_sum_bound z.gates z.maximumId hq hm
  simpa only [Net.document,Net.inputCount,emit_length,TemplateBytes.flatMap_bytes] using h

#print axioms serialized_rows_checked
#print axioms network_exact_bytes
#print axioms network_bytes_bound
end L3Emitter.AliasNetwork

import ConstructionTransportTools
import RecordedTableTransport
import RecordedFinalRows

namespace L3Emitter.ConstructionTableBounds
open EREF EREF.GeneralRED RecordedScopedTrace CanonicalReplayEnvelope
open ConstructionLocalTools ConstructionFreshBounds ConstructionFoldBounds ConstructionTransportTools

theorem ports (n : Nat) (hn : 2≤n) (D : List Row) (js : List RankPortBank.Job) :
    BoundedProgram 3 (RecordedRankPorts.runProgram n hn D js) := by
  induction js generalizing D with
  | nil=>exact empty 3
  | cons j js ih=>exact append 3 _ _ (append 3 _ _ (coordinate _ _ _ _ _) (polProgram 3 _)) (ih _)

theorem values (n : Nat) (hn : 2≤n) (D : List Row) (rs : List (RankPortBank.Record n)) :
    BoundedProgram 3 (RecordedRankPortValues.runProgram n hn D rs) := by
  induction rs generalizing D with
  | nil=>exact empty 3
  | cons r rs ih=>exact append 3 _ _ (append 3 _ _ (coordinate _ _ _ _ _) (polProgram 3 _)) (ih _)

theorem raw (n : Nat) (hn : 2≤n) (D : List Row) (rs : List (RawLowerInputBank.Port n)) :
    BoundedProgram 3 (RecordedRawLowerInputs.runProgram n hn D rs) := by
  induction rs generalizing D with
  | nil=>exact empty 3
  | cons r rs ih=>exact append 3 _ _ (coordinate _ _ _ _ _) (ih _)

theorem tables (n : Nat) (hn : 2≤n) (D : List Row) (ts : List Nat) :
    BoundedProgram 3 (RecordedRankTables.runProgram n hn D ts) := by
  induction ts generalizing D with
  | nil=>exact empty 3
  | cons t ts ih=>exact append 3 _ _ (coordinate _ _ _ _ _) (ih _)

theorem transport (n : Nat) (hn : 2≤n) : BoundedProgram 3 (RecordedTableTransport.program n hn) := by
  unfold RecordedTableTransport.program RecordedTableTransport.p5 RecordedTableTransport.p4
    RecordedTableTransport.p3 RecordedTableTransport.p2 RecordedTableTransport.p1 RecordedTableTransport.p0
  exact append 3 _ _ (append 3 _ _ (append 3 _ _ (append 3 _ _
    (append 3 _ _ (ports n hn _ _) (values n hn _ _)) (raw n hn _ _)) (polProgram 3 _))
    (append 3 _ _ (network _ _) (polProgram 3 _))) (tables n hn _ _)

theorem finalRows (n : Nat) (hn : 2≤n) : BoundedProgram 3 (RecordedFinalRows.program n hn) := by
  unfold RecordedFinalRows.program RecordedFinalRows.p10 RecordedFinalRows.p9 RecordedFinalRows.p8
    RecordedFinalRows.p7 RecordedFinalRows.p6 RecordedFinalRows.p5 RecordedFinalRows.p4
    RecordedFinalRows.p3 RecordedFinalRows.p2 RecordedFinalRows.p1 RecordedFinalRows.p0
  repeat first
    | apply ConstructionLocalTools.append
    | exact polProgram 3 _
    | exact network _ _

#print axioms transport
#print axioms finalRows
end L3Emitter.ConstructionTableBounds

import DecimalParser
import FiniteWitness

namespace L3Emitter.LiteralParser

def positive (negative : Bool) (digits : Bytes) : Option Literal :=
  match DecimalParser.parse digits with
  | none => none
  | some n => if 0 < n then some ⟨n,negative⟩ else none

def parse : Bytes → Option Literal
  | 120::ds => positive false ds
  | 126::120::ds => positive true ds
  | _ => none

theorem encoded (l : Literal) : emit (literal l) =
    (if l.negative then [126,120] else [120])++decimal l.varId := by
  cases l with
  | mk n b => cases b <;> simp [literal,emit,fixed,number,Piece.emit,ascii] <;> rfl

theorem roundtrip (l : Literal) (h : 0 < l.varId) :
    parse (emit (literal l)) = some l := by
  rcases l with ⟨n,b⟩
  cases b <;> simp only [encoded,Bool.false_eq_true,Bool.true_eq,↓reduceIte,
    List.cons_append,List.nil_append,parse,positive,DecimalParser.roundtrip,
    Option.bind_some,if_pos h]

def integer : Bytes → Option Int
  | [] => none
  | b::ds => if b = 45 then (DecimalParser.parse ds).map (fun n => -(n:Int))
      else (DecimalParser.parse (b::ds)).map (fun n => (n:Int))

theorem first_decimal_not_minus (n : Nat) : ∀ b bs, decimal n = b::bs → b ≠ 45 := by
  intro b bs he
  have hm : b ∈ decimal n := by rw [he]; simp
  obtain ⟨c,hc,hb⟩ := List.mem_map.mp hm
  have hd := Nat.isDigit_of_mem_toDigits (by decide : 0 < 10) (by decide : 10 ≤ 10) hc
  have hr : 48 ≤ c.toNat ∧ c.toNat ≤ 57 := by simpa only [Char.isDigit,Bool.and_eq_true,decide_eq_true_eq] using hd
  intro heq
  have hh := congrArg UInt8.toNat heq
  rw [←hb,UInt8.toNat_ofNat',Nat.mod_eq_of_lt (by omega)] at hh
  change c.toNat = 45 at hh
  omega

theorem integer_positive (n : Nat) : integer (decimal n) = some (n:Int) := by
  cases he : decimal n with
  | nil => have hp := digits_pos n; have hh := decimal_length n; simp [he] at hh; omega
  | cons b bs =>
    have hn := first_decimal_not_minus n b bs he
    have hp : DecimalParser.parse (b::bs) = some n := by rw [←he]; exact DecimalParser.roundtrip n
    simp [integer,hn,hp]

theorem integer_roundtrip (n : Int) : integer (emit (L3Emitter.integer n)) = some n := by
  cases n with
  | ofNat n =>
    rw [Int.ofNat_eq_natCast]
    simpa [L3Emitter.integer,show ¬(n:Int) < 0 by omega,emit,number,Piece.emit] using integer_positive n
  | negSucc n =>
    have he : emit (L3Emitter.integer (Int.negSucc n)) = 45::decimal (n+1) := by
      simp [L3Emitter.integer,emit,fixed,number,Piece.emit,ascii]
      rfl
    rw [he]
    simp [integer,DecimalParser.roundtrip]
    omega

#print axioms roundtrip
#print axioms integer_roundtrip
end L3Emitter.LiteralParser

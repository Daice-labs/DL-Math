import RecordedOperandFields
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Range
namespace L3Emitter.FieldLengthsFromIDs
open EREF EREF.GeneralRED RecordedScopedTrace ByteOperandBounds RecordedOperandFields

theorem list_length (M : Nat) (xs : List Nat) (h:xs.Nodup) (hb:∀x∈xs,x≤M) : xs.length≤M+1 := by
  have hs:xs.toFinset⊆Finset.range (M+1):=by
    intro x hx
    exact Finset.mem_range.mpr (by have:=hb x (List.mem_toFinset.mp hx);omega)
  have hc:=Finset.card_le_card hs
  rwa [List.toFinset_card_of_nodup h,Finset.card_range] at hc

/-- Canonical rows contain each variable at most once. This discharges
serialized term-count bounds from the variable-ID ceiling. -/
theorem row_length (M : Nat) (R : Row) (hc:Canonical R) (h:RowBound M R) : R.terms.length≤M+1 := by
  have hs:(R.terms.map (fun t=>t.2.natAbs)).Pairwise (· < ·):=by
    simpa only [List.pairwise_map] using hc.2
  have hn:=EREF.nodup_of_sorted _ hs
  have hh:=list_length M (R.terms.map (fun t=>t.2.natAbs)) hn (by
    intro x hx;obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hx;exact (h.1 t ht).2)
  simpa only [List.length_map] using hh

/-- Valid finite witnesses have distinct keys. Count is bounded without
assuming a separate list-length envelope. -/
theorem witness_length (M : Nat) (w : FiniteWitness.Data) (hv:FiniteWitness.valid w=true)
    (h:WitnessBound M w) : w.length≤M+1 := by
  have hn: (w.map Prod.fst).Nodup:=of_decide_eq_true (Bool.and_eq_true_iff.mp hv).2
  have hh:=list_length M (w.map Prod.fst) hn (by
    intro x hx;obtain ⟨e,he,rfl⟩:=List.mem_map.mp hx;exact (h e he).1)
  simpa only [List.length_map] using hh

def Content (M : Nat) : Step→Prop
  | .pol _ ts=>Tape M ts
  | .consequence R p=>RowBound M R ∧ Local M p
  | .red R w ps=>RowBound M R ∧ WitnessBound M w ∧ ∀p∈ps,Local M p

theorem widths (M limit guard : Nat) (D : List Row) (c : Step)
    (hc:c.accepts limit guard D=true) (h:Content M c) : StepFields M (M+1) (M+1) c := by
  cases c with
  | pol R ts=>exact h
  | consequence R p=>
    have hcan:Canonical R:=of_decide_eq_true (Bool.and_eq_true_iff.mp hc).1
    exact ⟨h.1,row_length M R hcan h.1,h.2⟩
  | red R w ps=>
    have hpre:=(Bool.and_eq_true_iff.mp (Bool.and_eq_true_iff.mp hc).1).1
    have hcan:Canonical R:=of_decide_eq_true (Bool.and_eq_true_iff.mp hpre).1
    have hw:FiniteWitness.valid w=true:=(Bool.and_eq_true_iff.mp hpre).2
    exact ⟨h.1,row_length M R hcan h.1,h.2.1,witness_length M w hw h.2.1,h.2.2⟩

theorem program_widths (M limit guard : Nat) (D E : List Row) (p : Program)
    (hp:check limit guard D p=some E) (h:∀c∈p,Content M c) : ProgramFields M (M+1) (M+1) p := by
  induction p generalizing D with
  | nil=>simp [ProgramFields]
  | cons c cs ih=>
    simp only [check] at hp
    split at hp
    · rename_i hc
      intro t ht
      rcases List.mem_cons.mp ht with rfl|ht
      · exact widths M limit guard D t hc (h t (by simp))
      · exact ih _ hp (fun q hq=>h q (by simp [hq])) t ht
    · contradiction
#print axioms row_length
#print axioms witness_length
#print axioms program_widths
end L3Emitter.FieldLengthsFromIDs

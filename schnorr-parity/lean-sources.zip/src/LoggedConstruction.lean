import RecordedExpressionRun
namespace L3Emitter.LoggedConstruction
open EREF EREF.GeneralRED REDWitness AliasNetwork RecordedExpressions RecordedExpressionRun
variable {base:List Row} {A B:Type}

def Certified (p:Logged base A):Prop:=Correct p ∧ Extends (forget p)

theorem lift (p:StateM (Net base) A) (hp:Extends p):Certified (RecordedExpressions.lift p):=
  ⟨lift_correct p,hp⟩
theorem pure (a:A):Certified (RecordedExpressions.lift (base:=base) (Pure.pure a)):=
  lift _ (pure_extends a)
theorem mux (c a b:Bit):Certified (RecordedExpressions.mux (base:=base) c a b):=
  ⟨mux_correct c a b,mux_extends c a b⟩
theorem bind (p:Logged base A) (f:A→Logged base B) (hp:Certified p) (hf:∀a,Certified (f a)):
    Certified (RecordedExpressions.bind p f):=by
  refine ⟨bind_correct p f hp.1 (fun a=>(hf a).1) (fun a=>(hf a).2),?_⟩
  rw [forget_bind]
  exact bind_extends _ _ hp.2 (fun a=>(hf a).2)
theorem tabulate (n:Nat) (f:Fin n→Logged base A) (hf:∀i,Certified (f i)):
    Certified (tabulateLog n f):=by
  refine ⟨tabulate_correct n f (fun i=>(hf i).1) (fun i=>(hf i).2),?_⟩
  rw [tabulate_binding]
  exact tabulate_extends n _ (fun i=>(hf i).2)
#print axioms bind
#print axioms tabulate
end L3Emitter.LoggedConstruction

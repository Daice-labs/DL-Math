import GammaComparison
namespace L3Emitter.GammaTapeBytes
open EREF EREF.GeneralRED REDWitness AliasProgram PolTapeBytes ClauseTransport

theorem resolve_bounded (D:List Row) (G H Q:List Int) (a:Int) (M:Nat)
    (hd:D.length+1≤M) (hm:∀l∈H++Q,l.natAbs≤M) (h2:2≤M):
    ∀t∈CommonGuardResolve.tape D G H Q a,Bounded M t:=by
  intro t ht
  simp only [CommonGuardResolve.tape,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at ht
  rcases ht with ((rfl|rfl|rfl)|ht)|rfl
  · exact (ProjectionBytes.locate_bound D _).trans hd
  · exact (ProjectionBytes.locate_bound D _).trans hd
  · trivial
  · exact ProjectionBytes.pad_bound M _ hm t ht
  · exact h2

theorem resolve_bytes (D:List Row) (G H Q:List Int) (a:Int) (M:Nat)
    (hd:D.length+1≤M) (hm:∀l∈H++Q,l.natAbs≤M) (h2:2≤M):
    (emit (tapeDoc (CommonGuardResolve.tape D G H Q a))).length≤7+(4+2*(H.length+Q.length))*(3+digits M):=by
  have h:=tape_bound M _ (resolve_bounded D G H Q a M hd hm h2)
  rw [CommonGuardResolve.token_count] at h
  exact h

theorem unary_tokens (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u side a b v:Bool) (D:List Row):
    (GammaUnaryChoice.tape n hn j u side a b v D).length=16:=by
  unfold GammaUnaryChoice.tape
  rw [CommonGuardResolve.token_count]
  simp [GammaUnaryChoice.Q,GammaUnaryChoice.K,UnaryValueStep.G,UnaryValueStep.H,LookupEvaluation.guards]
theorem cofactor_tokens (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (side a b v:Bool) (D:List Row):
    (GammaCofactorValue.tape n hn j side a b v D).length=14:=by
  unfold GammaCofactorValue.tape
  rw [CommonGuardResolve.token_count]
  rfl
theorem comparison_tokens (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u side a b v:Bool) (D:List Row):
    (GammaComparison.tape n hn j u side a b v D).length=12:=by
  unfold GammaComparison.tape
  rw [CommonGuardResolve.token_count]
  rfl

theorem local_commands (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u side a b v:Bool) (D:List Row):
    (GammaComparison.program n hn j u side a b v D).length=3:=rfl
theorem local_tokens (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u side a b v:Bool) (D:List Row):
    PrioritySize.tokensCount (GammaComparison.program n hn j u side a b v D)=42:=by
  simp [PrioritySize.tokensCount,GammaComparison.program,unary_tokens,cofactor_tokens,comparison_tokens]

-- M is an explicit operand bound, not an asserted function of n.
theorem local_bytes (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u side a b v:Bool) (D:List Row) (M:Nat)
    (hd:D.length+3≤M)
    (hu:∀l∈[-BetaAliasValue.choice j]++GammaUnaryChoice.Q n hn j u side a b (!v),l.natAbs≤M)
    (hc:∀l∈[-GuardedGatePOL.sign side (GammaChoiceBank.hit n hn j.1)]++GammaCofactorValue.Q n hn j side a b v,l.natAbs≤M)
    (he:∀l∈GammaComparison.H n hn j u side b v++GammaComparison.Q n hn j side b v,l.natAbs≤M):
    (emit (document (GammaComparison.program n hn j u side a b v D))).length≤21+42*(3+digits M):=by
  have hb:∀cmd∈GammaComparison.program n hn j u side a b v D,∀t∈cmd.2,Bounded M t:=by
    intro cmd hm
    simp only [GammaComparison.program,List.mem_cons,List.not_mem_nil,or_false] at hm
    rcases hm with rfl|rfl|rfl
    · exact resolve_bounded _ _ _ _ _ M (by omega) hu (by omega)
    · exact resolve_bounded _ _ _ _ _ M (by omega) hc (by omega)
    · exact resolve_bounded _ _ _ _ _ M (by simp;omega) he (by omega)
  have h:=PrioritySize.document_bound M _ hb
  rw [local_commands,local_tokens] at h
  exact h
#print axioms local_bytes
end L3Emitter.GammaTapeBytes

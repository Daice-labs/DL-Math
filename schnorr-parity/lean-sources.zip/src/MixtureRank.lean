import MixtureGamma

namespace L3Emitter.MixtureRank
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL GuardedTree SourceMixture

def positiveSeeds (s:Refs) (c:Bit) : Program :=
  [(clause [-c.val,-s.rank.val,s.rank.val],[.lit (-c.val)])]
def positiveRows (s:Refs) (c:Bit) := outputs (positiveSeeds s c)
def negativeSeeds (s:Refs) (c:Bit) (D:List Row) : Program :=
  [(clause [-c.val,s.rank.val,-s.beta.val],MixtureGamma.weakening D c s.beta s.rank),
    (clause [-c.val,s.rank.val,-s.gamma.val],MixtureGamma.weakening D c s.gamma s.rank),
    (clause [-c.val,s.rank.val,-s.rank.val],[.lit (-c.val)])]
def negativeRows (s:Refs) (c:Bit) :=
  [clause [-c.val,s.rank.val,-s.beta.val],clause [-c.val,s.rank.val,-s.gamma.val],
    clause [-c.val,s.rank.val,-s.rank.val]]

theorem positive_seeds (s:Refs) (c:Bit) (D:List Row) :
    check D (positiveSeeds s c)=some (D++positiveRows s c) := by
  apply IndependentProgram.check_base
  intro cmd hc
  obtain rfl:=List.mem_singleton.mp hc
  rw [MixtureGamma.complement_clause (-c.val) s.rank.val (neg_ne_zero.mpr c.property) s.rank.property]
  simp [polEval,c.property]
theorem negative_seeds (s:Refs) (c:Bit) (D:List Row)
    (hb:clause [-c.val,-s.beta.val]∈D) (hg:clause [-c.val,-s.gamma.val]∈D) :
    check D (negativeSeeds s c D)=some (D++negativeRows s c) := by
  apply IndependentProgram.check_base
  intro cmd hc
  simp only [negativeSeeds,List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl|rfl|rfl
  · exact MixtureGamma.weakening_check D _ _ _ hb
  · exact MixtureGamma.weakening_check D _ _ _ hg
  · have he:clause [-c.val,s.rank.val,-s.rank.val]=litAxiom (-c.val):=by
      simpa only [neg_neg] using MixtureGamma.complement_clause (-c.val) (-s.rank.val)
        (neg_ne_zero.mpr c.property) (neg_ne_zero.mpr s.rank.property)
    simp [polEval,he,c.property]

def positiveBody (s:Refs) (c:Bit) :=positiveRows s c++(rankTree s true).rows [-c.val,-s.rank.val]
def negativeBody (s:Refs) (c:Bit) :=negativeRows s c++(rankTree s false).rows [-c.val,s.rank.val]
def positiveProgram (s:Refs) (c:Bit) (D:List Row) :=positiveSeeds s c++
  (rankTree s true).program [-c.val,-s.rank.val] (D++positiveRows s c)
def negativeProgram (s:Refs) (c:Bit) (D:List Row) :=negativeSeeds s c D++
  (rankTree s false).program [-c.val,s.rank.val] (D++negativeRows s c)

theorem positive_assumptions (s:Refs) (c:Bit) (D:List Row) :
    (rankTree s true).Assumptions (D++positiveRows s c) [-c.val,-s.rank.val] := by
  intro x hx
  obtain rfl:=List.mem_singleton.mp hx
  exact List.mem_append_right _ (List.mem_singleton_self _)
theorem negative_assumptions (s:Refs) (c:Bit) (D:List Row) :
    (rankTree s false).Assumptions (D++negativeRows s c) [-c.val,s.rank.val] := by
  intro x hx
  simp only [rankTree,Tree.leaves,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hx
  rcases hx with (rfl|rfl)|rfl <;> apply List.mem_append_right <;> simp [negativeRows,guarded,sign]

theorem positive_check (s:Refs) (c:Bit) (D:List Row) (h:s.Ready D) :
    check D (positiveProgram s c D)=some (D++positiveBody s c) := by
  have h1:=positive_seeds s c D
  have h2:=(rank_checks s (D++positiveRows s c) [-c.val,-s.rank.val] true
    (by simp [Valid,c.property,s.rank.property]) (MixtureGamma.ready_mono h (fun R hr=>List.mem_append_left _ hr))
    (positive_assumptions s c D)).1
  simpa only [positiveProgram,positiveBody,List.append_assoc] using check_append _ _ _ _ _ h1 h2
theorem negative_check (s:Refs) (c:Bit) (D:List Row) (h:s.Ready D)
    (hb:clause [-c.val,-s.beta.val]∈D) (hg:clause [-c.val,-s.gamma.val]∈D) :
    check D (negativeProgram s c D)=some (D++negativeBody s c) := by
  have h1:=negative_seeds s c D hb hg
  have h2:=(rank_checks s (D++negativeRows s c) [-c.val,s.rank.val] false
    (by simp [Valid,c.property,s.rank.property]) (MixtureGamma.ready_mono h (fun R hr=>List.mem_append_left _ hr))
    (negative_assumptions s c D)).1
  simpa only [negativeProgram,negativeBody,List.append_assoc] using check_append _ _ _ _ _ h1 h2

def program (s:Refs) (c:Bit) (D:List Row) :=positiveProgram s c D++negativeProgram s c (D++positiveBody s c)
def rows (s:Refs) (c:Bit) :=positiveBody s c++negativeBody s c
theorem checks (s:Refs) (c:Bit) (D:List Row) (h:s.Ready D)
    (hb:clause [-c.val,-s.beta.val]∈D) (hg:clause [-c.val,-s.gamma.val]∈D) :
    check D (program s c D)=some (D++rows s c) := by
  have h1:=positive_check s c D h
  have h2:=negative_check s c (D++positiveBody s c) (MixtureGamma.ready_mono h (fun R hr=>List.mem_append_left _ hr))
    (List.mem_append_left _ hb) (List.mem_append_left _ hg)
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h1 h2
theorem relations (s:Refs) (c:Bit) : clause [-c.val,-s.rank.val,s.q.val]∈rows s c ∧
    clause [-c.val,-s.q.val,s.rank.val]∈rows s c := by
  constructor
  · simp [rows,positiveBody,rankTree,Tree.rows,guarded,sign]
  · rw [MixtureGamma.rotate (-c.val) (-s.q.val) s.rank.val (neg_ne_zero.mpr c.property)
      (neg_ne_zero.mpr s.q.property) s.rank.property]
    simp [rows,negativeBody,rankTree,Tree.rows,Tree.value,GuardedGatePOL.value,guarded,sign]

#print axioms checks
#print axioms relations
end L3Emitter.MixtureRank

import FinalSelectedCases
namespace L3Emitter.FinalSelectedJoin
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions FinalEvaluationContext
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def body (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):=
  RetainedBlockFold.body (FinalSelectedCases.rows n hn x a b side) (List.finRange (W n))
def row (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):=clause (FinalSelectedCases.core n hn x a b side)
def rows (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool):=body n hn x a b side++[row n hn x a b side]
def joinTape (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row):=
  ProjectionTrace.joinCaseTokens E (List.finRange (W n)) (fun i=>(source n hn i).val) (row n hn x a b side)
def program (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row):Program:=
  RetainedBlockFold.run (FinalSelectedCases.leaf n hn x a b side) (FinalSelectedCases.rows n hn x a b side) (List.finRange (W n)) E++
  [(row n hn x a b side,joinTape n hn x a b side (E++body n hn x a b side))]

theorem checks (n:Nat) (hn:2≤n) (x:Fin (T n)) (a b side:Bool) (E:List Row) (he:∀R∈D n hn,R∈E):
    check E (program n hn x a b side E)=some (E++rows n hn x a b side):=by
  have h0:=RetainedBlockFold.checks (D n hn) (FinalSelectedCases.leaf n hn x a b side) (FinalSelectedCases.rows n hn x a b side)
    (fun _:Fin (W n)=>True) (fun i _ E' he'=>FinalSelectedCases.checks n hn x a b side i E' he') (List.finRange (W n)) (by simp) E he
  have ha:clause ((List.finRange (W n)).map fun i=>(source n hn i).val)∈E:=by
    have h:=FinalSelectorSources.terminal_alo n hn
    simpa only [List.finRange,List.map_ofFn,Function.comp_def] using he _ (FinalKeptEvaluation.recorded_kept n hn _ h)
  have h1:=ProjectionTrace.join_cases (E++body n hn x a b side) (List.finRange (W n)) (fun i=>(source n hn i).val)
    (row n hn x a b side) (canonical_normalize _ _) (by simp;unfold W AliasAssembly.width RankConstruction.width;omega)
    (fun i _=>(source n hn i).property) (List.mem_append_left _ ha)
    (by
      intro i hi;apply List.mem_append_right
      exact RetainedBlockFold.contains (FinalSelectedCases.rows n hn x a b side) (List.finRange (W n)) i hi _ (FinalSelectedCases.contains n hn x a b side i))
  have h2:check (E++body n hn x a b side) [(row n hn x a b side,joinTape n hn x a b side (E++body n hn x a b side))]=
      some ((E++body n hn x a b side)++[row n hn x a b side]):=by simp only [check,joinTape,h1,↓reduceIte]
  simpa only [program,rows,body,List.append_assoc] using check_append _ _ _ _ _ h0 h2
#print axioms checks
end L3Emitter.FinalSelectedJoin

import REDWitness

namespace L3Emitter.REDWitness
open EREF EREF.GeneralRED

/-- Pairwise incompatible falsifying input patterns whenever output bits differ. -/
def Compatible (gs : List GateRow) : Prop :=
  ∀ r ∈ gs, ∀ g ∈ gs, r.bit ≠ g.bit → ∀ α, 1 ≤ sum α r.inputs + sum α g.inputs

/-- Every fresh gate clause is covered, for arbitrary database and arbitrary fan-in. -/
theorem gate_trace (base : List Row) (gs : List GateRow) (q : Nat) (hq : 0 < q)
    (hb : ∀ R ∈ base, Canonical R ∧ ∀ t ∈ R.terms, t.2.natAbs ≠ q)
    (hg : ∀ g ∈ gs, Valid g.inputs ∧ Fresh q g.inputs)
    (hp : Compatible gs) : CheckedTrace base (base ++ gs.map (GateRow.row q)) := by
  have go : ∀ (tail : List GateRow) (pre : List GateRow), gs = pre ++ tail →
      CheckedTrace (base ++ pre.map (GateRow.row q)) (base ++ gs.map (GateRow.row q)) := by
    intro tail
    induction tail with
    | nil =>
      intro pre heq
      simp only [List.append_nil] at heq
      subst gs
      exact .refl _
    | cons g tail ih =>
      intro pre heq
      have hpre : ∀ r ∈ pre, r ∈ gs := by intro r hr; rw [heq]; simp [hr]
      have hgin : g ∈ gs := by rw [heq]; simp
      have ho := gate_red_obligations base pre g q hq hb (hg g hgin)
        (fun r hr => hg r (hpre r hr))
        (fun r hr hne α => hp r (hpre r hr) g hgin hne α)
      have hs : CheckedStep (base ++ pre.map (GateRow.row q))
          ((base ++ pre.map (GateRow.row q)) ++ [g.row q]) :=
        .red _ _ _ (canonical_normalize _ _) (fun R hR => single_to_refutation _ _ _ (ho R hR))
      have ht := ih (pre ++ [g]) (by simpa [List.append_assoc] using heq)
      have he : base ++ (pre ++ [g]).map (GateRow.row q) =
          (base ++ pre.map (GateRow.row q)) ++ [g.row q] := by simp [List.append_assoc]
      rw [he] at ht
      exact .cons hs ht
  simpa using go gs [] (by simp)

def orGate (xs : List Int) : List GateRow :=
  xs.map (fun x => ⟨[-x],true⟩) ++ [⟨xs,false⟩]

def andGate (xs : List Int) : List GateRow :=
  xs.map (fun x => ⟨[x],false⟩) ++ [⟨xs.map (-·),true⟩]

def eqGate (a b : Int) : List GateRow :=
  [⟨[a,b],true⟩, ⟨[a,-b],false⟩, ⟨[-a,b],false⟩, ⟨[-a,-b],true⟩]

def muxGate (c a b : Int) : List GateRow :=
  [⟨[-c,-a],true⟩, ⟨[-c,a],false⟩, ⟨[c,-b],true⟩, ⟨[c,b],false⟩]

theorem or_compatible (xs : List Int) (hz : Valid xs) : Compatible (orGate xs) := by
  intro r hr g hg hne α
  simp only [orGate, List.mem_append, List.mem_map, List.mem_singleton] at hr hg
  rcases hr with ⟨x,hx,rfl⟩ | rfl <;> rcases hg with ⟨y,hy,rfl⟩ | rfl
  · exact False.elim (hne rfl)
  · have := sum_mem_le α hx
    rw [sum_cons, sum_nil, litVal_neg α x (hz x hx)]
    dsimp only at *
    omega
  · have := sum_mem_le α hy
    rw [sum_cons, sum_nil, litVal_neg α y (hz y hy)]
    dsimp only at *
    omega
  · exact False.elim (hne rfl)

theorem and_compatible (xs : List Int) (hz : Valid xs) : Compatible (andGate xs) := by
  intro r hr g hg hne α
  simp only [andGate, List.mem_append, List.mem_map, List.mem_singleton] at hr hg
  rcases hr with ⟨x,hx,rfl⟩ | rfl <;> rcases hg with ⟨y,hy,rfl⟩ | rfl
  · exact False.elim (hne rfl)
  · have hm : -x ∈ xs.map (-·) := List.mem_map.mpr ⟨x,hx,rfl⟩
    have := sum_mem_le α hm
    rw [litVal_neg α x (hz x hx)] at this
    simp only [sum_cons, sum_nil]; omega
  · have hm : -y ∈ xs.map (-·) := List.mem_map.mpr ⟨y,hy,rfl⟩
    have := sum_mem_le α hm
    rw [litVal_neg α y (hz y hy)] at this
    simp only [sum_cons, sum_nil]; omega
  · exact False.elim (hne rfl)

theorem eq_compatible (a b : Int) (ha : a ≠ 0) (hb : b ≠ 0) : Compatible (eqGate a b) := by
  intro r hr g hg hne α
  have := litVal_nonneg α a
  have := litVal_nonneg α b
  have := litVal_le_one α a
  have := litVal_le_one α b
  simp only [eqGate, List.mem_cons, List.mem_nil_iff, or_false] at hr hg
  rcases hr with rfl | rfl | rfl | rfl <;> rcases hg with rfl | rfl | rfl | rfl <;>
    simp only [sum_cons, sum_nil, litVal_neg α a ha, litVal_neg α b hb] at * <;>
    first | exact False.elim (hne rfl) | omega

theorem mux_compatible (c a b : Int) (hc : c ≠ 0) (ha : a ≠ 0) (hb : b ≠ 0) :
    Compatible (muxGate c a b) := by
  intro r hr g hg hne α
  have := litVal_nonneg α c
  have := litVal_nonneg α a
  have := litVal_nonneg α b
  have := litVal_le_one α c
  have := litVal_le_one α a
  have := litVal_le_one α b
  simp only [muxGate, List.mem_cons, List.mem_nil_iff, or_false] at hr hg
  rcases hr with rfl | rfl | rfl | rfl <;> rcases hg with rfl | rfl | rfl | rfl <;>
    simp only [sum_cons, sum_nil, litVal_neg α c hc, litVal_neg α a ha, litVal_neg α b hb] at * <;>
    first | exact False.elim (hne rfl) | omega

/-- Input checks mention only nonzero IDs and freshness, never a proof-search oracle. -/
theorem or_inputs (xs : List Int) (q : Nat) (hz : Valid xs) (hf : Fresh q xs) :
    ∀ g ∈ orGate xs, Valid g.inputs ∧ Fresh q g.inputs := by
  intro g hg
  simp only [orGate, List.mem_append, List.mem_map, List.mem_singleton] at hg
  rcases hg with ⟨x,hx,rfl⟩ | rfl
  · constructor
    · intro l hl; simp only [List.mem_singleton] at hl; subst l; exact neg_ne_zero.mpr (hz x hx)
    · intro l hl; simp only [List.mem_singleton] at hl; subst l; simpa using hf x hx
  · exact ⟨hz,hf⟩

theorem and_inputs (xs : List Int) (q : Nat) (hz : Valid xs) (hf : Fresh q xs) :
    ∀ g ∈ andGate xs, Valid g.inputs ∧ Fresh q g.inputs := by
  intro g hg
  simp only [andGate, List.mem_append, List.mem_map, List.mem_singleton] at hg
  rcases hg with ⟨x,hx,rfl⟩ | rfl
  · constructor
    · intro l hl; simp only [List.mem_singleton] at hl; subst l; exact hz x hx
    · intro l hl; simp only [List.mem_singleton] at hl; subst l; exact hf x hx
  · constructor
    · intro l hl; obtain ⟨x,hx,rfl⟩ := List.mem_map.mp hl; exact neg_ne_zero.mpr (hz x hx)
    · intro l hl; obtain ⟨x,hx,rfl⟩ := List.mem_map.mp hl; simpa using hf x hx

theorem or_emitter_correct (base : List Row) (xs : List Int) (q : Nat) (hq : 0 < q)
    (hb : ∀ R ∈ base, Canonical R ∧ ∀ t ∈ R.terms, t.2.natAbs ≠ q)
    (hz : Valid xs) (hf : Fresh q xs) :
    CheckedTrace base (base ++ (orGate xs).map (GateRow.row q)) :=
  gate_trace base (orGate xs) q hq hb (or_inputs xs q hz hf) (or_compatible xs hz)

theorem and_emitter_correct (base : List Row) (xs : List Int) (q : Nat) (hq : 0 < q)
    (hb : ∀ R ∈ base, Canonical R ∧ ∀ t ∈ R.terms, t.2.natAbs ≠ q)
    (hz : Valid xs) (hf : Fresh q xs) :
    CheckedTrace base (base ++ (andGate xs).map (GateRow.row q)) :=
  gate_trace base (andGate xs) q hq hb (and_inputs xs q hz hf) (and_compatible xs hz)

theorem eq_inputs (a b : Int) (q : Nat) (ha : a ≠ 0) (hb : b ≠ 0)
    (fa : a.natAbs ≠ q) (fb : b.natAbs ≠ q) :
    ∀ g ∈ eqGate a b, Valid g.inputs ∧ Fresh q g.inputs := by
  intro g hg
  simp only [eqGate, List.mem_cons, List.mem_nil_iff, or_false] at hg
  rcases hg with rfl | rfl | rfl | rfl <;>
    simp [Valid, Fresh, ha, hb, fa, fb]

theorem mux_inputs (c a b : Int) (q : Nat) (hc : c ≠ 0) (ha : a ≠ 0) (hb : b ≠ 0)
    (fc : c.natAbs ≠ q) (fa : a.natAbs ≠ q) (fb : b.natAbs ≠ q) :
    ∀ g ∈ muxGate c a b, Valid g.inputs ∧ Fresh q g.inputs := by
  intro g hg
  simp only [muxGate, List.mem_cons, List.mem_nil_iff, or_false] at hg
  rcases hg with rfl | rfl | rfl | rfl <;>
    simp [Valid, Fresh, hc, ha, hb, fc, fa, fb]

theorem eq_emitter_correct (base : List Row) (a b : Int) (q : Nat) (hq : 0 < q)
    (hbase : ∀ R ∈ base, Canonical R ∧ ∀ t ∈ R.terms, t.2.natAbs ≠ q)
    (ha : a ≠ 0) (hb : b ≠ 0) (fa : a.natAbs ≠ q) (fb : b.natAbs ≠ q) :
    CheckedTrace base (base ++ (eqGate a b).map (GateRow.row q)) :=
  gate_trace base (eqGate a b) q hq hbase (eq_inputs a b q ha hb fa fb) (eq_compatible a b ha hb)

theorem mux_emitter_correct (base : List Row) (c a b : Int) (q : Nat) (hq : 0 < q)
    (hbase : ∀ R ∈ base, Canonical R ∧ ∀ t ∈ R.terms, t.2.natAbs ≠ q)
    (hc : c ≠ 0) (ha : a ≠ 0) (hb : b ≠ 0)
    (fc : c.natAbs ≠ q) (fa : a.natAbs ≠ q) (fb : b.natAbs ≠ q) :
    CheckedTrace base (base ++ (muxGate c a b).map (GateRow.row q)) :=
  gate_trace base (muxGate c a b) q hq hbase
    (mux_inputs c a b q hc ha hb fc fa fb) (mux_compatible c a b hc ha hb)

#print axioms eq_emitter_correct
#print axioms mux_emitter_correct
#print axioms gate_trace
#print axioms or_emitter_correct
#print axioms and_emitter_correct
#print axioms eq_compatible
#print axioms mux_compatible
end L3Emitter.REDWitness

import NumericProgramFields
import NumericCofactorFields
namespace L3Emitter.NumericCofactorTapes
open EREF EREF.GeneralRED RecordedOperandFields REDWitness FamilyNamespace CofactorSemantics

theorem both (M i j:Nat) (B:Int) (lo hi:List ClauseTransport.Link)
 (hB:B.natAbs≤M) (hlo:∀l∈lo,l.target.natAbs≤M) (hhi:∀l∈hi,l.target.natAbs≤M)
 (hl:lo.length≤M) (hh:hi.length≤M) (hM:2≤M):
 Tape M (CofactorClause.tokensBoth i j B lo hi):=by
 apply NumericSelectionTapes.append
 · exact NumericSelectionTapes.append M _ _ (NumericClauseTapes.tokens M i B lo hB hlo hl)
     (NumericClauseTapes.tokens M j (-B) hi (by simpa using hB) hhi hh)
 · intro t ht;simp only [List.mem_cons,List.not_mem_nil,or_false] at ht
   rcases ht with rfl|rfl
   · trivial
   · exact hM

theorem targets (M n s offset B g x:Nat) (a b c side:Bool)
 (hg:g<s) (hx:x<truthRows n) (hV:variableCount (n+1) s≤offset)
 (hM:offset+3*s*truthRows n≤M):
 ∀l∈links n s offset B g x a b c side,l.target.natAbs≤M:=by
 intro l hl;simp only [links,List.mem_cons,List.not_mem_nil,or_false] at hl
 rcases hl with rfl|rfl|rfl|rfl
 · change (output (low n offset g 0 x) _).natAbs≤M
   rw [NumericCofactorNamespace.output_abs]
   exact (CofactorBytes.low_bound n s offset g 0 x hg (by decide) hx).trans hM
 · change (output (low n offset g 1 x) _).natAbs≤M
   rw [NumericCofactorNamespace.output_abs]
   exact (CofactorBytes.low_bound n s offset g 1 x hg (by decide) hx).trans hM
 · change (output (low n offset g 2 x) _).natAbs≤M
   rw [NumericCofactorNamespace.output_abs]
   exact (CofactorBytes.low_bound n s offset g 2 x hg (by decide) hx).trans hM
 · exact (NumericCofactorNamespace.fn_bound n s g hg a b c).trans (by omega)

theorem tape (M n s offset B g x:Nat) (a b c:Bool)
 (hg:g<s) (hx:x<truthRows n) (hV:variableCount (n+1) s≤offset)
 (hB:B≤M) (hM:offset+3*s*truthRows n≤M) (h4:4≤M):
 Tape M (CofactorSemantics.tape n s offset B g x a b c):=by
 apply both
 · simpa using hB
 · exact targets M n s offset B g x a b c false hg hx hV hM
 · exact targets M n s offset B g x a b c true hg hx hV hM
 · exact h4
 · exact h4
 · omega

theorem actual (M n:Nat) (hn:2≤n) (hM:NumericCofactorNamespace.cap n hn≤M) (h4:4≤M):
 NumericProgramFields.Bounded M (ConstantCofactor.program n hn):=by
 apply NumericProgramFields.rebase
 intro z hz;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hz
 have hv:=CofactorSection.job_bounds n (3*(n+1)-4) j hj
 apply tape M n (3*(n+1)-4) _ _ j.1 j.2.1 _ _ _ hv.1 hv.2
 · exact ConstantCofactor.offset_original n hn
 · have hb:ConstantCofactor.B n hn≤ConstantCofactor.offset n hn:=by
     unfold ConstantCofactor.B ConstantCofactor.offset ConstantConstruction.C ConstantConstruction.m;omega
   unfold NumericCofactorNamespace.cap at hM;omega
 · exact hM
 · exact h4
#print axioms actual
end L3Emitter.NumericCofactorTapes

import NumericCofactorSelection
import NumericCofactorTapes
import NumericConstantTapes
import RecordedConstantTransport
namespace L3Emitter.NumericConstantTransport
open EREF EREF.GeneralRED FieldLengthsFromIDs

def bound (n:Nat):Nat:=NumericRestrictionSelection.bound (n+1)+1600*FrontendNamespaceEnvelope.scale (n+1)+10

theorem cap_le (n:Nat) (hn:2≤n):NumericCofactorNamespace.cap n hn≤bound n:=by
 have h:=NumericCofactorNamespace.cap_bound n hn;unfold bound;omega

theorem bank (n:Nat) (hn:2≤n):
 ∀c∈RecordedConstantTransport.bankProgram n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · exact RecursiveOperandBounds.content_mono (by unfold bound;omega) c
     (NumericCofactorSelection.program (n+1) (by omega) c hc)
 · apply NumericCofactorFields.program (bound n) n (3*(n+1)-4) _ _ _
     (ConstantCofactor.offset_original n hn) ?_ (cap_le n hn) (by unfold bound;omega) c hc
   unfold ConstantCofactor.B ConstantCofactor.offset ConstantConstruction.C ConstantConstruction.m;omega

theorem cofactor (n:Nat) (hn:2≤n):
 ∀c∈RecordedConstantTransport.cofactorProgram n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · exact bank n hn c hc
 · exact NumericProgramFields.pol (bound n) _
     (NumericCofactorTapes.actual (bound n) n hn (cap_le n hn) (by unfold bound;omega)) c hc

theorem fields (n:Nat) (hn:2≤n):
 ∀c∈RecordedConstantTransport.fieldsProgram n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · exact cofactor n hn c hc
 · exact NumericProgramFields.pol (bound n) _ (NumericConstantTapes.fields (bound n) _ _ _) c hc

theorem primary (n:Nat) (hn:2≤n):
 ∀c∈RecordedConstantTransport.primaryProgram n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · exact fields n hn c hc
 · exact NumericProgramFields.pol (bound n) _ (NumericConstantTapes.primary (bound n) n hn) c hc

theorem betaPort (n:Nat) (hn:2≤n):
 ∀c∈RecordedConstantTransport.betaPortProgram n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · exact primary n hn c hc
 · exact NumericProgramFields.pol (bound n) _
     (NumericConstantTapes.betaPort (bound n) n hn (cap_le n hn) (by unfold bound;omega)) c hc

theorem program (n:Nat) (hn:2≤n):
 ∀c∈RecordedConstantTransport.program n hn,Content (bound n) c:=by
 intro c hc;rcases List.mem_append.mp hc with hc|hc
 · exact betaPort n hn c hc
 · exact NumericProgramFields.pol (bound n) _
     (NumericConstantTapes.betaValue (bound n) n hn (cap_le n hn) (by unfold bound;omega)) c hc
#print axioms program
end L3Emitter.NumericConstantTransport

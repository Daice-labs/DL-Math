import FableIntegration
import L3FrontInv2
import L3OutputStage

namespace L3Emitter.FableOutputIntegration
open EREF.GeneralRED L3Emitter.FableEncoding

/-- Checked stage 6 can be appended after any checked Fable prefix, with the
    initial database proved equal to the v5/v7 encoding of the original family. -/
theorem from_original (k : Nat) (hk : 3≤k)
    (t : L3.StI (fam k (3*k-4)).V)
    (hi : (fam k (3*k-4)).Good3 t)
    (hp : L3.ObligationsChecked (fam k (3*k-4)).db5 t.s.cmds) :
    CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (L3.exec (fam k (3*k-4)).db5 ((fam k (3*k-4)).stage6 t).s.cmds) := by
  exact L3Emitter.SelectorNormalization.trace_trans (fable_prefix_on_v5 k hk)
    ((fam k (3*k-4)).stage6_trace (by change 2≤k; omega)
      (by change 2≤3*k-4; omega) rfl t hi hp)

/-- An unconditional trace from the original formula through stages 0–4 and
    then stage 6. Stage 5 is deliberately omitted here: this is a checked
    output-exclusion component, not the actual complete frontend sequence. -/
theorem output_exclusion_from_original (k : Nat) (hk : 3≤k) :
    CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (L3.exec (fam k (3*k-4)).db5
        ((fam k (3*k-4)).stage6 ((fam k (3*k-4)).t4 (by change 1≤3*k-4; omega))).s.cmds) := by
  let F := fam k (3*k-4)
  have hs : 1≤F.s := by change 1≤3*k-4; omega
  have ht3 : F.Good3 (F.t3 hs) := F.good3_stage3 hs
  have ht4 : F.Good3 (F.t4 hs) := F.Good3_of_keeps2 (F.keeps2_stage4 (F.t3 hs)) ht3
  exact from_original k hk (F.t4 hs) ht4 (F.obls_t4 (by change 1≤k; omega) hs)

/-- On the real stage order, stage 6 introduces no new proof premises.
    The remaining premise here is precisely the still-open stage-5 obligations. -/
theorem actual_through_stage6 (k : Nat) (hk : 3≤k)
    (hs : 1≤(fam k (3*k-4)).s)
    (h5 : L3.ObligationsChecked (fam k (3*k-4)).db5
      ((fam k (3*k-4)).stage5 ((fam k (3*k-4)).V_pos hs)
        ((fam k (3*k-4)).t4 hs)).s.cmds) :
    CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (L3.exec (fam k (3*k-4)).db5
        ((fam k (3*k-4)).stage6
          ((fam k (3*k-4)).stage5 ((fam k (3*k-4)).V_pos hs)
            ((fam k (3*k-4)).t4 hs))).s.cmds) := by
  let F := fam k (3*k-4)
  have ht3 : F.Good3 (F.t3 hs) := F.good3_stage3 hs
  have ht4 : F.Good3 (F.t4 hs) := F.Good3_of_keeps2 (F.keeps2_stage4 (F.t3 hs)) ht3
  have ht5 := F.Good3_of_keeps2 (F.keeps2_stage5 (F.V_pos hs) (F.t4 hs)) ht4
  exact from_original k hk _ ht5 h5

#print axioms from_original
#print axioms output_exclusion_from_original
#print axioms actual_through_stage6
end L3Emitter.FableOutputIntegration

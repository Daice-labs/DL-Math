import GateCategories
import ProjectionPrograms

namespace L3Emitter.CategoryPrograms
open EREF EREF.GeneralRED REDWitness RankProjection Resolution ProjectionTrace AliasProgram GateCategories

def choices (n:Nat) (hn:2≤n) := BranchChoices.chosen (n+1) (by omega)
def cats (n:Nat) := categories (3*(n+1)-4)
def value (n:Nat) (hn:2≤n) (g:Nat) (q:Category) := (bit n hn g q).val
def vars (n:Nat) (hn:2≤n) (g:Nat) := (cats n).map (value n hn g)
def base (n:Nat) (hn:2≤n) := FirstPortOneHot.result n hn
def Keep (n:Nat) (hn:2≤n) (D:List Row) := ∀R∈base n hn,R∈D

theorem choice_alo (n:Nat) (hn:2≤n) : clause ((choices n hn).map Choice.lit)∈base n hn :=
  rank_to_endpoint n hn _ (RankConstruction.inputs (n+1) (by omega)).alo
theorem choice_pair (n:Nat) (hn:2≤n) (c d:Choice (3*(n+1)-4))
    (hc:c∈choices n hn) (hd:d∈choices n hn) (hne:c≠d) : clause [-c.lit,-d.lit]∈base n hn :=
  rank_to_endpoint n hn _ ((RankConstruction.inputs (n+1) (by omega)).amo c hc d hd hne)
theorem choices_nonempty (n:Nat) (hn:2≤n) : choices n hn≠[] := RankAdmission.nonempty (n+1) (by omega)

def aloRows (n:Nat) (hn:2≤n) (g:Nat) :=
  aloBlocks (choices n hn) Choice.lit (vars n hn g)++[clause (vars n hn g)]
def aloProgram (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=
  ProjectionPrograms.alo D (choices n hn) Choice.lit (fun c=>value n hn g (owner g c)) (vars n hn g)

theorem alo_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (D:List Row) (hd:Keep n hn D) :
    check D (aloProgram n hn g D)=some (D++aloRows n hn g) := by
  have h:=ProjectionPrograms.alo_check D (choices n hn) Choice.lit
    (fun c=>value n hn g (owner g c)) (vars n hn g) (choices_nonempty n hn)
    (fun c hc=>c.nonzero) (by
      intro l hl;obtain ⟨q,hq,rfl⟩:=List.mem_map.mp hl;exact (bit n hn g q).property)
    (hd _ (choice_alo n hn)) (by
      intro c hc
      refine ⟨List.mem_map.mpr ⟨owner g c,owner_mem c g hg hs,rfl⟩,?_⟩
      apply hd
      exact forward n hn g hg hs (owner g c) (owner_mem c g hg hs) c.lit
        ((support_mem (choices n hn) g (owner g c) c.lit).mpr ⟨c,hc,owner_active c g hg hs,rfl⟩))
  simpa only [aloProgram,aloRows,List.append_assoc] using h

def side (g:Nat) (q:Category) (c:Choice s) := decide (¬Active c g q)
def pairRows (n:Nat) (hn:2≤n) (g:Nat) (q r:Category) :=
  pairBlocks (choices n hn) Choice.lit (value n hn g q) (value n hn g r) (side g q)++
    [clause [-value n hn g q,-value n hn g r]]
def pairProgram (n:Nat) (hn:2≤n) (g:Nat) (q r:Category) (D:List Row) :=
  ProjectionPrograms.pair D (choices n hn) Choice.lit (value n hn g q) (value n hn g r) (side g q)
    (support (choices n hn) g q) (support (choices n hn) g r)

theorem pair_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (q r:Category) (hq:q∈cats n) (hr:r∈cats n) (hne:q≠r) (D:List Row) (hd:Keep n hn D) :
    check D (pairProgram n hn g q r D)=some (D++pairRows n hn g q r) := by
  have h:=ProjectionPrograms.pair_check D (choices n hn) Choice.lit (value n hn g q) (value n hn g r)
    (side g q) (support (choices n hn) g q) (support (choices n hn) g r)
    (choices_nonempty n hn) (fun c hc=>c.nonzero) (bit n hn g q).property (bit n hn g r).property
    (support_valid _ _ _) (support_valid _ _ _) (hd _ (choice_alo n hn))
    (hd _ (backward n hn g hg hs q hq)) (hd _ (backward n hn g hg hs r hr)) (by
      intro c hc l hl
      by_cases ha:Active c g q
      · simp only [side,ha,not_true_eq_false,decide_false,Bool.false_eq_true,↓reduceIte] at hl
        obtain ⟨d,hd',had,rfl⟩:=(support_mem (choices n hn) g r l).mp hl
        apply hd
        apply choice_pair n hn c d hc hd'
        intro he;subst d
        exact hne (active_unique c g q r ha had)
      · simp only [side,ha,not_false_eq_true,decide_true,↓reduceIte] at hl
        obtain ⟨d,hd',had,rfl⟩:=(support_mem (choices n hn) g q l).mp hl
        apply hd
        apply choice_pair n hn c d hc hd'
        intro he;subst d;exact ha had)
  simpa only [pairProgram,pairRows,List.append_assoc] using h

def pairs (n:Nat) := (cats n).flatMap (fun q=>(cats n).filterMap (fun r=>if q≠r then some (q,r) else none))
theorem pair_mem (n:Nat) (q r:Category) : (q,r)∈pairs n ↔ q∈cats n ∧ r∈cats n ∧ q≠r := by
  simp [pairs,List.mem_filterMap,List.mem_flatMap]

def pairLoop (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) : List (Category×Category)→Program
  | []=>[]
  | (q,r)::ps=>pairProgram n hn g q r D++pairLoop n hn g (D++pairRows n hn g q r) ps
def pairBody (n:Nat) (hn:2≤n) (g:Nat) (ps:List (Category×Category)) := ps.flatMap (fun p=>pairRows n hn g p.1 p.2)

theorem pairLoop_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (D:List Row) (ps:List (Category×Category)) (hp:∀p∈ps,p∈pairs n) (hd:Keep n hn D) :
    check D (pairLoop n hn g D ps)=some (D++pairBody n hn g ps) := by
  induction ps generalizing D with
  | nil=>simp [pairLoop,pairBody,check]
  | cons p ps ih=>
    obtain ⟨q,r⟩:=p
    have hm:=(pair_mem n q r).mp (hp (q,r) (by simp))
    have h1:=pair_check n hn g hg hs q r hm.1 hm.2.1 hm.2.2 D hd
    have h2:=ih (D++pairRows n hn g q r) (fun p hp'=>hp p (by simp [hp']))
      (fun R hr=>List.mem_append_left _ (hd R hr))
    simpa only [pairLoop,pairBody,List.flatMap_cons,List.append_assoc]
      using check_append _ _ _ _ _ h1 h2

def rows (n:Nat) (hn:2≤n) (g:Nat) := aloRows n hn g++pairBody n hn g (pairs n)
def program (n:Nat) (hn:2≤n) (g:Nat) (D:List Row) :=
  aloProgram n hn g D++pairLoop n hn g (D++aloRows n hn g) (pairs n)

theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (D:List Row) (hd:Keep n hn D) : check D (program n hn g D)=some (D++rows n hn g) := by
  have h1:=alo_check n hn g hg hs D hd
  have h2:=pairLoop_check n hn g hg hs (D++aloRows n hn g) (pairs n) (fun p h=>h)
    (fun R hr=>List.mem_append_left _ (hd R hr))
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h1 h2

theorem alo_mem (n:Nat) (hn:2≤n) (g:Nat) : clause (vars n hn g)∈rows n hn g :=
  List.mem_append_left _ (List.mem_append_right _ (by simp))

theorem exclusion_mem (n:Nat) (hn:2≤n) (g:Nat) (q r:Category)
    (hq:q∈cats n) (hr:r∈cats n) (hne:q≠r) : clause [-value n hn g q,-value n hn g r]∈rows n hn g :=
  List.mem_append_right _ (List.mem_flatMap.mpr ⟨(q,r),(pair_mem n q r).mpr ⟨hq,hr,hne⟩,
    List.mem_append_right _ (by simp)⟩)

#print axioms checks
#print axioms exclusion_mem
end L3Emitter.CategoryPrograms

import GlobalExtensionMainTapes
namespace L3Emitter.FrontendMainTapeLength
open EREF EREF.GeneralRED MainTapeRecurrence L3 L3.Defs

def Short (p : RecordedScopedTrace.Program):Prop:=count p≤p.length

theorem join {p q : RecordedScopedTrace.Program} (hp:Short p) (hq:Short q) : Short (p++q) := by
  unfold Short at *;rw [append,List.length_append];omega

theorem gate (D : List EREF.Row) (q : Nat) (defs : Defs) : Short (RecordedDefinitions.emit D q defs) := by
  have h:=CompleteFinalRowTapes.gate_zero D q [] (RecordedDefinitions.data defs)
  unfold Short;rw [RecordedDefinitions.emit,h];omega

theorem definitions (D : List EREF.Row) (cs : List Cmd) : Short (RecordedFrontendDefs.emit D cs) := by
  induction cs generalizing D with
  | nil=>simp [Short,RecordedFrontendDefs.emit,count]
  | cons c cs ih=>
    cases c with
    | orDef q xs=>exact join (gate ..) (ih _)
    | andDef q xs=>exact join (gate ..) (ih _)
    | eqDef q a b=>exact join (gate ..) (ih _)
    | rup c=>
      have h:=ih (D++[(clauseRow c).toE])
      unfold Short at *
      change 1+count (RecordedFrontendDefs.emit _ cs)≤(RecordedFrontendDefs.emit _ cs).length+1
      omega

theorem suffix {m : Nat} (D : List EREF.Row) (t u : StI m) : Short (RecordedDefinitionSuffix.program D t u) :=
  definitions ..

theorem selector_left (k s m : Nat) : count (RecordedSelectorPrefix.left k s m)=0 := by
  induction m with
  | zero=>rfl
  | succ m ih=>rw [RecordedSelectorPrefix.left,append,ih];rfl

theorem selector_right (k s m : Nat) : count (RecordedSelectorPrefix.right k s m)=0 := by
  induction m with
  | zero=>rfl
  | succ m ih=>rw [RecordedSelectorPrefix.right,append,ih];rfl

theorem normalization (k s : Nat) : count (RecordedNormalization.program k s)=0 := by
  rw [RecordedNormalization.program,append,RecordedSelectorPrefix.program,append,selector_left,selector_right]
  rfl

theorem stage3 (k s : Nat) (hs : 1≤s) : Short (RecordedFrontendDefs.throughStage3 k s hs) := by
  apply join
  · unfold Short;rw [normalization];omega
  · exact definitions ..

theorem stage4_run (F : Fam) (t : StI F.V) (D : List EREF.Row) (js : List RecordedStage4.Job) :
    count (RecordedStage4.run F t D js)=0 := by
  induction js generalizing D with
  | nil=>rfl
  | cons j js ih=>change 0+count (RecordedStage4.run F t _ js)=0;rw [ih]

theorem stage4 (k s : Nat) (hs : 1≤s) : Short (RecordedStage4Assembly.throughStage4 k s hs) := by
  apply join (stage3 ..)
  unfold Short RecordedStage4Assembly.program;rw [stage4_run];omega

theorem splits (leaf : List EREF.Row→List Int→RecordedRefutation.Certificate)
    (D : List EREF.Row) (c vs : List Int) : count (RecordedSplit.run leaf D c vs)=0 := by
  induction vs generalizing D c with
  | nil=>rfl
  | cons v vs ih=>rw [RecordedSplit.run,append,append,ih,ih];rfl

theorem fold {S A : Type} (next:S→A→S) (emit:S→A→RecordedScopedTrace.Program) (s:S) (xs:List A)
    (h:∀s a,Short (emit s a)) : Short (RecordedStateFold.run next emit s xs) := by
  induction xs generalizing s with
  | nil=>simp [Short,RecordedStateFold.run,count]
  | cons a xs ih=>exact join (h s a) (ih _)

theorem port (F : Fam) (hm : 1≤F.V) (t : StI F.V) (g p bit cb : Nat) :
    Short (RecordedPortStep.program F hm t g p bit cb) := by
  apply join
  · apply join (suffix ..)
    apply fold;intro u j
    unfold Short RecordedWireSplit.program;rw [splits];omega
  · change count [_,_]≤2
    change 0≤2;omega

theorem gate_finish (F : Fam) (hm : 1≤F.V) (bit cb g : Nat) (u : StI F.V) :
    Short (RecordedGateStep.finish F hm bit cb g u) := by
  unfold RecordedGateStep.finish;split
  · unfold Short RecordedFirstSplit.program;rw [splits];omega
  · apply join (join (port ..) (port ..))
    unfold Short RecordedGateSplit.program;rw [splits];omega

theorem gate_step (F : Fam) (hm : 1≤F.V) (bit cb : Nat) (t : StI F.V) (g : Nat) :
    Short (RecordedGateStep.program F hm bit cb t g) := join (suffix ..) (gate_finish ..)

theorem gate_order (F : Fam) (hm : 1≤F.V) (bit cb : Nat) (t : StI F.V) (m : Nat) :
    Short (RecordedGateOrder.program F hm bit cb t m) := by
  induction m with
  | zero=>simp [Short,RecordedGateOrder.program,count]
  | succ m ih=>exact join ih (gate_step ..)

theorem bit_step (F : Fam) (hm : 1≤F.V) (t : StI F.V) (b : Nat) :
    Short (RecordedBitStep.program F hm t b) := by
  apply join (join (suffix ..) (gate_order ..))
  change 0≤1;omega

theorem merge (F : Fam) (t : StI F.V) (c0 c1 : Nat) : Short (RecordedMergeFinish.program F t c0 c1) := by
  apply join
  · unfold Short RecordedCoverageMerge.splitProgram;rw [splits];omega
  · change 0≤1;omega

theorem stage5 (F : Fam) (hm : 1≤F.V) (t : StI F.V) : Short (RecordedStage5.program F hm t) :=
  join (join (bit_step ..) (bit_step ..)) (merge ..)

theorem stage6 (F : Fam) (t : StI F.V) : Short (RecordedStage6.program F t) := by
  apply join
  · apply join
    · apply fold;intro u pb
      unfold Short RecordedOutputSplit.program;rw [splits];omega
    · apply fold;intro u p
      change 0≤2;omega
  · change 0≤1;omega

theorem stage7 (F : Fam) (t : StI F.V) : Short (RecordedStage7.program F t) := by
  apply join
  · apply join (suffix ..)
    apply fold;intro u b
    change 0≤1;omega
  · change 0≤1;omega

theorem complete (k s : Nat) (hs : 1≤s) : Short (RecordedFrontendComplete.program k s hs) :=
  join (join (join (stage4 ..) (stage5 ..)) (stage6 ..)) (stage7 ..)

theorem parity (k : Nat) (hk : 2≤k) :
    count (RecordedFrontendComplete.program k (3*k-4) (by omega))≤800*(k+1)^2 :=
  (complete k (3*k-4) (by omega)).trans (ConstructionFrontendCount.parity k hk)
#print axioms parity
end L3Emitter.FrontendMainTapeLength

import FinalEvaluationImage
import FinalU2Image
namespace L3Emitter.FinalLowerComplete
open EREF EREF.GeneralRED FamilyRows
attribute [local irreducible] FinalOutputDefinitions.base FinalOutputDefinitions.initialNet

def result (n:Nat) (hn:2≤n):List Row:=FinalEvaluationImage.result n hn
def imageBank (n:Nat) (hn:2≤n):List Row:=
  (OriginalEncoding.specs n (3*n-4)).map (FinalLowerImage.image n hn)
theorem u2_retained (n:Nat) (hn:2≤n):∀R∈FinalU2Bank.result n hn,R∈result n hn:=
  fun R h=>List.mem_append_left _ (List.mem_append_left _ h)
theorem transfer_retained (n:Nat) (hn:2≤n):∀R∈FinalPrimaryTransfers.result n hn,R∈result n hn:=by
  intro R h
  apply u2_retained
  apply FinalU2Image.retained
  exact List.mem_append_left _ h
theorem selector_retained (n:Nat) (hn:2≤n):∀R∈FinalSelectorCardinalities.result n hn,R∈result n hn:=by
  intro R h
  apply transfer_retained
  apply List.mem_append_left
  apply FinalTransferBank.retained
  exact FinalOutputLinks.retained n hn R h

theorem every_original_row_image (n:Nat) (hn:2≤n) (r:Spec) (hr:r∈OriginalEncoding.specs n (3*n-4)):
    FinalLowerImage.image n hn r∈result n hn:=by
  simp only [OriginalEncoding.specs,List.mem_append] at hr
  rcases hr with (((h|h)|h)|h)|h
  · exact selector_retained n hn _ (FinalSelectorImage.all_selector_images n hn r h)
  · exact u2_retained n hn _ (FinalU2Image.all_U2_images n hn r h)
  · exact transfer_retained n hn _ (FinalTransferImage.all_transfer_images n hn r h)
  · exact FinalEvaluationImage.all_semantics_images n hn r h
  · exact FinalEvaluationImage.definitions_retained n hn _ (FinalLowerImage.all_output_images n hn r h)

theorem all_lower_rows (n:Nat) (hn:2≤n):∀R∈imageBank n hn,R∈result n hn:=by
  intro R h
  obtain ⟨r,hr,rfl⟩:=List.mem_map.mp h
  exact every_original_row_image n hn r hr

theorem original_to_complete_lower_image (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  FinalEvaluationImage.original_to_final_evaluation_rows n hn

/-- Complete constructive image of the smaller original formula. This is a
transport theorem, not a recursive refutation or a serialized checker result. -/
theorem complete_lower_image (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) ∧
    ∀R∈imageBank n hn,R∈result n hn:=
  ⟨original_to_complete_lower_image n hn,all_lower_rows n hn⟩
#print axioms complete_lower_image
#print axioms every_original_row_image
end L3Emitter.FinalLowerComplete

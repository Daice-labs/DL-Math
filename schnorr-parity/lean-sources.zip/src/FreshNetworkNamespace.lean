import LowerWeakeningOperandBound
namespace L3Emitter.FreshNetworkNamespace
open EREF EREF.GeneralRED REDWitness AliasNetwork

theorem max_list (M:Nat) (xs:List Nat) (h:∀x∈xs,x≤M):xs.foldr max 0≤M:=by
  induction xs with
  | nil=>exact Nat.zero_le _
  | cons x xs ih=>exact max_le (h x (by simp)) (ih (fun y hy=>h y (by simp [hy])))

theorem ceiling_le (M:Nat) (D:List Row) (h:∀R∈D,∀t∈R.terms,t.2.natAbs≤M):
    CanonicalTrace.ceiling D≤M:=by
  apply max_list
  intro x hx
  obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hx
  obtain ⟨R,hR,ht⟩:=List.mem_flatMap.mp ht
  exact h R hR t ht

theorem literals_le (M:Nat) (xs:List Int) (h:∀l∈xs,l.natAbs≤M):RawValueBank.literalMax xs≤M:=by
  apply max_list
  intro x hx;obtain ⟨l,hl,rfl⟩:=List.mem_map.mp hx;exact h l hl

theorem gate_inputs (M:Nat) (b:Bool) (xs:List Int) (h:∀l∈xs,l.natAbs≤M)
    (g:GateRow) (hg:g∈(if b then andGate else orGate) xs):∀l∈g.inputs,l.natAbs≤M:=by
  cases b <;> simp only [Bool.false_eq_true,if_false,if_true,andGate,orGate,List.mem_append] at hg
  · rcases hg with hg|hg
    · obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hg
      intro l hl;obtain rfl:=List.mem_singleton.mp hl;simpa only [Int.natAbs_neg] using h x hx
    · obtain rfl:=List.mem_singleton.mp hg;exact h
  · rcases hg with hg|hg
    · obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hg
      intro l hl;obtain rfl:=List.mem_singleton.mp hl;exact h l hx
    · obtain rfl:=List.mem_singleton.mp hg
      intro l hl;obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hl;simpa only [Int.natAbs_neg] using h x hx

theorem gate_rows (M:Nat) (g:Gate) (hq:g.q≤M) (hx:∀x∈g.xs,x.val.natAbs≤M):
    ∀R∈g.rows,∀t∈R.terms,t.2.natAbs≤M:=by
  intro R hR
  obtain ⟨r,hr,rfl⟩:=List.mem_map.mp hR
  apply RowSupport.clause_bound
  intro l hl
  rcases List.mem_append.mp hl with hl|hl
  · apply gate_inputs M g.isAnd (g.xs.map Subtype.val) _ r hr l hl
    intro l hl;obtain ⟨x,hx',rfl⟩:=List.mem_map.mp hl;exact hx x hx'
  · obtain rfl:=List.mem_singleton.mp hl
    cases r.bit <;> simpa only [REDWitness.output,Bool.false_eq_true,if_false,if_true,Int.natAbs_neg,Int.natAbs_natCast] using hq

/-- One fresh gate advances the greatest variable ID by at most one,
provided its inputs already fit the current numeric ceiling. -/
theorem push_ceiling (M:Nat) {base:List Row} (z:Net base) (b:Bool) (xs:List Bit)
    (hz:CanonicalTrace.ceiling z.rows≤M) (hx:∀x∈xs,x.val.natAbs≤M):
    CanonicalTrace.ceiling (push z b xs).rows≤M+1:=by
  have ha:allocation z xs≤M:=max_le hz (literals_le M _ (by
    intro l hl;obtain ⟨x,hx',rfl⟩:=List.mem_map.mp hl;exact hx x hx'))
  rw [rows_push]
  apply ceiling_le
  intro R hR
  rcases List.mem_append.mp hR with hR|hR
  · intro t ht
    have h:=((CanonicalTrace.bounded z.rows z.canonical) R hR).2 t ht
    omega
  · exact gate_rows (M+1) (freshGate z b xs) (by change allocation z xs+1≤M+1;omega)
      (by intro x hx';exact (hx x hx').trans (by omega)) R hR

theorem output_bound (M:Nat) {base:List Row} (z:Net base) (xs:List Bit)
    (hz:CanonicalTrace.ceiling z.rows≤M) (hx:∀x∈xs,x.val.natAbs≤M):
    (output z xs).val.natAbs≤M+1:=by
  have ha:allocation z xs≤M:=max_le hz (literals_le M _ (by
    intro l hl;obtain ⟨x,hx',rfl⟩:=List.mem_map.mp hl;exact hx x hx'))
  change ((allocation z xs+1:Nat):Int).natAbs≤M+1
  simpa only [Int.natAbs_natCast] using Nat.add_le_add_right ha 1

#print axioms push_ceiling
end L3Emitter.FreshNetworkNamespace

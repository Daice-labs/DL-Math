import NumericEnvelopeAlgebra
namespace L3Emitter.NumericClosedNamespace
open EREF EREF.GeneralRED NumericEnvelopeAlgebra

theorem tables (n:Nat):NumericRankTables.bound n≤11000000000*(n+2)^9*(2^(n+1))^4:=by
  let K:=n+2;let T:=2^(n+1)
  have hK:1≤K:=by dsimp[K];omega
  have hT:1≤T:=Nat.one_le_pow _ _ (by omega)
  have hg:K≤K^8*T^4:=by simpa only [pow_one,pow_zero,Nat.mul_one] using grow K T hK hT 1 8 (by omega) 0 4 (by omega)
  have hr:=raw n
  change NumericRawLowerRows.bound n≤422000000*K^8*T^4 at hr
  have hc:NumericComposedTables.bound n≤423000000*K^8*T^4:=by
    unfold NumericComposedTables.bound
    change NumericRawLowerRows.bound n+108*K≤_;nlinarith
  have ht:NumericRankTables.cost n≤3400000000*K^8*T^4:=by
    unfold NumericRankTables.cost
    change 4*(2*NumericComposedTables.bound n+3*K+2)≤_;nlinarith
  have hc':NumericComposedTables.bound n≤423000000*K^9*T^4:=hc.trans
    (by simpa only [Nat.mul_assoc] using Nat.mul_le_mul_left 423000000 (grow K T hK hT 8 9 (by omega) 4 4 (by omega)))
  have hm:=Nat.mul_le_mul_left (3*K) ht
  unfold NumericRankTables.bound
  change NumericComposedTables.bound n+3*K*NumericRankTables.cost n≤11000000000*K^9*T^4
  nlinarith

def envelope (n:Nat):Nat:=12000000000*(n+2)^9*(2^(n+1))^4

theorem final (n:Nat):NumericFinalConstruction.bound n≤envelope n:=by
  let K:=n+2;let T:=2^(n+1)
  have hK:1≤K:=by dsimp[K];omega
  have hT:1≤T:=Nat.one_le_pow _ _ (by omega)
  have hw:FinalOutputDefinitions.W n≤4*K:=by unfold FinalOutputDefinitions.W AliasAssembly.width RankConstruction.width;dsimp[K];omega
  have htt:FinalOutputDefinitions.T n≤T:=by unfold FinalOutputDefinitions.T FamilyNamespace.truthRows;exact Nat.pow_le_pow_right (by omega) (by omega)
  have h0:=Nat.mul_le_mul htt hw
  have h1:=Nat.mul_le_mul_left 6 (show FinalOutputDefinitions.W n-1≤4*K by omega)
  have hc:NumericFinalConstruction.cost n≤70*K*T:=by
    unfold NumericFinalConstruction.cost
    have h3:=Nat.mul_le_mul_left 6 htt
    have hkt:K≤K*T:=by nlinarith
    have htt':T≤K*T:=by nlinarith
    nlinarith
  have hc':NumericFinalConstruction.cost n≤70*K^9*T^4:=hc.trans
    (by simpa only [Nat.mul_assoc,pow_one] using Nat.mul_le_mul_left 70 (grow K T hK hT 1 9 (by omega) 1 4 (by omega)))
  have hb:=tables n
  change NumericRankTables.bound n≤11000000000*K^9*T^4 at hb
  unfold NumericFinalConstruction.bound envelope
  change NumericRankTables.bound n+NumericFinalConstruction.cost n≤12000000000*K^9*T^4
  have hpos:1≤K^9*T^4:=Nat.mul_pos (Nat.pow_pos (by omega)) (Nat.pow_pos (by omega))
  nlinarith

#print axioms final
end L3Emitter.NumericClosedNamespace

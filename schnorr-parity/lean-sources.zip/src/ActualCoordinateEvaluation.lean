import EvaluationCase

namespace L3Emitter.ActualCoordinateEvaluation
open EREF EREF.GeneralRED REDWitness AliasNetwork RecursiveAliases AliasProgram GuardedGatePOL

def cfg (n:Nat) (hn:2≤n):=PrimaryAliasBank.cfg n hn
def beforeGate (n:Nat) (hn:2≤n) (g:Nat):=GateSnapshots.beforeGate n hn g
def left (n:Nat) (hn:2≤n) (g:Nat):=
  CoordinateSnapshots.left (cfg n hn) (beforeGate n hn g).1 g (beforeGate n hn g).2
def right (n:Nat) (hn:2≤n) (g:Nat):=
  CoordinateSnapshots.right (cfg n hn) (beforeGate n hn g).1 g (beforeGate n hn g).2
def expr (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1)+2)):=
  coordinate (cfg n hn) g (left n hn g).1 (right n hn g).1 i
def start (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1)+2)):=
  CoordinateSnapshots.start (cfg n hn) (beforeGate n hn g).1 g (beforeGate n hn g).2 i

theorem compiled_output (n:Nat) (hn:2≤n) (g:Nat) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1)+2)):
    ((expr n hn g i).compile (start n hn g i)).1=(AliasAssembly.built n hn).1.2 (n+1+g) i:=by
  rw [GateSnapshots.output n hn g hs]
  exact (CoordinateSnapshots.tabulate_at _ (fun j=>(expr n hn g j).compile) (right n hn g).2 i).symm

theorem compiled_rows (n:Nat) (hn:2≤n) (g:Nat) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1)+2)):
    ∀R∈((expr n hn g i).compile (start n hn g i)).2.rows,R∈UnaryRelationBank.result n hn:=by
  intro R hr
  have ht:R∈(GateSnapshots.atGate n hn g).2.rows:=
    CoordinateSnapshots.tabulate_after _ _ (fun j=>Expr.extends _) (right n hn g).2 i R hr
  exact UnaryRelationBank.retains n hn R (UnaryRelationBank.category_keep n hn R
    (GateSnapshots.built_to_bank n hn R (GateSnapshots.rows_retained n hn g hs R ht)))

def rows (α:Val) (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1)+2)):=
  EvaluationCase.rows α (expr n hn g i) (start n hn g i)
def program (α:Val) (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1)+2)) (D:List Row):=
  EvaluationCase.program α (expr n hn g i) (start n hn g i) D

theorem checks (α:Val) (n:Nat) (hn:2≤n) (g:Nat) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1)+2)) (D:List Row) (hd:∀R∈UnaryRelationBank.result n hn,R∈D):
    check D (program α n hn g i D)=some (D++rows α n hn g i) ∧
    guarded (EvaluationCase.guards α (expr n hn g i))
      (sign (coordinateValue ((cfg n hn).map (eval α)) g
        (view α (left n hn g).1) (view α (right n hn g).1) i)
        ((AliasAssembly.built n hn).1.2 (n+1+g) i))∈D++rows α n hn g i:=by
  have h:=EvaluationCase.checks α (expr n hn g i) (start n hn g i) D
    (fun R hr=>hd R (compiled_rows n hn g hs i R hr))
  refine ⟨h.1,?_⟩
  have hv:(expr n hn g i).value α=coordinateValue ((cfg n hn).map (eval α)) g
      (view α (left n hn g).1) (view α (right n hn g).1) i:=coordinate_value ..
  rw [hv,compiled_output n hn g hs i] at h
  exact h.2

theorem original_to_case (α:Val) (n:Nat) (hn:2≤n) (g:Nat) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1)+2)):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4))
      (UnaryRelationBank.result n hn++rows α n hn g i):=
  L3.Fam.checkedTrace_trans (UnaryRelationBank.original_to_unary_relations n hn)
    (check_trace _ _ _ (checks α n hn g hs i _ (fun R h=>h)).1)

theorem coordinate_cost (c:Config Bit) (g:Nat) {w:Nat} (l r:AliasBits w) (i:Fin (w+2)):
    EvaluationCase.cost (coordinate c g l r i)≤25 ∧ (ExpressionEvaluation.leaves (coordinate c g l r i)).length≤19:=by
  unfold coordinate
  split_ifs <;> simp [EvaluationCase.cost,ExpressionEvaluation.leaves,lookup]

theorem program_count (α:Val) (n:Nat) (hn:2≤n) (g:Nat)
    (i:Fin (AliasAssembly.width (n+1)+2)) (D:List Row):(program α n hn g i D).length≤63:=by
  rw [program,EvaluationCase.commands_count]
  have h:=coordinate_cost (cfg n hn) g (left n hn g).1 (right n hn g).1 i
  change EvaluationCase.cost (expr n hn g i)≤25 ∧ (ExpressionEvaluation.leaves (expr n hn g i)).length≤19 at h
  omega

#print axioms compiled_output
#print axioms checks
#print axioms original_to_case
#print axioms program_count
end L3Emitter.ActualCoordinateEvaluation

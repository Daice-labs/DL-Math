import NumericAliasContext
import FrontendNamespaceEnvelope
namespace L3Emitter.NumericNetwork
open EREF EREF.GeneralRED AliasNetwork RecursiveAliases AliasAssembly FamilyNamespace
open FrontendNamespaceEnvelope

def externalCeiling (k:Nat):Nat:=2000*scale k

theorem external_bound (k:Nat) (hk:3≤k):ExternalBound (externalCeiling k) k hk:=by
  have hr:=restriction k hk
  have hc:=constant k hk
  have ho:=original k
  have hp:1≤scale k:=Nat.mul_pos (Nat.pow_pos (by omega)) (Nat.pow_pos (by omega))
  have hpow:1≤2^k:=Nat.one_le_pow _ _ (by omega)
  have hk2:k^2≤scale k:=(Nat.pow_le_pow_left (show k≤k+1 by omega) 2).trans
    (by unfold scale;exact Nat.le_mul_of_pos_right _ hpow)
  have hk1:k≤scale k:=(show k≤k^2 by nlinarith).trans hk2
  constructor
  · change (RestrictionBit.B k hk :Int).natAbs≤externalCeiling k
    simp only[Int.natAbs_natCast];unfold externalCeiling;omega
  · change (ConstantConstruction.C k hk :Int).natAbs≤externalCeiling k
    simp only[Int.natAbs_natCast];unfold externalCeiling;omega
  · intro b g x hx
    obtain ⟨c,hc,rfl⟩:=List.mem_map.mp hx
    have h:=RestrictionBounds.branch_bounds k hk c.lit (List.mem_map.mpr ⟨c,(List.mem_filter.mp hc).1,rfl⟩)
    change c.lit.natAbs≤externalCeiling k
    unfold externalCeiling;omega
  · intro g hg t ht
    change (RankConstruction.v k hk g t).natAbs≤externalCeiling k
    unfold RankConstruction.v
    simp only[Int.natAbs_natCast]
    have hw:RankConstruction.width k≤3*k:=by unfold RankConstruction.width;omega
    have ht':t<4*k:=by unfold width at ht;omega
    have hprod:g*RankConstruction.width k≤9*k^2:=by nlinarith [Nat.mul_le_mul (show g≤3*k by omega) hw]
    unfold externalCeiling;omega
  · intro g hg p hp j hj
    have h:encode k (3*k-4) (.sel g p j)≤variableCount k (3*k-4):=
      (encode_bounds k (3*k-4) (.sel g p j) ⟨hg,hp,hj⟩).2
    change ((encode k (3*k-4) (.sel g p j):Nat):Int).natAbs≤externalCeiling k
    simp only[Int.natAbs_natCast];unfold externalCeiling;omega
  · intro g hg a b
    have hab:2*a.toNat+b.toNat<4:=by cases a <;> cases b <;> decide
    have h:encode k (3*k-4) (.fn g (2*a.toNat+b.toNat))≤variableCount k (3*k-4):=
      (encode_bounds k (3*k-4) (.fn g (2*a.toNat+b.toNat)) ⟨hg,hab⟩).2
    change ((encode k (3*k-4) (.fn g (2*a.toNat+b.toNat)):Nat):Int).natAbs≤externalCeiling k
    simp only[Int.natAbs_natCast];unfold externalCeiling;omega

theorem external_mono {M N k:Nat} {hk:3≤k} (h:M≤N) (he:ExternalBound M k hk):ExternalBound N k hk:=
  ⟨he.restriction.trans h,he.constant.trans h,
   fun b g x hx=>(he.choice b g x hx).trans h,
   fun g hg t ht=>(he.rank g hg t ht).trans h,
   fun g hg p hp j hj=>(he.selector g hg p hp j hj).trans h,
   fun g hg a b=>(he.function g hg a b).trans h⟩

#print axioms external_bound
end L3Emitter.NumericNetwork

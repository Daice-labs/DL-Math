import ProjectionNormalization
import NamedSerialization
import NormalizationBytes

namespace L3Emitter.FullNormalization
open EREF EREF.GeneralRED FamilyNamespace FamilyRows InputSwap
open SelectorNormalization

def finalRows (k s : Nat) : List Row :=
  ProjectionNormalization.base k s++[(forbidden 0 3).row k s,(forbidden 0 12).row k s]

/-- All 2k RED normalization steps. All old rows and previous commands are
    covered. No input-case satisfiability or normalization oracle is assumed. -/
theorem full_normalization_all (k s : Nat) (hk : 2≤k) (hs : 0<s) :
    CheckedTrace (OriginalEncoding.rows k s) (finalRows k s) := by
  have hp := selector_prefix_all k s hk hs
  have repeated := obligation_step _ _ _ (by exact canonical_normalize _ _)
    (RepeatedWitness.repeated_input_all k s hk hs)
  have hr : CheckedTrace (OriginalEncoding.rows k s) (ProjectionNormalization.base k s) := by
    have h := trace_trans hp (CheckedTrace.cons repeated (CheckedTrace.refl _))
    simpa only [RepeatedWitness.prior,RepeatedWitness.candidate,ProjectionNormalization.base,
      ProjectionNormalization.units,state_snoc] using h
  have p1 := obligation_step _ _ _ (canonical_normalize _ _)
    (ProjectionNormalization.first_projection_all k s hk hs)
  have p2 := obligation_step _ _ _ (canonical_normalize _ _)
    (ProjectionNormalization.second_projection_all k s hk hs)
  have h := trace_trans hr (CheckedTrace.cons p1 (CheckedTrace.cons p2 (CheckedTrace.refl _)))
  simpa [finalRows,List.append_assoc] using h

def specPB (k s : Nat) (r : Spec) : PBRow :=
  ⟨r.literals.map (fun l => (1,TemplateBytes.signedLiteral (lit k s l))),r.rhs⟩

theorem spec_binding (k s : Nat) (r : Spec) : TemplateBytes.decodeRow (specPB k s r)=r.row k s := by
  simp [TemplateBytes.decodeRow,specPB,Spec.row,List.map_map,Function.comp_def,
    TemplateBytes.literal_roundtrip]

def repeatedEntries (k s : Nat) := NamedSerialization.entries k s (RepeatedWitness.image k)
def projectionEntries (k s : Nat) := NamedSerialization.entries k s (fun w => .wire (PortSwap.combined k w))
def extraSpecs : List Spec := [unitSpec 1 0,forbidden 0 3,forbidden 0 12]
def extraCommands (k s : Nat) : List Command :=
  [.red (specPB k s (unitSpec 1 0)) (repeatedEntries k s),
   .red (specPB k s (forbidden 0 3)) (projectionEntries k s),
   .red (specPB k s (forbidden 0 12)) (projectionEntries k s)]
def commands (k s : Nat) := NormalizationEmitter.commandsAll k s++extraCommands k s
def document (k s : Nat) : Doc := (commands k s).flatMap command

theorem command_count (k s : Nat) (hk : 2≤k) : (commands k s).length=2*k := by
  simp only [commands,List.length_append,NormalizationEmitter.prefix_count k s hk,
    extraCommands,List.length_cons,List.length_nil]
  omega

theorem prior_specs (k s : Nat) (hs : 0<s) (previous : List (Nat × Nat))
    (hv : ∀ pj∈previous,pj.1<2 ∧ pj.2<k) (R : Row) (hr : R∈state k s previous) :
    ∃ r : Spec,r.valid k s ∧ r.row k s=R := by
  rcases List.mem_append.mp hr with hr | hr
  · obtain ⟨r,hmem,rfl⟩ := List.mem_map.mp hr
    exact ⟨r,original_valid k s r ((OriginalEncoding.spec_mem_iff k s hs r).mp hmem),rfl⟩
  · obtain ⟨pj,hpj,rfl⟩ := List.mem_map.mp hr
    exact ⟨unitSpec pj.1 pj.2,unit_valid k s _ _ hs (hv pj hpj).1 (hv pj hpj).2,unit_binding _ _ _ _⟩

theorem repeated_serialized (k s : Nat) (hk : 2≤k) (hs : 0<s) :
    Obligations (RepeatedWitness.prior k s) (RepeatedWitness.candidate k)
      (NamedSerialization.decoded (repeatedEntries k s)) := by
  have ho := RepeatedWitness.repeated_input_all k s hk hs
  intro R hr
  have hex : ∃ r : Spec,r.valid k s ∧ r.row k s=R := by
    rcases List.mem_cons.mp hr with rfl | hr
    · exact ⟨unitSpec 1 0,unit_valid k s _ _ hs (by decide) (by omega),unit_binding _ _ _ _⟩
    · apply prior_specs k s hs (rightPrevious k k) _ R hr
      intro pj hpj
      rcases (right_mem k k pj.1 pj.2).mp hpj with h | h <;> omega
  obtain ⟨r,hv,rfl⟩ := hex
  rw [show repeatedEntries k s=NamedSerialization.entries k s (RepeatedWitness.image k) from rfl,
    NamedSerialization.serialized_subst k s (RepeatedWitness.image k) (RepeatedWitness.image_valid k s) r hv]
  exact ho _ hr

theorem projection_serialized (k s c : Nat) (hk : 2≤k) (hs : 0<s)
    (previous : List Row)
    (hp : ∀ R∈previous,∃ r : Spec,r.valid k s ∧ r.row k s=R)
    (ho : Obligations previous ((forbidden 0 c).row k s) (ProjectionNormalization.actual k s hk)) :
    Obligations previous ((forbidden 0 c).row k s)
      (NamedSerialization.decoded (projectionEntries k s)) := by
  intro R hr
  have hex : ∃ r : Spec,r.valid k s ∧ r.row k s=R := by
    rcases List.mem_cons.mp hr with rfl | hr
    · exact ⟨forbidden 0 c,ProjectionNormalization.forbidden_valid k s c hs,rfl⟩
    · exact hp R hr
  obtain ⟨r,hv,rfl⟩ := hex
  rw [show projectionEntries k s=NamedSerialization.entries k s (fun w => .wire (PortSwap.combined k w)) from rfl,
    NamedSerialization.wire_serialized_subst k s (PortSwap.combined k) (PortSwap.combined_valid k s hk) r hv]
  exact ho _ hr

theorem projection_base_specs (k s : Nat) (hk : 2≤k) (hs : 0<s) (R : Row)
    (hr : R∈ProjectionNormalization.base k s) : ∃ r : Spec,r.valid k s ∧ r.row k s=R := by
  apply prior_specs k s hs (ProjectionNormalization.units k) _ R hr
  intro pj hpj
  rcases (ProjectionNormalization.units_mem k pj.1 pj.2 hk).mp hpj with h | h <;> omega

theorem first_projection_serialized (k s : Nat) (hk : 2≤k) (hs : 0<s) :
    Obligations (ProjectionNormalization.base k s) ((forbidden 0 3).row k s)
      (NamedSerialization.decoded (projectionEntries k s)) :=
  projection_serialized k s 3 hk hs _ (projection_base_specs k s hk hs)
    (ProjectionNormalization.first_projection_all k s hk hs)

theorem second_projection_serialized (k s : Nat) (hk : 2≤k) (hs : 0<s) :
    Obligations (ProjectionNormalization.base k s++[(forbidden 0 3).row k s]) ((forbidden 0 12).row k s)
      (NamedSerialization.decoded (projectionEntries k s)) := by
  apply projection_serialized k s 12 hk hs _ _ (ProjectionNormalization.second_projection_all k s hk hs)
  intro R hR
  rcases List.mem_append.mp hR with hR | hR
  · exact projection_base_specs k s hk hs R hR
  · obtain rfl := List.mem_singleton.mp hR
    exact ⟨forbidden 0 3,ProjectionNormalization.forbidden_valid k s 3 hs,rfl⟩

#print axioms full_normalization_all
#print axioms repeated_serialized
#print axioms first_projection_serialized
#print axioms second_projection_serialized
#print axioms command_count
end L3Emitter.FullNormalization

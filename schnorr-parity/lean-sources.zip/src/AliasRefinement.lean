import AliasAssembly
import SemanticCircuitTopology

set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

namespace L3Emitter.AliasRefinement
open EREF AliasNetwork RecursiveAliases L3Uniform.Alias L3Uniform.Circuit L3Uniform.Rank
variable {w : Nat}

theorem bool_cases (f : Bool→Bool) (b : Bool) : (if b then f true else f false)=f b := by
  cases b <;> rfl

theorem table_first (t : Table) (b c : Bool) :
    (if b then t.eval true c else t.eval false c)=t.eval b c := by cases b <;> rfl

def encoding (w : Nat) (a : Alias) : AliasValues w :=
  fun i=>if i.val<w then decide (i.val=a.source)
    else a.unary.eval (decide (i.val=w+1))

def ideal (h : High) (beta gamma : Nat) (b c : Bool) : Config Bool where
  k := h.k
  T := true
  F := false
  B := b
  C := c
  beta := fun g=>decide (g=beta)
  gamma := fun g=>decide (g=gamma)
  hit := fun g=>decide (h.left g=h.k+beta)
  kept := fun g=>decide (g≠0 ∧ g≠beta ∧ g≠gamma)
  rank := fun g t=>decide (g≠0 ∧ g≠beta ∧ g≠gamma ∧ rank beta gamma g=t)
  sel := fun g p j=>decide (j=if p=0 then h.left g else h.right g)
  fn := fun g a b=>(h.table g).eval a b

theorem initial_encoding (h : High) (beta gamma : Nat) (b c : Bool) (j : Nat) :
    (fun i=>if i.val<w then
      if i.val=(if j=0 then 0 else j-1) then true else false
      else if j=0 then b else if i.val=w+1 then true else false) =
      encoding w (L3Uniform.Circuit.initial b j) := by
  funext i
  by_cases hj:j=0 <;> by_cases hi:i.val<w <;>
    simp [encoding,L3Uniform.Circuit.initial,constantAlias,wireAlias,Unary.eval,hj,hi]

theorem coordinate_nonzero (h : High) (beta gamma g : Nat) (b c : Bool)
    (l r : Alias) (hg : g≠0) (hbg : beta≠gamma) :
    coordinateValue (ideal h beta gamma b c) g (encoding w l) (encoding w r) =
      encoding w (if g=beta then constantAlias c
        else if g=gamma then
          if h.left g=h.k+beta then r.map ((h.table g).fixLeft c)
          else l.map ((h.table g).fixRight c)
        else wireAlias (h.k-1+rank beta gamma g)) := by
  funext i
  by_cases hb:g=beta
  · have hh:g≠gamma:=by omega
    simp_all [coordinateValue,ideal,encoding,constantAlias,Unary.eval]
  · by_cases hc:g=gamma
    · by_cases hit:h.left g=h.k+beta <;> by_cases hi:i.val<w <;> by_cases hu:i.val=w+1 <;>
        simp_all [coordinateValue,ideal,encoding,Alias.map,Unary.comp,
          Table.fixLeft,Table.fixRight,Unary.eval] <;> try simp only [bool_cases,table_first]
    · by_cases hi:i.val<w
      · have he : (h.k-1 ≤ i.val ∧ rank beta gamma g=i.val-(h.k-1)) ↔
            i.val=h.k-1+rank beta gamma g := by omega
        simp only [coordinateValue,ideal,hg,hb,hc,hi,↓reduceIte,decide_false,decide_true,
          Bool.false_and,Bool.false_or,Bool.true_and,encoding,wireAlias]
        by_cases hr:h.k-1 ≤ i.val
        · have hh:(rank beta gamma g=i.val-(h.k-1)) ↔ i.val=h.k-1+rank beta gamma g := by omega
          simp [hr,hh,hg,hb,hc]
        · have hh:i.val≠h.k-1+rank beta gamma g:=by omega
          simp [hr,hh,hg,hb,hc]
      · simp [coordinateValue,ideal,hg,hb,hc,hi,encoding,wireAlias,Unary.eval]

theorem coordinate_zero (h : High) (beta gamma : Nat) (b c : Bool) (l : Alias) :
    coordinateValue (ideal h beta gamma b c) 0 (encoding w l) (encoding w (wireAlias 0)) =
      encoding w ((wireAlias 0).map ((h.table 0).fixLeft b)) := by
  funext i
  by_cases hi:i.val<w <;> by_cases hu:i.val=w+1 <;>
    simp [coordinateValue,ideal,encoding,Alias.map,Unary.comp,Table.fixLeft,
      wireAlias,Unary.eval,hi,hu]

/-- The bridge uses the original circuit representation already proved in
    CircuitTransport. Selector/choice facts remain explicit hypotheses; this
    theorem does not promote them to emitted POL/RUP leaves. -/
theorem step_agrees (h : High) (beta gamma g : Nat) (b c : Bool)
    (as : Nat→Alias) (hbg : beta≠gamma)
    (hl : h.left g<h.k+g) (hr : h.right g<h.k+g)
    (hfirst : g=0 → as (h.right g)=wireAlias 0) :
    stepValue (ideal h beta gamma b c) (fun j=>encoding w (as j)) g =
      encoding w (nextAlias h beta gamma b c as g) := by
  have lp := portValues_onehot h.k g (h.left g)
    ((ideal h beta gamma b c).sel g 0) (fun j=>encoding w (as j)) hl
    (by intro i hi;rfl)
  have rp := portValues_onehot h.k g (h.right g)
    ((ideal h beta gamma b c).sel g 1) (fun j=>encoding w (as j)) hr
    (by intro i hi;rfl)
  change coordinateValue _ g (portValues h.k g _ _) (portValues h.k g _ _) = _
  rw [lp,rp]
  dsimp only
  by_cases hg:g=0
  · rw [hfirst hg]
    subst g
    simpa [nextAlias,hfirst rfl] using coordinate_zero (w:=w) h beta gamma b c (as (h.left 0))
  · simpa [nextAlias,hg] using
      coordinate_nonzero (w:=w) h beta gamma g b c (as (h.left g)) (as (h.right g)) hg hbg

#print axioms coordinate_nonzero
#print axioms coordinate_zero
#print axioms step_agrees
end L3Emitter.AliasRefinement

import NumericProjectionTapes
import NumericCategoryRows
import ForcingSize
namespace L3Emitter.NumericCategoryTapes
open EREF EREF.GeneralRED RecordedOperandFields NumericProgramFields GateCategories CategoryPrograms

def bound (n:Nat):Nat:=NumericValueClosed.bound n+36*(n+1)^2+1

theorem choices_length (n:Nat) (hn:2≤n):(choices n hn).length+1≤bound n:=by
 have h:=ForcingSize.chosen_bound (n+1) (by omega)
 unfold choices bound;omega

theorem pair (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4)
 (q r:Category) (hq:q∈cats n) (hr:r∈cats n) (D:List Row):
 Bounded (bound n) (pairProgram n hn g q r D):=by
 have hM:NumericValueClosed.bound n≤bound n:=by unfold bound;omega
 apply NumericProjectionTapes.pair
 · intro c hc;exact (NumericCategoryRows.choices n hn c hc).trans hM
 · exact (NumericCategoryRows.bit_bound n hn g hg q hq).trans hM
 · exact (NumericCategoryRows.bit_bound n hn g hg r hr).trans hM
 · unfold support;simp only [List.length_map]
   exact (Nat.add_le_add_right (List.length_filter_le _ _) 1).trans (choices_length n hn)
 · unfold support;simp only [List.length_map]
   exact (Nat.add_le_add_right (List.length_filter_le _ _) 1).trans (choices_length n hn)
 · have h:=choices_length n hn;omega

theorem pairs_loop (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4)
 (D:List Row) (ps:List (Category×Category)) (hp:∀p∈ps,p∈pairs n):
 Bounded (bound n) (pairLoop n hn g D ps):=by
 induction ps generalizing D with
 | nil=>simp [pairLoop,Bounded]
 | cons p ps ih=>
   obtain ⟨q,r⟩:=p
   have h:=(pair_mem n q r).mp (hp (q,r) (by simp))
   intro z hz;rcases List.mem_append.mp hz with hz|hz
   · exact pair n hn g hg q r h.1 h.2.1 D z hz
   · exact ih _ (by intro p hp';exact hp p (by simp [hp'])) z hz

theorem gate (n:Nat) (hn:2≤n) (g:Nat) (hg:g<3*(n+1)-4) (D:List Row):
 Bounded (bound n) (CategoryPrograms.program n hn g D):=by
 intro z hz;rcases List.mem_append.mp hz with hz|hz
 · apply NumericProjectionTapes.alo _ _ _ _ _ _ ?_ ?_ z hz
   · intro l hl;exact (NumericCategoryRows.vars_bound n hn g hg l hl).trans (by unfold bound;omega)
   · have h:=choices_length n hn;omega
 · exact pairs_loop n hn g hg _ _ (fun _ h=>h) z hz

theorem loop (n:Nat) (hn:2≤n) (D:List Row) (gs:List Nat)
 (hg:∀g∈gs,g<3*(n+1)-4):Bounded (bound n) (CategoryBank.loop n hn D gs):=by
 induction gs generalizing D with
 | nil=>simp [CategoryBank.loop,Bounded]
 | cons g gs ih=>
   intro z hz;rcases List.mem_append.mp hz with hz|hz
   · exact gate n hn g (hg g (by simp)) D z hz
   · exact ih _ (by intro j hj;exact hg j (by simp [hj])) z hz

theorem emitted (n:Nat) (hn:2≤n):Bounded (bound n) (CategoryBank.emitted n hn):=by
 apply loop
 intro g hg;exact ((CategoryBank.gate_mem n g).mp hg).2
#print axioms emitted
end L3Emitter.NumericCategoryTapes

import HitCellPOL
namespace L3Emitter.HitBranchBinding
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram ConcreteSelection GuardedGatePOL
abbrev Choice:=HitExclusions.Choice

def es (n:Nat) (hn:2≤n) (c:Choice n):=HitSnapshots.entries n hn c.gamma c.gamma_lt
def edge (n:Nat) (hn:2≤n) (c:Choice n):Bit:=(PrimaryAliasBank.cfg n hn).sel c.gamma 0 (n+1+c.beta)
def hit (n:Nat) (hn:2≤n) (c:Choice n):Bit:=(PrimaryAliasBank.cfg n hn).hit c.gamma

def picked (n:Nat) (hn:2≤n) (c:Choice n):Cell:=
  ((es n hn c).find? (fun d=>decide (d.choice=(PrimaryAliasBank.cfg n hn).beta c.beta ∧ d.value=edge n hn c))).getD
    ⟨(PrimaryAliasBank.cfg n hn).beta c.beta,edge n hn c,hit n hn c⟩

theorem picked_properties (n:Nat) (hn:2≤n) (c:Choice n):
    picked n hn c∈es n hn c ∧ (picked n hn c).choice=(PrimaryAliasBank.cfg n hn).beta c.beta ∧
    (picked n hn c).value=edge n hn c:=by
  have pairs: (es n hn c).map (fun d=>(d.choice,d.value))=HitSnapshots.inputs n hn c.gamma:=
    (HitSnapshots.properties n hn c.gamma c.gamma_lt).1
  have hm:((PrimaryAliasBank.cfg n hn).beta c.beta,edge n hn c)∈HitSnapshots.inputs n hn c.gamma:=by
    apply List.mem_map.mpr
    exact ⟨c.beta-1,List.mem_range.mpr (by have:=c.beta_pos;have:=c.ordered;omega),by simp [edge,Nat.sub_add_cancel (Nat.one_le_of_lt c.beta_pos)]⟩
  rw [←pairs] at hm
  obtain ⟨d,hd,he⟩:=List.mem_map.mp hm
  have hex: ((es n hn c).find? (fun d=>decide (d.choice=(PrimaryAliasBank.cfg n hn).beta c.beta ∧ d.value=edge n hn c))).isSome:=
    List.find?_isSome.mpr ⟨d,hd,by simp only [decide_eq_true_eq];exact ⟨congrArg Prod.fst he,congrArg Prod.snd he⟩⟩
  cases hfind:(es n hn c).find? (fun d=>decide (d.choice=(PrimaryAliasBank.cfg n hn).beta c.beta ∧ d.value=edge n hn c)) with
  | none=>simp only [hfind,Option.isSome_none,Bool.false_eq_true] at hex
  | some d=>
    have hp:=List.find?_some hfind
    simp only [decide_eq_true_eq] at hp
    simpa only [picked,hfind,Option.getD_some] using And.intro (List.mem_of_find?_eq_some hfind) hp

def cellRows (n:Nat) (hn:2≤n) (c:Choice n):=(es n hn c).map (HitCellPOL.row c.lit (edge n hn c).val)
def cellProgram (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row):Program:=
  (es n hn c).map fun d=>(HitCellPOL.row c.lit (edge n hn c).val d,HitCellPOL.tape D c.lit (edge n hn c).val d)

theorem cell_checks (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row)
    (hd:∀R∈UnaryValueBank.result n hn,R∈D) (he:∀R∈HitExclusions.rows n hn c,R∈D):
    check D (cellProgram n hn c D)=some (D++cellRows n hn c):=by
  have hp:=HitSnapshots.properties n hn c.gamma c.gamma_lt
  have hc:=IndependentProgram.check_base D (cellProgram n hn c D) (by
    intro cmd hm;obtain ⟨d,hd',rfl⟩:=List.mem_map.mp hm
    apply HitCellPOL.checks D c.lit (edge n hn c).val d c.nonzero (edge n hn c).property ((hp.2.1 d hd').mono hd)
    intro hne
    have hi:(d.choice,d.value)∈HitSnapshots.inputs n hn c.gamma:=by rw [←hp.1];exact List.mem_map.mpr ⟨d,hd',rfl⟩
    obtain ⟨i,hi,hid⟩:=List.mem_map.mp hi
    have hb:(PrimaryAliasBank.cfg n hn).beta (i+1)=d.choice:=congrArg Prod.fst hid
    have hv:(PrimaryAliasBank.cfg n hn).sel c.gamma 0 (n+1+(i+1))=d.value:=congrArg Prod.snd hid
    have hib:i+1≠c.beta:=by intro h;apply hne;rw [←hv,h];rfl
    rw [←hb]
    exact he _ (List.mem_map.mpr ⟨i+1,(HitExclusions.gate_mem n c _).mpr
      ⟨by omega,by have:=List.mem_range.mp hi;omega,hib⟩,rfl⟩))
  simpa [cellProgram,cellRows,outputs,List.map_map] using hc

def backRow (n:Nat) (hn:2≤n) (c:Choice n):=clause [-c.lit,-(hit n hn c).val,(edge n hn c).val]
def backTape (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row):=
  GuardedOrJoin.tape D c.lit (edge n hn c).val (hit n hn c).val ((es n hn c).map (fun d=>d.term.val))

theorem back_check (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row)
    (hd:∀R∈UnaryValueBank.result n hn,R∈D) (he:∀R∈cellRows n hn c,R∈D):
    polEval (dbOf D) (backTape n hn c D) []=some (backRow n hn c):=by
  have hp:=HitSnapshots.properties n hn c.gamma c.gamma_lt
  have hv:Valid ((es n hn c).map (fun d=>d.term.val)):=by
    intro l hl;obtain ⟨d,hd,rfl⟩:=List.mem_map.mp hl;exact d.term.property
  have hne:(es n hn c).map (fun d=>d.term.val)≠[]:=by
    intro h
    have hm: (picked n hn c).term.val∈(es n hn c).map (fun d=>d.term.val):=List.mem_map.mpr ⟨_,(picked_properties n hn c).1,rfl⟩
    rw [h] at hm;exact List.not_mem_nil hm
  apply GuardedOrJoin.checks D c.lit (edge n hn c).val (hit n hn c).val _ c.nonzero
    (edge n hn c).property (hit n hn c).property hv hne
  · apply hd;simpa only [List.map_map,Function.comp_def] using hp.2.2.2
  · intro x hx;obtain ⟨d,hd',rfl⟩:=List.mem_map.mp hx
    exact he _ (List.mem_map.mpr ⟨d,hd',rfl⟩)

def forwardRow (n:Nat) (hn:2≤n) (c:Choice n):=clause [-c.lit,-(edge n hn c).val,(hit n hn c).val]
def forwardTape (n:Nat) (hn:2≤n) (c:Choice n) (D:List Row):=
  HitCellPOL.forwardTape D c.lit (edge n hn c).val (hit n hn c).val (picked n hn c)

theorem forward_check (n:Nat) (hn:2≤n) (c:Choice n) (hc:c∈CategoryPrograms.choices n hn)
    (D:List Row) (hd:∀R∈UnaryValueBank.result n hn,R∈D):
    polEval (dbOf D) (forwardTape n hn c D) []=some (forwardRow n hn c):=by
  have pp:=picked_properties n hn c
  have hp:=HitSnapshots.properties n hn c.gamma c.gamma_lt
  apply HitCellPOL.forward_check D c.lit (edge n hn c).val (hit n hn c).val _
    c.nonzero (edge n hn c).property (hit n hn c).property (congrArg Subtype.val pp.2.2)
    ((hp.2.1 _ pp.1).mono hd)
  · rw [pp.2.1]
    apply hd
    exact UnaryPortTransport.category_keep n hn _ (CategoryBank.retains n hn _
      (GateCategories.forward n hn c.beta c.beta_pos (by have:=c.ordered;have:=c.gamma_lt;omega)
       .beta (by simp [GateCategories.categories]) c.lit
       ((GateCategories.support_mem _ _ _ _).mpr ⟨c,hc,rfl,rfl⟩)))
  · exact hd _ (hp.2.2.1 _ (List.mem_map.mpr ⟨_,pp.1,rfl⟩))

#print axioms picked_properties
#print axioms cell_checks
#print axioms back_check
#print axioms forward_check
end L3Emitter.HitBranchBinding

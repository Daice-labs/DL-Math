import MixtureBeta
import MixtureRank

namespace L3Emitter.CategorySourceInputs
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GateCategories CategoryPrograms SourceMixture

def c (n:Nat) (hn:2≤n) := PrimaryAliasBank.cfg n hn
def rankAt (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) : Bit :=
  if n ≤ i.val then AliasAssembly.rankBit (n+1) (by omega) g (i.val-n) else (c n hn).F
def Keep (n:Nat) (hn:2≤n) (D:List Row) :=∀R∈CategoryBank.result n hn,R∈D

theorem true_unit (n:Nat) (hn:2≤n) : clause [(c n hn).T.val]∈CategoryBank.result n hn := by
  apply CategoryBank.retains
  apply FirstPortOneHot.block_retains n hn 1
  apply FirstPortOneHot.block_retains n hn 0
  exact List.mem_append_left _ (PrimaryAliasBank.true_unit n hn)

theorem beta_gamma (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) :
    clause [-((c n hn).beta g).val,-((c n hn).gamma g).val]∈CategoryBank.result n hn := by
  exact CategoryBank.exclusion n hn g hg hs .beta .gamma
    (by simp [cats,categories]) (by simp [cats,categories]) (by decide)

def exclusionRow (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (cat:Category) :=
  clause [-(bit n hn g cat).val,-(rankAt n hn g i).val]
def tape (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (cat:Category) (D:List Row) : List Tok :=
  if n ≤ i.val then [.ref (ReferenceTransport.locate D (exclusionRow n hn g i cat))]
  else ChoiceProjection.weakenTokens D [(c n hn).T.val] [-(bit n hn g cat).val]

theorem tape_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1))) (cat:Category) (hcat:cat=.beta ∨ cat=.gamma)
    (D:List Row) (hd:Keep n hn D) :
    polEval (dbOf D) (tape n hn g i cat D) []=some (exclusionRow n hn g i cat) := by
  by_cases hi:n ≤ i.val
  · have ht:i.val-n<RankConstruction.width (n+1):=by
      have hh:=i.isLt
      unfold AliasAssembly.width at hh
      omega
    have hc:cat∈cats n:=by rcases hcat with rfl|rfl <;> simp [cats,categories]
    have hr:Category.rank (i.val-n)∈cats n:=by
      simp [cats,categories,RankConstruction.width] at ht ⊢
      exact ht
    have he:cat≠.rank (i.val-n):=by rcases hcat with rfl|rfl <;> simp
    have hx:=hd _ (CategoryBank.exclusion n hn g hg hs cat (.rank (i.val-n)) hc hr he)
    have heq:clause [-value n hn g cat,-value n hn g (.rank (i.val-n))]=exclusionRow n hn g i cat:=by
      simp [value,exclusionRow,rankAt,hi,bit]
    rw [heq] at hx
    simp only [tape,hi,↓reduceIte,polEval,ReferenceTransport.locate_correct _ _ hx]
  · have hu:=hd _ (true_unit n hn)
    have hw:=ChoiceProjection.weaken_succeeds D [(c n hn).T.val] [-(bit n hn g cat).val]
      (by simp [Valid,(c n hn).T.property]) (by simp [Valid,(bit n hn g cat).property]) hu
    have heq:clause ([(c n hn).T.val]++[-(bit n hn g cat).val])=exclusionRow n hn g i cat:=by
      simp only [exclusionRow,rankAt,hi,↓reduceIte,c,PrimaryAliasBank.false_bit,neg,neg_neg,
        List.cons_append,List.nil_append]
      exact PriorityExclusive.clause_swap _ _ (PrimaryAliasBank.cfg n hn).T.property
        (neg_ne_zero.mpr (bit n hn g cat).property)
    simpa only [tape,hi,↓reduceIte,heq] using hw

def rows (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) :=
  [exclusionRow n hn g i .beta,exclusionRow n hn g i .gamma]
def prepare (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (D:List Row) : Program :=
  [(exclusionRow n hn g i .beta,tape n hn g i .beta D),
   (exclusionRow n hn g i .gamma,tape n hn g i .gamma D)]
theorem prepare_check (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1))) (D:List Row) (hd:Keep n hn D) :
    check D (prepare n hn g i D)=some (D++rows n hn g i) := by
  apply IndependentProgram.check_base
  intro cmd hc
  simp only [prepare,List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl|rfl
  · exact tape_check n hn g hg hs i .beta (Or.inl rfl) D hd
  · exact tape_check n hn g hg hs i .gamma (Or.inr rfl) D hd

def compatible (n:Nat) (hn:2≤n) (g:Nat) (i:Fin (AliasAssembly.width (n+1))) (s:Refs) :=
  s.beta=(c n hn).beta g ∧ s.gamma=(c n hn).gamma g ∧ s.rank=rankAt n hn g i

theorem all_inputs (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (i:Fin (AliasAssembly.width (n+1))) (s:Refs) (h:compatible n hn g i s)
    (D:List Row) (hd:Keep n hn D) :
    clause [-s.beta.val,-s.gamma.val]∈D++rows n hn g i ∧
    clause [-s.gamma.val,-s.beta.val]∈D++rows n hn g i ∧
    clause [-s.beta.val,-s.rank.val]∈D++rows n hn g i ∧
    clause [-s.gamma.val,-s.rank.val]∈D++rows n hn g i := by
  have hb:clause [-s.beta.val,-s.gamma.val]∈D:=by
    rw [h.1,h.2.1];exact hd _ (beta_gamma n hn g hg hs)
  have hg':clause [-s.gamma.val,-s.beta.val]∈D:=by
    rwa [PriorityExclusive.clause_swap (-s.gamma.val) (-s.beta.val)
      (neg_ne_zero.mpr s.gamma.property) (neg_ne_zero.mpr s.beta.property)]
  refine ⟨List.mem_append_left _ hb,List.mem_append_left _ hg',?_,?_⟩
  · apply List.mem_append_right
    simp [rows,exclusionRow,bit,h.1,h.2.2,c]
  · apply List.mem_append_right
    simp [rows,exclusionRow,bit,h.2.1,h.2.2,c]

#print axioms prepare_check
#print axioms all_inputs
end L3Emitter.CategorySourceInputs

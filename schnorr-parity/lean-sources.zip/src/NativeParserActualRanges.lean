import NativeParserStackShapes
namespace L3Emitter.NativeParserActualRanges
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace CanonicalFileGrammar

theorem events (n:Nat) (hn:2≤n)
 (hm:(NativeCompatibleFamily.compiled n).store.next≤CanonicalMachineReference.referenceLimit):
 ∀e∈(NativeCompatibleFamily.commands n).flatMap commandEvents,PinnedCommandReader.Valid e:=by
 have hp:=NativeCompatibleFamily.checked n hn
 have hb:=ActionReferenceBounds.program 0 (RecordedUniformFamily.guard n) _ _
   (initial (NativeRecordedFamily.original n)) id (NativeCompatibleFamily.emitter n)
   (by change 0<_+1;omega) (initial_embeds _) hp
 have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
   (initial (NativeRecordedFamily.original n)) id (NativeCompatibleFamily.emitter n) hp
 rw [←he] at hb
 have hb':ActionReferenceBounds.ProgramBound CanonicalMachineReference.referenceLimit
   (NativeRecordedFamily.original n) (initial (NativeRecordedFamily.original n)) id (NativeCompatibleFamily.emitter n):=
   ActionReferenceBounds.program_mono _ _ _ _ _ _ hm hb
 intro e he
 exact PinnedEventReferences.parser_valid e (NativeCompatibleFamily.valid n hn e he)
   (PinnedEventReferences.program_events _ _ _ _ _ hb' e he)

theorem formula_before_next (n:Nat) (hn:2≤n):
 (NativeRecordedFamily.original n).length<(NativeCompatibleFamily.compiled n).store.next:=by
 have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
   (initial (NativeRecordedFamily.original n)) id (NativeCompatibleFamily.emitter n)
   (NativeCompatibleFamily.checked n hn)
 change (NativeCompatibleFamily.compiled n).store.next=(NativeRecordedFamily.original n).length+1+_ at he
 omega

theorem conclusion_positive (n:Nat) (hn:2≤n):0<NativeCompatibleFamily.conclusion n:=by
 have h := (NativeCompatibleFamily.execution n hn).2
 unfold NativeSparseStore.read NativeReference.resolve NativeReference.normalize at h
 simp only [show ¬(NativeCompatibleFamily.conclusion n:Int)<0 by omega,↓reduceIte] at h
 split at h
 · rename_i hi;omega
 · simp at h

/-- Actual allocation range, independent of the deliberately coarse global
polynomial envelope. It permits sharp finite-size witnesses of nonvacuity. -/
theorem file (names:List Nat) (n:Nat) (hn:2≤n)
 (hm:(NativeCompatibleFamily.compiled n).store.next≤CanonicalMachineReference.referenceLimit):
 PinnedFileOnline.parse names (NativeCompatibleFamily.bytes n)=some (
  (NativeParserEventCoordinates.allocate names ((NativeCompatibleFamily.commands n).flatMap commandEvents)).1,
  ⟨(NativeRecordedFamily.original n).length,
   (NativeCompatibleFamily.commands n).map (PinnedCoordinateChange.command (PinnedCoordinateChange.coordinate
     (NativeParserEventCoordinates.allocate names ((NativeCompatibleFamily.commands n).flatMap commandEvents)).1)),
   NativeCompatibleFamily.conclusion n⟩):=by
 apply PinnedFileOnline.roundtrip _ _ (events n hn hm)
 · exact lt_of_lt_of_le (formula_before_next n hn) hm
 · exact ⟨conclusion_positive n hn,
     lt_of_lt_of_le (CanonicalMachineReference.read_id_below_next _ _ _ (NativeCompatibleFamily.execution n hn).2) hm⟩
#print axioms file
end L3Emitter.NativeParserActualRanges

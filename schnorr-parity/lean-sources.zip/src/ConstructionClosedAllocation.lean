import ConstructionCompleteCount
import ConstructionAllocationEnvelope
namespace L3Emitter.ConstructionClosedAllocation
open EREF EREF.GeneralRED RecordedScopedTrace AuditLocalCosts ConstructionCompleteCount

def formulaBound (n : Nat) :=128*(n+1)^2*2^n
def certificateBound (n : Nat) :=mainBound n*(formulaBound n+mainBound n)
def localTokenBound (n : Nat) :=(704*n+700)*certificateBound n
def allocationBound (n : Nat) :=2*mainBound n+certificateBound n*(704*n+701)

theorem certificates (n : Nat) (hn : 2≤n) : certCount (RecordedUniformFamily.emitter n)≤certificateBound n := by
  have h:=ConstructionAllocationEnvelope.certificates n hn
  have hm:=main n hn
  have hf:=CanonicalFormulaEnvelope.original_rows n
  exact h.trans (Nat.mul_le_mul hm (Nat.add_le_add hf hm))

theorem local_tokens (n : Nat) (hn : 2≤n) : localTokenCount (RecordedUniformFamily.emitter n)≤localTokenBound n := by
  have h:=CanonicalReplayEnvelope.total_tokens (704*n+700) _ (ConstructionFamilyLocalBounds.emitter n hn)
  simpa only [localTokenBound,Nat.mul_comm] using h.trans (Nat.mul_le_mul_right (704*n+700) (certificates n hn))

theorem allocations (n : Nat) (hn : 2≤n) :
    NativeRecordedAllocation.program (RecordedUniformFamily.emitter n)≤allocationBound n := by
  have h:=ConstructionAllocationEnvelope.allocations n hn
  have hm:=main n hn
  have hf:=CanonicalFormulaEnvelope.original_rows n
  exact h.trans (Nat.add_le_add (Nat.mul_le_mul_left 2 hm)
    (Nat.mul_le_mul_right _ (Nat.mul_le_mul hm (Nat.add_le_add hf hm))))

theorem main_in_formula (n : Nat) (hn : 2≤n) :
    (RecordedUniformFamily.emitter n).length≤54016000*(ConstructionFormulaScale.rows n)^8 := by
  have ha:=ConstructionFormulaScale.arity n hn
  have ht:=ConstructionFormulaScale.truth_table n hn
  have hw:n+2≤2*ConstructionFormulaScale.rows n:=by omega
  have hm:=Nat.mul_le_mul (Nat.mul_le_mul_left 422000 (Nat.pow_le_pow_left hw 7)) ht
  exact (main n hn).trans (hm.trans_eq (by ring))

/-- Polynomial in the actual encoded formula row count. Counts allocated rows,
including local subproof rows later deleted. It is not serialized bytes. -/
theorem allocation_in_formula (n : Nat) (hn : 2≤n) :
    NativeRecordedAllocation.program (RecordedUniformFamily.emitter n)≤
      2*54016000*(ConstructionFormulaScale.rows n)^8+
      704*54016000*(ConstructionFormulaScale.rows n)^8*
        (ConstructionFormulaScale.rows n+54016000*(ConstructionFormulaScale.rows n)^8)*ConstructionFormulaScale.rows n :=
  ConstructionAllocationEnvelope.polynomial_allocation n 54016000 8 hn (main_in_formula n hn)

#print axioms certificates
#print axioms local_tokens
#print axioms allocations
#print axioms main_in_formula
#print axioms allocation_in_formula
end L3Emitter.ConstructionClosedAllocation

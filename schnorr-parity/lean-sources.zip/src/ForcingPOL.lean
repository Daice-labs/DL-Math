import BranchChoices
import ClauseTransport
import WeightedChainCompiler

set_option linter.unusedSimpArgs false

/- Fixed POL templates for forcing-port coverage. No RUP search or
   unverified satisfiability solver occurs in these constructors. -/
namespace L3Emitter.ForcingPOL
open EREF EREF.GeneralRED REDWitness ReferenceTransport LocalCombination
open ClauseTransport CaseJoin WeightedChainCompiler

structure Port where
  c : Int
  p : Int
  sel : Int
  force : Int
  e0 : Int
  e1 : Int
  q0 : Int
  q1 : Int

def Port.valid (v : Port) : Prop :=
  Valid [v.c,v.p,v.sel,v.force,v.e0,v.e1,v.q0,v.q1]

def Port.r (v : Port) := clause [-v.p,v.sel]
def Port.rs (v : Port) : List Row := [
  clause [-v.p,v.sel], clause [-v.p,v.force],
  clause [-v.force,v.e0,v.e1],
  clause [-v.c,-v.sel,-v.e0,v.q0],
  clause [-v.c,-v.sel,-v.e1,v.q1]]
def Port.pad (v : Port) := [-v.c,v.q0,v.q0,v.q1,v.q1]
def Port.target (v : Port) := clause [-v.c,-v.p,v.q0,v.q1]
def Port.tokens (D : List Row) (v : Port) :=
  sumTape D v.r v.rs ++ padSteps v.pad ++ [.div 3]

theorem port_identity (v : Port) (hv : v.valid) :
    chain (chain v.r v.rs) (v.pad.map litAxiom)=scaled 3 v.target := by
  have hc : v.c≠0 := hv _ (by simp)
  have hp : v.p≠0 := hv _ (by simp)
  have hs : v.sel≠0 := hv _ (by simp)
  have hf : v.force≠0 := hv _ (by simp)
  have h0 : v.e0≠0 := hv _ (by simp)
  have h1 : v.e1≠0 := hv _ (by simp)
  have hq0 : v.q0≠0 := hv _ (by simp)
  have hq1 : v.q1≠0 := hv _ (by simp)
  apply canonical_ext _ _
    (chain_canonical _ _ (chain_canonical _ _ (canonical_normalize _ _)))
    (canonical_scaled 3 (by decide) _ (canonical_normalize _ _))
  intro α
  simp only [Port.r,Port.rs,Port.pad,Port.target,chain,List.map_cons,List.map_nil]
  have hcl (xs : List Int) : Canonical (clause xs) := canonical_normalize _ _
  simp only [val_add,canonical_add,canonical_normalize,canonical_litAxiom,hcl,val_scaled]
  simp [clause,val_normalize,tvalZ,val_litAxiom,hc,hp,hs,hf,h0,h1,hq0,hq1,
    sum,litVal_neg]
  <;> ring

theorem port_succeeds (D : List Row) (v : Port) (hv : v.valid)
    (hr : v.r∈D) (hrs : ∀r∈v.rs,r∈D) :
    polEval (dbOf D) (v.tokens D) []=some v.target := by
  have hp : Valid v.pad := by
    intro l hl
    have hc := hv v.c (by simp); have h0 := hv v.q0 (by simp); have h1 := hv v.q1 (by simp)
    simp only [Port.pad,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with rfl|rfl|rfl|rfl|rfl <;> omega
  unfold Port.tokens sumTape
  simp only [List.append_assoc,List.cons_append,List.nil_append,polEval,locate_correct D _ hr]
  rw [steps_eval D v.rs hrs, padSteps_eval _ _ hp,port_identity v hv]
  simp only [polEval,show 0<3 by decide,↓reduceIte]
  rw [divide_scaled 3 (by decide) v.target (canonical_normalize _ _)]

theorem port_token_count (D : List Row) (v : Port) : (v.tokens D).length=22 := by
  simp [Port.tokens,sumTape,steps,Port.rs,padSteps,Port.pad]

structure Gate where
  c : Int
  consumer : Int
  p0 : Int
  p1 : Int
  q00 : Int
  q01 : Int
  q10 : Int
  q11 : Int

def Gate.valid (v : Gate) : Prop :=
  Valid [v.c,v.consumer,v.p0,v.p1,v.q00,v.q01,v.q10,v.q11]
def Gate.r (v : Gate) := clause [-v.c,v.consumer]
def Gate.rs (v : Gate) : List Row := [
  clause [-v.consumer,v.p0,v.p1],
  clause [-v.c,-v.p0,v.q00,v.q01],
  clause [-v.c,-v.p1,v.q10,v.q11]]
def Gate.qs (v : Gate) := [v.q00,v.q01,v.q10,v.q11]
def Gate.pad (v : Gate) := v.qs++v.qs
def Gate.target (v : Gate) := clause (-v.c::v.qs)
def Gate.tokens (D : List Row) (v : Gate) :=
  sumTape D v.r v.rs ++ padSteps v.pad ++ [.div 3]

theorem gate_identity (v : Gate) (hv : v.valid) :
    chain (chain v.r v.rs) (v.pad.map litAxiom)=scaled 3 v.target := by
  have hc : v.c≠0 := hv _ (by simp)
  have hb : v.consumer≠0 := hv _ (by simp)
  have hp0 : v.p0≠0 := hv _ (by simp)
  have hp1 : v.p1≠0 := hv _ (by simp)
  have h00 : v.q00≠0 := hv _ (by simp)
  have h01 : v.q01≠0 := hv _ (by simp)
  have h10 : v.q10≠0 := hv _ (by simp)
  have h11 : v.q11≠0 := hv _ (by simp)
  apply canonical_ext _ _
    (chain_canonical _ _ (chain_canonical _ _ (canonical_normalize _ _)))
    (canonical_scaled 3 (by decide) _ (canonical_normalize _ _))
  intro α
  simp only [Gate.r,Gate.rs,Gate.pad,Gate.qs,Gate.target,List.cons_append,List.nil_append,
    chain,List.map_cons,List.map_nil]
  have hcl (xs : List Int) : Canonical (clause xs) := canonical_normalize _ _
  simp only [val_add,canonical_add,canonical_normalize,canonical_litAxiom,hcl,val_scaled]
  simp [clause,val_normalize,tvalZ,val_litAxiom,hc,hb,hp0,hp1,h00,h01,h10,h11,
    sum,litVal_neg]
  <;> ring

theorem gate_succeeds (D : List Row) (v : Gate) (hv : v.valid)
    (hr : v.r∈D) (hrs : ∀r∈v.rs,r∈D) :
    polEval (dbOf D) (v.tokens D) []=some v.target := by
  have hp : Valid v.pad := by
    intro l hl
    have h00 := hv v.q00 (by simp); have h01 := hv v.q01 (by simp)
    have h10 := hv v.q10 (by simp); have h11 := hv v.q11 (by simp)
    simp only [Gate.pad,Gate.qs,List.mem_append,List.mem_cons,List.not_mem_nil,or_false] at hl
    rcases hl with (rfl|rfl|rfl|rfl)|(rfl|rfl|rfl|rfl) <;> assumption
  unfold Gate.tokens sumTape
  simp only [List.append_assoc,List.cons_append,List.nil_append,polEval,locate_correct D _ hr]
  rw [steps_eval D v.rs hrs,padSteps_eval _ _ hp,gate_identity v hv]
  simp only [polEval,show 0<3 by decide,↓reduceIte]
  rw [divide_scaled 3 (by decide) v.target (canonical_normalize _ _)]

theorem gate_token_count (D : List Row) (v : Gate) : (v.tokens D).length=24 := by
  simp [Gate.tokens,sumTape,steps,Gate.rs,padSteps,Gate.pad,Gate.qs]

#print axioms port_succeeds
#print axioms gate_succeeds
end L3Emitter.ForcingPOL

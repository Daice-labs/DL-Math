import GammaPreservation
namespace L3Emitter.GammaPreservationBoth
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
abbrev Job:=BetaPort.Job
def conclusion (n:Nat) (hn:2≤n) (j:Job n) (u v:Bool) (frame:List Int):List Int:=
  [-BetaAliasValue.choice j]++frame++[-GammaPreservation.out n hn j u v,GammaPreservation.target n hn j v]
def rows (n:Nat) (hn:2≤n) (j:Job n) (u v:Bool) (frame:List Int):=
  GammaPreservation.rows n hn j u false v frame++GammaPreservation.rows n hn j u true v frame++[clause (conclusion n hn j u v frame)]
def program (n:Nat) (hn:2≤n) (j:Job n) (u v:Bool) (frame:List Int) (D:List Row):=
  GammaPreservation.program n hn j u false v frame D++
  GammaPreservation.program n hn j u true v frame (D++GammaPreservation.rows n hn j u false v frame)++
  [(clause (conclusion n hn j u v frame),GammaValueJoin.joinTape
    (D++GammaPreservation.rows n hn j u false v frame++GammaPreservation.rows n hn j u true v frame)
    (conclusion n hn j u v frame) (GammaChoiceBank.hit n hn j.1))]

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (u v:Bool) (frame:List Int) (hf:Valid frame)
    (D:List Row) (hd:∀R∈GammaComparisonBank.result n hn,R∈D)
    (hi:∀side b,GammaPreservation.hypothesis n hn j u side b frame∈D):
    check D (program n hn j u v frame D)=some (D++rows n hn j u v frame):=by
  have h0:=GammaPreservation.checks n hn j hj u false v frame hf D hd (hi false)
  have h1:=GammaPreservation.checks n hn j hj u true v frame hf (D++GammaPreservation.rows n hn j u false v frame)
    (fun R h=>List.mem_append_left _ (hd R h)) (fun b=>List.mem_append_left _ (hi true b))
  let E:=D++GammaPreservation.rows n hn j u false v frame++GammaPreservation.rows n hn j u true v frame
  have hc:=BetaAliasValue.choice_valid n hn j hj
  have vg:Valid (conclusion n hn j u v frame):=EvaluationCaseSeeds.valid_join
    (EvaluationCaseSeeds.valid_join (by simp [Valid,hc]) hf)
    (by simp [GammaPreservation.out,GammaPreservation.target,Valid,sign_valid])
  have he:∀side,clause (conclusion n hn j u v frame++[-sign side (GammaChoiceBank.hit n hn j.1)])=
      clause (GammaPreservation.guards n hn j side frame++[-GammaPreservation.out n hn j u v,GammaPreservation.target n hn j v]):=by
    intro side
    apply ProjectionTrace.clause_perm _ _ (EvaluationCaseSeeds.valid_join vg (by simp [Valid,sign_valid]))
      (EvaluationCaseSeeds.valid_join (GammaPreservation.valid_guards n hn j hj side frame hf)
        (by simp [GammaPreservation.out,GammaPreservation.target,Valid,sign_valid]))
    apply List.perm_iff_count.mpr
    intro z;simp only [conclusion,GammaPreservation.guards,List.count_append,List.count_cons,List.count_nil];omega
  have hm:∀side,clause (conclusion n hn j u v frame++[-sign side (GammaChoiceBank.hit n hn j.1)])∈E:=by
    intro side;rw [he side];cases side
    · exact List.mem_append_left _ (List.mem_append_right _ (GammaPreservation.conclusion_present n hn j u false v frame))
    · exact List.mem_append_right _ (GammaPreservation.conclusion_present n hn j u true v frame)
  have ht:=GammaValueJoin.binary E (conclusion n hn j u v frame) (GammaChoiceBank.hit n hn j.1) vg
    (by simpa [sign] using hm false) (by simpa [sign] using hm true)
  have hl:check E [(clause (conclusion n hn j u v frame),GammaValueJoin.joinTape E (conclusion n hn j u v frame) (GammaChoiceBank.hit n hn j.1))]=
      some (E++[clause (conclusion n hn j u v frame)]):=by simp only [check,ht,↓reduceIte]
  have hh:=check_append _ _ _ _ _ h0 h1
  simpa only [E,program,rows,List.append_assoc] using check_append _ _ _ _ _ hh hl

theorem command_count (n:Nat) (hn:2≤n) (j:Job n) (u v:Bool) (frame:List Int) (D:List Row):
    (program n hn j u v frame D).length=23:=by
  simp [program,GammaPreservation.command_count]
#print axioms checks
#print axioms command_count
end L3Emitter.GammaPreservationBoth

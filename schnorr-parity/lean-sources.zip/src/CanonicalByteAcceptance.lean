import CanonicalWholeFile
import CanonicalCompiledValidity

namespace L3Emitter.CanonicalByteAcceptance
open EREF NativeSparseStore CanonicalByteFraming CanonicalLineParser CanonicalLineEncoding
open CanonicalFileGrammar

/-- Whole-file parsing now has no lexical-validity hypothesis: it is discharged
from the checked recursive emitter for every arity at least two. -/
theorem family_readback (n : Nat) (hn : 2≤n) :
    CanonicalWholeFile.parse (CanonicalScopedBytes.familyBytes n)=some (CanonicalWholeFile.family n) :=
  CanonicalWholeFile.family_roundtrip_of_valid n (CanonicalCompiledValidity.family_valid n hn)

def formulaLines (D : List Row) := D.map (fun R=>emit (CanonicalScopedBytes.rowDoc R)++ascii " ;")
def formulaReadLines : List Bytes→Option (List Row)
  | []=>some []
  | l::ls=>do
    let middle←strip [] (ascii " ;") l
    let R←readRow middle
    let D←formulaReadLines ls
    return R::D

def formulaParse (bs : Bytes) : Option (List Row) :=
  match (fileLines bs).reverse with
  | []::ls=>formulaReadLines ls.reverse
  | _=>none

theorem formula_lines_roundtrip (D : List Row) (hc : ∀R∈D,Canonical R) :
    formulaReadLines (formulaLines D)=some D := by
  induction D with
  | nil=>rfl
  | cons R D ih=>
    have hh:=hc R (by simp)
    have ht:=ih (by intro R hR;exact hc R (by simp [hR]))
    simp only [formulaLines,List.map_cons,formulaReadLines]
    rw [show strip [] (ascii " ;") (emit (CanonicalScopedBytes.rowDoc R)++ascii " ;")=
      some (emit (CanonicalScopedBytes.rowDoc R)) by exact strip_roundtrip [] _ _]
    simp only [bind,Option.bind,read_row R hh]
    change (formulaReadLines (formulaLines D)).bind (fun D=>some (R::D))=some (R::D)
    rw [ht]
    rfl

theorem formula_lines_bytes (D : List Row) :
    joinLines (formulaLines D)=emit (CanonicalFormulaReadback.formulaDoc D) := by
  induction D with
  | nil=>rfl
  | cons R D ih=>
    change (emit (CanonicalScopedBytes.rowDoc R)++ascii " ;"++[10])++joinLines (formulaLines D)=_
    rw [ih]
    simp only [CanonicalFormulaReadback.formulaDoc,List.flatMap_cons,emit_append,emit_fixed]
    rw [show ascii " ;\n"=ascii " ;"++[10] by decide]
    simp only [List.append_assoc]

theorem formula_readback (D : List Row) (hc : ∀R∈D,Canonical R) :
    formulaParse (emit (CanonicalFormulaReadback.formulaDoc D))=some D := by
  rw [←formula_lines_bytes,formulaParse,split_lines]
  · simp only [List.reverse_append,List.reverse_cons,List.reverse_nil,List.nil_append,
      List.singleton_append,List.reverse_reverse]
    exact formula_lines_roundtrip D hc
  · intro l hl
    obtain ⟨R,hR,rfl⟩:=List.mem_map.mp hl
    simp only [List.mem_append,not_or]
    exact ⟨row_avoids (CanonicalScopedBytes.pbRow R) 10 (Or.inl rfl),by decide⟩

/-- Executable byte checker for the formal strict scope calculus. This theorem
is deliberately not named native acceptance: the pinned Rust implementation
refinement and machine bounds remain separate obligations. -/
def check (formula proof : Bytes) : Bool :=
  match formulaParse formula,CanonicalWholeFile.parse proof with
  | some D,some f=>
    if f.formulaRows≠D.length then false else
    match CanonicalScopeKernel.run D (initial D) id f.commands with
    | none=>false
    | some s=>match read s (f.conclusion:Int) with
      | some R=>decide ((R.total:Int)<R.bound)
      | none=>false
  | _,_=>false

theorem family_accepted (n : Nat) (hn : 2≤n) :
    check (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n)))
      (CanonicalScopedBytes.familyBytes n)=true := by
  have hf:=formula_readback (NativeRecordedFamily.original n) (OriginalEncoding.rows_canonical n (3*n-4))
  rw [check,hf,family_readback n hn]
  simp only [CanonicalWholeFile.family,ne_eq,not_true_eq_false,↓reduceIte]
  simp only [(CanonicalWireFamily.family_execution n hn).1,(CanonicalWireFamily.family_execution n hn).2]
  rfl

#print axioms family_readback
#print axioms formula_readback
#print axioms family_accepted
end L3Emitter.CanonicalByteAcceptance

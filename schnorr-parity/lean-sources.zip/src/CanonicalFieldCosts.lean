import CanonicalWireFamily

namespace L3Emitter.CanonicalFieldCosts
open EREF TemplateBytes CanonicalScopedBytes

def integerBytes (z : Int) := (if z<0 then 1 else 0)+digits z.natAbs
def termBytes (t : Nat×Int) := digits t.1+1+literalBytes t.2
def rowBytes (R : EREF.Row) := (R.terms.map termBytes).sum+(R.terms.length-1)+4+integerBytes R.bound

def literalCost (l : Literal) := (if l.negative then 2 else 1)+digits l.varId
def imageCost : L3Emitter.Image→Nat | .bit _=>1 | .lit l=>literalCost l
def entryCost (p : Nat×L3Emitter.Image) := 5+digits p.1+imageCost p.2
def witnessBytes (w : FiniteWitness.Data) := (w.map entryCost).sum+(w.length-1)

theorem separated_exact (ds : List Doc) :
    exactBytes (separated (fixed " ") ds)=(ds.map exactBytes).sum+(ds.length-1) := by
  cases ds with
  | nil=>rfl
  | cons d ds=>
    rw [separated_bytes]
    simp only [List.map_cons,List.sum_cons,List.length_cons,TemplateBytes.fixed_bytes]
    change _+_+ds.length*1=_
    omega

theorem integer_exact (z : Int) : exactBytes (integer z)=integerBytes z := by
  unfold integer integerBytes
  split <;> simp only [exactBytes_append,TemplateBytes.fixed_bytes,TemplateBytes.number_bytes,Nat.zero_add] <;> rfl

theorem term_exact (t : Nat×Int) :
    exactBytes (number t.1++fixed " "++literal (signedLiteral t.2))=termBytes t := by
  simp only [exactBytes_append,TemplateBytes.number_bytes,TemplateBytes.fixed_bytes,literal_bytes]
  rfl

/-- Exact serialized row BYTES: all coefficients, variable signs/IDs,
separators, inequality symbol and the signed RHS. -/
theorem row_exact (R : EREF.Row) : exactBytes (rowDoc R)=rowBytes R := by
  simp only [rowDoc,pbRow,row,exactBytes_append,separated_exact,List.map_map,Function.comp_def,
    TemplateBytes.number_bytes,literal_bytes,List.length_map,TemplateBytes.fixed_bytes,integer_exact]
  rfl

theorem literal_exact (l : Literal) : exactBytes (literal l)=literalCost l := by
  cases l with
  | mk n b=>cases b <;> rfl

theorem image_exact (v : L3Emitter.Image) : exactBytes (image v)=imageCost v := by
  cases v with
  | lit l=>exact literal_exact l
  | bit b=>cases b <;> rfl

theorem entry_exact (p : Nat×L3Emitter.Image) :
    exactBytes (literal ⟨p.1,false⟩++fixed " -> "++image p.2)=entryCost p := by
  simp only [exactBytes_append,literal_exact,TemplateBytes.fixed_bytes,image_exact]
  change (1+digits p.1)+4+imageCost p.2=5+digits p.1+imageCost p.2
  omega

theorem witness_exact (w : FiniteWitness.Data) : exactBytes (witness w)=witnessBytes w := by
  simp only [witness,separated_exact,List.map_map,Function.comp_def,entry_exact,List.length_map]
  rfl

/-- No row or witness is hidden in an unexplained byte statistic. -/
theorem red_exact (ids : Nat→Nat) (R : EREF.Row) (w : FiniteWitness.Data)
    (bs : List (EREF.Row×NativeScopedLocalGoal.Built)) :
    (emit (actionDoc ids (.red R w bs))).length=
      25+rowBytes R+witnessBytes w+goalsCost ids 0 bs := by
  rw [emit_length,action_exact]
  simp only [actionCost,row_exact,witness_exact]

theorem consequence_exact (ids : Nat→Nat) (R : EREF.Row) (b : NativeScopedLocalGoal.Built) :
    (emit (actionDoc ids (.consequence R b))).length=
      25+rowBytes R+tapesCost b.tapes+digits b.conclusion := by
  rw [emit_length,action_exact]
  simp only [actionCost,row_exact]

#print axioms separated_exact
#print axioms integer_exact
#print axioms row_exact
#print axioms witness_exact
#print axioms red_exact
#print axioms consequence_exact
end L3Emitter.CanonicalFieldCosts

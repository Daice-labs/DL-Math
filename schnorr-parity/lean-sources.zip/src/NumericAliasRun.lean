import NumericAliasConfig
namespace L3Emitter.NumericNetwork
open EREF EREF.GeneralRED AliasNetwork RecursiveAliases
variable {base:List Row}

def VectorBound (M:Nat) {w:Nat} (a:AliasBits w):Prop:=∀i,BitBound M (a i)
def SourceBound (M:Nat) {w:Nat} (a:Nat→AliasBits w):Prop:=∀j,VectorBound M (a j)

theorem vector_mono {M N w:Nat} (h:M≤N) (a:AliasBits w) (ha:VectorBound M a):
    VectorBound N a:=fun i=>(ha i).trans h

theorem source_mono {M N w:Nat} (h:M≤N) (a:Nat→AliasBits w) (ha:SourceBound M a):
    SourceBound N a:=fun j=>vector_mono h (a j) (ha j)

theorem port (M k g w:Nat) (sel:Nat→Bit) (as:Nat→AliasBits w)
    (hs:∀j,j<k+g→BitBound M (sel j)) (ha:SourceBound M as)
    (z:Net base) (hz:CanonicalTrace.ceiling z.rows≤M):
    VectorBound (M+(w+2)*(k+g+1)) (AliasNetwork.port k g sel as z).1 ∧
    CanonicalTrace.ceiling (AliasNetwork.port k g sel as z).2.rows≤M+(w+2)*(k+g+1):=by
  apply tabulate M (k+g+1) (w+2) _ ?_ M (by omega) z hz
  intro i N hN u hu
  have h:=select N u ((List.range (k+g)).map (fun j=>(sel j,as j i))) hu (by
    intro p hp
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hp
    exact ⟨(hs j (List.mem_range.mp hj)).trans hN,(ha j i).trans hN⟩)
  simpa only [List.length_map,List.length_range,Nat.add_assoc] using h

theorem step (M G w:Nat) (c:Config Bit) (g:Nat) (hg:g<G)
    (hc:ConfigBound M G w c) (as:Nat→AliasBits w) (ha:SourceBound M as)
    (z:Net base) (hz:CanonicalTrace.ceiling z.rows≤M):
    VectorBound (M+(w+2)*(2*(c.k+g+1)+25)) (RecursiveAliases.step c as g z).1 ∧
    CanonicalTrace.ceiling (RecursiveAliases.step c as g z).2.rows≤M+(w+2)*(2*(c.k+g+1)+25):=by
  let d:=(w+2)*(c.k+g+1)
  let l:=AliasNetwork.port c.k g (c.sel g 0) as z
  let r:=AliasNetwork.port c.k g (c.sel g 1) as l.2
  have hl:=port M c.k g w (c.sel g 0) as (hc.sel g hg 0 (by omega)) ha z hz
  have hr:=port (M+d) c.k g w (c.sel g 1) as
    (fun j hj=>(hc.sel g hg 1 (by omega) j hj).trans (by omega))
    (source_mono (by omega) as ha) l.2 hl.2
  have ht:=tabulate (M+d+d) 25 (w+2) (fun i=>(coordinate c g l.1 r.1 i).compile) (by
    intro i N hN u hu
    have he:=coordinate_bound N G w c g hg (config_mono (by omega) hc)
      l.1 r.1 (vector_mono (by omega) l.1 hl.1) (vector_mono hN r.1 hr.1) i
    have h:=compile _ N u he hu
    exact result_mono (Nat.add_le_add_left (coordinate_cost c g l.1 r.1 i) N) _ h)
    (M+d+d) (by omega) r.2 hr.2
  have heq:M+d+d+(w+2)*25=M+(w+2)*(2*(c.k+g+1)+25):=by dsimp[d];ring
  rw [heq] at ht
  exact ht

theorem run (M G w:Nat) (c:Config Bit) (g m:Nat) (hg:g+m≤G)
    (hc:ConfigBound M G w c) (as:Nat→AliasBits w) (ha:SourceBound M as)
    (z:Net base) (hz:CanonicalTrace.ceiling z.rows≤M):
    SourceBound (M+m*((w+2)*(2*(c.k+g+m)+25))) (RecursiveAliases.run c as g m z).1 ∧
    CanonicalTrace.ceiling (RecursiveAliases.run c as g m z).2.rows≤M+m*((w+2)*(2*(c.k+g+m)+25)):=by
  induction m generalizing M g as z with
  | zero=>simpa only [Nat.zero_mul,Nat.add_zero] using And.intro ha hz
  | succ m ih=>
    let d:=(w+2)*(2*(c.k+g+1)+25)
    let a:=RecursiveAliases.step c as g z
    have hs:=step M G w c g (by omega) hc as ha z hz
    have hu:SourceBound (M+d) (Function.update as (c.k+g) a.1):=by
      intro j
      by_cases hj:j=c.k+g
      · subst j;simpa using hs.1
      · simpa [Function.update_of_ne hj] using (source_mono (by omega : M≤M+d) as ha j)
    have ht:=ih (M+d) (g+1) (by omega) (config_mono (by omega) hc)
      (Function.update as (c.k+g) a.1) hu a.2 hs.2
    have he:M+d+m*((w+2)*(2*(c.k+(g+1)+m)+25))≤
        M+(m+1)*((w+2)*(2*(c.k+g+(m+1))+25)):=by
      have hd:d≤(w+2)*(2*(c.k+g+(m+1))+25):=Nat.mul_le_mul_left _ (by omega)
      have he:c.k+(g+1)+m=c.k+g+(m+1):=by omega
      rw[he];nlinarith
    exact ⟨source_mono he _ ht.1,ht.2.trans he⟩

#print axioms port
#print axioms step
#print axioms run
end L3Emitter.NumericNetwork

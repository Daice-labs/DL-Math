import L3BranchBank

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

/-- All rows of the branch chain are the actual live/eligible/successor/B
    definition rows at this point of the frontend. -/
theorem branch_from_database (hk : 1≤F.k) (hs : 1≤F.s)
    (t : StI F.V) (ht : F.Good3 t) (b B : Nat) (brs : List Int)
    (hb : 1≤b) (hbS : b<F.s-1) (hB : 1≤B)
    (hBor : Cmd.orDef B brs∈t.s.cmds)
    (hr : ∀g,b<g → g<F.s → F.BranchRecord b g t brs) :
    Refutation (exec F.db5 t.s.cmds ++ [negate (clauseRow [(B:Int),-(t.s.eligible b:Int)]).toE]) := by
  classical
  let xs := List.range' (b+1) (F.s-1-b)
  have records : ∀g∈xs,∃q r, Cmd.orDef q [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)]∈t.s.cmds ∧
      Cmd.andDef r [(t.s.eligible b:Int),(q:Int)]∈t.s.cmds ∧ (r:Int)∈brs ∧
      1≤q ∧ q≤t.s.var ∧ 1≤r ∧ r≤t.s.var := by
    intro g hg
    have hh := List.mem_range'_1.mp hg
    exact hr g (by omega) (by omega)
  let q : Nat→Nat := fun g => if h:g∈xs then Classical.choose (records g h) else 1
  let r : Nat→Nat := fun g => if h:g∈xs then Classical.choose (Classical.choose_spec (records g h)) else 1
  have hrec : ∀g∈xs, Cmd.orDef (q g) [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)]∈t.s.cmds ∧
      Cmd.andDef (r g) [(t.s.eligible b:Int),(q g:Int)]∈t.s.cmds ∧ (r g:Int)∈brs ∧
      1≤q g ∧ q g≤t.s.var ∧ 1≤r g ∧ r g≤t.s.var := by
    intro g hg
    simpa only [q,r,dif_pos hg] using Classical.choose_spec (Classical.choose_spec (records g hg))
  have hl := (ht.2.1 b hbS).1
  obtain ⟨cons,hcons,helig,hcL,heL,heU⟩ := ht.2.2.2.1 b hb (by omega)
  apply branch_cover_chain _
    (exec_bounded F.db5 F.V t.s.cmds (F.db5_bounded hk hs) t.inv.1).canonical B (t.s.eligible b)
    (t.s.live b) xs (fun g => t.s.edges b g 0) (fun g => t.s.edges b g 1) q r hB (by omega) (by have := hl.2.1; omega)
  · intro g hg
    have hh := List.mem_range'_1.mp hg
    have h0 : F.PEdge b g 0 t := (ht.2.1 b hbS).2 (g,0) ((F.mem_edgePairs b (g,0)).mpr ⟨hh.1,by omega,by simp⟩)
    have h1 : F.PEdge b g 1 t := (ht.2.1 b hbS).2 (g,1) ((F.mem_edgePairs b (g,1)).mpr ⟨hh.1,by omega,by simp⟩)
    have h0b := h0.2.1; have h1b := h1.2.1
    have rr := hrec g hg
    exact ⟨by omega,by omega,rr.2.2.2.1,rr.2.2.2.2.2.1⟩
  · apply All.of_mem
    intro z hz
    obtain ⟨g,hg,hz⟩ := List.mem_flatMap.mp hz
    obtain ⟨hq,hr,hmem,_⟩ := hrec g hg
    have hq0 := orDef_row_up F.db5 t.s.cmds _ _ hq (t.s.edges b g 0:Int) (by simp)
    have hq1 := orDef_row_up F.db5 t.s.cmds _ _ hq (t.s.edges b g 1:Int) (by simp)
    have hr0 := andDef_row_up F.db5 t.s.cmds _ _ hr
    have hB0 := orDef_row_up F.db5 t.s.cmds _ _ hBor (r g:Int) hmem
    simp only [branchPacket,List.mem_cons,List.not_mem_nil,or_false] at hz
    rcases hz with rfl | rfl | rfl | rfl | rfl | rfl
    · exact hq0
    · exact hq1
    · exact hr0
    · exact hr0
    · exact hB0
    · exact hB0
  · have h := orDef_row_down F.db5 t.s.cmds _ _ hl.1
    have heq : (F.edgePairs b).map (fun hp => (t.s.edges b hp.1 hp.2:Int)) =
        xs.flatMap (fun g => [(t.s.edges b g 0:Int),(t.s.edges b g 1:Int)]) := by
      simp [edgePairs,xs,List.map_flatMap]
    simp only [edgeTerms] at h
    rw [heq] at h
    exact h
  · exact andDef_row_down F.db5 t.s.cmds _ _ helig (t.s.live b:Int) (by simp)

#print axioms branch_from_database
end L3.Fam

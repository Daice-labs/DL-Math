import PortValueBounds
import SharedValueBank
namespace L3Emitter.GammaInductiveBounds
open EREF AliasProgram PolTapeBytes PrioritySize AliasNetwork
abbrev Job:=BetaPort.Job

theorem source_tokens (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (D:List Row):
    tokensCount (GammaEarlierPorts.sourceProgram n hn j i D)=34:=by
  simp [GammaEarlierPorts.sourceProgram,tokensCount,GammaSourcePorts.firstTape,GammaSourcePorts.tape,CommonGuardResolve.token_count]
theorem source_commands (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (D:List Row):
    (GammaEarlierPorts.sourceProgram n hn j i D).length=3:=by
  simp [GammaEarlierPorts.sourceProgram]

theorem one_tokens (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (z:Bool×Bool) (D:List Row):
    tokensCount (GammaEarlierPorts.one n hn j i t u z D)≤52*(n+1+GammaCofactorValue.g j)+18:=by
  have h:=PortValueBounds.port_tokens n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2 D
  simp only [tokensCount] at h
  simp only [GammaEarlierPorts.one,tokensCount,List.map_append,List.sum_append,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
    GammaPortHypotheses.tape,CommonGuardResolve.token_count,GammaPortHypotheses.H,GammaPortHypotheses.Q,List.length_cons,List.length_nil]
  omega
theorem one_commands (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (z:Bool×Bool) (D:List Row):
    (GammaEarlierPorts.one n hn j i t u z D).length≤3*(n+1+GammaCofactorValue.g j)+2:=by
  have h:=PortValueBounds.port_commands n hn (GammaCofactorValue.g j) (if z.1 then 1 else 0) j.2 i t u z.2 D
  simp only [GammaEarlierPorts.one,List.length_append,List.length_singleton];omega

theorem run_tokens (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (D:List Row) (zs:List (Bool×Bool)):
    tokensCount (GammaEarlierPorts.run n hn j i t u D zs)≤(52*(n+1+GammaCofactorValue.g j)+18)*zs.length:=by
  induction zs generalizing D with
  | nil=>simp [GammaEarlierPorts.run,tokensCount]
  | cons z zs ih=>
    have h0:=one_tokens n hn j i t u z D
    have h1:=ih (D++GammaEarlierPorts.oneRows n hn j i t u z)
    simp only [GammaEarlierPorts.run,tokens_append,List.length_cons,Nat.mul_add,Nat.mul_one] at *
    omega
theorem run_commands (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (D:List Row) (zs:List (Bool×Bool)):
    (GammaEarlierPorts.run n hn j i t u D zs).length≤(3*(n+1+GammaCofactorValue.g j)+2)*zs.length:=by
  induction zs generalizing D with
  | nil=>simp [GammaEarlierPorts.run]
  | cons z zs ih=>
    have h0:=one_commands n hn j i t u z D
    have h1:=ih (D++GammaEarlierPorts.oneRows n hn j i t u z)
    simp only [GammaEarlierPorts.run,List.length_append,List.length_cons,Nat.mul_add,Nat.mul_one] at *
    omega

theorem tokens (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u v:Bool) (D:List Row):
    tokensCount (GammaInductiveStep.program n hn j i t u v D)≤832*n+254:=by
  have h:=run_tokens n hn j i t u (D++GammaEarlierPorts.sourceRows n hn j i) GammaInductiveStep.pairs
  have hs:=j.1.2.parent.gamma_lt
  change GammaCofactorValue.g j<3*(n+1)-4 at hs
  simp only [GammaInductiveStep.pairs,List.length_cons,List.length_nil] at h
  simp only [GammaInductiveStep.program,GammaInductiveStep.pre,tokens_append,source_tokens,GammaPreservationBytes.both_tokens,
    GammaPortHypotheses.frame,GammaInductiveStep.pairs,List.length_cons,List.length_nil]
  omega
theorem commands (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u v:Bool) (D:List Row):
    (GammaInductiveStep.program n hn j i t u v D).length≤48*n+34:=by
  have h:=run_commands n hn j i t u (D++GammaEarlierPorts.sourceRows n hn j i) GammaInductiveStep.pairs
  have hs:=j.1.2.parent.gamma_lt
  change GammaCofactorValue.g j<3*(n+1)-4 at hs
  simp only [GammaInductiveStep.pairs,List.length_cons,List.length_nil] at h
  simp only [GammaInductiveStep.program,GammaInductiveStep.pre,List.length_append,source_commands,GammaPreservationBoth.command_count,GammaInductiveStep.pairs]
  omega

-- Actual serialized bound for this entire gamma step, conditional on operand
-- ceiling M. This is not the full emitter recurrence or an M(n) theorem.
theorem bytes (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u v:Bool) (D:List Row) (M:Nat)
    (hb:∀cmd∈GammaInductiveStep.program n hn j i t u v D,∀z∈cmd.2,Bounded M z):
    (emit (document (GammaInductiveStep.program n hn j i t u v D))).length≤
      7*(48*n+34)+(832*n+254)*(3+digits M):=by
  exact (document_bound M _ hb).trans (Nat.add_le_add
    (Nat.mul_le_mul_left 7 (commands n hn j i t u v D))
    (Nat.mul_le_mul_right _ (tokens n hn j i t u v D)))
#print axioms tokens
#print axioms commands
#print axioms bytes
end L3Emitter.GammaInductiveBounds

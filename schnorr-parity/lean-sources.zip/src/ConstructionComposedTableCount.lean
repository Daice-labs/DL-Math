import ConstructionGlobalCount

namespace L3Emitter.ConstructionComposedTableCount
open EREF EREF.GeneralRED AliasNetwork AliasProgram ConstructionCountTools ConstructionRelationCount
open ConstructionAliasCount

theorem lookup_mass {base : List Row} (f : Bool→Bool→Bit) (a b : Bit) (z : Net base) :
    mass (LookupEvaluation.result f a b z).2.gates≤mass z.gates+27 := by
  have h0:=ConstructionAliasCount.mux_cost b (f true true) (f true false) z
  have h1:=ConstructionAliasCount.mux_cost b (f false true) (f false false) (LookupEvaluation.top f b z).2
  have h2:=ConstructionAliasCount.mux_cost a (LookupEvaluation.top f b z).1 (LookupEvaluation.bottom f b z).1
    (LookupEvaluation.bottom f b z).2
  change mass (LookupEvaluation.top f b z).2.gates≤_ at h0
  change mass (LookupEvaluation.bottom f b z).2.gates≤_ at h1
  change mass (LookupEvaluation.result f a b z).2.gates≤_ at h2
  omega

theorem run_mass {base : List Row} (n : Nat) (hn : 2≤n) (js : List ComposedTableBank.Job) (z : Net base) :
    mass (ComposedTableBank.run n hn z js).1.gates≤mass z.gates+27*js.length := by
  induction js generalizing z with
  | nil=>simp [ComposedTableBank.run]
  | cons j js ih=>
    have h0:=lookup_mass (ComposedTableBank.originalFunction n j.1)
      (ComposedTableBank.unary n hn j.1 0 j.2.1) (ComposedTableBank.unary n hn j.1 1 j.2.2) z
    have h1:=ih (ComposedTableBank.entry n hn j z).2
    change mass (ComposedTableBank.entry n hn j z).2.gates≤_ at h0
    simp only [ComposedTableBank.run,List.length_cons]
    omega

theorem jobs (n : Nat) : (ComposedTableBank.jobs n).length=(3*(n+1)-5)*4 := by
  unfold ComposedTableBank.jobs
  rw [flat_exact _ _ 4 (by intro g hg;rfl),gates]

theorem definitions (n : Nat) (hn : 2≤n) :
    (RecordedNetwork.program (ComposedTableBank.base n hn) (ComposedTableBank.built n hn).1.gates).length≤324*(n+1) := by
  rw [ConstructionAliasBankCount.network_rows]
  have h:=run_mass n hn (ComposedTableBank.jobs n) (initial _ (ComposedTableBank.base_canonical n hn))
  change mass (ComposedTableBank.built n hn).1.gates≤0+27*(ComposedTableBank.jobs n).length at h
  rw [jobs] at h
  exact h.trans (by omega)

theorem leaf {base : List Row} (f : Bool→Bool→Bit) (a b : Bit) (va vb v : Bool) (z : Net base) (D : List Row) :
    (LookupEvaluation.program f a b va vb v z D).length≤12 := by
  have h0:=PrunedMuxEvaluation.count (LookupEvaluation.innerJob f b va z) vb (.leaf (f va vb) v)
  have h1:=PrunedMuxEvaluation.count (LookupEvaluation.outerJob f a b z) va (LookupEvaluation.innerTree f b va vb v z)
  change (LookupEvaluation.innerTree f b va vb v z).count≤0+3 at h0
  change (LookupEvaluation.tree f a b va vb v z).count≤_ at h1
  simp only [LookupEvaluation.program,List.length_append,GuardedTree.Tree.commands_count]
  change 6+_≤12
  omega

theorem cases_count (n : Nat) (hn : 2≤n) :
    (ComposedTableBank.cases n hn).length=(ComposedTableBank.jobs n).length*8 := by
  have hr:=congrArg List.length (ComposedTableBank.records_cover n hn
    (initial _ (ComposedTableBank.base_canonical n hn)) (ComposedTableBank.jobs n))
  simp only [List.length_map] at hr
  change (ComposedTableBank.built n hn).2.length=_ at hr
  unfold ComposedTableBank.cases
  rw [flat_exact _ _ 8 (by intro r hr;rfl),hr]

theorem complete (n : Nat) (hn : 2≤n) :
    (RecordedComposedTables.program n hn).length≤1500*(n+1) := by
  have h:=retained_fold (ComposedTableBank.leaf n hn) (ComposedTableBank.rows n hn)
    (ComposedTableBank.cases n hn) (ComposedTableBank.built n hn).1.rows 12
    (by intro c hc D;exact leaf ..)
  change (ComposedTableBank.program n hn).length≤_ at h
  rw [cases_count,jobs] at h
  have hd:=definitions n hn
  simp only [RecordedComposedTables.program,List.length_append,polProgram_length]
  omega

#print axioms complete
end L3Emitter.ConstructionComposedTableCount

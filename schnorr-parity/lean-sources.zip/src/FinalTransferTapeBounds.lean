import FinalU2TapeBounds
import ReplacementStageSize
namespace L3Emitter.FinalTransferTapeBounds
open EREF EREF.GeneralRED AliasNetwork AliasProgram U2ConstructionSize
open FinalOutputDefinitions

theorem seed (n : Nat) (hn : 2≤n) (p : Fin 2) (i : Fin (W n-1))
    (x : Fin (T n)) (b : Bool) (D : List Row) :
    tokens (FinalTransferSeed.program n hn p i x b D)≤7 := by
  unfold FinalTransferSeed.program
  split
  · simp [tokens]
  · split
    · simp [tokens,FinalTransferSeed.tautProgram,ComplementChoice.tautTokens,
        ChoiceProjection.weakenTokens,ClauseTransport.padSteps]
    · have he:=List.length_erase_le (l:=[-(FinalTransferContext.altSelector n hn p i).val,
          -GuardedVectorTransport.signed b (FinalTransferContext.value n hn i x),
          GuardedVectorTransport.signed b (FinalTransferContext.altPort n hn p x)])
          (a:=(PrimaryAliasBank.cfg n hn).T.val)
      simp [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
        PrimaryAliasRows.unitTape,ChoiceProjection.weakenTokens,List.length_cons,
        List.length_nil,List.length_append,ClauseTransport.padSteps,List.length_flatMap,
        List.map_map,Function.comp_def,List.sum_replicate,smul_eq_mul]
      simp only [List.length_cons,List.length_nil] at he
      omega

theorem mux (D : List Row) (c s a v p z q r : Bit) (b : Bool) :
    tokens (TransferMuxPOL.program D c s a v p z q r b)=44 := by
  simp [tokens,TransferMuxPOL.program,TransferMuxPOL.tape,TransferMuxPOL.links,
    ClauseTransport.tokens,ClauseTransport.linkSteps,ClauseTransport.Link.tokens,
    GuardedVectorTransport.link,ClauseTransport.padSteps,ClauseTransport.padding,
    ClauseTransport.Link.target,Resolution.mergeTokens]

theorem leaf (n : Nat) (hn : 2≤n) (j : FinalTransferBank.Job n) (D : List Row) :
    tokens (FinalTransferBank.leaf n hn j D)≤51 := by
  have h:=seed n hn j.1 j.2.1 j.2.2.1 j.2.2.2 D
  simp only [FinalTransferBank.leaf,tokens_append,mux];omega

theorem transfers (n : Nat) (hn : 2≤n) :
    tokens (FinalTransferBank.program n hn)≤816*(n+1)*2^n := by
  have h:=fold_tokens (FinalTransferBank.leaf n hn) (FinalTransferBank.rows n hn)
    (FinalTransferBank.jobs n) (FinalTransferContext.D n hn) 51 (fun j _ D=>leaf n hn j D)
  rw [ReplacementStageSize.transfer_jobs] at h
  have hw:W n-1≤4*(n+1):=by unfold W AliasAssembly.width RankConstruction.width;omega
  have hb:=Nat.mul_le_mul_right (T n) (Nat.mul_le_mul_left 4 hw)
  change tokens (FinalTransferBank.program n hn)≤4*(W n-1)*2^n*51 at h
  unfold T FamilyNamespace.truthRows at hb
  nlinarith

theorem primary (n : Nat) (hn : 2≤n) :
    tokens (FinalPrimaryTransfers.program n hn)≤6*n*2^n := by
  have h:=fold_tokens (FinalPrimaryTransfers.leaf n hn) (FinalPrimaryTransfers.rows n hn)
    (FinalPrimaryTransfers.jobs n) (FinalTransferBank.result n hn) 3 (by
      intro j hj D;simp [FinalPrimaryTransfers.leaf,tokens,RawLowerTransfers.primaryTape])
  rw [ReplacementStageSize.primary_jobs] at h
  change tokens (FinalPrimaryTransfers.program n hn)≤(2*n*2^n)*3 at h
  exact h.trans_eq (by ring)

theorem function_leaf (n : Nat) (hn : 2≤n) (j : FinalFunctionCases.Job) (D : List Row) :
    tokens (FinalFunctionCases.leaf n hn j D)≤6 := by
  unfold FinalFunctionCases.leaf
  split <;> simp [tokens,FunctionChainPOL.keptProgram,FunctionChainPOL.chosenProgram,GuardedJoin.tape]

theorem functions (n : Nat) (hn : 2≤n) :
    tokens (FinalFunctionCases.program n hn)≤288 := by
  have h:=fold_tokens (FinalFunctionCases.leaf n hn) (FinalFunctionCases.rows n hn)
    FinalFunctionCases.jobs (FinalPrimaryTransfers.result n hn) 6 (fun j _ D=>function_leaf n hn j D)
  simpa only [FinalFunctionCases.program,ReplacementStageSize.function_jobs] using h
#print axioms transfers
#print axioms primary
#print axioms functions
end L3Emitter.FinalTransferTapeBounds

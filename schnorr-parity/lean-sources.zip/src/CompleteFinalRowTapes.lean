import NetworkMainTokens
import FinalSelectorTapeBounds
import GlobalValueTokenEnvelope
namespace L3Emitter.CompleteFinalRowTapes
open EREF EREF.GeneralRED AliasNetwork AliasProgram U2ConstructionSize

theorem gate_zero (D : List Row) (q : Nat) (prev gs : List REDWitness.GateRow) :
    MainTapeRecurrence.count (RecordedGate.program D q prev gs)=0 := by
  induction gs generalizing prev with
  | nil=>rfl
  | cons g gs ih=>
    simp only [RecordedGate.program,MainTapeRecurrence.count,List.map_cons,List.sum_cons]
    change 0+MainTapeRecurrence.count (RecordedGate.program D q (prev++[g]) gs)=0
    rw [ih]

theorem network_zero (D : List Row) (gs : List AliasNetwork.Gate) :
    MainTapeRecurrence.count (RecordedNetwork.program D gs)=0 := by
  induction gs generalizing D with
  | nil=>rfl
  | cons g gs ih=>
    simp only [RecordedNetwork.program,MainTapeRecurrence.append,RecordedNetwork.gateProgram,
      gate_zero,ih,Nat.add_zero]

def Q (n : Nat):Nat:=(n+1)^4*(2^n)^2

theorem lift (n c p t : Nat) (hp:p≤4) (ht:t≤2) :
    c*(n+1)^p*(2^n)^t≤c*Q n := by
  have h1:=Nat.pow_le_pow_right (show 0<n+1 by omega) hp
  have h2:=Nat.pow_le_pow_right (show 0<2^n by positivity) ht
  exact (Nat.mul_le_mul (Nat.mul_le_mul_left c h1) h2).trans_eq (by unfold Q;ring)

/-- All main POL tapes in the actual replacement-output stage, including
selector cardinalities, transfers, U2, evaluation and the final image.
Fresh RED definitions have zero main POL tokens; their local proofs are
counted by the independent local-certificate envelope. -/
theorem complete (n : Nat) (hn : 2≤n) :
    MainTapeRecurrence.count (RecordedFinalRows.program n hn)≤10000*Q n := by
  have h0:MainTapeRecurrence.count (RecordedOutputDefinitions.program n hn)=0:=network_zero _ _
  have h1:tokens (FinalOutputRecorded.program n hn)≤400*Q n:=
    (NetworkMainTokens.final_mux n hn).trans (by simpa using lift n 400 1 1 (by omega) (by omega))
  have h2:tokens (FinalSelectorBank.program n hn)≤4000*Q n:=
    (FinalSelectorTapeBounds.selectors n hn).trans (by simpa using lift n 4000 4 0 (by omega) (by omega))
  have h3:tokens (FinalSelectorCardinalities.program n hn)≤48*Q n:=
    (FinalSelectorTapeBounds.cardinalities n hn).trans (by simpa using lift n 48 2 0 (by omega) (by omega))
  have h4:tokens (FinalOutputLinks.program n hn)≤164*Q n:=
    (NetworkMainTokens.final_links n hn).trans (by simpa using lift n 164 2 2 (by omega) (by omega))
  have h5:tokens (FinalTransferBank.program n hn)≤816*Q n:=
    (FinalTransferTapeBounds.transfers n hn).trans (by simpa using lift n 816 1 1 (by omega) (by omega))
  have h6:tokens (FinalPrimaryTransfers.program n hn)≤6*Q n:=by
    have h:=FinalTransferTapeBounds.primary n hn
    exact h.trans ((Nat.mul_le_mul_right (2^n) (show 6*n≤6*(n+1) by omega)).trans
      (by simpa using lift n 6 1 1 (by omega) (by omega)))
  have h7:tokens (FinalFunctionCases.program n hn)≤288*Q n:=
    (FinalTransferTapeBounds.functions n hn).trans (by simpa using lift n 288 0 0 (by omega) (by omega))
  have h8:tokens (FinalU2Bank.bothProgram n hn)≤2520*Q n:=
    (FinalU2TapeBounds.complete n hn).trans (by simpa using lift n 2520 0 0 (by omega) (by omega))
  have h9:tokens (FinalEvaluationBank.program n hn)+tokens (FinalEvaluationImage.program n hn)≤1312*Q n:=
    (FinalMainTapeBounds.evaluation_in_n n hn).trans (by simpa using lift n 1312 1 1 (by omega) (by omega))
  simp only [RecordedFinalRows.program,RecordedFinalRows.p10,RecordedFinalRows.p9,RecordedFinalRows.p8,
    RecordedFinalRows.p7,RecordedFinalRows.p6,RecordedFinalRows.p5,RecordedFinalRows.p4,
    RecordedFinalRows.p3,RecordedFinalRows.p2,RecordedFinalRows.p1,RecordedFinalRows.p0,
    MainTapeRecurrence.append,MainTapeRecurrence.pol_program,h0]
  change 0+tokens _+tokens _+tokens _+tokens _+tokens _+tokens _+tokens _+tokens _+tokens _+tokens _≤_
  omega
theorem in_formula (n : Nat) (hn : 2≤n) :
    MainTapeRecurrence.count (RecordedFinalRows.program n hn)≤
      10000*(ConstructionFormulaScale.rows n)^6 := by
  exact (complete n hn).trans (by simpa only [Q,←pow_mul,Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc] using ConstructionFormulaScale.monomial n 4 2 10000 hn)
#print axioms in_formula
#print axioms complete
end L3Emitter.CompleteFinalRowTapes

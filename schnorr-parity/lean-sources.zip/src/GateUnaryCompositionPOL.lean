import FinalU2Image
namespace L3Emitter.GateUnaryCompositionPOL
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL

def phaseRow (G:List Int) (o u:Int):Row:=clause (G++[-o,u])
def functionRow (G:List Int) (f u q:Int):Row:=clause (G++[-f,-u,q])
def gateRow (P:List Int) (f o:Int):Row:=clause (P++[-f,o])
def first (G:List Int) (o f q:Int):Row:=clause (G++[-o,-f,q])
def second (G P:List Int) (f q:Int):Row:=clause (G++P++[-f,q])
def finalRow (G P:List Int) (q:Int):Row:=clause (G++P++[q])

theorem clause_value_eq (A B:List Int) (ha:Valid A) (hb:Valid B)
    (h:∀α:Val,sum α A=sum α B):clause A=clause B:=by
  apply canonical_ext _ _ (canonical_normalize _ _) (canonical_normalize _ _)
  intro α
  change (clause A).val α=(clause B).val α
  rw [val_clause A ha,val_clause B hb,h]

def firstTape (D:List Row) (G:List Int) (o f u q:Int):=
  CommonGuardResolve.tape D G [-o] [-f,q] u

theorem first_check (D:List Row) (G:List Int) (o f u q:Int) (hg:Valid G)
    (ho:o≠0) (hf:f≠0) (hu:u≠0) (hq:q≠0)
    (hp:phaseRow G o u∈D) (hh:functionRow G f u q∈D):
    polEval (dbOf D) (firstTape D G o f u q) []=some (first G o f q):=by
  have he:CommonGuardResolve.right G [-f,q] u=functionRow G f u q:=by
    unfold CommonGuardResolve.right functionRow
    refine clause_value_eq _ _ ?_ ?_ ?_
    · simp_all [Valid,List.mem_append,or_imp,forall_and]
    · simp_all [Valid,List.mem_append,or_imp,forall_and]
    intro α;simp only [sum_append,sum_cons,sum_nil];ring
  have h:=CommonGuardResolve.checks D G [-o] [-f,q] u hg (by simp [Valid,ho]) (by simp [Valid,hf,hq]) hu
    (by simpa only [CommonGuardResolve.left,phaseRow,List.append_assoc,List.singleton_append] using hp) (he ▸ hh)
  simpa only [firstTape,CommonGuardResolve.target,first,List.append_assoc,List.singleton_append] using h

def secondTape (D:List Row) (G P:List Int) (o f q:Int):=
  CommonGuardResolve.tape D [-f] (G++[q]) P (-o)
theorem second_check (D:List Row) (G P:List Int) (o f q:Int) (hg:Valid G) (hp:Valid P)
    (ho:o≠0) (hf:f≠0) (hq:q≠0)
    (h0:first G o f q∈D) (h1:gateRow P f o∈D):
    polEval (dbOf D) (secondTape D G P o f q) []=some (second G P f q):=by
  have hl:CommonGuardResolve.left [-f] (G++[q]) (-o)=first G o f q:=by
    unfold CommonGuardResolve.left first
    refine clause_value_eq _ _ ?_ ?_ ?_
    · simp_all [Valid,List.mem_append,or_imp,forall_and]
    · simp_all [Valid,List.mem_append,or_imp,forall_and]
    intro α;simp only [sum_append,sum_cons,sum_nil];ring
  have hr:CommonGuardResolve.right [-f] P (-o)=gateRow P f o:=by
    unfold CommonGuardResolve.right gateRow
    refine clause_value_eq _ _ ?_ ?_ ?_
    · simp_all [Valid,List.mem_append,or_imp,forall_and]
    · simp_all [Valid,List.mem_append,or_imp,forall_and]
    intro α;simp only [sum_append,sum_cons,sum_nil,neg_neg];ring
  have ht:CommonGuardResolve.target [-f] (G++[q]) P=second G P f q:=by
    unfold CommonGuardResolve.target second
    refine clause_value_eq _ _ ?_ ?_ ?_
    · simp_all [Valid,List.mem_append,or_imp,forall_and]
    · simp_all [Valid,List.mem_append,or_imp,forall_and]
    intro α;simp only [sum_append,sum_cons,sum_nil];ring
  have h:=CommonGuardResolve.checks D [-f] (G++[q]) P (-o) (by simp [Valid,hf])
    (EvaluationCaseSeeds.valid_join hg (by simp [Valid,hq])) hp (neg_ne_zero.mpr ho) (hl ▸ h0) (hr ▸ h1)
  rw [ht] at h;exact h

def rows (G P:List Int) (o f:Bit) (q:Int):List Row:=
  [first G (sign false o) (sign false f) q,first G (sign true o) (sign true f) q,
   second G P (sign false f) q,second G P (sign true f) q,finalRow G P q]
def program (D:List Row) (G P:List Int) (o f:Bit) (u:Bool→Int) (q:Int):Program:=
  let r0:=first G (sign false o) (sign false f) q
  let r1:=first G (sign true o) (sign true f) q
  let r2:=second G P (sign false f) q
  let r3:=second G P (sign true f) q
  [(r0,firstTape D G (sign false o) (sign false f) (u false) q),
   (r1,firstTape (D++[r0]) G (sign true o) (sign true f) (u true) q),
   (r2,secondTape (D++[r0,r1]) G P (sign false o) (sign false f) q),
   (r3,secondTape (D++[r0,r1,r2]) G P (sign true o) (sign true f) q),
   (finalRow G P q,CommonGuardResolve.tape (D++[r0,r1,r2,r3]) (G++P++[q]) [] [] f.val)]

theorem checks (D:List Row) (G P:List Int) (o f:Bit) (u:Bool→Int) (q:Int) (hg:Valid G) (hp:Valid P)
    (hu:∀b,u b≠0) (hq:q≠0)
    (hphase:∀b,phaseRow G (sign b o) (u b)∈D)
    (hfunction:∀b,functionRow G (sign b f) (u b) q∈D)
    (hgate:∀b,gateRow P (sign b f) (sign b o)∈D):
    check D (program D G P o f u q)=some (D++rows G P o f q):=by
  let r0:=first G (sign false o) (sign false f) q
  let r1:=first G (sign true o) (sign true f) q
  let r2:=second G P (sign false f) q
  let r3:=second G P (sign true f) q
  have h0:=first_check D G _ _ _ q hg (sign_valid _ _) (sign_valid _ _) (hu false) hq (hphase false) (hfunction false)
  have h1:=first_check (D++[r0]) G _ _ _ q hg (sign_valid _ _) (sign_valid _ _) (hu true) hq
    (List.mem_append_left _ (hphase true)) (List.mem_append_left _ (hfunction true))
  have h2:=second_check (D++[r0,r1]) G P _ _ q hg hp (sign_valid _ _) (sign_valid _ _) hq
    (List.mem_append_right _ (List.mem_cons_self)) (List.mem_append_left _ (hgate false))
  have h3:=second_check (D++[r0,r1,r2]) G P _ _ q hg hp (sign_valid _ _) (sign_valid _ _) hq
    (List.mem_append_right _ (List.mem_cons_of_mem _ List.mem_cons_self)) (List.mem_append_left _ (hgate true))
  have perm (v:Int) (hv:v≠0):clause (G++P++[q,v])=clause (G++P++[v,q]):=by
    apply clause_value_eq _ _ (EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join hg hp) (by simp [Valid,hq,hv]))
      (EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join hg hp) (by simp [Valid,hq,hv]))
    intro α;simp only [sum_append,sum_cons,sum_nil];ring
  have h4:=CommonGuardResolve.checks (D++[r0,r1,r2,r3]) (G++P++[q]) [] [] f.val
    (EvaluationCaseSeeds.valid_join (EvaluationCaseSeeds.valid_join hg hp) (by simp [Valid,hq])) (by simp [Valid]) (by simp [Valid]) f.property
    (by
      have he:CommonGuardResolve.left (G++P++[q]) [] f.val=r2:=by
        simpa only [CommonGuardResolve.left,List.append_nil,List.append_assoc,List.singleton_append,r2,second,sign,Bool.false_eq_true,↓reduceIte,neg_neg] using perm f.val f.property
      rw [he]
      exact List.mem_append_right _ (by simp))
    (by
      have he:CommonGuardResolve.right (G++P++[q]) [] f.val=r3:=by
        simpa only [CommonGuardResolve.right,List.append_nil,List.append_assoc,List.singleton_append,r3,second,sign,↓reduceIte] using perm (-f.val) (neg_ne_zero.mpr f.property)
      rw [he]
      exact List.mem_append_right _ (by simp))
  simp only [CommonGuardResolve.target,List.append_nil] at h4
  change polEval _ _ []=some (finalRow G P q) at h4
  simp only [List.append_assoc,r0,r1,r2,r3] at h4
  simp only [program,check,h0,↓reduceIte,List.append_assoc,List.cons_append,List.nil_append,h1,h2,h3,h4,rows,r0,r1,r2,r3]

#print axioms checks
end L3Emitter.GateUnaryCompositionPOL

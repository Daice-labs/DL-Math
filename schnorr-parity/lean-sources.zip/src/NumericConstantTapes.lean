import NumericForcingTapes
import NumericSelectedCofactors
namespace L3Emitter.NumericConstantTapes
open EREF EREF.GeneralRED RecordedOperandFields REDWitness FamilyNamespace CofactorSemantics

theorem fields (M k:Nat) (hk:3≤k) (D:List Row):
 NumericProgramFields.Bounded M (ForcingFieldBank.program k hk D):=by
 apply NumericProgramFields.rebase
 intro z hz;obtain ⟨e,he,rfl⟩:=List.mem_map.mp hz
 exact NumericPriorityTapes.exclusive_tokens M _ _ _ _

theorem primary (M n:Nat) (hn:2≤n):NumericProgramFields.Bounded M (PrimaryBank.program n hn):=by
 apply NumericProgramFields.rebase
 intro z hz;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hz
 intro t ht;simp only [PrimaryCofactor.tape,List.mem_cons,List.not_mem_nil,or_false] at ht
 rcases ht with rfl|rfl|rfl <;> trivial

theorem selected (M:Nat) (D:List Row) (s a b p:Int) (hp:p.natAbs≤M) (hM:2≤M):
 Tape M (SelectedPort.tape D s a b p):=by
 intro t ht;simp only [SelectedPort.tape,List.mem_cons,List.not_mem_nil,or_false] at ht
 rcases ht with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
 · trivial
 · trivial
 · trivial
 · trivial
 · trivial
 · exact hp
 · trivial
 · exact hM

theorem betaPort (M n:Nat) (hn:2≤n) (hM:NumericCofactorNamespace.cap n hn≤M) (h2:2≤M):
 NumericProgramFields.Bounded M (BetaPort.program n hn):=by
 intro z hz;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hz
 apply selected M _ _ _ _ _ ?_ h2
 have h:=NumericSelectedCofactors.beta_job n hn j hj
 change (output (low n (ConstantCofactor.offset n hn) j.1.2.parent.beta j.1.2.port j.2) _).natAbs≤M
 rw [NumericCofactorNamespace.output_abs]
 exact (CofactorBytes.low_bound n (3*(n+1)-4) (ConstantCofactor.offset n hn)
   j.1.2.parent.beta j.1.2.port j.2 h.2.1 (by omega) h.2.2.2).trans hM

theorem leaf (M:Nat) (D:List Row) (s p q v a b e C:Int)
 (hv:v.natAbs≤M) (hC:C.natAbs≤M) (hM:5≤M):Tape M (ConstantLeaf.tape D s p q v a b e C):=by
 apply NumericSelectionTapes.append
 · apply NumericSelectionTapes.append
   · apply NumericSelectionTapes.append
     · intro t ht;obtain rfl:=List.mem_singleton.mp ht;trivial
     · exact NumericSelectionTapes.steps M _ _
   · apply NumericSelectionTapes.pad
     intro l hl;simp only [ConstantLeaf.padding,List.mem_cons,List.not_mem_nil,or_false] at hl
     rcases hl with rfl|rfl|rfl|rfl|rfl|rfl <;> first | exact hC | simpa using hv
 · intro t ht;obtain rfl:=List.mem_singleton.mp ht;exact hM

theorem betaValue (M n:Nat) (hn:2≤n) (hM:NumericCofactorNamespace.cap n hn≤M) (h5:5≤M):
 NumericProgramFields.Bounded M (BetaValue.program n hn):=by
 intro z hz;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hz
 apply leaf M _ _ _ _ _ _ _ _ _ ?_ ?_ h5
 · have h:=NumericSelectedCofactors.beta_job n hn j.1 ((BetaValue.job_mem n hn j).mp hj)
   change (output (low n (ConstantCofactor.offset n hn) j.1.1.2.parent.beta 2 j.1.2) _).natAbs≤M
   rw [NumericCofactorNamespace.output_abs]
   exact (CofactorBytes.low_bound n (3*(n+1)-4) (ConstantCofactor.offset n hn)
     j.1.1.2.parent.beta 2 j.1.2 h.2.1 (by omega) h.2.2.2).trans hM
 · change (output (ConstantConstruction.C (n+1) _) _).natAbs≤M
   rw [NumericCofactorNamespace.output_abs]
   unfold NumericCofactorNamespace.cap ConstantCofactor.offset at hM;omega
#print axioms betaValue
end L3Emitter.NumericConstantTapes

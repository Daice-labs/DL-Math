import ClauseReorder
namespace L3Emitter.GammaComparison
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL CofactorValueRows
abbrev Job:=BetaPort.Job
theorem bit_nonzero (q:Bit):q.val≠0:=q.property
def otherUnary (n:Nat) (hn:2≤n) (j:Job n) (u side:Bool):Bit:=
  if side then UnaryLookupEvaluation.rbit n hn (GammaCofactorValue.g j) u
  else UnaryLookupEvaluation.lbit n hn (GammaCofactorValue.g j) u

def G (n:Nat) (hn:2≤n) (j:Job n) (side a:Bool):List Int:=
  [-BetaAliasValue.choice j,-sign side (GammaChoiceBank.hit n hn j.1),-sign a (PrimaryAliasBank.cfg n hn).C]
def H (n:Nat) (hn:2≤n) (j:Job n) (u side b v:Bool):List Int:=
  [-sign b (otherUnary n hn j u side),-sign v (unary n hn (GammaCofactorValue.g j) u)]
def Q (n:Nat) (hn:2≤n) (j:Job n) (side b v:Bool):List Int:=
  [-sign b (GammaCofactorValue.other n hn j side),sign v (cofactor n hn (GammaCofactorValue.g j) j.2)]
def pivot (n:Nat) (hn:2≤n) (j:Job n) (side a b v:Bool):Int:=sign v (GammaCofactorValue.fbit n hn j side a b)
def row (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool):=
  CommonGuardResolve.target (G n hn j side a) (H n hn j u side b v) (Q n hn j side b v)
def tape (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool) (D:List Row):=
  CommonGuardResolve.tape D (G n hn j side a) (H n hn j u side b v) (Q n hn j side b v) (pivot n hn j side a b v)

theorem unary_binding (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (u side a b v:Bool):
    GammaUnaryChoice.row n hn j u side a b (!v)=
    CommonGuardResolve.left (G n hn j side a) (H n hn j u side b v) (pivot n hn j side a b v):=by
  have hh:(UnaryMuxBinding.job n hn (GammaCofactorValue.g j) u).c=GammaChoiceBank.hit n hn j.1:=rfl
  have hc:=BetaAliasValue.choice_valid n hn j hj
  cases side <;> cases a <;> cases b <;> cases v <;>
    simp only [GammaUnaryChoice.row,GammaUnaryChoice.Q,GammaUnaryChoice.K,GammaUnaryChoice.g,
      UnaryValueStep.G,UnaryValueStep.H,LookupEvaluation.guards,GammaUnaryChoice.va,GammaUnaryChoice.vb,
      UnaryLookupEvaluation.abit,UnaryLookupEvaluation.bbit,UnaryLookupEvaluation.cfg,hh,
      CommonGuardResolve.target,CommonGuardResolve.left,G,H,pivot,GammaCofactorValue.fbit,otherUnary,
      sign,Bool.not_true,Bool.not_false,Bool.false_eq_true,↓reduceIte,neg_neg,List.nil_append,List.cons_append,List.singleton_append]
  all_goals apply ProjectionTrace.clause_perm _ _ (by simp [Valid,hc,bit_nonzero]) (by simp [Valid,hc,bit_nonzero])
  all_goals apply List.perm_iff_count.mpr
  all_goals intro x; simp only [List.count_cons,List.count_nil];omega

theorem cofactor_binding (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (side a b v:Bool):
    GammaCofactorValue.row n hn j side a b v=
    CommonGuardResolve.right (G n hn j side a) (Q n hn j side b v) (pivot n hn j side a b v):=by
  have hc:=BetaAliasValue.choice_valid n hn j hj
  apply ProjectionTrace.clause_perm _ _
    (by simp [GammaCofactorValue.row,CommonGuardResolve.target,GammaCofactorValue.Q,Valid,hc,sign_valid])
    (by simp [CommonGuardResolve.right,G,Q,pivot,Valid,hc,sign_valid])
  apply List.perm_iff_count.mpr
  intro x
  simp only [CommonGuardResolve.right,CommonGuardResolve.target,GammaCofactorValue.Q,G,Q,pivot,
    List.nil_append,List.cons_append,List.singleton_append,List.count_cons,List.count_nil]
  omega

def rows (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool):=
  [GammaUnaryChoice.row n hn j u side a b (!v),GammaCofactorValue.row n hn j side a b v,row n hn j u side a b v]
def program (n:Nat) (hn:2≤n) (j:Job n) (u side a b v:Bool) (D:List Row):Program:=
  [(GammaUnaryChoice.row n hn j u side a b (!v),GammaUnaryChoice.tape n hn j u side a b (!v) D),
   (GammaCofactorValue.row n hn j side a b v,GammaCofactorValue.tape n hn j side a b v D),
   (row n hn j u side a b v,tape n hn j u side a b v
     (D++[GammaUnaryChoice.row n hn j u side a b (!v),GammaCofactorValue.row n hn j side a b v]))]

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (u side a b v:Bool)
    (D:List Row) (hd:∀R∈GammaChoiceBank.result n hn,R∈D):
    check D (program n hn j u side a b v D)=some (D++rows n hn j u side a b v):=by
  have h0:=GammaUnaryChoice.checks n hn j hj u side a b (!v) D hd
  have h1:=GammaCofactorValue.checks n hn j hj side a b v D hd
  have hc:=BetaAliasValue.choice_valid n hn j hj
  let E:=D++[GammaUnaryChoice.row n hn j u side a b (!v),GammaCofactorValue.row n hn j side a b v]
  have h2:=CommonGuardResolve.checks E (G n hn j side a) (H n hn j u side b v) (Q n hn j side b v) (pivot n hn j side a b v)
    (by simp [G,Valid,hc,sign_valid]) (by simp [H,Valid,sign_valid]) (by simp [Q,Valid,sign_valid]) (sign_valid _ _)
    (by rw [←unary_binding n hn j hj];exact List.mem_append_right _ (by simp))
    (by rw [←cofactor_binding n hn j hj];exact List.mem_append_right _ (by simp))
  have hpair:=IndependentProgram.check_base D
    [(GammaUnaryChoice.row n hn j u side a b (!v),GammaUnaryChoice.tape n hn j u side a b (!v) D),
     (GammaCofactorValue.row n hn j side a b v,GammaCofactorValue.tape n hn j side a b v D)] (by
      intro cmd hm;simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
      rcases hm with rfl|rfl;exact h0;exact h1)
  have hlast:check E [(row n hn j u side a b v,tape n hn j u side a b v E)]=some (E++[row n hn j u side a b v]):=by
    simp only [check,tape,row,h2,↓reduceIte]
  simpa only [outputs,List.map_cons,List.map_nil,E,program,rows,List.append_assoc,List.cons_append,List.nil_append]
    using check_append _ _ _ _ _ hpair hlast
#print axioms checks
end L3Emitter.GammaComparison

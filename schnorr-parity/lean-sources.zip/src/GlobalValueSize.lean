import GlobalPortValues
import ForcingSize
namespace L3Emitter.GlobalValueSize
open EREF AliasProgram AliasNetwork

theorem fold_commands {A:Type} (step:A→List Row→Program) (rows:A→List Row) (B:Nat)
    (hb:∀a D,(step a D).length≤B) (xs:List A) (D:List Row):
    (RetainedBlockFold.run step rows xs D).length≤B*xs.length:=by
  induction xs generalizing D with
  | nil=>simp [RetainedBlockFold.run]
  | cons x xs ih=>
    have h0:=hb x D
    have h1:=ih (D++rows x)
    simp only [RetainedBlockFold.run,List.length_append,List.length_cons,Nat.mul_add,Nat.mul_one]
    omega

theorem branch_commands (n:Nat) (hn:2≤n) (g:Nat) (j:BetaPort.Job n)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):
    (ForcingValueCases.program n hn g j i b v D).length≤48*n+34:=by
  unfold ForcingValueCases.program
  split
  · simp
  · split
    · exact GammaInductiveBounds.commands ..
    · split
      · simp
      · rename_i r hr
        have h:=RankValueBranch.command_count n hn g r i (SourceCoordinateValue.value n hn i r.val.2.1) b v D
        simp only [ForcingRankBranch.program,List.length_append,List.length_cons,List.length_nil]
        omega

theorem node_commands (n:Nat) (hn:2≤n) (g x:Nat) (node:PriorityBank.Node)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):
    (ForcingNodeValue.program n hn g x node i b v D).length≤48*n+34:=by
  unfold ForcingNodeValue.program
  split
  · simp
  · exact branch_commands ..

theorem nodes_count (n:Nat) (hn:2≤n):(ForcingNodeSource.nodes n hn).length≤36*(n+1)^2:=by
  simp only [ForcingNodeSource.nodes,ConstantLookup.ns,PriorityBank.nodes_length,ForcingFamily.raw,ForcingSize.raw_length]
  have h:=ForcingSize.chosen_bound (n+1) (by omega)
  nlinarith

def joinBound (n:Nat):=(48*n+34)*(36*(n+1)^2)+1

theorem join_commands (n:Nat) (hn:2≤n) (g x:Nat) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):
    (ExhaustiveValueJoin.program n hn g x i b v D).length≤joinBound n:=by
  have h:=fold_commands (fun node=>ForcingNodeValue.program n hn g x node i b v)
    (fun node=>ForcingNodeValue.rows n hn g x node i b v) (48*n+34)
    (fun node D=>node_commands n hn g x node i b v D) (ForcingNodeSource.nodes n hn) D
  have h1:=Nat.mul_le_mul_left (48*n+34) (nodes_count n hn)
  simp only [ExhaustiveValueJoin.program,List.length_append,List.length_cons,List.length_nil,joinBound]
  exact Nat.add_le_add_right (h.trans h1) 1

theorem jobs_count (n:Nat):(FirstGateBase.jobs n).length=FamilyNamespace.truthRows n*AliasAssembly.width (n+1)*4:=by
  simp [FirstGateBase.jobs,List.length_flatMap,List.map_map,Function.comp_def]
  ring

theorem step_commands (n:Nat) (hn:2≤n) (g:Nat) (D:List Row):
    (GlobalValueInduction.step n hn g D).length≤joinBound n*(FamilyNamespace.truthRows n*AliasAssembly.width (n+1)*4):=by
  have h:=fold_commands
    (fun j:FirstGateBase.Job n=>ExhaustiveValueJoin.program n hn g j.1 j.2.1 j.2.2.1 j.2.2.2)
    (fun j:FirstGateBase.Job n=>ExhaustiveValueJoin.rows n hn g j.1 j.2.1 j.2.2.1 j.2.2.2)
    (joinBound n) (fun j D=>join_commands n hn g j.1 j.2.1 j.2.2.1 j.2.2.2 D) (FirstGateBase.jobs n) D
  simpa only [jobs_count] using h

theorem run_commands (n:Nat) (hn:2≤n) (g m:Nat) (D:List Row):
    (GlobalValueInduction.run n hn g m D).length≤m*(joinBound n*(FamilyNamespace.truthRows n*AliasAssembly.width (n+1)*4)):=by
  induction m generalizing g D with
  | zero=>simp [GlobalValueInduction.run]
  | succ m ih=>
    have h0:=step_commands n hn g D
    have h1:=ih (g+1) (D++GlobalValueInduction.stepRows n hn g)
    simp only [GlobalValueInduction.run,List.length_append,Nat.add_mul,Nat.one_mul]
    omega

/-- Counts this actual all-gate POL extension. The predecessor, recursive
certificate, operand ceiling and full byte recurrence are not included. -/
theorem all_gate_commands_in_n (n:Nat) (hn:2≤n):
    (GlobalValueInduction.program n hn).length≤
      (3*(n+1)-5)*(((48*n+34)*(36*(n+1)^2)+1)*(2^n*(4*n-4)*4)):=by
  have h:=run_commands n hn 1 (3*(n+1)-5) (FirstGateBase.result n hn)
  have hw:AliasAssembly.width (n+1)=4*n-4:=by unfold AliasAssembly.width RankConstruction.width;omega
  simpa only [GlobalValueInduction.program,joinBound,FamilyNamespace.truthRows,hw] using h
#print axioms all_gate_commands_in_n
end L3Emitter.GlobalValueSize

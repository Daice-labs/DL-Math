import OneHotSerialized
import ComplementChoice

namespace L3Emitter.MuxVectorOneHot
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram SelectedVectorOneHot
variable {w:Nat}

theorem neg_distinct (c:Bit) : neg c≠c := by
  intro h
  have h':-c.val=c.val:=congrArg Subtype.val h
  have hc:=c.property
  omega

def inputs (c:Bit) (a b:AliasBits w) (v:Bit) := if v=c then a else b
def seedProgram (c:Bit) : Program := [(clause [c.val,-c.val],ComplementChoice.tautTokens c.val)]
def seeded (D:List Row) (c:Bit) := D++[clause [c.val,-c.val]]
def program (D:List Row) (c:Bit) (a b q:AliasBits w) := seedProgram c++
  SelectedVectorOneHot.program (seeded D c) [c,neg c] (inputs c a b) q
def result (D:List Row) (c:Bit) (q:AliasBits w) :=
  SelectedVectorOneHot.result (seeded D c) [c,neg c] q

/-- The four already emitted MUX implications. No semantic validity premise
    is accepted in place of their concrete row membership. -/
def Relations (D:List Row) (c:Bit) (a b q:AliasBits w) := ∀i,
  clause [-c.val,-(a i).val,(q i).val]∈D ∧
  clause [-c.val,-(q i).val,(a i).val]∈D ∧
  clause [c.val,-(b i).val,(q i).val]∈D ∧
  clause [c.val,-(q i).val,(b i).val]∈D

theorem checks (D:List Row) (c:Bit) (a b q:AliasBits w) (hw:0<w)
    (ha:SourceRows D a) (hb:SourceRows D b) (hr:Relations D c a b q) :
    check D (program D c a b q)=some (result D c q) := by
  have h0:check D (seedProgram c)=some (seeded D c) := by
    simp only [seedProgram,check,ComplementChoice.taut_pair_succeeds _ _ c.property,↓reduceIte,seeded]
  have h1:check (seeded D c)
      (SelectedVectorOneHot.program (seeded D c) [c,neg c] (inputs c a b) q)=
      some (result D c q) := by
    apply SelectedVectorOneHot.checks
    · exact hw
    · simp
    · exact List.mem_append_right _ (by simp [neg])
    · intro v hv
      simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
      rcases hv with hv|hv
      · subst v
        simpa only [inputs,if_pos rfl] using
          (show SourceRows (seeded D c) a from
            ⟨List.mem_append_left _ ha.1,fun i j hij=>List.mem_append_left _ (ha.2 i j hij)⟩)
      · subst v
        simpa only [inputs,if_neg (neg_distinct c)] using
          (show SourceRows (seeded D c) b from
            ⟨List.mem_append_left _ hb.1,fun i j hij=>List.mem_append_left _ (hb.2 i j hij)⟩)
    · intro v hv i
      simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
      rcases hv with hv|hv
      · subst v
        simpa only [inputs,if_pos rfl] using
          (show clause [-c.val,-(a i).val,(q i).val]∈seeded D c ∧
            clause [-c.val,-(q i).val,(a i).val]∈seeded D c from
            ⟨List.mem_append_left _ (hr i).1,List.mem_append_left _ (hr i).2.1⟩)
      · subst v
        rw [show inputs c a b (neg c)=b from if_neg (neg_distinct c)]
        simpa only [neg,neg_neg] using
          (show clause [c.val,-(b i).val,(q i).val]∈seeded D c ∧
            clause [c.val,-(q i).val,(b i).val]∈seeded D c from
            ⟨List.mem_append_left _ (hr i).2.2.1,List.mem_append_left _ (hr i).2.2.2⟩)
  exact check_append _ _ _ _ _ h0 h1

theorem source_rows (D:List Row) (c:Bit) (q:AliasBits w) : SourceRows (result D c q) q := by
  constructor
  · apply List.mem_append_left
    apply List.mem_append_right
    rw [←alo_binding]
    exact body_member [c,neg c] q _ (by simp [specs])
  · intro i j hij
    apply List.mem_append_left
    apply List.mem_append_right
    rw [←pair_binding]
    exact body_member [c,neg c] q _ (List.mem_cons_of_mem _ (pair_mem i j hij))

#print axioms checks
#print axioms source_rows
end L3Emitter.MuxVectorOneHot

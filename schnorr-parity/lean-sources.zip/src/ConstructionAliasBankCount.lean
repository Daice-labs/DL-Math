import ConstructionAliasCount

namespace L3Emitter.ConstructionAliasBankCount
open EREF EREF.GeneralRED AliasNetwork RecursiveAliases
open ConstructionAliasCount
variable {base : List Row}

def contextCap (k : Nat) := 1+2*(3*k-4)*(9*k^2+1)+(3*k-4)*(3*k+1)+(3*k-4)*(12*k+1)

theorem context (k : Nat) (hk : 3≤k) :
    ConstructionAliasCount.Cost (AliasAssembly.context (base:=base) k hk) (contextCap k) := by
  have hsupport (b : Bool) (g : Nat) :
      (AliasAssembly.choiceSupport k hk b g).length≤9*k^2 := by
    simp only [AliasAssembly.choiceSupport,List.length_map]
    exact (List.length_filter_le ..).trans (ForcingSize.chosen_bound k hk)
  unfold AliasAssembly.context
  have h:=ConstructionAliasCount.bind_cost (base:=base) (AND []) _ 1
    ((3*k-4)*(9*k^2+1)+((3*k-4)*(9*k^2+1)+((3*k-4)*(3*k+1)+((3*k-4)*(12*k+1)+0))))
    (ConstructionAliasCount.gate_cost true _) (fun T=>
      ConstructionAliasCount.bind_cost _ _ ((3*k-4)*(9*k^2+1))
        ((3*k-4)*(9*k^2+1)+((3*k-4)*(3*k+1)+((3*k-4)*(12*k+1)+0)))
        (ConstructionAliasCount.tabulate_cost (3*k-4) _ (9*k^2+1) (fun g=>
          ConstructionAliasCount.cost_mono _ _ _
            (ConstructionAliasCount.gate_cost false (AliasAssembly.choiceSupport k hk true g.val))
            (by have:=hsupport true g.val;omega)))
        (fun beta=>ConstructionAliasCount.bind_cost _ _ ((3*k-4)*(9*k^2+1))
          ((3*k-4)*(3*k+1)+((3*k-4)*(12*k+1)+0))
          (ConstructionAliasCount.tabulate_cost (3*k-4) _ (9*k^2+1) (fun g=>
            ConstructionAliasCount.cost_mono _ _ _
              (ConstructionAliasCount.gate_cost false (AliasAssembly.choiceSupport k hk false g.val))
              (by have:=hsupport false g.val;omega)))
          (fun gamma=>ConstructionAliasCount.bind_cost _ _ ((3*k-4)*(3*k+1)) ((3*k-4)*(12*k+1)+0)
            (ConstructionAliasCount.tabulate_cost (3*k-4) _ (3*k+1) (fun g=>
              ConstructionAliasCount.cost_mono _ _ _
                (ConstructionAliasCount.gate_cost false ((List.range (RankConstruction.width k)).map (AliasAssembly.rankBit k hk g.val)))
                (by simp only [List.length_map,List.length_range];unfold RankConstruction.width;omega)))
            (fun kept=>ConstructionAliasCount.bind_cost _ _ ((3*k-4)*(12*k+1)) 0
              (ConstructionAliasCount.tabulate_cost (3*k-4) _ (12*k+1) (fun g=>
                ConstructionAliasCount.cost_mono _ _ _
                  (ConstructionAliasCount.select_cost ((List.range (g.val-1)).map (fun h=>
                    (AliasAssembly.refAt (neg T) beta (h+1),AliasAssembly.selector k (3*k-4) g.val 0 (k+(h+1))))))
                  (by simp only [List.length_map,List.length_range];have:=g.isLt;omega)))
              (fun hit=>ConstructionAliasCount.pure_cost
                (⟨k,T,neg T,AliasAssembly.restrictionBit k hk,AliasAssembly.constantBit k hk,
                  AliasAssembly.refAt (neg T) beta,AliasAssembly.refAt (neg T) gamma,
                  AliasAssembly.refAt (neg T) hit,AliasAssembly.refAt (neg T) kept,
                  AliasAssembly.rankBit k hk,AliasAssembly.selector k (3*k-4),
                  AliasAssembly.functionBit k (3*k-4)⟩ : Config Bit))))))
  convert h using 1 <;> unfold contextCap <;> ring

theorem built_mass (n : Nat) (hn : 2≤n) :
    mass (AliasAssembly.built n hn).2.gates≤4000*(n+2)^3 := by
  let k:=n+1
  let z:=initial (AliasAssembly.source n hn) (AliasAssembly.source_canonical n hn)
  let c:=AliasAssembly.context k (by omega) z
  have hc:=context k (by omega) z
  have hr:=ConstructionAliasCount.run_cost c.1 (AliasAssembly.inputAliases (AliasAssembly.width k) c.1)
    0 (3*k-4) c.2
  have hck:c.1.k=k:=rfl
  rw [hck] at hr
  have hs:3*k-4≤3*k:=Nat.sub_le ..
  have hw:=AliasAssembly.width_bound k
  have hp:=Nat.mul_le_mul hs (Nat.mul_le_mul hw (show 8*(k+0+(3*k-4))+77≤32*k+77 by omega))
  change mass c.2.gates≤0+contextCap k at hc
  change mass (RecursiveAliases.run c.1 (AliasAssembly.inputAliases (AliasAssembly.width k) c.1)
    0 (3*k-4) c.2).2.gates≤4000*(k+1)^3
  unfold contextCap at hc
  have hsq:=Nat.mul_le_mul_right (9*k^2+1) hs
  have hlin:=Nat.mul_le_mul_right (3*k+1) hs
  have hhit:=Nat.mul_le_mul_right (12*k+1) hs
  nlinarith

theorem gate_rows (D : List Row) (g : Gate) :
    (RecordedNetwork.gateProgram D g).length=g.xs.length+1 := by
  rw [RecordedNetwork.gateProgram,ConstructionFrontendCountTools.gate_length]
  cases h:g.isAnd <;> simp [h,REDWitness.andGate,REDWitness.orGate]

theorem network_rows (D : List Row) (gs : List Gate) :
    (RecordedNetwork.program D gs).length=mass gs := by
  induction gs generalizing D with
  | nil=>rfl
  | cons g gs ih=>rw [RecordedNetwork.program,List.length_append,gate_rows,ih];rfl

theorem definitions (n : Nat) (hn : 2≤n) :
    (RecordedAliasDefinitions.program n hn).length≤4000*(n+2)^3 := by
  simpa only [RecordedAliasDefinitions.program,network_rows] using built_mass n hn

theorem expressions (n : Nat) (hn : 2≤n) :
    (RecordedExpressionRun.program n hn).length≤1200*(n+1)^2+600*(n+1) := by
  rw [RecordedExpressionRun.program,RecordedExpressionCost.program_count]
  have h:=RecordedExpressionCost.built_jobs n hn
  omega

theorem complete (n : Nat) (hn : 2≤n) :
    (RecordedAliasBanks.program n hn).length≤6100*(n+2)^3 := by
  have hd:=definitions n hn
  have hp:=ConcretePortCost.built_count n hn
  have he:=expressions n hn
  simp only [RecordedAliasBanks.program,List.length_append,ConstructionCountTools.polProgram_length]
  nlinarith

#print axioms built_mass
#print axioms network_rows
#print axioms complete
end L3Emitter.ConstructionAliasBankCount

import NativeLocalProgram
namespace L3Emitter.NativeScopedLocalGoal
open EREF EREF.GeneralRED NativeSparseStore

/-- This models local POL proof execution and scope closure in the pinned
native row store. It does not assert a Rust-parser or RED-rule refinement. -/
structure Built where
  tapes : List (List Tok)
  conclusion : Nat
  checkedStore : Store
  closedStore : Store

def compile (len : Nat) (s : Store) (ids : Nat→Nat) (G : Row)
    (p : RecordedRefutation.Certificate) : Built :=
  let localStore:=push s (negate G)
  let localIds:=extend ids len s.next
  let b:=NativeLocalProgram.compile (len+1) localStore localIds p.program
  ⟨b.tapes,b.ids p.conclusion,b.store,closeFrom b.store s.next⟩

def execute (s : Store) (G : Row) (p : Built) : Option Store := do
  let checked ← NativeLocalProgram.execute (push s (negate G)) p.tapes
  let R ← read checked (p.conclusion:Int)
  if (R.total:Int)<R.bound then return closeFrom checked s.next else none

theorem compile_next (len : Nat) (s : Store) (ids : Nat→Nat) (p : AliasProgram.Program) :
    (NativeLocalProgram.compile len s ids p).store.next=s.next+p.length := by
  induction p generalizing len s ids with
  | nil=>simp [NativeLocalProgram.compile]
  | cons c p ih=>simpa [NativeLocalProgram.compile,push,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using
      (ih (len+1) (push s c.1) (extend ids len s.next))

theorem compile_preserves (D : List Row) (oldIds : Nat→Nat) (len : Nat)
    (s : Store) (ids : Nat→Nat) (p : AliasProgram.Program) (he : Embeds D s oldIds) :
    Embeds D (NativeLocalProgram.compile len s ids p).store oldIds := by
  induction p generalizing len s ids with
  | nil=>exact he
  | cons c p ih=>exact ih (len+1) (push s c.1) (extend ids len s.next) (push_preserves D s oldIds he c.1)

theorem correct (D : List Row) (s : Store) (ids : Nat→Nat) (G : Row)
    (hs : 0<s.next) (he : Embeds D s ids) (p : RecordedRefutation.Certificate)
    (hp : RecordedRefutation.accepts (D++[negate G]) p=true) :
    execute s G (compile D.length s ids G p)=some (compile D.length s ids G p).closedStore ∧
    Embeds D (compile D.length s ids G p).closedStore ids ∧
    (compile D.length s ids G p).closedStore.next=s.next+1+p.program.length := by
  have he1:=push_embeds D s ids he hs (negate G)
  have hp0:=hp
  unfold RecordedRefutation.accepts at hp0
  split at hp0
  · contradiction
  · rename_i E hE
    split at hp0
    · contradiction
    · rename_i R hR
      have hh:=NativeLocalProgram.correct (D++[negate G]) E (push s (negate G))
        (extend ids D.length s.next) (by dsimp [push];omega) he1 p.program hE
      have hc:=NativeLocalProgram.conclusion (D++[negate G]) (push s (negate G))
        (extend ids D.length s.next) (by dsimp [push];omega) he1 p hp
      have hl : (D++[negate G]).length=D.length+1:=by simp
      rw [hl] at hh hc
      obtain ⟨C,hC,hcontra⟩:=hc
      change (C.total:Int)<C.bound at hcontra
      refine ⟨?_,?_,?_⟩
      · simp [execute,compile,hh.1,hC,hcontra]
      · apply close_preserves D _ ids
        · exact compile_preserves D ids _ _ _ p.program (push_preserves D s ids he (negate G))
        · intro i Q hQ;exact (he i Q hQ).2.1
      · change (NativeLocalProgram.compile (D.length+1) (push s (negate G))
          (extend ids D.length s.next) p.program).store.next=_
        rw [compile_next]
        rfl

theorem physical_tape_count (len : Nat) (s : Store) (ids : Nat→Nat) (G : Row)
    (p : RecordedRefutation.Certificate) :
    (compile len s ids G p).tapes.length=p.program.length :=
  NativeLocalProgram.tapes_count ..

#print axioms correct
#print axioms physical_tape_count
end L3Emitter.NativeScopedLocalGoal

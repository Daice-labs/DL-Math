import FinalMainTapeBounds
namespace L3Emitter.FinalU2TapeBounds
open EREF EREF.GeneralRED AliasNetwork AliasProgram U2ConstructionSize
open FinalOutputDefinitions

theorem link (n : Nat) (hn : 2≤n) (c : FinalFunctionFullLinks.Case)
    (ab : Fin 4) (r : Bool) (D : List Row) :
    (FinalFunctionFullLinks.tape n hn c ab r D).length≤5 := by
  simp only [FinalFunctionFullLinks.tape,ChoiceProjection.weakenTokens,
    List.length_cons,List.length_append,ClauseTransport.padSteps]
  unfold FinalFunctionFullLinks.extra
  split <;> simp

theorem links (n : Nat) (hn : 2≤n) (c : FinalFunctionFullLinks.Case) (D : List Row) :
    tokens (FinalU2Bank.linkProgram n hn c D)≤40 := by
  have h : ∀js : List (Bool×Bool×Bool),
      (js.map (fun j=>(FinalFunctionFullLinks.tape n hn c (FinalU2Bank.code j.1 j.2.1) j.2.2 D).length)).sum≤js.length*5 := by
    intro js
    induction js with
    | nil => simp
    | cons j js ih =>
      have hj:=link n hn c (FinalU2Bank.code j.1 j.2.1) j.2.2 D
      simp only [List.map_cons,List.sum_cons,List.length_cons];omega
  have hh:=h FinalU2Bank.jobs
  change _≤8*5 at hh
  simpa only [tokens,FinalU2Bank.linkProgram,List.map_map,Function.comp_def] using hh

theorem core (D : List Row) (G : List Int) (f q : U2SourcePOL.Table)
    (c : FinalFunctionFullLinks.Case) (p : Bool) (hG : G.length=4) :
    tokens (OutputU2POL.program D G f q c p)≤34 := by
  unfold OutputU2POL.program
  split
  · simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,clause_map_count]
    have hp:(OutputU2POL.pairs f q c p).length=4:=rfl
    rw [hp];decide
  · simp only [tokens,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
      CommonGuardResolve.token_count,List.length_append,List.length_cons,List.length_nil,hG]
    simp [ChoiceProjection.weakenTokens,ClauseTransport.padSteps,OutputU2POL.spare]
    split <;> simp

theorem leaf (n : Nat) (hn : 2≤n) (p : Bool) (c : FinalFunctionFullLinks.Case) (D : List Row) :
    tokens (FinalU2Bank.leaf n hn p c D)≤74 := by
  have h0:=links n hn c D
  have h1:=core (D++FinalU2Bank.linkRows n hn c) (FinalFunctionFullLinks.guards n hn c)
    (FinalU2Bank.f n hn) (FinalU2Bank.q n hn) c p rfl
  simp only [FinalU2Bank.leaf,tokens_append];omega

theorem half (n : Nat) (hn : 2≤n) (p : Bool) (D : List Row) :
    tokens (FinalU2Bank.program n hn p D)≤1260 := by
  have h0:=fold_tokens (FinalU2Bank.leaf n hn p) (FinalU2Bank.body n hn p) FinalU2Bank.cases D 74
    (fun c _ E=>leaf n hn p c E)
  have h1:=split_tokens (D++RetainedBlockFold.body (FinalU2Bank.body n hn p) FinalU2Bank.cases)
    (U2SourcePOL.literals (FinalU2Bank.q n hn) U2SourcePOL.identity U2SourcePOL.identity p)
    (FinalU2Bank.vars n hn)
  change _≤16*74 at h0
  change _+4=5*2^4 at h1
  simp only [FinalU2Bank.program,tokens_append];omega

/-- All main POL tokens in both replacement-output U2 exclusions. -/
theorem complete (n : Nat) (hn : 2≤n) :
    tokens (FinalU2Bank.bothProgram n hn)≤2520 := by
  have h0:=half n hn false (FinalU2Bank.base n hn)
  have h1:=half n hn true (FinalU2Bank.base n hn++FinalU2Bank.rows n hn false)
  simp only [FinalU2Bank.bothProgram,tokens_append];omega
#print axioms complete
end L3Emitter.FinalU2TapeBounds

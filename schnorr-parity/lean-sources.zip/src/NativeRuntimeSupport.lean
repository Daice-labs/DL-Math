import PinnedRetainedScope
import RowSupport
namespace L3Emitter.NativeRuntimeSupport
open EREF EREF.GeneralRED

def RowVars (K:Nat) (R:Row):Prop:=∀t∈R.terms,t.2.natAbs≤K
def TapeVars (K:Nat) (ts:List Tok):Prop:=∀l,Tok.lit l∈ts→l.natAbs≤K
def ImageVars (K:Nat):L3Emitter.Image→Prop
 | .bit _=>True
 | .lit l=>l.varId≤K
def WitnessVars (K:Nat) (w:FiniteWitness.Data):Prop:=∀p∈w,ImageVars K p.2

def CommandVars (K:Nat):CanonicalScopeKernel.Command→Prop
 | .pol ts=>TapeVars K ts
 | .consequence R p=>RowVars K R ∧ ∀ts∈p.tapes,TapeVars K ts
 | .red R w gs=>RowVars K R ∧ WitnessVars K w ∧ ∀g∈gs,∀ts∈g.proof.tapes,TapeVars K ts

def StoreVars (K:Nat) (s:NativeSparseStore.Store):Prop:=∀i R,s.rows i=some R→Canonical R ∧ RowVars K R

theorem ordered_length (K lo:Nat) (xs:List Nat) (hlo:lo≤K+1)
 (hp:xs.Pairwise (·<·)) (hb:∀x∈xs,lo≤x ∧ x≤K):xs.length+lo≤K+1:=by
 induction xs generalizing lo with
 | nil=>simpa using hlo
 | cons x xs ih=>
   have hx:=hb x (by simp)
   have hp':=List.pairwise_cons.mp hp
   have h:=ih (x+1) (by omega) hp'.2 (by
     intro y hy
     have hh:=hb y (by simp [hy])
     have hl:=hp'.1 y hy
     omega)
   simp only [List.length_cons];omega

theorem row_length (K:Nat) (R:Row) (hc:Canonical R) (hb:RowVars K R):R.terms.length≤K:=by
 have hp:(R.terms.map (fun t=>t.2.natAbs)).Pairwise (·<·):=by
   simpa only [List.pairwise_map] using hc.2
 have h:=ordered_length K 1 (R.terms.map (fun t=>t.2.natAbs)) (by omega) hp (by
   intro v hv;obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hv
   have hz:=Int.natAbs_pos.mpr (hc.1 t ht).2
   exact ⟨by omega,hb t ht⟩)
 simp only [List.length_map] at h
 omega

theorem row_fits (K:Nat) (R:Row) (hc:Canonical R) (hb:RowVars K R) (hK:K<2^63):
 PinnedIntegerRepresentations.fits 64 R.terms.length:=by
 have hl:=row_length K R hc hb
 unfold PinnedIntegerRepresentations.fits
 norm_num
 omega

theorem normalize_vars (K:Nat) (ts:List (Int×Int)) (b:Int) (h:∀t∈ts,t.2.natAbs≤K):RowVars K (normalize ts b):=
 RowSupport.normalize_bound K ts b h
 theorem add_vars (K:Nat) (A B:Row) (ha:RowVars K A) (hb:RowVars K B):RowVars K (add A B):=by
 apply normalize_vars
 intro t ht
 rcases List.mem_append.mp ht with ht|ht
 · obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht;exact ha u hu
 · obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht;exact hb u hu
 theorem multiply_vars (K:Nat) (A:Row) (k:Nat) (ha:RowVars K A):RowVars K (multiply A k):=by
 apply normalize_vars
 intro t ht;obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht;exact ha u hu
 theorem divide_vars (K:Nat) (A:Row) (k:Nat) (ha:RowVars K A):RowVars K (divide A k):=by
 apply normalize_vars
 intro t ht;obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht;exact ha u hu
 theorem saturate_vars (K:Nat) (A:Row) (ha:RowVars K A):RowVars K (saturate A):=by
 unfold saturate;split
 · apply normalize_vars
   intro t ht;obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht;exact ha u hu
 · simp [RowVars]
 theorem negate_vars (K:Nat) (A:Row) (ha:RowVars K A):RowVars K (negate A):=by
 apply normalize_vars
 intro t ht;obtain ⟨u,hu,rfl⟩:=List.mem_map.mp ht;simpa using ha u hu
 theorem literal_vars (K:Nat) (l:Int) (hl:l.natAbs≤K):RowVars K (litAxiom l):=by
 apply normalize_vars
 intro t ht;obtain rfl:=List.mem_singleton.mp ht;exact hl

theorem pol_vars (K:Nat) (db:Nat→Option Row) (ts:List Tok) (st:List Row) (R:Row)
 (hd:∀i Q,db i=some Q→RowVars K Q) (ht:TapeVars K ts)
 (hs:∀Q∈st,RowVars K Q) (h:polEval db ts st=some R):RowVars K R:=by
 induction ts generalizing st with
 | nil=>cases st with
   | nil=>simp [polEval] at h
   | cons A st=>cases st with
     | nil=>simp only [polEval,Option.some.injEq] at h;subst R;exact hs A (by simp)
     | cons B st=>simp [polEval] at h
 | cons t ts ih=>
   have ht':TapeVars K ts:=fun l hl=>ht l (by simp [hl])
   cases t with
   | ref i=>
     cases he:db i with
     | none=>simp [polEval,he] at h
     | some Q=>
       apply ih (Q::st) ht' ?_ (by simpa only [polEval,he] using h)
       intro A hA;rcases List.mem_cons.mp hA with rfl|hA
       · exact hd i A he
       · exact hs A hA
   | lit l=>
     by_cases hl:l=0
     · simp [polEval,hl] at h
     · apply ih (litAxiom l::st) ht' ?_ (by simpa only [polEval,if_pos hl] using h)
       intro A hA;rcases List.mem_cons.mp hA with rfl|hA
       · exact literal_vars K l (ht l (by simp))
       · exact hs A hA
   | add=>
     cases st with
     | nil=>simp [polEval] at h
     | cons A st=>cases st with
       | nil=>simp [polEval] at h
       | cons B st=>
         apply ih (add B A::st) ht' ?_ h
         intro Q hQ;rcases List.mem_cons.mp hQ with rfl|hQ
         · exact add_vars K B A (hs B (by simp)) (hs A (by simp))
         · exact hs Q (by simp [hQ])
   | mul k=>
     cases st with
     | nil=>simp [polEval] at h
     | cons A st=>
       by_cases hk:0<k
       · apply ih (multiply A k::st) ht' ?_ (by simpa only [polEval,if_pos hk] using h)
         intro Q hQ;rcases List.mem_cons.mp hQ with rfl|hQ
         · exact multiply_vars K A k (hs A (by simp))
         · exact hs Q (by simp [hQ])
       · simp [polEval,hk] at h
   | div d=>
     cases st with
     | nil=>simp [polEval] at h
     | cons A st=>
       by_cases hd':0<d
       · apply ih (divide A d::st) ht' ?_ (by simpa only [polEval,if_pos hd'] using h)
         intro Q hQ;rcases List.mem_cons.mp hQ with rfl|hQ
         · exact divide_vars K A d (hs A (by simp))
         · exact hs Q (by simp [hQ])
       · simp [polEval,hd'] at h
   | sat=>
     cases st with
     | nil=>simp [polEval] at h
     | cons A st=>
       apply ih (saturate A::st) ht' ?_ h
       intro Q hQ;rcases List.mem_cons.mp hQ with rfl|hQ
       · exact saturate_vars K A (hs A (by simp))
       · exact hs Q (by simp [hQ])
#print axioms row_fits
#print axioms pol_vars
end L3Emitter.NativeRuntimeSupport

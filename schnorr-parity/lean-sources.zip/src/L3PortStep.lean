import L3PortFinish

namespace L3.Fam
open L3 EREF EREF.GeneralRED StI
variable (F : Fam)

def wireStart (hm : 1≤F.V) (g p bit : Nat) (t : StI F.V) : StI F.V :=
  (t.EQ hm (F.port g p (F.bitX bit) : Int) (F.port g p (F.bitY bit) : Int)).2

theorem wireFold_fixed (g p bit cb q : Nat) (xs : List Nat) (base u : StI F.V)
    (hk : Keeps2 base u) :
    xs.foldl (F.wireSplit g p bit cb q) u =
    xs.foldl (fun v j => v.split (F.wireC base g p j cb q) (F.wireVs g p bit)) u := by
  induction xs generalizing u with
  | nil => rfl
  | cons j xs ih =>
    rw [List.foldl_cons,List.foldl_cons,ih _ (keeps2_trans hk (F.wireSplit_keeps _ _ _ _ _ u j))]
    congr 1
    unfold wireSplit
    rw [F.wireC_keeps hk]

theorem portEqStep_factor (hm : 1≤F.V) (g p bit cb : Nat) (t : StI F.V) :
    F.portEqStep hm g bit cb t p = F.wireFinish g p cb (t.s.var+1)
      (F.wireSplits g p bit cb (t.s.var+1) (F.wireStart hm g p bit t)) := by
  let u := F.wireStart hm g p bit t
  have hu : Keeps2 t u := keeps2_EQ _ hm _ _
  let v := F.wireSplits g p bit cb (t.s.var+1) u
  have kv : Keeps2 t v := keeps2_trans hu
    (keeps2_foldl _ _ (F.wireSplit_keeps g p bit cb (t.s.var+1)) u)
  have ve : v=(List.range' 1 (F.k+g-1)).foldl
      (fun w j => w.split (F.wireC t g p j cb (t.s.var+1)) (F.wireVs g p bit)) u :=
    F.wireFold_fixed _ _ _ _ _ _ t u hu
  have c : F.wireCoverC v g p cb (t.s.var+1)=F.wireCoverC t g p cb (t.s.var+1) := by
    simp only [wireCoverC,kv.2.1.1,kv.2.2.2.2.2.2]
  change F.portEqStep hm g bit cb t p = F.wireFinish g p cb (t.s.var+1) v
  unfold wireFinish
  rw [c,ve]
  rfl

theorem wireStart_inv (hk : 2≤F.k) (hm : 1≤F.V) (g p bit cb : Nat) (t : StI F.V)
    (ht : F.Good3 t) (hg : g<F.s) (hp : p<2) (hb : bit<2)
    (hc : 1≤cb ∧ cb≤t.s.var) (hr : ∀h<g,F.GateRecord bit cb h t) :
    F.WireInv g p bit cb (t.s.var+1) (F.wireStart hm g p bit t) := by
  have keeps : Keeps2 t (F.wireStart hm g p bit t) := keeps2_EQ _ hm _ _
  have hV := t.var_ge
  have hx := F.port_le g p _ hg (by omega) (F.bitX_lt hk bit hb)
  have hy := F.port_le g p _ hg (by omega) (F.bitY_lt hk bit hb)
  have hxp := F.port_pos g p (F.bitX bit)
  have hyp := F.port_pos g p (F.bitY bit)
  have hPV := F.port_bound_le_V
  refine ⟨F.Good3_of_keeps2 keeps ht,?_,?_,?_,?_⟩
  · intro h hh; exact F.GateRecord_keeps keeps bit cb h rfl (hr h hh)
  · change Cmd.eqDef _ _ _∈t.s.cmds ++ [.eqDef _ (t.s.chk1 _) (t.s.chk1 _)]
    rw [StI.chk1_eq t _ (by simp; omega),StI.chk1_eq t _ (by simp; omega)]
    simp
  · change 1≤cb ∧ cb≤t.s.var+1; omega
  · change 1≤t.s.var+1 ∧ t.s.var+1≤t.s.var+1; omega

theorem wireStart_obls (hm : 1≤F.V) (g p bit : Nat) (t : StI F.V)
    (hc : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.wireStart hm g p bit t).s.cmds := by
  change ObligationsChecked F.db5 (t.s.cmds ++ [.eqDef _ _ _])
  apply obligations_append _ _ _ hc
  intro o ho; simp [obls] at ho

/-- The entire actual portEqStep, including its fresh EQ, all selected-wire
    splits, the selector sum, and forcing-consumer clause, is checked. -/
theorem portEqStep_obls (hk : 2≤F.k) (hs : 1≤F.s) (hm : 1≤F.V)
    (g p bit cb : Nat) (t : StI F.V) (ht : F.Good3 t)
    (hg1 : 1≤g) (hg : g<F.s) (hp : p<2) (hb : bit<2)
    (hc : 1≤cb ∧ cb≤t.s.var) (hr : ∀h<g,F.GateRecord bit cb h t)
    (ho : ObligationsChecked F.db5 t.s.cmds) :
    ObligationsChecked F.db5 (F.portEqStep hm g bit cb t p).s.cmds := by
  rw [F.portEqStep_factor]
  have hi := F.wireStart_inv hk hm g p bit cb t ht hg hp hb hc hr
  have he := F.wireStart_obls hm g p bit t ho
  obtain ⟨hinv,hchecked⟩ := F.wireSplits_obls hk hs _ g p bit cb (t.s.var+1) hg hp hb hi he
  exact F.wireFinish_obls hk hs _ g p bit cb (t.s.var+1) hg1 hg hp hinv
    (F.wireSplits_roots hk _ g p bit cb (t.s.var+1) hg hp hb hi) hchecked

#print axioms portEqStep_factor
#print axioms portEqStep_obls
end L3.Fam

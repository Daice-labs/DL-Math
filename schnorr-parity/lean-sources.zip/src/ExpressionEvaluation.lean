import EvaluationTree

namespace L3Emitter.ExpressionEvaluation
open EREF EREF.GeneralRED REDWitness AliasNetwork EvaluationTree GuardedGatePOL
variable {base:List Row}

/-- Compile the same coordinate once; the proof tree uses its saved references. -/
def build (α:Val) : Expr→Net base→Tree×Net base
  | .lit b,z=>(.leaf b (eval α b),z)
  | .and a b,z=>
    let x:=build α a z
    let y:=build α b x.2
    let q:=AND [x.1.root,y.1.root] y.2
    (.node true x.1 y.1 q.1,q.2)
  | .or a b,z=>
    let x:=build α a z
    let y:=build α b x.2
    let q:=OR [x.1.root,y.1.root] y.2
    (.node false x.1 y.1 q.1,q.2)
  | .mux c a b,z=>
    let x:=build α c z
    let y:=build α a x.2
    let v:=build α b y.2
    let l:=AND [x.1.root,y.1.root] v.2
    let r:=AND [neg x.1.root,v.1.root] l.2
    let q:=OR [l.1,r.1] r.2
    (.node false (.node true x.1 y.1 l.1) (.node true (.flip x.1) v.1 r.1) q.1,q.2)

theorem binding (α:Val) (e:Expr) (z:Net base) :
    ((build α e z).1.root,(build α e z).2)=e.compile z := by
  induction e generalizing z with
  | lit b=>rfl
  | and a b ha hb=>
    have hx:=ha z;have hy:=hb (build α a z).2
    change _ = AND [(a.compile z).1,(b.compile (a.compile z).2).1] (b.compile (a.compile z).2).2
    rw [←hx,←hy];rfl
  | or a b ha hb=>
    have hx:=ha z;have hy:=hb (build α a z).2
    change _ = OR [(a.compile z).1,(b.compile (a.compile z).2).1] (b.compile (a.compile z).2).2
    rw [←hx,←hy];rfl
  | mux c a b hc ha hb=>
    have hx:=hc z;have hy:=ha (build α c z).2;have hv:=hb (build α a (build α c z).2).2
    change _ = MUX (c.compile z).1 (a.compile (c.compile z).2).1
      (b.compile (a.compile (c.compile z).2).2).1 (b.compile (a.compile (c.compile z).2).2).2
    rw [←hx,←hy,←hv];rfl

theorem retains (α:Val) (e:Expr) (z:Net base) :∀R∈z.rows,R∈(build α e z).2.rows := by
  have h:=congrArg Prod.snd (binding α e z)
  rw [h];exact e.extends z

theorem ready (α:Val) (e:Expr) (z:Net base) :(build α e z).1.Ready (build α e z).2.rows := by
  induction e generalizing z with
  | lit b=>trivial
  | and a b ha hb=>
    let x:=build α a z;let y:=build α b x.2
    have keep:∀R∈y.2.rows,R∈(AND [x.1.root,y.1.root] y.2).2.rows:=push_retains y.2 true _
    exact ⟨(ha z).mono (fun R h=>keep R (retains α b x.2 R h)),(hb x.2).mono keep,actual_and y.2 _ _⟩
  | or a b ha hb=>
    let x:=build α a z;let y:=build α b x.2
    have keep:∀R∈y.2.rows,R∈(OR [x.1.root,y.1.root] y.2).2.rows:=push_retains y.2 false _
    exact ⟨(ha z).mono (fun R h=>keep R (retains α b x.2 R h)),(hb x.2).mono keep,actual_or y.2 _ _⟩
  | mux c a b hc ha hb=>
    let x:=build α c z;let y:=build α a x.2;let v:=build α b y.2
    let l:=AND [x.1.root,y.1.root] v.2
    let r:=AND [neg x.1.root,v.1.root] l.2
    let q:=OR [l.1,r.1] r.2
    have kr:∀R∈r.2.rows,R∈q.2.rows:=push_retains r.2 false _
    have kl:∀R∈l.2.rows,R∈q.2.rows:=fun R h=>kr R (push_retains l.2 true _ R h)
    have kv:∀R∈v.2.rows,R∈q.2.rows:=fun R h=>kl R (push_retains v.2 true _ R h)
    have ky:∀R∈y.2.rows,R∈q.2.rows:=fun R h=>kv R (retains α b y.2 R h)
    have kx:∀R∈x.2.rows,R∈q.2.rows:=fun R h=>ky R (retains α a x.2 R h)
    exact ⟨⟨(hc z).mono kx,(ha x.2).mono ky,(actual_and v.2 _ _).mono kl⟩,
      ⟨(hc z).mono kx,(hb y.2).mono kv,(actual_and l.2 _ _).mono kr⟩,actual_or r.2 _ _⟩

theorem value (α:Val) (e:Expr) (z:Net base) :(build α e z).1.value=e.value α := by
  induction e generalizing z with
  | lit b=>rfl
  | and a b ha hb=>simp only [build,Tree.value,GuardedGatePOL.value,↓reduceIte,ha,hb,Expr.value]
  | or a b ha hb=>simp only [build,Tree.value,GuardedGatePOL.value,Bool.false_eq_true,↓reduceIte,ha,hb,Expr.value]
  | mux c a b hc ha hb=>
    simp only [build,Tree.value,GuardedGatePOL.value,Bool.false_eq_true,↓reduceIte,hc,ha,hb,Expr.value]
    cases c.value α <;> simp

def leaves : Expr→List Bit
  | .lit b=>[b]
  | .and a b=>leaves a++leaves b
  | .or a b=>leaves a++leaves b
  | .mux c a b=>leaves c++leaves a++leaves b

theorem leaf_binding (α:Val) (e:Expr) (z:Net base) (x:Bit×Bool)
    (hx:x∈(build α e z).1.leaves) :x.1∈leaves e ∧ x.2=eval α x.1 := by
  induction e generalizing z with
  | lit b=>obtain rfl:=List.mem_singleton.mp hx;exact ⟨by simp [leaves],rfl⟩
  | and a b ha hb=>
    rcases List.mem_append.mp hx with h|h
    · have h':=ha z h;exact ⟨List.mem_append_left _ h'.1,h'.2⟩
    · have h':=hb (build α a z).2 h;exact ⟨List.mem_append_right _ h'.1,h'.2⟩
  | or a b ha hb=>
    rcases List.mem_append.mp hx with h|h
    · have h':=ha z h;exact ⟨List.mem_append_left _ h'.1,h'.2⟩
    · have h':=hb (build α a z).2 h;exact ⟨List.mem_append_right _ h'.1,h'.2⟩
  | mux c a b hc ha hb=>
    change x∈((build α c z).1.leaves++(build α a (build α c z).2).1.leaves)++
      ((build α c z).1.leaves++(build α b (build α a (build α c z).2).2).1.leaves) at hx
    rcases List.mem_append.mp hx with h|h
    · rcases List.mem_append.mp h with h|h
      · have h':=hc z h;exact ⟨List.mem_append_left _ (List.mem_append_left _ h'.1),h'.2⟩
      · have h':=ha (build α c z).2 h;exact ⟨List.mem_append_left _ (List.mem_append_right _ h'.1),h'.2⟩
    · rcases List.mem_append.mp h with h|h
      · have h':=hc z h;exact ⟨List.mem_append_left _ (List.mem_append_left _ h'.1),h'.2⟩
      · have h':=hb (build α a (build α c z).2).2 h;exact ⟨List.mem_append_right _ h'.1,h'.2⟩

/-- Explicit evaluation derivation. Premises are guarded input rows, not an inference oracle. -/
theorem checks (α:Val) (e:Expr) (z:Net base) (D:List Row) (G:List Int) (hg:Valid G)
    (hd:∀R∈(e.compile z).2.rows,R∈D)
    (ha:∀b∈leaves e,guarded G (sign (eval α b) b)∈D) :
    AliasProgram.check D ((build α e z).1.program G D)=some (D++(build α e z).1.rows G) ∧
    guarded G (sign (e.value α) (e.compile z).1)∈D++(build α e z).1.rows G := by
  have hr:=(ready α e z).mono (fun R h=>hd R (by rw [←congrArg Prod.snd (binding α e z)];exact h))
  have hh:(build α e z).1.Assumptions D G:=by
    intro x hx
    have h:=leaf_binding α e z x hx
    rw [h.2];exact ha x.1 h.1
  refine ⟨(build α e z).1.checks D G hg hr hh,?_⟩
  have h:=(build α e z).1.output_mem D G hh
  have he:(build α e z).1.root=(e.compile z).1:=congrArg Prod.fst (binding α e z)
  rw [value,he] at h
  exact h

#print axioms binding
#print axioms ready
#print axioms value
#print axioms leaf_binding
#print axioms checks
end L3Emitter.ExpressionEvaluation

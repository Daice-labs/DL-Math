import NativeParserStackShapes
namespace L3Emitter.NativeParserDepth
open EREF

/-- Native parser stack counter after every operand/operator. Multiplication
and division read the scalar as a temporary operand before consuming it. -/
def states : List Tok→Nat→List Nat
 | [],d=>[d]
 | .ref _::ts,d=>d::states ts (d+1)
 | .lit _::ts,d=>d::states ts (d+1)
 | .add::ts,d=>d::states ts (d-1)
 | .mul _::ts,d=>d::(d+1)::states ts d
 | .div _::ts,d=>d::(d+1)::states ts d
 | .sat::ts,d=>d::states ts d

theorem depth_bound (ts:List Tok) (d:Nat):∀x∈states ts d,x≤d+ts.length+1:=by
 induction ts generalizing d with
 | nil=>intro x hx;obtain rfl:=List.mem_singleton.mp hx;omega
 | cons t ts ih=>
   cases t with
   | ref _ | lit _=>
     intro x hx
     rcases List.mem_cons.mp hx with rfl|hx
     · simp <;> omega
     · have hb:=ih (d+1) x hx;simp only [List.length_cons];omega
   | add=>
     intro x hx
     rcases List.mem_cons.mp hx with rfl|hx
     · simp <;> omega
     · have hb:=ih (d-1) x hx;simp only [List.length_cons];omega
   | mul _ | div _=>
     intro x hx
     rcases List.mem_cons.mp hx with rfl|hx
     · simp <;> omega
     rcases List.mem_cons.mp hx with rfl|hx
     · simp <;> omega
     · have hb:=ih d x hx;simp only [List.length_cons];omega
   | sat=>
     intro x hx
     rcases List.mem_cons.mp hx with rfl|hx
     · simp <;> omega
     · have hb:=ih d x hx;simp only [List.length_cons];omega

def InRange (ts:List Tok):Prop:=∀x∈states ts 0,x<2^64

theorem of_length (ts:List Tok) (h:ts.length+1<2^64):InRange ts:=by
 intro x hx
 have hb:=depth_bound ts 0 x hx
 omega

/-- Each intermediate source counter fits the 64-bit usize representation.
This includes the transient scalar slot, not only post-operation depths. -/
theorem machine_counters (ts:List Tok) (h:ts.length+1<2^64):
 ∀x∈states ts 0,(UInt64.ofNat x).toNat=x:=by
 intro x hx
 exact UInt64.toNat_ofNat_of_lt' (of_length ts h x hx)

def FileRange (cs:List CanonicalScopeKernel.Command):Prop:=
 ∀e∈cs.flatMap CanonicalFileGrammar.commandEvents,
 match e with | .pol ts=>ts.length+1<2^64 | _=>True

theorem file_counters (cs:List CanonicalScopeKernel.Command) (h:FileRange cs):
 ∀ts,CanonicalLineParser.Event.pol ts∈cs.flatMap CanonicalFileGrammar.commandEvents→
 ∀x∈states ts 0,(UInt64.ofNat x).toNat=x:=by
 intro ts ht
 exact machine_counters ts (h (.pol ts) ht)
#print axioms machine_counters
#print axioms file_counters
end L3Emitter.NativeParserDepth

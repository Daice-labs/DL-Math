import ConstructionFreshBounds
import ConstructionNormalizationBounds
import RecordedSplitCost
import RecordedStateFold
import RecordedDefinitionSuffix
import RecordedStage4Cost

namespace L3Emitter.ConstructionFoldBounds
open EREF EREF.GeneralRED RecordedScopedTrace CanonicalReplayEnvelope RecordedReplayCost
open ConstructionLocalTools ConstructionFreshBounds

theorem singleton (B : Nat) (c : Step) (h : BoundedGoals B (AuditLocalCosts.certificates c)) :
    BoundedProgram B [c] := by
  intro d hd
  obtain rfl:=List.mem_singleton.mp hd
  exact h

theorem empty (B : Nat) : BoundedProgram B [] := by intro c hc;simp at hc

theorem defs (D : List Row) (cs : List L3.Cmd) :
    BoundedProgram 3 (RecordedFrontendDefs.emit D cs) := by
  induction cs generalizing D with
  | nil=>exact empty 3
  | cons c cs ih=>
    cases c with
    | orDef q xs=>exact append 3 _ _ (definitions D q _) (ih _)
    | andDef q xs=>exact append 3 _ _ (definitions D q _) (ih _)
    | eqDef q a b=>exact append 3 _ _ (definitions D q _) (ih _)
    | rup c=>
      intro d hd
      rcases List.mem_cons.mp hd with rfl|hd
      · exact pol 3 _ _
      · exact ih _ d hd

theorem suffix (m : Nat) (D : List Row) (t u : L3.StI m) :
    BoundedProgram 3 (RecordedDefinitionSuffix.program D t u) := defs _ _

theorem fold {σ α : Type} (B : Nat) (next : σ→α→σ) (emit : σ→α→Program)
    (s : σ) (xs : List α) (h : ∀s x,BoundedProgram B (emit s x)) :
    BoundedProgram B (RecordedStateFold.run next emit s xs) := by
  induction xs generalizing s with
  | nil=>exact empty B
  | cons x xs ih=>exact append B _ _ (h s x) (ih _)

theorem split (B : Nat) (leaf : List Row→List Int→RecordedRefutation.Certificate)
    (D : List Row) (c vs : List Int) (hb : 7≤B)
    (hl : ∀D c,tokens (leaf D c)≤B) : BoundedProgram B (RecordedSplit.run leaf D c vs) := by
  induction vs generalizing D c with
  | nil=>exact singleton B _ (consequence B _ _ (hl D c))
  | cons v vs ih=>
    apply append B
    · exact append B _ _ (ih _ _) (ih _ _)
    · apply singleton B
      apply consequence B
      exact (RecordedSplitCost.node_tokens D c v).le.trans hb

theorem stage4 (F : L3.Fam) (t : L3.StI F.V) (D : List Row) (js : List RecordedStage4.Job) :
    BoundedProgram 13 (RecordedStage4.run F t D js) := by
  induction js generalizing D with
  | nil=>exact empty 13
  | cons j js ih=>
    intro c hc
    rcases List.mem_cons.mp hc with rfl|hc
    · exact consequence 13 _ _ (RecordedStage4Cost.proof_tokens F t D j).le
    · exact ih _ c hc

theorem throughStage4 (k s : Nat) (hs : 1≤s) :
    BoundedProgram (2*k+13) (RecordedStage4Assembly.throughStage4 k s hs) := by
  apply append
  · apply append
    · exact CanonicalFamilyEnvelope.bounded_mono _ _ _ (by omega)
        (ConstructionNormalizationBounds.normalization k s)
    · exact CanonicalFamilyEnvelope.bounded_mono _ _ _ (by omega) (defs _ _)
  · exact CanonicalFamilyEnvelope.bounded_mono _ _ _ (by omega) (stage4 _ _ _ _)

#print axioms defs
#print axioms fold
#print axioms split
#print axioms throughStage4
end L3Emitter.ConstructionFoldBounds

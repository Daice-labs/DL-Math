import LowerTopologyBank
import PrefixALO
namespace L3Emitter.LowerSelectorALO
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram FamilyNamespace FamilyRows SelectedVectorOneHot

def full (n:Nat) (hn:2≤n) (t p:Nat):List Int:=
  List.ofFn fun i:Fin (AliasAssembly.width (n+1))=>(LowerTransferImage.wire n hn (.sel t p i.val)).val

def suffix (n:Nat) (hn:2≤n) (t p:Nat):List Int:=(full n hn t p).drop (n+t)

theorem full_valid (n:Nat) (hn:2≤n) (t p:Nat):Valid (full n hn t p):=by
  intro x hx;obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hx
  exact (LowerTransferImage.wire n hn (.sel t p i.val)).property

theorem prefix_eq (n:Nat) (hn:2≤n) (t p:Nat) (ht:t<RankConstruction.width (n+1)):
    (full n hn t p).take (n+t)=LowerSelectorAMO.xs n hn t p:=by
  apply List.ext_getElem
  · simp only [List.length_take,full,List.length_ofFn,LowerSelectorAMO.xs]
    exact min_eq_left (by unfold AliasAssembly.width;omega)
  · intro i hi hj
    simp [full,LowerSelectorAMO.xs]

theorem split_eq (n:Nat) (hn:2≤n) (t p:Nat) (ht:t<RankConstruction.width (n+1)):
    LowerSelectorAMO.xs n hn t p++suffix n hn t p=full n hn t p:=by
  rw [←prefix_eq n hn t p ht]
  exact List.take_append_drop _ _

theorem full_alo (n:Nat) (hn:2≤n) (t p:Nat) (ht:t<RankConstruction.width (n+1)) (hp:p<2):
    clause (full n hn t p)∈LowerTopologyBank.result n hn:=by
  obtain ⟨r,he,heq⟩:=LowerTransferImage.port_exists n hn t p ht hp
  have hv:=RawUnaryBank.port_present n hn r.val r.property
  have hr:=RawLowerInputBank.port_present n hn r.val.1 hv
  have h:=((RankPortBank.original_to_rank_port_bank n hn).2 r.val.1.1 hr).1.1
  have heq':full n hn t p=sourceLiterals r.val.1.1.2.2:=by
    apply congrArg List.ofFn
    funext i
    simp [full,LowerTransferImage.wire,he,i.isLt,RawInputSelection.coordinate,sourceLiterals]
  rw [heq']
  exact List.mem_append_left _ (RankZeroTransport.rank_kept n hn _ h)

theorem forbidden_unit (n:Nat) (hn:2≤n) (t p i:Nat) (ht:t<RankConstruction.width (n+1)) (hp:p<2)
    (hlo:n+t ≤ i) (hi:i<AliasAssembly.width (n+1)):
    clause [-(LowerTransferImage.wire n hn (.sel t p i)).val]∈LowerTopologyBank.result n hn:=by
  obtain ⟨r,he,heq⟩:=LowerTransferImage.port_exists n hn t p ht hp
  have hv:=RawUnaryBank.port_present n hn r.val r.property
  have hr:=RawLowerInputBank.port_present n hn r.val.1 hv
  have hur:i-n < RankConstruction.width (n+1):=by unfold AliasAssembly.width at hi;omega
  have hrt:r.val.1.1.1=t:=congrArg Prod.fst heq
  have h:=LowerTopologyBank.all_units n hn r.val.1.1 hr ⟨i-n,hur⟩ (by change r.val.1.1.1 ≤ i-n;rw [hrt];omega)
  have hcoord:TopologyContext.coord n ⟨i-n,hur⟩=⟨i,hi⟩:=by apply Fin.ext;dsimp [TopologyContext.coord];omega
  rw [hcoord] at h
  simpa only [LowerTransferImage.wire,he,dif_pos hi,RawInputSelection.coordinate] using h

theorem suffix_units (n:Nat) (hn:2≤n) (t p:Nat) (ht:t<RankConstruction.width (n+1)) (hp:p<2):
    ∀x∈suffix n hn t p,clause [-x]∈LowerTopologyBank.result n hn:=by
  intro x hx
  obtain ⟨i,hi,he⟩:=List.mem_iff_getElem.mp hx
  have hlen:(full n hn t p).length=AliasAssembly.width (n+1):=by simp [full]
  have hi':n+t+i<AliasAssembly.width (n+1):=by
    change i<((full n hn t p).drop (n+t)).length at hi
    rw [List.length_drop,hlen] at hi;omega
  have h:=forbidden_unit n hn t p (n+t+i) ht hp (by omega) hi'
  have he':x=(LowerTransferImage.wire n hn (.sel t p (n+t+i))).val:=by
    rw [←he]
    simp [suffix,full]
  rw [he'];exact h

def leaf (n:Nat) (hn:2≤n) (j:RankPortBank.Job) (D:List Row):Program:=
  [(clause (LowerSelectorAMO.xs n hn j.1 j.2),PrefixALO.tape D (LowerSelectorAMO.xs n hn j.1 j.2) (suffix n hn j.1 j.2))]
def rows (n:Nat) (hn:2≤n) (j:RankPortBank.Job):List Row:=[clause (LowerSelectorAMO.xs n hn j.1 j.2)]

theorem leaf_check (n:Nat) (hn:2≤n) (j:RankPortBank.Job) (hj:RankPortBank.ValidJob n j)
    (D:List Row) (hd:∀R∈LowerTopologyBank.result n hn,R∈D):
    check D (leaf n hn j D)=some (D++rows n hn j):=by
  have h:=PrefixALO.checks D (LowerSelectorAMO.xs n hn j.1 j.2) (suffix n hn j.1 j.2)
    (LowerSelectorAMO.valid n hn j.1 j.2)
    (fun x hx=>full_valid n hn j.1 j.2 x (List.mem_of_mem_drop hx))
    (by rw [split_eq n hn j.1 j.2 hj.1];exact hd _ (full_alo n hn j.1 j.2 hj.1 hj.2))
    (fun x hx=>hd _ (suffix_units n hn j.1 j.2 hj.1 hj.2 x hx))
  simp only [leaf,rows,check,h,↓reduceIte]

def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (RankPortBank.jobs n) (LowerTopologyBank.result n hn)
def result (n:Nat) (hn:2≤n):=LowerTopologyBank.result n hn++RetainedBlockFold.body (rows n hn) (RankPortBank.jobs n)

theorem checks (n:Nat) (hn:2≤n):check (LowerTopologyBank.result n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (RankPortBank.ValidJob n) (leaf_check n hn) _
    (fun j hj=>(RankPortBank.job_mem n j).mp hj) _ (fun _ h=>h)
theorem original_to_selector_ALO (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (LowerTopologyBank.original_to_lower_topology n hn) (check_trace _ _ _ (checks n hn))

theorem image_eq (n:Nat) (hn:2≤n) (t p:Nat):
    LowerTransferImage.image n hn (InputSwap.oneHot n t p true)=clause (LowerSelectorAMO.xs n hn t p):=by
  simp only [LowerTransferImage.image,InputSwap.oneHot,↓reduceIte,List.map_map,GuardedGatePOL.sign,clause,
    LowerSelectorAMO.xs,List.map_ofFn]
  congr 1
  apply List.ext_getElem
  · simp
  · intro i hi hj;simp

theorem all_ALO_images (n:Nat) (hn:2≤n) (t p:Nat) (ht:t<3*n-4) (hp:p<2):
    LowerTransferImage.image n hn (InputSwap.oneHot n t p true)∈result n hn:=by
  rw [image_eq]
  exact List.mem_append_right _ (RetainedBlockFold.contains (rows n hn) (RankPortBank.jobs n) (t,p)
    ((RankPortBank.job_mem n _).mpr ⟨by unfold RankConstruction.width;omega,hp⟩) _ (List.mem_singleton_self _))
#print axioms original_to_selector_ALO
#print axioms forbidden_unit
#print axioms all_ALO_images
end L3Emitter.LowerSelectorALO

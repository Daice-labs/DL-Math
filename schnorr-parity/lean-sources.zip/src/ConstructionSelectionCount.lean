import ConstructionFrontendCount
import ConstructionCountTools
import RecordedForcingSelection
import ForcingSize

namespace L3Emitter.ConstructionSelectionCount
open EREF EREF.GeneralRED L3 ConstructionFrontendCountTools

theorem priority_definitions (m : Nat) (a : Int) (xs : List Int) :
    list (PriorityBank.cmds m a xs)=6*xs.length := by
  induction xs generalizing m a with
  | nil => rfl
  | cons x xs ih =>
    simp only [PriorityBank.cmds,list,List.map_cons,List.sum_cons,
      ConstructionFrontendCountTools.command,List.length_cons,List.length_nil]
    change 3+ (3+list (PriorityBank.cmds (m+2) (m+2:Int) xs))=6*(xs.length+1)
    rw [ih];omega

/-- Main-command count, including all extension definitions and selection POLs. -/
theorem priority (D : List EREF.Row) (m : Nat) (xs : List Int) :
    (RecordedPriority.program D m xs).length=xs.length^2+9*xs.length+3 := by
  rw [RecordedPriority.program,List.length_append,definitions,
    ConstructionCountTools.polProgram_length,PrioritySize.selection_lines,PriorityBank.nodes_length]
  have h:=priority_definitions (m+1) (m+1:Int) xs
  change list (.orDef (m+1) [] :: PriorityBank.cmds (m+1) (m+1:Int) xs)+_=_
  change 1+list (PriorityBank.cmds (m+1) (m+1:Int) xs)+_=_
  rw [h];omega

theorem branch_inputs (k : Nat) (hk : 3≤k) :
    (FrontendSelection.xs k hk).length≤9*k^2 := by
  have h:=congrArg List.length (BranchChoices.chosen_literals k hk)
  simp only [List.length_map,PriorityBank.choices,PriorityBank.nodes_length] at h
  have hc:=ForcingSize.chosen_bound k hk
  simpa only [List.length_map,PriorityBank.nodes_length] using h ▸ hc

theorem branches (k : Nat) (hk : 3≤k) :
    (RecordedBranchSelection.program k hk).length≤1000*(k+1)^4 := by
  have hf:=ConstructionFrontendCount.parity k (by omega)
  have hx:=branch_inputs k hk
  have hsq:=Nat.mul_le_mul hx hx
  have hp:(k+1)^2≤(k+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have hk2:k^2≤(k+1)^2:=Nat.pow_le_pow_left (by omega) 2
  have hk4:k^4≤(k+1)^4:=Nat.pow_le_pow_left (by omega) 4
  simp only [RecordedBranchSelection.program,List.length_append,priority,
    List.length_cons,List.length_nil]
  nlinarith

theorem forcing_step (D : List EREF.Row) (k : Nat) (hk : 3≤k)
    (c : RankProjection.Choice (3*k-4)) (m : Nat) :
    (RecordedForcing.stepProgram D k hk c m).length=21 := by
  rw [RecordedForcing.stepProgram,List.length_append,definitions,
    ConstructionCountTools.polProgram_length,ForcingSize.derived_lines]
  rfl

theorem forcing_stage (D : List EREF.Row) (k : Nat) (hk : 3≤k) (m : Nat)
    (cs : List (RankProjection.Choice (3*k-4))) :
    (RecordedForcing.stageProgram D k hk m cs).length=21*cs.length := by
  induction cs generalizing D m with
  | nil=>rfl
  | cons c cs ih=>
    rw [RecordedForcing.stageProgram,List.length_append,forcing_step,ih,List.length_cons]
    omega

theorem forcing (k : Nat) (hk : 3≤k) :
    (RecordedForcing.program k hk).length≤189*k^2+1 := by
  simp only [RecordedForcing.program,List.length_append,forcing_stage,List.length_cons,List.length_nil]
  have h:=ForcingSize.chosen_bound k hk
  omega

theorem forcing_inputs (k : Nat) (hk : 3≤k) :
    (ForcingFamily.raw k hk).length≤36*k^2 := by
  rw [ForcingFamily.raw,ForcingSize.raw_length]
  have h:=ForcingSize.chosen_bound k hk
  omega

/-- Bound for the actual full selected forcing prefix. Unit: main commands. -/
theorem selected (k : Nat) (hk : 3≤k) :
    (RecordedForcingSelection.program k hk).length≤3000*(k+1)^4 := by
  have hb:=branches k hk
  have hf:=forcing k hk
  have hx:=forcing_inputs k hk
  have hsq:=Nat.mul_le_mul hx hx
  have hp:(k+1)^2≤(k+1)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have hk2:k^2≤(k+1)^2:=Nat.pow_le_pow_left (by omega) 2
  have hk4:k^4≤(k+1)^4:=Nat.pow_le_pow_left (by omega) 4
  simp only [RecordedForcingSelection.program,List.length_append,priority]
  nlinarith

#print axioms priority
#print axioms branches
#print axioms selected
end L3Emitter.ConstructionSelectionCount

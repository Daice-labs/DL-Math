import GammaEarlierPorts
namespace L3Emitter.GammaInductiveStep
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
abbrev Job:=BetaPort.Job

def pairs:List (Bool×Bool):=[(false,false),(false,true),(true,false),(true,true)]
def preRows (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool):=
  GammaEarlierPorts.sourceRows n hn j i++GammaEarlierPorts.body n hn j i t u pairs
def pre (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (D:List Row):=
  GammaEarlierPorts.sourceProgram n hn j i D++
    GammaEarlierPorts.run n hn j i t u (D++GammaEarlierPorts.sourceRows n hn j i) pairs

theorem pre_checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u:Bool) (D:List Row)
    (ht:∀a,a<n+1 → a≠0 → i.val=a-1 → t=PrimaryValueSeeds.truth (PrimaryAliasBank.cfg n hn) (PrimaryInputLinks.d n a j.2))
    (hd:∀R∈GammaComparisonBank.result n hn,R∈D)
    (hi:∀b,PortValueBank.Earlier n hn (GammaCofactorValue.g j) j.2 i t u b D):
    check D (pre n hn j i t u D)=some (D++preRows n hn j i t u):=by
  have h0:=GammaEarlierPorts.source_checks n hn j hj i D hd
  have h1:=GammaEarlierPorts.run_check n hn j hj i t u (D++GammaEarlierPorts.sourceRows n hn j i) pairs ht
    ⟨fun R h=>List.mem_append_left _ (hd R h),fun b g hg=>List.mem_append_left _ (hi b g hg),by
      intro side;apply List.mem_append_right;cases side <;> simp [GammaEarlierPorts.sourceRows]⟩
  simpa only [pre,preRows,List.append_assoc] using check_append _ _ _ _ _ h0 h1

theorem hypotheses_present (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u side b:Bool):
    GammaPreservation.hypothesis n hn j u side b (GammaPortHypotheses.frame n hn j i t u)∈preRows n hn j i t u:=by
  apply List.mem_append_right
  apply List.mem_flatMap.mpr
  refine ⟨(side,b),?_,List.mem_append_right _ (List.mem_singleton_self _)⟩
  cases side <;> cases b <;> simp [pairs]

def rows (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u v:Bool):=
  preRows n hn j i t u++GammaPreservationBoth.rows n hn j u v (GammaPortHypotheses.frame n hn j i t u)
def program (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u v:Bool) (D:List Row):=
  pre n hn j i t u D++GammaPreservationBoth.program n hn j u v (GammaPortHypotheses.frame n hn j i t u)
    (D++preRows n hn j i t u)

def conclusion (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u v:Bool):=
  clause [-BetaAliasValue.choice j,-(GammaSourcePorts.q n hn j i).val,-sign u t,
    -sign v (CofactorValueRows.unary n hn (GammaCofactorValue.g j) u),sign v (CofactorValueRows.cofactor n hn (GammaCofactorValue.g j) j.2)]

/-- The gamma preservation step now constructs its earlier-port premises.
The only row-valued induction hypothesis is about strictly earlier gates. -/
theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u v:Bool) (D:List Row)
    (ht:∀a,a<n+1 → a≠0 → i.val=a-1 → t=PrimaryValueSeeds.truth (PrimaryAliasBank.cfg n hn) (PrimaryInputLinks.d n a j.2))
    (hd:∀R∈GammaComparisonBank.result n hn,R∈D)
    (hi:∀b,PortValueBank.Earlier n hn (GammaCofactorValue.g j) j.2 i t u b D):
    check D (program n hn j i t u v D)=some (D++rows n hn j i t u v):=by
  have h0:=pre_checks n hn j hj i t u D ht hd hi
  have h1:=GammaPreservationBoth.checks n hn j hj u v (GammaPortHypotheses.frame n hn j i t u)
    (by simp [GammaPortHypotheses.frame,Valid,(GammaSourcePorts.q n hn j i).property,sign_valid])
    (D++preRows n hn j i t u) (fun R h=>List.mem_append_left _ (hd R h))
    (fun side b=>List.mem_append_right _ (hypotheses_present n hn j i t u side b))
  simpa only [program,rows,List.append_assoc] using check_append _ _ _ _ _ h0 h1

theorem conclusion_present (n:Nat) (hn:2≤n) (j:Job n) (i:Fin (AliasAssembly.width (n+1))) (t:Bit) (u v:Bool):
    conclusion n hn j i t u v∈rows n hn j i t u v:=by
  apply List.mem_append_right
  apply List.mem_append_right
  exact List.mem_singleton_self _
#print axioms checks
#print axioms conclusion_present
end L3Emitter.GammaInductiveStep

import FamilyRows

open Classical
namespace L3Emitter.NamedWitness
open EREF EREF.GeneralRED FamilyNamespace FamilyRows

inductive Target where
  | wire (w : Wire)
  | bit (b : Bool)
  deriving DecidableEq, Repr

def Target.valid (k s : Nat) : Target → Prop
  | .wire w => FamilyNamespace.Valid k s w
  | .bit _ => True

def Target.eval (β : Wire → Bool) : Target → Bool
  | .wire w => β w
  | .bit b => b

def Target.image (k s : Nat) (t : Target) (h : t.valid k s) : EREF.GeneralRED.Image :=
  match t with
  | .wire w => .literal (encode k s w) (by have := (encode_bounds k s w h).1; omega)
  | .bit b => .constant b

def valuation (k s : Nat) (α : Val) : Wire → Bool := fun w => α (encode k s w)

theorem target_eval (k s : Nat) (t : Target) (h : t.valid k s) (α : Val) :
    (t.image k s h).eval α=t.eval (valuation k s α) := by
  cases t with
  | bit b => rfl
  | wire w =>
    have hp : (0:Int)<encode k s w := by exact_mod_cast (encode_bounds k s w h).1
    simp [Target.image,EREF.GeneralRED.Image.eval,Target.eval,valuation,hp]
    omega

noncomputable def witness (k s : Nat) (f : Wire → Target)
    (hf : ∀ w, FamilyNamespace.Valid k s w → (f w).valid k s) : Witness := fun v =>
  if h : ∃ w, FamilyNamespace.Valid k s w ∧ encode k s w=v then
    (f (Classical.choose h)).image k s (hf _ (Classical.choose_spec h).1)
  else if hz : v=0 then .constant false
  else .literal (v:Int) (by omega)

theorem at_wire (k s : Nat) (f : Wire → Target)
    (hf : ∀ w, FamilyNamespace.Valid k s w → (f w).valid k s)
    (w : Wire) (hw : FamilyNamespace.Valid k s w) (α : Val) :
    applyWitness (witness k s f hf) α (encode k s w) = (f w).eval (valuation k s α) := by
  have he : ∃ u, FamilyNamespace.Valid k s u ∧ encode k s u=encode k s w := ⟨w,hw,rfl⟩
  have hu : Classical.choose he=w :=
    encode_injective k s _ _ (Classical.choose_spec he).1 hw (Classical.choose_spec he).2
  unfold applyWitness witness
  simp only [dif_pos he]
  rw [target_eval]
  rw [hu]

def literalValue (β : Wire → Bool) (l : NamedLit) : Int :=
  if l.2 then b2i (β l.1) else 1-b2i (β l.1)

theorem literal_value (k s : Nat) (α : Val) (l : NamedLit)
    (hl : FamilyNamespace.Valid k s l.1) :
    litVal α (lit k s l)=literalValue (valuation k s α) l := by
  have hp : 0<encode k s l.1 := (encode_bounds k s _ hl).1
  rcases l with ⟨w,b⟩
  cases b <;> simp [lit,litVal,literalValue,valuation,hp,
    show ¬(encode k s w:Int)<0 by omega]

def value (β : Wire → Bool) (r : Spec) : Int :=
  (r.literals.map (literalValue β)).sum-r.rhs

theorem row_value_named (k s : Nat) (r : Spec) (hr : r.valid k s) (α : Val) :
    (r.row k s).val α=value (valuation k s α) r := by
  rw [row_value k s r hr]
  unfold REDWitness.sum value
  simp only [List.map_map,Function.comp_def]
  congr 2
  exact List.map_congr_left (by intro l hl; exact literal_value k s α l (hr l hl))

theorem subst_value (k s : Nat) (f : Wire → Target)
    (hf : ∀ w, FamilyNamespace.Valid k s w → (f w).valid k s)
    (r : Spec) (hr : r.valid k s) (α : Val) :
    (substRow (r.row k s) (witness k s f hf)).val α =
      value (fun w => (f w).eval (valuation k s α)) r := by
  rw [val_substRow,row_value_named k s r hr]
  unfold value
  congr 2
  apply List.map_congr_left
  intro l hl
  unfold literalValue valuation
  rw [at_wire k s f hf l.1 (hr l hl) α]
  rfl

#print axioms subst_value
end L3Emitter.NamedWitness

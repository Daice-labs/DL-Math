import GammaPreservationBoth
namespace L3Emitter.GammaPreservationBytes
open EREF AliasProgram PolTapeBytes PrioritySize

theorem prep_tokens (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u side v:Bool) (frame:List Int) (D:List Row):
    tokensCount (GammaPreservation.prep n hn j u side v frame D)=4+8*frame.length:=by
  simp [GammaPreservation.prep,GammaPreservation.pairs,tokensCount,ChoiceProjection.weakenTokens,
    ClauseTransport.padSteps,List.length_flatMap,List.map_map,Function.comp_def]
  omega

theorem side_tokens (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u side v:Bool) (frame:List Int) (D:List Row):
    tokensCount (GammaPreservation.program n hn j u side v frame D)=56+8*frame.length:=by
  simp only [GammaPreservation.program,tokens_append,prep_tokens,GammaPreservation.suffix,GammaValueJoin.token_count]
  omega

theorem both_tokens (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u v:Bool) (frame:List Int) (D:List Row):
    tokensCount (GammaPreservationBoth.program n hn j u v frame D)=116+16*frame.length:=by
  simp only [GammaPreservationBoth.program,tokens_append,side_tokens]
  simp [tokensCount,GammaValueJoin.joinTape,CommonGuardResolve.token_count]
  omega

-- This is a bound on the actual 23-command block. A global operand ceiling M(n)
-- and the remaining emitter stages are not supplied by this component theorem.
theorem bytes (n:Nat) (hn:2≤n) (j:BetaPort.Job n) (u v:Bool) (frame:List Int) (D:List Row) (M:Nat)
    (hb:∀cmd∈GammaPreservationBoth.program n hn j u v frame D,∀t∈cmd.2,Bounded M t):
    (emit (document (GammaPreservationBoth.program n hn j u v frame D))).length≤
      161+(116+16*frame.length)*(3+digits M):=by
  have h:=document_bound M _ hb
  rw [GammaPreservationBoth.command_count,both_tokens] at h
  exact h
#print axioms bytes
end L3Emitter.GammaPreservationBytes

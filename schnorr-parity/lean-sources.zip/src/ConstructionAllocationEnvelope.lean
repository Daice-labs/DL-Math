import ConstructionFamilyLocalBounds
import ConstructionFormulaScale

namespace L3Emitter.ConstructionAllocationEnvelope
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation AuditLocalCosts

/-- Unit: MAIN COMMANDS. This exact statistic is not a closed bound in n. -/
def mainCount (n : Nat) := (RecordedUniformFamily.emitter n).length

/-- Unit: STORED LOCAL CERTIFICATES, including every retained-frame goal. -/
theorem certificates (n : Nat) (hn : 2≤n) :
    certCount (RecordedUniformFamily.emitter n)≤
      mainCount n*(ConstructionFormulaScale.rows n+mainCount n) :=
  CanonicalAllocationBound.certificate_count 0 (RecordedUniformFamily.guard n) _ _ _
    (RecordedUniformFamily.recorded_refutation n hn).1

/-- No assumed local-token ceiling remains. Unit: TOTAL LOCAL POL TOKENS;
main POL tapes are deliberately not included in this statistic. -/
theorem local_tokens (n : Nat) (hn : 2≤n) :
    localTokenCount (RecordedUniformFamily.emitter n)≤
      (704*n+700)*(mainCount n*(ConstructionFormulaScale.rows n+mainCount n)) := by
  have ht:=CanonicalReplayEnvelope.total_tokens (704*n+700) _ (ConstructionFamilyLocalBounds.emitter n hn)
  have hc:=certificates n hn
  simpa only [Nat.mul_comm] using ht.trans (Nat.mul_le_mul_right (704*n+700) hc)

/-- Every allocated physical row is counted, including rows deleted when a
subproof closes. Only the global MAIN COMMAND count remains unclosed here. -/
theorem allocations (n : Nat) (hn : 2≤n) :
    NativeRecordedAllocation.program (RecordedUniformFamily.emitter n)≤
      2*mainCount n+mainCount n*(ConstructionFormulaScale.rows n+mainCount n)*(704*n+701) := by
  exact CanonicalAllocationBound.family_allocation_bound n (704*n+700) hn
    (ConstructionFamilyLocalBounds.emitter n hn)

/-- Once a construction-specific polynomial main count is proved, the local
proof storage and allocation bounds are polynomials in actual formula rows.
This theorem records the remaining premise explicitly. -/
theorem polynomial_allocation (n C d : Nat) (hn : 2≤n)
    (hmain : mainCount n≤C*(ConstructionFormulaScale.rows n)^d) :
    NativeRecordedAllocation.program (RecordedUniformFamily.emitter n)≤
      2*C*(ConstructionFormulaScale.rows n)^d+
      704*C*(ConstructionFormulaScale.rows n)^d*
        (ConstructionFormulaScale.rows n+C*(ConstructionFormulaScale.rows n)^d)*ConstructionFormulaScale.rows n := by
  have hnF:=ConstructionFormulaScale.arity n hn
  have ht:704*n+701≤704*ConstructionFormulaScale.rows n:=by omega
  have h:=allocations n hn
  have hh:=Nat.mul_le_mul (Nat.mul_le_mul hmain (Nat.add_le_add_left hmain (ConstructionFormulaScale.rows n))) ht
  have hlin:=Nat.mul_le_mul_left 2 hmain
  calc
    _ ≤ 2*(C*(ConstructionFormulaScale.rows n)^d)+
      (C*(ConstructionFormulaScale.rows n)^d)*(ConstructionFormulaScale.rows n+C*(ConstructionFormulaScale.rows n)^d)*
      (704*ConstructionFormulaScale.rows n) := h.trans (Nat.add_le_add hlin hh)
    _ = _ := by ring

#print axioms local_tokens
#print axioms allocations
#print axioms polynomial_allocation
end L3Emitter.ConstructionAllocationEnvelope

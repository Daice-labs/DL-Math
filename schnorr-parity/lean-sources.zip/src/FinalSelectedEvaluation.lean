import FinalKeptEvaluation
import SelectedOutputPOL
namespace L3Emitter.FinalSelectedEvaluation
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions FinalEvaluationContext
attribute [local irreducible] FinalOutputDefinitions.base initialNet LowerTransferImage.wire

def lits (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool):SelectedOutputPOL.Lits:=
  ⟨(source n hn (coord n i)).val,(H n hn).val,-sign side (OutputPhaseRows.phase n hn),
    sign a (SourceCoordinateValue.value n hn (coord n i) x.val),u n hn x side a,
    sign a ((built n hn).1.outs x),sign a (FinalKeptEvaluation.port n hn x 0),qlit n hn x a b⟩
theorem valid (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool):
    (lits n hn x i a b side).Valid:=by
  simp [lits,SelectedOutputPOL.Lits.Valid,Valid,u,qlit,sign_valid,(source n hn (coord n i)).property,(H n hn).property]

theorem phase_row (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool):
    SelectedOutputPOL.phaseRow (lits n hn x i a b side)∈D n hn:=by
  have h:=phase_kept n hn _ (OutputPhaseBank.all_rows n hn x.val x.isLt (coord n i) a side)
  exact h

theorem function_row (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool):
    SelectedOutputPOL.functionRow (lits n hn x i a b side)∈D n hn:=by
  let v:=OutputPhaseRows.truth n x.val side
  have he:(v^^side)=InputSwap.parity n x.val:=by unfold v OutputPhaseRows.truth;cases InputSwap.parity n x.val <;> cases side <;> decide
  have ha:FinalFunctionFullLinks.input (FinalU2Bank.code a b)=a:=by cases a <;> cases b <;> decide
  have h:=function_kept n hn _ (FinalFunctionFullLinks.short_present n hn (v,v,false,side) (FinalU2Bank.code a b) false)
  have hu:FinalFunctionFullLinks.uv (v,v,false,side) a=v:=by cases a <;> rfl
  simpa only [FinalFunctionFullLinks.short,FinalFunctionFullLinks.predicted,ha,hu,Bool.false_eq_true,↓reduceIte,he,
    SelectedOutputPOL.functionRow,lits,qlit,u,v,FinalU2Bank.q,FinalFunctionFullLinks.q] using h

theorem links_kept (n:Nat) (hn:2≤n):∀R∈FinalOutputLinks.result n hn,R∈D n hn:=by
  intro R h
  apply FinalU2Image.retained
  apply List.mem_append_left
  apply List.mem_append_left
  exact FinalTransferBank.retained n hn R h

theorem value_row (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool):
    SelectedOutputPOL.valueRow (lits n hn x i a b side)∈D n hn:=by
  have h:=FinalOutputLinks.relation n hn i x
  exact RawUnaryTransport.raw_polarity (D n hn) (source n hn (coord n i))
    (SourceCoordinateValue.value n hn (coord n i) x.val) ((built n hn).1.outs x) a
    ⟨links_kept n hn _ h.1,links_kept n hn _ h.2⟩

theorem port_row (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool):
    SelectedOutputPOL.portRow (lits n hn x i a b side)∈D n hn:=by
  have h:=(FinalPortSlots.rows n hn 0 x).2.2
  have he:FinalPortSlots.alternative n hn (initialNet n hn) 0 x=(built n hn).1.outs x:=FinalTransferSeed.port_zero n hn 0 rfl x
  rw [he] at h
  have hh:=RawUnaryTransport.raw_polarity (D n hn) (neg (H n hn)) ((built n hn).1.outs x)
    (FinalKeptEvaluation.port n hn x 0) a
    ⟨by simpa only [neg,neg_neg] using FinalKeptEvaluation.recorded_kept n hn _ h.1,
     by simpa only [neg,neg_neg] using FinalKeptEvaluation.recorded_kept n hn _ h.2⟩
  simpa only [neg,neg_neg] using hh

def rows (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool):=SelectedOutputPOL.rows (lits n hn x i a b side)
def program (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool) (E:List Row):=
  SelectedOutputPOL.program E (lits n hn x i a b side)
theorem checks (n:Nat) (hn:2≤n) (x:Fin (T n)) (i:Fin (W n-1)) (a b side:Bool) (E:List Row) (he:∀R∈D n hn,R∈E):
    check E (program n hn x i a b side E)=some (E++rows n hn x i a b side):=
  SelectedOutputPOL.checks E _ (valid n hn x i a b side) (he _ (phase_row n hn x i a b side))
    (he _ (function_row n hn x i a b side)) (he _ (value_row n hn x i a b side)) (he _ (port_row n hn x i a b side))
#print axioms checks
end L3Emitter.FinalSelectedEvaluation

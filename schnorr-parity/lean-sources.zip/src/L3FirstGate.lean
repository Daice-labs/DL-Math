import L3SelectedWire
import L3SelectorCoverage

namespace L3
open EREF EREF.GeneralRED

def pinRows (sel : Int) (xs : List Int) : List Row :=
  clauseRow (sel::xs) :: xs.map (fun x => clauseRow [-x])

theorem negUnits_sum (α : Val) (xs : List Int) (hn : ∀x∈xs,x≠0) :
    ((xs.map fun x => clauseRow [-x]).map fun r => lsum α r.lits-(r.rhs : Int)).sum = -lsum α xs := by
  induction xs with
  | nil => simp [lsum_nil]
  | cons x xs ih =>
    have hc := lv_neg_lit α x (hn x (by simp))
    rw [List.map_cons,List.map_cons,List.sum_cons,ih (fun y hy => hn y (by simp [hy]))]
    simp only [clauseRow,lsum_cons,lsum_nil]
    omega

theorem pinRows_sum (α : Val) (sel : Int) (xs : List Int) (hn : ∀x∈xs,x≠0) :
    ((pinRows sel xs).map fun r => lsum α r.lits-(r.rhs : Int)).sum = lv α sel-1 := by
  unfold pinRows
  rw [List.map_cons,List.sum_cons,negUnits_sum α xs hn]
  simp only [clauseRow,lsum_cons]
  omega

theorem pinRows_nz (sel : Int) (xs : List Int) (hs : sel≠0) (hn : ∀x∈xs,x≠0) :
    All Row.nz (pinRows sel xs) := by
  constructor
  · intro l hl; rcases List.mem_cons.mp hl with rfl | hl
    · exact hs
    · exact hn l hl
  · induction xs with
    | nil => trivial
    | cons x xs ih =>
      refine ⟨?_,ih (fun y hy => hn y (by simp [hy]))⟩
      intro l hl
      have hx := hn x (by simp)
      simp only [clauseRow,List.mem_cons,List.not_mem_nil,or_false] at hl
      subst l; omega

namespace Fam
variable (F : Fam)

def firstLeaf (x cb v : Nat) (pol : Bool) : List Int :=
  [-(cb : Int),(v : Int),if pol then -(F.val 0 x : Int) else (F.val 0 x : Int)]

def firstCoreRows (x y cb v : Nat) (bit pol : Bool) : List Row :=
  [F.row3i 0 0 0 x,F.row3i 0 0 0 y,F.row3i 0 1 1 x,F.row3i 0 1 1 y,
   F.row4P pol 0 x 0 bit.toNat,F.row4P (!pol) 0 y 1 bit.toNat,
   gateRow [if pol then -(F.fn 0 bit.toNat : Int) else (F.fn 0 bit.toNat : Int),
     if pol then (F.fn 0 (bit.toNat+2) : Int) else -(F.fn 0 (bit.toNat+2) : Int)] cb false,
   gateRow [if pol then -(F.val 0 x : Int) else (F.val 0 x : Int),
     if pol then -(F.val 0 y : Int) else (F.val 0 y : Int)] v true]

/-- T5a, the normalized first gate. The two ALO/unit sums are included twice
    to supply the selected input at both compared truth-table rows. -/
theorem first_gate_leaf (x y cb v : Nat) (bit pol : Bool)
    (hc : 1≤cb) (hv : 1≤v)
    (h0x : F.inputBit 0 x=false) (h0y : F.inputBit 0 y=true)
    (h1x : F.inputBit 1 x=bit) (h1y : F.inputBit 1 y=bit)
    (xs ys : List Int) (hxs : ∀x∈xs,x≠0) (hys : ∀y∈ys,y≠0)
    (D : List EREF.Row) (hD : ∀R∈D,Canonical R)
    (hp0 : All (fun r => r.toE∈D) (pinRows (F.sel 0 0 0 : Int) xs))
    (hp1 : All (fun r => r.toE∈D) (pinRows (F.sel 0 1 1 : Int) ys))
    (hm : All (fun r => r.toE∈D) (F.firstCoreRows x y cb v bit pol)) :
    Refutation (D ++ [negate (clauseRow (F.firstLeaf x cb v pol)).toE]) := by
  have hs0 := F.sel_pos 0 0 0
  have hs1 := F.sel_pos 0 1 1
  have hpx0 := F.port_pos 0 0 x
  have hpy0 := F.port_pos 0 0 y
  have hpx1 := F.port_pos 0 1 x
  have hpy1 := F.port_pos 0 1 y
  have hvx := F.val_pos 0 x
  have hvy := F.val_pos 0 y
  have hn0 := F.fn_pos 0 0
  have hn1 := F.fn_pos 0 1
  have hn2 := F.fn_pos 0 2
  have hn3 := F.fn_pos 0 3
  let ps := pinRows (F.sel 0 0 0 : Int) xs ++ pinRows (F.sel 0 1 1 : Int) ys
  have hpn : All Row.nz ps := All.append (pinRows_nz _ _ (by omega) hxs) (pinRows_nz _ _ (by omega) hys)
  have hpm : All (fun r => r.toE∈D) ps := All.append hp0 hp1
  apply weighted_clause_chain D _ 2 (ps ++ ps ++ F.firstCoreRows x y cb v bit pol) hD
  · cases pol <;> simp only [firstLeaf,Bool.false_eq_true,↓reduceIte] <;> nz_lits
  · exact All.append (All.append hpm hpm) hm
  · apply All.append (All.append hpn hpn)
    cases bit <;> cases pol <;>
      simp only [firstCoreRows,row3i,h0x,h0y,h1x,h1y,row4P,row4,row4',m1,m2,gateRow,pos,neg,
        Bool.toNat,Bool.cond_false,Bool.cond_true,Nat.reduceAdd,Nat.reduceMul,
        Bool.not_false,Bool.not_true,Bool.false_eq_true,Bool.true_eq_false,↓reduceIte,All]
    all_goals repeat' first | apply And.intro | exact True.intro
    all_goals nz_lits
  · intro α
    simp only [List.map_append,List.sum_append,ps,pinRows_sum α _ xs hxs,pinRows_sum α _ ys hys]
    cases bit <;> cases pol <;>
      simp [firstCoreRows,firstLeaf,row3i,h0x,h0y,h1x,h1y,row4P,row4,row4',m1,m2,gateRow,pos,neg,lsum_cons,lsum_nil] <;> lv_omega

#print axioms first_gate_leaf
end Fam
end L3

import FinalOutputCore
namespace L3Emitter.DefinitionNetworkBridge
open EREF EREF.GeneralRED REDWitness AliasNetwork
variable {base:List Row} {A:Type}

theorem checked (hc:∀R∈base,Canonical R) (p:StateM (Net base) A):
    CheckedTrace base (p (initial base hc)).2.rows:=(p (initial base hc)).2.checked

theorem retains (hc:∀R∈base,Canonical R) (p:StateM (Net base) A) (hp:Extends p):
    ∀R∈base,R∈(p (initial base hc)).2.rows:=by
  intro R hr
  exact hp (initial base hc) R (by simpa only [initial,Net.rows,List.flatMap_nil,List.append_nil] using hr)

theorem cost (hc:∀R∈base,Canonical R) (p:StateM (Net base) A) (c:Nat) (hp:Cost p c):
    (p (initial base hc)).2.gates.length≤c:=by
  have h:=hp (initial base hc)
  simpa only [initial,List.length_nil,Nat.zero_add] using h
#print axioms checked
#print axioms retains
#print axioms cost
end L3Emitter.DefinitionNetworkBridge

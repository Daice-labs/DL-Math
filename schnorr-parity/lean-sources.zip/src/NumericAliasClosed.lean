import NumericAliasSource
import NumericAliasRecorded
import RecursiveOperandBounds
namespace L3Emitter.NumericAliasClosed
open EREF EREF.GeneralRED FieldLengthsFromIDs

def bound (n:Nat):Nat:=18000*(n+2)^4*(2^(n+1))^2

theorem field_cap (n:Nat) (hn:2≤n):NumericAliasRecorded.fieldCap n hn≤bound n:=by
  have h:=NumericAliasRecorded.field_polynomial n hn
  have hs:=NumericAliasSource.ceiling n hn
  have hp:1≤2^(n+1):=Nat.one_le_pow _ _ (by omega)
  have h34:(n+2)^3≤(n+2)^4:=Nat.pow_le_pow_right (by omega) (by omega)
  have hpow:2^(n+1)≤(2^(n+1))^2:=by nlinarith
  have ha:=Nat.mul_le_mul_right ((2^(n+1))^2) h34
  have hb:=Nat.mul_le_mul_left ((n+2)^4) hpow
  unfold bound;nlinarith

theorem fields (n:Nat) (hn:2≤n):
    ∀c∈RecordedAliasDefinitions.program n hn,Content (bound n) c:=by
  intro c hc
  exact RecursiveOperandBounds.content_mono (field_cap n hn) c (NumericAliasRecorded.fields n hn c hc)

#print axioms fields
end L3Emitter.NumericAliasClosed

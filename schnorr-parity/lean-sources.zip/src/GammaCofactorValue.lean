import GammaChoiceBank
namespace L3Emitter.GammaCofactorValue
open EREF EREF.GeneralRED REDWitness AliasNetwork GuardedGatePOL CofactorValueRows
abbrev Job:=BetaPort.Job

def g {n:Nat} (j:Job n):Nat:=j.1.2.parent.gamma
def other (n:Nat) (hn:2≤n) (j:Job n) (side:Bool):Bit:=
  ⟨(CofactorSemantics.low n (ConstantCofactor.offset n hn) (g j) (if side then 1 else 0) j.2:Int),by
    have:=CofactorSemantics.low_pos n (ConstantCofactor.offset n hn) (g j) (if side then 1 else 0) j.2;omega⟩
def fbit (n:Nat) (hn:2≤n) (j:Job n) (side a b:Bool):Bit:=
  (PrimaryAliasBank.cfg n hn).fn (g j) (if side then a else b) (if side then b else a)
def oldJob (n:Nat) (j:Job n) (side a b v:Bool):GammaUnary.Job n:=
  ((j,g j,if side then 0 else 1,!a),b,!v)
def Q (n:Nat) (hn:2≤n) (j:Job n) (side a b v:Bool):List Int:=
  [-sign a (PrimaryAliasBank.cfg n hn).C,-sign b (other n hn j side),sign v (cofactor n hn (g j) j.2),-sign v (fbit n hn j side a b)]
def row (n:Nat) (hn:2≤n) (j:Job n) (side a b v:Bool):=
  CommonGuardResolve.target [-BetaAliasValue.choice j] [-sign side (GammaChoiceBank.hit n hn j.1)] (Q n hn j side a b v)
def tape (n:Nat) (hn:2≤n) (j:Job n) (side a b v:Bool) (D:List Row):=
  CommonGuardResolve.tape D [-BetaAliasValue.choice j] [-sign side (GammaChoiceBank.hit n hn j.1)] (Q n hn j side a b v)
    (GammaChoiceBank.port n hn j.1 side).val

theorem forcing_job (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn):j.1∈GammaChoiceBank.jobs n hn:=by
  have h:=BetaPort.valid_job n hn j hj
  exact (ForcingFieldBank.job_mem _ _ _ _).mpr ⟨h.1,h.2.1,h.2.2.1⟩

theorem keeps_unary (n:Nat) (hn:2≤n):∀R∈UnaryValueBank.result n hn,R∈GammaChoiceBank.result n hn:=
  fun R h=>List.mem_append_left _ (ReceivingEdgeBank.retains n hn R (HitBranchBank.retains n hn R h))

theorem keeps_gamma (n:Nat) (hn:2≤n):∀R∈GammaUnary.result n hn,R∈GammaChoiceBank.result n hn:=by
  intro R h
  apply keeps_unary n hn
  apply alias_keep n hn
  exact AliasAssembly.preserves_predecessor n hn R (List.mem_append_left _ h)

theorem old_present (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (side a b v:Bool):
    GammaUnary.row n hn (oldJob n j side a b v)∈GammaChoiceBank.result n hn:=by
  apply keeps_gamma n hn
  apply List.mem_append_right
  apply List.mem_map.mpr
  refine ⟨oldJob n j side a b v,?_,rfl⟩
  apply List.mem_flatMap.mpr
  refine ⟨(oldJob n j side a b v).1,?_,?_⟩
  · apply (GammaConstant.job_mem n hn _).mpr
    exact ⟨hj,j.1.2.parent.gamma_lt,j.1.2.parent.ordered,by cases side <;> simp [oldJob]⟩
  · exact List.mem_flatMap.mpr ⟨b,by cases b <;> simp,List.mem_map.mpr ⟨!v,by cases v <;> simp,rfl⟩⟩

theorem old_binding (n:Nat) (hn:2≤n) (j:Job n) (side a b v:Bool):
    GammaUnary.row n hn (oldJob n j side a b v)=
      CommonGuardResolve.right [-BetaAliasValue.choice j] (Q n hn j side a b v) (GammaChoiceBank.port n hn j.1 side).val:=by
  have hc:(PrimaryAliasBank.cfg n hn).C.val=(ConstantConstruction.C (n+1) (by omega):Int):=rfl
  have hf:∀a b,((PrimaryAliasBank.cfg n hn).fn (g j) a b).val=
    (FamilyNamespace.encode (n+1) (3*(n+1)-4) (.fn (g j) (2*a.toNat+b.toNat)):Int):=fun _ _=>rfl
  cases side <;> cases a <;> cases b <;> cases v <;>
    simp only [GammaUnary.row,oldJob,GammaConstant.c,GammaConstant.e,WireCofactor.selector,
      BetaValue.C,GammaConstant.betaJob,GammaUnary.otherWire,GammaUnary.outWire,GammaUnary.fn,GammaUnary.a,GammaUnary.other,GammaUnary.positive,
      CofactorSemantics.fnLiteral,CommonGuardResolve.right,Q,BetaAliasValue.choice,
      sign,other,cofactor,fbit,GammaChoiceBank.port,ReceivingEdgeCover.port,hc,hf,
      Bool.not_true,Bool.not_false,Bool.false_eq_true,↓reduceIte,neg_neg,List.singleton_append,List.cons_append,List.nil_append]
  all_goals rfl

theorem checks (n:Nat) (hn:2≤n) (j:Job n) (hj:j∈BetaPort.jobs n hn) (side a b v:Bool)
    (D:List Row) (hd:∀R∈GammaChoiceBank.result n hn,R∈D):
    polEval (dbOf D) (tape n hn j side a b v D) []=some (row n hn j side a b v):=by
  apply CommonGuardResolve.checks D _ _ _ _
    (by simp [Valid,BetaAliasValue.choice_valid n hn j hj]) (by simp [Valid,sign_valid]) (by simp [Q,Valid,sign_valid])
    (GammaChoiceBank.port n hn j.1 side).property
  · exact hd _ (GammaChoiceBank.receiving n hn j.1 (forcing_job n hn j hj) side)
  · rw [←old_binding]
    exact hd _ (old_present n hn j hj side a b v)

#print axioms old_binding
#print axioms checks
end L3Emitter.GammaCofactorValue

import L3CoverageComplete

namespace L3Emitter.FableCoverageIntegration
open EREF.GeneralRED L3Emitter.FableEncoding

/-- The actual normalization/frontend order through coverage and output
    exclusion. No unresolved coverage premise remains. This is a semantic
    checked trace, not a theorem about the native serialized RUP checker. -/
theorem actual_through_stage6 (k : Nat) (hk : 3≤k) :
    CheckedTrace (OriginalEncoding.rows k (3*k-4))
      (L3.exec (fam k (3*k-4)).db5
        ((fam k (3*k-4)).stage6
          ((fam k (3*k-4)).stage5 ((fam k (3*k-4)).V_pos (by change 1≤3*k-4; omega))
            ((fam k (3*k-4)).t4 (by change 1≤3*k-4; omega)))).s.cmds) := by
  apply L3Emitter.FableOutputIntegration.actual_through_stage6 k hk
  exact (fam k (3*k-4)).t5_obls (by change 2≤k; omega)
    (by change 2≤3*k-4; omega) rfl

#print axioms actual_through_stage6
end L3Emitter.FableCoverageIntegration

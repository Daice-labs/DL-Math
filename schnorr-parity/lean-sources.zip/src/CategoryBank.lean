import CategoryPrograms

namespace L3Emitter.CategoryBank
open EREF EREF.GeneralRED REDWitness AliasProgram GateCategories CategoryPrograms

def gates (n:Nat) := (List.range (3*(n+1)-5)).map (·+1)
theorem gate_mem (n g:Nat) : g∈gates n ↔ 0<g ∧ g<3*(n+1)-4 := by
  simp only [gates,List.mem_map,List.mem_range]
  constructor
  · rintro ⟨i,hi,rfl⟩;omega
  · intro h;exact ⟨g-1,by omega,by omega⟩

def body (n:Nat) (hn:2≤n) (gs:List Nat) := gs.flatMap (CategoryPrograms.rows n hn)
def loop (n:Nat) (hn:2≤n) (D:List Row) : List Nat→Program
  | []=>[]
  | g::gs=>CategoryPrograms.program n hn g D++loop n hn (D++CategoryPrograms.rows n hn g) gs

theorem loop_check (n:Nat) (hn:2≤n) (D:List Row) (gs:List Nat)
    (hg:∀g∈gs,g∈gates n) (hd:Keep n hn D) :
    check D (loop n hn D gs)=some (D++body n hn gs) := by
  induction gs generalizing D with
  | nil=>simp [loop,body,check]
  | cons g gs ih=>
    have hm:=(gate_mem n g).mp (hg g (by simp))
    have h1:=CategoryPrograms.checks n hn g hm.1 hm.2 D hd
    have h2:=ih (D++CategoryPrograms.rows n hn g) (fun j hj=>hg j (by simp [hj]))
      (fun R hr=>List.mem_append_left _ (hd R hr))
    simpa only [loop,body,List.flatMap_cons,List.append_assoc] using check_append _ _ _ _ _ h1 h2

def result (n:Nat) (hn:2≤n) := base n hn++body n hn (gates n)
def emitted (n:Nat) (hn:2≤n) := loop n hn (base n hn) (gates n)
theorem checks (n:Nat) (hn:2≤n) : check (base n hn) (emitted n hn)=some (result n hn) :=
  loop_check n hn _ _ (fun g h=>h) (fun R h=>h)
theorem retains (n:Nat) (hn:2≤n) : ∀R∈base n hn,R∈result n hn :=
  fun R h=>List.mem_append_left _ h
theorem contains_gate (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) :
    ∀R∈CategoryPrograms.rows n hn g,R∈result n hn := by
  intro R hr
  exact List.mem_append_right _ (List.mem_flatMap.mpr ⟨g,(gate_mem n g).mpr ⟨hg,hs⟩,hr⟩)
theorem alo (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4) :
    clause (vars n hn g)∈result n hn :=
  contains_gate n hn g hg hs _ (CategoryPrograms.alo_mem n hn g)
theorem exclusion (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (q r:Category) (hq:q∈cats n) (hr:r∈cats n) (hne:q≠r) :
    clause [-value n hn g q,-value n hn g r]∈result n hn :=
  contains_gate n hn g hg hs _ (CategoryPrograms.exclusion_mem n hn g q r hq hr hne)
theorem original_to_categories (n:Nat) (hn:2≤n) :
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn) :=
  L3.Fam.checkedTrace_trans (FirstPortOneHot.original_to_first_port_onehot n hn)
    (check_trace _ _ _ (checks n hn))

#print axioms original_to_categories
#print axioms alo
#print axioms exclusion
end L3Emitter.CategoryBank

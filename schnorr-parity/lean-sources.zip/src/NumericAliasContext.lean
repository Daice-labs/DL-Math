import NumericAliasRun
namespace L3Emitter.NumericNetwork
open EREF EREF.GeneralRED AliasNetwork RecursiveAliases AliasAssembly
variable {base:List Row}

structure ExternalBound (M k:Nat) (hk:3≤k):Prop where
  restriction : BitBound M (restrictionBit k hk)
  constant : BitBound M (constantBit k hk)
  choice : ∀b g,∀x∈choiceSupport k hk b g,BitBound M x
  rank : ∀g,g<3*k-4 → ∀t,t<width k → BitBound M (rankBit k hk g t)
  selector : ∀g,g<3*k-4 → ∀p,p<2 → ∀j,j<k+g → BitBound M (selector k (3*k-4) g p j)
  function : ∀g,g<3*k-4 → ∀a b,BitBound M (functionBit k (3*k-4) g a b)

theorem refAt_bound (M s:Nat) (v:Bit) (f:Fin s→Bit) (hv:BitBound M v)
    (hf:∀i,BitBound M (f i)) (g:Nat):BitBound M (refAt v f g):=by
  unfold refAt;split_ifs;exact hf _;exact hv

def contextCost (k:Nat):Nat:=1+3*(3*k-4)+(3*k-4)*(3*k-4)

theorem context (M k:Nat) (hk:3≤k) (he:ExternalBound M k hk)
    (z:Net base) (hz:CanonicalTrace.ceiling z.rows≤M):
    ConfigBound (M+contextCost k) (3*k-4) (width k) (AliasAssembly.context k hk z).1 ∧
    CanonicalTrace.ceiling (AliasAssembly.context k hk z).2.rows≤M+contextCost k:=by
  let s:=3*k-4
  let tz:=AND [] z
  let F:=neg tz.1
  let bs:=AliasNetwork.tabulate s (fun g=>OR (choiceSupport k hk true g.val)) tz.2
  let gs:=AliasNetwork.tabulate s (fun g=>OR (choiceSupport k hk false g.val)) bs.2
  let ks:=AliasNetwork.tabulate s (fun g=>OR ((List.range (RankConstruction.width k)).map (rankBit k hk g.val))) gs.2
  let hs:=AliasNetwork.tabulate s (fun g=>AliasNetwork.select ((List.range (g.val-1)).map (fun h=>(refAt F bs.1 (h+1),selector k s g.val 0 (k+(h+1)))))) ks.2
  have ht:ResultBound (M+1) tz:=gate M z true [] hz (by simp)
  have hF:BitBound (M+1) F:=by
    change (-tz.1.val).natAbs≤M+1;rw[Int.natAbs_neg];exact ht.1
  have hb:=tabulate M 1 s (fun g=>OR (choiceSupport k hk true g.val)) (by
    intro g N hN u hu;exact gate N u false _ hu (fun x hx=>(he.choice true g.val x hx).trans hN))
    (M+1) (by omega) tz.2 ht.2
  have hg:=tabulate M 1 s (fun g=>OR (choiceSupport k hk false g.val)) (by
    intro g N hN u hu;exact gate N u false _ hu (fun x hx=>(he.choice false g.val x hx).trans hN))
    (M+1+s) (by omega) bs.2 (by simpa using hb.2)
  have hkept:=tabulate M 1 s (fun g=>OR ((List.range (RankConstruction.width k)).map (rankBit k hk g.val))) (by
    intro g N hN u hu;apply gate N u false _ hu
    intro x hx;obtain ⟨t,ht,rfl⟩:=List.mem_map.mp hx
    exact (he.rank g.val g.isLt t (by
      have h:=List.mem_range.mp ht;unfold width;omega)).trans hN)
    (M+1+s+s) (by omega) gs.2 (by simpa using hg.2)
  have hhit:=tabulate (M+1+s+s+s) s s (fun g=>AliasNetwork.select ((List.range (g.val-1)).map (fun h=>(refAt F bs.1 (h+1),selector k s g.val 0 (k+(h+1)))))) (by
    intro g N hN u hu
    have h:=select N u ((List.range (g.val-1)).map (fun h=>(refAt F bs.1 (h+1),selector k s g.val 0 (k+(h+1))))) hu (by
      intro p hp;obtain ⟨j,hj,rfl⟩:=List.mem_map.mp hp
      constructor
      · exact refAt_bound N s F bs.1 (hF.trans (by omega)) (fun i=>(hb.1 i).trans (by simp only [Nat.mul_one] at *;omega)) _
      · exact (he.selector g.val g.isLt 0 (by omega) (k+(j+1)) (by have h:=List.mem_range.mp hj;omega)).trans (by omega))
    apply result_mono ?_ _ h
    simp only [List.length_map,List.length_range]
    have hp:0<s:=by dsimp[s];omega
    have hl:=g.isLt
    omega)
    (M+1+s+s+s) (by omega) ks.2 (by simpa using hkept.2)
  have hm:M+1+s+s+s+s*s=M+contextCost k:=by unfold contextCost;dsimp[s];ring
  have hh:∀i,BitBound (M+contextCost k) (hs.1 i):=by simpa only [hm] using hhit.1
  have hz':CanonicalTrace.ceiling hs.2.rows≤M+contextCost k:=by simpa only [hm] using hhit.2
  have hT:BitBound (M+contextCost k) tz.1:=ht.1.trans (by unfold contextCost;omega)
  have hF':BitBound (M+contextCost k) F:=hF.trans (by unfold contextCost;omega)
  have hb':∀i,BitBound (M+contextCost k) (bs.1 i):=fun i=>(hb.1 i).trans (by simp only[Nat.mul_one];unfold contextCost;dsimp[s];omega)
  have hg':∀i,BitBound (M+contextCost k) (gs.1 i):=fun i=>(hg.1 i).trans (by simp only[Nat.mul_one];unfold contextCost;dsimp[s];omega)
  have hk':∀i,BitBound (M+contextCost k) (ks.1 i):=fun i=>(hkept.1 i).trans (by simp only[Nat.mul_one];unfold contextCost;dsimp[s];omega)
  constructor
  · exact ⟨hT,hF',he.restriction.trans (by omega),he.constant.trans (by omega),
      (fun g _=>refAt_bound _ _ F bs.1 hF' hb' g),
      (fun g _=>refAt_bound _ _ F gs.1 hF' hg' g),
      (fun g _=>refAt_bound _ _ F hs.1 hF' hh g),
      (fun g _=>refAt_bound _ _ F ks.1 hF' hk' g),
      (fun g hg t ht=>(he.rank g hg t ht).trans (by omega)),
      (fun g hg p hp j hj=>(he.selector g hg p hp j hj).trans (by omega)),
      (fun g hg a b=>(he.function g hg a b).trans (by omega))⟩
  · exact hz'

#print axioms context
end L3Emitter.NumericNetwork

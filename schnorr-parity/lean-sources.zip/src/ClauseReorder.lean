import GammaUnaryChoice
namespace L3Emitter.ClauseReorder
open EREF REDWitness
-- Positions only: no literal distinctness assumption.
theorem permute6 (a b c d e f:Int) (h:Valid [a,b,c,d,e,f]):
    clause [a,b,c,d,e,f]=clause [a,d,b,c,e,f]:=by
  apply ProjectionTrace.clause_perm _ _ h
  · intro l hl;apply h l
    simp only [List.mem_cons,List.not_mem_nil,or_false] at *
    tauto
  · apply List.perm_iff_count.mpr
    intro x
    simp only [List.count_cons,List.count_nil]
    omega
end L3Emitter.ClauseReorder

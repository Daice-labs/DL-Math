import NumericOneHotBit
import NumericProgramFields
import RecordedCaseProjection
namespace L3Emitter.NumericCaseProjection
open EREF EREF.GeneralRED RecordedOperandFields FieldLengthsFromIDs

theorem blocks {ι:Type} (M:Nat) (D:List Row) (rows:ι→List Row)
 (block:List Row→ι→RecordedScopedTrace.Program) (is:List ι)
 (h:∀i∈is,∀E,∀c∈block E i,Content M c):
 ∀c∈RecordedBlocks.program rows block D is,Content M c:=by
 induction is generalizing D with
 | nil=>simp [RecordedBlocks.program]
 | cons i is ih=>
   intro c hc;rcases List.mem_append.mp hc with hc|hc
   · exact h i (by simp) D c hc
   · exact ih _ (by intro i hi;exact h i (by simp [hi])) c hc

theorem weaken (M:Nat) (D:List Row) (xs ys:List Int) (hy:∀y∈ys,y.natAbs≤M):
 Tape M (ChoiceProjection.weakenTokens D xs ys):=by
 apply NumericSelectionTapes.append
 · intro t ht;obtain rfl:=List.mem_singleton.mp ht;trivial
 · exact NumericSelectionTapes.pad M ys hy

theorem alo {ι:Type} (M:Nat) (D:List Row) (is:List ι) (c owner:ι→Int) (qs:List Int)
 (hq:∀q∈qs,q.natAbs≤M) (hl:is.length≤M):
 ∀z∈RecordedCaseProjection.aloProgram D is c owner qs,Content M z:=by
 intro z hz;rcases List.mem_append.mp hz with hz|hz
 · apply blocks M D _ _ is ?_ z hz
   intro i hi E z hz;obtain rfl:=List.mem_singleton.mp hz
   apply weaken
   intro q hq';exact hq q (List.mem_of_mem_erase hq')
 · obtain rfl:=List.mem_singleton.mp hz
   apply NumericClauseTapes.join
   simpa only [List.length_map] using hl

theorem pair (M:Nat) (D:List Row) (c q r:Int) (side:Bool) (xs ys:List Int)
 (hc:c.natAbs≤M) (hq:q.natAbs≤M) (hr:r.natAbs≤M)
 (hx:xs.length+1≤M) (hy:ys.length+1≤M):
 ∀z∈RecordedCaseProjection.pairProgram D c q r side xs ys,Content M z:=by
 intro z hz;rcases List.mem_append.mp hz with hz|hz
 · obtain rfl:=List.mem_singleton.mp hz
   cases side
   · exact NumericOneHotBit.exclude M _ _ _ _ hc hr hy
   · exact NumericOneHotBit.exclude M _ _ _ _ hc hq hx
 · obtain rfl:=List.mem_singleton.mp hz
   apply weaken
   intro l hl;obtain rfl:=List.mem_singleton.mp hl
   cases side <;> first | simpa [ProjectionTrace.second] using hq | simpa [ProjectionTrace.second] using hr

theorem amo {ι:Type} (M:Nat) (D:List Row) (is:List ι) (c:ι→Int) (q r:Int)
 (side:ι→Bool) (xs ys:List Int) (hc:∀i∈is,(c i).natAbs≤M)
 (hq:q.natAbs≤M) (hr:r.natAbs≤M) (hx:xs.length+1≤M) (hy:ys.length+1≤M) (hl:is.length≤M):
 ∀z∈RecordedCaseProjection.amoProgram D is c q r side xs ys,Content M z:=by
 intro z hz;rcases List.mem_append.mp hz with hz|hz
 · exact blocks M D _ _ is (by intro i hi E;exact pair M E (c i) q r (side i) xs ys (hc i hi) hq hr hx hy) z hz
 · obtain rfl:=List.mem_singleton.mp hz
   apply NumericClauseTapes.join
   simpa only [List.length_map] using hl
#print axioms alo
#print axioms amo
end L3Emitter.NumericCaseProjection

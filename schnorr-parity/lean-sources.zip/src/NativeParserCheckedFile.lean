import NativeParserActualRanges
namespace L3Emitter.NativeParserCheckedFile
open EREF CanonicalFileGrammar NativeParserEventCoordinates NativeParserStackShapes

def checkEvent : CanonicalLineParser.Event→Bool
 | .pol ts=>decide (CanonicalNativePOLShape.shape ts 0=some 1)
 | _=>true

def parse (names:List Nat) (bs:Bytes):Option (List Nat×CanonicalWholeFile.File):=do
 let result←PinnedFileOnline.parse names bs
 if (result.2.commands.flatMap commandEvents).all checkEvent then return result else none

theorem coordinate_shape (ρ:Nat→Nat) (ts:List Tok) (d:Nat):
 CanonicalNativePOLShape.shape (ts.map (PinnedCoordinateChange.token ρ)) d=
 CanonicalNativePOLShape.shape ts d:=by
 induction ts generalizing d with
 | nil=>rfl
 | cons t ts ih=>cases t <;> simp only [List.map_cons,PinnedCoordinateChange.token,CanonicalNativePOLShape.shape,ih]

theorem renamed (ρ:Nat→Nat) (e:CanonicalLineParser.Event) (h:EventValid e):
 checkEvent (event ρ e)=true:=by
 cases e with
 | pol ts=>simp only [event,checkEvent,coordinate_shape,decide_eq_true_eq];exact h
 | pbc _ | red _ _ | goal _ | close _ | endRed=>rfl

theorem checks (ρ:Nat→Nat) (cs:List CanonicalScopeKernel.Command)
 (h:∀e∈cs.flatMap commandEvents,EventValid e):
 ((cs.map (PinnedCoordinateChange.command ρ)).flatMap commandEvents).all checkEvent=true:=by
 rw [commands_events,List.all_eq_true]
 intro e he
 obtain ⟨q,hq,rfl⟩:=List.mem_map.mp he
 exact renamed ρ q (h q hq)

def names (initial:List Nat) (n:Nat):List Nat:=
 (allocate initial ((NativeCompatibleFamily.commands n).flatMap commandEvents)).1

def file (initial:List Nat) (n:Nat):CanonicalWholeFile.File:=
 ⟨(NativeRecordedFamily.original n).length,
 (NativeCompatibleFamily.commands n).map (PinnedCoordinateChange.command (PinnedCoordinateChange.coordinate (names initial n))),
 NativeCompatibleFamily.conclusion n⟩

/-- Complete emitted-file parser including the native POL stack discipline,
fixed-width reference fields, and encounter-order variable allocation. -/
theorem family (initial:List Nat) (n:Nat) (hn:2≤n)
 (hm:(NativeCompatibleFamily.compiled n).store.next≤CanonicalMachineReference.referenceLimit):
 parse initial (NativeCompatibleFamily.bytes n)=some (names initial n,file initial n):=by
 rw [parse,NativeParserActualRanges.file initial n hn hm]
 simp only [bind,Option.bind]
 rw [checks _ _ (NativeParserStackShapes.family n hn)]
 rfl
#print axioms family
end L3Emitter.NativeParserCheckedFile

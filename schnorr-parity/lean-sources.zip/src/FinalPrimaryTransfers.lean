import FinalTransferBank
namespace L3Emitter.FinalPrimaryTransfers
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL
open FinalOutputDefinitions FinalTransferContext
abbrev Job (n:Nat):=Fin 2×Fin n×Fin (T n)
def index (n:Nat) (hn:2≤n) (i:Fin n):Fin (W n-1):=⟨i.val,by have:=i.isLt;unfold W AliasAssembly.width RankConstruction.width;omega⟩
def truth (n:Nat) (i:Fin n) (x:Fin (T n)):=PrimaryInputLinks.d n (i.val+1) x.val

theorem value_truth (n:Nat) (hn:2≤n) (i:Fin n) (x:Fin (T n)):
    GuardedVectorTransport.signed (truth n i x) (value n hn (index n hn i) x)=(PrimaryAliasBank.cfg n hn).T.val:=by
  have h:=SourceCoordinateValue.primary n hn (coord n (index n hn i)) x.val (i.val+1) (by have:=i.isLt;omega) (by omega) (by rfl)
  change GuardedVectorTransport.signed (truth n i x) (SourceCoordinateValue.value n hn (coord n (index n hn i)) x.val)=_
  rw [h]
  cases hb:truth n i x <;> simp only [GuardedVectorTransport.signed,hb,Bool.false_eq_true,↓reduceIte,PrimaryValueSeeds.truth,
    show PrimaryInputLinks.d n (i.val+1) x.val=truth n i x from rfl,PrimaryAliasBank.false_bit,neg,neg_neg]

def row (n:Nat) (hn:2≤n) (j:Job n):=RawLowerTransfers.primaryRow (targetSelector n hn j.1 (index n hn j.2.1)) (targetPort n hn j.1 j.2.2) (truth n j.2.1 j.2.2)
def rows (n:Nat) (hn:2≤n) (j:Job n):=[row n hn j]
def leaf (n:Nat) (hn:2≤n) (j:Job n) (E:List Row):Program:=
  [(row n hn j,RawLowerTransfers.primaryTape E (targetSelector n hn j.1 (index n hn j.2.1)) (targetPort n hn j.1 j.2.2) (PrimaryAliasBank.cfg n hn).T (truth n j.2.1 j.2.2))]
def jobs (n:Nat):List (Job n):=(List.finRange 2).flatMap fun p=>(List.finRange n).flatMap fun i=>(List.finRange (T n)).map fun x=>(p,i,x)

theorem leaf_check (n:Nat) (hn:2≤n) (j:Job n) (E:List Row) (hk:∀R∈FinalTransferBank.result n hn,R∈E):
    check E (leaf n hn j E)=some (E++rows n hn j):=by
  obtain ⟨p,i,x⟩:=j
  have h:=FinalTransferBank.contains n hn p (index n hn i) x (truth n i x)
  change clause [-(targetSelector n hn p (index n hn i)).val,
    -GuardedVectorTransport.signed (truth n i x) (value n hn (index n hn i) x),
    GuardedVectorTransport.signed (truth n i x) (targetPort n hn p x)]∈_ at h
  rw [value_truth] at h
  have ht:=FinalTransferBank.retained n hn _ (definitions_kept n hn _ (FinalLowerImage.true_present n hn))
  have hh:=RawLowerTransfers.primary_check E (targetSelector n hn p (index n hn i)) (targetPort n hn p x)
    (PrimaryAliasBank.cfg n hn).T (truth n i x) (hk _ h) (hk _ ht)
  simp only [leaf,rows,row,check,hh,↓reduceIte]

def program (n:Nat) (hn:2≤n):=RetainedBlockFold.run (leaf n hn) (rows n hn) (jobs n) (FinalTransferBank.result n hn)
def result (n:Nat) (hn:2≤n):=FinalTransferBank.result n hn++RetainedBlockFold.body (rows n hn) (jobs n)
theorem checks (n:Nat) (hn:2≤n):check (FinalTransferBank.result n hn) (program n hn)=some (result n hn):=
  RetainedBlockFold.checks _ _ _ (fun _=>True) (fun j _=>leaf_check n hn j) _ (by simp) _ (fun _ h=>h)
theorem original_to_primary_transfers (n:Nat) (hn:2≤n):
    CheckedTrace (OriginalEncoding.rows (n+1) (3*(n+1)-4)) (result n hn):=
  L3.Fam.checkedTrace_trans (FinalTransferBank.original_to_replacement_transfers n hn) (check_trace _ _ _ (checks n hn))
theorem contains (n:Nat) (hn:2≤n) (p:Fin 2) (i:Fin n) (x:Fin (T n)):
    row n hn (p,i,x)∈result n hn:=
  List.mem_append_right _ (RetainedBlockFold.contains (rows n hn) (jobs n) (p,i,x) (by simp [jobs]) _ (List.mem_singleton_self _))
#print axioms original_to_primary_transfers
#print axioms value_truth
end L3Emitter.FinalPrimaryTransfers

import Serialization

namespace L3Emitter.DecimalParser

/-- Parse actual ASCII bytes, rejecting every nondecimal byte. The numeric
state is unbounded Nat; the native machine-width bound is a separate premise. -/
def scan (acc : Nat) : Bytes → Option Nat
  | [] => some acc
  | b::bs => if 48 ≤ b.toNat ∧ b.toNat ≤ 57 then
      scan (10*acc+(b.toNat-48)) bs else none

def parse (bs : Bytes) : Option Nat := if bs.isEmpty then none else scan 0 bs

theorem scan_append (xs ys : Bytes) (a b : Nat) (h : scan a xs = some b) :
    scan a (xs++ys) = scan b ys := by
  induction xs generalizing a with
  | nil => simp only [scan,Option.some.injEq] at h; subst b; rfl
  | cons x xs ih =>
    simp only [scan] at h
    split at h
    · rename_i hx
      simp only [List.cons_append,scan,if_pos hx]
      exact ih _ h
    · contradiction

theorem digit_value (d : Nat) (hd : d < 10) :
    (UInt8.ofNat d.digitChar.toNat).toNat = 48+d := by
  rw [Nat.toNat_digitChar_of_lt_ten hd,UInt8.toNat_ofNat']
  exact Nat.mod_eq_of_lt (by omega)

theorem scan_digit (a d : Nat) (hd : d < 10) :
    scan a [UInt8.ofNat d.digitChar.toNat] = some (10*a+d) := by
  simp only [scan,digit_value d hd]
  rw [if_pos (by omega)]
  simp

/-- Roundtrip and positional value for every decimal numeral, including zero. -/
theorem scan_decimal (n a : Nat) :
    scan a (decimal n) = some (a*10^digits n+n) := by
  induction n using Nat.strongRecOn generalizing a with
  | ind n ih =>
    by_cases hn : n < 10
    · have hd : decimal n = [UInt8.ofNat n.digitChar.toNat] := by
        simp only [decimal,Nat.toDigits_of_lt_base hn,List.map_cons,List.map_nil]
      have hl : digits n = 1 := by simp [digits,Nat.toDigits_of_lt_base hn]
      rw [hd,hl,scan_digit a n hn]
      congr 1; omega
    · have hlt : n/10 < n := Nat.div_lt_self (by omega) (by decide)
      have hd : decimal n = decimal (n/10)++[UInt8.ofNat (n%10).digitChar.toNat] := by
        simp only [decimal,Nat.toDigits_of_base_le (by decide : 1 < 10) (by omega : 10 ≤ n),
          List.map_append,List.map_cons,List.map_nil]
      have hl : digits n = digits (n/10)+1 := by
        simp only [digits,Nat.toDigits_of_base_le (by decide : 1 < 10) (by omega : 10 ≤ n),
          List.length_append,List.length_cons,List.length_nil]
      rw [hd,scan_append _ _ a _ (ih (n/10) hlt a),scan_digit _ (n%10) (Nat.mod_lt _ (by decide)),hl]
      congr 1
      have hmod := Nat.div_add_mod n 10
      rw [Nat.pow_succ]
      nlinarith

theorem roundtrip (n : Nat) : parse (decimal n) = some n := by
  have hne : (decimal n).isEmpty = false := by
    cases he : decimal n with
    | nil => have h := decimal_length n; have hp := digits_pos n; simp [he] at h; omega
    | cons b bs => rfl
  simp only [parse,hne,Bool.false_eq_true,↓reduceIte,scan_decimal,Nat.zero_mul,Nat.zero_add]

theorem decimal_injective {n m : Nat} (h : decimal n = decimal m) : n = m := by
  have hh := congrArg parse h
  simpa only [roundtrip,Option.some.injEq] using hh

#print axioms scan_decimal
#print axioms roundtrip
#print axioms decimal_injective
end L3Emitter.DecimalParser

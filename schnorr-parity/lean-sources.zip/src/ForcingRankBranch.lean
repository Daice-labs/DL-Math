import RankChoiceLift
namespace L3Emitter.ForcingRankBranch
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL

def target (n:Nat) (hn:2≤n) (g:Nat) (j:BetaPort.Job n) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):=
  clause (-BetaAliasValue.choice j::RankChoiceLift.lits n hn g j.2 i b v)
def prior (n:Nat) (hn:2≤n) (g:Nat) (r:RankEvaluationBank.Ref n hn) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):=
  RankValueBranch.rows n hn g r i (SourceCoordinateValue.value n hn i r.val.2.1) b v
def rows (n:Nat) (hn:2≤n) (g:Nat) (j:BetaPort.Job n) (r:RankEvaluationBank.Ref n hn) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):=
  prior n hn g r i b v++[RankChoiceLift.row n hn g j r,target n hn g j i b v]
def program (n:Nat) (hn:2≤n) (g:Nat) (j:BetaPort.Job n) (r:RankEvaluationBank.Ref n hn) (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row):Program:=
  RankValueBranch.program n hn g r i (SourceCoordinateValue.value n hn i r.val.2.1) b v D++
    [(RankChoiceLift.row n hn g j r,RankChoiceLift.tape n hn g j r (D++prior n hn g r i b v)),
     (target n hn g j i b v,RankChoiceLift.liftTape n hn g j r i b v (D++prior n hn g r i b v++[RankChoiceLift.row n hn g j r]))]

theorem checks (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (j:BetaPort.Job n) (hj:j∈BetaPort.jobs n hn) (r:RankEvaluationBank.Ref n hn)
    (hb:g≠j.1.2.parent.beta) (hc:g≠j.1.2.parent.gamma)
    (ht:r.val.1=L3Uniform.Rank.rank j.1.2.parent.beta j.1.2.parent.gamma g) (hx:r.val.2.1=j.2)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool) (D:List Row) (hd:∀R∈SharedValueBank.result n hn,R∈D):
    check D (program n hn g j r i b v D)=some (D++rows n hn g j r i b v):=by
  have e0:=ValueInductionBranches.rank n hn g hg hs r i b v D hd
  have e1:=RankChoiceLift.checks n hn g hg hs j hj r hb hc ht (D++prior n hn g r i b v)
    (fun R h=>List.mem_append_left _ (hd R h))
  have e2:=RankChoiceLift.lift_checks n hn g j hj r hx i b v
    (D++prior n hn g r i b v++[RankChoiceLift.row n hn g j r])
    (List.mem_append_right _ (List.mem_singleton_self _)) (by
      apply List.mem_append_left;apply List.mem_append_right
      exact List.mem_append_right _ (List.mem_singleton_self _))
  have e3:check (D++prior n hn g r i b v)
      [(RankChoiceLift.row n hn g j r,RankChoiceLift.tape n hn g j r (D++prior n hn g r i b v)),
       (target n hn g j i b v,RankChoiceLift.liftTape n hn g j r i b v (D++prior n hn g r i b v++[RankChoiceLift.row n hn g j r]))]=
      some ((D++prior n hn g r i b v)++[RankChoiceLift.row n hn g j r,target n hn g j i b v]):=by
    change polEval _ _ []=some (target n hn g j i b v) at e2
    simp only [List.append_assoc] at e2
    simp only [check,e1,ite_true,List.append_assoc,List.singleton_append,e2]
  simpa only [program,rows,prior,List.append_assoc] using check_append _ _ _ _ _ e0 e3

theorem target_present (n:Nat) (hn:2≤n) (g:Nat) (j:BetaPort.Job n) (r:RankEvaluationBank.Ref n hn)
    (i:Fin (AliasAssembly.width (n+1))) (b v:Bool):target n hn g j i b v∈rows n hn g j r i b v:=
  List.mem_append_right _ (by simp)

#print axioms checks
end L3Emitter.ForcingRankBranch

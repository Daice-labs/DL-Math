import ConstantConstruction
import L3Chain

namespace L3Emitter.ConstantSource
open EREF EREF.GeneralRED REDWitness ForcingCandidates PriorityBank

abbrev F (k : Nat) := FableEncoding.fam k (3*k-4)
abbrev front (k : Nat) (hk : 3≤k) := FrontendSelection.front k hk

def eqBit (k : Nat) (hk : 3≤k) (z : Candidate (3*k-4)) : Int :=
  (front k hk).s.eqrow z.parent.beta z.port z.bit
def otherIndex {s : Nat} (z : Candidate s) := if z.port=0 then 2*z.bit+1 else 2+z.bit
def otherLiteral (k : Nat) (z : Candidate (3*k-4)) : Int := (F k).fn z.parent.beta (otherIndex z)

theorem front_retained (k : Nat) (hk : 3≤k) (R : Row) (hR : R∈FrontendSelection.db k hk) :
    R∈ConstantConstruction.result k hk :=
  ConstantConstruction.retains_rank k hk R (L3.exec_mono _ _ _
    (RestrictionBounds.retains_front k hk R (SelectedBranch.retained k hk R hR)))

theorem equality_rows (k : Nat) (hk : 3≤k) (z : Candidate (3*k-4)) (hz : z∈candidates k hk) :
    eqBit k hk z≠0 ∧
    clause [-eqBit k hk z,-otherLiteral k z,ConstantLookup.literal k z]∈ConstantConstruction.result k hk ∧
    clause [-eqBit k hk z,otherLiteral k z,-ConstantLookup.literal k z]∈ConstantConstruction.result k hk := by
  have hw:=wellformed _ _ z hz
  have hg:=(F k).final_branch_ready (FrontendSelection.prior k hk) (FrontendSelection.prior_good k hk)
  have hh : (F k).Good3 (front k hk) := hg.1
  obtain ⟨he0,he1,_,_⟩:=hh.2.2.1 z.parent.beta z.port
    (by have:=z.parent.beta_pos;omega)
    (by have:=z.parent.ordered;have:=z.parent.gamma_lt;change z.parent.beta<3*k-4;omega) hw.2.1
  have heq : (F k).PEq z.parent.beta z.port z.bit (front k hk) := by
    have hb:z.bit=0 ∨ z.bit=1:=by omega
    rcases hb with hb|hb <;> rw [hb] <;> assumption
  have he:=L3.eqDef_rows (F k).db5 (front k hk).s.cmds _ _ _ heq.1
  have hi : L3.Fam.eqPair z.port z.bit=(ConstantLookup.index z,otherIndex z) := by
    have hp:z.port=0 ∨ z.port=1:=by omega
    have hb:z.bit=0 ∨ z.bit=1:=by omega
    rcases hp with hp|hp <;> rcases hb with hb|hb <;>
      simp [L3.Fam.eqPair,ConstantLookup.index,otherIndex,hp,hb]
  rw [hi] at he
  have h0 : ConstantLookup.literal k z≠0 := by have:=ConstantLookup.literal_bound k hk z hz;intro h;rw [h] at this;simp at this
  have h1 : otherLiteral k z≠0 := by have:=(F k).fn_pos z.parent.beta (otherIndex z);unfold otherLiteral;omega
  have hE : eqBit k hk z≠0 := by have:=heq.2.1;unfold eqBit;omega
  refine ⟨hE,?_,?_⟩
  · have hr:=front_retained k hk _ he.2.1
    change clause [ConstantLookup.literal k z,-otherLiteral k z,-eqBit k hk z]∈ConstantConstruction.result k hk at hr
    rw [ForcingBinding.rotate3 _ _ _ h0 (by omega) (by omega)] at hr
    have hp : clause [-eqBit k hk z,ConstantLookup.literal k z,-otherLiteral k z]=
        clause [-eqBit k hk z,-otherLiteral k z,ConstantLookup.literal k z] :=
      ProjectionTrace.clause_perm _ _ (by simp [Valid,hE,h0,h1]) (by simp [Valid,hE,h0,h1])
        (List.Perm.cons _ (List.Perm.swap ..))
    rwa [hp] at hr
  · have hr:=front_retained k hk _ he.2.2.1
    change clause [-ConstantLookup.literal k z,otherLiteral k z,-eqBit k hk z]∈ConstantConstruction.result k hk at hr
    rw [ForcingBinding.rotate3 _ _ _ (by omega) h1 (by omega)] at hr
    have hp : clause [-eqBit k hk z,-ConstantLookup.literal k z,otherLiteral k z]=
        clause [-eqBit k hk z,otherLiteral k z,-ConstantLookup.literal k z] :=
      ProjectionTrace.clause_perm _ _ (by simp [Valid,hE,h0,h1]) (by simp [Valid,hE,h0,h1])
        (List.Perm.cons _ (List.Perm.swap ..))
    rwa [hp] at hr

theorem selected_field (k : Nat) (hk : 3≤k) (n : Node) (hn : n∈ConstantLookup.ns k hk)
    (z : Candidate (3*k-4)) (hz : z∈candidates k hk) (hid : n.input=(z.var:Int))
    (x : Int) (hx : x∈fields k hk z) :
    polEval (dbOf (ForcingFamily.selected k hk))
      (PriorityExclusive.tokens (ForcingFamily.selected k hk) (n.choice:Int) n.input x) []=
        some (clause [-(n.choice:Int),x]) := by
  obtain ⟨z',hz',he,hh⟩:=ForcingCandidates.selected_fields k hk n hn
  have heq:=ConstantLookup.id_injective _ _ z' z hz' hz (by omega)
  subst z';exact hh x hx

#print axioms equality_rows
#print axioms selected_field
end L3Emitter.ConstantSource

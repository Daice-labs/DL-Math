import NativeCompatibleFamily
import CanonicalBaseMachineFields
import NativeParserFieldNames
import NumericOriginalFields
namespace L3Emitter.NativeCompatibleBaseRanges
open EREF EREF.GeneralRED NativeSparseStore FieldLengthsFromIDs RecordedOperandFields

theorem allocation_le (n:Nat) (hn:2≤n):
 (NativeCompatibleFamily.compiled n).store.next≤(NativeRecordedFamily.compiled n).store.next:=by
 have h1:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id _ (NativeCompatibleFamily.checked n hn)
 have h2:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id _ (RecordedUniformFamily.recorded_refutation n hn).1
 change (NativeCompatibleFamily.compiled n).store.next=_ at h1
 change (NativeRecordedFamily.compiled n).store.next=_ at h2
 rw [h1,h2]
 exact Nat.add_le_add_left (NativeTautGoalCosts.allocation _ _) _

theorem counter:(NativeCompatibleFamily.compiled 2).store.next<CanonicalMachineReference.referenceLimit:=by
 have h:=(allocation_le 2 (by omega)).trans ActualReferenceWidths.base_counter
 have hb:ActualReferenceWidths.baseBound<CanonicalMachineReference.referenceLimit:=by
  norm_num [ActualReferenceWidths.baseBound,CanonicalMachineReference.referenceLimit]
 exact lt_of_le_of_lt h hb

theorem fields:
 WholeFileByteBudget.Fields CanonicalBaseMachineFields.bound (CanonicalBaseMachineFields.bound+1)
  (CanonicalBaseMachineFields.bound+1) (NativeRecordedFamily.original 2)
  (initial (NativeRecordedFamily.original 2)) id (NativeCompatibleFamily.emitter 2):=by
 have hc:=NativeTautGoalCosts.content CanonicalBaseMachineFields.bound (NativeRecordedFamily.original 2)
  (RecordedUniformFamily.emitter 2) CanonicalBaseMachineFields.numeric
 have hr:=ActionReferenceBounds.program 0 (RecordedUniformFamily.guard 2) _ _
  (initial (NativeRecordedFamily.original 2)) id _ (by change 0<_+1;omega)
  (initial_embeds _) (NativeCompatibleFamily.checked 2 (by omega))
 have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard 2) _ _
  (initial (NativeRecordedFamily.original 2)) id _ (NativeCompatibleFamily.checked 2 (by omega))
 rw [←he] at hr
 have hb:(NativeCompatibleFamily.compiled 2).store.next≤CanonicalBaseMachineFields.bound:=by
  have h:=(allocation_le 2 (by omega)).trans ActualReferenceWidths.base_counter
  unfold CanonicalBaseMachineFields.bound;omega
 exact RecordedOperandFields.program_compile _ _ _ _ _ _ _
  (FieldLengthsFromIDs.program_widths _ 0 (RecordedUniformFamily.guard 2) _ _ _
   (NativeCompatibleFamily.checked 2 (by omega)) hc)
  (ActionReferenceBounds.program_mono _ _ _ _ _ _ hb hr)

theorem original:∀R∈NativeRecordedFamily.original 2,ByteOperandBounds.RowBound CanonicalBaseMachineFields.bound R:=by
 intro R hR
 exact NumericOriginalFields.row 2 2 _ (by decide) (by decide) (by decide) R hR

/-- The actual encountered namespace fits at the base without constructing its
serialized stream. Units are variable names, not bytes or currency. -/
theorem names:(NativeParserBundle.names 2).length<CanonicalMachineReference.referenceLimit:=
 lt_of_le_of_lt (NativeParserFieldNames.names_length 2 _ _ _ original fields) CanonicalBaseMachineFields.in_range

#print axioms counter
#print axioms names
end L3Emitter.NativeCompatibleBaseRanges

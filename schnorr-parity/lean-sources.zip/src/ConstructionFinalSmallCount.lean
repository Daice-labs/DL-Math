import ConstructionLowerBasicCount
import GateEvaluationSize
namespace L3Emitter.ConstructionFinalSmallCount
set_option maxRecDepth 2000
set_option maxHeartbeats 800000
open EREF EREF.GeneralRED AliasProgram ConstructionCountTools ConstructionRelationCount FinalOutputDefinitions

theorem specs (n : Nat) : (FinalSelectorSpecs.specs n).length≤1+(W n-1)^2 := by
  unfold FinalSelectorSpecs.specs
  have h:=flat_bound (List.finRange (W n-1))
    (fun i=>(List.finRange (W n-1)).filterMap (fun j=>if i<j then some (FinalSelectorSpecs.pair n i j) else none))
    (W n-1) (by intro i hi;exact (List.length_filterMap_le ..).trans_eq List.length_finRange)
  simp only [List.length_finRange] at h
  simp only [List.length_cons]
  nlinarith

theorem selectors (n : Nat) (hn : 2≤n) : (FinalSelectorBank.program n hn).length≤136*(n+1)^2 := by
  have h:=retained_fold (FinalSelectorBank.leaf n hn) (FinalSelectorBank.rows n hn)
    (FinalSelectorBank.jobs n) (FinalSelectorSources.D n hn) 4 (by
      intro j hj D;simp [FinalSelectorBank.leaf,MuxConditionalClause.command_count])
  change (FinalSelectorBank.program n hn).length≤_ at h
  have hj:(FinalSelectorBank.jobs n).length=2*(FinalSelectorSpecs.specs n).length:=by
    simp [FinalSelectorBank.jobs,List.length_flatMap];omega
  rw [hj] at h
  have hw:W n-1≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);unfold W;omega
  have hp:=Nat.pow_le_pow_left hw 2
  have hs:=specs n
  nlinarith

theorem cardinalities (n : Nat) (hn : 2≤n) : (FinalSelectorCardinalities.program n hn).length≤8*(n+1) := by
  have h:=retained_fold (FinalSelectorCardinalities.leaf n hn) (FinalSelectorCardinalities.rows n hn)
    (List.finRange 2) (FinalSelectorBank.result n hn) (W n-1) (by
      intro p hp D;simpa only [FinalSelectorCardinalities.xs,List.length_ofFn] using
        OneHotSize.commands_bound D (FinalSelectorCardinalities.xs n hn p))
  change (FinalSelectorCardinalities.program n hn).length≤_ at h
  simp only [List.length_finRange] at h
  have hw:W n-1≤4*(n+1):=by have:=AliasAssembly.width_bound (n+1);unfold W;omega
  omega

theorem u2_leaf (n : Nat) (hn : 2≤n) (p : Bool) (c : FinalFunctionFullLinks.Case) (D : List Row) :
    (FinalU2Bank.leaf n hn p c D).length≤10 := by
  have h:(OutputU2POL.program (D++FinalU2Bank.linkRows n hn c) (FinalFunctionFullLinks.guards n hn c)
      (FinalU2Bank.f n hn) (FinalU2Bank.q n hn) c p).length≤2:=by
    unfold OutputU2POL.program;split <;> simp
  simp only [FinalU2Bank.leaf,List.length_append,FinalU2Bank.linkProgram,List.length_map]
  change 8+_≤10
  omega

theorem u2_half (n : Nat) (hn : 2≤n) (p : Bool) (D : List Row) :
    (FinalU2Bank.program n hn p D).length≤200 := by
  have h:=retained_fold (FinalU2Bank.leaf n hn p) (FinalU2Bank.body n hn p) FinalU2Bank.cases D 10
    (by intro c hc E;exact u2_leaf n hn p c E)
  have hs:=U2ConstructionSize.split_commands (D++RetainedBlockFold.body (FinalU2Bank.body n hn p) FinalU2Bank.cases)
    (U2SourcePOL.literals (FinalU2Bank.q n hn) U2SourcePOL.identity U2SourcePOL.identity p) (FinalU2Bank.vars n hn)
  change _+1=2^(4+1) at hs
  change _≤16*10 at h
  simp only [FinalU2Bank.program,List.length_append]
  omega

theorem u2 (n : Nat) (hn : 2≤n) : (FinalU2Bank.bothProgram n hn).length≤400 := by
  have h0:=u2_half n hn false (FinalU2Bank.base n hn)
  have h1:=u2_half n hn true (FinalU2Bank.base n hn++FinalU2Bank.rows n hn false)
  simp only [FinalU2Bank.bothProgram,List.length_append];omega
#print axioms selectors
#print axioms cardinalities
#print axioms u2
end L3Emitter.ConstructionFinalSmallCount

import CanonicalCountRecurrence
import CanonicalAllocationBound
import FormulaSize

namespace L3Emitter.CanonicalPrefixEnvelope
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation AuditLocalCosts
open CanonicalCountRecurrence ActualLowerComposition

theorem checked_length (M guard : Nat) (D E : List Row) (p : Program)
    (hp : check M guard D p=some E) : E.length=D.length+p.length := by
  induction p generalizing D with
  | nil=>simp only [check,Option.some.injEq] at hp;subst E;simp
  | cons c cs ih=>
    simp only [check] at hp
    split at hp
    · have hi:=ih (D++[c.row]) hp
      simpa [List.length_append,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hi
    · contradiction

def sourceRows (i : Nat) := (OriginalEncoding.rows (i+3) (3*(i+3)-4)).length

/-- The retained replay frame is bounded by the original upper row count and
new main prefix length. This is proved from the actual prefix execution. -/
theorem frame_bound (i : Nat) : frameRows i≤sourceRows i+(levelPrefix i).length := by
  have hp:=RecordedActualActivation.full_certified (i+2) (by omega)
    (RecordedRecursiveStep.reserve (i+2) (RecordedUniformFamily.family i))
    (by unfold RecordedRecursiveStep.reserve;exact Nat.le_max_left _ _)
  obtain ⟨g,hg⟩:=hp
  have h:=checked_length 0 g _ _ _ hg
  simp only [RecordedActualActivation.frame,RecordedActualActivation.bankResult,
    GuardActivation.bank,List.length_append,List.length_map,List.length_singleton] at h
  change frameRows i≤(OriginalEncoding.rows (i+3) (3*(i+3)-4)).length+_
  unfold frameRows levelPrefix
  have he:i+2+1=i+3:=by omega
  rw [he] at h
  omega

theorem prefix_cert_bound (i A F : Nat) (ha : (levelPrefix i).length≤A) (hf : sourceRows i≤F) :
    certCount (levelPrefix i)≤A*(F+A) := by
  have hp:=RecordedActualActivation.full_certified (i+2) (by omega)
    (RecordedRecursiveStep.reserve (i+2) (RecordedUniformFamily.family i))
    (by unfold RecordedRecursiveStep.reserve;exact Nat.le_max_left _ _)
  obtain ⟨g,hg⟩:=hp
  have h:=CanonicalAllocationBound.certificate_count 0 g _ _ _ hg
  have he:i+2+1=i+3:=by omega
  rw [he] at h
  change certCount (levelPrefix i)≤(levelPrefix i).length*(sourceRows i+(levelPrefix i).length) at h
  exact h.trans (Nat.mul_le_mul ha (Nat.add_le_add hf ha))

def mainSum : Nat→Nat
  | 0=>0
  | m+1=>mainSum m+(levelPrefix m).length

theorem main_exact (m : Nat) : (RecordedUniformFamily.family m).length=
    (RecordedUniformFamily.family 0).length+mainSum m := by
  induction m with
  | zero=>simp [mainSum]
  | succ m ih=>rw [RecordedUniformFamily.main_recurrence,ih];simp only [mainSum,levelPrefix];omega

theorem main_sum_bound (m A : Nat) (h : ∀ i<m,(levelPrefix i).length≤A) : mainSum m≤m*A := by
  induction m with
  | zero=>simp [mainSum]
  | succ m ih=>
    have hi:=ih (by intro i hi;exact h i (by omega))
    have hm:=h m (by omega)
    simp only [mainSum,Nat.succ_mul]
    omega

/-- All certificate counts, including retained-frame copies, reduce to a
main-prefix-length envelope and an original-formula row envelope. There is
no unbounded certificate oracle in this reduction. The actual main-prefix
length envelope still has to be discharged. -/
theorem certificate_envelope (m A F : Nat)
    (ha : ∀ i<m,(levelPrefix i).length≤A) (hf : ∀ i<m,sourceRows i≤F) :
    certCount (RecordedUniformFamily.family m)≤certCount (RecordedUniformFamily.family 0)+
      m*(A*(F+A))+m*(F+A)*(redCount (RecordedUniformFamily.family 0)+m*A) := by
  apply CanonicalCountRecurrence.cert_bound
  · intro i hi
    exact (frame_bound i).trans (Nat.add_le_add (hf i hi) (ha i hi))
  · intro i hi
    exact (CanonicalAllocationBound.reds_le _).trans (ha i hi)
  · intro i hi
    exact prefix_cert_bound i A F (ha i hi) (hf i hi)

#print axioms frame_bound
#print axioms prefix_cert_bound
#print axioms main_exact
#print axioms certificate_envelope
end L3Emitter.CanonicalPrefixEnvelope

import ConstructionFrontendCountTools

namespace L3Emitter.ConstructionFrontendDefinitionCount
open EREF EREF.GeneralRED L3 L3.Fam ConstructionFrontendCountTools

@[simp] theorem setLive_cost {m : Nat} (t : StI m) (f : Nat→Nat) : state (t.setLive f)=state t := rfl
@[simp] theorem setEdges_cost {m : Nat} (t : StI m) (f : Nat→Nat→Nat→Nat) : state (t.setEdges f)=state t := rfl
@[simp] theorem setEqrow_cost {m : Nat} (t : StI m) (f : Nat→Nat→Nat→Nat) : state (t.setEqrow f)=state t := rfl
@[simp] theorem setForce_cost {m : Nat} (t : StI m) (f : Nat→Nat→Nat) : state (t.setForce f)=state t := rfl
@[simp] theorem setP0force_cost {m : Nat} (t : StI m) (f : Nat→Nat→Nat) : state (t.setP0force f)=state t := rfl
@[simp] theorem setEligible_cost {m : Nat} (t : StI m) (f : Nat→Nat) : state (t.setEligible f)=state t := rfl
@[simp] theorem setA_cost {m : Nat} (t : StI m) (a : Nat) : state (t.setA a)=state t := rfl

variable (F : Fam)

theorem stage0 : state F.stage0=3 := by
  simp [Fam.stage0,state,list,ConstructionFrontendCountTools.command,StI.init,St.init,StI.OR,St.OR,StI.AND,St.AND,
    StI.rup,St.rup,StI.setLive,St.chk]

theorem edge (g : Nat) (acc : StI F.V×List Int) (hp : Nat×Nat) :
    state (F.edgeStep g acc hp).1≤state acc.1+3 := by
  simpa only [Fam.edgeStep,setEdges_cost,List.length_cons,List.length_nil] using
    and_cost acc.1 [(acc.1.s.live hp.1:Int),(F.sel hp.1 hp.2 (F.k+g):Int)]

theorem edge_terms (g : Nat) (acc : StI F.V×List Int) (hp : Nat×Nat) :
    (F.edgeStep g acc hp).2.length=acc.2.length+1 := by
  simp [Fam.edgeStep]

theorem terms_fold (g : Nat) (acc : StI F.V×List Int) (xs : List (Nat×Nat)) :
    (xs.foldl (F.edgeStep g) acc).2.length=acc.2.length+xs.length := by
  induction xs generalizing acc with
  | nil => simp
  | cons x xs ih => simp only [List.foldl_cons,ih,edge_terms,List.length_cons];omega

theorem edge_pairs (g : Nat) : (F.edgePairs g).length≤2*F.s := by
  have h:=FormulaSize.flatMap_bound (List.range' (g+1) (F.s-1-g))
    (fun h=>[(h,0),(h,1)]) 2 (by intros;simp)
  simp only [List.length_range'] at h
  exact h.trans (by omega)

theorem gate (t : StI F.V) (g : Nat) : state (F.gateStep t g)≤state t+(8*F.s+1) := by
  let u:=(F.edgePairs g).foldl (F.edgeStep g) (t,[])
  have h:=fold_cost (fun a:StI F.V×List Int=>state a.1) (F.edgeStep g)
    (F.edgePairs g) (t,[]) 3 (edge F g)
  have ht:=terms_fold F g (t,[]) (F.edgePairs g)
  have ho:=or_cost u.1 u.2
  have he:=edge_pairs F g
  change state u.1≤state t+(F.edgePairs g).length*3 at h
  change u.2.length=0+(F.edgePairs g).length at ht
  change state (F.gateStep t g)≤_
  simpa only [Fam.gateStep,setLive_cost] using (show state (u.1.OR u.2).2≤state t+(8*F.s+1) by
    simp only [List.length_nil,zero_add] at ht
    omega)

theorem stage1 (t : StI F.V) : state (F.stage1 t)≤state t+(F.s-1)*(8*F.s+1) := by
  simpa only [List.length_reverse,List.length_range] using
    fold_cost state F.gateStep ((List.range (F.s-1)).reverse) t (8*F.s+1) (gate F)

theorem eq_step (hm : 1≤F.V) (g p : Nat) (acc : StI F.V×List Int) (b : Nat) :
    state (F.eqStep hm g p acc b).1=state acc.1+4 := by
  simp only [Fam.eqStep,setEqrow_cost,eq_cost]

theorem eq_terms (hm : 1≤F.V) (g p : Nat) (acc : StI F.V×List Int) (b : Nat) :
    (F.eqStep hm g p acc b).2.length=acc.2.length+1 := by simp [Fam.eqStep]

theorem port (hm : 1≤F.V) (g : Nat) (acc : StI F.V×List Int) (p : Nat) :
    state (F.portStep hm g acc p).1≤state acc.1+14 := by
  let u:=([0,1]:List Nat).foldl (F.eqStep hm g p) (acc.1,[])
  have he:state u.1=state acc.1+8 := by simp [u,List.foldl_cons,eq_step]
  have hl:u.2.length=2 := by simp [u,List.foldl_cons,eq_terms]
  have ho:=or_cost u.1 u.2
  let v:=(u.1.OR u.2).2.setForce (fun g' p'=>if g'=g ∧ p'=p then (u.1.OR u.2).1 else (u.1.OR u.2).2.s.force g' p')
  have ha:=and_cost v [(F.sel g p 0:Int),((u.1.OR u.2).1:Int)]
  change state (v.AND [(F.sel g p 0:Int),((u.1.OR u.2).1:Int)]).2≤state acc.1+14
  have hv:state v=state (u.1.OR u.2).2 := rfl
  simp only [List.length_cons,List.length_nil] at ha
  omega

theorem port_terms (hm : 1≤F.V) (g : Nat) (acc : StI F.V×List Int) (p : Nat) :
    (F.portStep hm g acc p).2.length=acc.2.length+1 := by simp [Fam.portStep]

theorem eligible (hm : 1≤F.V) (t : StI F.V) (g : Nat) :
    state (F.eligStep hm t g)≤state t+34 := by
  let u:=([0,1]:List Nat).foldl (F.portStep hm g) (t,[])
  have he:state u.1≤state t+28 := by
    have h0:=port F hm g (t,[]) 0
    have h1:=port F hm g (F.portStep hm g (t,[]) 0) 1
    change state (F.portStep hm g (t,[]) 0).1≤state t+14 at h0
    exact h1.trans (by omega)
  have hl:u.2.length=2 := by simp [u,List.foldl_cons,port_terms]
  have ho:=or_cost u.1 u.2
  let v:=(u.1.OR u.2).2
  have ha:=and_cost v [(v.s.live g:Int),((u.1.OR u.2).1:Int)]
  change state (v.AND [(v.s.live g:Int),((u.1.OR u.2).1:Int)]).2≤state t+34
  simp only [List.length_cons,List.length_nil] at ha
  have hv:state v=state (u.1.OR u.2).2:=rfl
  omega

theorem stage2 (hm : 1≤F.V) (t : StI F.V) :
    state (F.stage2 hm t)≤state t+(F.s-1)*34 := by
  simpa only [List.length_range'] using fold_cost state (F.eligStep hm)
    (List.range' 1 (F.s-1)) t 34 (eligible F hm)

theorem stage3 (t : StI F.V) : state (F.stage3 t)≤state t+F.s+1 := by
  have h:=or_cost t ((List.range' 1 (F.s-1)).map fun g=>(t.s.eligible g:Int))
  simp only [List.length_map,List.length_range'] at h
  exact h.trans (by omega)

/-- Complete definition prefix cost; all bounds depend only on gate budget.
Unit: MAIN COMMANDS after expansion, not stored local proofs. -/
theorem definition_prefix (k s : Nat) (hs : 1≤s) :
    (RecordedFrontendDefs.stage3 k s hs).length≤8*s^2+37*s+4 := by
  let F:=FableEncoding.fam k s
  have h0:=stage0 F
  have h1:=stage1 F F.stage0
  have h2:=stage2 F (F.V_pos hs) (F.stage1 F.stage0)
  have h3:=stage3 F (F.stage2 (F.V_pos hs) (F.stage1 F.stage0))
  have h4:(F.s-1)*(8*F.s+1)≤F.s*(8*F.s+1):=Nat.mul_le_mul_right _ (Nat.sub_le ..)
  have h5:(F.s-1)*34≤F.s*34:=Nat.mul_le_mul_right _ (Nat.sub_le ..)
  unfold RecordedFrontendDefs.stage3
  rw [definitions]
  change state (F.t3 hs)≤_
  unfold Fam.t3
  have hFs:F.s=s:=rfl
  nlinarith

#print axioms definition_prefix
end L3Emitter.ConstructionFrontendDefinitionCount

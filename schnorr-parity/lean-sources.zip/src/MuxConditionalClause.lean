import GuardedVectorTransport
namespace L3Emitter.MuxConditionalClause
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram ReferenceTransport Resolution GuardedVectorTransport
variable {ι:Type}
def caseRows (c:Bit) (q:ι→Bit) (ls:List (ι×Bool)):=
  [branch (GuardedVectorTransport.row q ls) (-c.val),branch (GuardedVectorTransport.row q ls) c.val]
def cases (D:List Row) (c:Bit) (a b q:ι→Bit) (ls:List (ι×Bool)):Program:=
  [(branch (GuardedVectorTransport.row q ls) (-c.val),unguardedTape D (neg c) a q ls),
   (branch (GuardedVectorTransport.row q ls) c.val,tape D c b q ls)]
def program (D:List Row) (c:Bit) (a b q:ι→Bit) (ls:List (ι×Bool)):Program:=
  let E:=D++caseRows c q ls
  cases D c a b q ls++[(GuardedVectorTransport.row q ls,mergeTokens (locate E (branch (GuardedVectorTransport.row q ls) c.val)) (locate E (branch (GuardedVectorTransport.row q ls) (-c.val))))]
def result (D:List Row) (c:Bit) (q:ι→Bit) (ls:List (ι×Bool)):=D++caseRows c q ls++[GuardedVectorTransport.row q ls]

theorem checks (D:List Row) (c:Bit) (a b q:ι→Bit) (ls:List (ι×Bool)) (hne:ls≠[])
    (ha:GuardedVectorTransport.row a ls∈D) (hb:branch (GuardedVectorTransport.row b ls) c.val∈D)
    (hra:Relations D (neg c) a q) (hrb:Relations D c b q):
    check D (program D c a b q ls)=some (result D c q ls):=by
  have h0:=unguarded_checks D (neg c) a q ls hne ha hra
  have h1:=GuardedVectorTransport.checks D c b q ls hb hrb
  have hc:check D (cases D c a b q ls)=some (D++caseRows c q ls):=by
    have hh:=IndependentProgram.check_base D (cases D c a b q ls) (by
      intro cmd hm
      rcases List.mem_cons.mp hm with rfl|hm
      · exact h0
      · obtain rfl:=List.mem_singleton.mp hm;exact h1)
    simpa only [outputs,cases,caseRows,List.map_cons,List.map_nil] using hh
  let E:=D++caseRows c q ls
  have hp:branch (GuardedVectorTransport.row q ls) c.val∈E:=List.mem_append_right _ (List.mem_cons_of_mem _ (List.mem_singleton_self _))
  have hm:branch (GuardedVectorTransport.row q ls) (-c.val)∈E:=List.mem_append_right _ (List.mem_cons_self)
  have h2:=merge_succeeds (dbOf E) (GuardedVectorTransport.row q ls) (canonical_normalize _ _) c.val c.property
    (locate E (branch (GuardedVectorTransport.row q ls) c.val)) (locate E (branch (GuardedVectorTransport.row q ls) (-c.val)))
    (locate_correct _ _ hp) (locate_correct _ _ hm)
  have hf:check E [(GuardedVectorTransport.row q ls,mergeTokens (locate E (branch (GuardedVectorTransport.row q ls) c.val)) (locate E (branch (GuardedVectorTransport.row q ls) (-c.val))))]=some (E++[GuardedVectorTransport.row q ls]):=by
    simp only [check,h2,↓reduceIte]
  exact check_append _ _ _ _ _ hc hf

theorem contains (D:List Row) (c:Bit) (q:ι→Bit) (ls:List (ι×Bool)):GuardedVectorTransport.row q ls∈result D c q ls:=
  List.mem_append_right _ (List.mem_singleton_self _)
theorem command_count (D:List Row) (c:Bit) (a b q:ι→Bit) (ls:List (ι×Bool)):
    (program D c a b q ls).length=3:=rfl
#print axioms checks
end L3Emitter.MuxConditionalClause

import AuditLocalCosts
namespace L3Emitter.AuditReplayCosts
open EREF EREF.GeneralRED RecordedScopedTrace RecordedRefutation AuditLocalCosts

theorem replay_reds (D U I : List Row) (a : Row→Nat) (l : Int) (p : Program) :
    redCount (RecordedActivatedReplay.program D U I a l p)=redCount p := by
  induction p generalizing D with
  | nil=>rfl
  | cons c p ih=>
    have ht:=ih (D++[c.row])
    unfold redCount at ht
    cases c <;> simp [RecordedActivatedReplay.program,RecordedActivatedReplay.step,redCount,ht]

/-- Exact total certificate count, including all additional retained-frame
obligations, for any accepted lower trace. No local goal is treated as free. -/
theorem replay_certificates (M guard : Nat) (D E U I : List Row) (a : Row→Nat)
    (l : Int) (p : Program) (hp : check M guard D p=some E) :
    certCount (RecordedActivatedReplay.program D U I a l p)=
      certCount p+(U.length+I.length+1)*redCount p := by
  induction p generalizing D with
  | nil=>simp [certCount,allCertificates,redCount,RecordedActivatedReplay.program]
  | cons c p ih=>
    simp only [check] at hp
    split at hp
    · rename_i hc
      have ht:=ih (D++[c.row]) hp
      rw [RecordedActivatedReplay.program,certs_cons,certs_cons,ht]
      cases c with
      | pol R ts=>simp [RecordedActivatedReplay.step,certificates,redCount]
      | consequence R q=>simp [RecordedActivatedReplay.step,certificates,redCount];omega
      | red R w ps=>
        have hg:=goals_length D R w (R::D) ps (Bool.and_eq_true_iff.mp hc).2
        simp only [RecordedActivatedReplay.step,certificates,RecordedReplayCost.goals_count,
          redCount,List.map_cons,List.sum_cons,List.length_cons] at *
        rw [hg]
        ring
    · contradiction

theorem relocated_rows (D F : List Row) (C : Row) (w : FiniteWitness.Data)
    (ps : List Certificate) (R : Row) :
    (RecordedActivatedReplay.relocateGoal D F C w ps R).program.length=
      (RecordedGoalLookup.pick (C::D) ps R).program.length := rebase_program_length _ _ _

/-- Rowwise rather than aggregate cost: lookup selects the first certificate
for an equal row. Repeated rows therefore require explicit multiplicities. -/
theorem replay_goal_rows (D U I : List Row) (a : Row→Nat) (l : Int) (C : Row)
    (w : FiniteWitness.Data) (ps : List Certificate) :
    ((RecordedActivatedReplay.goals D U I a l C w ps).map (fun q=>q.program.length)).sum =
      (RecordedGoalLookup.pick (C::D) ps C).program.length+U.length+I.length+
      (I.map (fun R=>(RecordedGoalLookup.pick (C::D) ps R).program.length)).sum+1+
      (D.map (fun R=>(RecordedGoalLookup.pick (C::D) ps R).program.length)).sum := by
  simp only [RecordedActivatedReplay.goals,List.map_append,List.sum_append,List.map_cons,
    List.map_nil,List.sum_cons,List.sum_nil,List.map_map,Function.comp_def,
    relocated_rows,RecordedFrameGoals.guarded_length,RecordedFrameGoals.fixed,
    List.length_cons,List.length_nil]
  have hU : (U.map (fun _=>1)).sum=U.length := by simp
  rw [hU]
  have hI : (I.map (fun R=>(RecordedGoalLookup.pick (C::D) ps R).program.length+1)).sum =
      (I.map (fun R=>(RecordedGoalLookup.pick (C::D) ps R).program.length)).sum+I.length := by
    simp [List.sum_map_add]
  rw [hI]
  omega

#print axioms replay_reds
#print axioms replay_certificates
#print axioms relocated_rows
#print axioms replay_goal_rows
end L3Emitter.AuditReplayCosts

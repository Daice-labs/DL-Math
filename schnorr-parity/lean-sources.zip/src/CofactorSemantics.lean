import CofactorClause
import OriginalEncoding
import GateTemplates

set_option linter.unusedSimpArgs false

namespace L3Emitter.CofactorSemantics
open EREF REDWitness ReferenceTransport ClauseTransport CofactorClause
open FamilyNamespace FamilyRows

/-- `n` is the number of remaining inputs; the original has `n+1`.
    Three cofactor wires per gate/row, stored once in a shared bank. -/
def lifted (n x : Nat) (side : Bool) : Nat := x + if side then truthRows n else 0
def high (n s g p x : Nat) (side : Bool) : Nat :=
  encode (n+1) s (if p<2 then .port g p (lifted n x side)
    else .val g (lifted n x side))
def low (n offset g p x : Nat) : Nat := offset+1+(3*g+p)*truthRows n+x
def guard (B : Nat) (side : Bool) : Int := if side then -(B:Int) else B

def cellRows (n s offset B g p x : Nat) : List Row :=
  (muxGate B (high n s g p x true) (high n s g p x false)).map
    (GateRow.row (low n offset g p x))

def bank (n s offset B : Nat) : List Row :=
  (List.range s).flatMap fun g => (List.range 3).flatMap fun p =>
    (List.range (truthRows n)).flatMap fun x => cellRows n s offset B g p x

def database (n s offset B : Nat) : List Row :=
  OriginalEncoding.rows (n+1) s ++ bank n s offset B

theorem lifted_lt (n x : Nat) (hx : x<truthRows n) (side : Bool) :
    lifted n x side<truthRows (n+1) := by
  have hp := truthRows_pos n
  have he : truthRows (n+1)=2*truthRows n := by unfold truthRows; rw [pow_succ]; omega
  rw [he]
  cases side <;> simp only [lifted,Bool.false_eq_true,↓reduceIte,Bool.true_eq] <;> omega

theorem high_pos (n s g p x : Nat) (hg : g<s) (hp : p<3)
    (hx : x<truthRows n) (side : Bool) : 0<high n s g p x side := by
  unfold high
  split
  · exact (encode_bounds (n+1) s (.port g p (lifted n x side))
      ⟨hg,by assumption,lifted_lt n x hx side⟩).1
  · exact (encode_bounds (n+1) s (.val g (lifted n x side))
      ⟨hg,lifted_lt n x hx side⟩).1

theorem low_pos (n offset g p x : Nat) : 0<low n offset g p x := by
  unfold low; omega

theorem cell_in_bank (n s offset B g p x : Nat) (hg : g<s) (hp : p<3)
    (hx : x<truthRows n) (R : Row) (hR : R∈cellRows n s offset B g p x) :
    R∈database n s offset B := by
  apply List.mem_append_right
  exact List.mem_flatMap.mpr ⟨g,List.mem_range.mpr hg,
    List.mem_flatMap.mpr ⟨p,List.mem_range.mpr hp,
      List.mem_flatMap.mpr ⟨x,List.mem_range.mpr hx,hR⟩⟩⟩

def linkRow (n s offset B g p x : Nat) (side sign : Bool) : Row :=
  clause [guard B side,-output (high n s g p x side) sign,
    output (low n offset g p x) sign]

theorem link_in_bank (n s offset B g p x : Nat) (hg : g<s) (hp : p<3)
    (hx : x<truthRows n) (side sign : Bool) :
    linkRow n s offset B g p x side sign∈database n s offset B := by
  apply cell_in_bank n s offset B g p x hg hp hx
  cases side <;> cases sign <;>
    simp [linkRow,guard,cellRows,muxGate,GateRow.row,output]

def link (n s offset B g p x : Nat) (side sign : Bool) : Link :=
  .mapped (output (high n s g p x side) sign)
    (output (low n offset g p x) sign)
    (locate (database n s offset B) (linkRow n s offset B g p x side sign))

theorem link_available (n s offset B g p x : Nat) (hg : g<s) (hp : p<3)
    (hx : x<truthRows n) (side sign : Bool) :
    (link n s offset B g p x side sign).Available (dbOf (database n s offset B))
      (guard B side) := by
  refine ⟨output_nonzero _ (high_pos n s g p x hg hp hx side) sign,
    output_nonzero _ (low_pos ..) sign,?_⟩
  exact locate_correct _ _ (link_in_bank n s offset B g p x hg hp hx side sign)

def fnLiteral (n s g : Nat) (a b c : Bool) : Int :=
  output (encode (n+1) s (.fn g (2*a.toNat+b.toNat))) c

def links (n s offset B g x : Nat) (a b c side : Bool) : List Link :=
  [link n s offset B g 0 x side (!a),link n s offset B g 1 x side (!b),
   link n s offset B g 2 x side (!c),.same (fnLiteral n s g a b c)]

def original (n s g x : Nat) (a b c side : Bool) : Row :=
  (InputSwap.semantics g (lifted n x side) a b c).row (n+1) s

theorem source_binding (n s offset B g x : Nat) (a b c side : Bool) :
    sourceClause (links n s offset B g x a b c side)=original n s g x a b c side := by
  simp only [sourceClause,links,link,Link.source,clause,original,InputSwap.semantics,
    Spec.row,List.map_cons,List.map_nil,high,show (0:Nat)<2 by decide,
    show (1:Nat)<2 by decide,show ¬(2:Nat)<2 by decide,↓reduceIte,
    fnLiteral,output,FamilyRows.lit]

theorem original_in_database (n s offset B g x : Nat) (hg : g<s)
    (hx : x<truthRows n) (a b c side : Bool) :
    original n s g x a b c side∈database n s offset B := by
  apply List.mem_append_left
  apply List.mem_map.mpr
  refine ⟨InputSwap.semantics g (lifted n x side) a b c,?_,rfl⟩
  exact (OriginalEncoding.spec_mem_iff _ _ (by omega) _).mpr
    (InputSwap.Original.semantics _ _ _ _ _ hg (lifted_lt n x hx side))

def sourceId (n s offset B g x : Nat) (a b c side : Bool) : Nat :=
  locate (database n s offset B) (original n s g x a b c side)

def tape (n s offset B g x : Nat) (a b c : Bool) : List Tok :=
  tokensBoth (sourceId n s offset B g x a b c false)
    (sourceId n s offset B g x a b c true) B
    (links n s offset B g x a b c false) (links n s offset B g x a b c true)

def goal (n s offset g x : Nat) (a b c : Bool) : Row :=
  clause [output (low n offset g 0 x) (!a),output (low n offset g 1 x) (!b),
    output (low n offset g 2 x) (!c),fnLiteral n s g a b c]

/-- Every original gate-semantics clause transports for every gate and every
    truth row. Premise IDs come from the actual original encoding and the
    shared MUX bank; no unproved local leaf hypothesis is supplied. -/
theorem all_gate_semantics (n s offset B g x : Nat) (hB : 0<B) (hg : g<s)
    (hx : x<truthRows n) (a b c : Bool) :
    polEval (dbOf (database n s offset B)) (tape n s offset B g x a b c) [] =
      some (goal n s offset g x a b c) := by
  have hl : ∀ side, ∀ p∈links n s offset B g x a b c side,
      p.Available (dbOf (database n s offset B)) (guard B side) := by
    intro side p hp
    simp only [links,List.mem_cons,List.not_mem_nil,or_false] at hp
    rcases hp with rfl|rfl|rfl|rfl
    · exact link_available n s offset B g 0 x hg (by decide) hx side (!a)
    · exact link_available n s offset B g 1 x hg (by decide) hx side (!b)
    · exact link_available n s offset B g 2 x hg (by decide) hx side (!c)
    · have hfn : 0<encode (n+1) s (.fn g (2*a.toNat+b.toNat)) :=
        (encode_bounds (n+1) s (.fn g (2*a.toNat+b.toNat))
          ⟨hg,by cases a <;> cases b <;> decide⟩).1
      have hz := output_nonzero _ hfn c
      exact ⟨hz,hz,True.intro⟩
  have hs : ∀ side, dbOf (database n s offset B) (sourceId n s offset B g x a b c side)=
      some (sourceClause (links n s offset B g x a b c side)) := by
    intro side
    rw [source_binding]
    exact locate_correct _ _ (original_in_database n s offset B g x hg hx a b c side)
  exact both_succeed _ _ _ B (by omega) _ _ (by simp [links]) (by simp [links])
    (hs false) (hs true) (hl false) (hl true) (by simp [links,link,Link.target])

theorem tape_length (n s offset B g x : Nat) (a b c : Bool) :
    (tape n s offset B g x a b c).length=70 := by
  simp [tape,both_token_count,links]

#print axioms all_gate_semantics
#print axioms tape_length
end L3Emitter.CofactorSemantics

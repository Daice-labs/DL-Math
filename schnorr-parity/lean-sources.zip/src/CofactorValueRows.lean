import UnaryPortTransport

namespace L3Emitter.CofactorValueRows
open EREF EREF.GeneralRED REDWitness AliasNetwork AliasProgram GuardedGatePOL

def cofactor (n:Nat) (hn:2≤n) (g x:Nat):Bit:=
  ⟨(CofactorSemantics.low n (ConstantCofactor.offset n hn) g 2 x:Int),by
    have := CofactorSemantics.low_pos n (ConstantCofactor.offset n hn) g 2 x
    omega⟩

def unary (n:Nat) (hn:2≤n) (g:Nat) (b:Bool):Bit:=
  (AliasAssembly.built n hn).1.2 (n+1+g) (UnarySnapshots.position (AliasAssembly.width (n+1)) b)

theorem unary_keep (n:Nat) (hn:2≤n):∀R∈UnaryRelationBank.result n hn,R∈UnaryValueBank.result n hn:=
  fun R h=>UnaryValueBank.retains n hn R (UnaryLookupBank.retains n hn R h)

theorem alias_keep (n:Nat) (hn:2≤n):∀R∈(AliasAssembly.built n hn).2.rows,R∈UnaryValueBank.result n hn:=by
  intro R h
  rw [←(RecordedAliasRun.built_binding n hn).2] at h
  have hp:R∈PrimaryAliasBank.result n hn:=List.mem_append_left _ (List.mem_append_left _
    (List.mem_append_left _ (List.mem_append_left _ h)))
  exact UnaryPortTransport.category_keep n hn R (CategoryBank.retains n hn R
    (FirstPortOneHot.block_retains n hn 1 _ R (FirstPortOneHot.block_retains n hn 0 _ R hp)))

theorem raw_keep (n:Nat) (hn:2≤n):∀R∈(RawValueBank.result n hn).1,R∈UnaryValueBank.result n hn:=by
  intro R h
  exact alias_keep n hn R (AliasAssembly.preserves_predecessor n hn R
    (List.mem_append_left _ (List.mem_append_left _ h)))

theorem beta_keep (n:Nat) (hn:2≤n):∀R∈BetaValue.result n hn,R∈UnaryValueBank.result n hn:=by
  intro R h
  exact raw_keep n hn R (GammaUnary.retains n hn R (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _ h))))

theorem raw_cover (n:Nat) (hn:2≤n) (t x:Nat)
    (ht:t<RankConstruction.width (n+1)) (hx:x<FamilyNamespace.truthRows n):
    ∃r∈(RawValueBank.result n hn).2,r.1=t ∧ r.2.1=x:=by
  have h: (t,x)∈((RawValueBank.result n hn).2.map (fun r=>(r.1,r.2.1))):=by
    rw [RawValueBank.result,RawValueBank.records_cover]
    exact (RawValueBank.job_mem n (t,x)).mpr ⟨ht,hx⟩
  obtain ⟨r,hr,he⟩:=List.mem_map.mp h
  exact ⟨r,hr,congrArg Prod.fst he,congrArg Prod.snd he⟩

theorem raw_positive (n:Nat) (hn:2≤n) (D:List Row) (js:List RawValueBank.Job)
    (r:RawValueBank.Record) (hr:r∈(RawValueBank.run n hn D js).2):0<r.2.2:=by
  induction js generalizing D with
  | nil=>simp [RawValueBank.run] at hr
  | cons j js ih=>
    rcases List.mem_cons.mp hr with rfl|hr
    · change 0<RawValueBank.out n hn D j
      unfold RawValueBank.out;omega
    · exact ih _ hr

def rawBit (n:Nat) (hn:2≤n) (r:RawValueBank.Record) (hr:r∈(RawValueBank.result n hn).2):Bit:=
  ⟨(r.2.2:Int),by have:=raw_positive n hn _ _ r hr;omega⟩

theorem raw_link (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (r:RawValueBank.Record) (hr:r∈(RawValueBank.result n hn).2) (v:Bool):
    GuardedJoin.link [-(GateCategories.bit n hn g (.rank r.1)).val]
      (sign v (cofactor n hn g r.2.1)) (sign v (rawBit n hn r hr))∈UnaryValueBank.result n hn:=by
  have h:=(RawValueBank.original_to_raw_bank n hn).2 r hr g hg hs
  exact raw_keep n hn _ (UnaryValueStep.conditional_link _ (GateCategories.bit n hn g (.rank r.1))
    (cofactor n hn g r.2.1) (rawBit n hn r hr) v h.1 h.2)

theorem raw_reverse_link (n:Nat) (hn:2≤n) (g:Nat) (hg:0<g) (hs:g<3*(n+1)-4)
    (r:RawValueBank.Record) (hr:r∈(RawValueBank.result n hn).2) (v:Bool):
    GuardedJoin.link [-(GateCategories.bit n hn g (.rank r.1)).val]
      (sign v (rawBit n hn r hr)) (sign v (cofactor n hn g r.2.1))∈UnaryValueBank.result n hn:=by
  have h:=(RawValueBank.original_to_raw_bank n hn).2 r hr g hg hs
  exact raw_keep n hn _ (UnaryValueStep.conditional_link _ (GateCategories.bit n hn g (.rank r.1))
    (rawBit n hn r hr) (cofactor n hn g r.2.1) v h.2 h.1)

#print axioms raw_cover
#print axioms raw_link
#print axioms raw_reverse_link
end L3Emitter.CofactorValueRows

import CanonicalByteFraming
import CanonicalWireFamily

set_option linter.unusedSimpArgs false
namespace L3Emitter.CanonicalLineParser
open EREF EREF.GeneralRED CanonicalByteFraming CanonicalScopedBytes CanonicalScopeKernel
open CanonicalRowParser TemplateBytes

inductive Event where
  | pol (ts : List Tok)
  | pbc (R : EREF.Row)
  | red (R : EREF.Row) (w : FiniteWitness.Data)
  | goal (key : GoalKey)
  | close (id : Nat)
  | endRed

def operands (ts : List Tok) := separated (fixed " ") (ts.map (fun t=>polToken (CompactTapeBytes.token t)))
def line : Event→Bytes
  | .pol ts=>ascii "pol "++emit (operands ts)++ascii " ;"
  | .pbc R=>ascii "pbc "++emit (rowDoc R)++ascii " : subproof"
  | .red R w=>ascii "red "++emit (rowDoc R)++ascii " : "++emit (witness w)++ascii " : subproof"
  | .goal key=>ascii "proofgoal "++emit (CanonicalWireFamily.keyDoc key)
  | .close id=>ascii "qed : "++decimal id++ascii " ;"
  | .endRed=>ascii "qed ;"

def readRow (bs : Bytes) : Option EREF.Row := do
  let r←CanonicalRowParser.parse bs
  return ⟨r.terms.map (fun t=>(t.1,SignedNative.litId t.2)),r.rhs⟩

theorem read_row (R : EREF.Row) (hR : Canonical R) : readRow (emit (rowDoc R))=some R := by
  simp only [readRow,CanonicalRowParser.original_row_roundtrip R hR,bind,Option.bind,pbRow,
    List.map_map,Function.comp_def,CanonicalFormulaReadback.signed_id]
  simp [bind,Option.bind,List.map_map,Function.comp_def,CanonicalFormulaReadback.signed_id]

def readKey (bs : Bytes) : Option GoalKey :=
  if bs=ascii "#1" then some .candidate else (DecimalParser.parse bs).map GoalKey.database

theorem key_roundtrip (k : GoalKey) : readKey (emit (CanonicalWireFamily.keyDoc k))=some k := by
  cases k with
  | candidate=>rfl
  | database i=>
    have hn:decimal i≠ascii "#1":=by
      intro he
      have h:=congrArg DecimalParser.parse he
      rw [DecimalParser.roundtrip] at h
      contradiction
    simp [readKey,CanonicalWireFamily.keyDoc,emit,number,Piece.emit,hn,DecimalParser.roundtrip]

def readRed (bs : Bytes) : Option (EREF.Row×FiniteWitness.Data) :=
  match bs.splitOn 58 with
  | [a,b]=>do return (←readRow a,←CanonicalWitnessParser.parse b)
  | _=>none

theorem red_fields_roundtrip (R : EREF.Row) (w : FiniteWitness.Data)
    (hr : Canonical R) (hw : FiniteWitness.valid w=true) :
    readRed (emit (rowDoc R)++ascii " : "++emit (witness w))=some (R,w) := by
  have ra:(58:UInt8)∉emit (rowDoc R)++[32]:=by
    simpa using And.intro (row_avoids (pbRow R) 58 (Or.inr rfl)) (by decide : (58:UInt8)≠32)
  have wa:(58:UInt8)∉32::emit (witness w):=by
    simpa using witness_avoids w 58 (Or.inr rfl)
  rw [show ascii " : "=([32,58,32]:Bytes) by decide]
  simp only [List.append_assoc,List.cons_append,List.nil_append]
  rw [show emit (rowDoc R)++32::58::32::emit (witness w)=
    (emit (rowDoc R)++[32])++58::32::emit (witness w) by simp [List.append_assoc]]
  unfold readRed
  rw [List.splitOn_append_cons_self,List.splitOn_eq_singleton ra,List.splitOn_eq_singleton wa]
  have lr:readRow (emit (rowDoc R)++[32])=some R:=by
    have he:lex (emit (rowDoc R)++[32])=lex (emit (rowDoc R)):=by
      simpa only [show lex []=[] from rfl,List.append_nil,List.nil_append] using lex_space (emit (rowDoc R)) []
    simpa only [readRow,CanonicalRowParser.parse,he] using read_row R hr
  have lw:CanonicalWitnessParser.parse (32::emit (witness w))=some w:=by
    have he:lex (32::emit (witness w))=lex (emit (witness w)):=by
      simpa only [show lex []=[] from rfl,List.append_nil,List.nil_append] using lex_space [] (emit (witness w))
    simpa only [CanonicalWitnessParser.parse,he] using CanonicalWitnessParser.witness_roundtrip w hw
  simp [lr,lw,bind,Option.bind]

/-- The command line is dispatched by its literal ASCII prefix, then each
field is parsed from the recovered bytes. -/
def parse (bs : Bytes) : Option Event :=
  if bs.take 4=ascii "pol " then do
    let x←strip (ascii "pol ") (ascii " ;") bs
    return .pol (←CanonicalPOLParser.parse x)
  else if bs.take 4=ascii "pbc " then do
    let x←strip (ascii "pbc ") (ascii " : subproof") bs
    return .pbc (←readRow x)
  else if bs.take 4=ascii "red " then do
    let x←strip (ascii "red ") (ascii " : subproof") bs
    let (R,w)←readRed x
    return .red R w
  else if bs.take 4=ascii "proo" then do
    let x←strip (ascii "proofgoal ") [] bs
    return .goal (←readKey x)
  else if bs=ascii "qed ;" then some .endRed
  else do
    let x←strip (ascii "qed : ") (ascii " ;") bs
    return .close (←DecimalParser.parse x)

def Valid : Event→Prop
  | .pol ts=>∀ t∈ts,CanonicalPOLParser.Valid t
  | .pbc R=>Canonical R
  | .red R w=>Canonical R ∧ FiniteWitness.valid w=true
  | _=>True

theorem roundtrip (e : Event) (hv : Valid e) : parse (line e)=some e := by
  cases e with
  | pol ts=>
    have hh:(line (.pol ts)).take 4=ascii "pol ":=by
      simp only [line,List.append_assoc,show ascii "pol "=([112,111,108,32]:Bytes) by decide]
      rfl
    unfold parse
    rw [hh,if_pos rfl]
    simp only [line,strip_roundtrip,bind,Option.bind]
    rw [operands,CanonicalPOLParser.tape_roundtrip ts hv]
    rfl
  | pbc R=>
    have hh:(line (.pbc R)).take 4=ascii "pbc ":=by
      simp only [line,List.append_assoc,show ascii "pbc "=([112,98,99,32]:Bytes) by decide]
      rfl
    unfold parse
    rw [hh]
    simp only [show ascii "pbc "≠ascii "pol " by decide,↓reduceIte]
    simp only [line,strip_roundtrip,bind,Option.bind,read_row R hv]
    rfl
  | red R w=>
    have hh:(line (.red R w)).take 4=ascii "red ":=by
      simp only [line,List.append_assoc,show ascii "red "=([114,101,100,32]:Bytes) by decide]
      rfl
    have he:line (.red R w)=ascii "red "++(emit (rowDoc R)++ascii " : "++emit (witness w))++ascii " : subproof":=by
      simp only [line,List.append_assoc]
    unfold parse
    rw [hh]
    simp only [show ascii "red "≠ascii "pol " by decide,show ascii "red "≠ascii "pbc " by decide,↓reduceIte]
    rw [he,strip_roundtrip]
    simp only [bind,Option.bind,red_fields_roundtrip R w hv.1 hv.2]
    rfl
  | goal key=>
    have hh:(line (.goal key)).take 4=ascii "proo":=by
      simp only [line,show ascii "proofgoal "=([112,114,111,111,102,103,111,97,108,32]:Bytes) by decide,
        show ascii "proo"=([112,114,111,111]:Bytes) by decide]
      rfl
    have he:line (.goal key)=ascii "proofgoal "++emit (CanonicalWireFamily.keyDoc key)++[]:=by simp [line]
    unfold parse
    rw [hh]
    simp only [show ascii "proo"≠ascii "pol " by decide,show ascii "proo"≠ascii "pbc " by decide,
      show ascii "proo"≠ascii "red " by decide,↓reduceIte]
    rw [he,strip_roundtrip]
    simp only [bind,Option.bind,key_roundtrip]
    rfl
  | close id=>
    have hh:(line (.close id)).take 4=ascii "qed ":=by
      simp only [line,List.append_assoc,show ascii "qed : "=([113,101,100,32,58,32]:Bytes) by decide,
        show ascii "qed "=([113,101,100,32]:Bytes) by decide]
      rfl
    have he:line (.close id)≠ascii "qed ;":=by
      intro he
      have h:=congrArg (List.take 5) he
      simp only [line,List.append_assoc,
        show ascii "qed : "=([113,101,100,32,58,32]:Bytes) by decide,
        show ascii "qed ;"=([113,101,100,32,59]:Bytes) by decide] at h
      change ([113,101,100,32,58]:Bytes)=[113,101,100,32,59] at h
      exact (by decide : ([113,101,100,32,58]:Bytes)≠[113,101,100,32,59]) h
    unfold parse
    rw [hh]
    simp only [show ascii "qed "≠ascii "pol " by decide,show ascii "qed "≠ascii "pbc " by decide,
      show ascii "qed "≠ascii "red " by decide,show ascii "qed "≠ascii "proo" by decide,he,↓reduceIte]
    simp only [line,strip_roundtrip,bind,Option.bind,DecimalParser.roundtrip]
    rfl
  | endRed=>rfl

#print axioms read_row
#print axioms red_fields_roundtrip
#print axioms roundtrip
end L3Emitter.CanonicalLineParser

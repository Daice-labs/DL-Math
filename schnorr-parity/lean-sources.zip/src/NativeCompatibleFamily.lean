import NativeTautGoalCosts
import CanonicalByteAcceptance
namespace L3Emitter.NativeCompatibleFamily
open EREF EREF.GeneralRED NativeSparseStore RecordedScopedTrace

def emitter (n:Nat):Program:=NativeTautGoalLowering.program (NativeRecordedFamily.original n) (RecordedUniformFamily.emitter n)
def compiled (n:Nat):=NativeRecordedProgram.compile (NativeRecordedFamily.original n)
 (initial (NativeRecordedFamily.original n)) id (emitter n)
def conclusion (n:Nat):Nat:=(compiled n).ids
 (ReferenceTransport.locate (RecordedUniformFamily.finalRows n) (REDWitness.clause []))
def commands (n:Nat):=CanonicalScopeKernel.compile (NativeRecordedFamily.original n)
 (initial (NativeRecordedFamily.original n)) id (emitter n)
def file (n:Nat):CanonicalWholeFile.File:=⟨(NativeRecordedFamily.original n).length,commands n,conclusion n⟩
def bytes (n:Nat):Bytes:=CanonicalWholeFile.render (file n)

theorem checked (n:Nat) (hn:2≤n):check 0 (RecordedUniformFamily.guard n)
 (NativeRecordedFamily.original n) (emitter n)=some (RecordedUniformFamily.finalRows n):=
 NativeTautGoalLowering.program_accepts _ _ _ _ _ (RecordedUniformFamily.recorded_refutation n hn).1

theorem execution (n:Nat) (hn:2≤n):
 CanonicalScopeKernel.run (NativeRecordedFamily.original n) (initial (NativeRecordedFamily.original n)) id
 (commands n)=some (compiled n).store ∧
 read (compiled n).store (conclusion n:Int)=some (REDWitness.clause []):=by
 have hh:=NativeRecordedProgram.correct 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id (emitter n) (by change 0<_+1;omega) (initial_embeds _) (checked n hn)
 exact ⟨CanonicalScopeKernel.correct 0 (RecordedUniformFamily.guard n) _ _ _ _ _
  (by change 0<_+1;omega) (initial_embeds _) (checked n hn),
  read_absolute _ _ _ hh.2.1 _ _ (ReferenceTransport.locate_correct _ _ (RecordedUniformFamily.recorded_refutation n hn).2)⟩

theorem valid (n:Nat) (hn:2≤n):∀e∈(commands n).flatMap CanonicalFileGrammar.commandEvents,CanonicalLineParser.Valid e:=by
 have h:=CanonicalCompiledValidity.compile_valid 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id (emitter n) (by change 0<_+1;omega) (initial_embeds _) (checked n hn)
 intro e he
 obtain ⟨c,hc,he⟩:=List.mem_flatMap.mp he
 exact CanonicalCompiledValidity.events_valid c (h c hc) e he

theorem readback (n:Nat) (hn:2≤n):CanonicalWholeFile.parse (bytes n)=some (file n):=
 CanonicalWholeFile.roundtrip _ (valid n hn)

theorem accepted (n:Nat) (hn:2≤n):CanonicalByteAcceptance.check
 (emit (CanonicalFormulaReadback.formulaDoc (NativeRecordedFamily.original n))) (bytes n)=true:=by
 rw [CanonicalByteAcceptance.check,CanonicalByteAcceptance.formula_readback (NativeRecordedFamily.original n) (OriginalEncoding.rows_canonical n (3*n-4)),readback n hn]
 simp only [file,ne_eq,not_true_eq_false,if_false,(execution n hn).1,(execution n hn).2]
 rfl

theorem allocation (n:Nat) (hn:2≤n):(compiled n).store.next≤ConstructionClosedReference.nextBound n:=by
 have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id (emitter n) (checked n hn)
 have ha:NativeRecordedAllocation.program (emitter n)≤ConstructionClosedAllocation.allocationBound n:=
  (NativeTautGoalCosts.allocation _ _).trans (ConstructionClosedAllocation.allocations n hn)
 have hf:=CanonicalFormulaEnvelope.original_rows n
 rw [show (compiled n).store.next=(initial (NativeRecordedFamily.original n)).next+NativeRecordedAllocation.program (emitter n) from he]
 unfold initial ConstructionClosedReference.nextBound ConstructionClosedAllocation.formulaBound
 change (OriginalEncoding.rows n (3*n-4)).length+1+_≤_
 omega

theorem fields (n:Nat) (hn:2≤n):
 WholeFileByteBudget.Fields (NumericFamilyClosed.fields n) (NumericFamilyClosed.fields n+1) (NumericFamilyClosed.fields n+1)
 (NativeRecordedFamily.original n) (initial (NativeRecordedFamily.original n)) id (emitter n):=by
 have hc:=NativeTautGoalCosts.content (NumericFamilyClosed.fields n) (NativeRecordedFamily.original n)
  (RecordedUniformFamily.emitter n) (NumericFamilyClosed.family_fields n hn)
 have hr:=ActionReferenceBounds.program 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id (emitter n) (by change 0<_+1;omega) (initial_embeds _) (checked n hn)
 have he:=NativeRecordedAllocation.program_next 0 (RecordedUniformFamily.guard n) _ _
  (initial (NativeRecordedFamily.original n)) id (emitter n) (checked n hn)
 rw [←he] at hr
 have hb:(compiled n).store.next≤NumericFamilyClosed.fields n:=(allocation n hn).trans (by unfold NumericFamilyClosed.fields;omega)
 exact RecordedOperandFields.program_compile _ _ _ _ _ _ _
  (FieldLengthsFromIDs.program_widths _ 0 (RecordedUniformFamily.guard n) _ _ _ (checked n hn) hc)
  (ActionReferenceBounds.program_mono _ _ _ _ _ _ hb hr)

#print axioms accepted
#print axioms fields
end L3Emitter.NativeCompatibleFamily

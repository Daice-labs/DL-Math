import OP01_AllEllSpec

/-! Generic counting only. No avoidance or contour hypothesis is imported as a premise. -/
namespace Haralambis.Capacity
noncomputable section
open scoped BigOperators
open OP01.Fixed411

/-- Actual number of saturated physical windows among P consecutive starts. -/
def saturatedCount (x : ℤ → ℕ) (q k : ℕ) (w : ℤ) (P : ℕ) : ℕ :=
  ((Finset.range P).filter (fun t : ℕ => intervalCount x (w + (t:ℤ)) q = k+1)).card

/-- Real sum of actual length-q window counts; every membership retains its multiplicity. -/
def windowSum (x : ℤ → ℕ) (q : ℕ) (w : ℤ) (N : ℕ) : ℝ :=
  ∑ t ∈ Finset.range N, (intervalCount x (w + t) q : ℝ)

theorem intervalCount_add (x : ℤ → ℕ) (w : ℤ) (m n : ℕ) :
    intervalCount x w (m+n) = intervalCount x w m + intervalCount x (w+m) n := by
  simp only [intervalCount, Finset.sum_range_add]
  congr 1
  apply Finset.sum_congr rfl
  intro i hi
  congr 1
  push_cast
  ring

theorem intervalCount_shift (x : ℤ → ℕ) (hx : bitValid x) (w : ℤ) (N j : ℕ) :
    intervalCount x w N ≤ j + intervalCount x (w+j) N := by
  have h₁ := intervalCount_add x w N j
  have h₂ := intervalCount_add x w j N
  have h₃ := OP01.Fixed411.RealWrapper.intervalCount_le x hx w j
  have he : N+j = j+N := Nat.add_comm _ _
  rw [he] at h₁
  omega

theorem windowSum_add (x : ℤ → ℕ) (q : ℕ) (w : ℤ) (m n : ℕ) :
    windowSum x q w (m+n) = windowSum x q w m + windowSum x q (w+m) n := by
  simp only [windowSum, Finset.sum_range_add]
  congr 1
  apply Finset.sum_congr rfl
  intro i hi
  congr 2
  push_cast
  ring

theorem capacity_block (x : ℤ → ℕ) (q P k Δ J : ℕ)
    (balance : k*P+Δ=q*J)
    (windows : ∀ w : ℤ, intervalCount x w q ≤ k+1)
    (capacity : ∀ w : ℤ, saturatedCount x q k w P ≤ Δ) (w : ℤ) :
    windowSum x q w P ≤ (q:ℝ)*J := by
  have hp (t : ℕ) : intervalCount x (w+t) q ≤
      k + if intervalCount x (w+t) q = k+1 then 1 else 0 := by
    have := windows (w+t)
    split_ifs <;> omega
  have hs := Finset.sum_le_sum (s:=Finset.range P) (fun t _ => hp t)
  have hsat : (∑ t ∈ Finset.range P,
      if intervalCount x (w+t) q = k+1 then 1 else 0) = saturatedCount x q k w P := by
    simp only [saturatedCount, Finset.card_filter]
  rw [Finset.sum_add_distrib, hsat] at hs
  simp only [Finset.sum_const, Finset.card_range, smul_eq_mul] at hs
  have hc := capacity w
  have hn : (∑ t ∈ Finset.range P, intervalCount x (w+t) q) ≤ q*J := by
    nlinarith
  simpa only [windowSum, Nat.cast_sum, Nat.cast_mul] using
    (show ((∑ t ∈ Finset.range P, intervalCount x (w+t) q : ℕ):ℝ) ≤ ((q*J:ℕ):ℝ) by exact_mod_cast hn)

/-- A generic block argument, with an explicit remainder budget. -/
theorem windowSum_bound (x : ℤ → ℕ) (q P k Δ J : ℕ)
    (hP : 0<P) (balance : k*P+Δ=q*J)
    (windows : ∀ w : ℤ, intervalCount x w q ≤ k+1)
    (capacity : ∀ w : ℤ, saturatedCount x q k w P ≤ Δ) (w : ℤ) (N : ℕ) :
    windowSum x q w N ≤ ((q:ℝ)*J/P)*N + (P-1:ℝ) := by
  have hPr : (0:ℝ)<P := by exact_mod_cast hP
  have hb : (k:ℝ)*P+Δ=(q:ℝ)*J := by exact_mod_cast balance
  have hk : (k:ℝ) ≤ (q:ℝ)*J/P := by
    apply (le_div_iff₀ hPr).mpr
    have : (0:ℝ)≤Δ := Nat.cast_nonneg _
    linarith
  induction N using Nat.strong_induction_on generalizing w with
  | h N ih =>
    by_cases hn : N<P
    · have hnR : (N:ℝ) ≤ (P:ℝ)-1 := by
        have : (N:ℝ)+1≤P := by exact_mod_cast (show N+1≤P by omega)
        linarith
      have hs : windowSum x q w N ≤ (N:ℝ)*((k:ℝ)+1) := by
        unfold windowSum
        calc
          _ ≤ ∑ _t ∈ Finset.range N, ((k:ℝ)+1) := by
            apply Finset.sum_le_sum
            intro t ht
            exact_mod_cast windows (w+t)
          _ = _ := by simp; ring
      have hm := mul_le_mul_of_nonneg_left hk (Nat.cast_nonneg N)
      nlinarith
    · have hsmall : N-P<N := by omega
      have hi := ih (N-P) hsmall (w+P)
      have hblock := capacity_block x q P k Δ J balance windows capacity w
      have hsplit : N=P+(N-P) := by omega
      rw [hsplit, windowSum_add]
      push_cast
      have hNr : (N:ℝ)=(P:ℝ)+(N-P:ℕ) := by exact_mod_cast hsplit
      have hcancel : ((q:ℝ)*J/P)*P=(q:ℝ)*J := div_mul_cancel₀ _ hPr.ne'
      nlinarith

/-- Exact convolution exchange, not an independent-fibre surrogate. -/
theorem windowSum_exchange (x : ℤ → ℕ) (q N : ℕ) (w : ℤ) :
    windowSum x q w N = ∑ j ∈ Finset.range q, (intervalCount x (w+j) N : ℝ) := by
  simp only [windowSum, intervalCount, Nat.cast_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro t ht
  congr 2
  ring

theorem sum_offsets (q : ℕ) :
    (∑ j ∈ Finset.range q, (j:ℝ)) = (q:ℝ)*((q:ℝ)-1)/2 := by
  induction q with
  | zero => simp
  | succ q ih =>
    rw [Finset.sum_range_succ, ih]
    push_cast
    ring

theorem convolution_lower (x : ℤ → ℕ) (hx : bitValid x) (q N : ℕ) (w : ℤ) :
    (q:ℝ)*(intervalCount x w N:ℝ) - (q:ℝ)*((q:ℝ)-1)/2 ≤ windowSum x q w N := by
  have hp (j : ℕ) : (intervalCount x w N:ℝ) ≤ (j:ℝ)+(intervalCount x (w+j) N:ℝ) := by
    exact_mod_cast intervalCount_shift x hx w N j
  have hs := Finset.sum_le_sum (s:=Finset.range q) (fun j _ => hp j)
  rw [Finset.sum_add_distrib, sum_offsets, ← windowSum_exchange] at hs
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul] at hs
  linarith

/-- Requested bound, including N=0 and every integer origin. -/
theorem interval_bound (x : ℤ → ℕ) (hx : bitValid x) (q P k Δ J : ℕ)
    (hq : 0<q) (hP : 0<P) (hΔ : Δ≤P) (balance : k*P+Δ=q*J)
    (windows : ∀ w : ℤ, intervalCount x w q ≤ k+1)
    (capacity : ∀ w : ℤ, saturatedCount x q k w P ≤ Δ) (w : ℤ) (N : ℕ) :
    (intervalCount x w N:ℝ) ≤ (J:ℝ)/P*N + ((q:ℝ)-1)/2 + ((P:ℝ)-1)/q := by
  have h₁ := convolution_lower x hx q N w
  have h₂ := windowSum_bound x q P k Δ J hP balance windows capacity w N
  have hqr : (0:ℝ)<q := by exact_mod_cast hq
  have hPr : (0:ℝ)<P := by exact_mod_cast hP
  have he : (q:ℝ)*((J:ℝ)/P*N + ((q:ℝ)-1)/2 + ((P:ℝ)-1)/q) =
      ((q:ℝ)*J/P)*N+(P:ℝ)-1+(q:ℝ)*((q:ℝ)-1)/2 := by
    field_simp
    <;> ring
  nlinarith

end
end Haralambis.Capacity

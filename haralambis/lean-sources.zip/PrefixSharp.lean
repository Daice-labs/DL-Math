import PrefixConstruction
import SharpArithmetic

namespace Haralambis.ArbitraryTriples
noncomputable section

/-- The accepted three-prefix theorem in the canonical circular-distance κ.
The physical signing and arithmetic identity are both instantiated internally. -/
theorem primitive_three_prefix
    (a b c : ℕ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (hp : primitive a b c) (S : Set ℤ) (hS : Avoids a b c S) (t : ℤ) :
    ∃ L : ℕ, (L = a+b ∨ L = a+c ∨ L = b+c) ∧
      (Capacity.physicalCount S t L : ℝ) ≤ kappa a b c * L := by
  rw [primitive_kappa_eq_kappaStar a b c (by omega) (by omega) (by omega) hp]
  exact three_prefix_star a b c ha hab hbc S hS t

#print axioms primitive_three_prefix
end
end Haralambis.ArbitraryTriples

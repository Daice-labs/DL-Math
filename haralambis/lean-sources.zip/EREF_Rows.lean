/-!
# ER/EF Theorem 1 formalization — stage 1/3: canonical PB rows and their exact algebra

The mathematical objects of `THEOREM_B7_ER_EF.md` §2.1–2.2, transcribed from the pinned
`algebra.py` (`normalize`, `negate`, `add`, `multiply`, `divide`, `saturation`):

* a literal is a nonzero signed integer, its variable the absolute value;
* a row is a list of (positive coefficient, literal) terms and a signed integer bound;
* `normalize` sign-fixes negative coefficients (−a·ℓ = a·ℓ̄ − a), merges equal literals, cancels
  complementary pairs (c·x + c·x̄ = c, subtracting c from the bound), and sorts by variable;
* the value of a row under a total assignment is Σ aᵢ·ℓᵢ(α) − b; the row holds iff the value is ≥ 0.

Main results of this file:
* `val_normalize`   — normalization preserves the value under every assignment;
* `canonical_normalize` — its output is canonical (positive coefficients, strictly increasing
  variables, each variable in one polarity);
* `canonical_ext` — a canonical row is determined by its value function (the tool by which every
  later syntactic identity is reduced to arithmetic);
* soundness of `add`, `multiply`, `divide`, `saturate`, and the exact `negate` law;
* `canonical_contra_iff` — a canonical row is syntactically contradictory (bound > total) iff it
  holds under no assignment.
-/

namespace EREF

/-! ## Literals, assignments, values -/

abbrev Val := Nat → Bool

def b2i (b : Bool) : Int := if b then 1 else 0

/-- the Boolean value of a signed literal under α, as 0/1 (`bit if lit > 0 else 1 - bit`) -/
def litVal (α : Val) (l : Int) : Int := if 0 < l then b2i (α l.natAbs) else 1 - b2i (α l.natAbs)

theorem litVal_nonneg (α : Val) (l : Int) : 0 ≤ litVal α l := by
  unfold litVal b2i; split <;> split <;> omega
theorem litVal_le_one (α : Val) (l : Int) : litVal α l ≤ 1 := by
  unfold litVal b2i; split <;> split <;> omega
theorem litVal_neg (α : Val) (l : Int) (hl : l ≠ 0) : litVal α (-l) = 1 - litVal α l := by
  unfold litVal
  rw [Int.natAbs_neg]
  by_cases h : 0 < l
  · have h2 : ¬ (0 < -l) := by omega
    rw [if_pos h, if_neg h2]
  · have h2 : 0 < -l := by omega
    rw [if_neg h, if_pos h2]; omega

/-- Σ a·ℓ(α) over a signed-coefficient term list -/
def tvalZ (α : Val) : List (Int × Int) → Int
  | [] => 0
  | (c, l) :: ts => c * litVal α l + tvalZ α ts

/-- Σ a·ℓ(α) over a positive-coefficient term list -/
def tval (α : Val) : List (Nat × Int) → Int
  | [] => 0
  | (a, l) :: ts => (a : Int) * litVal α l + tval α ts

theorem tval_append (α : Val) (s t : List (Nat × Int)) : tval α (s ++ t) = tval α s + tval α t := by
  induction s with
  | nil => simp [tval]
  | cons x s ih => obtain ⟨a, l⟩ := x; simp [tval, ih]; omega

theorem tval_nonneg (α : Val) (ts : List (Nat × Int)) : 0 ≤ tval α ts := by
  induction ts with
  | nil => simp [tval]
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x; simp only [tval]
    have := litVal_nonneg α l
    have : 0 ≤ (a : Int) * litVal α l := Int.mul_nonneg (by omega) this
    omega

/-! ## Rows -/

structure Row where
  terms : List (Nat × Int)
  bound : Int
  deriving DecidableEq, Repr

def Row.val (R : Row) (α : Val) : Int := tval α R.terms - R.bound
def Row.sat (R : Row) (α : Val) : Prop := 0 ≤ R.val α

def totalL : List (Nat × Int) → Nat
  | [] => 0
  | (a, _) :: ts => a + totalL ts
def Row.total (R : Row) : Nat := totalL R.terms

theorem totalL_append (s t : List (Nat × Int)) : totalL (s ++ t) = totalL s + totalL t := by
  induction s with
  | nil => simp [totalL]
  | cons x s ih => obtain ⟨a, l⟩ := x; simp [totalL, ih]; omega

theorem tval_le_totalL (α : Val) (ts : List (Nat × Int)) : tval α ts ≤ totalL ts := by
  induction ts with
  | nil => simp [tval, totalL]
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x; simp only [tval, totalL]
    have h1 := litVal_le_one α l
    have h2 : (a : Int) * litVal α l ≤ a := by
      have := Int.mul_le_mul_of_nonneg_left h1 (Int.ofNat_nonneg a); simpa using this
    push_cast; omega

/-- canonical: positive coefficients, nonzero literals, variables strictly increasing
    (hence each variable occurs once, in one polarity) -/
def Canonical (R : Row) : Prop :=
  (∀ t ∈ R.terms, 0 < t.1 ∧ t.2 ≠ 0) ∧ R.terms.Pairwise (fun s t => s.2.natAbs < t.2.natAbs)

/-! ## Normalization, transcribed from `algebra.normalize` -/

/-- sign fixing: −a·ℓ = a·ℓ̄ − a, i.e. bound −= a (a < 0); zero coefficients dropped -/
def signFix : List (Int × Int) → List (Nat × Int) × Int
  | [] => ([], 0)
  | (c, l) :: ts =>
    let r := signFix ts
    if c < 0 then (((-c).toNat, -l) :: r.1, r.2 + c)       -- bound' = bound - (-c)... recorded as a delta
    else if c = 0 then r
    else ((c.toNat, l) :: r.1, r.2)

theorem signFix_val (α : Val) (ts : List (Int × Int)) (h : ∀ t ∈ ts, t.2 ≠ 0) :
    tval α (signFix ts).1 + (signFix ts).2 = tvalZ α ts := by
  induction ts with
  | nil => simp [signFix, tvalZ, tval]
  | cons x ts ih =>
    obtain ⟨c, l⟩ := x
    have hl : l ≠ 0 := h (c, l) (List.mem_cons_self ..)
    have ih' := ih (fun t ht => h t (List.mem_cons_of_mem _ ht))
    simp only [signFix, tvalZ]
    by_cases hc : c < 0
    · simp only [hc, ↓reduceIte, tval]
      rw [litVal_neg α l hl]
      have : ((-c).toNat : Int) = -c := Int.toNat_of_nonneg (by omega)
      rw [this]
      generalize hL : litVal α l = L at ih' ⊢
      have e : (-c) * (1 - L) = c * L - c := by
        rw [Int.neg_mul, Int.mul_sub, Int.mul_one]; omega
      rw [e]; omega
    · by_cases hc0 : c = 0
      · simp [hc, hc0, ih']
      · simp only [hc, hc0, ↓reduceIte, tval]
        have : (c.toNat : Int) = c := Int.toNat_of_nonneg (by omega)
        rw [this]; omega

/-! ### grouping by variable -/

/-- insert into a strictly increasing list, skipping duplicates -/
def insertVar (v : Nat) : List Nat → List Nat
  | [] => [v]
  | w :: ws => if v < w then v :: w :: ws else if v = w then w :: ws else w :: insertVar v ws

theorem mem_insertVar (u v : Nat) (ws : List Nat) : u ∈ insertVar v ws ↔ u = v ∨ u ∈ ws := by
  induction ws with
  | nil => simp [insertVar]
  | cons w ws ih =>
    simp only [insertVar]
    by_cases h1 : v < w
    · simp [h1]
    · by_cases h2 : v = w
      · subst h2; simp [h1]
      · rw [if_neg h1, if_neg h2]; simp only [List.mem_cons, ih]
        constructor <;> (rintro (h | h | h) <;> simp [h])

theorem insertVar_sorted (v : Nat) (ws : List Nat) (h : ws.Pairwise (· < ·)) :
    (insertVar v ws).Pairwise (· < ·) := by
  induction ws with
  | nil => simp [insertVar]
  | cons w ws ih =>
    rw [List.pairwise_cons] at h
    obtain ⟨hw, hws⟩ := h
    simp only [insertVar]
    by_cases h1 : v < w
    · rw [if_pos h1, List.pairwise_cons, List.pairwise_cons]
      refine ⟨?_, hw, hws⟩
      intro a ha; simp at ha; rcases ha with rfl | ha
      · exact h1
      · exact Nat.lt_trans h1 (hw a ha)
    · by_cases h2 : v = w
      · rw [if_neg h1, if_pos h2, List.pairwise_cons]; exact ⟨hw, hws⟩
      · rw [if_neg h1, if_neg h2, List.pairwise_cons]
        refine ⟨?_, ih hws⟩
        intro a ha; rw [mem_insertVar] at ha
        rcases ha with rfl | ha
        · omega
        · exact hw a ha

def varsOf (ts : List (Nat × Int)) : List Nat := ts.foldr (fun t acc => insertVar t.2.natAbs acc) []

theorem mem_varsOf (ts : List (Nat × Int)) (v : Nat) : v ∈ varsOf ts ↔ ∃ t ∈ ts, t.2.natAbs = v := by
  induction ts with
  | nil => simp [varsOf]
  | cons t ts ih =>
    simp only [varsOf, List.foldr_cons] at ih ⊢
    rw [mem_insertVar, ih]
    constructor
    · rintro (h | ⟨u, hu, rfl⟩)
      · exact ⟨t, List.mem_cons_self .., h.symm⟩
      · exact ⟨u, List.mem_cons_of_mem _ hu, rfl⟩
    · rintro ⟨u, hu, rfl⟩
      rcases List.mem_cons.mp hu with rfl | hu
      · exact Or.inl rfl
      · exact Or.inr ⟨u, hu, rfl⟩

theorem varsOf_sorted (ts : List (Nat × Int)) : (varsOf ts).Pairwise (· < ·) := by
  induction ts with
  | nil => simp [varsOf]
  | cons t ts ih => simp only [varsOf, List.foldr_cons] at ih ⊢; exact insertVar_sorted _ _ ih

theorem nodup_of_sorted (vs : List Nat) (h : vs.Pairwise (· < ·)) : vs.Nodup :=
  h.imp (fun hlt => Nat.ne_of_lt hlt)

/-- Σ of coefficients of the literal +v -/
def posSum (v : Nat) : List (Nat × Int) → Nat
  | [] => 0
  | (a, l) :: ts => (if l = (v : Int) then a else 0) + posSum v ts
/-- Σ of coefficients of the literal −v -/
def negSum (v : Nat) : List (Nat × Int) → Nat
  | [] => 0
  | (a, l) :: ts => (if l = -(v : Int) then a else 0) + negSum v ts

/-- the canonical term of variable v, if any -/
def groupTerm (ts : List (Nat × Int)) (v : Nat) : Option (Nat × Int) :=
  let p := posSum v ts; let n := negSum v ts
  if p = n then none else if n < p then some (p - n, (v : Int)) else some (n - p, -(v : Int))

def cancelSum (ts : List (Nat × Int)) : List Nat → Nat
  | [] => 0
  | v :: vs => min (posSum v ts) (negSum v ts) + cancelSum ts vs

/-- `algebra.normalize`: sign-fix, group by variable, cancel complements, sort by variable -/
def normalize (ts : List (Int × Int)) (b : Int) : Row :=
  let f := signFix ts
  let vs := varsOf f.1
  ⟨vs.filterMap (groupTerm f.1), b - f.2 - cancelSum f.1 vs⟩

/-! ### the value is preserved -/

def sumVars (f : Nat → Int) : List Nat → Int
  | [] => 0
  | v :: vs => f v + sumVars f vs

theorem sumVars_add (f g : Nat → Int) (vs : List Nat) :
    sumVars (fun v => f v + g v) vs = sumVars f vs + sumVars g vs := by
  induction vs with
  | nil => simp [sumVars]
  | cons v vs ih => simp [sumVars, ih]; omega

theorem sumVars_zero_of_not_mem (c : Int) (w : Nat) (vs : List Nat) (hw : w ∉ vs) :
    sumVars (fun v => if v = w then c else 0) vs = 0 := by
  induction vs with
  | nil => rfl
  | cons u us ih =>
    simp only [sumVars]
    have hu : u ≠ w := fun h => hw (h ▸ List.mem_cons_self ..)
    rw [if_neg hu, ih (fun h => hw (List.mem_cons_of_mem _ h))]; simp

theorem sumVars_single (c : Int) (w : Nat) (vs : List Nat) (hn : vs.Nodup) (hw : w ∈ vs) :
    sumVars (fun v => if v = w then c else 0) vs = c := by
  induction vs with
  | nil => simp at hw
  | cons v vs ih =>
    rw [List.nodup_cons] at hn
    simp only [sumVars]
    rcases List.mem_cons.mp hw with rfl | hw'
    · rw [if_pos rfl, sumVars_zero_of_not_mem _ _ _ hn.1]; simp
    · have hv : v ≠ w := fun h => hn.1 (h ▸ hw')
      rw [if_neg hv, ih hn.2 hw']; simp

theorem sumVars_zero (vs : List Nat) : sumVars (fun _ => 0) vs = 0 := by
  induction vs with
  | nil => rfl
  | cons v vs ih => simp [sumVars, ih]

theorem posSum_cons (v : Nat) (a : Nat) (l : Int) (ts : List (Nat × Int)) :
    posSum v ((a, l) :: ts) = (if l = (v : Int) then a else 0) + posSum v ts := rfl
theorem negSum_cons (v : Nat) (a : Nat) (l : Int) (ts : List (Nat × Int)) :
    negSum v ((a, l) :: ts) = (if l = -(v : Int) then a else 0) + negSum v ts := rfl

/-- the grouped value of one variable -/
def gval (α : Val) (ts : List (Nat × Int)) (v : Nat) : Int :=
  (posSum v ts : Int) * b2i (α v) + (negSum v ts : Int) * (1 - b2i (α v))

theorem tval_group (α : Val) (ts : List (Nat × Int)) (vs : List Nat) (hn : vs.Nodup)
    (hv : ∀ t ∈ ts, t.2.natAbs ∈ vs) (hz : ∀ t ∈ ts, t.2 ≠ 0) :
    tval α ts = sumVars (gval α ts) vs := by
  induction ts with
  | nil =>
    have : gval α [] = fun _ => 0 := by funext v; simp [gval, posSum, negSum]
    simp [tval, this, sumVars_zero]
  | cons t ts ih =>
    obtain ⟨a, l⟩ := t
    have hl : l ≠ 0 := hz (a, l) (List.mem_cons_self ..)
    have hmem : l.natAbs ∈ vs := hv (a, l) (List.mem_cons_self ..)
    have ih' := ih (fun t ht => hv t (List.mem_cons_of_mem _ ht)) (fun t ht => hz t (List.mem_cons_of_mem _ ht))
    simp only [tval]
    rw [ih']
    -- split the grouped value of the cons into the new term's contribution plus the rest
    have hsplit : ∀ v, gval α ((a, l) :: ts) v =
        ((if l = (v : Int) then (a : Int) * b2i (α v) else 0) +
         (if l = -(v : Int) then (a : Int) * (1 - b2i (α v)) else 0)) + gval α ts v := by
      intro v
      simp only [gval, posSum_cons, negSum_cons]
      by_cases h1 : l = (v : Int)
      · have h2 : ¬ (l = -(v : Int)) := by omega
        simp only [if_pos h1, if_neg h2]
        push_cast
        simp only [Int.zero_add, Int.add_zero]
        rw [Int.add_mul]; omega
      · simp only [if_neg h1]
        by_cases h2 : l = -(v : Int)
        · simp only [if_pos h2]
          push_cast
          simp only [Int.zero_add, Int.add_zero]
          rw [Int.add_mul]; omega
        · simp only [if_neg h2]
          push_cast
          simp only [Int.zero_add, Int.add_zero]
    have hsum : sumVars (gval α ((a, l) :: ts)) vs =
        sumVars (fun v => (if l = (v : Int) then (a : Int) * b2i (α v) else 0) +
                          (if l = -(v : Int) then (a : Int) * (1 - b2i (α v)) else 0)) vs +
        sumVars (gval α ts) vs := by
      rw [← sumVars_add]; congr 1; funext v; exact hsplit v
    rw [hsum, sumVars_add]
    -- exactly one of the two indicator sums is the literal's contribution
    by_cases hpos : 0 < l
    · have e1 : sumVars (fun (v : Nat) => if l = (v : Int) then (a : Int) * b2i (α v) else 0) vs
          = (a : Int) * b2i (α l.natAbs) := by
        have : (fun (v : Nat) => if l = (v : Int) then (a : Int) * b2i (α v) else 0)
             = (fun (v : Nat) => if v = l.natAbs then (a : Int) * b2i (α l.natAbs) else 0) := by
          funext v
          by_cases h : l = (v : Int)
          · have hv : v = l.natAbs := by omega
            rw [if_pos h, if_pos hv, hv]
          · have hv : v ≠ l.natAbs := by omega
            rw [if_neg h, if_neg hv]
        rw [this, sumVars_single _ _ _ hn hmem]
      have e2 : sumVars (fun (v : Nat) => if l = -(v : Int) then (a : Int) * (1 - b2i (α v)) else 0) vs = 0 := by
        have : (fun (v : Nat) => if l = -(v : Int) then (a : Int) * (1 - b2i (α v)) else 0) = (fun _ => (0 : Int)) := by
          funext v; have : l ≠ -(v : Int) := by omega
          simp [this]
        rw [this, sumVars_zero]
      rw [e1, e2]; simp [litVal, hpos]
    · have e1 : sumVars (fun (v : Nat) => if l = (v : Int) then (a : Int) * b2i (α v) else 0) vs = 0 := by
        have : (fun (v : Nat) => if l = (v : Int) then (a : Int) * b2i (α v) else 0) = (fun _ => (0 : Int)) := by
          funext v; have : l ≠ (v : Int) := by omega
          simp [this]
        rw [this, sumVars_zero]
      have e2 : sumVars (fun (v : Nat) => if l = -(v : Int) then (a : Int) * (1 - b2i (α v)) else 0) vs
          = (a : Int) * (1 - b2i (α l.natAbs)) := by
        have : (fun (v : Nat) => if l = -(v : Int) then (a : Int) * (1 - b2i (α v)) else 0)
             = (fun (v : Nat) => if v = l.natAbs then (a : Int) * (1 - b2i (α l.natAbs)) else 0) := by
          funext v
          by_cases h : l = -(v : Int)
          · have hv : v = l.natAbs := by omega
            rw [if_pos h, if_pos hv, hv]
          · have hv : v ≠ l.natAbs := by omega
            rw [if_neg h, if_neg hv]
        rw [this, sumVars_single _ _ _ hn hmem]
      rw [e1, e2]; simp [litVal, hpos]

theorem posSum_zero_eq_zero (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) : posSum 0 ts = 0 := by
  induction ts with
  | nil => rfl
  | cons t ts ih =>
    obtain ⟨a, l⟩ := t
    have hl : l ≠ 0 := hz (a, l) (List.mem_cons_self ..)
    simp only [posSum]; rw [if_neg (by simpa using hl), ih (fun t ht => hz t (List.mem_cons_of_mem _ ht))]

theorem negSum_zero_eq_zero (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) : negSum 0 ts = 0 := by
  induction ts with
  | nil => rfl
  | cons t ts ih =>
    obtain ⟨a, l⟩ := t
    have hl : l ≠ 0 := hz (a, l) (List.mem_cons_self ..)
    simp only [negSum]; rw [if_neg (by simpa using hl), ih (fun t ht => hz t (List.mem_cons_of_mem _ ht))]

theorem groupTerm_tval (α : Val) (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) (v : Nat) :
    (match groupTerm ts v with
      | none => 0
      | some (a, l) => (a : Int) * litVal α l) + (min (posSum v ts) (negSum v ts) : Int) = gval α ts v := by
  by_cases hv0 : v = 0
  · subst hv0
    unfold groupTerm gval
    rw [posSum_zero_eq_zero ts hz, negSum_zero_eq_zero ts hz]; simp
  unfold groupTerm gval
  generalize posSum v ts = p; generalize negSum v ts = n
  have hv : (0 : Int) < (v : Int) := by omega
  by_cases h1 : p = n
  · subst h1; simp only [↓reduceIte]
    generalize b2i (α v) = B
    rw [Int.mul_sub, Int.mul_one]; simp; omega
  · simp only [h1, ↓reduceIte]
    by_cases h2 : n < p
    · simp only [h2, ↓reduceIte, litVal]
      have hpn : ((p - n : Nat) : Int) = p - n := by omega
      have hmin : min (p : Int) (n : Int) = n := by
        rw [Int.min_def]; split <;> omega
      rw [hpn, hmin, Int.natAbs_natCast, if_pos hv]
      generalize b2i (α v) = B
      rw [Int.sub_mul, Int.mul_sub, Int.mul_one]; omega
    · simp only [h2, ↓reduceIte, litVal]
      have hpn : p < n := by omega
      have hneg : ¬ (0 : Int) < -(v : Int) := by omega
      rw [if_neg hneg, Int.natAbs_neg, Int.natAbs_natCast]
      have hnp : ((n - p : Nat) : Int) = n - p := by omega
      have hmin : min (p : Int) (n : Int) = p := by
        rw [Int.min_def]; split <;> omega
      rw [hnp, hmin]
      generalize b2i (α v) = B
      rw [Int.sub_mul, Int.mul_sub, Int.mul_sub, Int.mul_one, Int.mul_one]; omega

theorem tval_filterMap_group (α : Val) (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) (vs : List Nat) :
    tval α (vs.filterMap (groupTerm ts)) + (cancelSum ts vs : Int) = sumVars (gval α ts) vs := by
  induction vs with
  | nil => simp [tval, cancelSum, sumVars]
  | cons v vs ih =>
    simp only [List.filterMap_cons, cancelSum, sumVars]
    have h := groupTerm_tval α ts hz v
    rcases hg : groupTerm ts v with _ | ⟨a, l⟩
    · rw [hg] at h; simp only at h
      push_cast; omega
    · rw [hg] at h; simp only [tval] at h ⊢
      push_cast; omega

/-- **normalization preserves the value** under every assignment (literals nonzero) -/
theorem val_normalize (α : Val) (ts : List (Int × Int)) (b : Int) (hz : ∀ t ∈ ts, t.2 ≠ 0) :
    (normalize ts b).val α = tvalZ α ts - b := by
  unfold normalize Row.val
  simp only
  have hfix := signFix_val α ts hz
  have hz' : ∀ t ∈ (signFix ts).1, t.2 ≠ 0 := by
    clear hfix
    induction ts with
    | nil => simp [signFix]
    | cons x ts ih =>
      obtain ⟨c, l⟩ := x
      have hl : l ≠ 0 := hz (c, l) (List.mem_cons_self ..)
      have ih' := ih (fun t ht => hz t (List.mem_cons_of_mem _ ht))
      simp only [signFix]
      by_cases hc : c < 0
      · simp only [hc, ↓reduceIte]
        intro t ht; rcases List.mem_cons.mp ht with rfl | ht
        · simp; exact hl
        · exact ih' t ht
      · by_cases hc0 : c = 0
        · simp only [hc, hc0, ↓reduceIte]; exact ih'
        · simp only [hc, hc0, ↓reduceIte]
          intro t ht; rcases List.mem_cons.mp ht with rfl | ht
          · exact hl
          · exact ih' t ht
  have hgrp := tval_group α (signFix ts).1 (varsOf (signFix ts).1)
    (nodup_of_sorted _ (varsOf_sorted _))
    (fun t ht => (mem_varsOf _ _).mpr ⟨t, ht, rfl⟩) hz'
  have hfm := tval_filterMap_group α (signFix ts).1 hz' (varsOf (signFix ts).1)
  omega

/-- **normalization yields a canonical row** -/
theorem canonical_normalize (ts : List (Int × Int)) (b : Int) : Canonical (normalize ts b) := by
  unfold normalize Canonical
  simp only
  constructor
  · intro t ht
    rw [List.mem_filterMap] at ht
    obtain ⟨v, _, hv⟩ := ht
    unfold groupTerm at hv
    simp only at hv
    by_cases h1 : posSum v (signFix ts).1 = negSum v (signFix ts).1
    · simp [h1] at hv
    · simp only [h1, ↓reduceIte] at hv
      by_cases h2 : negSum v (signFix ts).1 < posSum v (signFix ts).1
      · simp only [h2, ↓reduceIte, Option.some.injEq] at hv
        rw [← hv]; constructor
        · omega
        · -- v ≠ 0 since every literal of the sign-fixed list is nonzero and v = |literal|
          intro h0; simp at h0; subst h0
          -- posSum 0 and negSum 0 coincide (literal 0 = -0), contradiction with h2
          have : ∀ us : List (Nat × Int), posSum 0 us = negSum 0 us := by
            intro us; induction us with
            | nil => rfl
            | cons u us ih => obtain ⟨a, l⟩ := u; simp [posSum, negSum, ih]
          have := this (signFix ts).1; omega
      · simp only [h2, ↓reduceIte, Option.some.injEq] at hv
        rw [← hv]; constructor
        · omega
        · intro h0; simp at h0; subst h0
          have : ∀ us : List (Nat × Int), posSum 0 us = negSum 0 us := by
            intro us; induction us with
            | nil => rfl
            | cons u us ih => obtain ⟨a, l⟩ := u; simp [posSum, negSum, ih]
          have := this (signFix ts).1; omega
  · apply List.Pairwise.filterMap (R := (· < ·))
    · intro u u' huu' t ht t' ht'
      have hu : t.2.natAbs = u := by
        unfold groupTerm at ht; simp only at ht
        split at ht
        · simp at ht
        · split at ht <;> simp only [Option.some.injEq] at ht <;> rw [← ht] <;> simp
      have hu' : t'.2.natAbs = u' := by
        unfold groupTerm at ht'; simp only at ht'
        split at ht'
        · simp at ht'
        · split at ht' <;> simp only [Option.some.injEq] at ht' <;> rw [← ht'] <;> simp
      rw [hu, hu']; exact huu'
    · exact varsOf_sorted _

/-! ## A canonical row is determined by its value function -/

def setVar (α : Val) (v : Nat) (b : Bool) : Val := fun u => if u = v then b else α u

/-- signed coefficient sum of variable v (0 if absent) -/
def sgnCoef (v : Nat) : List (Nat × Int) → Int
  | [] => 0
  | (a, l) :: ts => (if l.natAbs = v then (if 0 < l then (a : Int) else -(a : Int)) else 0) + sgnCoef v ts

theorem litVal_setVar_diff (α : Val) (v : Nat) (l : Int) (hl : l ≠ 0) :
    litVal (setVar α v true) l - litVal (setVar α v false) l =
      if l.natAbs = v then (if 0 < l then 1 else -1) else 0 := by
  unfold litVal setVar b2i
  by_cases hv : l.natAbs = v
  · rw [if_pos hv]
    by_cases h : 0 < l
    · simp [h, hv]
    · simp [h, hv]
  · rw [if_neg hv]
    by_cases h : 0 < l
    · simp [h, hv]
    · simp [h, hv]

theorem tval_setVar_diff (α : Val) (v : Nat) (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) :
    tval (setVar α v true) ts - tval (setVar α v false) ts = sgnCoef v ts := by
  induction ts with
  | nil => simp [tval, sgnCoef]
  | cons t ts ih =>
    obtain ⟨a, l⟩ := t
    have hl : l ≠ 0 := hz (a, l) (List.mem_cons_self ..)
    have ih' := ih (fun t ht => hz t (List.mem_cons_of_mem _ ht))
    simp only [tval, sgnCoef]
    have hd := litVal_setVar_diff α v l hl
    have : (a : Int) * litVal (setVar α v true) l - (a : Int) * litVal (setVar α v false) l
        = (a : Int) * (litVal (setVar α v true) l - litVal (setVar α v false) l) := by
      rw [Int.mul_sub]
    have e : (a : Int) * litVal (setVar α v true) l + tval (setVar α v true) ts -
        ((a : Int) * litVal (setVar α v false) l + tval (setVar α v false) ts) =
        ((a : Int) * litVal (setVar α v true) l - (a : Int) * litVal (setVar α v false) l) +
        (tval (setVar α v true) ts - tval (setVar α v false) ts) := by omega
    rw [e, this, hd, ih']
    by_cases hv : l.natAbs = v
    · by_cases h : 0 < l
      · simp [hv, h]
      · simp [hv, h]
    · simp [hv]

theorem val_setVar_diff (R : Row) (α : Val) (v : Nat) (hz : ∀ t ∈ R.terms, t.2 ≠ 0) :
    R.val (setVar α v true) - R.val (setVar α v false) = sgnCoef v R.terms := by
  unfold Row.val
  have := tval_setVar_diff α v R.terms hz
  omega

/-- in a strictly sorted list, a variable below the head is absent -/
theorem sgnCoef_eq_zero_of_lt (v : Nat) (ts : List (Nat × Int))
    (h : ∀ t ∈ ts, v < t.2.natAbs) : sgnCoef v ts = 0 := by
  induction ts with
  | nil => rfl
  | cons t ts ih =>
    obtain ⟨a, l⟩ := t
    simp only [sgnCoef]
    have : l.natAbs ≠ v := by have := h (a, l) (List.mem_cons_self ..); simp at this; omega
    rw [if_neg this, ih (fun t ht => h t (List.mem_cons_of_mem _ ht))]; simp

theorem sgnCoef_cons_ne (v : Nat) (a : Nat) (l : Int) (ts : List (Nat × Int)) (h : l.natAbs ≠ v) :
    sgnCoef v ((a, l) :: ts) = sgnCoef v ts := by
  simp only [sgnCoef]; rw [if_neg h]; simp

theorem sgnCoef_cons_self (a : Nat) (l : Int) (ts : List (Nat × Int)) :
    sgnCoef l.natAbs ((a, l) :: ts) = (if 0 < l then (a : Int) else -(a : Int)) + sgnCoef l.natAbs ts := by
  simp [sgnCoef]

theorem sgnCoef_cons_eq (v : Nat) (a : Nat) (l : Int) (ts : List (Nat × Int)) (h : l.natAbs = v) :
    sgnCoef v ((a, l) :: ts) = (if 0 < l then (a : Int) else -(a : Int)) + sgnCoef v ts := by
  subst h; exact sgnCoef_cons_self a l ts

/-- canonical term lists with the same signed-coefficient function are equal -/
theorem canonical_terms_ext (ts us : List (Nat × Int))
    (hts : (∀ t ∈ ts, 0 < t.1 ∧ t.2 ≠ 0) ∧ ts.Pairwise (fun s t => s.2.natAbs < t.2.natAbs))
    (hus : (∀ t ∈ us, 0 < t.1 ∧ t.2 ≠ 0) ∧ us.Pairwise (fun s t => s.2.natAbs < t.2.natAbs))
    (h : ∀ v, sgnCoef v ts = sgnCoef v us) : ts = us := by
  induction ts generalizing us with
  | nil =>
    cases us with
    | nil => rfl
    | cons u us =>
      obtain ⟨a, l⟩ := u
      have h1 := h l.natAbs
      rw [List.pairwise_cons] at hus
      rw [sgnCoef_cons_self, sgnCoef_eq_zero_of_lt l.natAbs us (fun t ht => hus.2.1 t ht)] at h1
      have ha := (hus.1 (a, l) (List.mem_cons_self ..)).1
      simp only [sgnCoef] at h1
      split at h1 <;> omega
  | cons t ts ih =>
    obtain ⟨a, l⟩ := t
    rw [List.pairwise_cons] at hts
    have hpos := hts.1 (a, l) (List.mem_cons_self ..)
    have ha : 0 < a := hpos.1
    have hl0 : l ≠ 0 := hpos.2
    cases us with
    | nil =>
      have h1 := h l.natAbs
      rw [sgnCoef_cons_self, sgnCoef_eq_zero_of_lt l.natAbs ts (fun t ht => hts.2.1 t ht)] at h1
      simp only [sgnCoef] at h1
      split at h1 <;> omega
    | cons u us =>
      obtain ⟨a', l'⟩ := u
      rw [List.pairwise_cons] at hus
      have hpos' := hus.1 (a', l') (List.mem_cons_self ..)
      have ha' : 0 < a' := hpos'.1
      have hl0' : l' ≠ 0 := hpos'.2
      -- the heads carry the same variable
      have hv : l.natAbs = l'.natAbs := by
        rcases Nat.lt_trichotomy l.natAbs l'.natAbs with hlt | heq | hgt
        · exfalso
          have h1 := h l.natAbs
          rw [sgnCoef_cons_self, sgnCoef_eq_zero_of_lt l.natAbs ts (fun t ht => hts.2.1 t ht),
              sgnCoef_cons_ne _ _ _ _ (Nat.ne_of_gt hlt),
              sgnCoef_eq_zero_of_lt l.natAbs us (fun t ht => Nat.lt_trans hlt (hus.2.1 t ht))] at h1
          split at h1 <;> omega
        · exact heq
        · exfalso
          have h1 := h l'.natAbs
          rw [sgnCoef_cons_ne _ _ _ _ (Nat.ne_of_gt hgt),
              sgnCoef_eq_zero_of_lt l'.natAbs ts (fun t ht => Nat.lt_trans hgt (hts.2.1 t ht)),
              sgnCoef_cons_self, sgnCoef_eq_zero_of_lt l'.natAbs us (fun t ht => hus.2.1 t ht)] at h1
          split at h1 <;> omega
      -- the heads are equal
      have hhead : (a, l) = (a', l') := by
        have h1 := h l.natAbs
        rw [sgnCoef_cons_self, sgnCoef_eq_zero_of_lt l.natAbs ts (fun t ht => hts.2.1 t ht),
            sgnCoef_cons_eq _ _ _ _ hv.symm,
            sgnCoef_eq_zero_of_lt l.natAbs us (fun t ht => hv ▸ hus.2.1 t ht)] at h1
        have : a = a' ∧ l = l' := by
          split at h1 <;> split at h1 <;> omega
        rw [this.1, this.2]
      rw [hhead]
      congr 1
      apply ih us ⟨fun t ht => hts.1 t (List.mem_cons_of_mem _ ht), hts.2.2⟩
        ⟨fun t ht => hus.1 t (List.mem_cons_of_mem _ ht), hus.2.2⟩
      intro v
      have h1 := h v
      by_cases hvv : l.natAbs = v
      · rw [← hvv, sgnCoef_eq_zero_of_lt l.natAbs ts (fun t ht => hts.2.1 t ht),
            sgnCoef_eq_zero_of_lt l.natAbs us (fun t ht => hv ▸ hus.2.1 t ht)]
      · rw [sgnCoef_cons_ne v a l ts hvv, sgnCoef_cons_ne v a' l' us (hv ▸ hvv)] at h1
        exact h1

/-- **a canonical row is determined by its value function** -/
theorem canonical_ext (R S : Row) (hR : Canonical R) (hS : Canonical S)
    (h : ∀ α, R.val α = S.val α) : R = S := by
  have hterms : R.terms = S.terms := by
    apply canonical_terms_ext R.terms S.terms hR hS
    intro v
    have hzR : ∀ t ∈ R.terms, t.2 ≠ 0 := fun t ht => (hR.1 t ht).2
    have hzS : ∀ t ∈ S.terms, t.2 ≠ 0 := fun t ht => (hS.1 t ht).2
    rw [← val_setVar_diff R (fun _ => false) v hzR, ← val_setVar_diff S (fun _ => false) v hzS, h, h]
  have hbound : R.bound = S.bound := by
    have := h (fun _ => false)
    unfold Row.val at this
    rw [hterms] at this
    omega
  cases R; cases S
  simp only at hterms hbound
  rw [hterms, hbound]

/-! ## The operations of `algebra.py`, and their soundness -/

def Row.toSigned (R : Row) : List (Int × Int) := R.terms.map fun (a, l) => ((a : Int), l)

theorem tvalZ_append (α : Val) (s t : List (Int × Int)) : tvalZ α (s ++ t) = tvalZ α s + tvalZ α t := by
  induction s with
  | nil => simp [tvalZ]
  | cons x s ih => obtain ⟨c, l⟩ := x; simp [tvalZ, ih]; omega

theorem tvalZ_toSigned (α : Val) (R : Row) : tvalZ α R.toSigned = tval α R.terms := by
  unfold Row.toSigned
  induction R.terms with
  | nil => simp [tvalZ, tval]
  | cons x ts ih => obtain ⟨a, l⟩ := x; simp [tvalZ, tval, ih]

theorem toSigned_nonzero (R : Row) (hR : Canonical R) : ∀ t ∈ R.toSigned, t.2 ≠ 0 := by
  intro t ht
  unfold Row.toSigned at ht
  rw [List.mem_map] at ht
  obtain ⟨⟨a, l⟩, hmem, rfl⟩ := ht
  exact (hR.1 (a, l) hmem).2

def negTerms (ts : List (Nat × Int)) : List (Int × Int) := ts.map fun t => ((t.1 : Int), -t.2)
def mulTerms (k : Nat) (ts : List (Nat × Int)) : List (Int × Int) := ts.map fun t => (((t.1 * k : Nat) : Int), t.2)
def ceilTerms (d : Nat) (ts : List (Nat × Int)) : List (Int × Int) := ts.map fun t => (ceilDiv' t.1 d, t.2)
  where ceilDiv' (x : Int) (d : Nat) : Int := -((-x) / (d : Int))
def capTerms (b : Int) (ts : List (Nat × Int)) : List (Int × Int) := ts.map fun t => (min (t.1 : Int) b, t.2)

theorem mem_negTerms_nonzero (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) : ∀ t ∈ negTerms ts, t.2 ≠ 0 := by
  intro t ht; unfold negTerms at ht; rw [List.mem_map] at ht
  obtain ⟨u, hu, rfl⟩ := ht; have := hz u hu; simp; exact this
theorem mem_mulTerms_nonzero (k : Nat) (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) : ∀ t ∈ mulTerms k ts, t.2 ≠ 0 := by
  intro t ht; unfold mulTerms at ht; rw [List.mem_map] at ht
  obtain ⟨u, hu, rfl⟩ := ht; exact hz u hu
theorem mem_ceilTerms_nonzero (d : Nat) (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) : ∀ t ∈ ceilTerms d ts, t.2 ≠ 0 := by
  intro t ht; unfold ceilTerms at ht; rw [List.mem_map] at ht
  obtain ⟨u, hu, rfl⟩ := ht; exact hz u hu
theorem mem_capTerms_nonzero (b : Int) (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) : ∀ t ∈ capTerms b ts, t.2 ≠ 0 := by
  intro t ht; unfold capTerms at ht; rw [List.mem_map] at ht
  obtain ⟨u, hu, rfl⟩ := ht; exact hz u hu

/-- `algebra.negate`: Σ aᵢ·ℓ̄ᵢ ≥ A − b + 1 -/
def negate (R : Row) : Row := normalize (negTerms R.terms) ((R.total : Int) - R.bound + 1)
/-- `algebra.add` -/
def add (R S : Row) : Row := normalize (R.toSigned ++ S.toSigned) (R.bound + S.bound)
/-- `algebra.multiply` (positive multiplier) -/
def multiply (R : Row) (k : Nat) : Row := normalize (mulTerms k R.terms) (R.bound * k)
/-- Python `-((-value) // divisor)` -/
abbrev ceilDiv := ceilTerms.ceilDiv'
/-- `algebra.divide` (positive divisor): upward rounding of every coefficient and the bound -/
def divide (R : Row) (d : Nat) : Row := normalize (ceilTerms d R.terms) (ceilDiv R.bound d)
/-- `saturation`: for b > 0 cap every coefficient at b; for b ≤ 0 keep the degree, drop the terms -/
def saturate (R : Row) : Row :=
  if 0 < R.bound then normalize (capTerms R.bound R.terms) R.bound else ⟨[], R.bound⟩
/-- the terms of variable v / the other terms -/
def keepVar (v : Nat) : List (Nat × Int) → List (Nat × Int)
  | [] => []
  | t :: ts => if t.2.natAbs = v then t :: keepVar v ts else keepVar v ts
def dropVar (v : Nat) : List (Nat × Int) → List (Nat × Int)
  | [] => []
  | t :: ts => if t.2.natAbs = v then dropVar v ts else t :: dropVar v ts
def liftTerms (ts : List (Nat × Int)) : List (Int × Int) := ts.map fun t => ((t.1 : Int), t.2)

theorem mem_dropVar (v : Nat) (ts : List (Nat × Int)) : ∀ t ∈ dropVar v ts, t ∈ ts := by
  induction ts with
  | nil => simp [dropVar]
  | cons x ts ih =>
    intro t ht
    simp only [dropVar] at ht
    split at ht
    · exact List.mem_cons_of_mem _ (ih t ht)
    · rcases List.mem_cons.mp ht with rfl | ht
      · exact List.mem_cons_self ..
      · exact List.mem_cons_of_mem _ (ih t ht)

/-- substitution of a constant for a variable: the variable's terms are removed and their
    value under the constant is subtracted from the bound -/
def substConst (R : Row) (v : Nat) (bit : Bool) : Row :=
  normalize (liftTerms (dropVar v R.terms)) (R.bound - tval (fun _ => bit) (keepVar v R.terms))

/-- exact negation law: the value of the negation is −1 − the value -/
theorem tvalZ_negTerms (α : Val) (ts : List (Nat × Int)) (hz : ∀ t ∈ ts, t.2 ≠ 0) :
    tvalZ α (negTerms ts) = (totalL ts : Int) - tval α ts := by
  induction ts with
  | nil => simp [negTerms, tvalZ, tval, totalL]
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x
    have hl : l ≠ 0 := hz (a, l) (List.mem_cons_self ..)
    simp only [negTerms, List.map_cons, tvalZ, tval, totalL] at ih ⊢
    rw [litVal_neg α l hl, ih (fun t ht => hz t (List.mem_cons_of_mem _ ht))]
    push_cast; rw [Int.mul_sub, Int.mul_one]; omega

theorem val_negate (R : Row) (hR : Canonical R) (α : Val) : (negate R).val α = -1 - R.val α := by
  unfold negate
  rw [val_normalize _ _ _ (mem_negTerms_nonzero _ (fun t ht => (hR.1 t ht).2))]
  unfold Row.val Row.total
  rw [tvalZ_negTerms α R.terms (fun t ht => (hR.1 t ht).2)]
  omega

theorem sat_negate_iff (R : Row) (hR : Canonical R) (α : Val) : (negate R).sat α ↔ ¬ R.sat α := by
  unfold Row.sat; rw [val_negate R hR α]; omega

/-- POL addition is sound -/
theorem val_add (R S : Row) (hR : Canonical R) (hS : Canonical S) (α : Val) :
    (add R S).val α = R.val α + S.val α := by
  unfold add
  rw [val_normalize, tvalZ_append, tvalZ_toSigned, tvalZ_toSigned]
  · unfold Row.val; omega
  · intro t ht; rw [List.mem_append] at ht
    rcases ht with ht | ht
    · exact toSigned_nonzero R hR t ht
    · exact toSigned_nonzero S hS t ht

theorem sat_add (R S : Row) (hR : Canonical R) (hS : Canonical S) (α : Val)
    (h1 : R.sat α) (h2 : S.sat α) : (add R S).sat α := by
  unfold Row.sat at *; rw [val_add R S hR hS]; omega

theorem tvalZ_mulTerms (α : Val) (k : Nat) (ts : List (Nat × Int)) :
    tvalZ α (mulTerms k ts) = (k : Int) * tval α ts := by
  induction ts with
  | nil => simp [mulTerms, tvalZ, tval]
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x
    simp only [mulTerms, List.map_cons, tvalZ, tval] at ih ⊢
    rw [ih]; push_cast
    rw [Int.mul_add, Int.mul_left_comm, Int.mul_assoc]

/-- POL multiplication is sound -/
theorem val_multiply (R : Row) (hR : Canonical R) (k : Nat) (α : Val) :
    (multiply R k).val α = (k : Int) * R.val α := by
  unfold multiply
  rw [val_normalize _ _ _ (mem_mulTerms_nonzero _ _ (fun t ht => (hR.1 t ht).2))]
  unfold Row.val
  rw [tvalZ_mulTerms, Int.mul_sub, Int.mul_comm R.bound (k : Int)]

theorem sat_multiply (R : Row) (hR : Canonical R) (k : Nat) (α : Val) (h : R.sat α) :
    (multiply R k).sat α := by
  unfold Row.sat at *; rw [val_multiply R hR k α]
  exact Int.mul_nonneg (Int.ofNat_nonneg k) h

/-- d·⌈x/d⌉ ≥ x -/
theorem ceilDiv_mul_ge (x : Int) (d : Nat) (hd : 0 < d) : x ≤ (d : Int) * ceilDiv x d := by
  unfold ceilDiv ceilTerms.ceilDiv'
  have := Int.ediv_mul_le (-x) (b := (d : Int)) (by omega)
  rw [Int.mul_neg, Int.mul_comm]; omega

/-- ⌈x/d⌉ ≤ s whenever x ≤ d·s -/
theorem ceilDiv_le_of_le (x : Int) (d : Nat) (hd : 0 < d) (s : Int) (h : x ≤ (d : Int) * s) :
    ceilDiv x d ≤ s := by
  unfold ceilDiv ceilTerms.ceilDiv'
  have hd' : (0 : Int) < d := by omega
  have : -s ≤ (-x) / (d : Int) := by
    rw [Int.le_ediv_iff_mul_le hd', Int.neg_mul]
    rw [Int.mul_comm] at h; omega
  omega

theorem tval_le_mul_tvalZ_ceilTerms (α : Val) (d : Nat) (hd : 0 < d) (ts : List (Nat × Int)) :
    tval α ts ≤ (d : Int) * tvalZ α (ceilTerms d ts) := by
  induction ts with
  | nil => simp [ceilTerms, tval, tvalZ]
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x
    simp only [ceilTerms, List.map_cons, tval, tvalZ] at ih ⊢
    rw [Int.mul_add]
    have h1 := ceilDiv_mul_ge (a : Int) d hd
    have hL := litVal_nonneg α l
    have : (a : Int) * litVal α l ≤ (d : Int) * (ceilTerms.ceilDiv' (a : Int) d * litVal α l) := by
      rw [← Int.mul_assoc]
      exact Int.mul_le_mul_of_nonneg_right h1 hL
    omega

/-- POL division is sound -/
theorem sat_divide (R : Row) (hR : Canonical R) (d : Nat) (hd : 0 < d) (α : Val) (h : R.sat α) :
    (divide R d).sat α := by
  unfold divide Row.sat
  rw [val_normalize _ _ _ (mem_ceilTerms_nonzero _ _ (fun t ht => (hR.1 t ht).2))]
  have hk := tval_le_mul_tvalZ_ceilTerms α d hd R.terms
  unfold Row.sat Row.val at h
  have : R.bound ≤ (d : Int) * tvalZ α (ceilTerms d R.terms) := by omega
  have := ceilDiv_le_of_le R.bound d hd _ this
  omega

theorem tvalZ_capTerms_nonneg (α : Val) (b : Int) (hb : 0 < b) (ts : List (Nat × Int)) :
    0 ≤ tvalZ α (capTerms b ts) := by
  induction ts with
  | nil => simp [capTerms, tvalZ]
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x
    simp only [capTerms, List.map_cons, tvalZ] at ih ⊢
    have hL := litVal_nonneg α l
    have hm : 0 ≤ min (a : Int) b := by rw [Int.min_def]; split <;> omega
    have := Int.mul_nonneg hm hL
    omega

/-- Σ min(aᵢ,b)·ℓᵢ ≥ min(Σ aᵢ ℓᵢ, b) for b > 0 -/
theorem satsum_ge_min (α : Val) (b : Int) (hb : 0 < b) (ts : List (Nat × Int)) :
    min (tval α ts) b ≤ tvalZ α (capTerms b ts) := by
  induction ts with
  | nil => simp [capTerms, tval, tvalZ]; omega
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x
    simp only [capTerms, List.map_cons, tval, tvalZ] at ih ⊢
    have h0 := litVal_nonneg α l; have h1 := litVal_le_one α l
    have hT := tval_nonneg α ts
    have hS := tvalZ_capTerms_nonneg α b hb ts
    have hL : litVal α l = 0 ∨ litVal α l = 1 := by omega
    rcases hL with hL | hL
    · rw [hL]; simp; exact ih
    · rw [hL]; simp
      rw [Int.min_def] at ih ⊢; rw [Int.min_def]
      split at ih <;> split <;> split <;> omega

/-- POL saturation is sound -/
theorem sat_saturate (R : Row) (hR : Canonical R) (α : Val) (h : R.sat α) : (saturate R).sat α := by
  unfold saturate
  split
  · rename_i hb
    unfold Row.sat
    rw [val_normalize _ _ _ (mem_capTerms_nonzero _ _ (fun t ht => (hR.1 t ht).2))]
    have := satsum_ge_min α R.bound hb R.terms
    unfold Row.sat Row.val at h
    rw [Int.min_def] at this; split at this <;> omega
  · unfold Row.sat Row.val; simp [tval]; omega

/-- a literal axiom ℓ ≥ 0 (degree zero) is sound -/
theorem sat_literal_axiom (l : Int) (α : Val) : (Row.mk [(1, l)] 0).sat α := by
  unfold Row.sat Row.val; simp [tval]; exact litVal_nonneg α l

theorem tval_split_var (α : Val) (v : Nat) (bit : Bool) (ts : List (Nat × Int)) :
    tvalZ α (liftTerms (dropVar v ts)) + tval (fun _ => bit) (keepVar v ts) = tval (setVar α v bit) ts := by
  induction ts with
  | nil => simp [liftTerms, dropVar, keepVar, tvalZ, tval]
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x
    by_cases hv : l.natAbs = v
    · simp only [dropVar, keepVar, hv, ↓reduceIte, tval]
      have : litVal (setVar α v bit) l = litVal (fun _ => bit) l := by
        unfold litVal setVar; rw [hv]; simp
      rw [this]; omega
    · simp only [dropVar, keepVar, hv, ↓reduceIte, liftTerms, List.map_cons, tvalZ, tval] at ih ⊢
      have : litVal (setVar α v bit) l = litVal α l := by
        unfold litVal setVar; rw [if_neg hv]
      rw [this]; omega

/-- substitution of a constant: value under α of R|_{v:=bit} is the value of R under α[v:=bit] -/
theorem val_substConst (R : Row) (hR : Canonical R) (v : Nat) (bit : Bool) (α : Val) :
    (substConst R v bit).val α = R.val (setVar α v bit) := by
  unfold substConst
  rw [val_normalize]
  · unfold Row.val
    have := tval_split_var α v bit R.terms
    omega
  · intro t ht; unfold liftTerms at ht; rw [List.mem_map] at ht
    obtain ⟨u, hu, rfl⟩ := ht
    exact (hR.1 u (mem_dropVar v R.terms u hu)).2

/-! ## Constant rows -/

/-- in a strictly sorted list each variable occurs once -/
theorem var_unique (ts : List (Nat × Int)) (h : ts.Pairwise (fun s t => s.2.natAbs < t.2.natAbs)) :
    ∀ s ∈ ts, ∀ t ∈ ts, s.2.natAbs = t.2.natAbs → s = t := by
  induction ts with
  | nil => simp
  | cons x ts ih =>
    rw [List.pairwise_cons] at h
    intro s hs t ht heq
    rcases List.mem_cons.mp hs with hs1 | hs2
    · rcases List.mem_cons.mp ht with ht1 | ht2
      · rw [hs1, ht1]
      · exfalso; have := h.1 t ht2; rw [hs1] at heq; omega
    · rcases List.mem_cons.mp ht with ht1 | ht2
      · exfalso; have := h.1 s hs2; rw [ht1] at heq; omega
      · exact ih h.2 s hs2 t ht2 heq

def hasPos (v : Nat) : List (Nat × Int) → Bool
  | [] => false
  | t :: ts => (t.2 == (v : Int)) || hasPos v ts

theorem hasPos_iff (v : Nat) (ts : List (Nat × Int)) : hasPos v ts = true ↔ ∃ a, (a, (v : Int)) ∈ ts := by
  induction ts with
  | nil => simp [hasPos]
  | cons x ts ih =>
    obtain ⟨a, l⟩ := x
    simp only [hasPos, Bool.or_eq_true, beq_iff_eq, ih, List.mem_cons, Prod.mk.injEq]
    constructor
    · rintro (h | ⟨a', h⟩)
      · exact ⟨a, Or.inl ⟨rfl, h.symm⟩⟩
      · exact ⟨a', Or.inr h⟩
    · rintro ⟨a', h | h⟩
      · exact Or.inl h.2.symm
      · exact Or.inr ⟨a', h⟩

/-- the assignment that makes every literal of a canonical row true -/
def allTrue (R : Row) : Val := fun v => hasPos v R.terms

theorem litVal_allTrue (R : Row) (hR : Canonical R) : ∀ t ∈ R.terms, litVal (allTrue R) t.2 = 1 := by
  intro t ht
  obtain ⟨a, l⟩ := t
  have hl := (hR.1 (a, l) ht).2
  unfold litVal allTrue b2i
  by_cases hp : 0 < l
  · rw [if_pos hp]
    have : hasPos l.natAbs R.terms = true :=
      (hasPos_iff _ _).mpr ⟨a, by rwa [Int.natAbs_of_nonneg (by omega)]⟩
    simp [this]
  · rw [if_neg hp]
    have : hasPos l.natAbs R.terms = false := by
      apply Bool.eq_false_iff.mpr
      intro hpos
      obtain ⟨a', hmem⟩ := (hasPos_iff _ _).mp hpos
      have := var_unique R.terms hR.2 (a', (l.natAbs : Int)) hmem (a, l) ht (by simp)
      simp only [Prod.mk.injEq] at this
      omega
    simp [this]

theorem tval_allTrue (R : Row) (hR : Canonical R) : tval (allTrue R) R.terms = R.total := by
  unfold Row.total
  have hone := litVal_allTrue R hR
  suffices h : ∀ ts : List (Nat × Int), (∀ t ∈ ts, litVal (allTrue R) t.2 = 1) →
      tval (allTrue R) ts = totalL ts from h R.terms hone
  intro ts hone
  induction ts with
  | nil => rfl
  | cons t ts ih =>
    obtain ⟨a, l⟩ := t
    simp only [tval, totalL]
    rw [hone (a, l) (List.mem_cons_self ..), ih (fun t ht => hone t (List.mem_cons_of_mem _ ht))]
    simp

/-- **a canonical row is contradictory (bound > total) iff it holds under no assignment** -/
theorem canonical_contra_iff (R : Row) (hR : Canonical R) :
    ((R.total : Int) < R.bound) ↔ ∀ α, ¬ R.sat α := by
  constructor
  · intro h α hs
    unfold Row.sat Row.val at hs
    have := tval_le_totalL α R.terms
    unfold Row.total at h; omega
  · intro h
    have := h (allTrue R)
    unfold Row.sat Row.val at this
    rw [tval_allTrue R hR] at this
    omega

/-- a row is syntactically contradictory: bound > total -/
def Contra (R : Row) : Prop := (R.total : Int) < R.bound

/-- the contradictory row `0 ≥ 1` -/
def contra : Row := ⟨[], 1⟩

theorem contra_canonical : Canonical contra := by
  unfold Canonical contra; simp

theorem canonical_eq_contra_of_val (R : Row) (hR : Canonical R) (h : ∀ α, R.val α = -1) : R = contra :=
  canonical_ext R contra hR contra_canonical (fun α => by rw [h α]; simp [contra, Row.val, tval])

end EREF

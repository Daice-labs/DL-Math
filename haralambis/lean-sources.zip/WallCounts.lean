import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic.Ring
import Lean.Elab.Tactic.Omega
namespace Haralambis.Counts
open Finset

def count (X : ℤ → ℤ) (t : ℤ) (n : ℕ) := ∑ i ∈ range n, X (t+i)
def wall (X : ℤ → ℤ) (t : ℤ) (d : ℕ) := 1-X t-X (t+d)

theorem physical_wall (X : ℤ → ℤ) (t : ℤ) (d : ℕ)
    (h0 : X t = 0 ∨ X t = 1) (h1 : X (t+d) = 0 ∨ X (t+d) = 1)
    (ha : ¬ (X t = 1 ∧ X (t+d) = 1)) :
    (wall X t d = 0 ∨ wall X t d = 1) ∧
    (wall X t d = 1 ↔ X t = 0 ∧ X (t+d) = 0) := by
  unfold wall
  omega

theorem count_split (X : ℤ → ℤ) (t : ℤ) (m n : ℕ) :
    count X t (m+n) = count X t m + count X (t+m) n := by
  unfold count
  rw [sum_range_add]
  congr 1
  apply sum_congr rfl
  intro i hi
  congr 1
  omega

theorem pair_wall_count (X : ℤ → ℤ) (t : ℤ) (x y : ℕ) :
    (∑ i ∈ range y, wall X (t+i) x) + (∑ i ∈ range x, wall X (t+i) y) =
      (x+y:ℕ) - 2*count X t (x+y) := by
  have hxy := count_split X t x y
  have hyx := count_split X t y x
  rw [Nat.add_comm y x] at hyx
  have h1 : (∑ i ∈ range y, X (t+i+x)) = count X (t+x) y := by
    apply sum_congr rfl
    intro i hi
    congr 1
    omega
  have h2 : (∑ i ∈ range x, X (t+i+y)) = count X (t+y) x := by
    apply sum_congr rfl
    intro i hi
    congr 1
    omega
  simp only [wall, sum_sub_distrib, sum_const, card_range, nsmul_eq_mul, mul_one]
  rw [h1,h2]
  change (y:ℤ)-count X t y-count X (t+x) y +
    ((x:ℤ)-count X t x-count X (t+y) x) = _
  push_cast
  omega

/-- Both directions of the signed wall bound, using one physical sign map. -/
theorem signed_pair_bounds (X : ℤ → ℤ) (s : ℤ → ℕ → ℤ) (t : ℤ) (x y : ℕ)
    (hx : ∀ i < y, -wall X (t+i) x ≤ s (t+i) x ∧ s (t+i) x ≤ wall X (t+i) x)
    (hy : ∀ i < x, -wall X (t+i) y ≤ s (t+i) y ∧ s (t+i) y ≤ wall X (t+i) y) :
    let w := (∑ i ∈ range y, s (t+i) x) - ∑ i ∈ range x, s (t+i) y;
    let e := ((x+y:ℕ):ℤ) - 2*count X t (x+y);
    -e ≤ w ∧ w ≤ e := by
  have xa := sum_le_sum (s := range y) (fun i hi => (hx i (mem_range.mp hi)).1)
  have xb := sum_le_sum (s := range y) (fun i hi => (hx i (mem_range.mp hi)).2)
  have ya := sum_le_sum (s := range x) (fun i hi => (hy i (mem_range.mp hi)).1)
  have yb := sum_le_sum (s := range x) (fun i hi => (hy i (mem_range.mp hi)).2)
  simp only [sum_neg_distrib] at xa ya
  have he := pair_wall_count X t x y
  dsimp
  omega

theorem sum_mod_two (f g : ℕ → ℤ) (n : ℕ)
    (h : ∀ i < n, f i % 2 = g i % 2) :
    (∑ i ∈ range n, f i) % 2 = (∑ i ∈ range n, g i) % 2 := by
  induction n with
  | zero => simp
  | succ n ih =>
    simp only [sum_range_succ]
    have hi := ih (fun i hi => h i (by omega))
    have hn := h n (by omega)
    omega

theorem signed_pair_parity (X : ℤ → ℤ) (s : ℤ → ℕ → ℤ) (t : ℤ) (x y : ℕ)
    (hx : ∀ i < y, s (t+i) x % 2 = wall X (t+i) x % 2)
    (hy : ∀ i < x, s (t+i) y % 2 = wall X (t+i) y % 2) :
    ((∑ i ∈ range y, s (t+i) x) - ∑ i ∈ range x, s (t+i) y) % 2 =
      ((x+y:ℕ):ℤ) % 2 := by
  have h1 := sum_mod_two (fun i => s (t+i) x) (fun i => wall X (t+i) x) y hx
  have h2 := sum_mod_two (fun i => s (t+i) y) (fun i => wall X (t+i) y) x hy
  have he := pair_wall_count X t x y
  dsimp at h1 h2
  omega

#print axioms physical_wall
#print axioms pair_wall_count
end Haralambis.Counts

#print axioms Haralambis.Counts.signed_pair_bounds

#print axioms Haralambis.Counts.signed_pair_parity

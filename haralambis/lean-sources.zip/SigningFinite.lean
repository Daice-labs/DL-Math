import Mathlib
set_option maxHeartbeats 2000000
namespace Haralambis.Signing
open Finset
attribute [local instance] Classical.propDecidable

/-- Hall counting with multiplicities retained in the finite incidence type. -/
theorem two_regular_matching {O L R : Type} [Fintype O] [Fintype L] [Fintype R]
    (p : O → L) (q : O → R)
    (hp : ∀ l, (univ.filter fun o => p o = l).card = 2)
    (hq : ∀ r, (univ.filter fun o => q o = r).card = 2) :
    ∃ f : L → R, Function.Bijective f ∧ ∀ l, ∃ o, p o = l ∧ q o = f l := by
  classical
  have count (T : Type) [Fintype T] (r : O → T)
      (hr : ∀ t, (univ.filter fun o => r o = t).card = 2) :
      Fintype.card O = Fintype.card T * 2 := by
    have h := card_eq_sum_card_fiberwise (s := (univ : Finset O)) (t := (univ : Finset T))
      (f := r) (by intro o ho; exact mem_univ _)
    simpa [hr] using h
  have hc : Fintype.card L = Fintype.card R := by
    have h1 := count L p hp
    have h2 := count R q hq
    omega
  have hall : ∀ A : Finset L, A.card ≤ (univ.filter fun r => ∃ l ∈ A, ∃ o, p o = l ∧ q o = r).card := by
    intro A
    let U : Finset O := univ.filter fun o => p o ∈ A
    let B : Finset R := univ.filter fun r => ∃ l ∈ A, ∃ o, p o = l ∧ q o = r
    have hu : U.card = A.card * 2 := by
      have h := card_eq_sum_card_fiberwise (s := U) (t := A) (f := p)
        (by intro o ho; exact (mem_filter.mp ho).2)
      have hf (l : L) (hl : l ∈ A) : U.filter (fun o => p o = l) = univ.filter (fun o => p o = l) := by
        ext o
        simp only [U, mem_filter, mem_univ, true_and]
        constructor
        · exact fun h => h.2
        · intro he; exact ⟨he ▸ hl, he⟩
      rw [h]
      calc
        ∑ l ∈ A, (U.filter fun o => p o = l).card = ∑ l ∈ A, 2 := by
          apply sum_congr rfl
          intro l hl
          rw [hf l hl, hp]
        _ = A.card * 2 := by simp
    have hub : U.card ≤ B.card * 2 := by
      have h := card_eq_sum_card_fiberwise (s := U) (t := B) (f := q) (by
        intro o ho
        change q o ∈ B
        change q o ∈ univ.filter _
        simp only [mem_filter, mem_univ, true_and]
        exact ⟨p o, (mem_filter.mp ho).2, o, rfl, rfl⟩)
      rw [h]
      calc
        ∑ r ∈ B, (U.filter fun o => q o = r).card ≤ ∑ r ∈ B, 2 := by
          apply sum_le_sum
          intro r hr
          rw [← hq r]
          apply card_le_card
          intro o ho
          exact mem_filter.mpr ⟨mem_univ _, (mem_filter.mp ho).2⟩
        _ = B.card * 2 := by simp
    change A.card ≤ B.card
    omega
  obtain ⟨f, hf, hmem⟩ :=
    (Fintype.all_card_le_filter_rel_iff_exists_injective
      (fun l r => ∃ o, p o = l ∧ q o = r)).mp hall
  exact ⟨f, (Fintype.bijective_iff_injective_and_card f).mpr ⟨hf, hc⟩, hmem⟩

/-- The two-element orbit partition of a fixed-point-free involution. -/
def pairSetoid {O : Type} (P : O → O) (hP : Function.Involutive P) : Setoid O where
  r x y := x = y ∨ P x = y
  iseqv := {
    refl := fun _ => Or.inl rfl
    symm := by
      intro x y h
      rcases h with h | h
      · exact Or.inl h.symm
      · right; rw [← h, hP]
    trans := by
      intro x y z h k
      rcases h with h | h <;> rcases k with k | k
      · exact Or.inl (h.trans k)
      · exact Or.inr (h ▸ k)
      · exact Or.inr (h.trans k)
      · left; rw [← k, ← h, hP]
  }

abbrev PairClass {O : Type} (P : O → O) (hP : Function.Involutive P) := Quotient (pairSetoid P hP)

theorem pair_fiber_two {O : Type} [Fintype O] (P : O → O)
    (hP : Function.Involutive P) (hnP : ∀ o, P o ≠ o)
    (l : PairClass P hP) :
    (univ.filter fun o => (Quotient.mk (pairSetoid P hP) o) = l).card = 2 := by
  classical
  induction l using Quotient.inductionOn with
  | h x =>
    have he : (univ.filter fun o => Quotient.mk (pairSetoid P hP) o = Quotient.mk _ x) = {x, P x} := by
      ext o
      simp only [mem_filter, mem_univ, true_and, Quotient.eq, pairSetoid, mem_insert, mem_singleton]
      constructor
      · rintro (h | h)
        · exact Or.inl h
        · right; rw [← h, hP]
      · rintro (h | h)
        · exact Or.inl h
        · right; rw [h, hP]
    rw [he, card_pair (Ne.symm (hnP x))]

/-- Two finite pair partitions admit one common transversal. This proof uses
Hall, retaining occurrences even when their two orbit classes coincide. -/
theorem two_involutions_coloring {O : Type} [Fintype O]
    (P Q : O → O) (hP : Function.Involutive P) (hQ : Function.Involutive Q)
    (hnP : ∀ o, P o ≠ o) (hnQ : ∀ o, Q o ≠ o) :
    ∃ color : O → Bool, (∀ o, color (P o) = !color o) ∧
      (∀ o, color (Q o) = !color o) := by
  classical
  let p : O → PairClass P hP := Quotient.mk _
  let q : O → PairClass Q hQ := Quotient.mk _
  letI : Fintype (PairClass P hP) := Fintype.ofFinite _
  letI : Fintype (PairClass Q hQ) := Fintype.ofFinite _
  obtain ⟨f, hf, hmem⟩ := two_regular_matching p q
    (by intro l; simpa only [p] using pair_fiber_two P hP hnP l)
    (by intro r; simpa only [q] using pair_fiber_two Q hQ hnQ r)
  choose g hgp hgq using hmem
  let color : O → Bool := fun o => decide (g (p o) = o)
  have pp (o : O) : p (P o) = p o := Quotient.sound (Or.inr (hP o))
  have qq (o : O) : q (Q o) = q o := Quotient.sound (Or.inr (hQ o))
  have pairP (o : O) : g (p o) = o ∨ g (p o) = P o := by
    have h := Quotient.exact (hgp (p o))
    rcases h with h | h
    · exact Or.inl h
    · right
      exact (hP (g (p o))).symm.trans (congrArg P h)
  have oneP (o : O) : color (P o) = !color o := by
    rcases pairP o with h | h
    · simp [color, pp, h, Ne.symm (hnP o)]
    · simp [color, pp, h, hnP o]
  have selected_unique (o u : O) (ho : color o = true) (hu : color u = true)
      (he : q o = q u) : o = u := by
    have ho' : g (p o) = o := of_decide_eq_true ho
    have hu' : g (p u) = u := of_decide_eq_true hu
    have hg : f (p o) = f (p u) := by rw [← hgq, ← hgq, ho', hu', he]
    rw [← ho', ← hu', hf.1 hg]
  have selected_exists (o : O) : ∃ u, q u = q o ∧ color u = true := by
    obtain ⟨l, hl⟩ := hf.2 (q o)
    refine ⟨g l, (hgq l).trans hl, ?_⟩
    simp [color, hgp]
  refine ⟨color, oneP, ?_⟩
  intro o
  have ex := selected_exists o
  have alt : color o = true ∨ color (Q o) = true := by
    rcases ex with ⟨u, he, hu⟩
    have h := Quotient.exact he
    rcases h with h | h
    · exact Or.inl (h ▸ hu)
    · right
      have huq : u = Q o := by rw [← h, hQ]
      exact huq ▸ hu
  have notboth : ¬(color o = true ∧ color (Q o) = true) := by
    rintro ⟨ho, hqo⟩
    exact hnQ o (selected_unique (Q o) o hqo ho (qq o))
  cases hc : color o <;> cases hqc : color (Q o) <;> simp_all
end Haralambis.Signing

import DensityAssembly
namespace Haralambis.Composition
open OP01.Fixed411 Finset

theorem count_shift_period (x : ℤ → ℕ) (p : ℕ)
    (hp : ∀ z : ℤ, x (z+p)=x z) (w : ℤ) (N : ℕ) :
    intervalCount x (w+p) N = intervalCount x w N := by
  unfold intervalCount
  apply sum_congr rfl
  intro i hi
  have he : w+(p:ℤ)+i = (w+i)+p := by omega
  rw [he,hp]

theorem count_period_blocks (x : ℤ → ℕ) (p : ℕ)
    (hp : ∀ z : ℤ, x (z+p)=x z) (k : ℕ) :
    intervalCount x 0 (p*k) = k*intervalCount x 0 p := by
  induction k with
  | zero => simp [intervalCount]
  | succ k ih =>
    rw [Nat.mul_succ, Nat.add_comm (p*k) p, count_add]
    rw [count_shift_period x p hp 0 (p*k), ih]
    ring

theorem periodic_density (x : ℤ → ℕ) (hx : bitValid x) (p : ℕ) (hp : 0<p)
    (hper : ∀ z : ℤ, x (z+p)=x z) :
    upperDensity x = (intervalCount x 0 p : ℝ)/p := by
  let C := intervalCount x 0 p
  have hpR : (0:ℝ)<p := by exact_mod_cast hp
  have bounds (n : ℕ) :
      (C:ℝ)*n - (p:ℝ)*C ≤ (p:ℝ)*intervalCount x 0 n ∧
      (p:ℝ)*intervalCount x 0 n ≤ (C:ℝ)*n + (p:ℝ)*C := by
    let q := n/p
    have hlo : p*q ≤ n := by dsimp [q]; have := Nat.div_mul_le_self n p; nlinarith
    have hhi : n ≤ p*(q+1) := by
      have he := Nat.mod_add_div n p
      have hr := Nat.mod_lt n hp
      dsimp [q]
      nlinarith
    have hcl := count_mono x 0 hlo
    have hcu := count_mono x 0 hhi
    rw [count_period_blocks x p hper] at hcl hcu
    have hlR : (p:ℝ)*q ≤ n := by exact_mod_cast hlo
    have huR : (n:ℝ) ≤ (p:ℝ)*(q+1) := by exact_mod_cast hhi
    have hclR : (q:ℝ)*C ≤ intervalCount x 0 n := by exact_mod_cast hcl
    have hcuR : (intervalCount x 0 n:ℝ) ≤ (q+1:ℕ)*C := by exact_mod_cast hcu
    push_cast at hcuR
    have hC : (0:ℝ)≤C := Nat.cast_nonneg C
    constructor <;> nlinarith
  apply le_antisymm
  · exact OP01.AllEll.density_upper x hx p C ((p:ℝ)*C) hpR (fun n => (bounds n).2)
  · exact OP01.AllEll.density_lower x hx p C ((p:ℝ)*C) hpR (fun n => (bounds n).1)
#print axioms periodic_density
end Haralambis.Composition

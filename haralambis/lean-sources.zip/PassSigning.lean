import PhysicalFaces

/-! Local physical pass pairing. This file does not prove global wall signing.
The four Boolean values are the occupancy of the actual quadrilateral corners
in cyclic order: z, z+x, z+x+y, z+y. The four sides follow the same order as
PhysicalFaces.edge. -/
namespace Haralambis.Physical

/-- No side has two occupied endpoints. Extra forbidden diagonals can only
strengthen this hypothesis. -/
def faceAvoiding (v : Fin 4 → Bool) : Prop :=
  ¬(v 0 = true ∧ v 1 = true) ∧ ¬(v 1 = true ∧ v 2 = true) ∧
  ¬(v 2 = true ∧ v 3 = true) ∧ ¬(v 3 = true ∧ v 0 = true)

def faceWall (v : Fin 4 → Bool) (s : Fin 4) : Bool :=
  if s = 0 then !v 0 && !v 1 else if s = 1 then !v 1 && !v 2
  else if s = 2 then !v 2 && !v 3 else !v 3 && !v 0

/-- At zero occupants pair at opposite corners. At one occupant this pairs
the two sides not incident to it. With opposite occupants there are no walls. -/
def passMate (v : Fin 4 → Bool) (s : Fin 4) : Fin 4 :=
  if v 1 || v 3 then
    if s = 0 then 1 else if s = 1 then 0 else if s = 2 then 3 else 2
  else
    if s = 0 then 3 else if s = 1 then 2 else if s = 2 then 1 else 0

theorem passMate_involutive (v : Fin 4 → Bool) : Function.Involutive (passMate v) := by
  intro s
  fin_cases s <;> cases h : (v 1 || v 3) <;> simp [passMate, h]

theorem passMate_ne (v : Fin 4 → Bool) (s : Fin 4) : passMate v s ≠ s := by
  fin_cases s <;> cases h : (v 1 || v 3) <;> simp [passMate, h]

set_option maxHeartbeats 1000000 in
/-- Pairing is on actual walls, uniformly for every avoiding occupancy. -/
theorem passMate_preserves_walls (v : Fin 4 → Bool) (hv : faceAvoiding v)
    (s : Fin 4) (hs : faceWall v s = true) : faceWall v (passMate v s) = true := by
  cases h0 : v 0 <;> cases h1 : v 1 <;> cases h2 : v 2 <;> cases h3 : v 3 <;>
    fin_cases s <;> simp_all [faceAvoiding, faceWall, passMate]

/-- Thus no pass pairs a physical side with itself, and each wall belongs to
exactly one two-element pass (the orbit of the fixed-point-free involution). -/
theorem wall_pair (v : Fin 4 → Bool) (hv : faceAvoiding v) (s : Fin 4)
    (hs : faceWall v s = true) :
    faceWall v (passMate v s) = true ∧ passMate v s ≠ s ∧ passMate v (passMate v s) = s :=
  ⟨passMate_preserves_walls v hv s hs, passMate_ne v s, passMate_involutive v s⟩

/-- If each pass cancels and nonwalls are zero, the four contributions sum to
zero. This is a local summation theorem, not an existence assumption hidden as
a signing conclusion. -/
theorem paired_sum_zero (v : Fin 4 → Bool) (x : Fin 4 → ℤ)
    (hn : ∀ s, faceWall v s = false → x s = 0)
    (hp : ∀ s, faceWall v s = true → x s + x (passMate v s) = 0) :
    x 0 + x 1 + x 2 + x 3 = 0 := by
  have hc (s : Fin 4) : x s + x (passMate v s) = 0 := by
    cases hs : faceWall v s
    · have hms : passMate v (passMate v s) = s := passMate_involutive v s
      cases hm : faceWall v (passMate v s)
      · rw [hn s hs, hn _ hm]; omega
      · have h := hp (passMate v s) hm
        rw [hms] at h
        omega
    · exact hp s hs
  have h0 := hc 0
  have h1 := hc 1
  have h2 := hc 2
  have h3 := hc 3
  cases h : (v 1 || v 3) <;> simp [passMate, h] at h0 h1 h2 h3 <;> omega

/-- The actual quadrilateral corners, in the occupancy order used above. -/
def corner (a b c t : ℤ) (f : Face) (i : Fin 4) : ℤ :=
  let z := t + f.2
  let x := distance a b c (axes f.1).1
  let y := distance a b c (axes f.1).2
  if i = 0 then z else if i = 1 then z+x else if i = 2 then z+x+y else z+y

def occupancy (S : ℤ → Bool) (a b c t : ℤ) (f : Face) : Fin 4 → Bool :=
  fun i => S (corner a b c t f i)

def physicalWall (S : ℤ → Bool) (a b c : ℤ) (e : Edge) : Bool :=
  !S e.1 && !S (e.1 + distance a b c e.2)

/-- The local Boolean wall test is exactly the test on physical edge endpoints. -/
theorem faceWall_physical (S : ℤ → Bool) (a b c t : ℤ) (f : Face) (s : Fin 4) :
    faceWall (occupancy S a b c t f) s = physicalWall S a b c (edge a b c t (f,s)) := by
  rcases f with ⟨f,k⟩
  fin_cases f <;> fin_cases s <;>
    simp [faceWall, occupancy, physicalWall, corner, edge, axes, distance,
      add_assoc, add_comm, add_left_comm, Bool.and_comm]

/-- Global avoidance implies the exact four local side restrictions. -/
theorem avoiding_occupancy (S : ℤ → Bool) (a b c t : ℤ) (f : Face)
    (hS : ∀ z i, ¬(S z = true ∧ S (z + distance a b c i) = true)) :
    faceAvoiding (occupancy S a b c t f) := by
  let z := t + f.2
  let x := distance a b c (axes f.1).1
  let y := distance a b c (axes f.1).2
  have h0 := hS z (axes f.1).1
  have h1 := hS (z+x) (axes f.1).2
  have h2 := hS (z+y) (axes f.1).1
  have h3 := hS z (axes f.1).2
  change ¬(S z = true ∧ S (z+x) = true) ∧
    ¬(S (z+x) = true ∧ S (z+x+y) = true) ∧
    ¬(S (z+x+y) = true ∧ S (z+y) = true) ∧
    ¬(S (z+y) = true ∧ S z = true)
  refine ⟨h0, h1, ?_, ?_⟩
  · intro h
    apply h2
    refine ⟨h.2, ?_⟩
    have he : z + y + x = z + x + y := by ring
    change S (z+y+x) = true
    rw [he]
    exact h.1
  · intro h
    exact h3 ⟨h.2, h.1⟩

end Haralambis.Physical

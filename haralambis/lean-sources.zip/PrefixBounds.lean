import LocalClass
import Definitions
import LatticeMinimum

/-! The exact same-signing-to-prefix implication. The physical constructor is
not a premise of any arithmetic lemma here and must be instantiated separately. -/
namespace Haralambis.ArbitraryTriples
noncomputable section

theorem signed_pair_count_bound (X : ℤ → ℤ) (s : ℤ → ℕ → ℤ)
    (t : ℤ) (x y : ℕ) (h : Local.ValidSigns X s t x y) :
    |(Identities.W s t x y : ℝ)| ≤ (x+y : ℕ) - 2*(Counts.count X t (x+y) : ℝ) := by
  have hb := Counts.signed_pair_bounds X s t x y h.1 h.2.1
  change -(((x+y:ℕ):ℤ)-2*Counts.count X t (x+y)) ≤ Identities.W s t x y ∧
    Identities.W s t x y ≤ ((x+y:ℕ):ℤ)-2*Counts.count X t (x+y) at hb
  have hl : -(((x+y:ℕ):ℝ)-2*(Counts.count X t (x+y):ℝ)) ≤
      (Identities.W s t x y : ℝ) := by exact_mod_cast hb.1
  have hu : (Identities.W s t x y : ℝ) ≤
      ((x+y:ℕ):ℝ)-2*(Counts.count X t (x+y):ℝ) := by exact_mod_cast hb.2
  exact abs_le.mpr ⟨hl,hu⟩

theorem good_pair_of_ratio (X : ℤ → ℤ) (s : ℤ → ℕ → ℤ)
    (t : ℤ) (x y : ℕ) (hL : 0 < x+y) (δ : ℝ)
    (h : Local.ValidSigns X s t x y)
    (hr : δ ≤ |(Identities.W s t x y : ℝ)| / ((x:ℝ)+y)) :
    (Counts.count X t (x+y) : ℝ) ≤ ((1-δ)/2) * (x+y : ℕ) := by
  have hpos : (0:ℝ)<(x+y:ℕ) := by exact_mod_cast hL
  rw [← Nat.cast_add] at hr
  have hm := (le_div_iff₀ hpos).mp hr
  have hb := signed_pair_count_bound X s t x y h
  nlinarith

theorem three_prefix_of_same_signing
    (a b c : ℕ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (X : ℤ → ℤ) (s : ℤ → ℕ → ℤ) (t : ℤ)
    (vab : Local.ValidSigns X s t a b) (vac : Local.ValidSigns X s t a c)
    (vbc : Local.ValidSigns X s t b c)
    (habcurl : ∀ k : ℕ, k+1<c → Identities.curl s (t+k) a b = 0)
    (haccurl : ∀ k : ℕ, k+1<b → Identities.curl s (t+k) a c = 0)
    (hbccurl : ∀ k : ℕ, k+1<a → Identities.curl s (t+k) b c = 0) :
    ∃ L : ℕ, (L=a+b ∨ L=a+c ∨ L=b+c) ∧
      (Counts.count X t L : ℝ) ≤ kappaStar a b c * L := by
  have hclass := Local.class_of_same_signing X s t a b c vab vac vbc habcurl haccurl hbccurl
  have hd := deltaStar_le_classSize a b c
    (Identities.W s t a b, Identities.W s t a c, Identities.W s t b c) hclass
  simp only [classSize] at hd
  rcases le_max_iff.mp hd with hd | hd
  · exact ⟨a+b,Or.inl rfl,good_pair_of_ratio X s t a b (by omega) _ vab hd⟩
  · rcases le_max_iff.mp hd with hd | hd
    · exact ⟨a+c,Or.inr (Or.inl rfl),good_pair_of_ratio X s t a c (by omega) _ vac hd⟩
    · exact ⟨b+c,Or.inr (Or.inr rfl),good_pair_of_ratio X s t b c (by omega) _ vbc hd⟩

#print axioms signed_pair_count_bound
#print axioms three_prefix_of_same_signing
end
end Haralambis.ArbitraryTriples

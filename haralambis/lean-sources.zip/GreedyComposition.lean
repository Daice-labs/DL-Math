import Definitions

namespace Haralambis.Composition
open Finset OP01.Fixed411

/-- Physical counts split at an arbitrary integer start. -/
theorem count_add (x : ℤ → ℕ) (w : ℤ) (m n : ℕ) :
    intervalCount x w (m+n) = intervalCount x w m + intervalCount x (w+m) n := by
  unfold intervalCount
  rw [sum_range_add]
  congr 1
  apply sum_congr rfl
  intro i hi
  congr 1
  omega

theorem count_mono (x : ℤ → ℕ) (w : ℤ) {m n : ℕ} (h : m ≤ n) :
    intervalCount x w m ≤ intervalCount x w n := by
  unfold intervalCount
  exact sum_le_sum_of_subset (range_mono h)

/-- One endpoint loss, not one loss per chosen prefix. This is a generic
composition lemma; the good-prefix premise is discharged later by signing. -/
theorem greedy_interval (x : ℤ → ℕ) (ρ : ℝ) (hρ : 0 ≤ ρ)
    (B : ℕ) (hB : 0 < B)
    (good : ∀ w : ℤ, ∃ l : ℕ, 0 < l ∧ l ≤ B ∧ (intervalCount x w l : ℝ) ≤ ρ*l)
    (N : ℕ) (w : ℤ) :
    (intervalCount x w N : ℝ) ≤ ρ*N + ρ*(B-1 : ℕ) := by
  induction N using Nat.strong_induction_on generalizing w with
  | h N ih =>
    by_cases hN : N = 0
    · subst N
      simp only [intervalCount, range_zero, sum_empty, Nat.cast_zero, mul_zero, zero_add]
      positivity
    obtain ⟨l, hl, hlB, hg⟩ := good w
    by_cases hn : N ≤ l
    · have hc : (intervalCount x w N : ℝ) ≤ intervalCount x w l := by exact_mod_cast count_mono x w hn
      have hbound : (l:ℝ) ≤ N + (B-1:ℕ) := by exact_mod_cast (show l ≤ N + (B-1) by omega)
      nlinarith
    · have hs : N-l < N := by omega
      have hi := ih (N-l) hs (w+l)
      have he : l+(N-l)=N := by omega
      have hc := count_add x w l (N-l)
      rw [he] at hc
      have hcr : (intervalCount x w N : ℝ) = intervalCount x w l + intervalCount x (w+l) (N-l) := by exact_mod_cast hc
      have hlen : (N:ℝ) = l + (N-l:ℕ) := by exact_mod_cast he.symm
      nlinarith

#print axioms greedy_interval
end Haralambis.Composition

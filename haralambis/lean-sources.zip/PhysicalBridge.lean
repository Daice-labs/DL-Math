import PassSigning
import LocalClass
import Definitions

/-! Reconciliation of the physical edge model with the canonical set occupancy,
length-indexed wall signs, and the three curl ranges. This module alone does not
construct the physical edge signing. -/
namespace Haralambis.ArbitraryTriples
noncomputable section
open Physical

def setBits (S : Set ℤ) : ℤ → Bool := by
  classical
  exact fun z => decide (z ∈ S)

def setOccupancy (S : Set ℤ) : ℤ → ℤ :=
  fun z => (Capacity.membership S z : ℤ)

theorem setBits_avoiding (a b c : ℕ) (S : Set ℤ) (hS : Avoids a b c S) :
    ∀ z i, ¬(setBits S z = true ∧
      setBits S (z + distance a b c i) = true) := by
  intro z i
  fin_cases i <;> simp only [distance, Fin.reduceFinMk, ↓reduceIte, setBits,
    decide_eq_true_eq] <;> intro h
  · exact (hS z h.1).1 h.2
  · exact (hS z h.1).2.1 h.2
  · exact (hS z h.1).2.2 h.2

def edgeSign (S : Set ℤ) (a b c : ℕ) (σ : Edge → ℤ) (e : Edge) : ℤ :=
  if physicalWall (setBits S) a b c e then σ e else 0

def lengthSign (a b : ℕ) (ε : Edge → ℤ) (z : ℤ) (d : ℕ) : ℤ :=
  if d = a then ε (z,0) else if d = b then ε (z,1) else ε (z,2)

@[simp] theorem lengthSign_a (a b : ℕ) (ε : Edge → ℤ) (z : ℤ) :
    lengthSign a b ε z a = ε (z,0) := by simp [lengthSign]
@[simp] theorem lengthSign_b (a b : ℕ) (hab : a < b) (ε : Edge → ℤ) (z : ℤ) :
    lengthSign a b ε z b = ε (z,1) := by simp [lengthSign, Nat.ne_of_gt hab]
@[simp] theorem lengthSign_c (a b c : ℕ) (hab : a < b) (hbc : b < c)
    (ε : Edge → ℤ) (z : ℤ) :
    lengthSign a b ε z c = ε (z,2) := by
  simp [lengthSign, Nat.ne_of_gt (hab.trans hbc), Nat.ne_of_gt hbc]

theorem edgeSign_spec (a b c : ℕ) (S : Set ℤ) (hS : Avoids a b c S)
    (σ : Edge → ℤ) (hσ : ∀ e, σ e = 1 ∨ σ e = -1) (z : ℤ) (i : Fin 3) :
    let d := (distance a b c i).toNat;
    -Counts.wall (setOccupancy S) z d ≤ edgeSign S a b c σ (z,i) ∧
    edgeSign S a b c σ (z,i) ≤ Counts.wall (setOccupancy S) z d ∧
    edgeSign S a b c σ (z,i) % 2 = Counts.wall (setOccupancy S) z d % 2 := by
  classical
  have havoid := setBits_avoiding a b c S hS z i
  simp only [setBits, decide_eq_true_eq] at havoid
  have hd : ((distance a b c i).toNat : ℤ) = distance a b c i := by
    fin_cases i <;> simp [distance]
  have hu := hσ (z,i)
  dsimp only
  by_cases hz : z ∈ S <;> by_cases he : z + distance a b c i ∈ S <;>
    rcases hu with hu | hu <;>
    simp_all [edgeSign, physicalWall, setBits, setOccupancy,
      Capacity.membership, Counts.wall]

def faceSum (a b c : ℕ) (t : ℤ) (ε : Edge → ℤ) (f : Face) : ℤ :=
  coeff (f,0) * ε (edge a b c t (f,0)) +
  coeff (f,1) * ε (edge a b c t (f,1)) +
  coeff (f,2) * ε (edge a b c t (f,2)) +
  coeff (f,3) * ε (edge a b c t (f,3))

theorem faceSum_ab (a b c : ℕ) (hab : a < b) (hbc : b < c)
    (t k : ℤ) (ε : Edge → ℤ) :
    faceSum a b c t ε (0,k) = Identities.curl (lengthSign a b ε) (t+k) a b := by
  simp [faceSum, coeff, edge, axes, distance, Identities.curl,
    lengthSign, Nat.ne_of_gt hab]
  ring

theorem faceSum_ac (a b c : ℕ) (hab : a < b) (hbc : b < c)
    (t k : ℤ) (ε : Edge → ℤ) :
    faceSum a b c t ε (1,k) = -Identities.curl (lengthSign a b ε) (t+k) a c := by
  simp [faceSum, coeff, edge, axes, distance, Identities.curl,
    lengthSign, Nat.ne_of_gt hab, Nat.ne_of_gt hbc, Nat.ne_of_gt (hab.trans hbc)]
  ring

theorem faceSum_bc (a b c : ℕ) (hab : a < b) (hbc : b < c)
    (t k : ℤ) (ε : Edge → ℤ) :
    faceSum a b c t ε (2,k) = Identities.curl (lengthSign a b ε) (t+k) b c := by
  simp [faceSum, coeff, edge, axes, distance, Identities.curl,
    lengthSign, Nat.ne_of_gt hab, Nat.ne_of_gt hbc, Nat.ne_of_gt (hab.trans hbc)]
  ring

theorem lengthSign_spec (a b c : ℕ) (hab : a < b) (hbc : b < c)
    (S : Set ℤ) (hS : Avoids a b c S) (σ : Edge → ℤ)
    (hσ : ∀ e, σ e = 1 ∨ σ e = -1) (z : ℤ) (d : ℕ)
    (hd : d=a ∨ d=b ∨ d=c) :
    -Counts.wall (setOccupancy S) z d ≤ lengthSign a b (edgeSign S a b c σ) z d ∧
    lengthSign a b (edgeSign S a b c σ) z d ≤ Counts.wall (setOccupancy S) z d ∧
    lengthSign a b (edgeSign S a b c σ) z d % 2 = Counts.wall (setOccupancy S) z d % 2 := by
  rcases hd with hd | hd | hd <;> subst d
  · simpa [distance] using edgeSign_spec a b c S hS σ hσ z 0
  · simpa [distance, lengthSign_b a b hab] using edgeSign_spec a b c S hS σ hσ z 1
  · simpa [distance, lengthSign_c a b c hab hbc] using edgeSign_spec a b c S hS σ hσ z 2

theorem validSigns_of_edgeSign (a b c : ℕ) (hab : a < b) (hbc : b < c)
    (S : Set ℤ) (hS : Avoids a b c S) (σ : Edge → ℤ)
    (hσ : ∀ e, σ e = 1 ∨ σ e = -1) (t : ℤ) (x y : ℕ)
    (hx : x=a ∨ x=b ∨ x=c) (hy : y=a ∨ y=b ∨ y=c) :
    Local.ValidSigns (setOccupancy S) (lengthSign a b (edgeSign S a b c σ)) t x y := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro i hi
    have h := lengthSign_spec a b c hab hbc S hS σ hσ (t+i) x hx
    exact ⟨h.1,h.2.1⟩
  · intro i hi
    have h := lengthSign_spec a b c hab hbc S hS σ hσ (t+i) y hy
    exact ⟨h.1,h.2.1⟩
  · intro i hi
    exact (lengthSign_spec a b c hab hbc S hS σ hσ (t+i) x hx).2.2
  · intro i hi
    exact (lengthSign_spec a b c hab hbc S hS σ hσ (t+i) y hy).2.2

theorem curls_of_faceSum (a b c : ℕ) (hab : a < b) (hbc : b < c)
    (t : ℤ) (ε : Edge → ℤ)
    (hf : ∀ f, valid a b c f → faceSum a b c t ε f = 0) :
    (∀ k : ℕ, k+1<c → Identities.curl (lengthSign a b ε) (t+k) a b = 0) ∧
    (∀ k : ℕ, k+1<b → Identities.curl (lengthSign a b ε) (t+k) a c = 0) ∧
    (∀ k : ℕ, k+1<a → Identities.curl (lengthSign a b ε) (t+k) b c = 0) := by
  refine ⟨?_, ?_, ?_⟩
  · intro k hk
    have h := hf (0,k) (by simp only [valid, Fin.reduceFinMk, ↓reduceIte]; omega)
    rw [faceSum_ab a b c hab hbc] at h
    exact h
  · intro k hk
    have h := hf (1,k) (by simp only [valid, Fin.reduceFinMk, ↓reduceIte]; omega)
    rw [faceSum_ac a b c hab hbc] at h
    omega
  · intro k hk
    have h := hf (2,k) (by simp only [valid, Fin.reduceFinMk, ↓reduceIte]; omega)
    rw [faceSum_bc a b c hab hbc] at h
    exact h

#print axioms edgeSign_spec
#print axioms curls_of_faceSum
end
end Haralambis.ArbitraryTriples

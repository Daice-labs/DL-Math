import SharpArithmetic

namespace Haralambis.ArbitraryTriples
noncomputable section
open OP01.Fixed411.RealWrapper

theorem distance_neg (t : ℝ) :
    OP01.Fixed411.distanceToInteger (-t) = OP01.Fixed411.distanceToInteger t := by
  have hle (t : ℝ) : OP01.Fixed411.distanceToInteger (-t) ≤
      OP01.Fixed411.distanceToInteger t := by
    apply le_csInf (distance_nonempty t)
    rintro r ⟨m,rfl⟩
    have hh := distance_le_abs (-t) (-m)
    simpa only [Int.cast_neg, neg_sub_neg, abs_sub_comm] using hh
  exact le_antisymm (hle t) (by simpa using hle (-t))

theorem profile_neg (a b c : ℕ) (t : ℝ) : profile a b c (-t) = profile a b c t := by
  simp only [profile,mul_neg,distance_neg]

theorem nonnegative_rational_phase (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    ∃ q : ℚ, 0 ≤ q ∧ profile a b c (q:ℝ) = kappa a b c := by
  obtain ⟨q,hq⟩ := rational_phase_attainment a b c ha hb hc
  by_cases h : 0 ≤ q
  · exact ⟨q,h,hq⟩
  · refine ⟨-q,by linarith,?_⟩
    simpa only [Rat.cast_neg,profile_neg] using hq

theorem distance_eq_min_fract (t : ℝ) : OP01.Fixed411.distanceToInteger t =
    min (Int.fract t) (1-Int.fract t) := by
  rw [distance_eq_half_sub]
  unfold Int.fract
  by_cases h : t - (Int.floor t : ℝ) ≤ 1/2
  · rw [abs_of_nonpos (by linarith),min_eq_left (by linarith)]
    ring
  · rw [abs_of_nonneg (by linarith),min_eq_right (by linarith)]
    ring

def circularNumerator (d n p : ℕ) : ℕ := min (d*n%p) (p-d*n%p)

def rotationNumerator (a b c n p : ℕ) : ℕ :=
  min (circularNumerator a n p) (min (circularNumerator b n p) (circularNumerator c n p))

theorem distance_nat_ratio (d n p : ℕ) (hp : 0<p) :
    OP01.Fixed411.distanceToInteger ((d:ℝ)*((n:ℝ)/p)) =
      (circularNumerator d n p : ℝ)/p := by
  have hpR : (0:ℝ)<p := by exact_mod_cast hp
  have hmod := Nat.mod_lt (d*n) hp
  have hrepr : (d:ℝ)*((n:ℝ)/p) - ((d*n%p:ℕ):ℝ)/p = ((d*n/p:ℕ):ℝ) := by
    apply (mul_right_cancel₀ (ne_of_gt hpR))
    rw [sub_mul,div_mul_cancel₀ _ (ne_of_gt hpR)]
    have he : (d:ℝ)*((n:ℝ)/p)*p = (d*n:ℕ) := by push_cast; field_simp
    rw [he]
    have hh := Nat.mod_add_div (d*n) p
    have hh' : ((d*n%p:ℕ):ℝ)+(p:ℝ)*((d*n/p:ℕ):ℝ) = (d*n:ℕ) := by exact_mod_cast hh
    nlinarith
  have hfract : Int.fract ((d:ℝ)*((n:ℝ)/p)) = ((d*n%p:ℕ):ℝ)/p := by
    apply Int.fract_eq_iff.mpr
    refine ⟨by positivity, (div_lt_one hpR).mpr (by exact_mod_cast hmod), ?_⟩
    exact ⟨(d*n/p:ℕ), by simpa using hrepr⟩
  rw [distance_eq_min_fract,hfract]
  have hsub : 1 - ((d*n%p:ℕ):ℝ)/p = ((p-d*n%p:ℕ):ℝ)/p := by
    rw [Nat.cast_sub hmod.le]
    field_simp
  rw [hsub]
  unfold circularNumerator
  by_cases h : d*n%p ≤ p-d*n%p
  · rw [min_eq_left h,min_eq_left ((div_le_div_iff_of_pos_right hpR).mpr (by exact_mod_cast h))]
  · have h' := le_of_lt (lt_of_not_ge h)
    rw [min_eq_right h',min_eq_right ((div_le_div_iff_of_pos_right hpR).mpr (by exact_mod_cast h'))]

theorem profile_nat_ratio (a b c n p : ℕ) (hp : 0<p) :
    profile a b c ((n:ℝ)/p) = (rotationNumerator a b c n p : ℝ)/p := by
  have hpR : (0:ℝ)<p := by exact_mod_cast hp
  unfold profile rotationNumerator
  rw [distance_nat_ratio a n p hp,distance_nat_ratio b n p hp,distance_nat_ratio c n p hp]
  have hm (x y : ℕ) : min ((x:ℝ)/p) ((y:ℝ)/p) = (min x y : ℕ)/p := by
    by_cases h : x ≤ y
    · rw [min_eq_left h,min_eq_left ((div_le_div_iff_of_pos_right hpR).mpr (by exact_mod_cast h))]
    · have h' := le_of_lt (lt_of_not_ge h)
      rw [min_eq_right h',min_eq_right ((div_le_div_iff_of_pos_right hpR).mpr (by exact_mod_cast h'))]
  rw [hm,hm]

/-- A rational maximizing phase gives an exact integral density numerator. -/
theorem integral_rotation_parameters (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    ∃ n p k : ℕ, 0<p ∧ Nat.Coprime n p ∧ k≤p ∧
      profile a b c ((n:ℝ)/p) = kappa a b c ∧
      (k:ℝ)/p = kappa a b c := by
  obtain ⟨q,hq,hmax⟩ := nonnegative_rational_phase a b c ha hb hc
  have hn : 0 ≤ q.num := by exact (Rat.num_nonneg.mpr hq)
  have hnum : (q.num.natAbs : ℤ) = q.num := by rw [Int.natCast_natAbs,abs_of_nonneg hn]
  have heq : (q.num.natAbs : ℝ)/(q.den:ℝ) = (q:ℝ) := by
    have hn' : (q.num.natAbs:ℝ) = (q.num:ℝ) := by
      simpa only [Int.cast_natCast] using congrArg (fun z : ℤ => (z:ℝ)) hnum
    rw [hn']
    exact_mod_cast q.num_div_den
  let k := rotationNumerator a b c q.num.natAbs q.den
  refine ⟨q.num.natAbs,q.den,k,q.den_pos,q.reduced,?_,?_,?_⟩
  · exact le_trans (min_le_left _ _) (le_trans (min_le_left _ _) (Nat.le_of_lt (Nat.mod_lt _ q.den_pos)))
  · rw [heq]; exact hmax
  · rw [← profile_nat_ratio a b c _ _ q.den_pos,heq]
    exact hmax

/-- Two residues in an arc shorter than a forbidden circular step cannot coexist. -/
theorem modular_pair_avoids (d n p k : ℕ) (hp : 0<p)
    (hstep : (k:ℝ)/p ≤ OP01.Fixed411.distanceToInteger ((d:ℝ)*((n:ℝ)/p)))
    (z : ℤ) (hz : (z*(n:ℤ))%(p:ℤ) < (k:ℤ)) :
    ¬ ((z+(d:ℤ))*(n:ℤ))%(p:ℤ) < (k:ℤ) := by
  intro hz'
  have hpI : (0:ℤ)<p := by exact_mod_cast hp
  have hpR : (0:ℝ)<p := by exact_mod_cast hp
  let r₀ := (z*(n:ℤ))%(p:ℤ)
  let r₁ := ((z+(d:ℤ))*(n:ℤ))%(p:ℤ)
  let q₀ := (z*(n:ℤ))/(p:ℤ)
  let q₁ := ((z+(d:ℤ))*(n:ℤ))/(p:ℤ)
  have hr₀ : 0 ≤ r₀ := Int.emod_nonneg _ (ne_of_gt hpI)
  have hr₁ : 0 ≤ r₁ := Int.emod_nonneg _ (ne_of_gt hpI)
  have hr : -(k:ℤ) < r₁-r₀ ∧ r₁-r₀ < (k:ℤ) := by
    dsimp [r₀,r₁] at *
    omega
  have hrR : |((r₁-r₀:ℤ):ℝ)| < (k:ℝ) := by
    rw [abs_lt]
    exact_mod_cast hr
  have heI : (d:ℤ)*n = (p:ℤ)*(q₁-q₀)+(r₁-r₀) := by
    have h₀ := Int.ediv_add_emod (z*(n:ℤ)) (p:ℤ)
    have h₁ := Int.ediv_add_emod ((z+(d:ℤ))*(n:ℤ)) (p:ℤ)
    change (p:ℤ)*q₀+r₀=z*n at h₀
    change (p:ℤ)*q₁+r₁=(z+d)*n at h₁
    linear_combination h₀-h₁
  have heR : (d:ℝ)*n = (p:ℝ)*((q₁-q₀:ℤ):ℝ)+((r₁-r₀:ℤ):ℝ) := by
    exact_mod_cast heI
  have heq : (d:ℝ)*((n:ℝ)/p)-((q₁-q₀:ℤ):ℝ) = ((r₁-r₀:ℤ):ℝ)/p := by
    apply (eq_div_iff (ne_of_gt hpR)).mpr
    field_simp
    nlinarith [heR]
  have hdist := distance_le_abs ((d:ℝ)*((n:ℝ)/p)) (q₁-q₀)
  rw [heq,abs_div,abs_of_pos hpR] at hdist
  have hlt := (div_lt_div_iff_of_pos_right hpR).mpr hrR
  linarith

end
end Haralambis.ArbitraryTriples
#print axioms Haralambis.ArbitraryTriples.integral_rotation_parameters
#print axioms Haralambis.ArbitraryTriples.modular_pair_avoids

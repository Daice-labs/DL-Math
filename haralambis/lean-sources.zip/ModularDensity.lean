import PeriodicDensity
namespace Haralambis.ArbitraryTriples
open OP01.Fixed411 Finset

/-- The first k residues of the coprime rational rotation n/p. -/
def rotationWord (n p k : ℕ) (z : ℤ) : ℕ :=
  if (z*(n:ℤ)) % (p:ℤ) < (k:ℤ) then 1 else 0

theorem rotationWord_bits (n p k : ℕ) : bitValid (rotationWord n p k) := by
  intro z
  unfold rotationWord
  split <;> norm_num

theorem rotationWord_period (n p k : ℕ) (z : ℤ) :
    rotationWord n p k (z+p) = rotationWord n p k z := by
  simp [rotationWord, add_mul, Int.add_emod]

theorem rotationWord_nat (n p k i : ℕ) :
    rotationWord n p k (i:ℤ) = if i*n%p < k then 1 else 0 := by
  simp only [rotationWord, ← Nat.cast_mul, ← Int.natCast_emod, Nat.cast_lt]

/-- Coprime multiplication permutes the residues, so precisely k positions of
a full period are occupied, including the endpoint cases k=0 and k=p. -/
theorem rotationWord_count (n p k : ℕ) (hp : 0<p) (hk : k≤p)
    (hcop : Nat.Coprime n p) : intervalCount (rotationWord n p k) 0 p = k := by
  let m : Fin p → Fin p := fun i => ⟨i.val*n%p, Nat.mod_lt _ hp⟩
  have hinj : Function.Injective m := by
    intro i j he
    have hmod : i.val*n ≡ j.val*n [MOD p] := congrArg Fin.val he
    have hij := Nat.ModEq.cancel_right_of_coprime hcop.symm hmod
    exact Fin.ext (hij.eq_of_lt_of_lt i.isLt j.isLt)
  let e : Fin p ≃ Fin p := Equiv.ofBijective m
    ((Fintype.bijective_iff_injective_and_card m).mpr ⟨hinj,rfl⟩)
  have hsum : (∑ i : Fin p, if i.val*n%p < k then (1:ℕ) else 0) =
      ∑ i : Fin p, if i.val < k then (1:ℕ) else 0 :=
    e.sum_comp (fun i => if i.val < k then (1:ℕ) else 0)
  have hfilter : (range p).filter (fun i => i<k) = range k := by
    ext i
    simp only [mem_filter, mem_range]
    omega
  calc
    intervalCount (rotationWord n p k) 0 p =
        ∑ i ∈ range p, if i*n%p < k then (1:ℕ) else 0 := by
      simp only [intervalCount, zero_add, rotationWord_nat]
    _ = ∑ i : Fin p, if i.val*n%p < k then (1:ℕ) else 0 :=
      (Fin.sum_univ_eq_sum_range (fun i => if i*n%p < k then (1:ℕ) else 0) p).symm
    _ = ∑ i : Fin p, if i.val < k then (1:ℕ) else 0 := hsum
    _ = ∑ i ∈ range p, if i < k then (1:ℕ) else 0 :=
      Fin.sum_univ_eq_sum_range (fun i => if i<k then (1:ℕ) else 0) p
    _ = k := by rw [sum_boole, hfilter, card_range, Nat.cast_id]

/-- The actual programme upper density of the periodic modular word. -/
theorem rotationWord_density (n p k : ℕ) (hp : 0<p) (hk : k≤p)
    (hcop : Nat.Coprime n p) : upperDensity (rotationWord n p k) = (k:ℝ)/p := by
  rw [Haralambis.Composition.periodic_density (rotationWord n p k)
    (rotationWord_bits n p k) p hp (rotationWord_period n p k),
    rotationWord_count n p k hp hk hcop]

#print axioms rotationWord_density
end Haralambis.ArbitraryTriples

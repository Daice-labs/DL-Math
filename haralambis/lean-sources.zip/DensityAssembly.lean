import GreedyComposition

namespace Haralambis.ArbitraryTriples
noncomputable section
open OP01.Fixed411 Haralambis.Capacity

theorem membership_of_bits (x : ℤ → ℕ) (hx : bitValid x) :
    membership {z | x z = 1} = x := by
  funext z
  have hz := hx z
  by_cases h : x z = 1
  · simp [membership, h]
  · have h0 : x z = 0 := by omega
    simp [membership, h0]

/-- Converts a physical interval bound to the actual programme density. -/
theorem upperDensity_of_physical_bound (x : ℤ → ℕ) (hx : bitValid x) (ρ C : ℝ)
    (hb : ∀ n : ℕ, (physicalCount {z | x z = 1} 0 n : ℝ) ≤ ρ*n+C) :
    upperDensity x ≤ ρ := by
  have h := OP01.AllEll.density_upper x hx 1 ρ C (by norm_num)
  apply (by simpa using h)
  intro n
  simpa [physicalCount_eq, membership_of_bits x hx] using hb n

/-- Exact supremum assembly. These uniform bound/attainment premises are explicit
and must be discharged before the final arbitrary-triple theorem is claimed. -/
theorem mu_eq_of_bound_and_attainment (a b c : ℕ) (ρ C : ℝ)
    (upper : ∀ S : Set ℤ, Avoids a b c S → ∀ n : ℕ,
      (physicalCount S 0 n : ℝ) ≤ ρ*n+C)
    (lower : ∃ S : Set ℤ, Avoids a b c S ∧ originalUpperDensity S = ρ) :
    mu a b c = ρ := by
  have hb : ∀ x : ℤ → ℕ, avoids a b c x → upperDensity x ≤ ρ := by
    intro x hx
    apply upperDensity_of_physical_bound x hx.1 ρ C
    apply upper {z | x z = 1}
    apply (avoids_membership_iff a b c _).mp
    rw [membership_of_bits x hx.1]
    exact hx
  obtain ⟨S,hS,hρ⟩ := lower
  have hd : upperDensity (membership S) = ρ := by
    simpa [originalUpperDensity_eq] using hρ
  have hm : ρ ∈ {r : ℝ | ∃ x : ℤ → ℕ, avoids a b c x ∧ r = upperDensity x} :=
    ⟨membership S, (avoids_membership_iff a b c S).mpr hS, hd.symm⟩
  unfold mu
  apply le_antisymm
  · apply csSup_le ⟨ρ,hm⟩
    rintro r ⟨x,hx,rfl⟩
    exact hb x hx
  · apply le_csSup _ hm
    refine ⟨ρ,?_⟩
    rintro r ⟨x,hx,rfl⟩
    exact hb x hx

#print axioms membership_of_bits
#print axioms mu_eq_of_bound_and_attainment
end
end Haralambis.ArbitraryTriples

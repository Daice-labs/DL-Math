import SigningGlobal
import PassSigning
set_option maxHeartbeats 3000000
namespace Haralambis.Physical
open Finset
attribute [local instance] Classical.propDecidable

/-- Actual valid wall occurrences, not a quotient by physical edge: parallel
passes and both appearances of a shared edge remain separate incidences. -/
noncomputable def wallOccurrences (S : ℤ → Bool) (a b c t : ℤ) : Finset Occurrence :=
  (((univ : Finset (Fin 3)).product (Icc 0 c)).product (univ : Finset (Fin 4))).filter
    (fun o => valid a b c o.1 ∧ physicalWall S a b c (edge a b c t o) = true)

theorem mem_wallOccurrences (S : ℤ → Bool) (a b c t : ℤ) (hab : a < b) (hbc : b < c)
    (o : Occurrence) : o ∈ wallOccurrences S a b c t ↔
      valid a b c o.1 ∧ physicalWall S a b c (edge a b c t o) = true := by
  classical
  rcases o with ⟨⟨f,k⟩,s⟩
  simp only [wallOccurrences, mem_filter]
  constructor
  · exact fun h => h.2
  · intro h
    refine ⟨?_,h⟩
    apply Finset.mem_product.mpr
    refine ⟨Finset.mem_product.mpr ⟨mem_univ _, Finset.mem_Icc.mpr ?_⟩, mem_univ _⟩
    change 0 ≤ k ∧ k ≤ c
    have hv := h.1
    fin_cases f <;> simp only [valid] at hv <;> norm_num at hv <;> omega

/-- Unconditional global physical wall signing for every avoiding occupancy.
The finite doubled pass system is constructed from the actual face ranges and
side pairing, and all untouched physical walls receive sign +1. -/
theorem global_physical_signing (S : ℤ → Bool) (a b c t : ℤ)
    (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (hS : ∀ z i, ¬(S z = true ∧ S (z + distance a b c i) = true)) :
    ∃ σ : Edge → ℤ, (∀ e, σ e = 1 ∨ σ e = -1) ∧
      ∀ f, valid a b c f →
      let x := fun s : Fin 4 => if physicalWall S a b c (edge a b c t (f,s)) then
        coeff (f,s) * σ (edge a b c t (f,s)) else 0
      x 0 + x 1 + x 2 + x 3 = 0 := by
  classical
  let O := {o : Occurrence // o ∈ wallOccurrences S a b c t}
  have vo (o : O) : valid a b c o.val.1 ∧
      physicalWall S a b c (edge a b c t o.val) = true :=
    (mem_wallOccurrences S a b c t hab hbc o.val).mp o.property
  let P : O → O := fun o =>
    ⟨(o.val.1, passMate (occupancy S a b c t o.val.1) o.val.2), by
      apply (mem_wallOccurrences S a b c t hab hbc _).mpr
      refine ⟨(vo o).1, ?_⟩
      rw [← faceWall_physical]
      apply passMate_preserves_walls _ (avoiding_occupancy S a b c t o.val.1 hS)
      rw [faceWall_physical]
      exact (vo o).2⟩
  have hP : Function.Involutive P := by
    intro o
    apply Subtype.ext
    exact Prod.ext rfl (passMate_involutive (occupancy S a b c t o.val.1) o.val.2)
  have hnP (o : O) : P o ≠ o := by
    intro he
    have hs := congrArg (fun x : O => x.val.2) he
    exact passMate_ne (occupancy S a b c t o.val.1) o.val.2 hs
  obtain ⟨σ, hunit, hpass⟩ := Haralambis.Signing.finite_physical_signing P hP hnP
    (fun o => edge a b c t o.val) (fun o => coeff o.val)
    (fun o => coeff_unit o.val) (by
      intro o u he hc
      apply Subtype.ext
      exact same_sign_unique a b c t ha hab hbc o.val u.val (vo o).1 (vo u).1 he hc)
  refine ⟨σ,hunit,?_⟩
  intro f hf
  let v := occupancy S a b c t f
  let x : Fin 4 → ℤ := fun s => if faceWall v s then coeff (f,s) * σ (edge a b c t (f,s)) else 0
  have hsum : x 0 + x 1 + x 2 + x 3 = 0 := by
    apply paired_sum_zero v x
    · intro s hs
      simp [x, hs]
    · intro s hs
      have hm : faceWall v (passMate v s) = true :=
        passMate_preserves_walls v (avoiding_occupancy S a b c t f hS) s hs
      let o : O := ⟨(f,s), (mem_wallOccurrences S a b c t hab hbc _).mpr
        ⟨hf, by rw [← faceWall_physical]; exact hs⟩⟩
      have hp := hpass o
      change coeff (f,s) * σ (edge a b c t (f,s)) +
        coeff (f,passMate v s) * σ (edge a b c t (f,passMate v s)) = 0 at hp
      simpa only [x, hs, hm, Bool.true_eq, if_true] using hp
  simpa only [x, v, faceWall_physical] using hsum

#print axioms global_physical_signing
end Haralambis.Physical

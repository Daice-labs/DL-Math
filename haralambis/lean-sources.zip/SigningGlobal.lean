import SigningFinite
set_option maxHeartbeats 2000000
namespace Haralambis.Signing
attribute [local instance] Classical.propDecidable

/-- The contribution associated with a selected/unselected incidence. -/
def bitSign (b : Bool) : ℤ := if b then 1 else -1

theorem bitSign_unit (b : Bool) : bitSign b = 1 ∨ bitSign b = -1 := by cases b <;> simp [bitSign]
theorem bitSign_not (b : Bool) : bitSign (!b) = -bitSign b := by cases b <;> simp [bitSign]

/-- Complete each one-occurrence wall by exchanging the two copies. Interior
walls stay in their own copy. Hall coloring then descends to physical walls. -/
theorem finite_physical_signing {O E : Type} [Fintype O]
    (P : O → O) (hP : Function.Involutive P) (hnP : ∀ o, P o ≠ o)
    (edge : O → E) (coeff : O → ℤ)
    (hc : ∀ o, coeff o = 1 ∨ coeff o = -1)
    (hi : ∀ o u, edge o = edge u → coeff o = coeff u → o = u) :
    ∃ σ : E → ℤ, (∀ e, σ e = 1 ∨ σ e = -1) ∧
      ∀ o, coeff o * σ (edge o) + coeff (P o) * σ (edge (P o)) = 0 := by
  classical
  let rel (o u : O) : Prop := edge o = edge u ∧ coeff o = -coeff u
  have rsym {o u : O} (h : rel o u) : rel u o := ⟨h.1.symm, by omega⟩
  have rne {o u : O} (h : rel o u) : o ≠ u := by
    intro he
    have hunit := hc o
    have heq := h.2
    rw [← he] at heq
    omega
  have runique {o u v : O} (h : rel o u) (k : rel o v) : u = v :=
    hi u v (h.1.symm.trans k.1) (by have h1 := h.2; have h2 := k.2; omega)
  let has (o : O) := ∃ u, rel o u
  let mate (o : O) : O := if h : has o then Classical.choose h else o
  have mate_rel (o : O) (h : has o) : rel o (mate o) := by
    simpa only [mate, dif_pos h] using Classical.choose_spec h
  have mate_has (o : O) (h : has o) : has (mate o) := ⟨o, rsym (mate_rel o h)⟩
  have mate_inv (o : O) (h : has o) : mate (mate o) = o :=
    runique (mate_rel (mate o) (mate_has o h)) (rsym (mate_rel o h))
  let Q (x : O × Bool) : O × Bool := if has x.1 then (mate x.1, x.2) else (x.1, !x.2)
  have hQ : Function.Involutive Q := by
    rintro ⟨o,b⟩
    by_cases h : has o
    · simp [Q, h, mate_has o h, mate_inv o h]
    · simp [Q, h]
  have hnQ (x : O × Bool) : Q x ≠ x := by
    rcases x with ⟨o,b⟩
    by_cases h : has o
    · intro he
      have hm : mate o = o := by simpa [Q, h] using congrArg Prod.fst he
      exact rne (mate_rel o h) hm.symm
    · cases b <;> simp [Q, h]
  let P' (x : O × Bool) := (P x.1, x.2)
  have hP' : Function.Involutive P' := by rintro ⟨o,b⟩; simp [P', hP o]
  have hnP' (x : O × Bool) : P' x ≠ x := by
    intro he
    exact hnP x.1 (congrArg Prod.fst he)
  obtain ⟨color, cp, cq⟩ := two_involutions_coloring P' Q hP' hQ hnP' hnQ
  let contribution (o : O) : ℤ := bitSign (color (o,false))
  have opposite (o u : O) (h : rel o u) : contribution u = -contribution o := by
    have hh : has o := ⟨u,h⟩
    have hm : mate o = u := runique (mate_rel o hh) h
    have he : Q (o,false) = (u,false) := by simp [Q, hh, hm]
    have hh' := cq (o,false)
    rw [he] at hh'
    simp [contribution, hh', bitSign_not]
  have consistent (o u : O) (he : edge o = edge u) :
      coeff o * contribution o = coeff u * contribution u := by
    by_cases heq : coeff o = coeff u
    · rw [hi o u he heq]
    · have ho := hc o
      have hu := hc u
      have hopp : coeff o = -coeff u := by omega
      have hcon := opposite o u ⟨he,hopp⟩
      rw [hcon, hopp]
      ring
  let σ (e : E) : ℤ := if h : ∃ o, edge o = e then
    coeff (Classical.choose h) * contribution (Classical.choose h) else 1
  have sigma_at (o : O) : σ (edge o) = coeff o * contribution o := by
    have h : ∃ u, edge u = edge o := ⟨o,rfl⟩
    dsimp only [σ]
    rw [dif_pos h]
    exact consistent _ o (Classical.choose_spec h)
  refine ⟨σ, ?_, ?_⟩
  · intro e
    by_cases h : ∃ o, edge o = e
    · dsimp only [σ]
      rw [dif_pos h]
      rcases hc (Classical.choose h) with hu | hu <;>
        rcases bitSign_unit (color (Classical.choose h,false)) with hv | hv <;>
        simp [contribution, hu, hv]
    · simp [σ, h]
  · intro o
    have hunit : coeff o * coeff o = 1 := by rcases hc o with h | h <;> rw [h] <;> norm_num
    have hunit' : coeff (P o) * coeff (P o) = 1 := by rcases hc (P o) with h | h <;> rw [h] <;> norm_num
    have hpass : contribution (P o) = -contribution o := by
      have h := cp (o,false)
      change color (P o,false) = !color (o,false) at h
      simp [contribution, h, bitSign_not]
    rw [sigma_at, sigma_at, ← mul_assoc, ← mul_assoc, hunit, hunit', one_mul, one_mul, hpass]
    ring
end Haralambis.Signing

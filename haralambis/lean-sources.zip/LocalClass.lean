import WindowIdentities
import WallCounts
import LatticeImage

namespace Haralambis.Local
open Finset
/-- An intermediate interface, not signing existence: all physical obligations
must be supplied for the same map. -/
def ValidSigns (X : ℤ → ℤ) (s : ℤ → ℕ → ℤ) (t : ℤ) (x y : ℕ) : Prop :=
  (∀ i < y, -Counts.wall X (t+i) x ≤ s (t+i) x ∧ s (t+i) x ≤ Counts.wall X (t+i) x) ∧
  (∀ i < x, -Counts.wall X (t+i) y ≤ s (t+i) y ∧ s (t+i) y ≤ Counts.wall X (t+i) y) ∧
  (∀ i < y, s (t+i) x % 2 = Counts.wall X (t+i) x % 2) ∧
  (∀ i < x, s (t+i) y % 2 = Counts.wall X (t+i) y % 2)

theorem class_of_same_signing (X : ℤ → ℤ) (s : ℤ → ℕ → ℤ) (t : ℤ) (a b c : ℕ)
    (vab : ValidSigns X s t a b) (vac : ValidSigns X s t a c) (vbc : ValidSigns X s t b c)
    (hab : ∀ k : ℕ, k+1<c → Identities.curl s (t+k) a b = 0)
    (hac : ∀ k : ℕ, k+1<b → Identities.curl s (t+k) a c = 0)
    (hbc : ∀ k : ℕ, k+1<a → Identities.curl s (t+k) b c = 0) :
    Arithmetic.InParityLattice a b c (Identities.W s t a b)
      (Identities.W s t a c) (Identities.W s t b c) := by
  refine ⟨Identities.compatible_class s t a b c hab hac hbc, ?_, ?_, ?_⟩
  · simpa [Identities.W, Nat.cast_add] using Counts.signed_pair_parity X s t a b vab.2.2.1 vab.2.2.2
  · simpa [Identities.W, Nat.cast_add] using Counts.signed_pair_parity X s t a c vac.2.2.1 vac.2.2.2
  · simpa [Identities.W, Nat.cast_add] using Counts.signed_pair_parity X s t b c vbc.2.2.1 vbc.2.2.2

#print axioms class_of_same_signing
end Haralambis.Local

/- UNCOMPILED DRAFT SPECIFICATION. No theorem proof is supplied here.
   These Prop definitions name the obligations in FORMALIZATION_HANDOFF.txt.
   Pin a compatible Lean/mathlib project and audit these definitions first. -/
import Mathlib

namespace OP01.Fixed411
noncomputable section
open scoped BigOperators

def bitValid (x : ℤ → ℕ) : Prop := ∀ z, x z ≤ 1

def avoids (x : ℤ → ℕ) : Prop := bitValid x ∧
  ∀ z, x z + x (z + 1) ≤ 1 ∧ x z + x (z + 10) ≤ 1 ∧
    x z + x (z + 18) ≤ 1

def weight (j : Fin 30) : ℕ :=
  if j.val = 9 ∨ j.val = 20 then 3
  else if j.val = 10 ∨ j.val = 19 then 4 else 2

def windowValid (x : Fin 30 → ℕ) : Prop :=
  (∀ j, x j ≤ 1) ∧ ∀ i j, i.val < j.val →
    (j.val - i.val = 1 ∨ j.val - i.val = 10 ∨ j.val - i.val = 18) →
    x i + x j ≤ 1

def localLemmaGoal : Prop := ∀ x : Fin 30 → ℕ,
  windowValid x → (∑ j : Fin 30, weight j * x j) ≤ 24

def intervalCount (x : ℤ → ℕ) (a : ℤ) (n : ℕ) : ℕ :=
  ∑ j ∈ Finset.range n, x (a + (j : ℤ))

def intervalBoundGoal : Prop := ∀ (x : ℤ → ℕ), avoids x →
  ∀ (a : ℤ) (n : ℕ), 11 * intervalCount x a n ≤ 4 * n + 319

-- Infimum of eventual upper bounds with arbitrary positive slack.
-- Prove this equals the conventional bounded-sequence limsup before using it.
def upperDensity (x : ℤ → ℕ) : ℝ :=
  sInf {r : ℝ | ∀ ε : ℝ, 0 < ε → ∃ N : ℕ,
    ∀ n : ℕ, N ≤ n → 0 < n →
      (intervalCount x 0 n : ℝ) / (n : ℝ) ≤ r + ε}

def mu : ℝ := sSup {r : ℝ | ∃ x : ℤ → ℕ, avoids x ∧ r = upperDensity x}

def witness (z : ℤ) : ℕ :=
  if z % 11 = 0 ∨ z % 11 = 2 ∨ z % 11 = 5 ∨ z % 11 = 8 then 1 else 0

def lowerWitnessGoal : Prop := avoids witness ∧ upperDensity witness = (4 : ℝ) / 11

def distanceToInteger (t : ℝ) : ℝ :=
  sInf (Set.range (fun m : ℤ => |t - (m : ℝ)|))

def kappa : ℝ := sSup (Set.range (fun t : ℝ =>
  min (distanceToInteger t) (min (distanceToInteger (10*t)) (distanceToInteger (18*t)))))

def fixedResultGoal : Prop := mu = (4 : ℝ) / 11 ∧ kappa = (4 : ℝ) / 11

def cyclicValid (n : ℕ) (hn : 0 < n) (x : Fin n → ℕ) : Prop :=
  (∀ i, x i ≤ 1) ∧ ∀ i, ∀ d ∈ ([1,10,18] : List ℕ),
    x i + x ⟨(i.val + d) % n, Nat.mod_lt _ hn⟩ ≤ 1

-- Self-loop periods are included and force all entries to zero.
def cyclicBoundGoal : Prop := ∀ (n : ℕ) (hn : 0 < n) (x : Fin n → ℕ),
  cyclicValid n hn x → 11 * (∑ i : Fin n, x i) ≤ 4 * n

end
end OP01.Fixed411

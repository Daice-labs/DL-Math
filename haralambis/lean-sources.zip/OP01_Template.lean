import OP01_Density
set_option maxRecDepth 10000

/-!
# OP-01: the lifting template and the odd-cycle closure, parametric in the distance set

Part 1 — `lift`: for any distance list `D`, window length `L`, nonnegative weights `w` with
Σ_{j<L} w_j = T and bound `B`, a *window lemma* (every D-avoiding window has Σ w_j x_{a+j} ≤ B)
lifts to T · count(a, N) ≤ B · N + T · (L − 1) for every start a ∈ ℤ and every length N — i.e.
upper density ≤ B/T.  `OP01_Density.interval_bound` is the instance D = {1,10,18}, L = 30,
T = 66, B = 24 (`interval_bound'` below re-derives it from the template).  A new fixed cell
needs only its window lemma (F1/F2); everything after it is this file.

Part 2 — `odd_cycle_bound`: a closed walk of odd length 2m+1 in the distance graph (steps
±d, d ∈ D, summing to 0) gives a window lemma with bound m and total 2m+1, hence
(2m+1) · count ≤ m · N + const — upper density ≤ m/(2m+1).  Instance: for every m ≥ 1 the
family member D = {1, 8m, 8m+8} (k = 4m in {1, 2k, 2k+8}) has the walk
m × (+(8m+8)) followed by (m+1) × (−8m), so μ ≤ m/(2m+1) = k/(2k+4) = κ, uniformly in m
(`family_k_div_4`).  The matching lower bound μ ≥ κ is Cantor–Gordon's; its Lean form is
per-instance (the witness residues) and is not part of this file.
-/

namespace OP01.Template
open EREF OP01.Density

/-- D-avoiding for an arbitrary distance list -/
def AvoidsD (D : List Int) (x : Int → Bool) : Prop :=
  ∀ (z : Int), ∀ d ∈ D, ¬ (x z = true ∧ x (z + d) = true)

/-- the window condition on [a, a+L) -/
def WindowAvoidsD (D : List Int) (L : Nat) (x : Int → Bool) (a : Int) : Prop :=
  ∀ (i j : Nat), i < j → j < L → ((j : Int) - i) ∈ D → ¬ (x (a + i) = true ∧ x (a + j) = true)

theorem windowAvoidsD_of_avoidsD (D : List Int) (L : Nat) (x : Int → Bool) (h : AvoidsD D x) (a : Int) :
    WindowAvoidsD D L x a := by
  intro i j _ _ hd hx
  apply h (a + i) _ hd
  refine ⟨hx.1, ?_⟩
  have : a + (i : Int) + ((j : Int) - i) = a + j := by omega
  rw [this]; exact hx.2

/-- the weighted window sum Σ_{j<L} w_j · x(a+j) -/
def Wgen (w : Nat → Int) (L : Nat) (x : Int → Bool) (a : Int) : Int :=
  fsum (fun j => w j * b2i (x (a + j))) L

theorem shifted_sum_gen (w : Nat → Int) (L : Nat) (x : Int → Bool) (a : Int) (N : Nat) :
    fsum (fun t => Wgen w L x (a + t)) N = fsum (fun j => w j * count x (a + j) N) L := by
  unfold Wgen
  rw [fsum_swap (fun t j => w j * b2i (x (a + t + j))) L N]
  apply fsum_congr
  intro j _
  unfold count
  rw [← fsum_mul_left]
  apply fsum_congr
  intro t _
  show w j * b2i (x (a + t + j)) = w j * b2i (x (a + j + t))
  congr 3; omega

theorem count_shift_ge_gen (x : Int → Bool) (a : Int) (N j L : Nat) (hj : j < L) (hN : L - 1 ≤ N) :
    count x (a + ((L - 1 : Nat) : Int)) (N - (L - 1)) ≤ count x (a + j) N := by
  have h := count_sub_le x (a + j) (L - 1 - j) (N - (L - 1)) j
  have e1 : a + (j : Int) + ((L - 1 - j : Nat) : Int) = a + ((L - 1 : Nat) : Int) := by omega
  have e2 : (L - 1 - j) + (N - (L - 1)) + j = N := by omega
  rw [e1, e2] at h
  exact h

/-- **the lifting template** -/
theorem lift (D : List Int) (L : Nat) (w : Nat → Int) (B T : Int)
    (hL : 1 ≤ L) (hw : ∀ j, j < L → 0 ≤ w j) (hT : fsum w L = T) (hB : 0 ≤ B)
    (hloc : ∀ x a, WindowAvoidsD D L x a → Wgen w L x a ≤ B)
    (x : Int → Bool) (hx : AvoidsD D x) (a : Int) (N : Nat) :
    T * count x a N ≤ B * N + T * ((L - 1 : Nat) : Int) := by
  have hT0 : 0 ≤ T := hT ▸ fsum_nonneg w L hw
  by_cases hN : L - 1 ≤ N
  · have hsum : fsum (fun t => Wgen w L x (a + t)) N ≤ B * N := by
      have := fsum_le (fun t => Wgen w L x (a + t)) (fun _ => B) N
        (fun t _ => hloc x (a + t) (windowAvoidsD_of_avoidsD D L x hx _))
      rw [fsum_const] at this; rw [Int.mul_comm]; exact this
    rw [shifted_sum_gen] at hsum
    have hlow : fsum (fun j => w j * count x (a + ((L - 1 : Nat) : Int)) (N - (L - 1))) L ≤
        fsum (fun j => w j * count x (a + j) N) L := by
      apply fsum_le
      intro j hj
      exact Int.mul_le_mul_of_nonneg_left (count_shift_ge_gen x a N j L hj hN) (hw j hj)
    rw [fsum_mul_right, hT] at hlow
    have hsplit : count x a N = count x a (L - 1) + count x (a + ((L - 1 : Nat) : Int)) (N - (L - 1)) := by
      have := count_add x a (L - 1) (N - (L - 1))
      rw [show (L - 1) + (N - (L - 1)) = N by omega] at this
      exact this
    have hc1 := count_le x a (L - 1)
    have hc1' : T * count x a (L - 1) ≤ T * ((L - 1 : Nat) : Int) :=
      Int.mul_le_mul_of_nonneg_left hc1 hT0
    rw [hsplit, Int.mul_add]
    omega
  · have hc := count_le x a N
    have hc' : T * count x a N ≤ T * N := Int.mul_le_mul_of_nonneg_left hc hT0
    have hTN : T * (N : Int) ≤ T * ((L - 1 : Nat) : Int) :=
      Int.mul_le_mul_of_nonneg_left (by omega) hT0
    have hBN : 0 ≤ B * (N : Int) := Int.mul_nonneg hB (by omega)
    omega

/-- the {1,10,18} interval bound re-derived from the template and the F2 window lemma -/
theorem interval_bound' (x : Int → Bool) (hx : Avoids x) (a : Int) (N : Nat) :
    66 * count x a N ≤ 24 * N + 66 * 29 :=
  lift D 30 w 24 66 (by omega) (fun j _ => by unfold w; omega) fsum_w (by omega)
    (fun x a h => window_bound x a h) x hx a N

/-! ## Part 2: odd cycles -/

/-- Σ_{i<n} f (i+1) = Σ_{i<n+1} f i − f 0 -/
theorem fsum_shift (f : Nat → Int) (n : Nat) : fsum (fun i => f (i + 1)) n = fsum f (n + 1) - f 0 := by
  have := fsum_split f 1 n
  rw [Nat.add_comm 1 n] at this
  rw [this]
  simp only [fsum, Int.zero_add]
  have : fsum (fun t => f (1 + t)) n = fsum (fun i => f (i + 1)) n := by
    apply fsum_congr; intro i _; rw [Nat.add_comm]
  omega

/-- a cyclic 0/1 sequence of odd length 2m+1 with no two cyclically adjacent ones sums to at most m -/
theorem cyclic_sum_le (y : Nat → Int) (m : Nat)
    (h01 : ∀ i, i ≤ 2 * m + 1 → 0 ≤ y i ∧ y i ≤ 1)
    (hcyc : y (2 * m + 1) = y 0)
    (hadj : ∀ i, i < 2 * m + 1 → y i + y (i + 1) ≤ 1) :
    fsum y (2 * m + 1) ≤ m := by
  have h1 : fsum (fun i => y i + y (i + 1)) (2 * m + 1) ≤ (2 * m + 1 : Nat) * 1 := by
    rw [← fsum_const]; exact fsum_le _ _ _ (fun i hi => hadj i hi)
  rw [fsum_add, fsum_shift] at h1
  have h2 : fsum y (2 * m + 1 + 1) = fsum y (2 * m + 1) + y (2 * m + 1) := rfl
  rw [h2, hcyc] at h1
  push_cast at h1
  omega

/-- positions of the walk: p i = Σ_{j<i} s j -/
abbrev walkPos (s : Nat → Int) (i : Nat) : Int := fsum s i

/-- **the cycle lemma** (adjacency form): along a closed walk of odd length 2m+1 whose consecutive
positions never both carry a one, at most m positions carry a one -/
theorem cycle_lemma_adj (s : Nat → Int) (m : Nat) (hclosed : fsum s (2 * m + 1) = 0)
    (x : Int → Bool) (a : Int)
    (hadj : ∀ i, i < 2 * m + 1 → ¬ (x (a + walkPos s i) = true ∧ x (a + walkPos s (i + 1)) = true)) :
    fsum (fun i => b2i (x (a + walkPos s i))) (2 * m + 1) ≤ m := by
  apply cyclic_sum_le (fun i => b2i (x (a + walkPos s i))) m
  · intro i _; exact ⟨b2i_nonneg _, b2i_le_one _⟩
  · show b2i (x (a + fsum s (2 * m + 1))) = b2i (x (a + fsum s 0))
    rw [hclosed]; rfl
  · intro i hi
    have key := hadj i hi
    show b2i (x (a + walkPos s i)) + b2i (x (a + walkPos s (i + 1))) ≤ 1
    cases hx1 : x (a + walkPos s i) <;> cases hx2 : x (a + walkPos s (i + 1)) <;> simp_all [b2i]

/-- the cycle lemma for a globally D-avoiding sequence, steps in ±D -/
theorem cycle_lemma (D : List Int) (s : Nat → Int) (m : Nat)
    (hs : ∀ i, i < 2 * m + 1 → s i ∈ D ∨ -(s i) ∈ D)
    (hclosed : fsum s (2 * m + 1) = 0)
    (x : Int → Bool) (hx : AvoidsD D x) (a : Int) :
    fsum (fun i => b2i (x (a + walkPos s i))) (2 * m + 1) ≤ m := by
  apply cycle_lemma_adj s m hclosed x a
  intro i hi
  have hstep : walkPos s (i + 1) = walkPos s i + s i := rfl
  rw [hstep]
  rcases hs i hi with hd | hd
  · have := hx (a + walkPos s i) (s i) hd
    rw [show a + walkPos s i + s i = a + (walkPos s i + s i) by omega] at this
    exact this
  · have := hx (a + (walkPos s i + s i)) (-(s i)) hd
    rw [show a + (walkPos s i + s i) + -(s i) = a + walkPos s i by omega] at this
    intro h; exact this ⟨h.2, h.1⟩

/-- bounded steps give bounded positions: |s j| ≤ M ⇒ |p i| ≤ i·M -/
theorem walkPos_bound (s : Nat → Int) (M : Int) (hM : ∀ j, -M ≤ s j ∧ s j ≤ M) (i : Nat) :
    -((i : Int) * M) ≤ walkPos s i ∧ walkPos s i ≤ (i : Int) * M := by
  induction i with
  | zero => simp [walkPos, fsum]
  | succ i ih =>
    show -(((i + 1 : Nat) : Int) * M) ≤ fsum s i + s i ∧ fsum s i + s i ≤ ((i + 1 : Nat) : Int) * M
    have := hM i
    push_cast
    rw [Int.add_mul, Int.one_mul]
    unfold walkPos at ih
    omega

/-- multiplicity of the offset j among the walk positions shifted by lo -/
def mult (s : Nat → Int) (n : Nat) (lo : Int) (j : Nat) : Int :=
  fsum (fun i => if walkPos s i - lo = j then 1 else 0) n

/-- Σ_{j<L} [q = j] · f j = f q for 0 ≤ q < L (as integers) -/
theorem fsum_indicator (f : Nat → Int) (q : Int) (L : Nat) (h0 : 0 ≤ q) (hL : q < L) :
    fsum (fun j => (if q = j then 1 else 0) * f j) L = f q.toNat := by
  induction L with
  | zero => omega
  | succ L ih =>
    simp only [fsum]
    by_cases hq : q = L
    · subst hq
      rw [if_pos rfl, Int.one_mul, Int.toNat_natCast]
      have : fsum (fun j => (if (L : Int) = j then 1 else 0) * f j) L = fsum (fun _ => (0 : Int)) L := by
        apply fsum_congr; intro j hj
        rw [if_neg (by omega), Int.zero_mul]
      rw [this, fsum_const]; simp
    · rw [if_neg hq, Int.zero_mul, ih (by omega)]; omega

theorem mult_nonneg (s : Nat → Int) (n : Nat) (lo : Int) (j : Nat) : 0 ≤ mult s n lo j := by
  unfold mult; apply fsum_nonneg; intro i _; split <;> omega

/-- the walk's window sum equals the sum over its positions -/
theorem Wgen_mult (s : Nat → Int) (n : Nat) (lo : Int) (L : Nat)
    (hb : ∀ i, i < n → lo ≤ walkPos s i ∧ walkPos s i < lo + L) (x : Int → Bool) (a : Int) :
    Wgen (mult s n lo) L x a = fsum (fun i => b2i (x ((a - lo) + walkPos s i))) n := by
  unfold Wgen mult
  have : fsum (fun j => fsum (fun i => if walkPos s i - lo = j then 1 else 0) n * b2i (x (a + j))) L =
      fsum (fun j => fsum (fun i => (if walkPos s i - lo = j then 1 else 0) * b2i (x (a + j))) n) L := by
    apply fsum_congr; intro j _; rw [fsum_mul_right]
  rw [this, ← fsum_swap (fun i j => (if walkPos s i - lo = j then 1 else 0) * b2i (x (a + j))) L n]
  apply fsum_congr
  intro i hi
  obtain ⟨h1, h2⟩ := hb i hi
  rw [fsum_indicator (fun j => b2i (x (a + j))) (walkPos s i - lo) L (by omega) (by omega)]
  show b2i (x (a + ((walkPos s i - lo).toNat : Int))) = b2i (x ((a - lo) + walkPos s i))
  congr 2; omega

/-- the total weight of the walk window is its length -/
theorem mult_total (s : Nat → Int) (n : Nat) (lo : Int) (L : Nat)
    (hb : ∀ i, i < n → lo ≤ walkPos s i ∧ walkPos s i < lo + L) :
    fsum (mult s n lo) L = n := by
  unfold mult
  rw [← fsum_swap (fun i j => if walkPos s i - lo = j then 1 else 0) L n]
  have : fsum (fun i => fsum (fun j => if walkPos s i - lo = j then 1 else 0) L) n = fsum (fun _ => (1 : Int)) n := by
    apply fsum_congr; intro i hi
    obtain ⟨h1, h2⟩ := hb i hi
    have := fsum_indicator (fun _ => (1 : Int)) (walkPos s i - lo) L (by omega) (by omega)
    simp only [Int.mul_one] at this
    exact this
  rw [this, fsum_const]; omega

/-- **the odd-cycle bound**: a closed walk of odd length 2m+1 with steps in ±D (D positive),
positions in [lo, lo+L), gives (2m+1) · count(a, N) ≤ m · N + (2m+1)(L−1) for every D-avoiding
sequence — upper density at most m/(2m+1) -/
theorem odd_cycle_bound (D : List Int) (hD : ∀ d ∈ D, 0 < d) (s : Nat → Int) (m : Nat) (lo : Int) (L : Nat)
    (hL : 1 ≤ L)
    (hs : ∀ i, i < 2 * m + 1 → s i ∈ D ∨ -(s i) ∈ D)
    (hclosed : fsum s (2 * m + 1) = 0)
    (hb : ∀ i, i < 2 * m + 1 → lo ≤ walkPos s i ∧ walkPos s i < lo + L)
    (x : Int → Bool) (hx : AvoidsD D x) (a : Int) (N : Nat) :
    ((2 * m + 1 : Nat) : Int) * count x a N ≤ (m : Int) * N + ((2 * m + 1 : Nat) : Int) * ((L - 1 : Nat) : Int) := by
  apply lift D L (mult s (2 * m + 1) lo) m ((2 * m + 1 : Nat) : Int) hL
    (fun j _ => mult_nonneg _ _ _ _) (mult_total s (2 * m + 1) lo L hb) (by omega) _ x hx a N
  intro y b hwin
  rw [Wgen_mult s (2 * m + 1) lo L hb y b]
  apply cycle_lemma_adj s m hclosed y (b - lo)
  intro i hi
  -- the two positions, as window offsets
  have hb1 := hb i hi
  have hb2 : lo ≤ walkPos s (i + 1) ∧ walkPos s (i + 1) < lo + L := by
    by_cases h : i + 1 < 2 * m + 1
    · exact hb (i + 1) h
    · have : i + 1 = 2 * m + 1 := by omega
      rw [this]; show lo ≤ fsum s (2 * m + 1) ∧ fsum s (2 * m + 1) < lo + L
      rw [hclosed]; have := hb 0 (by omega); simpa [walkPos, fsum] using this
  have hstep : walkPos s (i + 1) = walkPos s i + s i := rfl
  have e1 : b - lo + walkPos s i = b + ((walkPos s i - lo).toNat : Int) := by omega
  have e2 : b - lo + walkPos s (i + 1) = b + ((walkPos s (i + 1) - lo).toNat : Int) := by omega
  rw [e1, e2]
  rcases hs i hi with hd | hd
  · have hpos := hD _ hd
    exact hwin (walkPos s i - lo).toNat (walkPos s (i + 1) - lo).toNat (by omega) (by omega)
      (by rw [show (((walkPos s (i + 1) - lo).toNat : Nat) : Int) - ((walkPos s i - lo).toNat : Int) = s i by omega]; exact hd)
  · have hpos := hD _ hd
    intro h
    exact hwin (walkPos s (i + 1) - lo).toNat (walkPos s i - lo).toNat (by omega) (by omega)
      (by rw [show (((walkPos s i - lo).toNat : Nat) : Int) - ((walkPos s (i + 1) - lo).toNat : Int) = -(s i) by omega]; exact hd)
      ⟨h.2, h.1⟩

/-! ## Instance: the family {1, 2k, 2k+8} at every k divisible by 4

With k = 4m, D = {1, 8m, 8m+8} and κ = k/(2k+4) = m/(2m+1).  The walk: m steps of +(8m+8)
then m+1 steps of −8m; m·(8m+8) − (m+1)·8m = 0, length 2m+1. -/

/-- the step function of the walk -/
def famStep (m : Nat) (i : Nat) : Int := if i < m then 8 * (m : Int) + 8 else -(8 * (m : Int))

theorem famStep_closed (m : Nat) : fsum (famStep m) (2 * m + 1) = 0 := by
  have hsplit := fsum_split (famStep m) m (m + 1)
  rw [show m + (m + 1) = 2 * m + 1 by omega] at hsplit
  rw [hsplit]
  have h1 : fsum (famStep m) m = fsum (fun _ => 8 * (m : Int) + 8) m := by
    apply fsum_congr; intro i hi; unfold famStep; rw [if_pos hi]
  have h2 : fsum (fun t => famStep m (m + t)) (m + 1) = fsum (fun _ => -(8 * (m : Int))) (m + 1) := by
    apply fsum_congr; intro i _; unfold famStep; rw [if_neg (by omega)]
  rw [h1, h2, fsum_const, fsum_const]
  push_cast
  rw [Int.mul_neg, ← Int.sub_eq_add_neg, Int.mul_add, Int.add_mul, Int.mul_left_comm (m : Int) 8 m, Int.one_mul]
  omega

theorem famStep_mem (m : Nat) (i : Nat) :
    famStep m i ∈ [1, 8 * (m : Int), 8 * (m : Int) + 8] ∨ -(famStep m i) ∈ [1, 8 * (m : Int), 8 * (m : Int) + 8] := by
  unfold famStep
  split
  · left; simp
  · right; simp

theorem famStep_abs (m : Nat) (j : Nat) : -(8 * (m : Int) + 8) ≤ famStep m j ∧ famStep m j ≤ 8 * (m : Int) + 8 := by
  unfold famStep; split <;> omega

/-- **every k ≡ 0 (mod 4)**: for D = {1, 8m, 8m+8} (k = 4m), every D-avoiding sequence has
(2m+1) · count(a, N) ≤ m · N + (2m+1) · 4·m(8m+8), i.e. upper density ≤ m/(2m+1) = κ -/
theorem family_k_div_4 (m : Nat) (hm : 1 ≤ m) (x : Int → Bool)
    (hx : AvoidsD [1, 8 * (m : Int), 8 * (m : Int) + 8] x) (a : Int) (N : Nat) :
    ((2 * m + 1 : Nat) : Int) * count x a N ≤ (m : Int) * N + ((2 * m + 1 : Nat) : Int) * ((4 * (m * (8 * m + 8)) : Nat) : Int) := by
  generalize hP : m * (8 * m + 8) = P
  have hPc : (P : Int) = (m : Int) * (8 * m + 8) := by rw [← hP]; push_cast; rfl
  have hL : (4 * P + 1 : Nat) - 1 = 4 * P := by omega
  rw [← hL]
  apply odd_cycle_bound [1, 8 * (m : Int), 8 * (m : Int) + 8] (by simp; omega) (famStep m) m
    (-(2 * (P : Int))) (4 * P + 1) (by omega) (fun i _ => famStep_mem m i)
    (famStep_closed m) _ x hx a N
  intro i hi
  have hb := walkPos_bound (famStep m) (8 * (m : Int) + 8) (famStep_abs m) i
  have hi' : (i : Int) ≤ 2 * m := by omega
  have hM : 0 ≤ 8 * (m : Int) + 8 := by omega
  have h2 : (i : Int) * (8 * m + 8) ≤ 2 * (m : Int) * (8 * m + 8) := Int.mul_le_mul_of_nonneg_right hi' hM
  rw [Int.mul_assoc, ← hPc] at h2
  push_cast
  constructor <;> omega

/-! ## How a new fixed cell uses `lift`

For D with κ = B/T: supply the window length L, the weights w (Σ w = T), and the window
lemma `∀ x a, WindowAvoidsD D L x a → Wgen w L x a ≤ B` — which is what the certificate replay
(`OP01_Cert`-style `target_sat` plus the `tval_range` unfolding) produces.  `lift` then gives
T · count ≤ B · N + T(L−1) for every start and length; the witness residues give the matching
lower count.  Nothing else changes between cells. -/

end OP01.Template

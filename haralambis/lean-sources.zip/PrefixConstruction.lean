import PhysicalBridge
import PrefixBounds
import SigningPhysical

/-! Actual physical signing instantiated in the canonical set model. The
resulting local prefix theorem has no signing or arithmetic-identity premise. -/
namespace Haralambis.ArbitraryTriples
noncomputable section
open Physical

theorem three_prefix_star (a b c : ℕ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (S : Set ℤ) (hS : Avoids a b c S) (t : ℤ) :
    ∃ L : ℕ, (L = a+b ∨ L = a+c ∨ L = b+c) ∧
      (Capacity.physicalCount S t L : ℝ) ≤ kappaStar a b c * L := by
  obtain ⟨σ,hσ,hfaces⟩ := global_physical_signing (setBits S) a b c t
    (by exact_mod_cast ha) (by exact_mod_cast hab) (by exact_mod_cast hbc)
    (setBits_avoiding a b c S hS)
  let ε := edgeSign S a b c σ
  have hf : ∀ f, valid a b c f → faceSum a b c t ε f = 0 := by
    intro f hv
    have h := hfaces f hv
    simpa only [faceSum, ε, edgeSign, mul_ite, mul_zero] using h
  obtain ⟨cab,cac,cbc⟩ := curls_of_faceSum a b c hab hbc t ε hf
  have vs := validSigns_of_edgeSign a b c hab hbc S hS σ hσ t
  obtain ⟨L,hL,hcount⟩ := three_prefix_of_same_signing a b c ha hab hbc
    (setOccupancy S) (lengthSign a b ε) t
    (vs a b (Or.inl rfl) (Or.inr (Or.inl rfl)))
    (vs a c (Or.inl rfl) (Or.inr (Or.inr rfl)))
    (vs b c (Or.inr (Or.inl rfl)) (Or.inr (Or.inr rfl))) cab cac cbc
  refine ⟨L,hL,?_⟩
  change ((Counts.count (fun z => (Capacity.membership S z : ℤ)) t L) : ℝ) ≤ _ at hcount
  rw [count_membership] at hcount
  simpa only [Int.cast_natCast] using hcount

theorem primitive_three_prefix_star
    (a b c : ℕ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (hp : primitive a b c) (S : Set ℤ) (hS : Avoids a b c S) (t : ℤ) :
    ∃ L : ℕ, (L = a+b ∨ L = a+c ∨ L = b+c) ∧
      (Capacity.physicalCount S t L : ℝ) ≤ kappaStar a b c * L :=
  three_prefix_star a b c ha hab hbc S hS t

#print axioms three_prefix_star
#print axioms primitive_three_prefix_star
end
end Haralambis.ArbitraryTriples

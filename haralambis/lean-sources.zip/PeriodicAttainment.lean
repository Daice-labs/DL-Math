import RationalRotation
import ModularDensity

namespace Haralambis.ArbitraryTriples
noncomputable section

def rotationSet (n p k : ℕ) : Set ℤ := {z | (z*(n:ℤ))%(p:ℤ) < (k:ℤ)}

theorem rotationSet_membership (n p k : ℕ) :
    Haralambis.Capacity.membership (rotationSet n p k) = rotationWord n p k := by
  funext z
  simp only [Haralambis.Capacity.membership,rotationSet,Set.mem_setOf_eq,rotationWord]
  split_ifs <;> rfl

theorem rotationSet_periodic (n p k : ℕ) (hp : 0<p) : Periodic (rotationSet n p k) := by
  refine ⟨p,hp,?_⟩
  intro z
  simp [rotationSet,add_mul,Int.add_emod]

theorem rotationSet_avoids (a b c n p k : ℕ) (hp : 0<p)
    (hstep : (k:ℝ)/p ≤ profile a b c ((n:ℝ)/p)) :
    Avoids a b c (rotationSet n p k) := by
  intro z hz
  refine ⟨?_,?_,?_⟩
  · exact modular_pair_avoids a n p k hp (le_trans hstep (min_le_left _ _)) z hz
  · exact modular_pair_avoids b n p k hp
      (le_trans hstep (le_trans (min_le_right _ _) (min_le_left _ _))) z hz
  · exact modular_pair_avoids c n p k hp
      (le_trans hstep (le_trans (min_le_right _ _) (min_le_right _ _))) z hz

/-- A periodic actual integer set attains the canonical rotation supremum.
No local signing, capacity assumption, or presumed sharpness enters this proof. -/
theorem arbitrary_triple_periodic_attainment (a b c : ℕ)
    (ha : 1≤a) (hab : a<b) (hbc : b<c) :
    ∃ S : Set ℤ, Avoids a b c S ∧ Periodic S ∧
      Haralambis.Capacity.originalUpperDensity S = kappa a b c := by
  obtain ⟨n,p,k,hp,hcop,hk,hphase,hdensity⟩ :=
    integral_rotation_parameters a b c (by omega) (by omega) (by omega)
  refine ⟨rotationSet n p k,rotationSet_avoids a b c n p k hp ?_,
    rotationSet_periodic n p k hp,?_⟩
  · rw [hphase,hdensity]
  · rw [Haralambis.Capacity.originalUpperDensity_eq,rotationSet_membership,
      rotationWord_density n p k hp hk hcop,hdensity]

end
end Haralambis.ArbitraryTriples
#print axioms Haralambis.ArbitraryTriples.arbitrary_triple_periodic_attainment

import LatticeMinimum

namespace Haralambis.ArbitraryTriples
noncomputable section
open Haralambis.Arithmetic OP01.Fixed411.RealWrapper

/-- Exact distance to integers on the unit cell containing t. -/
theorem distance_eq_half_sub (t : ℝ) :
    OP01.Fixed411.distanceToInteger t =
      1/2 - |t - ((Int.floor t : ℝ) + 1/2)| := by
  have hlo := Int.floor_le t
  have hhi := Int.lt_floor_add_one t
  apply le_antisymm
  · by_cases h : t ≤ (Int.floor t : ℝ)+1/2
    · have hb := distance_le_abs t (Int.floor t)
      rw [abs_of_nonneg (by linarith)] at hb
      rw [abs_of_nonpos (by linarith)]
      linarith
    · have hb := distance_le_abs t (Int.floor t+1)
      push_cast at hb
      rw [abs_of_nonpos (by linarith)] at hb
      rw [abs_of_nonneg (by linarith)]
      linarith
  · apply distance_lower_of_bracket _ _ (Int.floor t)
    · have hh := neg_le_abs (t-((Int.floor t:ℝ)+1/2)); linarith
    · push_cast
      have hh := le_abs_self (t-((Int.floor t:ℝ)+1/2)); linarith

theorem distance_nonneg (t : ℝ) : 0 ≤ OP01.Fixed411.distanceToInteger t := by
  apply le_csInf (distance_nonempty t)
  rintro r ⟨m,rfl⟩
  exact abs_nonneg _

theorem distance_le_half (t : ℝ) : OP01.Fixed411.distanceToInteger t ≤ 1/2 := by
  rw [distance_eq_half_sub]
  exact sub_le_self _ (abs_nonneg _)

theorem distance_lower_of_odd (t δ : ℝ) (A : ℤ) (hA : Odd A)
    (h : |t-(A:ℝ)/2| ≤ δ/2) :
    (1-δ)/2 ≤ OP01.Fixed411.distanceToInteger t := by
  obtain ⟨k,rfl⟩ := hA
  obtain ⟨hl,hu⟩ := abs_le.mp h
  apply distance_lower_of_bracket _ _ k <;> push_cast at * <;> linarith

theorem phase_image_bound (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (t : ℝ) : ∃ A B C : ℤ, Odd A ∧ Odd B ∧ Odd C ∧
      classSize a b c (tripleImage a b c A B C) ≤ 1-2*profile a b c t := by
  let A : ℤ := 2 * Int.floor ((a:ℝ)*t) + 1
  let B : ℤ := 2 * Int.floor ((b:ℝ)*t) + 1
  let C : ℤ := 2 * Int.floor ((c:ℝ)*t) + 1
  let δ := 1 - 2 * profile a b c t
  have hpa : profile a b c t ≤ OP01.Fixed411.distanceToInteger ((a:ℝ)*t) := min_le_left _ _
  have hpb : profile a b c t ≤ OP01.Fixed411.distanceToInteger ((b:ℝ)*t) :=
    le_trans (min_le_right _ _) (min_le_left _ _)
  have hpc : profile a b c t ≤ OP01.Fixed411.distanceToInteger ((c:ℝ)*t) :=
    le_trans (min_le_right _ _) (min_le_right _ _)
  have hδ : 0 ≤ δ := by dsimp [δ]; linarith [distance_le_half ((a:ℝ)*t)]
  have hh (d : ℕ) (hp : profile a b c t ≤ OP01.Fixed411.distanceToInteger ((d:ℝ)*t)) :
      |(d:ℝ)*t - ((2*Int.floor ((d:ℝ)*t)+1:ℤ):ℝ)/2| ≤ δ/2 := by
    rw [distance_eq_half_sub] at hp
    push_cast
    have heq : (2*(Int.floor ((d:ℝ)*t):ℝ)+1)/2 =
        (Int.floor ((d:ℝ)*t):ℝ)+1/2 := by ring
    rw [heq]; dsimp [δ]; linarith
  have hbds := (common_phase_iff (a:ℝ) b c A B C δ
    (by exact_mod_cast ha) (by exact_mod_cast hb) (by exact_mod_cast hc) hδ).mp
      ⟨t,hh a hpa,hh b hpb,hh c hpc⟩
  let X := tripleImage a b c A B C
  have hsize : classSize a b c X ≤ δ := by
    unfold classSize
    apply max_le
    · apply (div_le_iff₀ (by positivity : (0:ℝ)<a+b)).mpr
      simpa [X,tripleImage] using hbds.1
    · apply max_le
      · apply (div_le_iff₀ (by positivity : (0:ℝ)<a+c)).mpr
        simpa [X,tripleImage] using hbds.2.1
      · apply (div_le_iff₀ (by positivity : (0:ℝ)<b+c)).mpr
        simpa [X,tripleImage] using hbds.2.2
  exact ⟨A,B,C,⟨_,rfl⟩,⟨_,rfl⟩,⟨_,rfl⟩,hsize⟩

theorem profile_le_kappaStar (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (t : ℝ) : profile a b c t ≤ kappaStar a b c := by
  let A : ℤ := 2 * Int.floor ((a:ℝ)*t) + 1
  let B : ℤ := 2 * Int.floor ((b:ℝ)*t) + 1
  let C : ℤ := 2 * Int.floor ((c:ℝ)*t) + 1
  let δ := 1 - 2 * profile a b c t
  have hpa : profile a b c t ≤ OP01.Fixed411.distanceToInteger ((a:ℝ)*t) := min_le_left _ _
  have hpb : profile a b c t ≤ OP01.Fixed411.distanceToInteger ((b:ℝ)*t) :=
    le_trans (min_le_right _ _) (min_le_left _ _)
  have hpc : profile a b c t ≤ OP01.Fixed411.distanceToInteger ((c:ℝ)*t) :=
    le_trans (min_le_right _ _) (min_le_right _ _)
  have hδ : 0 ≤ δ := by dsimp [δ]; linarith [distance_le_half ((a:ℝ)*t)]
  have hh (d : ℕ) (hp : profile a b c t ≤ OP01.Fixed411.distanceToInteger ((d:ℝ)*t)) :
      |(d:ℝ)*t - ((2*Int.floor ((d:ℝ)*t)+1:ℤ):ℝ)/2| ≤ δ/2 := by
    rw [distance_eq_half_sub] at hp
    push_cast
    have heq : (2*(Int.floor ((d:ℝ)*t):ℝ)+1)/2 =
        (Int.floor ((d:ℝ)*t):ℝ)+1/2 := by ring
    rw [heq]; dsimp [δ]; linarith
  have hbds := (common_phase_iff (a:ℝ) b c A B C δ
    (by exact_mod_cast ha) (by exact_mod_cast hb) (by exact_mod_cast hc) hδ).mp
      ⟨t,hh a hpa,hh b hpb,hh c hpc⟩
  let X := tripleImage a b c A B C
  have hX : InParityLattice a b c X.1 X.2.1 X.2.2 := by
    dsimp [X, tripleImage]
    refine ⟨?_,?_,?_,?_⟩
    · unfold InRelationLattice; ring
    all_goals dsimp [A,B,C]; ring_nf; omega
  have hsize : classSize a b c X ≤ δ := by
    unfold classSize
    apply max_le
    · apply (div_le_iff₀ (by positivity : (0:ℝ)<a+b)).mpr
      simpa [X,tripleImage] using hbds.1
    · apply max_le
      · apply (div_le_iff₀ (by positivity : (0:ℝ)<a+c)).mpr
        simpa [X,tripleImage] using hbds.2.1
      · apply (div_le_iff₀ (by positivity : (0:ℝ)<b+c)).mpr
        simpa [X,tripleImage] using hbds.2.2
  have hmin := deltaStar_le_classSize a b c X hX
  unfold kappaStar
  dsimp [δ] at hsize
  linarith

theorem profile_nonneg (a b c : ℕ) (t : ℝ) : 0 ≤ profile a b c t :=
  le_min (distance_nonneg _) (le_min (distance_nonneg _) (distance_nonneg _))

theorem kappaStar_nonneg (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    0 ≤ kappaStar a b c :=
  le_trans (profile_nonneg a b c 0) (profile_le_kappaStar a b c ha hb hc 0)

def rationalClassSize (a b c : ℕ) (A : ℤ × ℤ × ℤ) : ℚ :=
  max (|(A.1 : ℚ)| / ((a : ℚ) + b))
    (max (|(A.2.1 : ℚ)| / ((a : ℚ) + c))
      (|(A.2.2 : ℚ)| / ((b : ℚ) + c)))

theorem cast_rationalClassSize (a b c : ℕ) (A : ℤ × ℤ × ℤ) :
    (rationalClassSize a b c A : ℝ) = classSize a b c A := by
  simp [rationalClassSize,classSize]

/-- Every odd integer image has a rational common phase at its exact class size. -/
theorem rational_phase_of_image (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (A B C : ℤ) (hA : Odd A) (hB : Odd B) (hC : Odd C) :
    ∃ q : ℚ, (1-classSize a b c (tripleImage a b c A B C))/2 ≤
      profile a b c (q:ℝ) := by
  let X := tripleImage a b c A B C
  let δ := rationalClassSize a b c X
  have hδ : 0 ≤ δ := by dsimp [δ,rationalClassSize]; positivity
  have hrat : |(b:ℚ)*A-(a:ℚ)*B| ≤ δ*((a:ℚ)+b) ∧
      |(c:ℚ)*A-(a:ℚ)*C| ≤ δ*((a:ℚ)+c) ∧
      |(c:ℚ)*B-(b:ℚ)*C| ≤ δ*((b:ℚ)+c) := by
    have h₁ : |(X.1:ℚ)|/((a:ℚ)+b) ≤ δ := le_max_left _ _
    have h₂ : |(X.2.1:ℚ)|/((a:ℚ)+c) ≤ δ :=
      le_trans (le_max_left _ _) (le_max_right _ _)
    have h₃ : |(X.2.2:ℚ)|/((b:ℚ)+c) ≤ δ :=
      le_trans (le_max_right _ _) (le_max_right _ _)
    have h₁' := (div_le_iff₀ (by positivity : (0:ℚ)<a+b)).mp h₁
    have h₂' := (div_le_iff₀ (by positivity : (0:ℚ)<a+c)).mp h₂
    have h₃' := (div_le_iff₀ (by positivity : (0:ℚ)<b+c)).mp h₃
    simpa [X,tripleImage] using And.intro h₁' (And.intro h₂' h₃')
  obtain ⟨q,hqa,hqb,hqc⟩ :=
    (common_phase_iff (a:ℚ) b c A B C δ (by exact_mod_cast ha)
      (by exact_mod_cast hb) (by exact_mod_cast hc) hδ).mpr hrat
  have hqa' : |(a:ℝ)*(q:ℝ)-(A:ℝ)/2| ≤ (δ:ℝ)/2 := by exact_mod_cast hqa
  have hqb' : |(b:ℝ)*(q:ℝ)-(B:ℝ)/2| ≤ (δ:ℝ)/2 := by exact_mod_cast hqb
  have hqc' : |(c:ℝ)*(q:ℝ)-(C:ℝ)/2| ≤ (δ:ℝ)/2 := by exact_mod_cast hqc
  have heq : (δ:ℝ) = classSize a b c X := cast_rationalClassSize a b c X
  rw [heq] at hqa' hqb' hqc'
  exact ⟨q,le_min (distance_lower_of_odd _ _ A hA hqa')
    (le_min (distance_lower_of_odd _ _ B hB hqb')
      (distance_lower_of_odd _ _ C hC hqc'))⟩

theorem primitive_rational_phase_kappaStar (a b c : ℕ)
    (ha : 0<a) (hb : 0<b) (hc : 0<c) (hp : primitive a b c) :
    ∃ q : ℚ, profile a b c (q:ℝ) = kappaStar a b c := by
  obtain ⟨X,hX,hmin⟩ := deltaStar_attained a b c ha hb hc
  obtain ⟨A,B,C,hA,hB,hC,himage⟩ :=
    (primitive_nat_odd_image_iff a b c X.1 X.2.1 X.2.2 hp).mp hX
  obtain ⟨q,hq⟩ := rational_phase_of_image a b c ha hb hc A B C hA hB hC
  have himage' : tripleImage a b c A B C = X := by simpa using himage
  rw [himage',hmin] at hq
  exact ⟨q,le_antisymm (profile_le_kappaStar a b c ha hb hc q) hq⟩

theorem primitive_kappa_eq_kappaStar (a b c : ℕ)
    (ha : 0<a) (hb : 0<b) (hc : 0<c) (hp : primitive a b c) :
    kappa a b c = kappaStar a b c := by
  obtain ⟨q,hq⟩ := primitive_rational_phase_kappaStar a b c ha hb hc hp
  apply le_antisymm
  · apply csSup_le (Set.range_nonempty _)
    rintro r ⟨t,rfl⟩
    exact profile_le_kappaStar a b c ha hb hc t
  · rw [← hq]
    apply le_csSup
    · refine ⟨kappaStar a b c, ?_⟩
      rintro r ⟨t,rfl⟩
      exact profile_le_kappaStar a b c ha hb hc t
    · exact ⟨q,rfl⟩

/-- The odd-image optimization is attained even without primitivity. -/
theorem odd_image_minimum (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    ∃ A B C : ℤ, Odd A ∧ Odd B ∧ Odd C ∧
      ∀ D E F : ℤ, Odd D → Odd E → Odd F →
        classSize a b c (tripleImage a b c A B C) ≤
          classSize a b c (tripleImage a b c D E F) := by
  classical
  have hex : ∃ n : ℕ, ∃ A B C : ℤ, Odd A ∧ Odd B ∧ Odd C ∧
      classScore a b c (tripleImage a b c A B C) = n :=
    ⟨_,1,1,1,by norm_num,by norm_num,by norm_num,rfl⟩
  obtain ⟨A,B,C,hA,hB,hC,hs⟩ := Nat.find_spec hex
  refine ⟨A,B,C,hA,hB,hC,?_⟩
  intro D E F hD hE hF
  have hh := Nat.find_min' hex (show ∃ A B C : ℤ, Odd A ∧ Odd B ∧ Odd C ∧
      classScore a b c (tripleImage a b c A B C) =
        classScore a b c (tripleImage a b c D E F) from ⟨D,E,F,hD,hE,hF,rfl⟩)
  rw [← hs] at hh
  have hr : (classScore a b c (tripleImage a b c A B C) : ℝ) ≤
      classScore a b c (tripleImage a b c D E F) := by exact_mod_cast hh
  rw [classScore_eq a b c ha hb hc, classScore_eq a b c ha hb hc] at hr
  exact (mul_le_mul_iff_left₀ (by positivity : (0:ℝ) <
    ((a:ℝ)+b)*((a:ℝ)+c)*((b:ℝ)+c))).mp (by nlinarith [hr])

/-- Rational maximizing phase for every positive triple, without gcd assumptions. -/
theorem rational_phase_attainment (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    ∃ q : ℚ, profile a b c (q:ℝ) = kappa a b c := by
  obtain ⟨A,B,C,hA,hB,hC,hmin⟩ := odd_image_minimum a b c ha hb hc
  let r := (1-classSize a b c (tripleImage a b c A B C))/2
  have hu : ∀ t : ℝ, profile a b c t ≤ r := by
    intro t
    obtain ⟨D,E,F,hD,hE,hF,hbound⟩ := phase_image_bound a b c ha hb hc t
    have hh := hmin D E F hD hE hF
    dsimp [r]
    linarith
  obtain ⟨q,hq⟩ := rational_phase_of_image a b c ha hb hc A B C hA hB hC
  have hqeq : profile a b c (q:ℝ) = r := le_antisymm (hu q) hq
  refine ⟨q,le_antisymm ?_ ?_⟩
  · apply le_csSup
    · exact ⟨r,by rintro y ⟨t,rfl⟩; exact hu t⟩
    · exact ⟨q,rfl⟩
  · rw [hqeq]
    apply csSup_le (Set.range_nonempty _)
    rintro y ⟨t,rfl⟩
    exact hu t

end
end Haralambis.ArbitraryTriples
#print axioms Haralambis.ArbitraryTriples.primitive_kappa_eq_kappaStar


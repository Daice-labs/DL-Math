import Definitions
namespace Haralambis.ArbitraryTriples
noncomputable section

theorem profile_scale (a b c g : ℕ) (t : ℝ) :
    profile (g*a) (g*b) (g*c) t = profile a b c ((g:ℝ)*t) := by
  unfold profile
  simp [Nat.cast_mul, mul_assoc, mul_left_comm, mul_comm]

theorem kappa_scale (a b c g : ℕ) (hg : 0 < g) :
    kappa (g*a) (g*b) (g*c) = kappa a b c := by
  unfold kappa
  congr 1
  ext r
  constructor
  · rintro ⟨t,rfl⟩
    exact ⟨(g:ℝ)*t, (profile_scale a b c g t).symm⟩
  · rintro ⟨t,rfl⟩
    refine ⟨t/g, ?_⟩
    rw [profile_scale]
    have hn : (g:ℝ) ≠ 0 := by exact_mod_cast hg.ne'
    rw [mul_div_cancel₀ _ hn]

def residueSet (S : Set ℤ) (g : ℕ) (r : ℤ) : Set ℤ := {z | (g:ℤ)*z+r ∈ S}

theorem avoids_residue (a b c g : ℕ) (S : Set ℤ)
    (hS : Avoids (g*a) (g*b) (g*c) S) (r : ℤ) :
    Avoids a b c (residueSet S g r) := by
  intro z hz
  have h := hS ((g:ℤ)*z+r) hz
  dsimp [residueSet]
  convert h using 1 <;> push_cast <;> congr 2 <;> ring

#print axioms kappa_scale
#print axioms avoids_residue
end
end Haralambis.ArbitraryTriples

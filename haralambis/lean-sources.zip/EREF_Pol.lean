import EREF_Rows

/-!
# ER/EF Theorem 1 formalization — stage 3: the POL evaluator and its soundness

`def_calculus.pol`: a stack machine over tokens `ref i`, `literal l` (the degree-zero axiom ℓ ≥ 0),
`+`, `multiply k`, `divide d` (k, d ≥ 1), `s` (saturation). Every intermediate row is canonical,
and every row produced is satisfied by any assignment satisfying the referenced rows.
-/

namespace EREF

inductive Tok where
  | ref (i : Nat)
  | lit (l : Int)
  | add
  | mul (k : Nat)
  | div (d : Nat)
  | sat
  deriving DecidableEq, Repr

/-- the degree-zero literal axiom `normalize(((1, lit),), 0)` -/
def litAxiom (l : Int) : Row := normalize [(1, l)] 0

/-- the stack machine; `db` is the current database (id ↦ row) -/
def polEval (db : Nat → Option Row) : List Tok → List Row → Option Row
  | [], [r] => some r
  | [], _ => none
  | .ref i :: ts, st =>
    match db i with
    | some r => polEval db ts (r :: st)
    | none => none
  | .lit l :: ts, st => if l ≠ 0 then polEval db ts (litAxiom l :: st) else none
  | .add :: ts, b :: a :: st => polEval db ts (add a b :: st)
  | .add :: _, _ => none
  | .mul k :: ts, a :: st => if 0 < k then polEval db ts (multiply a k :: st) else none
  | .mul _ :: _, [] => none
  | .div d :: ts, a :: st => if 0 < d then polEval db ts (divide a d :: st) else none
  | .div _ :: _, [] => none
  | .sat :: ts, a :: st => polEval db ts (saturate a :: st)
  | .sat :: _, [] => none

theorem canonical_add (R S : Row) : Canonical (add R S) := canonical_normalize _ _
theorem canonical_multiply (R : Row) (k : Nat) : Canonical (multiply R k) := canonical_normalize _ _
theorem canonical_divide (R : Row) (d : Nat) : Canonical (divide R d) := canonical_normalize _ _
theorem canonical_negate (R : Row) : Canonical (negate R) := canonical_normalize _ _
theorem canonical_substConst (R : Row) (v : Nat) (b : Bool) : Canonical (substConst R v b) :=
  canonical_normalize _ _
theorem canonical_saturate (R : Row) : Canonical (saturate R) := by
  unfold saturate; split
  · exact canonical_normalize _ _
  · unfold Canonical; simp
theorem canonical_litAxiom (l : Int) : Canonical (litAxiom l) := canonical_normalize _ _

theorem val_litAxiom (l : Int) (hl : l ≠ 0) (α : Val) : (litAxiom l).val α = litVal α l := by
  unfold litAxiom; rw [val_normalize]
  · simp [tvalZ]
  · intro t ht; simp at ht; rw [ht]; exact hl

/-- a database is *good* for α when every row it holds is canonical and satisfied by α -/
def GoodDb (db : Nat → Option Row) (α : Val) : Prop :=
  ∀ i R, db i = some R → Canonical R ∧ R.sat α

/-- **POL soundness**: from a good database and a good stack, the result is canonical and satisfied -/
theorem polEval_sound (db : Nat → Option Row) (α : Val) (hdb : GoodDb db α) :
    ∀ (ts : List Tok) (st : List Row), (∀ R ∈ st, Canonical R ∧ R.sat α) →
      ∀ out, polEval db ts st = some out → Canonical out ∧ out.sat α := by
  intro ts
  induction ts with
  | nil =>
    intro st hst out hout
    match st with
    | [r] => simp [polEval] at hout; rw [← hout]; exact hst r (List.mem_cons_self ..)
    | [] => simp [polEval] at hout
    | _ :: _ :: _ => simp [polEval] at hout
  | cons t ts ih =>
    intro st hst out hout
    cases t with
    | ref i =>
      simp only [polEval] at hout
      split at hout
      · rename_i r hr
        apply ih (r :: st) _ out hout
        intro R hR
        rcases List.mem_cons.mp hR with rfl | hR
        · exact hdb i R hr
        · exact hst R hR
      · exact absurd hout (by simp)
    | lit l =>
      simp only [polEval] at hout
      split at hout
      · rename_i hl
        apply ih _ _ out hout
        intro R hR
        rcases List.mem_cons.mp hR with rfl | hR
        · refine ⟨canonical_litAxiom l, ?_⟩
          unfold Row.sat; rw [val_litAxiom l hl]; exact litVal_nonneg α l
        · exact hst R hR
      · exact absurd hout (by simp)
    | add =>
      match st with
      | b :: a :: st =>
        simp only [polEval] at hout
        apply ih _ _ out hout
        intro R hR
        rcases List.mem_cons.mp hR with rfl | hR
        · have ha := hst a (List.mem_cons_of_mem _ (List.mem_cons_self ..))
          have hb := hst b (List.mem_cons_self ..)
          exact ⟨canonical_add a b, sat_add a b ha.1 hb.1 α ha.2 hb.2⟩
        · exact hst R (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hR))
      | [] => simp [polEval] at hout
      | [_] => simp [polEval] at hout
    | mul k =>
      match st with
      | a :: st =>
        simp only [polEval] at hout
        split at hout
        · apply ih _ _ out hout
          intro R hR
          rcases List.mem_cons.mp hR with rfl | hR
          · have ha := hst a (List.mem_cons_self ..)
            exact ⟨canonical_multiply a k, sat_multiply a ha.1 k α ha.2⟩
          · exact hst R (List.mem_cons_of_mem _ hR)
        · exact absurd hout (by simp)
      | [] => simp [polEval] at hout
    | div d =>
      match st with
      | a :: st =>
        simp only [polEval] at hout
        split at hout
        · rename_i hd
          apply ih _ _ out hout
          intro R hR
          rcases List.mem_cons.mp hR with rfl | hR
          · have ha := hst a (List.mem_cons_self ..)
            exact ⟨canonical_divide a d, sat_divide a ha.1 d hd α ha.2⟩
          · exact hst R (List.mem_cons_of_mem _ hR)
        · exact absurd hout (by simp)
      | [] => simp [polEval] at hout
    | sat =>
      match st with
      | a :: st =>
        simp only [polEval] at hout
        apply ih _ _ out hout
        intro R hR
        rcases List.mem_cons.mp hR with rfl | hR
        · have ha := hst a (List.mem_cons_self ..)
          exact ⟨canonical_saturate a, sat_saturate a ha.1 α ha.2⟩
        · exact hst R (List.mem_cons_of_mem _ hR)
      | [] => simp [polEval] at hout

/-- corollary: a POL step whose result is syntactically contradictory refutes the database -/
theorem polEval_contra (db : Nat → Option Row) (ts : List Tok) (h : polEval db ts [] = some contra) :
    ∀ α, ¬ GoodDb db α := by
  intro α hdb
  have := (polEval_sound db α hdb ts [] (by simp) contra h).2
  unfold Row.sat Row.val contra at this; simp [tval] at this

end EREF

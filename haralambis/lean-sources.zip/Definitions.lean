import CapacityDensity
import WallCounts

/-! Definition reconciliation only. The arbitrary-triple Haralambis theorem is
not assumed or declared in this module. Existing density and circular-distance
definitions are imported unchanged from their retained source files. -/
namespace Haralambis.ArbitraryTriples
noncomputable section

def avoids (a b c : ℕ) (x : ℤ → ℕ) : Prop :=
  OP01.Fixed411.bitValid x ∧ ∀ z,
    x z + x (z + (a : ℤ)) ≤ 1 ∧
    x z + x (z + (b : ℤ)) ≤ 1 ∧
    x z + x (z + (c : ℤ)) ≤ 1

def Avoids (a b c : ℕ) (S : Set ℤ) : Prop :=
  ∀ z, z ∈ S → z + (a : ℤ) ∉ S ∧
    z + (b : ℤ) ∉ S ∧ z + (c : ℤ) ∉ S

def mu (a b c : ℕ) : ℝ :=
  sSup {r : ℝ | ∃ x : ℤ → ℕ, avoids a b c x ∧
    r = OP01.Fixed411.upperDensity x}

def profile (a b c : ℕ) (t : ℝ) : ℝ :=
  min (OP01.Fixed411.distanceToInteger ((a : ℝ) * t))
    (min (OP01.Fixed411.distanceToInteger ((b : ℝ) * t))
      (OP01.Fixed411.distanceToInteger ((c : ℝ) * t)))

def kappa (a b c : ℕ) : ℝ := sSup (Set.range (profile a b c))

def primitive (a b c : ℕ) : Prop := Nat.gcd (Nat.gcd a b) c = 1

def Periodic (S : Set ℤ) : Prop :=
  ∃ p : ℕ, 0 < p ∧ ∀ z : ℤ, z + (p : ℤ) ∈ S ↔ z ∈ S

theorem count_cast (x : ℤ → ℕ) (t : ℤ) (n : ℕ) :
    Haralambis.Counts.count (fun z => (x z : ℤ)) t n =
      (OP01.Fixed411.intervalCount x t n : ℤ) := by
  simp [Haralambis.Counts.count, OP01.Fixed411.intervalCount]

theorem count_membership (S : Set ℤ) (t : ℤ) (n : ℕ) :
    Haralambis.Counts.count
      (fun z => (Haralambis.Capacity.membership S z : ℤ)) t n =
      (Haralambis.Capacity.physicalCount S t n : ℤ) := by
  rw [count_cast, Haralambis.Capacity.physicalCount_eq]

theorem avoids_fixed (x : ℤ → ℕ) :
    avoids 1 10 18 x ↔ OP01.Fixed411.avoids x := Iff.rfl

theorem mu_fixed : mu 1 10 18 = OP01.Fixed411.mu := rfl

theorem kappa_fixed : kappa 1 10 18 = OP01.Fixed411.kappa := by
  have hp : profile 1 10 18 = fun t : ℝ =>
      min (OP01.Fixed411.distanceToInteger t)
        (min (OP01.Fixed411.distanceToInteger (10*t))
          (OP01.Fixed411.distanceToInteger (18*t))) := by
    funext t
    simp [profile]
  unfold kappa
  rw [hp]
  rfl

theorem avoids_membership_iff (a b c : ℕ) (S : Set ℤ) :
    avoids a b c (Haralambis.Capacity.membership S) ↔ Avoids a b c S := by
  classical
  constructor
  · rintro ⟨_, h⟩ z hz
    have hh := h z
    simpa [Haralambis.Capacity.membership, hz] using hh
  · intro h
    refine ⟨Haralambis.Capacity.membership_bits S, ?_⟩
    intro z
    by_cases hz : z ∈ S
    · obtain ⟨ha, hb, hc⟩ := h z hz
      simp [Haralambis.Capacity.membership, hz, ha, hb, hc]
    · simp only [Haralambis.Capacity.membership, hz, ↓reduceIte, zero_add]
      constructor
      · split_ifs <;> omega
      constructor <;> split_ifs <;> omega

end
end Haralambis.ArbitraryTriples

import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Tactic.Ring
import Lean.Elab.Tactic.Omega

namespace Haralambis.Identities
open Finset

def W (s : ℤ → ℕ → ℤ) (t : ℤ) (x y : ℕ) : ℤ :=
  (∑ i ∈ range y, s (t+i) x) - ∑ i ∈ range x, s (t+i) y

def curl (s : ℤ → ℕ → ℤ) (t : ℤ) (x y : ℕ) : ℤ :=
  s t x + s (t+x) y - s (t+y) x - s t y

theorem shift_sum (f : ℤ → ℤ) (t : ℤ) (n : ℕ) :
    (∑ i ∈ range n, f (t+1+i)) - (∑ i ∈ range n, f (t+i)) = f (t+n)-f t := by
  induction n with
  | zero => simp
  | succ n ih =>
    simp only [sum_range_succ]
    have he : t+1+(n:ℤ) = t+(n:ℤ)+1 := by omega
    push_cast
    rw [he]
    simp only [Int.add_assoc] at *
    omega

theorem increment (s : ℤ → ℕ → ℤ) (t : ℤ) (x y : ℕ) :
    W s (t+1) x y - W s t x y = -curl s t x y := by
  have hx := shift_sum (fun u => s u x) t y
  have hy := shift_sum (fun u => s u y) t x
  unfold W curl
  omega

theorem double_swap (f : ℤ → ℤ) (t : ℤ) (x y : ℕ) :
    (∑ i ∈ range x, ∑ j ∈ range y, f (t+i+j)) =
      ∑ j ∈ range y, ∑ i ∈ range x, f (t+j+i) := by
  rw [sum_comm]
  apply sum_congr rfl
  intro j hj
  apply sum_congr rfl
  intro i hi
  congr 1
  omega

theorem rectangle (s : ℤ → ℕ → ℤ) (t : ℤ) (a b c : ℕ) :
    (∑ k ∈ range b, W s (t+k) a c) - (∑ k ∈ range c, W s (t+k) a b) =
      ∑ j ∈ range a, W s (t+j) b c := by
  simp only [W, sum_sub_distrib]
  rw [double_swap (fun u => s u a) t b c,
      double_swap (fun u => s u c) t b a,
      double_swap (fun u => s u b) t c a]
  ring

theorem constant_of_curl (s : ℤ → ℕ → ℤ) (t : ℤ) (x y N : ℕ)
    (hz : ∀ k : ℕ, k+1 < N → curl s (t+k) x y = 0) :
    ∀ k : ℕ, k < N → W s (t+k) x y = W s t x y := by
  intro k hk
  induction k with
  | zero => simp
  | succ k ih =>
    have hi := ih (by omega)
    have h := increment s (t+k) x y
    rw [hz k (by omega)] at h
    have he : t+((k+1:ℕ):ℤ) = (t+k)+1 := by omega
    rw [he]
    omega

theorem compatible_class (s : ℤ → ℕ → ℤ) (t : ℤ) (a b c : ℕ)
    (hab : ∀ k : ℕ, k+1<c → curl s (t+k) a b = 0)
    (hac : ∀ k : ℕ, k+1<b → curl s (t+k) a c = 0)
    (hbc : ∀ k : ℕ, k+1<a → curl s (t+k) b c = 0) :
    (c:ℤ)*W s t a b - (b:ℤ)*W s t a c + (a:ℤ)*W s t b c = 0 := by
  have h := rectangle s t a b c
  have eab : (∑ k ∈ range c, W s (t+k) a b) = c * W s t a b := by
    calc
      _ = ∑ k ∈ range c, W s t a b := sum_congr rfl (fun k hk => constant_of_curl s t a b c hab k (mem_range.mp hk))
      _ = _ := by simp
  have eac : (∑ k ∈ range b, W s (t+k) a c) = b * W s t a c := by
    calc
      _ = ∑ k ∈ range b, W s t a c := sum_congr rfl (fun k hk => constant_of_curl s t a c b hac k (mem_range.mp hk))
      _ = _ := by simp
  have ebc : (∑ k ∈ range a, W s (t+k) b c) = a * W s t b c := by
    calc
      _ = ∑ k ∈ range a, W s t b c := sum_congr rfl (fun k hk => constant_of_curl s t b c a hbc k (mem_range.mp hk))
      _ = _ := by simp
  rw [eab, eac, ebc] at h
  omega

#print axioms increment
#print axioms rectangle
#print axioms compatible_class
end Haralambis.Identities

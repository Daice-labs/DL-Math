import Mathlib

/-! Physical face incidence for arbitrary positive `a < b < c`.
Edges are identified by their actual integer lower endpoint and distance axis.
Faces are indexed by family (0 = ab, 1 = ac, 2 = bc) and relative start.
No gcd, parity, or nondegeneracy assumptions beyond strict positive ordering
are used. This file establishes the incidence hypotheses, not the signing lemma.
-/
set_option maxHeartbeats 3000000

namespace Haralambis.Physical

abbrev Edge := ℤ × Fin 3
abbrev Face := Fin 3 × ℤ
abbrev Occurrence := Face × Fin 4

def valid (a b c : ℤ) (f : Face) : Prop :=
  0 ≤ f.2 ∧ f.2 ≤ (if f.1 = 0 then c else if f.1 = 1 then b else a) - 2

def axes (f : Fin 3) : Fin 3 × Fin 3 :=
  if f = 0 then (0, 1) else if f = 1 then (0, 2) else (1, 2)

def distance (a b c : ℤ) (i : Fin 3) : ℤ :=
  if i = 0 then a else if i = 1 then b else c

/-- The four actual sides of the quadrilateral, in its boundary order. -/
def edge (a b c t : ℤ) (o : Occurrence) : Edge :=
  let x := (axes o.1.1).1
  let y := (axes o.1.1).2
  let z := t + o.1.2
  if o.2 = 0 then (z, x)
  else if o.2 = 1 then (z + distance a b c x, y)
  else if o.2 = 2 then (z + distance a b c y, x)
  else (z, y)

/-- Boundary sign multiplied by the face orientation (+,-,+). -/
def coeff (o : Occurrence) : ℤ :=
  (if o.1.1 = 1 then -1 else 1) * (if o.2 = 0 ∨ o.2 = 1 then 1 else -1)

theorem coeff_unit (o : Occurrence) : coeff o = 1 ∨ coeff o = -1 := by
  rcases o with ⟨⟨f, k⟩, s⟩
  fin_cases f <;> fin_cases s <;> norm_num [coeff]

/-- Two actual occurrences of one edge cannot carry the same oriented sign.
This checks all physical sides against their actual face-start ranges. -/
theorem same_sign_unique (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (p q : Occurrence) (hp : valid a b c p.1) (hq : valid a b c q.1)
    (he : edge a b c t p = edge a b c t q) (hs : coeff p = coeff q) : p = q := by
  rcases p with ⟨⟨f, k⟩, s⟩
  rcases q with ⟨⟨g, l⟩, u⟩
  fin_cases f <;> fin_cases g <;> fin_cases s <;> fin_cases u <;>
    simp_all [valid, edge, axes, distance, coeff, Prod.ext_iff] <;> omega

/-- F2: distinct occurrences of a shared physical edge have opposite signs. -/
theorem shared_opposite (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (p q : Occurrence) (hp : valid a b c p.1) (hq : valid a b c q.1)
    (he : edge a b c t p = edge a b c t q) (hne : p ≠ q) : coeff p = -coeff q := by
  have hd : coeff p ≠ coeff q := fun h => hne (same_sign_unique a b c t ha hab hbc p q hp hq he h)
  rcases coeff_unit p with hp' | hp' <;> rcases coeff_unit q with hq' | hq' <;> omega

/-- F1: among any three occurrences of one physical edge, two coincide. -/
theorem at_most_two (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (p q r : Occurrence) (hp : valid a b c p.1) (hq : valid a b c q.1)
    (hr : valid a b c r.1)
    (hpq : edge a b c t p = edge a b c t q)
    (hpr : edge a b c t p = edge a b c t r) : p = q ∨ p = r ∨ q = r := by
  by_cases h : coeff p = coeff q
  · exact Or.inl (same_sign_unique a b c t ha hab hbc p q hp hq hpq h)
  by_cases h' : coeff p = coeff r
  · exact Or.inr (Or.inl (same_sign_unique a b c t ha hab hbc p r hp hr hpr h'))
  have hqr : coeff q = coeff r := by
    rcases coeff_unit p with hp' | hp' <;> rcases coeff_unit q with hq' | hq' <;>
      rcases coeff_unit r with hr' | hr' <;> omega
  exact Or.inr (Or.inr (same_sign_unique a b c t ha hab hbc q r hq hr (hpq.symm.trans hpr) hqr))

/-- The bc face family is empty at a=1, including its end cases. -/
theorem no_bc_when_a_one (b c k : ℤ) : ¬valid 1 b c (2, k) := by
  simp [valid]
  omega

/-- Every actual side lies in the claimed ambient integer interval. -/
theorem ambient_bounds (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (o : Occurrence) (ho : valid a b c o.1) :
    t ≤ (edge a b c t o).1 ∧
    (edge a b c t o).1 + distance a b c (edge a b c t o).2 ≤ t + a + b + c - 2 := by
  rcases o with ⟨⟨f, k⟩, s⟩
  fin_cases f <;> fin_cases s <;>
    simp_all [valid, edge, axes, distance] <;> omega

/-- The six boundary pairs, retaining the axis when starts coincide. -/
def boundaryEdge (a b c t : ℤ) (j : Fin 6) : Edge :=
  if j = 0 then (t+b-1, 0) else if j = 1 then (t+c-1, 0)
  else if j = 2 then (t+a-1, 1) else if j = 3 then (t+c-1, 1)
  else if j = 4 then (t+a-1, 2) else (t+b-1, 2)

def boundaryOccurrence (a b c : ℤ) (j : Fin 6) : Occurrence :=
  if j = 0 then ((0,b-1),0) else if j = 1 then ((0,c-b-1),2)
  else if j = 2 then ((0,a-1),3) else if j = 3 then ((0,c-a-1),1)
  else if j = 4 then ((1,a-1),3) else ((1,b-a-1),1)

theorem boundary_occurs (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (j : Fin 6) : valid a b c (boundaryOccurrence a b c j).1 ∧
    edge a b c t (boundaryOccurrence a b c j) = boundaryEdge a b c t j := by
  fin_cases j <;> simp [boundaryOccurrence, boundaryEdge, valid, edge, axes, distance, Prod.ext_iff] <;> omega

/-- Each named boundary pair has exactly one physical face occurrence. -/
theorem boundary_unique (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (j : Fin 6) (o : Occurrence) (ho : valid a b c o.1)
    (he : edge a b c t o = boundaryEdge a b c t j) : o = boundaryOccurrence a b c j := by
  rcases o with ⟨⟨f,k⟩,s⟩
  fin_cases j <;> fin_cases f <;> fin_cases s <;>
    simp_all [boundaryOccurrence, boundaryEdge, valid, edge, axes, distance, Prod.ext_iff] <;> omega

theorem boundary_single (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (j : Fin 6) : ∃! o : Occurrence, valid a b c o.1 ∧ edge a b c t o = boundaryEdge a b c t j := by
  refine ⟨boundaryOccurrence a b c j, boundary_occurs a b c t ha hab hbc j, ?_⟩
  intro o ho
  exact boundary_unique a b c t ha hab hbc j o ho.1 ho.2

/-- These are six distinct physical edges, even for a=1 or adjacent distances. -/
theorem boundary_injective (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c) :
    Function.Injective (boundaryEdge a b c t) := by
  intro i j h
  fin_cases i <;> fin_cases j <;> simp_all [boundaryEdge, Prod.ext_iff] <;> omega

/-- Distinct axes are distinct actual lengths for arbitrary strictly ordered distances. -/
theorem distance_injective (a b c : ℤ) (hab : a < b) (hbc : b < c) :
    Function.Injective (distance a b c) := by
  intro i j h
  fin_cases i <;> fin_cases j <;> simp_all [distance] <;> omega

/-- The abstract edge key determines, and is determined by, its ordered physical endpoints. -/
def endpoints (a b c : ℤ) (e : Edge) : ℤ × ℤ := (e.1, e.1 + distance a b c e.2)

theorem endpoints_injective (a b c : ℤ) (hab : a < b) (hbc : b < c) :
    Function.Injective (endpoints a b c) := by
  rintro ⟨r,i⟩ ⟨s,j⟩ h
  simp only [endpoints, Prod.mk.injEq] at h
  have hd : distance a b c i = distance a b c j := by omega
  exact Prod.ext h.1 (distance_injective a b c hab hbc hd)

/-- All four sides of an individual face are different physical edges. -/
theorem face_sides_injective (a b c t : ℤ) (ha : 1 ≤ a) (hab : a < b) (hbc : b < c)
    (f : Face) : Function.Injective (fun s : Fin 4 => edge a b c t (f,s)) := by
  rcases f with ⟨f,k⟩
  intro s u h
  fin_cases f <;> fin_cases s <;> fin_cases u <;>
    simp_all [edge, axes, distance, Prod.ext_iff] <;> omega

end Haralambis.Physical

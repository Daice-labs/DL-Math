import OP01_Cert
set_option maxRecDepth 10000

/-!
# OP-01 fixed D = {1,10,18}: from the kernel-checked local lemma to μ(D) = κ(D) = 4/11

Handoff obligations F2–F7 (`FORMALIZATION_HANDOFF.txt`, SHA-256 bedc624a…0138), in core Lean
(no Mathlib). The real-valued wrappers of `StatementSpec.lean` (`upperDensity` as an `sInf`, `mu`
as an `sSup`, `kappa` over ℝ) are Mathlib-dependent; every statement here is the integer form
whose content those wrappers package:

* F2  `window_bound`      Σ_{j<30} w_j x_{a+j} ≤ 24 for every window of a D-avoiding 0/1 sequence
* F3  `interval_bound`    11 · count(a, N) ≤ 4N + 319 for every start a ∈ ℤ and every length N
* F5  `witness_avoids`, `witness_count`   {0,2,5,8} + 11ℤ avoids D and 4N − 40 ≤ 11 · count ≤ 4N + 319
* F6  `kappa_at_4_11`, `kappa_le_4_11`    ‖(4/11)·d‖ ≥ 4/11 for all d ∈ D; every rational t = p/q has
                                          some d ∈ D with ‖t·d‖ ≤ 4/11 (cleared-denominator forms)
* F7  `cyclic_bound`      11 · |I| ≤ 4n for every independent set I of the circulant C_n(D), n > 0

Conventions: a 0/1 sequence is `x : Int → Bool`; `b2i` (from the row algebra) is its 0/1 value;
`count x a N = Σ_{t<N} x(a+t)`; `fsum f n = Σ_{j<n} f j`.
-/

namespace OP01.Density
open EREF OP01.Cert

/-- the distance set -/
def D : List Int := [1, 10, 18]

/-- a 0/1 sequence on ℤ avoids D: no two ones at a distance in D -/
def Avoids (x : Int → Bool) : Prop :=
  ∀ (z : Int), ∀ d ∈ D, ¬ (x z = true ∧ x (z + d) = true)

/-- the window condition the 61 edge rows express (0 ≤ i < j < 30, j − i ∈ D) -/
def WindowAvoids (x : Int → Bool) (a : Int) : Prop :=
  ∀ (i j : Nat), i < j → j < 30 → ((j : Int) - i) ∈ D → ¬ (x (a + i) = true ∧ x (a + j) = true)

theorem windowAvoids_of_avoids (x : Int → Bool) (h : Avoids x) (a : Int) : WindowAvoids x a := by
  intro i j _ _ hd hx
  have := h (a + i) _ hd
  apply this
  refine ⟨hx.1, ?_⟩
  have : a + (i : Int) + ((j : Int) - i) = a + j := by omega
  rw [this]; exact hx.2

/-- the handoff's weights (`StatementSpec.weight`) -/
def wN (j : Nat) : Nat := if j = 9 ∨ j = 20 then 3 else if j = 10 ∨ j = 19 then 4 else 2
def w (j : Nat) : Int := (wN j : Int)

/-! ## finite sums -/

/-- Σ_{j<n} f j -/
def fsum (f : Nat → Int) : Nat → Int
  | 0 => 0
  | n + 1 => fsum f n + f n

theorem fsum_congr (f g : Nat → Int) (n : Nat) (h : ∀ j, j < n → f j = g j) : fsum f n = fsum g n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [fsum]; rw [ih (fun j hj => h j (by omega)), h n (by omega)]

theorem fsum_add (f g : Nat → Int) (n : Nat) :
    fsum (fun j => f j + g j) n = fsum f n + fsum g n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [fsum]; rw [ih]; omega

theorem fsum_sub (f g : Nat → Int) (n : Nat) :
    fsum (fun j => f j - g j) n = fsum f n - fsum g n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [fsum]; rw [ih]; omega

theorem fsum_mul_left (c : Int) (f : Nat → Int) (n : Nat) :
    fsum (fun j => c * f j) n = c * fsum f n := by
  induction n with
  | zero => simp [fsum]
  | succ n ih => simp only [fsum]; rw [ih, Int.mul_add]

theorem fsum_mul_right (f : Nat → Int) (c : Int) (n : Nat) :
    fsum (fun j => f j * c) n = fsum f n * c := by
  induction n with
  | zero => simp [fsum]
  | succ n ih => simp only [fsum]; rw [ih, Int.add_mul]

theorem fsum_le (f g : Nat → Int) (n : Nat) (h : ∀ j, j < n → f j ≤ g j) : fsum f n ≤ fsum g n := by
  induction n with
  | zero => exact Int.le_refl _
  | succ n ih =>
    simp only [fsum]
    have := ih (fun j hj => h j (by omega)); have := h n (by omega); omega

theorem fsum_nonneg (f : Nat → Int) (n : Nat) (h : ∀ j, j < n → 0 ≤ f j) : 0 ≤ fsum f n := by
  induction n with
  | zero => exact Int.le_refl _
  | succ n ih =>
    simp only [fsum]
    have := ih (fun j hj => h j (by omega)); have := h n (by omega); omega

theorem fsum_const (c : Int) (n : Nat) : fsum (fun _ => c) n = n * c := by
  induction n with
  | zero => simp [fsum]
  | succ n ih => simp only [fsum]; rw [ih]; push_cast; rw [Int.add_mul]; omega

/-- splitting a sum: Σ_{j<m+n} f j = Σ_{j<m} f j + Σ_{t<n} f (m+t) -/
theorem fsum_split (f : Nat → Int) (m n : Nat) :
    fsum f (m + n) = fsum f m + fsum (fun t => f (m + t)) n := by
  induction n with
  | zero => simp [fsum]
  | succ n ih => rw [Nat.add_succ]; simp only [fsum]; rw [ih]; omega

/-- exchanging two finite sums -/
theorem fsum_swap (f : Nat → Nat → Int) (m n : Nat) :
    fsum (fun t => fsum (fun j => f t j) m) n = fsum (fun j => fsum (fun t => f t j) n) m := by
  induction n with
  | zero =>
    simp only [fsum]
    rw [fsum_const]; simp
  | succ n ih =>
    simp only [fsum]
    rw [ih, ← fsum_add]

theorem fsum_w : fsum w 30 = 66 := by decide

/-! ## windows and counts -/

/-- Σ_{j<30} w_j · x(a+j) -/
def W (x : Int → Bool) (a : Int) : Int := fsum (fun j => w j * b2i (x (a + j))) 30

/-- the number of ones in [a, a+N) -/
def count (x : Int → Bool) (a : Int) (N : Nat) : Int := fsum (fun t => b2i (x (a + t))) N

theorem b2i_nonneg (b : Bool) : 0 ≤ b2i b := by cases b <;> simp [b2i]
theorem b2i_le_one (b : Bool) : b2i b ≤ 1 := by cases b <;> simp [b2i]

theorem count_nonneg (x : Int → Bool) (a : Int) (N : Nat) : 0 ≤ count x a N :=
  fsum_nonneg _ _ (fun j _ => b2i_nonneg _)

theorem count_le (x : Int → Bool) (a : Int) (N : Nat) : count x a N ≤ N := by
  unfold count
  have := fsum_le (fun t => b2i (x (a + t))) (fun _ => 1) N (fun j _ => b2i_le_one _)
  rw [fsum_const] at this; omega

theorem count_add (x : Int → Bool) (a : Int) (m n : Nat) :
    count x a (m + n) = count x a m + count x (a + m) n := by
  unfold count
  rw [fsum_split]
  congr 1
  apply fsum_congr
  intro t _
  show b2i (x (a + ((m + t : Nat) : Int))) = b2i (x (a + m + t))
  congr 2; omega

/-- a sub-interval has at most as many ones -/
theorem count_sub_le (x : Int → Bool) (a : Int) (m n k : Nat) :
    count x (a + m) n ≤ count x a (m + n + k) := by
  rw [count_add, count_add]
  have := count_nonneg x a m
  have := count_nonneg x (a + ((m + n : Nat) : Int)) k
  omega

/-! ## F2: the window bound from the kernel-checked target row -/

/-- the target row's terms, as a map over the index range -/
theorem target_terms_eq :
    target.terms = (List.range 30).map (fun j => (wN j, -((j : Int) + 1))) := by decide

theorem tval_range (α : Val) (c : Nat → Nat) (n : Nat) :
    tval α ((List.range n).map (fun j => (c j, -((j : Int) + 1)))) =
      fsum (fun j => (c j : Int) * (1 - b2i (α (j + 1)))) n := by
  induction n with
  | zero => simp [tval, fsum]
  | succ n ih =>
    rw [List.range_succ, List.map_append, tval_append, ih]
    simp only [List.map_cons, List.map_nil, tval, fsum, Int.add_zero]
    congr 1

/-- **F2, the local weighted bound**: every window of a window-avoiding sequence has weighted
sum at most 24 -/
theorem window_bound (x : Int → Bool) (a : Int) (h : WindowAvoids x a) : W x a ≤ 24 := by
  let α : Val := fun k => x (a + (k : Int) - 1)
  have hspec : ∀ e ∈ handoffEdges, e.1 < e.2 ∧ e.2 < 30 ∧ ((e.2 : Int) - e.1) ∈ D := by decide
  have hE : ∀ R ∈ edges, R.sat α := by
    intro R hR
    obtain ⟨e, he, rfl⟩ := List.mem_map.mp hR
    rw [edgeRow_sat_iff]
    obtain ⟨h1, h2, h3⟩ := hspec e he
    have e1 : α (e.1 + 1) = x (a + e.1) := by show x _ = x _; congr 1; omega
    have e2 : α (e.2 + 1) = x (a + e.2) := by show x _ = x _; congr 1; omega
    rw [e1, e2]; exact h e.1 e.2 h1 h2 h3
  have ht := target_sat α hE
  unfold Row.sat Row.val at ht
  rw [target_terms_eq, tval_range] at ht
  have hW : fsum (fun j => (wN j : Int) * (1 - b2i (α (j + 1)))) 30 = 66 - W x a := by
    unfold W
    have : fsum (fun j => (wN j : Int) * (1 - b2i (α (j + 1)))) 30 =
        fsum (fun j => w j - w j * b2i (x (a + j))) 30 := by
      apply fsum_congr
      intro j _
      have : α (j + 1) = x (a + j) := by show x _ = x _; congr 1; omega
      rw [this]; unfold w; rw [Int.mul_sub, Int.mul_one]
    rw [this, fsum_sub, fsum_w]
  rw [hW] at ht
  show W x a ≤ 24
  have : target.bound = 42 := rfl
  omega

/-! ## F3: lifting to every interval of a D-avoiding sequence -/

/-- the N shifted window sums, exchanged: Σ_{t<N} W(a+t) = Σ_{j<30} w_j · count(a+j, N) -/
theorem shifted_sum (x : Int → Bool) (a : Int) (N : Nat) :
    fsum (fun t => W x (a + t)) N = fsum (fun j => w j * count x (a + j) N) 30 := by
  unfold W
  rw [fsum_swap (fun t j => w j * b2i (x (a + t + j))) 30 N]
  apply fsum_congr
  intro j _
  unfold count
  rw [← fsum_mul_left]
  apply fsum_congr
  intro t _
  show w j * b2i (x (a + t + j)) = w j * b2i (x (a + j + t))
  congr 3; omega

/-- every interior index a+29 .. a+N−1 lies in all 30 shifted windows -/
theorem count_shift_ge (x : Int → Bool) (a : Int) (N j : Nat) (hj : j < 30) (hN : 29 ≤ N) :
    count x (a + 29) (N - 29) ≤ count x (a + j) N := by
  have h := count_sub_le x (a + j) (29 - j) (N - 29) j
  have e1 : a + (j : Int) + ((29 - j : Nat) : Int) = a + 29 := by omega
  have e2 : (29 - j) + (N - 29) + j = N := by omega
  rw [e1, e2] at h
  exact h

/-- **F3, the interval bound**: 11 · count(a, N) ≤ 4N + 319 for every start and every length -/
theorem interval_bound (x : Int → Bool) (hx : Avoids x) (a : Int) (N : Nat) :
    11 * count x a N ≤ 4 * N + 319 := by
  by_cases hN : 29 ≤ N
  · -- Σ_{t<N} W(a+t) ≤ 24N
    have hsum : fsum (fun t => W x (a + t)) N ≤ 24 * N := by
      have := fsum_le (fun t => W x (a + t)) (fun _ => 24) N
        (fun t _ => window_bound x (a + t) (windowAvoids_of_avoids x hx _))
      rw [fsum_const] at this; omega
    rw [shifted_sum] at hsum
    -- Σ_j w_j count(a+j, N) ≥ 66 · count(a+29, N−29)
    have hlow : fsum (fun j => w j * count x (a + 29) (N - 29)) 30 ≤
        fsum (fun j => w j * count x (a + j) N) 30 := by
      apply fsum_le
      intro j hj
      have hw : 0 ≤ w j := by unfold w; omega
      exact Int.mul_le_mul_of_nonneg_left (count_shift_ge x a N j hj hN) hw
    rw [fsum_mul_right, fsum_w] at hlow
    -- count(a, N) ≤ 29 + count(a+29, N−29)
    have hsplit : count x a N = count x a 29 + count x (a + 29) (N - 29) := by
      have := count_add x a 29 (N - 29)
      rw [show 29 + (N - 29) = N by omega] at this
      exact this
    have h29 := count_le x a 29
    omega
  · have := count_le x a N
    omega

/-! ## F5: the lower construction {0, 2, 5, 8} + 11ℤ -/

/-- the handoff's witness (`StatementSpec.witness`) -/
def witness (z : Int) : Bool := decide (z % 11 = 0 ∨ z % 11 = 2 ∨ z % 11 = 5 ∨ z % 11 = 8)

theorem witness_avoids : Avoids witness := by
  intro z d hd
  simp only [D, List.mem_cons, List.not_mem_nil, or_false] at hd
  rcases hd with rfl | rfl | rfl <;> simp only [witness, decide_eq_true_eq] <;> omega

theorem witness_periodic (z : Int) : witness (z + 11) = witness z := by
  simp only [witness]
  congr 1
  apply propext
  constructor <;> intro h <;> omega

theorem count_witness_succ (a : Int) : count witness (a + 1) 11 = count witness a 11 := by
  have h1 : count witness a 12 = count witness a 1 + count witness (a + 1) 11 := by
    simpa using count_add witness a 1 11
  have h2 : count witness a 12 = count witness a 11 + count witness (a + 11) 1 := by
    simpa using count_add witness a 11 1
  have c1 : count witness a 1 = b2i (witness a) := by simp [count, fsum]
  have c2 : count witness (a + 11) 1 = b2i (witness a) := by
    simp only [count, fsum]
    rw [show a + 11 + ((0 : Nat) : Int) = a + 11 by omega, witness_periodic]; omega
  omega

theorem shift_invariant (f : Int → Int) (h : ∀ a, f (a + 1) = f a) : ∀ a, f a = f 0 := by
  intro a
  cases a with
  | ofNat n =>
    induction n with
    | zero => rfl
    | succ n ih => rw [show (Int.ofNat (n + 1)) = Int.ofNat n + 1 by rfl, h]; exact ih
  | negSucc n =>
    induction n with
    | zero => rw [← h]; rfl
    | succ n ih => rw [← h, show Int.negSucc (n + 1) + 1 = Int.negSucc n by omega]; exact ih

theorem count_witness_11 (a : Int) : count witness a 11 = 4 := by
  rw [shift_invariant (fun a => count witness a 11) count_witness_succ a]
  decide

theorem count_witness_blocks (a : Int) (k : Nat) : count witness a (11 * k) = 4 * k := by
  induction k with
  | zero => simp [count, fsum]
  | succ k ih =>
    rw [Nat.mul_succ, count_add, ih, count_witness_11]; push_cast; omega

/-- the witness has density exactly 4/11: 4N − 40 ≤ 11 · count ≤ 4N + 319 -/
theorem witness_count (a : Int) (N : Nat) :
    4 * N - 40 ≤ 11 * count witness a N ∧ 11 * count witness a N ≤ 4 * N + 319 := by
  refine ⟨?_, interval_bound witness witness_avoids a N⟩
  have hdiv : N = 11 * (N / 11) + N % 11 := (Nat.div_add_mod N 11).symm
  have hmod : N % 11 < 11 := Nat.mod_lt _ (by decide)
  have h := count_sub_le witness a 0 (11 * (N / 11)) (N % 11)
  rw [show (a + ((0 : Nat) : Int)) = a by simp, count_witness_blocks, show 0 + 11 * (N / 11) + N % 11 = N by omega] at h
  omega

/-! ## F6: κ({1,10,18}) = 4/11

`‖t‖` is the distance from t to the nearest integer.  For a rational t = p/q (q > 0) and an
integer d, `‖t·d‖ ≥ r/s` means `∀ m, s·|p·d − m·q| ≥ r·q` and `‖t·d‖ ≤ r/s` means
`∃ m, s·|p·d − m·q| ≤ r·q`; these are the definitions with the denominators cleared. -/

/-- at t = 4/11 every d ∈ D has ‖t·d‖ ≥ 4/11 (the three distances are 4/11, 4/11, 5/11) -/
theorem kappa_at_4_11 : ∀ d ∈ D, ∀ m : Int, 4 * 11 ≤ 11 * (4 * d - m * 11).natAbs := by
  intro d hd m
  simp only [D, List.mem_cons, List.not_mem_nil, or_false] at hd
  rcases hd with rfl | rfl | rfl <;> omega

/-- for every rational t = p/q some d ∈ D has ‖t·d‖ ≤ 4/11 -/
theorem kappa_le_4_11 (p q : Int) (hq : 0 < q) :
    ∃ d ∈ D, ∃ m : Int, 11 * (p * d - m * q).natAbs ≤ 4 * q := by
  have hdecomp : p % q + q * (p / q) = p := Int.emod_add_mul_ediv p q
  have hr0 : 0 ≤ p % q := Int.emod_nonneg p (by omega)
  have hr1 : p % q < q := Int.emod_lt_of_pos p hq
  generalize hk : p / q = k at hdecomp
  generalize hr : p % q = r at hdecomp hr0 hr1
  -- with p = q·k + r and m = k·d + c:  p·d − m·q = r·d − c·q
  have key : ∀ d c : Int, p * d - (k * d + c) * q = r * d - c * q := by
    intro d c
    rw [← hdecomp, Int.add_mul, Int.add_mul, Int.mul_right_comm k d q, Int.mul_comm k q]
    omega
  have hD1 : (1 : Int) ∈ D := by simp [D]
  have hD10 : (10 : Int) ∈ D := by simp [D]
  have hD18 : (18 : Int) ∈ D := by simp [D]
  by_cases c1 : 11 * r ≤ 4 * q
  · exact ⟨1, hD1, k * 1 + 0, by rw [key]; omega⟩
  by_cases c2 : 7 * q ≤ 11 * r
  · exact ⟨1, hD1, k * 1 + 1, by rw [key]; omega⟩
  by_cases c3 : 110 * r ≤ 48 * q
  · exact ⟨10, hD10, k * 10 + 4, by rw [key]; omega⟩
  by_cases c4 : 110 * r < 51 * q
  · exact ⟨18, hD18, k * 18 + 8, by rw [key]; omega⟩
  by_cases c5 : 110 * r ≤ 59 * q
  · exact ⟨10, hD10, k * 10 + 5, by rw [key]; omega⟩
  by_cases c6 : 110 * r < 62 * q
  · exact ⟨18, hD18, k * 18 + 10, by rw [key]; omega⟩
  · exact ⟨10, hD10, k * 10 + 6, by rw [key]; omega⟩

/-! ## F7: the cyclic corollary, 11·α(C_n(D)) ≤ 4n -/

/-- an independent set of the circulant C_n(D), given on the representatives 0 ≤ i < n
(`StatementSpec.cyclicValid`; a self-loop forces the vertex to 0) -/
def CyclicAvoids (n : Nat) (y : Int → Bool) : Prop :=
  ∀ (i : Int), 0 ≤ i → i < n → ∀ d ∈ D, ¬ (y i = true ∧ y ((i + d) % n) = true)

/-- the periodic lift -/
def lift (n : Nat) (y : Int → Bool) (z : Int) : Bool := y (z % n)

theorem lift_avoids (n : Nat) (hn : 0 < n) (y : Int → Bool) (h : CyclicAvoids n y) :
    Avoids (lift n y) := by
  intro z d hd hz
  have h0 : 0 ≤ z % n := Int.emod_nonneg z (by omega)
  have h1 : z % n < n := Int.emod_lt_of_pos z (by omega)
  apply h (z % n) h0 h1 d hd
  refine ⟨hz.1, ?_⟩
  have : (z % n + d) % n = (z + d) % n := by
    rw [Int.add_emod, Int.emod_emod_of_dvd _ (Int.dvd_refl _), ← Int.add_emod]
  unfold lift at hz
  rw [this]; exact hz.2

theorem lift_periodic (n : Nat) (y : Int → Bool) (z : Int) : lift n y (z + n) = lift n y z := by
  unfold lift
  rw [Int.add_emod_right]

theorem count_lift_shift (n : Nat) (y : Int → Bool) (a : Int) (m : Nat) :
    count (lift n y) (a + n) m = count (lift n y) a m := by
  unfold count
  apply fsum_congr
  intro t _
  rw [show a + (n : Int) + t = (a + t) + n by omega, lift_periodic]

theorem count_lift_blocks (n : Nat) (y : Int → Bool) (k : Nat) :
    count (lift n y) 0 (n * k) = k * count (lift n y) 0 n := by
  induction k with
  | zero => simp [count, fsum]
  | succ k ih =>
    rw [Nat.mul_succ, count_add, ih]
    have : count (lift n y) (0 + ((n * k : Nat) : Int)) n = count (lift n y) 0 n := by
      clear ih
      induction k with
      | zero => simp
      | succ k ih2 =>
        rw [show (0 : Int) + ((n * (k + 1) : Nat) : Int) = (0 + ((n * k : Nat) : Int)) + n by
            rw [Nat.mul_succ]; push_cast; omega,
          count_lift_shift]
        exact ih2
    rw [this]; push_cast; rw [Int.add_mul]; omega

/-- **F7**: every independent set of C_n(D) has 11 · |I| ≤ 4n -/
theorem cyclic_bound (n : Nat) (hn : 0 < n) (y : Int → Bool) (h : CyclicAvoids n y) :
    11 * fsum (fun i => b2i (y i)) n ≤ 4 * n := by
  have hcount : count (lift n y) 0 n = fsum (fun i => b2i (y i)) n := by
    unfold count
    apply fsum_congr
    intro i hi
    unfold lift
    rw [show (0 : Int) + (i : Int) = i by omega, Int.emod_eq_of_lt (by omega) (by omega)]
  have hb := interval_bound (lift n y) (lift_avoids n hn y h) 0 (n * 320)
  rw [count_lift_blocks, hcount] at hb
  push_cast at hb
  omega

/-- the same, as |I| ≤ ⌊4n/11⌋ -/
theorem cyclic_bound_floor (n : Nat) (hn : 0 < n) (y : Int → Bool) (h : CyclicAvoids n y) :
    fsum (fun i => b2i (y i)) n ≤ ((4 * n / 11 : Nat) : Int) := by
  have := cyclic_bound n hn y h
  omega

end OP01.Density

import Definitions
import LatticeImage
import RotationIntervals

namespace Haralambis.ArbitraryTriples
noncomputable section
open Haralambis.Arithmetic

def classSize (a b c : ℕ) (A : ℤ × ℤ × ℤ) : ℝ :=
  max (|(A.1 : ℝ)| / ((a : ℝ) + b))
    (max (|(A.2.1 : ℝ)| / ((a : ℝ) + c))
      (|(A.2.2 : ℝ)| / ((b : ℝ) + c)))

def deltaStar (a b c : ℕ) : ℝ :=
  sInf {r : ℝ | ∃ A : ℤ × ℤ × ℤ,
    InParityLattice a b c A.1 A.2.1 A.2.2 ∧ r = classSize a b c A}

def kappaStar (a b c : ℕ) : ℝ := (1 - deltaStar a b c) / 2

def classScore (a b c : ℕ) (A : ℤ × ℤ × ℤ) : ℕ :=
  max (A.1.natAbs * (a+c) * (b+c))
    (max (A.2.1.natAbs * (a+b) * (b+c)) (A.2.2.natAbs * (a+b) * (a+c)))

theorem classSize_nonneg (a b c : ℕ) (A : ℤ × ℤ × ℤ) :
    0 ≤ classSize a b c A := by unfold classSize; positivity

theorem parityLattice_nonempty (a b c : ℕ) :
    ∃ A : ℤ × ℤ × ℤ, InParityLattice a b c A.1 A.2.1 A.2.2 := by
  refine ⟨((b:ℤ)-a,(c:ℤ)-a,(c:ℤ)-b), ?_⟩
  refine ⟨?_, ?_, ?_, ?_⟩
  · unfold InRelationLattice; dsimp; ring
  all_goals dsimp; omega

theorem deltaStar_le_classSize (a b c : ℕ) (A : ℤ × ℤ × ℤ)
    (hA : InParityLattice a b c A.1 A.2.1 A.2.2) :
    deltaStar a b c ≤ classSize a b c A := by
  apply csInf_le
  · refine ⟨0, ?_⟩
    rintro r ⟨B, _, rfl⟩
    exact classSize_nonneg a b c B
  · exact ⟨A, hA, rfl⟩

theorem classScore_eq (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (A : ℤ × ℤ × ℤ) :
    (classScore a b c A : ℝ) = classSize a b c A *
      (((a:ℝ)+b)*((a:ℝ)+c)*((b:ℝ)+c)) := by
  have hab : (0:ℝ) < a+b := by positivity
  have hac : (0:ℝ) < a+c := by positivity
  have hbc : (0:ℝ) < b+c := by positivity
  have hn (z : ℤ) : (z.natAbs : ℝ) = |(z:ℝ)| := by
    simpa only [Int.cast_natCast, Int.cast_abs] using
      congrArg (fun n : ℤ => (n:ℝ)) (Int.natCast_natAbs z)
  unfold classScore classSize
  push_cast
  rw [max_mul_of_nonneg _ _ (by positivity), max_mul_of_nonneg _ _ (by positivity)]
  congr 1
  · rw [hn]; field_simp <;> ring
  · congr 1 <;> rw [hn] <;> field_simp <;> ring

theorem classSize_minimum (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    ∃ A : ℤ × ℤ × ℤ, InParityLattice a b c A.1 A.2.1 A.2.2 ∧
      ∀ B : ℤ × ℤ × ℤ, InParityLattice a b c B.1 B.2.1 B.2.2 →
        classSize a b c A ≤ classSize a b c B := by
  classical
  have hex : ∃ n : ℕ, ∃ A : ℤ × ℤ × ℤ,
      InParityLattice a b c A.1 A.2.1 A.2.2 ∧ classScore a b c A = n := by
    obtain ⟨A,hA⟩ := parityLattice_nonempty a b c
    exact ⟨_,A,hA,rfl⟩
  obtain ⟨A,hA,hs⟩ := Nat.find_spec hex
  refine ⟨A,hA,?_⟩
  intro B hB
  have hh := Nat.find_min' hex (show ∃ C : ℤ × ℤ × ℤ,
      InParityLattice a b c C.1 C.2.1 C.2.2 ∧ classScore a b c C = classScore a b c B
      from ⟨B,hB,rfl⟩)
  rw [← hs] at hh
  have hr : (classScore a b c A : ℝ) ≤ classScore a b c B := by exact_mod_cast hh
  rw [classScore_eq a b c ha hb hc A, classScore_eq a b c ha hb hc B] at hr
  exact (mul_le_mul_iff_left₀ (by positivity : (0:ℝ) <
    ((a:ℝ)+b)*((a:ℝ)+c)*((b:ℝ)+c))).mp (by nlinarith [hr])

theorem deltaStar_attained (a b c : ℕ) (ha : 0<a) (hb : 0<b) (hc : 0<c) :
    ∃ A : ℤ × ℤ × ℤ, InParityLattice a b c A.1 A.2.1 A.2.2 ∧
      classSize a b c A = deltaStar a b c := by
  obtain ⟨A,hA,hmin⟩ := classSize_minimum a b c ha hb hc
  refine ⟨A,hA,le_antisymm ?_ (deltaStar_le_classSize a b c A hA)⟩
  apply le_csInf
  · exact ⟨classSize a b c A,A,hA,rfl⟩
  · rintro r ⟨B,hB,rfl⟩
    exact hmin B hB

end
end Haralambis.ArbitraryTriples
#print axioms Haralambis.ArbitraryTriples.deltaStar_attained

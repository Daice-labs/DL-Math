import Mathlib.Tactic

set_option maxHeartbeats 2000000

namespace Haralambis.Arithmetic

variable {K : Type*} [Field K] [LinearOrder K] [IsStrictOrderedRing K]

omit [Field K] [IsStrictOrderedRing K] in
/-- The elementary one-dimensional, three-interval intersection criterion. -/
theorem three_closed_intervals (l₁ u₁ l₂ u₂ l₃ u₃ : K)
    (h₁₁ : l₁ ≤ u₁) (h₁₂ : l₁ ≤ u₂) (h₁₃ : l₁ ≤ u₃)
    (h₂₁ : l₂ ≤ u₁) (h₂₂ : l₂ ≤ u₂) (h₂₃ : l₂ ≤ u₃)
    (h₃₁ : l₃ ≤ u₁) (h₃₂ : l₃ ≤ u₂) (h₃₃ : l₃ ≤ u₃) :
    ∃ e : K, l₁ ≤ e ∧ e ≤ u₁ ∧ l₂ ≤ e ∧ e ≤ u₂ ∧ l₃ ≤ e ∧ e ≤ u₃ := by
  refine ⟨max l₁ (max l₂ l₃), le_max_left _ _, ?_, ?_, ?_, ?_, ?_⟩
  · exact max_le h₁₁ (max_le h₂₁ h₃₁)
  · exact le_trans (le_max_left _ _) (le_max_right _ _)
  · exact max_le h₁₂ (max_le h₂₂ h₃₂)
  · exact le_trans (le_max_right _ _) (le_max_right _ _)
  · exact max_le h₁₃ (max_le h₂₃ h₃₃)

/-- Exact simultaneous error criterion, with denominators cleared.
The signs agree with T(h) = (b ha-a hb, c ha-a hc, c hb-b hc). -/
theorem simultaneous_error_iff (a b c x y z δ : K)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hδ : 0 ≤ δ)
    (hrel : c * x - b * y + a * z = 0) :
    (∃ e : K, |2 * e| ≤ δ ∧ |2 * b * e + x| ≤ a * δ ∧
      |2 * c * e + y| ≤ a * δ) ↔
    |x| ≤ δ * (a + b) ∧ |y| ≤ δ * (a + c) ∧ |z| ≤ δ * (b + c) := by
  constructor
  · rintro ⟨e, he, hx, hy⟩
    obtain ⟨he₁, he₂⟩ := abs_le.mp he
    obtain ⟨hx₁, hx₂⟩ := abs_le.mp hx
    obtain ⟨hy₁, hy₂⟩ := abs_le.mp hy
    refine ⟨abs_le.mpr ⟨?_, ?_⟩, abs_le.mpr ⟨?_, ?_⟩, abs_le.mpr ⟨?_, ?_⟩⟩
    · nlinarith [mul_le_mul_of_nonneg_left he₂ hb.le]
    · nlinarith [mul_le_mul_of_nonneg_left he₁ hb.le]
    · nlinarith [mul_le_mul_of_nonneg_left he₂ hc.le]
    · nlinarith [mul_le_mul_of_nonneg_left he₁ hc.le]
    · have h₁ := mul_le_mul_of_nonneg_left hx₂ hc.le
      have h₂ := mul_le_mul_of_nonneg_left hy₁ hb.le
      have hh : a * (-(δ * (b + c))) ≤ a * z := by nlinarith [hrel]
      nlinarith
    · have h₁ := mul_le_mul_of_nonneg_left hx₁ hc.le
      have h₂ := mul_le_mul_of_nonneg_left hy₂ hb.le
      have hh : a * z ≤ a * (δ * (b + c)) := by nlinarith [hrel]
      nlinarith
  · rintro ⟨hx, hy, hz⟩
    obtain ⟨hx₁, hx₂⟩ := abs_le.mp hx
    obtain ⟨hy₁, hy₂⟩ := abs_le.mp hy
    obtain ⟨hz₁, hz₂⟩ := abs_le.mp hz
    have hb₂ : 0 < 2 * b := by positivity
    have hc₂ : 0 < 2 * c := by positivity
    have had : 0 ≤ a * δ := mul_nonneg ha.le hδ
    have h₁₁ : -δ / 2 ≤ δ / 2 := by linarith
    have h₁₂ : -δ / 2 ≤ (-x + a * δ) / (2 * b) := by
      apply (le_div_iff₀ hb₂).2
      nlinarith
    have h₁₃ : -δ / 2 ≤ (-y + a * δ) / (2 * c) := by
      apply (le_div_iff₀ hc₂).2
      nlinarith
    have h₂₁ : (-x - a * δ) / (2 * b) ≤ δ / 2 := by
      apply (div_le_iff₀ hb₂).2
      nlinarith
    have h₂₂ : (-x - a * δ) / (2 * b) ≤ (-x + a * δ) / (2 * b) := by
      apply (div_le_div_iff_of_pos_right hb₂).2
      linarith
    have h₂₃ : (-x - a * δ) / (2 * b) ≤ (-y + a * δ) / (2 * c) := by
      apply (div_le_div_iff₀ hb₂ hc₂).2
      nlinarith [mul_le_mul_of_nonneg_left hz₂ ha.le]
    have h₃₁ : (-y - a * δ) / (2 * c) ≤ δ / 2 := by
      apply (div_le_iff₀ hc₂).2
      nlinarith
    have h₃₂ : (-y - a * δ) / (2 * c) ≤ (-x + a * δ) / (2 * b) := by
      apply (div_le_div_iff₀ hc₂ hb₂).2
      nlinarith [mul_le_mul_of_nonneg_left hz₁ ha.le]
    have h₃₃ : (-y - a * δ) / (2 * c) ≤ (-y + a * δ) / (2 * c) := by
      apply (div_le_div_iff_of_pos_right hc₂).2
      linarith
    obtain ⟨e, he₁, he₂, he₃, he₄, he₅, he₆⟩ :=
      three_closed_intervals _ _ _ _ _ _ h₁₁ h₁₂ h₁₃ h₂₁ h₂₂ h₂₃ h₃₁ h₃₂ h₃₃
    have he₃' := (div_le_iff₀ hb₂).mp he₃
    have he₄' := (le_div_iff₀ hb₂).mp he₄
    have he₅' := (div_le_iff₀ hc₂).mp he₅
    have he₆' := (le_div_iff₀ hc₂).mp he₆
    refine ⟨e, abs_le.mpr ⟨?_, ?_⟩, abs_le.mpr ⟨?_, ?_⟩,
      abs_le.mpr ⟨?_, ?_⟩⟩ <;> nlinarith

private theorem half_scaled_bound_iff (u s δ : K) (hs : 0 < s) :
    |u / s| ≤ δ / 2 ↔ |2 * u| ≤ s * δ := by
  rw [abs_div, abs_of_pos hs, div_le_iff₀ hs, abs_mul]
  norm_num
  constructor <;> intro h <;> nlinarith

/-- The exact epsilon formulation displayed in the accepted arithmetic proof. -/
theorem epsilon_interval_iff (a b c x y z δ : K)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hδ : 0 ≤ δ)
    (hrel : c * x - b * y + a * z = 0) :
    (∃ e : K, |e| ≤ δ / 2 ∧ |(b * e + x / 2) / a| ≤ δ / 2 ∧
      |(c * e + y / 2) / a| ≤ δ / 2) ↔
    |x| ≤ δ * (a + b) ∧ |y| ≤ δ * (a + c) ∧ |z| ≤ δ * (b + c) := by
  rw [← simultaneous_error_iff a b c x y z δ ha hb hc hδ hrel]
  apply exists_congr
  intro e
  have h₁ := half_scaled_bound_iff e 1 δ (by norm_num : (0 : K) < 1)
  have h₂ := half_scaled_bound_iff (b * e + x / 2) a δ ha
  have h₃ := half_scaled_bound_iff (c * e + y / 2) a δ ha
  have he₂ : 2 * (b * e + x / 2) = 2 * b * e + x := by ring
  have he₃ : 2 * (c * e + y / 2) = 2 * c * e + y := by ring
  simpa only [div_one, one_mul, he₂, he₃] using and_congr h₁ (and_congr h₂ h₃)

/-- The three determinant inequalities are exactly the common-phase condition.
This works over both the real and rational fields, so rational input gives a
rational phase without an additional approximation or compactness argument. -/
theorem common_phase_iff (a b c A B C δ : K)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hδ : 0 ≤ δ) :
    (∃ θ : K, |a * θ - A / 2| ≤ δ / 2 ∧ |b * θ - B / 2| ≤ δ / 2 ∧
      |c * θ - C / 2| ≤ δ / 2) ↔
    |b * A - a * B| ≤ δ * (a + b) ∧
    |c * A - a * C| ≤ δ * (a + c) ∧
    |c * B - b * C| ≤ δ * (b + c) := by
  have hrel : c * (b * A - a * B) - b * (c * A - a * C) +
      a * (c * B - b * C) = 0 := by ring
  rw [← simultaneous_error_iff a b c (b * A - a * B)
    (c * A - a * C) (c * B - b * C) δ ha hb hc hδ hrel]
  constructor
  · rintro ⟨θ, hA, hB, hC⟩
    obtain ⟨hA₁, hA₂⟩ := abs_le.mp hA
    obtain ⟨hB₁, hB₂⟩ := abs_le.mp hB
    obtain ⟨hC₁, hC₂⟩ := abs_le.mp hC
    refine ⟨a * θ - A / 2, abs_le.mpr ⟨?_, ?_⟩,
      abs_le.mpr ⟨?_, ?_⟩, abs_le.mpr ⟨?_, ?_⟩⟩
    · nlinarith
    · nlinarith
    · nlinarith [mul_le_mul_of_nonneg_left hB₁ ha.le]
    · nlinarith [mul_le_mul_of_nonneg_left hB₂ ha.le]
    · nlinarith [mul_le_mul_of_nonneg_left hC₁ ha.le]
    · nlinarith [mul_le_mul_of_nonneg_left hC₂ ha.le]
  · rintro ⟨e, he, hB, hC⟩
    obtain ⟨he₁, he₂⟩ := abs_le.mp he
    obtain ⟨hB₁, hB₂⟩ := abs_le.mp hB
    obtain ⟨hC₁, hC₂⟩ := abs_le.mp hC
    let θ := (A / 2 + e) / a
    have heq : a * θ = A / 2 + e := by
      dsimp [θ]
      exact mul_div_cancel₀ _ (ne_of_gt ha)
    refine ⟨θ, abs_le.mpr ⟨?_, ?_⟩,
      abs_le.mpr ⟨?_, ?_⟩, abs_le.mpr ⟨?_, ?_⟩⟩
    · nlinarith
    · nlinarith
    · have hh : -(a * δ) ≤ 2 * a * (b * θ - B / 2) := by
        nlinarith [congrArg (fun t : K => b * t) heq]
      nlinarith
    · have hh : 2 * a * (b * θ - B / 2) ≤ a * δ := by
        nlinarith [congrArg (fun t : K => b * t) heq]
      nlinarith
    · have hh : -(a * δ) ≤ 2 * a * (c * θ - C / 2) := by
        nlinarith [congrArg (fun t : K => c * t) heq]
      nlinarith
    · have hh : 2 * a * (c * θ - C / 2) ≤ a * δ := by
        nlinarith [congrArg (fun t : K => c * t) heq]
      nlinarith

end Haralambis.Arithmetic

#print axioms Haralambis.Arithmetic.simultaneous_error_iff

#print axioms Haralambis.Arithmetic.common_phase_iff

#print axioms Haralambis.Arithmetic.epsilon_interval_iff

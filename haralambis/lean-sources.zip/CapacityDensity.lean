import SaturatedCapacity

namespace Haralambis.Capacity
noncomputable section
open scoped BigOperators
open OP01.Fixed411 OP01.Fixed411.RealWrapper

/-- Membership in the original set, with no graph or periodic surrogate. -/
def membership (S : Set ℤ) (z : ℤ) : ℕ := by
  classical
  exact if z∈S then 1 else 0

/-- Literal cardinality of S intersected with the half-open integer interval. -/
def physicalCount (S : Set ℤ) (w : ℤ) (N : ℕ) : ℕ := by
  classical
  exact ((Finset.Ico w (w+(N:ℤ))).filter (fun z => z∈S)).card

theorem membership_bits (S : Set ℤ) : bitValid (membership S) := by
  classical
  intro z
  simp only [membership]
  split_ifs <;> omega

theorem physicalCount_eq (S : Set ℤ) (w : ℤ) (N : ℕ) :
    physicalCount S w N = intervalCount (membership S) w N := by
  classical
  simp only [physicalCount, Finset.card_filter]
  rw [Int.Ico_eq_finset_map, Finset.sum_map]
  simp [intervalCount, membership]
  rw [Finset.card_filter]
  rfl

/-- The saturation hypothesis stated on actual integer starts. -/
def physicalSaturated (S : Set ℤ) (q k : ℕ) (w : ℤ) (P : ℕ) : ℕ :=
  ((Finset.Ico w (w+(P:ℤ))).filter (fun z => physicalCount S z q = k+1)).card

theorem physicalSaturated_eq (S : Set ℤ) (q k : ℕ) (w : ℤ) (P : ℕ) :
    physicalSaturated S q k w P = saturatedCount (membership S) q k w P := by
  classical
  simp only [physicalSaturated, saturatedCount, Finset.card_filter]
  rw [Int.Ico_eq_finset_map, Finset.sum_map]
  simp [physicalCount_eq]

/-- The original one-sided upper density: conventional limsup of actual counts. -/
def originalUpperDensity (S : Set ℤ) : ℝ :=
  Filter.limsup (fun N : ℕ => (physicalCount S 0 N:ℝ)/(N:ℝ)) Filter.atTop

def densitySequence (x : ℤ → ℕ) (N : ℕ) : ℝ :=
  (intervalCount x 0 N:ℝ)/(N:ℝ)

theorem densitySequence_nonneg (x : ℤ → ℕ) (N : ℕ) :
    0 ≤ densitySequence x N := by unfold densitySequence; positivity

theorem densitySequence_le_one (x : ℤ → ℕ) (hx : bitValid x) (N : ℕ) :
    densitySequence x N ≤ 1 := by
  by_cases hN : N=0
  · simp [densitySequence, hN]
  · have hNr : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
    apply (div_le_iff₀ hNr).mpr
    simpa using (show (intervalCount x 0 N:ℝ) ≤ (N:ℝ) by
      exact_mod_cast intervalCount_le x hx 0 N)

theorem sequence_bounded (x : ℤ → ℕ) (hx : bitValid x) :
    Filter.IsBoundedUnder (· ≤ ·) Filter.atTop (densitySequence x) :=
  by
    refine ⟨1, ?_⟩
    change ∀ᶠ N : ℕ in Filter.atTop, densitySequence x N ≤ 1
    exact Filter.Eventually.of_forall (densitySequence_le_one x hx)

theorem sequence_cobounded (x : ℤ → ℕ) :
    Filter.IsCoboundedUnder (· ≤ ·) Filter.atTop (densitySequence x) :=
  Filter.isCoboundedUnder_le_of_le Filter.atTop (densitySequence_nonneg x)

/-- Exact correspondence with the pre-existing eventual-upper-bound definition. -/
theorem eventualUpper_iff_limsup (x : ℤ → ℕ) (hx : bitValid x) (r : ℝ) :
    r ∈ eventualUpper x ↔ Filter.limsup (densitySequence x) Filter.atTop ≤ r := by
  constructor
  · intro hr
    apply (Filter.limsup_le_iff (sequence_cobounded x) (sequence_bounded x hx)).mpr
    intro y hy
    obtain ⟨N,hN⟩ := hr ((y-r)/2) (by linarith)
    apply Filter.eventually_atTop.mpr
    refine ⟨N+1, ?_⟩
    intro n hn
    have h := hN n (by omega) (by omega)
    dsimp [densitySequence]
    linarith
  · intro hr ε hε
    have hev := Filter.eventually_lt_of_limsup_lt
      (lt_of_le_of_lt hr (show r<r+ε by linarith)) (sequence_bounded x hx)
    obtain ⟨N,hN⟩ := Filter.eventually_atTop.mp hev
    refine ⟨N,?_⟩
    intro n hn _
    exact le_of_lt (hN n hn)

theorem upperDensity_eq_limsup (x : ℤ → ℕ) (hx : bitValid x) :
    upperDensity x = Filter.limsup (densitySequence x) Filter.atTop := by
  change sInf (eventualUpper x) = _
  apply le_antisymm
  · apply csInf_le (eventualUpper_bddBelow x)
    exact (eventualUpper_iff_limsup x hx _).mpr le_rfl
  · apply le_csInf (eventualUpper_nonempty x hx)
    intro r hr
    exact (eventualUpper_iff_limsup x hx r).mp hr

theorem originalUpperDensity_eq (S : Set ℤ) :
    originalUpperDensity S = upperDensity (membership S) := by
  rw [upperDensity_eq_limsup _ (membership_bits S)]
  simp only [originalUpperDensity, physicalCount_eq]
  rfl

theorem upper_density_bound (x : ℤ → ℕ) (hx : bitValid x) (q P k Δ J : ℕ)
    (hq : 0<q) (hP : 0<P) (hΔ : Δ≤P) (balance : k*P+Δ=q*J)
    (windows : ∀ w : ℤ, intervalCount x w q ≤ k+1)
    (capacity : ∀ w : ℤ, saturatedCount x q k w P ≤ Δ) :
    upperDensity x ≤ (J:ℝ)/P := by
  have h := OP01.AllEll.density_upper x hx 1 ((J:ℝ)/P)
    (((q:ℝ)-1)/2+((P:ℝ)-1)/q) (by norm_num)
    (fun n => by
      simpa only [one_mul, add_assoc] using
        interval_bound x hx q P k Δ J hq hP hΔ balance windows capacity 0 n)
  simpa using h

/-- Complete requested endpoint in literal set and conventional limsup definitions.
Both window hypotheses remain explicit. No contour or avoiding-set theorem is assumed. -/
theorem saturated_capacity_to_density (S : Set ℤ) (q P k Δ J : ℕ)
    (hq : 0<q) (hP : 0<P) (hΔ : Δ≤P) (balance : k*P+Δ=q*J)
    (windows : ∀ w : ℤ, physicalCount S w q ≤ k+1)
    (capacity : ∀ w : ℤ, physicalSaturated S q k w P ≤ Δ) :
    (∀ (w : ℤ) (N : ℕ), (physicalCount S w N:ℝ) ≤
      (J:ℝ)/P*N+((q:ℝ)-1)/2+((P:ℝ)-1)/q) ∧
    originalUpperDensity S ≤ (J:ℝ)/P := by
  have hw : ∀ w : ℤ, intervalCount (membership S) w q ≤ k+1 := by
    intro w
    simpa only [physicalCount_eq] using windows w
  have hc : ∀ w : ℤ, saturatedCount (membership S) q k w P ≤ Δ := by
    intro w
    simpa only [physicalSaturated_eq] using capacity w
  constructor
  · intro w N
    rw [physicalCount_eq]
    exact interval_bound (membership S) (membership_bits S) q P k Δ J
      hq hP hΔ balance hw hc w N
  · rw [originalUpperDensity_eq]
    exact upper_density_bound (membership S) (membership_bits S) q P k Δ J
      hq hP hΔ balance hw hc

end
end Haralambis.Capacity

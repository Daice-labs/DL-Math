import OP01_RealWrapper
import OP01_Template
namespace OP01.AllEll
noncomputable section
open scoped BigOperators
open OP01.Fixed411 OP01.Fixed411.RealWrapper
open EREF OP01.Density OP01.Template

def distances (ell k : ℕ) : List ℤ := [1,2*(k : ℤ),2*(k : ℤ)+2*ell]
def avoids (ell k : ℕ) (x : ℤ → ℕ) : Prop := bitValid x ∧
  ∀ z d, d ∈ distances ell k → x z + x (z+d) ≤ 1
def mu (ell k : ℕ) : ℝ := sSup {r : ℝ | ∃ x : ℤ → ℕ, avoids ell k x ∧ r = upperDensity x}
def profile (ell k : ℕ) (t : ℝ) : ℝ := min (distanceToInteger t)
  (min (distanceToInteger (2*(k : ℝ)*t)) (distanceToInteger ((2*(k : ℝ)+2*ell)*t)))
def kappa (ell k : ℕ) : ℝ := sSup (Set.range (profile ell k))
def tailGoal : Prop := ∀ ell k : ℕ, 1≤ell → ell*max 1 ((ell-1)^2)≤k →
  mu ell k=(k : ℝ)/(2*k+ell) ∧ kappa ell k=(k : ℝ)/(2*k+ell)

theorem avoids_bool (ell k : ℕ) (x : ℤ → ℕ) (hx : bitValid x) :
    avoids ell k x ↔ AvoidsD (distances ell k) (OP01.Fixed411.RealWrapper.toBool x) := by
  constructor
  · intro h z d hd hh
    have h1 : x z = 1 := by simpa [OP01.Fixed411.RealWrapper.toBool] using hh.1
    have h2 : x (z+d) = 1 := by simpa [OP01.Fixed411.RealWrapper.toBool] using hh.2
    have := h.2 z d hd; omega
  · intro h; refine ⟨hx,?_⟩; intro z d hd
    have hz := hx z; have hz' := hx (z+d)
    by_contra hn
    have h1 : x z=1 := by omega
    have h2 : x (z+d)=1 := by omega
    exact h z d hd ⟨by simp [OP01.Fixed411.RealWrapper.toBool,h1],by simp [OP01.Fixed411.RealWrapper.toBool,h2]⟩

theorem nat_bits (x : ℤ → Bool) : bitValid (OP01.Fixed411.RealWrapper.toNat x) := by
  intro z; cases h : x z <;> simp [OP01.Fixed411.RealWrapper.toNat,h]

theorem density_upper (x : ℤ → ℕ) (hx : bitValid x) (T B C : ℝ) (hT : 0<T)
    (hb : ∀ n : ℕ, T*(intervalCount x 0 n : ℝ) ≤ B*n+C) :
    upperDensity x ≤ B/T := by
  change sInf (eventualUpper x) ≤ _
  apply csInf_le (eventualUpper_bddBelow x)
  intro ε hε
  obtain ⟨N,hN⟩ := exists_nat_gt (C/(T*ε))
  refine ⟨N,?_⟩; intro n hn hp
  have hnR : (0 : ℝ)<n := by exact_mod_cast hp
  have hl : C/(T*ε)<(n : ℝ) := lt_of_lt_of_le hN (by exact_mod_cast hn)
  have hc : C<(n : ℝ)*(T*ε) := (div_lt_iff₀ (mul_pos hT hε)).mp hl
  have hb' := hb n
  apply (div_le_iff₀ hnR).mpr
  have he : B/T*T=B := div_mul_cancel₀ _ hT.ne'
  nlinarith

theorem density_lower (x : ℤ → ℕ) (hx : bitValid x) (T B C : ℝ) (hT : 0<T)
    (hb : ∀ n : ℕ, B*n-C ≤ T*(intervalCount x 0 n : ℝ)) :
    B/T ≤ upperDensity x := by
  change B/T ≤ sInf (eventualUpper x)
  apply le_csInf (eventualUpper_nonempty x hx)
  intro c hc
  by_contra hn
  have hlt : c < B/T := lt_of_not_ge hn
  let ε := (B/T-c)/3
  have he : 0<ε := by dsimp [ε]; linarith
  obtain ⟨N,hN⟩ := hc ε he
  obtain ⟨M,hM⟩ := exists_nat_gt (C/(T*ε))
  let n := N+M+1
  have hn : 0<n := by dsimp [n]; omega
  have hnR : (0 : ℝ)<n := by exact_mod_cast hn
  have hlarge : C/(T*ε)<(n : ℝ) := lt_of_lt_of_le hM (by dsimp [n]; exact_mod_cast (show M≤N+M+1 by omega))
  have hbudget : C<(n : ℝ)*(T*ε) := (div_lt_iff₀ (mul_pos hT he)).mp hlarge
  have hu := (div_le_iff₀ hnR).mp (hN n (by dsimp [n]; omega) hn)
  have hlo := hb n
  have heq : 3*ε = B/T-c := by dsimp [ε]; ring
  have heqT : B/T*T=B := div_mul_cancel₀ _ hT.ne'
  have heqn := congrArg (fun a : ℝ => a*T*(n : ℝ)) heq
  nlinarith [mul_pos (mul_pos he hT) hnR]

theorem mu_of_bounds (ell k : ℕ) (T B C E : ℝ) (hT : 0<T)
    (upper : ∀ x, avoids ell k x → ∀ n : ℕ, T*(intervalCount x 0 n : ℝ) ≤ B*n+C)
    (y : ℤ → ℕ) (hy : avoids ell k y)
    (lower : ∀ n : ℕ, B*n-E ≤ T*(intervalCount y 0 n : ℝ)) : mu ell k=B/T := by
  have hu (x : ℤ → ℕ) (hx : avoids ell k x) := density_upper x hx.1 T B C hT (upper x hx)
  have hyden : upperDensity y=B/T := le_antisymm (hu y hy) (density_lower y hy.1 T B E hT lower)
  have hm : B/T ∈ {r : ℝ | ∃ x, avoids ell k x ∧ r=upperDensity x} := ⟨y,hy,hyden.symm⟩
  have hbd : BddAbove {r : ℝ | ∃ x, avoids ell k x ∧ r=upperDensity x} := by
    refine ⟨B/T,?_⟩; rintro r ⟨x,hx,rfl⟩; exact hu x hx
  apply le_antisymm
  · apply csSup_le ⟨_,hm⟩; rintro r ⟨x,hx,rfl⟩; exact hu x hx
  · exact le_csSup hbd hm
end
end OP01.AllEll

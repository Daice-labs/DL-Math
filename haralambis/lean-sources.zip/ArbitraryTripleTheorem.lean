import IntervalEndpoint
import PeriodicAttainment
namespace Haralambis.ArbitraryTriples
noncomputable section
open Haralambis.Capacity

/-- Full arbitrary-triple Haralambis equality, using the canonical density and
rotation-distance supremum definitions. No primitive, parity, or signing
hypothesis remains. -/
theorem arbitrary_triple_mu_eq_kappa (a b c : ℕ)
    (ha : 1≤a) (hab : a<b) (hbc : b<c) : mu a b c = kappa a b c := by
  apply mu_eq_of_bound_and_attainment a b c (kappa a b c)
    (kappa a b c*((b:ℝ)+c-(tripleGcd a b c:ℝ)))
  · intro S hS n
    have h := arbitrary_sequence_interval a b c ha hab hbc (membership S)
      ((avoids_membership_iff a b c S).mpr hS) 0 n
    simpa only [physicalCount_eq] using h
  · obtain ⟨S,hS,_,hd⟩ := arbitrary_triple_periodic_attainment a b c ha hab hbc
    exact ⟨S,hS,hd⟩

/-- The three accepted endpoints in one declaration. Integer endpoints and the
exact gcd-scaled additive loss are retained. -/
theorem arbitrary_triple_complete (a b c : ℕ)
    (ha : 1≤a) (hab : a<b) (hbc : b<c) :
    mu a b c = kappa a b c ∧
    (∃ S : Set ℤ, Avoids a b c S ∧ Periodic S ∧ originalUpperDensity S = kappa a b c) ∧
    (∀ S : Set ℤ, Avoids a b c S → ∀ u v : ℤ, u<v →
      (physicalCount S u (v-u).toNat : ℝ) ≤
      kappa a b c*((v-u:ℤ):ℝ)+
      kappa a b c*((b:ℝ)+c-(Nat.gcd (Nat.gcd a b) c:ℝ))) :=
  ⟨arbitrary_triple_mu_eq_kappa a b c ha hab hbc,
    arbitrary_triple_periodic_attainment a b c ha hab hbc,
    arbitrary_triple_interval_bound a b c ha hab hbc⟩

#print axioms arbitrary_triple_mu_eq_kappa
#print axioms arbitrary_triple_complete
end
end Haralambis.ArbitraryTriples

import Definitions
namespace Haralambis.ArbitraryTriples

def tripleGcd (a b c : ℕ) := Nat.gcd (Nat.gcd a b) c

theorem gcd_parameters (a b c : ℕ) (ha : 0<a) (hab : a<b) (hbc : b<c) :
    let g := tripleGcd a b c;
    0<g ∧ g*(a/g)=a ∧ g*(b/g)=b ∧ g*(c/g)=c ∧
    0<a/g ∧ a/g<b/g ∧ b/g<c/g ∧ primitive (a/g) (b/g) (c/g) := by
  dsimp [tripleGcd]
  let g := Nat.gcd (Nat.gcd a b) c
  have hga : g ∣ a := dvd_trans (Nat.gcd_dvd_left _ _) (Nat.gcd_dvd_left _ _)
  have hgb : g ∣ b := dvd_trans (Nat.gcd_dvd_left _ _) (Nat.gcd_dvd_right _ _)
  have hgc : g ∣ c := Nat.gcd_dvd_right _ _
  have hg : 0<g := by
    by_contra h
    have he : g=0 := by omega
    rw [he] at hga
    simp at hga
    omega
  have ea : g*(a/g)=a := Nat.mul_div_cancel' hga
  have eb : g*(b/g)=b := Nat.mul_div_cancel' hgb
  have ec : g*(c/g)=c := Nat.mul_div_cancel' hgc
  have hp : primitive (a/g) (b/g) (c/g) := by
    unfold primitive
    have he : g * Nat.gcd (Nat.gcd (a/g) (b/g)) (c/g) = g := by
      rw [←Nat.gcd_mul_left, ←Nat.gcd_mul_left, ea,eb,ec]
    nlinarith
  exact ⟨hg,ea,eb,ec,by nlinarith,by nlinarith,by nlinarith,hp⟩
#print axioms gcd_parameters
end Haralambis.ArbitraryTriples

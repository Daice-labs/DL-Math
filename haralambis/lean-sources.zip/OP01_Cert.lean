import EREF_Pol
set_option maxRecDepth 100000

/-!
# OP-01 fixed D = {1,10,18}: the 41-step local cutting-planes derivation, kernel-checked in core Lean

Handoff obligation F1 ("kernel-checked local CP interpreter: implement only the rules used here,
prove its soundness once, instantiate with CertificateData, prove the finite check succeeds").

The rows are `EREF.Row` (the ER/EF stages 1–4 row algebra: exact `algebra.py` normalization,
`add`, `multiply`, `divide` with mathematical ceiling) and the rules are run by the POL stack
machine `EREF.polEval`, whose soundness `polEval_sound` is already a theorem.  The handoff's
`CertificateData.lean` (SHA-256 8c39b788…cd2c; `steps` block SHA dfcdc933…5f64) is translated
mechanically (`translate_cert.py`):
  variable v (0-based)  ↦  literal (v+1 : Int);  complement  ↦  −(v+1)
  row ids: inputs 1..61 ↦ database index id−1;  derived 63..103 ↦ id−2  (row 62 is absent)
  nonnegative        ↦ a sum of literal axioms with the expected coefficients (bound 0)
  edgeWeakening r    ↦ ref(edge r) plus literal axioms for the coefficient differences (bound 1)
  polynomial         ↦ ref/add as given; `scalar v, multiply` ↦ `mul v`; `scalar v, divideCeil` ↦ `div v`
A step is accepted iff the machine's result has exactly the expected (canonical) terms and a bound
at least the expected bound.  Nothing external is trusted: `check_ok` is decided by the kernel.
-/

namespace OP01.Cert
open EREF

/-- the edge row (1−x_i) + (1−x_j) ≥ 1 for the window pair (i, j), 0-based variables -/
def edgeRow (e : Nat × Nat) : Row :=
  normalize [(1, -((e.1 : Int) + 1)), (1, -((e.2 : Int) + 1))] 1

/-- the 61 window edges (0 ≤ i < j < 30, j − i ∈ {1, 10, 18}), in the handoff's order -/
def handoffEdges : List (Nat × Nat) := [(0, 1), (0, 10), (0, 18), (1, 2), (1, 11), (1, 19), (2, 3), (2, 12), (2, 20), (3, 4), (3, 13), (3, 21), (4, 5), (4, 14), (4, 22), (5, 6), (5, 15), (5, 23), (6, 7), (6, 16), (6, 24), (7, 8), (7, 17), (7, 25), (8, 9), (8, 18), (8, 26), (9, 10), (9, 19), (9, 27), (10, 11), (10, 20), (10, 28), (11, 12), (11, 21), (11, 29), (12, 13), (12, 22), (13, 14), (13, 23), (14, 15), (14, 24), (15, 16), (15, 25), (16, 17), (16, 26), (17, 18), (17, 27), (18, 19), (18, 28), (19, 20), (19, 29), (20, 21), (21, 22), (22, 23), (23, 24), (24, 25), (25, 26), (26, 27), (27, 28), (28, 29)]

/-- the 41 derivation steps (handoff ids 63..103), each as a POL program and its expected row -/
def steps : List (List Tok × Row) := [
  -- step id 63 (original id 167)
  ([.ref 58, .lit (-19), .add, .lit (-22), .add],
   ⟨[(1, -19), (1, -22), (1, -27), (1, -28)], 1⟩),
  -- step id 64 (original id 168)
  ([.ref 47, .lit (-22), .add],
   ⟨[(1, -18), (1, -22), (1, -28)], 1⟩),
  -- step id 65 (original id 169)
  ([.ref 58, .lit (-22), .add],
   ⟨[(1, -22), (1, -27), (1, -28)], 1⟩),
  -- step id 66 (original id 170)
  ([.ref 47],
   ⟨[(1, -18), (1, -28)], 1⟩),
  -- step id 67 (original id 171)
  ([.ref 58],
   ⟨[(1, -27), (1, -28)], 1⟩),
  -- step id 68 (original id 172)
  ([.ref 47, .lit (-24), .add],
   ⟨[(1, -18), (1, -24), (1, -28)], 1⟩),
  -- step id 69 (original id 173)
  ([.ref 26],
   ⟨[(1, -9), (1, -27)], 1⟩),
  -- step id 70 (original id 174)
  ([.ref 45, .lit (-19), .add, .lit (-28), .add],
   ⟨[(1, -17), (1, -19), (1, -27), (1, -28)], 1⟩),
  -- step id 71 (original id 175)
  ([.ref 58, .lit (-19), .add],
   ⟨[(1, -19), (1, -27), (1, -28)], 1⟩),
  -- step id 72 (original id 176)
  ([.ref 26, .lit (-26), .add],
   ⟨[(1, -9), (1, -26), (1, -27)], 1⟩),
  -- step id 73 (original id 177)
  ([.ref 23, .lit (-28), .add],
   ⟨[(1, -8), (1, -26), (1, -28)], 1⟩),
  -- step id 74 (original id 178)
  ([.ref 23],
   ⟨[(1, -8), (1, -26)], 1⟩),
  -- step id 75 (original id 179)
  ([.ref 43, .lit (-27), .add],
   ⟨[(1, -16), (1, -26), (1, -27)], 1⟩),
  -- step id 76 (original id 180)
  ([.ref 57, .lit (-24), .add],
   ⟨[(1, -24), (1, -26), (1, -27)], 1⟩),
  -- step id 77 (original id 181)
  ([.ref 41],
   ⟨[(1, -15), (1, -25)], 1⟩),
  -- step id 78 (original id 182)
  ([.ref 55],
   ⟨[(1, -24), (1, -25)], 1⟩),
  -- step id 79 (original id 183)
  ([.ref 60],
   ⟨[(1, -29), (1, -30)], 1⟩),
  -- step id 80 (original id 184)
  ([.ref 22, .lit (-27), .add],
   ⟨[(1, -8), (1, -18), (1, -27)], 1⟩),
  -- step id 81 (original id 185)
  ([.ref 45],
   ⟨[(1, -17), (1, -27)], 1⟩),
  -- step id 82 (original id 186)
  ([.ref 57],
   ⟨[(1, -26), (1, -27)], 1⟩),
  -- step id 83 (original id 187)
  ([.ref 77, .ref 28, .add],
   ⟨[(1, -10), (1, -20), (1, -29), (1, -30)], 2⟩),
  -- step id 84 (original id 188)
  ([.ref 59],
   ⟨[(1, -28), (1, -29)], 1⟩),
  -- step id 85 (original id 189)
  ([.ref 82, .ref 51, .add],
   ⟨[(1, -20), (1, -28), (1, -29), (1, -30)], 2⟩),
  -- step id 86 (original id 190)
  ([.ref 44],
   ⟨[(1, -17), (1, -18)], 1⟩),
  -- step id 87 (original id 191)
  ([.ref 60, .lit (-25), .add],
   ⟨[(1, -25), (1, -29), (1, -30)], 1⟩),
  -- step id 88 (original id 192)
  ([.ref 81, .ref 26, .add, .ref 47, .add, .ref 43, .add],
   ⟨[(1, -9), (1, -10), (1, -16), (1, -18), (1, -20), (1, -26), (1, -27), (1, -28), (1, -29), (1, -30)], 5⟩),
  -- step id 89 (original id 193)
  ([.ref 51, .lit (-29), .add],
   ⟨[(1, -20), (1, -29), (1, -30)], 1⟩),
  -- step id 90 (original id 194)
  ([.ref 86, .ref 20, .add, .mul 3, .ref 82, .ref 56, .add, .ref 51, .add, .ref 24, .add, .add, .ref 19, .add, .ref 42, .add, .ref 44, .add, .ref 45, .add, .div 4, .ref 34, .add, .ref 39, .add, .ref 14, .add, .mul 3, .ref 87, .ref 24, .add, .ref 57, .add, .ref 34, .add, .ref 54, .add, .ref 47, .add, .ref 19, .add, .add, .ref 13, .add, .ref 38, .add, .ref 40, .add, .ref 41, .add, .div 4, .ref 8, .add, .mul 3, .ref 86, .ref 19, .add, .ref 55, .add, .ref 52, .add, .ref 13, .add, .add, .ref 7, .add, .ref 33, .add, .ref 36, .add, .ref 37, .add, .div 4, .mul 3, .ref 85, .ref 28, .add, .ref 58, .add, .ref 34, .add, .ref 42, .add, .ref 39, .add, .ref 14, .add, .mul 3, .ref 83, .ref 77, .add, .ref 28, .add, .ref 29, .add, .div 2, .ref 34, .add, .ref 54, .add, .ref 45, .add, .add, .ref 13, .add, .ref 38, .add, .ref 40, .add, .ref 41, .add, .div 4, .ref 8, .add, .mul 3, .ref 81, .ref 58, .add, .ref 55, .add, .ref 52, .add, .ref 42, .add, .ref 13, .add, .add, .ref 7, .add, .ref 33, .add, .ref 36, .add, .ref 37, .add, .div 4, .add, .ref 18, .add, .ref 21, .add, .ref 22, .add, .ref 23, .add, .div 4, .mul 3, .ref 84, .ref 26, .add, .ref 79, .add, .ref 21, .add, .ref 22, .add, .div 2, .ref 59, .add, .ref 56, .add, .ref 28, .add, .ref 35, .add, .ref 53, .add, .ref 38, .add, .ref 8, .add, .mul 3, .ref 83, .ref 24, .add, .ref 23, .add, .ref 44, .add, .mul 3, .ref 81, .ref 22, .add, .add, .ref 26, .add, .ref 45, .add, .ref 57, .add, .ref 58, .add, .div 4, .ref 52, .add, .ref 41, .add, .add, .ref 7, .add, .ref 33, .add, .ref 36, .add, .ref 37, .add, .div 4, .add, .ref 12, .add, .ref 15, .add, .ref 16, .add, .ref 17, .add, .div 4, .mul 3, .ref 80, .ref 44, .add, .ref 79, .add, .ref 22, .add, .ref 23, .add, .div 2, .ref 24, .add, .ref 59, .add, .ref 35, .add, .ref 37, .add, .ref 41, .add, .ref 17, .add, .mul 3, .ref 78, .ref 24, .add, .ref 59, .add, .ref 35, .add, .ref 37, .add, .ref 55, .add, .add, .ref 16, .add, .ref 40, .add, .ref 42, .add, .ref 43, .add, .div 4, .mul 3, .ref 77, .ref 57, .add, .ref 33, .add, .ref 54, .add, .ref 24, .add, .ref 47, .add, .ref 40, .add, .add, .ref 15, .add, .ref 18, .add, .ref 19, .add, .ref 20, .add, .div 4, .ref 50, .add, .add, .ref 6, .add, .ref 9, .add, .ref 10, .add, .ref 11, .add, .div 4, .ref 0, .add, .mul 4, .ref 76, .ref 40, .add, .ref 75, .add, .ref 16, .add, .ref 17, .add, .div 2, .ref 45, .add, .ref 23, .add, .mul 3, .ref 74, .ref 40, .add, .add, .ref 15, .add, .ref 18, .add, .ref 19, .add, .ref 20, .add, .div 4, .ref 37, .add, .ref 10, .add, .mul 3, .ref 73, .ref 18, .add, .mul 2, .ref 72, .add, .ref 19, .add, .ref 42, .add, .ref 45, .add, .div 3, .ref 55, .add, .ref 36, .add, .add, .ref 9, .add, .ref 12, .add, .ref 13, .add, .ref 14, .add, .div 4, .ref 52, .add, .ref 3, .add, .ref 35, .add, .ref 29, .add, .add, .ref 2, .add, .ref 25, .add, .ref 46, .add, .ref 48, .add, .ref 49, .add, .div 5, .mul 4, .ref 71, .ref 25, .add, .ref 45, .add, .mul 3, .ref 70, .add, .ref 22, .add, .ref 44, .add, .ref 46, .add, .ref 47, .add, .div 4, .ref 41, .add, .ref 17, .add, .mul 3, .ref 69, .ref 22, .add, .mul 2, .ref 64, .add, .ref 21, .add, .ref 25, .add, .ref 26, .add, .div 3, .ref 55, .add, .add, .ref 16, .add, .ref 40, .add, .ref 42, .add, .ref 43, .add, .div 4, .ref 37, .add, .ref 11, .add, .mul 3, .ref 68, .ref 21, .add, .mul 3, .ref 67, .add, .ref 22, .add, .ref 44, .add, .ref 46, .add, .ref 47, .add, .div 4, .ref 56, .add, .ref 53, .add, .ref 16, .add, .add, .ref 10, .add, .ref 36, .add, .ref 38, .add, .ref 39, .add, .div 4, .mul 3, .ref 66, .ref 25, .add, .ref 57, .add, .ref 40, .add, .ref 37, .add, .ref 11, .add, .mul 3, .ref 65, .ref 46, .add, .ref 64, .add, .ref 25, .add, .ref 26, .add, .div 2, .ref 53, .add, .ref 43, .add, .add, .ref 10, .add, .ref 36, .add, .ref 38, .add, .ref 39, .add, .div 4, .add, .ref 15, .add, .ref 18, .add, .ref 19, .add, .ref 20, .add, .div 4, .mul 3, .ref 63, .ref 46, .add, .ref 62, .add, .ref 25, .add, .ref 26, .add, .div 2, .ref 43, .add, .ref 19, .add, .mul 3, .ref 61, .ref 42, .add, .add, .ref 18, .add, .ref 21, .add, .ref 22, .add, .ref 23, .add, .div 4, .ref 55, .add, .ref 36, .add, .add, .ref 9, .add, .ref 12, .add, .ref 13, .add, .ref 14, .add, .div 4, .ref 3, .add, .ref 51, .add, .add, .ref 1, .add, .ref 27, .add, .ref 30, .add, .ref 31, .add, .ref 32, .add, .div 5],
   ⟨[(1, -1), (1, -2), (1, -3), (1, -4), (1, -5), (1, -6), (1, -7), (1, -8), (1, -9), (1, -10), (1, -11), (1, -12), (1, -13), (1, -14), (1, -15), (1, -16), (1, -17), (1, -18), (1, -19), (1, -20), (1, -21), (1, -22), (1, -23), (1, -24), (1, -25), (1, -26), (1, -27), (1, -28), (1, -29), (1, -30)], 19⟩),
  -- step id 91 (original id 195)
  ([.ref 47, .lit (-24), .add, .lit (-26), .add],
   ⟨[(1, -18), (1, -24), (1, -26), (1, -28)], 1⟩),
  -- step id 92 (original id 196)
  ([.ref 22],
   ⟨[(1, -8), (1, -18)], 1⟩),
  -- step id 93 (original id 197)
  ([.ref 44, .lit (-26), .add, .lit (-28), .add],
   ⟨[(1, -17), (1, -18), (1, -26), (1, -28)], 1⟩),
  -- step id 94 (original id 198)
  ([.ref 45, .lit (-28), .add],
   ⟨[(1, -17), (1, -27), (1, -28)], 1⟩),
  -- step id 95 (original id 199)
  ([.ref 58, .lit (-25), .add],
   ⟨[(1, -25), (1, -27), (1, -28)], 1⟩),
  -- step id 96 (original id 200)
  ([.ref 43],
   ⟨[(1, -16), (1, -26)], 1⟩),
  -- step id 97 (original id 201)
  ([.ref 56],
   ⟨[(1, -25), (1, -26)], 1⟩),
  -- step id 98 (original id 202)
  ([.lit (-20)],
   ⟨[(1, -20)], 0⟩),
  -- step id 99 (original id 203)
  ([.lit (1), .lit (10), .add, .lit (12), .add, .lit (21), .add, .lit (29), .add],
   ⟨[(1, 1), (1, 10), (1, 12), (1, 21), (1, 29)], 0⟩),
  -- step id 100 (original id 204)
  ([.lit (-11), .lit (-20), .add],
   ⟨[(1, -11), (1, -20)], 0⟩),
  -- step id 101 (original id 205)
  ([.lit (3), .mul 2, .lit (11), .mul 2, .add, .lit (20), .mul 2, .add, .lit (22), .mul 2, .add],
   ⟨[(2, 3), (2, 11), (2, 20), (2, 22)], 0⟩),
  -- step id 102 (original id 206)
  ([.lit (9), .mul 2, .lit (11), .mul 2, .add, .lit (20), .mul 2, .add, .lit (-21), .add, .lit (28), .mul 2, .add],
   ⟨[(2, 9), (2, 11), (2, 20), (1, -21), (2, 28)], 0⟩),
  -- step id 103 (original id 207)
  ([.ref 88, .ref 96, .add, .mul 4, .ref 88, .ref 97, .add, .mul 2, .ref 95, .ref 42, .add, .ref 94, .add, .ref 19, .add, .ref 20, .add, .div 2, .ref 47, .add, .ref 26, .add, .mul 3, .ref 93, .ref 42, .add, .add, .ref 18, .add, .ref 21, .add, .ref 22, .add, .ref 23, .add, .div 4, .ref 39, .add, .ref 13, .add, .mul 3, .ref 92, .ref 21, .add, .mul 2, .ref 67, .add, .ref 22, .add, .ref 44, .add, .ref 47, .add, .div 3, .ref 56, .add, .ref 38, .add, .add, .ref 12, .add, .ref 15, .add, .ref 16, .add, .ref 17, .add, .div 4, .ref 53, .add, .ref 7, .add, .mul 3, .ref 91, .ref 21, .add, .mul 3, .ref 90, .add, .ref 26, .add, .ref 45, .add, .ref 57, .add, .ref 58, .add, .div 4, .ref 41, .add, .ref 17, .add, .mul 3, .ref 64, .ref 26, .add, .ref 65, .add, .ref 21, .add, .ref 22, .add, .div 2, .ref 55, .add, .add, .ref 16, .add, .ref 40, .add, .ref 42, .add, .ref 43, .add, .div 4, .mul 3, .ref 89, .ref 40, .add, .ref 26, .add, .add, .ref 15, .add, .ref 18, .add, .ref 19, .add, .ref 20, .add, .div 4, .ref 37, .add, .add, .ref 6, .add, .ref 9, .add, .ref 10, .add, .ref 11, .add, .div 4, .ref 98, .add, .add, .ref 5, .add, .ref 48, .add, .ref 51, .add, .div 3, .add, .ref 1, .add, .ref 27, .add, .ref 30, .add, .ref 31, .add, .ref 32, .add, .div 5, .mul 22, .ref 88, .mul 2, .ref 99, .add, .add, .ref 8, .mul 2, .add, .ref 31, .mul 4, .add, .ref 50, .mul 4, .add, .ref 52, .mul 2, .add, .div 12, .mul 11, .ref 88, .mul 2, .ref 100, .add, .add, .ref 24, .mul 2, .add, .ref 27, .mul 4, .add, .ref 28, .mul 4, .add, .ref 29, .mul 2, .add, .div 12],
   ⟨[(2, -1), (2, -2), (2, -3), (2, -4), (2, -5), (2, -6), (2, -7), (2, -8), (2, -9), (3, -10), (4, -11), (2, -12), (2, -13), (2, -14), (2, -15), (2, -16), (2, -17), (2, -18), (2, -19), (4, -20), (3, -21), (2, -22), (2, -23), (2, -24), (2, -25), (2, -26), (2, -27), (2, -28), (2, -29), (2, -30)], 42⟩)
]

/-- the 61 input rows -/
def edges : List Row := handoffEdges.map edgeRow

/-- the target row: Σ_j w_j (1 − x_j) ≥ 42, i.e. row id 103 -/
def target : Row := ⟨[(2, -1), (2, -2), (2, -3), (2, -4), (2, -5), (2, -6), (2, -7), (2, -8), (2, -9), (3, -10), (4, -11), (2, -12), (2, -13), (2, -14), (2, -15), (2, -16), (2, -17), (2, -18), (2, -19), (4, -20), (3, -21), (2, -22), (2, -23), (2, -24), (2, -25), (2, -26), (2, -27), (2, -28), (2, -29), (2, -30)], 42⟩

theorem target_is_last : steps[40].2 = target := rfl

def dbOf (db : List Row) : Nat → Option Row := fun i => db[i]?

/-- run the steps in order; each accepted step joins the database -/
def checkFrom (db : List Row) : List (List Tok × Row) → Bool
  | [] => true
  | (toks, exp) :: rest =>
    match polEval (dbOf db) toks [] with
    | some out => decide (out.terms = exp.terms) && decide (exp.bound ≤ out.bound) && checkFrom (db ++ [exp]) rest
    | none => false

/-- **the finite check, decided by the kernel** -/
theorem check_ok : checkFrom edges steps = true := by decide +kernel

theorem dbOf_good (db : List Row) (α : Val) (h : ∀ R ∈ db, Canonical R ∧ R.sat α) :
    GoodDb (dbOf db) α := by
  intro i R hR
  exact h R (List.mem_of_getElem? hR)

/-- **checker soundness**: every accepted step's expected row is canonical and holds under any
assignment under which the initial database holds -/
theorem checkFrom_sound (α : Val) : ∀ (ss : List (List Tok × Row)) (db : List Row),
    checkFrom db ss = true → (∀ R ∈ db, Canonical R ∧ R.sat α) →
    ∀ s ∈ ss, Canonical s.2 ∧ s.2.sat α := by
  intro ss
  induction ss with
  | nil => intro db _ _ s hs; simp at hs
  | cons s rest ih =>
    intro db hchk hdb s' hs'
    obtain ⟨toks, exp⟩ := s
    simp only [checkFrom] at hchk
    split at hchk
    · rename_i out hout
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hchk
      obtain ⟨⟨hterms, hbound⟩, hrest⟩ := hchk
      have hgood := polEval_sound (dbOf db) α (dbOf_good db α hdb) toks [] (by simp) out hout
      have hexp : Canonical exp ∧ exp.sat α := by
        constructor
        · unfold Canonical at *; rw [← hterms]; exact hgood.1
        · unfold Row.sat Row.val at *; rw [← hterms]; have := hgood.2; omega
      rcases List.mem_cons.mp hs' with h | h
      · subst h; exact hexp
      · refine ih (db ++ [exp]) hrest ?_ s' h
        intro R hR
        rcases List.mem_append.mp hR with h1 | h1
        · exact hdb R h1
        · simp at h1; subst h1; exact hexp
    · cases hchk

theorem edges_canonical : ∀ R ∈ edges, Canonical R := by
  intro R hR
  unfold edges at hR
  obtain ⟨e, _, rfl⟩ := List.mem_map.mp hR
  exact canonical_normalize _ _

/-- the edge row holds iff the two variables are not both true (variables are 1-based in `α`) -/
theorem edgeRow_sat_iff (e : Nat × Nat) (α : Val) :
    (edgeRow e).sat α ↔ ¬ (α (e.1 + 1) = true ∧ α (e.2 + 1) = true) := by
  unfold edgeRow Row.sat
  rw [val_normalize]
  · have h1 : litVal α (-((e.1 : Int) + 1)) = 1 - b2i (α (e.1 + 1)) := by
      rw [litVal_neg _ _ (by omega)]
      simp only [litVal]
      rw [if_pos (by omega)]
      congr 2
    have h2 : litVal α (-((e.2 : Int) + 1)) = 1 - b2i (α (e.2 + 1)) := by
      rw [litVal_neg _ _ (by omega)]
      simp only [litVal]
      rw [if_pos (by omega)]
      congr 2
    simp only [tvalZ, h1, h2]
    cases α (e.1 + 1) <;> cases α (e.2 + 1) <;> simp [b2i]
  · intro t ht
    simp only [List.mem_cons] at ht
    rcases ht with rfl | rfl | h
    · simp; omega
    · simp; omega
    · simp at h

/-- **the local lemma in row form**: under any assignment satisfying the 61 edge rows, the target
row Σ_j w_j (1 − x_j) ≥ 42 holds -/
theorem target_sat (α : Val) (hE : ∀ R ∈ edges, R.sat α) : target.sat α := by
  have hmem : steps[40] ∈ steps := List.getElem_mem (by decide)
  have := checkFrom_sound α steps edges check_ok
    (fun R hR => ⟨edges_canonical R hR, hE R hR⟩) steps[40] hmem
  rw [target_is_last] at this
  exact this.2

end OP01.Cert

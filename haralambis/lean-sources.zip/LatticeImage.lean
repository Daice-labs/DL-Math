import Mathlib.Data.Int.GCD
import Mathlib.Tactic

/-!
The primitive integer image and odd coset for the pair-sum lattice.
The coordinates are ordered (ab, ac, bc), with exactly the signs of the
accepted arbitrary-triple paper. No pairwise coprimality is assumed.
-/
namespace Haralambis.Arithmetic

/-- The three pair-sum relation coordinates of an integer triple. -/
def tripleImage (a b c ha hb hc : ℤ) : ℤ × ℤ × ℤ :=
  (b * ha - a * hb, c * ha - a * hc, c * hb - b * hc)

/-- The integral relation lattice. -/
def InRelationLattice (a b c x y z : ℤ) : Prop :=
  c * x - b * y + a * z = 0

/-- The affine parity coset used by the local counting theorem. -/
def InParityLattice (a b c x y z : ℤ) : Prop :=
  InRelationLattice a b c x y z ∧
  x % 2 = (a + b) % 2 ∧ y % 2 = (a + c) % 2 ∧ z % 2 = (b + c) % 2

/-- An explicit inverse from any three-term Bézout certificate. -/
theorem explicit_integer_inverse (a b c x y z u v w : ℤ)
    (hbez : a * u + b * v + c * w = 1)
    (hrel : InRelationLattice a b c x y z) :
    tripleImage a b c (v * x + w * y) (w * z - u * x) (-u * y - v * z) =
      (x, y, z) := by
  unfold InRelationLattice at hrel
  unfold tripleImage
  apply Prod.ext
  · dsimp
    linear_combination x * hbez - w * hrel
  · apply Prod.ext
    · dsimp
      linear_combination y * hbez + v * hrel
    · dsimp
      linear_combination z * hbez - u * hrel

/-- The primitive gcd hypothesis itself supplies the inverse's certificate. -/
theorem primitive_bezout (a b c : ℤ)
    (hprimitive : Int.gcd (Int.gcd a b : ℤ) c = 1) :
    ∃ u v w : ℤ, a * u + b * v + c * w = 1 := by
  have hab := Int.gcd_eq_gcd_ab a b
  have habc := Int.gcd_eq_gcd_ab (Int.gcd a b : ℤ) c
  rw [hprimitive] at habc
  refine ⟨Int.gcdA a b * Int.gcdA (Int.gcd a b : ℤ) c,
    Int.gcdB a b * Int.gcdA (Int.gcd a b : ℤ) c,
    Int.gcdB (Int.gcd a b : ℤ) c, ?_⟩
  push_cast at habc
  linear_combination -habc - Int.gcdA (Int.gcd a b : ℤ) c * hab

/-- Every primitive relation class, and only such a class, is an integer image. -/
theorem primitive_integer_image_iff (a b c x y z : ℤ)
    (hprimitive : Int.gcd (Int.gcd a b : ℤ) c = 1) :
    InRelationLattice a b c x y z ↔
      ∃ ha hb hc : ℤ, tripleImage a b c ha hb hc = (x, y, z) := by
  constructor
  · intro hrel
    obtain ⟨u, v, w, hbez⟩ := primitive_bezout a b c hprimitive
    exact ⟨v * x + w * y, w * z - u * x, -u * y - v * z,
      explicit_integer_inverse a b c x y z u v w hbez hrel⟩
  · rintro ⟨ha, hb, hc, h⟩
    have hx := congrArg Prod.fst h
    have hy := congrArg (fun p : ℤ × ℤ × ℤ => p.2.1) h
    have hz := congrArg (fun p : ℤ × ℤ × ℤ => p.2.2) h
    dsimp [tripleImage] at hx hy hz
    unfold InRelationLattice
    rw [← hx, ← hy, ← hz]
    ring

/-- Taking half after subtracting the all-ones image preserves the relation. -/
theorem parity_half (a b c x y z : ℤ)
    (h : InParityLattice a b c x y z) :
    ∃ p q r : ℤ, InRelationLattice a b c p q r ∧
      x = b - a + 2 * p ∧ y = c - a + 2 * q ∧ z = c - b + 2 * r := by
  obtain ⟨hrel, hx, hy, hz⟩ := h
  let p := (x - (b - a)) / 2
  let q := (y - (c - a)) / 2
  let r := (z - (c - b)) / 2
  have hp : x = b - a + 2 * p := by dsimp [p]; omega
  have hq : y = c - a + 2 * q := by dsimp [q]; omega
  have hr : z = c - b + 2 * r := by dsimp [r]; omega
  refine ⟨p, q, r, ?_, hp, hq, hr⟩
  unfold InRelationLattice at *
  rw [hp, hq, hr] at hrel
  nlinarith [hrel]

/-- Exact equality of the primitive parity lattice and images of odd triples. -/
theorem primitive_odd_image_iff (a b c x y z : ℤ)
    (hprimitive : Int.gcd (Int.gcd a b : ℤ) c = 1) :
    InParityLattice a b c x y z ↔
      ∃ ha hb hc : ℤ, Odd ha ∧ Odd hb ∧ Odd hc ∧
        tripleImage a b c ha hb hc = (x, y, z) := by
  constructor
  · intro h
    obtain ⟨p, q, r, hrel, hx, hy, hz⟩ := parity_half a b c x y z h
    obtain ⟨ka, kb, kc, hk⟩ :=
      (primitive_integer_image_iff a b c p q r hprimitive).mp hrel
    have hp := congrArg Prod.fst hk
    have hq := congrArg (fun p : ℤ × ℤ × ℤ => p.2.1) hk
    have hr := congrArg (fun p : ℤ × ℤ × ℤ => p.2.2) hk
    dsimp [tripleImage] at hp hq hr
    refine ⟨2 * ka + 1, 2 * kb + 1, 2 * kc + 1,
      ⟨ka, rfl⟩, ⟨kb, rfl⟩, ⟨kc, rfl⟩, ?_⟩
    unfold tripleImage
    apply Prod.ext
    · dsimp; linear_combination 2 * hp - hx
    · apply Prod.ext
      · dsimp; linear_combination 2 * hq - hy
      · dsimp; linear_combination 2 * hr - hz
  · rintro ⟨ha, hb, hc, ⟨ka, ha⟩, ⟨kb, hb⟩, ⟨kc, hc⟩, h⟩
    have hx := congrArg Prod.fst h
    have hy := congrArg (fun p : ℤ × ℤ × ℤ => p.2.1) h
    have hz := congrArg (fun p : ℤ × ℤ × ℤ => p.2.2) h
    dsimp [tripleImage] at hx hy hz
    refine ⟨(primitive_integer_image_iff a b c x y z hprimitive).mpr
      ⟨_, _, _, h⟩, ?_, ?_, ?_⟩
    · have heq : x = b - a + 2 * (b * ka - a * kb) := by
        rw [← hx, ha, hb]; ring
      omega
    · have heq : y = c - a + 2 * (c * ka - a * kc) := by
        rw [← hy, ha, hc]; ring
      omega
    · have heq : z = c - b + 2 * (c * kb - b * kc) := by
        rw [← hz, hb, hc]; ring
      omega

/-- Source-level version for natural distance triples. Positivity and ordering
are unnecessary for this arithmetic lemma. -/
theorem primitive_nat_odd_image_iff (a b c : ℕ) (x y z : ℤ)
    (hprimitive : Nat.gcd (Nat.gcd a b) c = 1) :
    InParityLattice a b c x y z ↔
      ∃ ha hb hc : ℤ, Odd ha ∧ Odd hb ∧ Odd hc ∧
        tripleImage a b c ha hb hc = (x, y, z) := by
  apply primitive_odd_image_iff
  simpa using hprimitive

end Haralambis.Arithmetic

#print axioms Haralambis.Arithmetic.primitive_integer_image_iff
#print axioms Haralambis.Arithmetic.primitive_odd_image_iff

#print axioms Haralambis.Arithmetic.primitive_nat_odd_image_iff

import PrefixSharp
import DensityAssembly
import GCDAssembly
import GCDParameters
namespace Haralambis.ArbitraryTriples
noncomputable section
open OP01.Fixed411 Haralambis.Capacity Haralambis.Composition

theorem primitive_sequence_interval (a b c : ℕ) (ha : 1≤a) (hab : a<b) (hbc : b<c)
    (hp : primitive a b c) (x : ℤ → ℕ) (hx : avoids a b c x) (w : ℤ) (N : ℕ) :
    (intervalCount x w N : ℝ) ≤ kappa a b c*N+kappa a b c*(b+c-1:ℕ) := by
  have hk : 0≤kappa a b c := by
    rw [primitive_kappa_eq_kappaStar a b c (by omega) (by omega) (by omega) hp]
    exact kappaStar_nonneg a b c (by omega) (by omega) (by omega)
  apply greedy_interval x (kappa a b c) hk (b+c) (by omega) _ N w
  intro t
  have hs : Avoids a b c {z | x z = 1} := by
    apply (avoids_membership_iff a b c _).mp
    rw [membership_of_bits x hx.1]
    exact hx
  obtain ⟨L,hL,hcount⟩ := primitive_three_prefix a b c ha hab hbc hp _ hs t
  refine ⟨L, by rcases hL with rfl|rfl|rfl <;> omega,
    by rcases hL with rfl|rfl|rfl <;> omega, ?_⟩
  simpa [physicalCount_eq, membership_of_bits x hx.1] using hcount

theorem arbitrary_sequence_interval (a b c : ℕ) (ha : 1≤a) (hab : a<b) (hbc : b<c)
    (x : ℤ → ℕ) (hx : avoids a b c x) (w : ℤ) (N : ℕ) :
    (intervalCount x w N : ℝ) ≤ kappa a b c*N+
      kappa a b c*((b:ℝ)+c-(tripleGcd a b c:ℝ)) := by
  let g := tripleGcd a b c
  obtain ⟨hg,ea,eb,ec,ha',hab',hbc',hp⟩ := gcd_parameters a b c (by omega) hab hbc
  change 0<g at hg
  change g*(a/g)=a at ea
  change g*(b/g)=b at eb
  change g*(c/g)=c at ec
  change 0<a/g at ha'
  change a/g<b/g at hab'
  change b/g<c/g at hbc'
  change primitive (a/g) (b/g) (c/g) at hp
  have hs : avoids (g*(a/g)) (g*(b/g)) (g*(c/g)) x := by simpa [ea,eb,ec] using hx
  have h := interval_scale (a/g) (b/g) (c/g) g hg (by omega)
    (fun y hy t n => primitive_sequence_interval _ _ _ (by omega) hab' hbc' hp y hy t n)
    x hs w N
  simpa only [ea,eb,ec,Int.cast_sub,Int.cast_add,Int.cast_natCast] using h

theorem arbitrary_triple_interval_bound
    (a b c : ℕ) (ha : 1≤a) (hab : a<b) (hbc : b<c)
    (S : Set ℤ) (hS : Avoids a b c S) (u v : ℤ) (huv : u<v) :
    (physicalCount S u (v-u).toNat : ℝ) ≤
      kappa a b c*((v-u:ℤ):ℝ)+kappa a b c*((b:ℝ)+c-(Nat.gcd (Nat.gcd a b) c:ℝ)) := by
  have h := arbitrary_sequence_interval a b c ha hab hbc (membership S)
    ((avoids_membership_iff a b c S).mpr hS) u (v-u).toNat
  rw [physicalCount_eq]
  have he : ((v-u).toNat:ℝ)=((v-u:ℤ):ℝ) := by
    rw [←Int.cast_natCast, Int.toNat_of_nonneg (by omega)]
  simpa [he,tripleGcd] using h

#print axioms arbitrary_triple_interval_bound
end
end Haralambis.ArbitraryTriples

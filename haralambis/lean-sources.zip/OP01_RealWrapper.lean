/-
Exact real-valued wrapper for the unchanged original StatementSpec.lean.
Compiled in the pinned native Lean 4.30.0 / Mathlib environment; actual build
and axiom evidence are retained separately. No reflection route is imported.
-/
import StatementSpec
import OP01_Density

namespace OP01.Fixed411.RealWrapper
noncomputable section
open scoped BigOperators
open OP01.Fixed411

/-- The original Nat-valued bit sequence, viewed as a Boolean sequence. -/
def toBool (x : ℤ → ℕ) : ℤ → Bool := fun z => decide (x z = 1)

def toNat (x : ℤ → Bool) : ℤ → ℕ := fun z => if x z then 1 else 0

theorem toBool_value (x : ℤ → ℕ) (hx : bitValid x) (z : ℤ) :
    EREF.b2i (toBool x z) = (x z : ℤ) := by
  have hz := hx z
  by_cases h : x z = 1
  · simp [toBool, EREF.b2i, h]
  · have h0 : x z = 0 := by omega
    simp [toBool, EREF.b2i, h0]

theorem toNat_toBool (x : ℤ → ℕ) (hx : bitValid x) : toNat (toBool x) = x := by
  funext z
  have hz := hx z
  by_cases h : x z = 1
  · simp [toNat, toBool, h]
  · have h0 : x z = 0 := by omega
    simp [toNat, toBool, h0]

theorem toBool_toNat (x : ℤ → Bool) : toBool (toNat x) = x := by
  funext z
  cases h : x z <;> simp [toBool, toNat, h]

theorem avoids_iff (x : ℤ → ℕ) (hx : bitValid x) :
    avoids x ↔ OP01.Density.Avoids (toBool x) := by
  constructor
  · intro h z d hd hboth
    have hz : x z = 1 := by simpa [toBool] using hboth.1
    have hzd : x (z+d) = 1 := by simpa [toBool] using hboth.2
    simp only [OP01.Density.D, List.mem_cons, List.not_mem_nil, or_false] at hd
    rcases hd with rfl | rfl | rfl
    · have := (h.2 z).1; omega
    · have := (h.2 z).2.1; omega
    · have := (h.2 z).2.2; omega
  · intro h
    refine ⟨hx, ?_⟩
    intro z
    have hp (d : ℤ) (hd : d ∈ OP01.Density.D) : x z + x (z+d) ≤ 1 := by
      have h1 := hx z
      have h2 := hx (z+d)
      by_contra hn
      have hz : x z = 1 := by omega
      have hzd : x (z+d) = 1 := by omega
      exact h z d hd ⟨by simp [toBool, hz], by simp [toBool, hzd]⟩
    exact ⟨hp 1 (by simp [OP01.Density.D]), hp 10 (by simp [OP01.Density.D]),
      hp 18 (by simp [OP01.Density.D])⟩

theorem fsum_eq_sum (f : ℕ → ℤ) (n : ℕ) :
    OP01.Density.fsum f n = ∑ j ∈ Finset.range n, f j := by
  induction n with
  | zero => simp [OP01.Density.fsum]
  | succ n ih => simp [OP01.Density.fsum, Finset.sum_range_succ, ih]

theorem count_bridge (x : ℤ → ℕ) (hx : bitValid x) (a : ℤ) (n : ℕ) :
    (intervalCount x a n : ℤ) = OP01.Density.count (toBool x) a n := by
  simp only [intervalCount, OP01.Density.count, fsum_eq_sum, Nat.cast_sum]
  apply Finset.sum_congr rfl
  intro j _
  exact (toBool_value x hx (a+j)).symm

theorem intervalCount_le (x : ℤ → ℕ) (hx : bitValid x) (a : ℤ) (n : ℕ) :
    intervalCount x a n ≤ n := by
  calc
    intervalCount x a n ≤ ∑ _j ∈ Finset.range n, (1 : ℕ) := by
      apply Finset.sum_le_sum
      intro j _
      exact hx (a+j)
    _ = n := by simp

theorem real_interval_bound (x : ℤ → ℕ) (hx : avoids x) (a : ℤ) (n : ℕ) :
    11 * (intervalCount x a n : ℝ) ≤ 4 * (n : ℝ) + 319 := by
  have h := OP01.Density.interval_bound (toBool x) ((avoids_iff x hx.1).mp hx) a n
  rw [← count_bridge x hx.1 a n] at h
  exact_mod_cast h

/-- Exactly the set whose real infimum occurs in the original specification. -/
def eventualUpper (x : ℤ → ℕ) : Set ℝ :=
  {r | ∀ ε : ℝ, 0 < ε → ∃ N : ℕ, ∀ n : ℕ, N ≤ n → 0 < n →
    (intervalCount x 0 n : ℝ) / (n : ℝ) ≤ r + ε}

theorem eventualUpper_nonempty (x : ℤ → ℕ) (hx : bitValid x) :
    (eventualUpper x).Nonempty := by
  refine ⟨1, ?_⟩
  intro ε hε
  refine ⟨1, ?_⟩
  intro n _ hn
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hc : (intervalCount x 0 n : ℝ) ≤ (n : ℝ) := by
    exact_mod_cast intervalCount_le x hx 0 n
  have hr : (intervalCount x 0 n : ℝ) / (n : ℝ) ≤ 1 := by
    apply (div_le_iff₀ hnR).mpr
    simpa using hc
  linarith

theorem eventualUpper_bddBelow (x : ℤ → ℕ) : BddBelow (eventualUpper x) := by
  refine ⟨0, ?_⟩
  intro r hr
  by_contra hn
  have hneg : r < 0 := lt_of_not_ge hn
  obtain ⟨N, hN⟩ := hr (-r/2) (by linarith)
  have h := hN (N+1) (by omega) (by omega)
  have hnonneg : (0 : ℝ) ≤ (intervalCount x 0 (N+1) : ℝ) / ((N+1 : ℕ) : ℝ) := by
    positivity
  linarith

theorem fourEleven_mem_eventualUpper (x : ℤ → ℕ) (hx : avoids x) :
    (4 : ℝ)/11 ∈ eventualUpper x := by
  intro ε hε
  obtain ⟨N, hN⟩ := exists_nat_gt ((319 : ℝ)/(11*ε))
  refine ⟨N, ?_⟩
  intro n hNn hn
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hnlarge : (319 : ℝ)/(11*ε) < (n : ℝ) :=
    lt_of_lt_of_le hN (by exact_mod_cast hNn)
  have hbudget : (319 : ℝ) < (n : ℝ)*(11*ε) :=
    (div_lt_iff₀ (by positivity : (0 : ℝ) < 11*ε)).mp hnlarge
  have hc := real_interval_bound x hx 0 n
  apply (div_le_iff₀ hnR).mpr
  nlinarith

theorem upperDensity_le_fourEleven (x : ℤ → ℕ) (hx : avoids x) :
    upperDensity x ≤ (4 : ℝ)/11 := by
  change sInf (eventualUpper x) ≤ _
  exact csInf_le (eventualUpper_bddBelow x) (fourEleven_mem_eventualUpper x hx)

theorem witness_bits : bitValid OP01.Fixed411.witness := by
  intro z
  unfold OP01.Fixed411.witness
  split_ifs <;> omega

theorem witness_bool : toBool OP01.Fixed411.witness = OP01.Density.witness := by
  funext z
  by_cases h : z % 11 = 0 ∨ z % 11 = 2 ∨ z % 11 = 5 ∨ z % 11 = 8
  · simp [toBool, OP01.Fixed411.witness, OP01.Density.witness, h]
  · simp [toBool, OP01.Fixed411.witness, OP01.Density.witness, h]

theorem original_witness_avoids : avoids OP01.Fixed411.witness := by
  apply (avoids_iff _ witness_bits).mpr
  rw [witness_bool]
  exact OP01.Density.witness_avoids

theorem witness_lower_count (a : ℤ) (n : ℕ) :
    4*(n : ℝ)-40 ≤ 11*(intervalCount OP01.Fixed411.witness a n : ℝ) := by
  have h := (OP01.Density.witness_count a n).1
  rw [← witness_bool, ← count_bridge _ witness_bits a n] at h
  exact_mod_cast h

theorem witness_density : upperDensity OP01.Fixed411.witness = (4 : ℝ)/11 := by
  apply le_antisymm (upperDensity_le_fourEleven _ original_witness_avoids)
  change (4 : ℝ)/11 ≤ sInf (eventualUpper OP01.Fixed411.witness)
  apply le_csInf (eventualUpper_nonempty _ witness_bits)
  intro c hc
  by_contra hnot
  have hc_lt : c < (4 : ℝ)/11 := lt_of_not_ge hnot
  let ε : ℝ := ((4 : ℝ)/11-c)/3
  have hε : 0 < ε := by dsimp [ε]; linarith
  obtain ⟨N, hN⟩ := hc ε hε
  obtain ⟨M, hM⟩ := exists_nat_gt ((40 : ℝ)/(11*ε))
  let n : ℕ := N+M+1
  have hn : 0 < n := by dsimp [n]; omega
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hMn : M ≤ n := by dsimp [n]; omega
  have hlarge : (40 : ℝ)/(11*ε) < (n : ℝ) :=
    lt_of_lt_of_le hM (by exact_mod_cast hMn)
  have hbudget : (40 : ℝ) < (n : ℝ)*(11*ε) :=
    (div_lt_iff₀ (by positivity : (0 : ℝ) < 11*ε)).mp hlarge
  have hup := (div_le_iff₀ hnR).mp (hN n (by dsimp [n]; omega) hn)
  have hlo := witness_lower_count 0 n
  have heq : 3*ε = (4 : ℝ)/11-c := by dsimp [ε]; ring
  have heqn := congrArg (fun v : ℝ => v * (n : ℝ)) heq
  nlinarith [mul_pos hε hnR, heqn]

theorem original_lowerWitnessGoal : OP01.Fixed411.lowerWitnessGoal :=
  ⟨original_witness_avoids, witness_density⟩

theorem mu_eq_fourEleven : OP01.Fixed411.mu = (4 : ℝ)/11 := by
  let M : Set ℝ := {r | ∃ x : ℤ → ℕ, avoids x ∧ r = upperDensity x}
  have hm : (4 : ℝ)/11 ∈ M :=
    ⟨OP01.Fixed411.witness, original_witness_avoids, witness_density.symm⟩
  have hb : BddAbove M := by
    refine ⟨(4 : ℝ)/11, ?_⟩
    rintro r ⟨x, hx, rfl⟩
    exact upperDensity_le_fourEleven x hx
  change sSup M = _
  apply le_antisymm
  · apply csSup_le ⟨_, hm⟩
    rintro r ⟨x, hx, rfl⟩
    exact upperDensity_le_fourEleven x hx
  · exact le_csSup hb hm

/- Direct real F6: the same seven interval branches as the deposited rational
   argument, now applied to t-floor(t). This bypasses, but does not assume,
   the uncompiled continuity/density bridge. It proves the ORIGINAL real goal. -/
theorem distance_bddBelow (t : ℝ) :
    BddBelow (Set.range (fun m : ℤ => |t-(m : ℝ)|)) := by
  refine ⟨0, ?_⟩
  rintro y ⟨m, rfl⟩
  exact abs_nonneg _

theorem distance_nonempty (t : ℝ) :
    (Set.range (fun m : ℤ => |t-(m : ℝ)|)).Nonempty := ⟨|t-(0 : ℤ)|, 0, rfl⟩

theorem distance_le_abs (t : ℝ) (m : ℤ) : distanceToInteger t ≤ |t-(m : ℝ)| :=
  csInf_le (distance_bddBelow t) ⟨m, rfl⟩

def profile (t : ℝ) : ℝ :=
  min (distanceToInteger t)
    (min (distanceToInteger (10*t)) (distanceToInteger (18*t)))

theorem real_near_integer (t : ℝ) :
    ∃ d : ℤ, (d = 1 ∨ d = 10 ∨ d = 18) ∧
      ∃ m : ℤ, |(d : ℝ)*t-(m : ℝ)| ≤ (4 : ℝ)/11 := by
  let k : ℤ := Int.floor t
  let u : ℝ := t-(k : ℝ)
  have h0 : 0 ≤ u := by
    dsimp [u, k]
    exact sub_nonneg.mpr (Int.floor_le t)
  have h1 : u < 1 := Int.fract_lt_one t
  have key (d c : ℤ) :
      (d : ℝ)*t-((k*d+c : ℤ) : ℝ) = (d : ℝ)*u-(c : ℝ) := by
    push_cast
    dsimp [u]
    ring
  by_cases c1 : 11*u ≤ 4
  · refine ⟨1, Or.inl rfl, k*1+0, ?_⟩
    rw [key]
    norm_num
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  by_cases c2 : 7 ≤ 11*u
  · refine ⟨1, Or.inl rfl, k*1+1, ?_⟩
    rw [key]
    norm_num
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  by_cases c3 : 110*u ≤ 48
  · refine ⟨10, Or.inr (Or.inl rfl), k*10+4, ?_⟩
    rw [key]
    norm_num
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  by_cases c4 : 110*u < 51
  · refine ⟨18, Or.inr (Or.inr rfl), k*18+8, ?_⟩
    rw [key]
    norm_num
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  by_cases c5 : 110*u ≤ 59
  · refine ⟨10, Or.inr (Or.inl rfl), k*10+5, ?_⟩
    rw [key]
    norm_num
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  by_cases c6 : 110*u < 62
  · refine ⟨18, Or.inr (Or.inr rfl), k*18+10, ?_⟩
    rw [key]
    norm_num
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  · refine ⟨10, Or.inr (Or.inl rfl), k*10+6, ?_⟩
    rw [key]
    norm_num
    exact abs_le.mpr ⟨by linarith, by linarith⟩

theorem profile_le (t : ℝ) : profile t ≤ (4 : ℝ)/11 := by
  obtain ⟨d, hd, m, hm⟩ := real_near_integer t
  rcases hd with rfl | rfl | rfl
  · have h := le_trans (distance_le_abs t m) (by simpa using hm)
    exact le_trans (min_le_left _ _) h
  · have h := le_trans (distance_le_abs (10*t) m) (by simpa using hm)
    exact le_trans (le_trans (min_le_right _ _) (min_le_left _ _)) h
  · have h := le_trans (distance_le_abs (18*t) m) (by simpa using hm)
    exact le_trans (le_trans (min_le_right _ _) (min_le_right _ _)) h

/-- A purely ordered estimate for any real value between two consecutive
    integers and at least r from both. -/
theorem distance_lower_of_bracket (t r : ℝ) (a : ℤ)
    (hleft : (a : ℝ)+r ≤ t) (hright : t ≤ ((a+1 : ℤ) : ℝ)-r) :
    r ≤ distanceToInteger t := by
  apply le_csInf (distance_nonempty t)
  rintro y ⟨m, rfl⟩
  by_cases hm : m ≤ a
  · have hmR : (m : ℝ) ≤ a := by exact_mod_cast hm
    exact le_trans (by linarith : r ≤ t-(m : ℝ)) (le_abs_self _)
  · have hma : a+1 ≤ m := by omega
    have hmR : ((a+1 : ℤ) : ℝ) ≤ m := by exact_mod_cast hma
    exact le_trans (by linarith : r ≤ -(t-(m : ℝ))) (neg_le_abs _)

theorem profile_at_fourEleven : (4 : ℝ)/11 ≤ profile ((4 : ℝ)/11) := by
  have h1 := distance_lower_of_bracket ((4 : ℝ)/11) ((4 : ℝ)/11) 0
    (by norm_num) (by norm_num)
  have h10 := distance_lower_of_bracket (10*((4 : ℝ)/11)) ((4 : ℝ)/11) 3
    (by norm_num) (by norm_num)
  have h18 := distance_lower_of_bracket (18*((4 : ℝ)/11)) ((4 : ℝ)/11) 6
    (by norm_num) (by norm_num)
  exact le_min h1 (le_min h10 h18)

theorem kappa_eq_fourEleven : OP01.Fixed411.kappa = (4 : ℝ)/11 := by
  have hb : BddAbove (Set.range profile) := by
    refine ⟨(4 : ℝ)/11, ?_⟩
    rintro y ⟨t, rfl⟩
    exact profile_le t
  have hn : (Set.range profile).Nonempty := ⟨profile 0, 0, rfl⟩
  change sSup (Set.range profile) = _
  apply le_antisymm
  · apply csSup_le hn
    rintro y ⟨t, rfl⟩
    exact profile_le t
  · exact le_trans profile_at_fourEleven (le_csSup hb ⟨(4 : ℝ)/11, rfl⟩)

/-- The original handoff goal, not a replacement statement. -/
theorem fixedResult : OP01.Fixed411.fixedResultGoal :=
  ⟨mu_eq_fourEleven, kappa_eq_fourEleven⟩

end
end OP01.Fixed411.RealWrapper

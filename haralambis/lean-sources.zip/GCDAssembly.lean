import Scaling
import ResidueCounts
namespace Haralambis.ArbitraryTriples
open OP01.Fixed411 Haralambis.Composition

theorem avoids_residue_sequence (a b c g : ℕ) (x : ℤ → ℕ)
    (hx : avoids (g*a) (g*b) (g*c) x) (w : ℤ) (r : ℕ) :
    avoids a b c (residueSequence x w g r) := by
  constructor
  · intro z; exact hx.1 _
  · intro z
    have h := hx.2 (w+r+(g:ℤ)*z)
    dsimp [residueSequence]
    convert h using 1 <;> push_cast <;> congr 2 <;> ring

/-- Exact scaled endpoint constant; residue cardinalities are counted once. -/
theorem interval_scale (a b c g : ℕ) (hg : 0<g) (hbc : 1 ≤ b+c)
    (bound : ∀ x : ℤ → ℕ, avoids a b c x → ∀ w : ℤ, ∀ n : ℕ,
      (intervalCount x w n : ℝ) ≤ kappa a b c*n + kappa a b c*(b+c-1:ℕ))
    (x : ℤ → ℕ) (hx : avoids (g*a) (g*b) (g*c) x) (w : ℤ) (N : ℕ) :
    (intervalCount x w N : ℝ) ≤ kappa (g*a) (g*b) (g*c)*N +
      kappa (g*a) (g*b) (g*c)*((g*b:ℕ)+(g*c:ℕ)-g:ℤ) := by
  rw [kappa_scale a b c g hg]
  have h := residue_interval_bound x w g hg (kappa a b c)
    (kappa a b c*(b+c-1:ℕ)) (fun r _ n => bound _ (avoids_residue_sequence a b c g x hx w r) 0 n) N
  have hc : (g:ℝ)*(kappa a b c*(b+c-1:ℕ)) =
      kappa a b c*(((g*b:ℕ)+(g*c:ℕ)-g:ℤ):ℝ) := by
    have he : ((b+c-1:ℕ):ℝ)=(b:ℝ)+c-1 := by
      rw [Nat.cast_sub hbc]; push_cast; rfl
    rw [he]
    push_cast
    ring
  rw [hc] at h
  exact h
#print axioms interval_scale
end Haralambis.ArbitraryTriples

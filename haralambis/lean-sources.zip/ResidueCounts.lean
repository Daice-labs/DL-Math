import GreedyComposition
namespace Haralambis.Composition
open Finset OP01.Fixed411

def residueSequence (x : ℤ → ℕ) (w : ℤ) (g r : ℕ) : ℤ → ℕ :=
  fun z => x (w+r+(g:ℤ)*z)

theorem residue_succ (x : ℤ → ℕ) (w : ℤ) (g r q : ℕ) :
    intervalCount (residueSequence x w g r) 0 (q+1) =
      intervalCount (residueSequence x w g r) 0 q + x (w+r+(g:ℤ)*q) := by
  simp [intervalCount, sum_range_succ, residueSequence]

theorem rectangle_count (x : ℤ → ℕ) (w : ℤ) (g q : ℕ) :
    intervalCount x w (g*q) = ∑ r ∈ range g, intervalCount (residueSequence x w g r) 0 q := by
  induction q with
  | zero => simp [intervalCount]
  | succ q ih =>
    rw [Nat.mul_succ, count_add, ih]
    simp only [residue_succ, sum_add_distrib]
    congr 1
    unfold intervalCount
    apply sum_congr rfl
    intro r hr
    congr 1
    push_cast
    ring

theorem residue_remainder (x : ℤ → ℕ) (w : ℤ) (g q r : ℕ) (hr : r ≤ g) :
    intervalCount x w (g*q+r) =
      (∑ s ∈ range r, intervalCount (residueSequence x w g s) 0 (q+1)) +
      ∑ s ∈ range (g-r), intervalCount (residueSequence x w g (r+s)) 0 q := by
  rw [count_add, rectangle_count]
  have he : r+(g-r)=g := by omega
  conv_lhs => arg 1; rw [←he, sum_range_add]
  simp only [he, residue_succ, sum_add_distrib]
  have ht : intervalCount x (w+((g*q:ℕ):ℤ)) r =
      ∑ s ∈ range r, x (w+s+(g:ℤ)*q) := by
    unfold intervalCount
    apply sum_congr rfl
    intro s hs
    congr 1
    push_cast
    ring
  rw [ht]
  omega

/-- Exact residue transfer, including short intervals and empty residues. -/
theorem residue_interval_bound (x : ℤ → ℕ) (w : ℤ) (g : ℕ) (hg : 0<g)
    (ρ C : ℝ)
    (hb : ∀ r < g, ∀ n : ℕ,
      (intervalCount (residueSequence x w g r) 0 n : ℝ) ≤ ρ*n+C)
    (N : ℕ) : (intervalCount x w N : ℝ) ≤ ρ*N+(g:ℝ)*C := by
  let q := N/g
  let r := N%g
  have hr : r < g := Nat.mod_lt N hg
  have hn : g*q+r=N := by dsimp [q,r]; have := Nat.mod_add_div N g; omega
  have hd := residue_remainder x w g q r (by omega)
  rw [hn] at hd
  have h1 := sum_le_sum (s := range r) (fun s hs => hb s (by have := mem_range.mp hs; omega) (q+1))
  have h2 := sum_le_sum (s := range (g-r)) (fun s hs => hb (r+s) (by have := mem_range.mp hs; omega) q)
  have hdR : (intervalCount x w N : ℝ) =
      (∑ s ∈ range r, (intervalCount (residueSequence x w g s) 0 (q+1) : ℝ)) +
      ∑ s ∈ range (g-r), (intervalCount (residueSequence x w g (r+s)) 0 q : ℝ) := by exact_mod_cast hd
  simp only [sum_const, card_range, nsmul_eq_mul] at h1 h2
  have hrR : (g:ℝ) = r+(g-r:ℕ) := by exact_mod_cast (show g=r+(g-r) by omega)
  have hnR : (g:ℝ)*q+r=N := by exact_mod_cast hn
  push_cast at h1
  rw [hdR]
  have heq : (r:ℝ)*(ρ*(q+1)+C)+(g-r:ℕ)*(ρ*q+C) = ρ*N+(g:ℝ)*C := by
    rw [←hnR, hrR]
    ring
  rw [←heq]
  exact add_le_add h1 h2
#print axioms residue_interval_bound
end Haralambis.Composition

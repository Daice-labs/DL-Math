import FiniteContract
namespace OP04
open scoped BigOperators
open Finset Polynomial P4c R1Circuit

theorem zeroCheck_sound (s:FiniteSource) (h:s.zeroCheck=true) (x:Finset s.Var) :
 (original (cnf s.cnfSource) x).eval 0 = if sat x s.cnfSource then 1 else 0 := by
 have hz:∀o:s.Occ,∀i:s.Var,evaluate (s.coefficients o i) 0=if i=(s.vars o).1 then 1 else 0 := by
  simpa only [FiniteSource.zeroCheck,decide_eq_true_eq] using h
 apply cnf_zero
 intro cl hc l hl
 rcases List.mem_flatMap.mp hc with ⟨g,hg,hcl⟩
 rcases List.mem_map.mp hcl with ⟨os,hos,rfl⟩
 rcases List.mem_map.mp hl with ⟨o,ho,rfl⟩
 apply canonical_zero univ (s.vars o).1 (mem_univ _) (s.forms o)
 intro i hi
 simpa only [FiniteSource.forms,eval_polynomial] using hz o i

noncomputable def sourcePolynomial (s:FiniteSource) : Polynomial ℚ := ∑x∈(univ:Finset s.Var).powerset,original (cnf s.cnfSource) x

theorem source_at_zero (s:FiniteSource) (h:s.zeroCheck=true) :
 (sourcePolynomial s).eval 0 = (((univ:Finset s.Var).powerset.filter (fun x=>sat x s.cnfSource=true)).card:ℚ) := by
 simp only [sourcePolynomial,eval_finsetSum]
 simp_rw [zeroCheck_sound s h]
 simp
end OP04

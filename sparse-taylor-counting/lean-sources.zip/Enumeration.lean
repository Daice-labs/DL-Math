import Circuit
import Lean.Elab.Tactic.Omega

open scoped BigOperators
namespace R1Enumeration
open Finset R1Difference R1Support R1Loops R1Circuit
noncomputable section
variable {I : Type*} [DecidableEq I]

theorem bounded_cardinal_loop (B : Finset I) (q : Nat) (f : Finset I → ℚ) :
    (∑ j ∈ range (min q B.card + 1), ∑ E ∈ powersetCard j B, f E) =
      ∑ E ∈ B.powerset.filter (fun E => E.card ≤ q), f E := by
  rw [← cardinal_loop B q f]
  calc
    _ = ∑ j ∈ range (min q B.card+1), ∑ E ∈ powersetCard j B,
        if j≤q then f E else 0 := by
      apply sum_congr rfl
      intro j hj
      have h : j≤q := by simp only [mem_range] at hj; omega
      simp [h]
    _ = _ := by
      apply sum_subset (range_mono (by omega : min q B.card+1 ≤ B.card+1))
      intro j hj hn
      have h : ¬j≤q := by simp only [mem_range] at hj hn; omega
      simp [h]

-- Exact j/E/h/U order used in _taylor_at; scalar component k of each z-array.
def enumerationLoop (B : Finset I) (e : Finset I → Expr I) (q k : Nat) : ℚ :=
  ∑ j ∈ range (min q B.card+1), ∑ E ∈ powersetCard j B,
    ∑ h ∈ range (j+1), ∑ U ∈ powersetCard h E,
      (-1:ℚ)^(j-h) *
      ∑ x ∈ B.powerset.filter (fun x => E ⊆ x), (eval (e x) U).coeff k

theorem enumeration_correct (B : Finset I) (e : Finset I → Expr I) (q k : Nat) :
    enumerationLoop B e q k = restrictedLoop B e q k := by
  unfold enumerationLoop
  have hi : ∀ j, ∀ E ∈ powersetCard j B,
      (∑ h ∈ range (j+1), ∑ U ∈ powersetCard h E,
        (-1:ℚ)^(j-h) * ∑ x ∈ B.powerset.filter (fun x => E ⊆ x), (eval (e x) U).coeff k) =
      ∑ x ∈ B.powerset.filter (fun x => E ⊆ x), difference E (fun U => (eval (e x) U).coeff k) := by
    intro j E hE
    have hj := (mem_powersetCard.mp hE).2
    subst j
    have hh : (∑ h ∈ range (E.card+1), ∑ U ∈ powersetCard h E,
        (-1:ℚ)^(E.card-h) * ∑ x ∈ B.powerset.filter (fun x => E ⊆ x), (eval (e x) U).coeff k) =
        ∑ U ∈ E.powerset, (-1:ℚ)^(E\U).card *
          ∑ x ∈ B.powerset.filter (fun x => E ⊆ x), (eval (e x) U).coeff k := by
      rw [sum_powerset]
      apply sum_congr rfl
      intro h _
      apply sum_congr rfl
      intro U hU
      rcases mem_powersetCard.mp hU with ⟨hs,hc⟩
      rw [card_sdiff_of_subset hs,hc]
    rw [hh]
    simp_rw [mul_sum]
    rw [sum_comm]
    rfl
  have ho : (∑ j ∈ range (min q B.card+1), ∑ E ∈ powersetCard j B,
    ∑ h ∈ range (j+1), ∑ U ∈ powersetCard h E,
      (-1:ℚ)^(j-h) * ∑ x ∈ B.powerset.filter (fun x => E ⊆ x), (eval (e x) U).coeff k) =
    ∑ j ∈ range (min q B.card+1), ∑ E ∈ powersetCard j B,
      ∑ x ∈ B.powerset.filter (fun x => E ⊆ x), difference E (fun U => (eval (e x) U).coeff k) := by
    apply sum_congr rfl
    intro j _
    apply sum_congr rfl
    intro E hE
    exact hi j E hE
  rw [ho,bounded_cardinal_loop]
  rfl

theorem enumeration_taylor (c : Circuit I) (B : Finset I) (t : ℚ)
    (q k : Nat) (hk:k≤q) :
    enumerationLoop B (fun x => translate t x c) q k =
    (Polynomial.taylor t (∑ x ∈ B.powerset, original c x)).coeff k := by
  rw [enumeration_correct]
  exact generic_taylor_extraction c B t q k hk

set_option pp.fullNames true
#print axioms enumeration_taylor
end
end R1Enumeration

import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Taylor
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Tactic.Ring

open scoped BigOperators
namespace R1
noncomputable section
open Classical
-- Generic finite weighted join. A block can be any finite type, not only bits.
theorem separated_join {K : Type*} [CommSemiring K] {ι : Type*} [Fintype ι] {A : ι → Type*}
    [DecidableEq ι] [∀ i, Fintype (A i)] (w : ∀ i, A i → K) :
    (∑ x : (∀ i, A i), ∏ i, w i (x i)) = ∏ i, ∑ a, w i a := by
  simpa using (Finset.prod_univ_sum (fun i => (Finset.univ : Finset (A i))) w).symm

-- Recovery with an explicitly checked dual witness. B includes all coefficients.
-- a[k] is the coefficient of T^k, m indexes point/order pairs.
def jet (B M : ℕ) (a : Fin (B+1) → ℚ) (matrix : Fin M → Fin (B+1) → ℚ)
    (j : Fin M) : ℚ := ∑ k, a k * matrix j k

def dualCheck (B M : ℕ) (matrix : Fin M → Fin (B+1) → ℚ)
    (w : Fin M → ℚ) : Prop :=
    ∀ k, (∑ j, w j * matrix j k) = if k.val = 0 then 1 else 0

theorem dual_recovery (B M : ℕ) (a : Fin (B+1) → ℚ)
    (matrix : Fin M → Fin (B+1) → ℚ) (w : Fin M → ℚ)
    (h : dualCheck B M matrix w) :
    (∑ j, w j * jet B M a matrix j) = a ⟨0, Nat.zero_lt_succ B⟩ := by
  simp only [jet, Finset.mul_sum]
  rw [Finset.sum_comm]
  have hh : ∀ k : Fin (B+1), (∑ j, w j * (a k * matrix j k)) =
      a k * (if k.val = 0 then 1 else 0) := by
    intro k
    calc
      _ = a k * ∑ j, w j * matrix j k := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro j _
        ring
      _ = _ := by rw [h k]
  simp_rw [hh]
  simp

-- Full coefficient equality is enough for generic Hermite/Taylor recovery.
-- This is the reusable independent oracle endpoint; no numerical sample premise.
theorem taylor_recovery (p candidate : Polynomial ℚ) (t : ℚ)
    (h : ∀ k, (Polynomial.taylor t candidate).coeff k =
                  (Polynomial.taylor t p).coeff k) : candidate.eval 0 = p.eval 0 := by
  have he : Polynomial.taylor t candidate = Polynomial.taylor t p := Polynomial.ext h
  exact congrArg (Polynomial.eval 0) ((Polynomial.taylor_injective t) he)

-- Every row-space witness is checked coordinatewise before this identity applies.
theorem measurement_transfer {K : Type*} [CommSemiring K] {I L : Type*} [Fintype I] [Fintype L]
    (p x : I → K) (rows : L → I → K) (lam : L → K)
    (h : ∀ i, p i = ∑ l, lam l * rows l i) :
    (∑ i, p i * x i) = ∑ l, lam l * ∑ i, rows l i * x i := by
  simp_rw [h, Finset.sum_mul]
  rw [Finset.sum_comm]
  simp only [Finset.mul_sum, mul_assoc]

-- General CNF arithmetization, including empty clauses and an empty formula.
abbrev Lit := Nat × Bool
abbrev CNF := List (List Lit)
def clauseWeight (a : Nat → Bool) : List Lit → ℚ
  | [] => 0
  | l :: ls => if a l.1 == l.2 then 1 else clauseWeight a ls

def clauseProduct (a : Nat → Bool) : List Lit → ℚ
  | [] => 1
  | l :: ls => (if a l.1 == l.2 then 0 else 1) * clauseProduct a ls

theorem clause_arithmetic (a : Nat → Bool) (ls : List Lit) :
    1 - clauseProduct a ls = clauseWeight a ls := by
  induction ls with
  | nil => simp [clauseProduct, clauseWeight]
  | cons l ls ih =>
    simp only [clauseProduct, clauseWeight]
    split <;> simp_all

def formulaWeight (a : Nat → Bool) : CNF → ℚ
  | [] => 1
  | c :: cs => (1 - clauseProduct a c) * formulaWeight a cs

theorem clause_boolean (a : Nat → Bool) (ls : List Lit) :
    clauseWeight a ls = if ls.any (fun l => a l.1 == l.2) then 1 else 0 := by
  induction ls with
  | nil => simp [clauseWeight]
  | cons l ls ih =>
    simp only [clauseWeight, List.any_cons]
    by_cases h : a l.1 = l.2 <;> simp_all

theorem formula_boolean (a : Nat → Bool) (f : CNF) :
    formulaWeight a f = if f.all (fun c => c.any (fun l => a l.1 == l.2)) then 1 else 0 := by
  induction f with
  | nil => simp [formulaWeight]
  | cons c cs ih =>
    rw [formulaWeight, clause_arithmetic, clause_boolean, ih]
    cases hc : c.any (fun l => a l.1 == l.2) <;>
      cases hs : cs.all (fun c => c.any (fun l => a l.1 == l.2)) <;> simp [hc, hs]

theorem correction_zero (p : Polynomial ℚ) (t : ℚ) :
    (Polynomial.taylor t p - Polynomial.C (p.eval t)).coeff 0 = 0 := by
  simp

-- Products of s correction factors cannot contribute below order |s|.
-- This is the algebraic truncation step, independent of finite test sizes.
theorem high_order_correction_vanishes {I : Type*} (s : Finset I)
    (p : I → Polynomial ℚ) (t : ℚ) (k : Nat) (hk : k < s.card) :
    (∏ i ∈ s, (Polynomial.taylor t (p i) - Polynomial.C ((p i).eval t))).coeff k = 0 := by
  have hd : (∏ _i ∈ s, (Polynomial.X : Polynomial ℚ)) ∣
      ∏ i ∈ s, (Polynomial.taylor t (p i) - Polynomial.C ((p i).eval t)) := by
    apply Finset.prod_dvd_prod_of_dvd
    intro i _
    exact Polynomial.X_dvd_iff.mpr (correction_zero (p i) t)
  have hd' : (Polynomial.X : Polynomial ℚ) ^ s.card ∣
      ∏ i ∈ s, (Polynomial.taylor t (p i) - Polynomial.C ((p i).eval t)) := by
    simpa using hd
  exact Polynomial.X_pow_dvd_iff.mp hd' k hk

-- Bounded integer measurement range: each bit is 0 or 1.
theorem measurement_range {I : Type*} [Fintype I] (row : I → ℤ) (x : I → Bool)
    (D : ℤ) (h : ∑ i, |row i| ≤ D) :
    |∑ i, row i * (if x i then 1 else 0)| ≤ D := by
  calc
    _ ≤ ∑ i, |row i * (if x i then 1 else 0)| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i, |row i| := by
      apply Finset.sum_le_sum
      intro i _
      cases x i <;> simp
    _ ≤ D := h

set_option pp.fullNames true
#print axioms high_order_correction_vanishes
#print axioms correction_zero
#print axioms measurement_transfer
#print axioms clause_arithmetic
#print axioms formula_boolean
#print axioms measurement_range
#print axioms separated_join
#print axioms dual_recovery
#print axioms taylor_recovery
end
end R1

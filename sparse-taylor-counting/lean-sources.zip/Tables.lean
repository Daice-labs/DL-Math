import PythonLoops
import Certificate
import Mathlib.Data.List.Nodup

namespace R1Tables
open R1Certificate R1PythonLoops
noncomputable section
abbrev Assignment := List (Nat × Bool)

def lookup (i : Nat) : Assignment → Option Bool
 | [] => none
 | (k,b)::xs => if i=k then some b else lookup i xs

def candidates (keys : List Nat) : List Assignment :=
  (assignments keys.length).map (fun bits => keys.zip bits)

theorem zip_injective (keys : List Nat) (a b : List Bool)
    (ha:a.length=keys.length) (hb:b.length=keys.length)
    (h:keys.zip a=keys.zip b) : a=b := by
  have hh := congrArg (List.map Prod.snd) h
  simpa [List.map_snd_zip ha.le,List.map_snd_zip hb.le] using hh

theorem candidate_nodup (keys : List Nat) : (candidates keys).Nodup := by
  apply List.Nodup.map_on _ (assignment_nodup keys.length)
  intro a ha b hb h
  exact zip_injective keys a b (assignment_length _ a ha) (assignment_length _ b hb) h

theorem candidate_iff (keys : List Nat) (u : Assignment) :
    u ∈ candidates keys ↔ ∃ bits : List Bool, bits.length=keys.length ∧ keys.zip bits=u := by
  constructor
  · intro h
    obtain ⟨bits,hb,he⟩ := List.mem_map.mp h
    exact ⟨bits,assignment_length _ bits hb,he⟩
  · rintro ⟨bits,hb,rfl⟩
    exact List.mem_map.mpr ⟨bits,hb ▸ assignment_complete bits,rfl⟩

theorem candidate_keys (keys : List Nat) (u : Assignment) (hu:u∈candidates keys) :
    u.map Prod.fst=keys := by
  obtain ⟨bits,hb,rfl⟩ := (candidate_iff keys u).mp hu
  exact List.map_fst_zip hb.symm.le

theorem lookup_member (u : Assignment) (hn:(u.map Prod.fst).Nodup)
    (i : Nat) (b : Bool) (hm:(i,b)∈u) : lookup i u=some b := by
  induction u with
  | nil => simp at hm
  | cons p xs ih =>
    rcases p with ⟨k,c⟩
    have hh := List.nodup_cons.mp hn
    rcases List.mem_cons.mp hm with he | ht
    · cases he; simp [lookup]
    · have hne : i≠k := by
        intro he; subst i
        exact hh.1 (List.mem_map.mpr ⟨(k,b),ht,rfl⟩)
      simp [lookup,hne,ih hh.2 ht]

def eligible (fixed : List Nat) (u : Assignment) : Bool :=
  fixed.all (fun i => lookup i u != some false)

theorem eligible_iff (fixed : List Nat) (u : Assignment) :
    eligible fixed u = true ↔ ∀ i∈fixed, lookup i u ≠ some false := by
  simp [eligible,List.all_eq_true]

-- Sparse row.get(i,0) is represented by a total integer row with zero at absent keys.
def measurement (rows : List (Nat → Int)) (u : Assignment) : List Int :=
  rows.map (fun row => (u.map (fun ib => row ib.1 * if ib.2 then 1 else 0)).sum)

def dictionaryMeasurement (rows : List (Nat → Int)) (u : Assignment) : List Int :=
  rows.map (fun row => ((u.map Prod.fst).map
    (fun i => row i * if (lookup i u).getD false then 1 else 0)).sum)

theorem measurement_correct (rows : List (Nat → Int)) (u : Assignment)
    (hn:(u.map Prod.fst).Nodup) : dictionaryMeasurement rows u=measurement rows u := by
  unfold dictionaryMeasurement measurement
  apply List.map_congr_left
  intro row _
  simp only [List.map_map,Function.comp_def]
  congr 1
  apply List.map_congr_left
  intro p hp
  rw [lookup_member u hn p.1 p.2 hp]
  rfl

def table (keys fixed : List Nat) (rows : List (Nat → Int)) : List Int → List Assignment :=
  groupTable (measurement rows) ((candidates keys).filter (eligible fixed)) (fun _ => [])

theorem bucket_exact (keys fixed : List Nat) (rows : List (Nat → Int)) (y : List Int) :
    table keys fixed rows y = ((candidates keys).filter (eligible fixed)).filter
       (fun u => decide (y=measurement rows u)) := by
  rw [table,group_table_correct]; rfl

theorem bucket_member_iff (keys fixed : List Nat) (rows : List (Nat → Int))
    (y : List Int) (u : Assignment) :
    u ∈ table keys fixed rows y ↔
    (∃ bits : List Bool, bits.length=keys.length ∧ keys.zip bits=u) ∧
    (∀ i∈fixed, lookup i u ≠ some false) ∧ y=measurement rows u := by
  simp only [bucket_exact,List.mem_filter,decide_eq_true_eq,eligible_iff,candidate_iff]
  tauto

theorem bucket_nodup (keys fixed : List Nat) (rows : List (Nat → Int)) (y : List Int) :
    (table keys fixed rows y).Nodup := by
  rw [bucket_exact]
  exact ((candidate_nodup keys).filter _).filter _

theorem unique_bucket (keys fixed : List Nat) (rows : List (Nat → Int))
    (y z : List Int) (u : Assignment) (hy:u∈table keys fixed rows y)
    (hz:u∈table keys fixed rows z) : y=z := by
  exact ((bucket_member_iff _ _ _ _ _).mp hy).2.2.trans
    ((bucket_member_iff _ _ _ _ _).mp hz).2.2.symm

-- Distinct sorted keys are supplied by the admitted partition. This makes zip
-- a faithful dictionary rather than a sequence with silently overwritten keys.
theorem admitted_measurement_correct (keys : List Nat) (hn:keys.Nodup)
    (rows : List (Nat → Int)) (u : Assignment) (hu:u∈candidates keys) :
    dictionaryMeasurement rows u=measurement rows u := by
  apply measurement_correct
  rw [candidate_keys keys u hu]
  exact hn

#print axioms candidate_nodup
#print axioms bucket_member_iff
#print axioms bucket_nodup
#print axioms unique_bucket
#print axioms admitted_measurement_correct
end
end R1Tables

import Counting
namespace P4c
open scoped BigOperators
open Classical Finset Polynomial R1Circuit
noncomputable section
variable {I : Type*} [DecidableEq I]

theorem eval_ite (b : Prop) [Decidable b] (p q : Polynomial ℚ) (t : ℚ) :
    (if b then p else q).eval t = if b then p.eval t else q.eval t := by
  split_ifs <;> rfl

def canonicalForm (B : Finset I) (p : I → Polynomial ℚ) : Form I :=
  B.toList.map (fun i => (i,p i))

theorem list_form_value (l : List I) (p : I → Polynomial ℚ) (x : Finset I) :
    formValue (l.map (fun i => (i,p i))) x = (l.map (fun i => if i ∈ x then p i else 0)).sum := by
  induction l with
  | nil => rfl
  | cons i l ih => simp [formValue,ih]

theorem canonical_value (B : Finset I) (p : I → Polynomial ℚ) (x : Finset I) :
    formValue (canonicalForm B p) x = ∑ i ∈ B, if i ∈ x then p i else 0 := by
  simp [canonicalForm,list_form_value]

theorem canonical_zero (B : Finset I) (v : I) (hv : v ∈ B)
    (p : I → Polynomial ℚ) (hp : ∀ i ∈ B, (p i).eval 0 = if i=v then 1 else 0)
    (x : Finset I) :
    (formValue (canonicalForm B p) x).eval 0 = if v ∈ x then 1 else 0 := by
  rw [canonical_value,eval_finsetSum]
  have he : ∀ i ∈ B, (if i ∈ x then p i else 0).eval 0 =
      if i=v then (if v∈x then 1 else 0) else 0 := by
    intro i hi
    by_cases h : i ∈ x <;> by_cases h' : i=v <;> simp_all
  simp_rw [sum_congr rfl he]
  simp [hv]

abbrev SourceLit (I : Type*) := I × Bool × Form I

def failure : List (SourceLit I) → Circuit I
  | [] => .constant 1
  | (v,sign,f)::ls => .mul
      (if sign then .add (.constant 1) (.neg (.form f)) else .form f) (failure ls)
def cnf : List (List (SourceLit I)) → Circuit I
  | [] => .constant 1
  | cl::cls => .mul (.add (.constant 1) (.neg (failure cl))) (cnf cls)
def sat (x : Finset I) (cls : List (List (SourceLit I))) : Bool :=
  cls.all (fun cl => cl.any (fun l => decide (l.1 ∈ x) == l.2.1))

theorem failure_zero (x : Finset I) (cl : List (SourceLit I))
    (h : ∀ l ∈ cl, (formValue l.2.2 x).eval 0 = if l.1∈x then 1 else 0) :
    (original (failure cl) x).eval 0 =
      if cl.any (fun l => decide (l.1∈x) == l.2.1) then 0 else 1 := by
  induction cl with
  | nil => simp [failure,original]
  | cons l ls ih =>
    rcases l with ⟨v,b,f⟩
    have hl := h (v,b,f) (by simp)
    have ht : ∀ l ∈ ls, (formValue l.2.2 x).eval 0 = if l.1∈x then 1 else 0 := by
      intro l hm; exact h l (by simp [hm])
    have hi := ih ht
    cases b <;> by_cases hv : v∈x <;>
      simp_all [failure,original,List.any_cons]

theorem cnf_zero (x : Finset I) (cls : List (List (SourceLit I)))
    (h : ∀ cl ∈ cls, ∀ l ∈ cl, (formValue l.2.2 x).eval 0 = if l.1∈x then 1 else 0) :
    (original (cnf cls) x).eval 0 = if sat x cls then 1 else 0 := by
  induction cls with
  | nil => simp [cnf,original,sat]
  | cons cl cls ih =>
    have hc := failure_zero x cl (h cl (by simp))
    have ht : ∀ cl ∈ cls, ∀ l ∈ cl, (formValue l.2.2 x).eval 0 = if l.1∈x then 1 else 0 := by
      intro cl hm; exact h cl (by simp [hm])
    have hi := ih ht
    simp only [cnf,original,eval_mul,eval_add,eval_C,eval_neg,hc,hi,sat,List.all_cons]
    by_cases h1 : cl.any (fun l => decide (l.1∈x) == l.2.1) = true <;>
      by_cases h2 : cls.all (fun cl => cl.any (fun l => decide (l.1∈x) == l.2.1)) = true <;> simp [h1,h2]

#print axioms canonical_zero
#print axioms cnf_zero
end
end P4c

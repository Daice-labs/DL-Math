import Counting
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FinCases
namespace P4c
open scoped BigOperators
open Polynomial
noncomputable section

theorem matrix_entry (D M : Nat) (ts : Fin M → ℚ) (ord : Fin M → Nat)
    (j : Fin M) (k : Fin (D+1)) :
    R1Recovery.matrix D M ts ord j k = (k.val.choose (ord j) : ℚ) * (ts j)^(k.val-ord j) := by
  simp [R1Recovery.matrix,coeff_X_add_C_pow,mul_comm]

-- Check a dual witness rather than trust the result of Gaussian elimination.
-- This proves uniqueness of the recovered constant, not merely agreement with a candidate.
theorem recovered_from_jets (p : Polynomial ℚ) (D M : Nat)
    (ts : Fin M → ℚ) (ord : Fin M → Nat) (w vals : Fin M → ℚ) (a : ℚ)
    (hd : p.natDegree ≤ D)
    (hw : R1.dualCheck D M (R1Recovery.matrix D M ts ord) w)
    (hv : ∀ j, vals j = (taylor (ts j) p).coeff (ord j))
    (ha : a = ∑ j,w j * vals j) : p.eval 0 = a := by
  rw [ha]
  simp_rw [hv, ← R1Recovery.jet_is_taylor p D M hd ts ord]
  rw [R1.dual_recovery D M _ _ w hw]
  exact (coeff_zero_eq_eval_zero p).symm
#print axioms matrix_entry
#print axioms recovered_from_jets
end
end P4c

import FiniteFibres
namespace OP04
open scoped BigOperators
open Finset Polynomial
abbrev MeasurementTuple (s:FiniteSource) (d:FiniteDesign s) := ∀g:s.Group,Fin (d.measurements g)→ℚ
structure RestrictedRow (s:FiniteSource) (d:FiniteDesign s) where
 tuples : List (MeasurementTuple s d)
 tables : List (∀g:s.Group,List (Finset (Fin (s.sizes g))))
namespace RestrictedRow
def members {s:FiniteSource} {d:FiniteDesign s} (r:RestrictedRow s d) (y:MeasurementTuple s d) : ∀g:s.Group,List (Finset (Fin (s.sizes g))) :=
 r.tables[r.tuples.idxOf y]?.getD (fun _=>[])

def keys (s:FiniteSource) (d:FiniteDesign s) (g:s.Group) :=
 (univ:Finset (Finset (Fin (s.sizes g)))).image (d.measure s g)
def coverageCheck (s:FiniteSource) (d:FiniteDesign s) (r:RestrictedRow s d) : Bool := decide
 (r.tuples.Nodup ∧ r.tuples.toFinset=Fintype.piFinset (keys s d) ∧
 ∀y∈r.tuples,∀g:s.Group,(r.members y g).Nodup ∧
 (r.members y g).toFinset=(univ:Finset (Finset (Fin (s.sizes g)))).filter (fun u=>d.measure s g u=y g))

def program (s:FiniteSource) (d:FiniteDesign s) (r:RestrictedRow s d) (t:ℚ) (E U:Finset s.Var) : FiniteExpr :=
 sumExpr (r.tuples.map (fun y=>prodExpr (List.ofFn (fun g:s.Group=>d.fibreExpr s t y g (r.members y g) E U))))

theorem meaning_program (s:FiniteSource) (d:FiniteDesign s) (r:RestrictedRow s d) (t:ℚ) (E U:Finset s.Var)
 (hc:r.coverageCheck s d=true) :
 meaning (r.program s d t E U)=
 ∑y∈Fintype.piFinset (keys s d),∏g:s.Group,∑u∈(univ:Finset (Finset (Fin (s.sizes g)))).filter (fun u=>d.measure s g u=y g),
 if restrict E g⊆u then localFactor s.clauses s.vars s.forms t d.lam y g u U else 0 := by
 have hc' : r.tuples.Nodup ∧ r.tuples.toFinset=Fintype.piFinset (keys s d) ∧
  ∀y∈r.tuples,∀g:s.Group,(r.members y g).Nodup ∧
  (r.members y g).toFinset=(univ:Finset (Finset (Fin (s.sizes g)))).filter (fun u=>d.measure s g u=y g) := by
  simpa only [coverageCheck,decide_eq_true_eq] using hc
 simp only [program,meaning_sum,List.map_map]
 rw [←List.sum_toFinset _ hc'.1]
 rw [←hc'.2.1]
 apply sum_congr rfl
 intro y hy
 have hy':y∈r.tuples:=List.mem_toFinset.mp hy
 dsimp only [Function.comp_apply]
 simp only [meaning_prod,List.map_ofFn,List.prod_ofFn]
 apply prod_congr rfl
 intro g _
 dsimp only [Function.comp_apply]
 simp only [FiniteDesign.fibreExpr,meaning_sum,List.map_map]
 rw [←List.sum_toFinset _ (hc'.2.2 y hy' g).1,(hc'.2.2 y hy' g).2]
 apply sum_congr rfl
 intro u _
 dsimp only [Function.comp_apply]
 split <;> simp [meaning_factor]
theorem program_separated (s:FiniteSource) (d:FiniteDesign s) (r:RestrictedRow s d) (t:ℚ) (E U:Finset s.Var)
 (hc:r.coverageCheck s d=true) :
 meaning (r.program s d t E U)=separated s.clauses s.vars s.forms t d.rows d.lam E U := by
 classical
 rw [meaning_program s d r t E U hc]
 unfold separated P4c.factored
 symm
 apply Finset.sum_bij (fun y _=>fun g=>(y g).val)
 · intro y _
   exact Fintype.mem_piFinset.mpr (fun g=>(y g).property)
 · intro a _ b _ hab
   funext g
   exact Subtype.ext (congrFun hab g)
 · intro y hy
   refine ⟨(fun g=>⟨y g,?_⟩),mem_univ _,rfl⟩
   exact Fintype.mem_piFinset.mp hy g
 · intro y _
   apply Finset.prod_congr rfl
   intro g _
   rw [Finset.sum_filter]
   apply Finset.sum_congr rfl
   intro u _
   have he : key d.rows g u=y g ↔ d.measure s g u=(y g).val := by
    exact Subtype.ext_iff
   simp only [he]

theorem checked_restricted (s:FiniteSource) (d:FiniteDesign s) (r:RestrictedRow s d) (t:ℚ) (E U:Finset s.Var)
 (hc:r.coverageCheck s d=true) (hr:d.rowCheck s t=true) (J:Nat) (recorded:List ℚ)
 (ha:expressionCheck J (r.program s d t E U) recorded=true) :
 Represents J recorded (∑x∈(univ:Finset s.Var).powerset.filter (fun x=>E⊆x),
 R1Support.eval (R1Circuit.translate t x (P4c.cnf s.cnfSource)) U) := by
 rw [←d.checked_separation s t hr E U,←program_separated s d r t E U hc]
 exact expressionCheck_sound J _ _ ha
end RestrictedRow
end OP04

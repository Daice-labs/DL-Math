import AssemblyArrays
open scoped BigOperators
namespace R1AssemblyPartition
noncomputable section
open Classical Finset
variable {G : Type*} [Fintype G] {I : G → Type*} [∀ g,Fintype (I g)]

def regroup : ((s : Sigma I) → Bool) ≃ ((g : G) → I g → Bool) where
 toFun x := fun g i => x ⟨g,i⟩
 invFun x := fun s => x s.1 s.2
 left_inv _ := rfl
 right_inv _ := rfl

theorem assignment_sum {K : Type*} [AddCommMonoid K]
    (f : ((s : Sigma I) → Bool) → K) :
    (∑ x : ((g : G) → I g → Bool), f (fun s => x s.1 s.2)) = ∑ x,f x := by
  exact (regroup.symm.sum_comp f)

theorem restricted_assignments {K : Type*} [AddCommMonoid K]
    (E : Sigma I → Prop) [DecidablePred E]
    (f : ((s : Sigma I) → Bool) → K) :
    (∑ x : ((g : G) → I g → Bool),
      if ∀ g i,E ⟨g,i⟩ → x g i=true then f (fun s => x s.1 s.2) else 0) =
    ∑ x : ((s : Sigma I) → Bool), if ∀ s,E s → x s=true then f x else 0 := by
  rw [← assignment_sum (fun x => if ∀ s,E s → x s=true then f x else 0)]
  apply sum_congr rfl
  intro x _
  have h : (∀ g i,E ⟨g,i⟩ → x g i=true) ↔ (∀ s : Sigma I,E s → x s.1 s.2=true) := by
    constructor
    · intro h s; exact h s.1 s.2
    · intro h g i; exact h ⟨g,i⟩
  simp only [h]

theorem clause_partition [DecidableEq G] {K : Type*} [CommMonoid K]
    (es : Finset Nat) (owner : Nat → G) (f : Nat → K) :
    (∏ g, ∏ e ∈ es.filter (fun e => owner e=g), f e) = ∏ e∈es,f e := by
  exact prod_fiberwise es owner f
#print axioms assignment_sum
#print axioms restricted_assignments
#print axioms clause_partition
end
end R1AssemblyPartition

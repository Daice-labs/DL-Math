import Enumeration
import Join
import Mathlib.Algebra.Polynomial.Degree.Support

open scoped BigOperators
namespace R1Recovery
open Finset Polynomial R1Circuit R1Enumeration
noncomputable section

def matrix (B M : Nat) (t : Fin M → ℚ) (order : Fin M → Nat) : Fin M → Fin (B+1) → ℚ :=
  fun j k => (taylor (t j) (X^k.val : Polynomial ℚ)).coeff (order j)

theorem jet_is_taylor (p : Polynomial ℚ) (B M : Nat) (hd : p.natDegree ≤ B)
    (t : Fin M → ℚ) (order : Fin M → Nat) (j : Fin M) :
    R1.jet B M (fun k => p.coeff k.val) (matrix B M t order) j =
      (taylor (t j) p).coeff (order j) := by
  have hp := p.as_sum_range_C_mul_X_pow' (by omega : p.natDegree < B+1)
  conv_rhs => rw [hp]
  simp only [map_sum,finsetSum_coeff,taylor_mul,taylor_C,coeff_C_mul]
  unfold R1.jet matrix
  exact Fin.sum_univ_eq_sum_range
    (fun i : Nat => p.coeff i * (taylor (t j) (X^i : Polynomial ℚ)).coeff (order j)) (B+1)

theorem recovered_constant {I : Type*} [DecidableEq I] (c : Circuit I)
    (A : Finset I) (B M q : Nat) (t : Fin M → ℚ) (order : Fin M → Nat)
    (w : Fin M → ℚ) (ho : ∀ j, order j ≤ q)
    (hd : (∑ x ∈ A.powerset, original c x).natDegree ≤ B)
    (hw : R1.dualCheck B M (matrix B M t order) w) :
    (∑ j, w j * enumerationLoop A (fun x => translate (t j) x c) q (order j)) =
      (∑ x ∈ A.powerset, original c x).eval 0 := by
  simp_rw [enumeration_taylor c A _ q _ (ho _)]
  simp_rw [← jet_is_taylor _ B M hd t order]
  rw [R1.dual_recovery B M _ _ w hw]
  exact coeff_zero_eq_eval_zero _

set_option pp.fullNames true
#print axioms jet_is_taylor
#print axioms recovered_constant
end
end R1Recovery

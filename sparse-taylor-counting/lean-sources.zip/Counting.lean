import Recovery
import AssemblySource
import Mathlib.Data.Finset.Powerset
open scoped BigOperators
namespace P4c
noncomputable section
open Classical Finset Polynomial R1Circuit R1Enumeration
variable {I G : Type*} [DecidableEq I] [Fintype G] [DecidableEq G]
variable {X Y : G → Type*} [∀ g, Fintype (X g)] [∀ g, Fintype (Y g)]
variable [∀ g, DecidableEq (Y g)]

def factored (key : ∀ g, X g → Y g)
    (w : (∀ g, Y g) → ∀ g, X g → Polynomial ℚ) : Polynomial ℚ :=
  ∑ y : (∀ g, Y g), ∏ g, ∑ x : X g, if key g x = y g then w y g x else 0

-- An explicit assignment equivalence supplies partition coverage, not a cardinality claim.
-- hlocal is a polynomial identity for ONE symbolic assignment; it is not a sum/count premise.
theorem factor_restricted (B E : Finset I) (c : Circuit I) (t : ℚ) (U : Finset I)
    (decode : (∀ g, X g) ≃ {x // x ∈ B.powerset})
    (key : ∀ g, X g → Y g)
    (w : (∀ g, Y g) → ∀ g, X g → Polynomial ℚ)
    (hlocal : ∀ x, (∏ g, w (fun g => key g (x g)) g (x g)) =
       if E ⊆ (decode x).val then R1Support.eval (translate t (decode x).val c) U else 0) :
    factored key w = ∑ x ∈ B.powerset.filter (fun x => E ⊆ x),
      R1Support.eval (translate t x c) U := by
  rw [factored, R1Join.measurement_fibres]
  simp_rw [hlocal]
  calc
    _ = ∑ x : {x // x ∈ B.powerset}, if E ⊆ x.val then R1Support.eval (translate t x.val c) U else 0 :=
      decode.sum_comp (fun x => if E ⊆ x.val then R1Support.eval (translate t x.val c) U else 0)
    _ = _ := by
      simp only [sum_filter]
      exact (Finset.sum_coe_sort B.powerset (fun x => if E ⊆ x then R1Support.eval (translate t x c) U else 0))

-- Scalar array entry, with exactly the contract's j/E/h/U ordering and signs.
def traceEntry (B : Finset I) (q k : Nat)
    (z : Finset I → Finset I → Polynomial ℚ) : ℚ :=
  ∑ j ∈ range (min q B.card + 1), ∑ E ∈ powersetCard j B,
    ∑ h ∈ range (j+1), ∑ U ∈ powersetCard h E,
      (-1 : ℚ)^(j-h) * (z E U).coeff k

theorem entry_taylor (B : Finset I) (c : Circuit I) (t : ℚ) (q k : Nat)
    (hk : k ≤ q) (z : Finset I → Finset I → Polynomial ℚ)
    (hz : ∀ E U, z E U = ∑ x ∈ B.powerset.filter (fun x => E ⊆ x),
       R1Support.eval (translate t x c) U) :
    traceEntry B q k z = (taylor t (∑ x ∈ B.powerset, original c x)).coeff k := by
  simp only [traceEntry, hz, finset_sum_coeff]
  exact enumeration_taylor c B t q k hk

-- End-to-end composition. All semantic and arithmetic obligations are visible.
-- No checker-success token or hash is a mathematical premise.
theorem count_from_designs (B : Finset I) (c : Circuit I)
    (satisfies : Finset I → Prop) [DecidablePred satisfies]
    (D M q : Nat) (points : Fin M → ℚ) (orders : Fin M → Nat)
    (dual : Fin M → ℚ) (values : Fin M → ℚ) (answer : ℚ)
    (decode : (∀ g, X g) ≃ {x // x ∈ B.powerset})
    (keys : Fin M → ∀ g, X g → Y g)
    (weights : Fin M → Finset I → Finset I → (∀ g, Y g) → ∀ g, X g → Polynomial ℚ)
    (hlocal : ∀ j E U x,
      (∏ g, weights j E U (fun g => keys j g (x g)) g (x g)) =
       if E ⊆ (decode x).val then R1Support.eval (translate (points j) (decode x).val c) U else 0)
    (hvalues : ∀ j, values j = traceEntry B q (orders j)
        (fun E U => factored (keys j) (weights j E U)))
    (horders : ∀ j, orders j ≤ q)
    (hdegree : (∑ x ∈ B.powerset, original c x).natDegree ≤ D)
    (hdual : R1.dualCheck D M (R1Recovery.matrix D M points orders) dual)
    (hanswer : answer = ∑ j, dual j * values j)
    (hsource : ∀ x ∈ B.powerset, (original c x).eval 0 = if satisfies x then 1 else 0) :
    answer = ((B.powerset.filter satisfies).card : ℚ) := by
  have he : ∀ j, values j = enumerationLoop B (fun x => translate (points j) x c) q (orders j) := by
    intro j
    rw [hvalues j]
    unfold traceEntry enumerationLoop
    simp_rw [factor_restricted B _ c (points j) _ decode (keys j) _ (hlocal j _ _)]
    simp only [finset_sum_coeff]
  rw [hanswer]
  simp_rw [he]
  rw [R1Recovery.recovered_constant c B D M q points orders dual horders hdegree hdual]
  simp only [eval_finset_sum]
  calc
    _ = ∑ x ∈ B.powerset, if satisfies x then (1 : ℚ) else 0 := by
      apply sum_congr rfl
      intro x hx
      exact hsource x hx
    _ = _ := by simp

#print axioms factor_restricted
#print axioms entry_taylor
#print axioms count_from_designs
end
end P4c

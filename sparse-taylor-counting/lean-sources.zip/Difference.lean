import Mathlib.Algebra.BigOperators.Group.Finset.Powerset
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Rat.Cast.Defs
import Mathlib.Tactic.Ring

open scoped BigOperators
namespace R1Difference
open Finset
noncomputable section
variable {I : Type*} [DecidableEq I]

def difference (E : Finset I) (f : Finset I → ℚ) : ℚ :=
  ∑ U ∈ E.powerset, (-1 : ℚ) ^ (E \ U).card * f U

@[simp] theorem difference_empty (f : Finset I → ℚ) : difference ∅ f = f ∅ := by
  simp [difference]

theorem difference_congr (E : Finset I) (f g : Finset I → ℚ)
    (h : ∀ U ⊆ E, f U = g U) : difference E f = difference E g := by
  apply sum_congr rfl
  intro U hU
  rw [h U (mem_powerset.mp hU)]

theorem difference_sub (E : Finset I) (f g : Finset I → ℚ) :
    difference E (fun U => f U - g U) = difference E f - difference E g := by
  simp only [difference, mul_sub, sum_sub_distrib]

theorem difference_insert (a : I) (E : Finset I) (ha : a ∉ E)
    (f : Finset I → ℚ) :
    difference (insert a E) f = difference E (fun U => f (insert a U) - f U) := by
  unfold difference
  rw [sum_powerset_insert ha]
  rw [← sum_add_distrib]
  apply sum_congr rfl
  intro U hU
  have hUE := mem_powerset.mp hU
  have haU : a ∉ U := fun h => ha (hUE h)
  have hd : a ∉ E \ U := fun h => ha (mem_sdiff.mp h).1
  have h1 : (insert a E) \ U = insert a (E \ U) := by
    ext i
    simp only [mem_sdiff, mem_insert]
    constructor
    · rintro ⟨h, hu⟩
      rcases h with h | h
      · exact Or.inl h
      · exact Or.inr ⟨h,hu⟩
    · rintro (h | ⟨h,hu⟩)
      · subst i; exact ⟨Or.inl rfl, haU⟩
      · exact ⟨Or.inr h,hu⟩
  have h2 : (insert a E) \ (insert a U) = E \ U := by
    ext i
    simp only [mem_sdiff,mem_insert]
    constructor
    · rintro ⟨hi,hn⟩
      rcases hi with hi | hi
      · exact False.elim (hn (Or.inl hi))
      · exact ⟨hi,fun hu => hn (Or.inr hu)⟩
    · rintro ⟨hi,hu⟩
      refine ⟨Or.inr hi,?_⟩
      rintro (h | h)
      · subst i; exact ha hi
      · exact hu h
  rw [h1,h2,card_insert_of_notMem hd,pow_succ]
  ring

-- Full Boolean finite-difference reconstruction, for arbitrary functions.
theorem reconstruction (A : Finset I) (f : Finset I → ℚ) :
    (∑ E ∈ A.powerset, difference E f) = f A := by
  induction A using Finset.induction_on generalizing f with
  | empty => simp
  | @insert a A ha ih =>
    rw [sum_powerset_insert ha,ih]
    have h : (∑ E ∈ A.powerset, difference (insert a E) f) =
        ∑ E ∈ A.powerset, difference E (fun U => f (insert a U) - f U) := by
      apply sum_congr rfl
      intro E hE
      exact difference_insert a E (fun he => ha (mem_powerset.mp hE he)) f
    rw [h,ih]
    ring

def monomial (S U : Finset I) : ℚ := if S ⊆ U then 1 else 0

@[simp] theorem difference_zero (E : Finset I) : difference E (fun _ => 0) = 0 := by
  simp [difference]

-- A Boolean finite difference selects exactly the monomial with that support.
theorem difference_monomial (E S : Finset I) :
    difference E (monomial S) = if S = E then 1 else 0 := by
  induction E using Finset.induction_on generalizing S with
  | empty => simp [monomial]
  | @insert a E ha ih =>
    rw [difference_insert a E ha]
    by_cases haS : a ∈ S
    · have h : difference E (fun U => monomial S (insert a U) - monomial S U) =
          difference E (monomial (S.erase a)) := by
        apply difference_congr
        intro U hU
        have haU : a ∉ U := fun h => ha (hU h)
        have hn : ¬ S ⊆ U := fun h => haU (h haS)
        have he : S ⊆ insert a U ↔ S.erase a ⊆ U := by
          constructor
          · intro h i hi
            have z := h (mem_of_mem_erase hi)
            rcases mem_insert.mp z with z | z
            · exact False.elim ((mem_erase.mp hi).1 z)
            · exact z
          · intro h i hi
            by_cases hh : i = a
            · exact mem_insert.mpr (Or.inl hh)
            · exact mem_insert.mpr (Or.inr (h (mem_erase.mpr ⟨hh,hi⟩)))
        simp [monomial, hn, he]
      rw [h,ih]
      have he : S.erase a = E ↔ S = insert a E := by
        constructor
        · intro h; rw [← h, insert_erase haS]
        · intro h; rw [h,erase_insert ha]
      simp only [he]
    · have h : difference E (fun U => monomial S (insert a U) - monomial S U) = 0 := by
        rw [← difference_zero E]
        apply difference_congr
        intro U hU
        have he : S ⊆ insert a U ↔ S ⊆ U := by
          constructor
          · intro h i hi
            rcases mem_insert.mp (h hi) with hh | hh
            · subst i; exact False.elim (haS hi)
            · exact hh
          · intro h i hi; exact mem_insert.mpr (Or.inr (h hi))
        simp [monomial,he]
      rw [h]
      have hn : S ≠ insert a E := by intro h; apply haS; rw [h]; exact mem_insert_self _ _
      simp [hn]

set_option pp.fullNames true
#print axioms difference_monomial
#print axioms difference_insert
#print axioms reconstruction
end
end R1Difference

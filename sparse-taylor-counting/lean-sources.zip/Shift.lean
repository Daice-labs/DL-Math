import Multiply
import Mathlib.Algebra.Polynomial.HasseDeriv

open scoped BigOperators
namespace R1Shift
open Finset Polynomial R1PythonLoops R1Multiply
noncomputable section

def weight (t c : ℚ) (k j : Nat) : ℚ := c * (k.choose j : ℚ) * t^(k-j)
def inner (J k : Nat) (c t : ℚ) (out : Nat → ℚ) : Nat → ℚ :=
  accumulation (List.range (min k (J-1)+1)) id (weight t c k) out

theorem inner_correct (J k j : Nat) (c t : ℚ) (out : Nat → ℚ)
    (hJ : 0<J) (hj:j<J) : inner J k c t out j = out j + weight t c k j := by
  unfold inner
  rw [accumulation_correct,list_range]
  simp only [id_eq]
  have he : j<min k (J-1)+1 ↔ j≤k := by omega
  by_cases hk:j≤k
  · simp [he,hk,eq_comm]
  · have hz : weight t c k j=0 := by
      unfold weight
      rw [Nat.choose_eq_zero_of_lt (by omega),Nat.cast_zero,mul_zero,zero_mul]
    simp [he,hk,hz,eq_comm]

def executeRows (rows : List (Nat × ℚ)) (J : Nat) (t : ℚ) (out : Nat → ℚ) :=
  rows.foldl (fun out kc => if kc.2=0 then out else inner J kc.1 kc.2 t out) out

theorem rows_correct (rows : List (Nat × ℚ)) (J j : Nat) (t : ℚ)
    (out : Nat → ℚ) (hJ:0<J) (hj:j<J) :
    executeRows rows J t out j = out j + (rows.map (fun kc => weight t kc.2 kc.1 j)).sum := by
  induction rows generalizing out with
  | nil => simp [executeRows]
  | cons kc xs ih =>
    rcases kc with ⟨k,c⟩
    change executeRows xs J t (if c=0 then out else inner J k c t out) j = _
    rw [ih]
    by_cases hc:c=0
    · simp [hc,weight]
    · simp [hc,inner_correct J k j c t out hJ hj,add_assoc]

def polynomial (rows : List (Nat × ℚ)) : Polynomial ℚ :=
  (rows.map (fun kc => monomial kc.1 kc.2)).sum

theorem monomial_shift (k j : Nat) (c t : ℚ) :
    (taylor t (monomial k c)).coeff j = weight t c k j := by
  rw [taylor_coeff,hasseDeriv_monomial,eval_monomial]
  unfold weight
  ring

theorem rows_polynomial (rows : List (Nat × ℚ)) (t : ℚ) (j : Nat) :
    (taylor t (polynomial rows)).coeff j =
      (rows.map (fun kc => weight t kc.2 kc.1 j)).sum := by
  unfold polynomial
  rw [map_list_sum]
  simp only [List.map_map,Function.comp_def,coeff_list_sum_map,monomial_shift]

def enumerate (cs : List ℚ) : List (Nat × ℚ) := (List.range cs.length).zip cs

def pshift (cs : List ℚ) (t : ℚ) (J : Nat) : Nat → ℚ :=
  executeRows (enumerate cs) J t (fun _ => 0)

theorem pshift_correct (cs : List ℚ) (t : ℚ) (J j : Nat) (hJ:0<J) (hj:j<J) :
    pshift cs t J j = (taylor t (polynomial (enumerate cs))).coeff j := by
  rw [pshift,rows_correct _ J j t _ hJ hj,rows_polynomial]
  simp

-- The two different index domains must not be silently conflated.
theorem inner_access (J k j : Nat) (hJ:0<J) (hj:j<min k (J-1)+1) :
    j<J ∧ j≤k := by omega

def setZero (out : Nat → ℚ) : Nat → ℚ := fun j => if j=0 then 0 else out j

def correction (cs : List ℚ) (t : ℚ) (J : Nat) : Nat → ℚ :=
  setZero (pshift cs t J)

theorem correction_correct (cs : List ℚ) (t : ℚ) (J j : Nat)
    (hJ:0<J) (hj:j<J) :
    correction cs t J j =
      (taylor t (polynomial (enumerate cs)) - C ((polynomial (enumerate cs)).eval t)).coeff j := by
  unfold correction setZero
  by_cases hz:j=0
  · subst j; simp
  · simp [hz,Ne.symm hz,coeff_C,pshift_correct cs t J j hJ hj]

set_option pp.fullNames true
#print axioms pshift_correct
#print axioms inner_access
#print axioms correction_correct
end
end R1Shift

import Tables
namespace R1TableSource
open R1Tables R1PythonLoops
noncomputable section
-- Typed supported program: fresh Boolean product, zip dictionary, guarded append.
inductive TableOp where
 | productZipGuardMeasureAppend

def execute (keys fixed : List Nat) (rows : List (Nat → Int))
    (_ : TableOp) : List Int → List Assignment :=
  (candidates keys).foldl (fun tab u =>
    if eligible fixed u then appendBucket (dictionaryMeasurement rows) tab u else tab)
    (fun _ => [])

theorem execute_correct (keys fixed : List Nat) (hn : keys.Nodup)
    (rows : List (Nat → Int)) (y : List Int) :
    execute keys fixed rows .productZipGuardMeasureAppend y = table keys fixed rows y := by
  unfold execute
  rw [← List.foldl_filter]
  change groupTable (dictionaryMeasurement rows)
    ((candidates keys).filter (eligible fixed)) (fun _ => []) y = _
  rw [group_table_correct, bucket_exact]
  simp only [List.nil_append]
  apply List.filter_congr
  intro u hu
  have hc := (List.mem_filter.mp hu).1
  rw [admitted_measurement_correct keys hn rows u hc]

theorem execute_members (keys fixed : List Nat) (hn : keys.Nodup)
    (rows : List (Nat → Int)) (y : List Int) (u : Assignment) :
    u ∈ execute keys fixed rows .productZipGuardMeasureAppend y ↔
    (∃ bits : List Bool, bits.length = keys.length ∧ keys.zip bits = u) ∧
    (∀ i ∈ fixed, lookup i u ≠ some false) ∧ y = measurement rows u := by
  rw [execute_correct keys fixed hn rows y, bucket_member_iff]

theorem execute_nodup (keys fixed : List Nat) (hn : keys.Nodup)
    (rows : List (Nat → Int)) (y : List Int) :
    (execute keys fixed rows .productZipGuardMeasureAppend y).Nodup := by
  rw [execute_correct keys fixed hn rows y]
  exact bucket_nodup keys fixed rows y
#print axioms execute_correct
#print axioms execute_members
#print axioms execute_nodup
end
end R1TableSource

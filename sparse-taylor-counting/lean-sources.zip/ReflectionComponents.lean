import Mathlib
set_option maxHeartbeats 0
open scoped BigOperators

namespace OP03Reflection

def unitJet (r : Nat) : ℚ := if r=0 then 1 else 0
def linearJet (t : ℚ) (r : Nat) : ℚ := if r=0 then t else if r=1 then 1 else 0

/-- These are the actual first two Taylor-matrix columns used by Recovery.lean. -/
theorem unitJet_eq_taylor_coeff (t : ℚ) (r : Nat) :
    unitJet r = (Polynomial.taylor t (1 : Polynomial ℚ)).coeff r := by
  rw [Polynomial.taylor_one, Polynomial.coeff_C]
  rfl

theorem linearJet_eq_taylor_coeff (t : ℚ) (r : Nat) :
    linearJet t r = (Polynomial.taylor t (Polynomial.X : Polynomial ℚ)).coeff r := by
  rw [Polynomial.taylor_X, Polynomial.coeff_add]
  simp only [Polynomial.coeff_X, Polynomial.coeff_C, linearJet]
  split_ifs <;> first | omega | ring

lemma linearJet_nonneg (t : ℚ) (ht : 0≤t) (r : Nat) : 0≤linearJet t r := by
  unfold linearJet
  split_ifs <;> linarith

lemma remainderJet_nonneg (t : ℚ) (ht : 1≤t) (r : Nat) :
    0 ≤ linearJet t r-unitJet r := by
  unfold linearJet unitJet
  split_ifs <;> linarith

theorem signed_recovery_obstruction {ι : Type} [Fintype ι]
    (t w : ι → ℚ) (r : ι → Nat)
    (ht : ∀i,1≤t i)
    (h0 : (∑i,w i*unitJet (r i))=1)
    (h1 : (∑i,w i*linearJet (t i) (r i))=0) :
    (∀i,0≤linearJet (t i) (r i)-unitJet (r i)) ∧
    (∑i,w i*(linearJet (t i) (r i)-unitJet (r i))) = -1 := by
  constructor
  · intro i; exact remainderJet_nonneg _ (ht i) _
  · simp_rw [mul_sub]
    rw [Finset.sum_sub_distrib,h1,h0]
    norm_num

theorem exact_recovery_requires_negative_weight {ι : Type} [Fintype ι]
    (t w : ι → ℚ) (r : ι → Nat)
    (ht : ∀i,0<t i)
    (h0 : (∑i,w i*unitJet (r i))=1)
    (h1 : (∑i,w i*linearJet (t i) (r i))=0) :
    ∃i,w i<0 := by
  classical
  by_contra hn
  have hw : ∀i,0≤w i := by simpa only [not_exists,not_lt] using hn
  have hpos : ∀i,0≤w i*linearJet (t i) (r i) := by
    intro i
    exact mul_nonneg (hw i) (linearJet_nonneg _ (le_of_lt (ht i)) _)
  have hz : ∀i,w i*linearJet (t i) (r i)=0 := by
    intro i
    have hi := Finset.single_le_sum (fun j _ => hpos j) (Finset.mem_univ i)
    rw [h1] at hi
    exact le_antisymm hi (hpos i)
  have hterm : ∀i,w i*unitJet (r i)=0 := by
    intro i
    by_cases hr : r i=0
    · have hi : w i*t i=0 := by simpa [linearJet,hr] using hz i
      have hiw : w i=0 := (mul_eq_zero.mp hi).resolve_right (ne_of_gt (ht i))
      simp [hiw]
    · simp [unitJet,hr]
  have : (∑i,w i*unitJet (r i))=0 := by simp_rw [hterm]; simp
  rw [h0] at this
  norm_num at this

section Endpoint
variable {G Y : Type} [Fintype G] [Fintype Y]
variable {I : G → Type} [∀g,Fintype (I g)]

def tableTotal (A : Y → ∀g,I g → ℚ) : ℚ := ∑y,∏g,∑u,A y g u

theorem selected_product_le_tableTotal
    (A : Y → ∀g,I g → ℚ) (hA : ∀y g u,0≤A y g u)
    (y : Y) (u : ∀g,I g) :
    (∏g,A y g (u g)) ≤ tableTotal A := by
  classical
  have hl : ∀g,A y g (u g) ≤ ∑v,A y g v := by
    intro g
    exact Finset.single_le_sum (fun v _ => hA y g v) (Finset.mem_univ (u g))
  have hp : (∏g,A y g (u g)) ≤ ∏g,∑v,A y g v := by
    exact Finset.prod_le_prod (fun g _=>hA y g (u g)) (fun g _=>hl g)
  have hs : (∏g,∑v,A y g v) ≤ tableTotal A := by
    unfold tableTotal
    refine Finset.single_le_sum (s := Finset.univ)
      (f := fun yy : Y => ∏g,∑v,A yy g v) ?_ (Finset.mem_univ y)
    intro yy _
    apply Finset.prod_nonneg
    intro g _
    exact Finset.sum_nonneg (fun v _=>hA yy g v)
  exact hp.trans hs

theorem zero_table_has_dead_group
    (A : Y → ∀g,I g → ℚ) (hA : ∀y g u,0≤A y g u)
    (hzero : tableTotal A=0) (y : Y) :
    ∃g,∀u,A y g u=0 := by
  classical
  have hnonneg : ∀yy,(0 : ℚ)≤∏g,∑u,A yy g u := by
    intro yy
    exact Finset.prod_nonneg (fun g _ => Finset.sum_nonneg (fun u _=>hA yy g u))
  have hle := Finset.single_le_sum (s := Finset.univ)
    (f := fun yy : Y => ∏g,∑u,A yy g u) (fun yy _=>hnonneg yy) (Finset.mem_univ y)
  change (∏g,∑u,A y g u) ≤ tableTotal A at hle
  rw [hzero] at hle
  have hp : (∏g,∑u,A y g u)=0 := le_antisymm hle (hnonneg y)
  obtain ⟨g,_,hg⟩ := Finset.prod_eq_zero_iff.mp hp
  refine ⟨g,?_⟩
  intro u
  have hu := Finset.single_le_sum (s := Finset.univ)
    (f := fun v : I g => A y g v) (fun v _=>hA y g v) (Finset.mem_univ u)
  rw [hg] at hu
  exact le_antisymm hu (hA y g u)

/-- X need not be finite: no global assignment enumeration occurs here.
The local-source bridge and nonnegative endpoint factors are explicit premises.
They are not asserted for general signed recovered traces. -/
theorem endpoint_witness_reflection {X : Type}
    (A : Y → ∀g,I g → ℚ) (hA : ∀y g u,0≤A y g u)
    (sat : X → Prop) (key : X → Y) (choice : ∀_x:X,∀g,I g)
    (hlocal : ∀x,sat x → (∏g,A (key x) g (choice x g))=1)
    (hzero : tableTotal A=0) : ∀x,¬sat x := by
  intro x hx
  have h := selected_product_le_tableTotal A hA (key x) (choice x)
  rw [hlocal x hx,hzero] at h
  norm_num at h

end Endpoint

def pointCount (t : ℚ) := 2*t+2*t^2
theorem actual_control_recovery :
    pointCount 1=4 ∧ pointCount 2=12 ∧ pointCount 3=24 ∧
    3*pointCount 1-3*pointCount 2+pointCount 3=0 := by
  norm_num [pointCount]

#print axioms linearJet_nonneg
#print axioms unitJet_eq_taylor_coeff
#print axioms linearJet_eq_taylor_coeff
#print axioms remainderJet_nonneg
#print axioms signed_recovery_obstruction
#print axioms exact_recovery_requires_negative_weight
#print axioms selected_product_le_tableTotal
#print axioms zero_table_has_dead_group
#print axioms endpoint_witness_reflection
#print axioms actual_control_recovery
end OP03Reflection

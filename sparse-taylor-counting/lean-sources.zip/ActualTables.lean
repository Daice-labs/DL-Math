import TableSource
namespace R1ActualTables
noncomputable section
open R1Tables R1TableSource
def extracted : TableOp := .productZipGuardMeasureAppend
theorem actual_table (keys fixed : List Nat) (hn:keys.Nodup)
 (rows : List (Nat → Int)) (y : List Int) (u : Assignment) :
 u ∈ execute keys fixed rows extracted y ↔
 (∃ bits : List Bool, bits.length=keys.length ∧ keys.zip bits=u) ∧
 (∀ i∈fixed, lookup i u ≠ some false) ∧ y=measurement rows u := by
 exact execute_members keys fixed hn rows y u
theorem actual_no_duplicates (keys fixed : List Nat) (hn:keys.Nodup)
 (rows : List (Nat → Int)) (y : List Int) :
 (execute keys fixed rows extracted y).Nodup := execute_nodup keys fixed hn rows y
#print axioms actual_table
#print axioms actual_no_duplicates
end
end R1ActualTables

import Std
namespace R1Certificate
-- Executable, closed finite endpoint. No native_decide or Python output is authority.
abbrev CNF := List (List (Nat × Bool))
def sat (xs : List Bool) (f : CNF) : Bool :=
  f.all (fun c => c.any (fun l => xs[l.1]?.getD false == l.2))
def assignments : Nat → List (List Bool)
  | 0 => [[]]
  | n+1 => (assignments n).map (false :: ·) ++ (assignments n).map (true :: ·)
def modelCount (n : Nat) (f : CNF) : Nat :=
  ((assignments n).filter (fun xs => sat xs f)).length

def accepted (n : Nat) (f : CNF) (answer : Nat) : Bool := modelCount n f == answer

theorem accepted_sound (n : Nat) (f : CNF) (answer : Nat)
    (h : accepted n f answer = true) :
    ((assignments n).filter (fun xs => sat xs f)).length = answer := by
  simpa [accepted,modelCount] using h

theorem assignment_length (n : Nat) : ∀ xs ∈ assignments n, xs.length = n := by
  induction n with
  | zero => simp [assignments]
  | succ n ih =>
    intro xs hx
    simp only [assignments,List.mem_append,List.mem_map] at hx
    rcases hx with ⟨ys,hy,rfl⟩ | ⟨ys,hy,rfl⟩ <;> simp [ih ys hy]

theorem assignment_complete (xs : List Bool) : xs ∈ assignments xs.length := by
  induction xs with
  | nil => simp [assignments]
  | cons b xs ih =>
    simp only [List.length_cons,assignments,List.mem_append,List.mem_map]
    cases b
    · exact Or.inl ⟨xs,ih,rfl⟩
    · exact Or.inr ⟨xs,ih,rfl⟩

theorem assignment_nodup (n : Nat) : (assignments n).Nodup := by
  induction n with
  | zero => simp [assignments]
  | succ n ih =>
    rw [assignments, List.nodup_append]
    constructor
    · simpa only [List.Nodup, List.pairwise_map, ne_eq, List.cons.injEq,
        true_and] using ih
    constructor
    · simpa only [List.Nodup, List.pairwise_map, ne_eq, List.cons.injEq,
        true_and] using ih
    · intro a ha b hb
      obtain ⟨x,_,rfl⟩ := List.mem_map.mp ha
      obtain ⟨y,_,rfl⟩ := List.mem_map.mp hb
      simp

#print axioms accepted_sound
#print axioms assignment_length
#print axioms assignment_complete
#print axioms assignment_nodup
end R1Certificate

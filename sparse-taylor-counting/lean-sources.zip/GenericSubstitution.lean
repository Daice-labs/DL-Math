import FinitePartition
namespace OP04
open scoped BigOperators
open Classical Finset Polynomial P4c R1Circuit
noncomputable section
variable {G:Type*} [Fintype G] [DecidableEq G]
variable {V:G→Type*} [∀g,Fintype (V g)] [∀g,DecidableEq (V g)]
variable {M:G→Type*} [∀g,Fintype (M g)]
def measurement (rows:∀g,M g→V g→ℚ) (g:G) (u:Finset (V g)) (k:M g) : ℚ := ∑i∈u,rows g k i

def ownedInput (p:Sigma V→Polynomial ℚ) (t:ℚ) (owner:G)
 (lam:∀h,M h→ℚ) (y:∀h,M h→ℚ) (u:Finset (V owner)) (U:Finset (Sigma V)) : Polynomial ℚ :=
 C ((∑i∈u,(p ⟨owner,i⟩).eval t) + ∑h∈univ.erase owner,∑k,lam h k*y h k) +
 R1Support.eval (corrections t (canonicalForm univ p)) U

theorem value_partition (p:Sigma V→Polynomial ℚ) (t:ℚ) (u:∀g,Finset (V g)) :
 (formValue (canonicalForm univ p) (glue u)).eval t = ∑g,∑i∈u g,(p ⟨g,i⟩).eval t := by
 rw [canonical_value,eval_finsetSum]
 simp [Fintype.sum_sigma,glue,P4c.eval_ite]

theorem row_space_substitution (p:Sigma V→Polynomial ℚ) (t:ℚ) (owner:G)
 (rows:∀g,M g→V g→ℚ) (lam:∀h,M h→ℚ)
 (hrow:∀h,h≠owner→∀i:V h,(p ⟨h,i⟩).eval t = ∑k,lam h k*rows h k i)
 (u:∀g,Finset (V g)) (U:Finset (Sigma V)) (v:Sigma V) (sign:Bool) :
 ownedInput p t owner lam (fun h=>measurement rows h (u h)) (u owner) U =
 shiftedInput t (glue u) U (v,sign,canonicalForm univ p) := by
 have remote (h:G) (hne:h≠owner) :
  (∑i∈u h,(p ⟨h,i⟩).eval t) = ∑k,lam h k*measurement rows h (u h) k := by
  simp_rw [hrow h hne]
  rw [sum_comm]
  simp only [measurement,mul_sum]
 unfold ownedInput shiftedInput
 rw [value_partition]
 congr 2
 rw [← sum_erase_add _ _ (mem_univ owner)]
 rw [add_comm]
 congr 1
 apply sum_congr rfl
 intro h hh
 exact (remote h (mem_erase.mp hh).1).symm
end
end OP04

import Source
open scoped BigOperators
namespace P4c
noncomputable section
open Classical Finset Polynomial R1Circuit
variable {I : Type*} [DecidableEq I]

def clausePoly (cl : List (SourceLit I)) (input : SourceLit I → Polynomial ℚ) : Polynomial ℚ :=
  1 - (cl.map (fun l => if l.2.1 then 1-input l else input l)).prod

def shiftedInput (t : ℚ) (x U : Finset I) (l : SourceLit I) : Polynomial ℚ :=
  C ((formValue l.2.2 x).eval t) + R1Support.eval (corrections t l.2.2) U

theorem failure_translated (cl : List (SourceLit I)) (t : ℚ) (x U : Finset I) :
    R1Support.eval (translate t x (failure cl)) U =
    (cl.map (fun l => if l.2.1 then 1-shiftedInput t x U l else shiftedInput t x U l)).prod := by
  induction cl with
  | nil => simp [failure,translate,R1Support.eval]
  | cons l ls ih =>
    rcases l with ⟨v,b,f⟩
    cases b <;> simp [failure,translate,R1Support.eval,shiftedInput,sub_eq_add_neg] at *
    all_goals exact Or.inl ih

theorem cnf_translated (cls : List (List (SourceLit I))) (t : ℚ) (x U : Finset I) :
    R1Support.eval (translate t x (cnf cls)) U =
    (cls.map (fun cl => clausePoly cl (shiftedInput t x U))).prod := by
  induction cls with
  | nil => simp [cnf,translate,R1Support.eval]
  | cons cl cls ih =>
    change (1 + -R1Support.eval (translate t x (failure cl)) U) *
      R1Support.eval (translate t x (cnf cls)) U = _
    rw [failure_translated,ih]
    simp [clausePoly,sub_eq_add_neg]

theorem clause_congr (cl : List (SourceLit I)) (a b : SourceLit I → Polynomial ℚ)
 (h : ∀ l∈cl, a l=b l) : clausePoly cl a=clausePoly cl b := by
 unfold clausePoly
 congr 2
 apply List.map_congr_left
 intro l hl
 rw [h l hl]

-- Clause-local substitution composes through any number of groups without assignments enumeration.
theorem grouped_local_identity {G : Type*} [Fintype G] [DecidableEq G]
    (cls : G → List (List (SourceLit I))) (t : ℚ) (x U : Finset I)
    (input : G → SourceLit I → Polynomial ℚ)
    (hinput : ∀ g cl, cl∈cls g → ∀ l∈cl, input g l=shiftedInput t x U l) :
    (∏ g, ((cls g).map (fun cl => clausePoly cl (input g))).prod) =
    R1Support.eval (translate t x (cnf ((Finset.univ : Finset G).toList.flatMap cls))) U := by
  rw [cnf_translated]
  have flatProd (ls : List G) (f : G → List (Polynomial ℚ)) :
      (ls.flatMap f).prod = (ls.map (fun a => (f a).prod)).prod := by
    induction ls with
    | nil => rfl
    | cons a ls ih => simp [List.flatMap_cons,List.prod_append,ih]
  rw [List.map_flatMap,flatProd]
  simp only [Finset.prod_map_toList]
  apply prod_congr rfl
  intro g _
  congr 1
  apply List.map_congr_left
  intro cl hc
  exact clause_congr cl _ _ (hinput g cl hc)
#print axioms cnf_translated
#print axioms grouped_local_identity
end
end P4c

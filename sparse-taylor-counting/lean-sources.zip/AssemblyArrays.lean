import Wiring
import SourceLoops
namespace R1AssemblyArrays
open Polynomial R1PythonLoops R1Multiply
noncomputable section
open scoped BigOperators

def Represents (J : Nat) (a : Nat → ℚ) (p : Polynomial ℚ) := ∀ k,k<J → a k=p.coeff k

theorem multiply_preserves (J : Nat) (a b : Nat → ℚ) (p r : Polynomial ℚ)
    (ha:Represents J a p) (hb:Represents J b r) :
    Represents J (zmulLoop J a b) (p*r) := by
  intro k hk
  have he : zmulLoop J a b k = zmulLoop J p.coeff r.coeff k := by
    rw [zmul_loop_correct,pairs_sum,zmul_loop_correct,pairs_sum]
    apply Finset.sum_congr rfl
    intro i hi
    apply Finset.sum_congr rfl
    intro j hj
    have hi' : i<J := Finset.mem_range.mp hi
    have hj' : j<J := by have := Finset.mem_range.mp hj; omega
    rw [ha i hi',hb j hj']
  rw [he]
  exact convolution J p r k hk

inductive Expr where
 | leaf : Polynomial ℚ → Expr
 | add : Expr → Expr → Expr
 | mul : Expr → Expr → Expr
 | neg : Expr → Expr

def meaning : Expr → Polynomial ℚ
 | .leaf p => p
 | .add a b => meaning a+meaning b
 | .mul a b => meaning a*meaning b
 | .neg a => -meaning a

def execute (J : Nat) : Expr → Nat → ℚ
 | .leaf p => p.coeff
 | .add a b => fun k => execute J a k+execute J b k
 | .mul a b => zmulLoop J (execute J a) (execute J b)
 | .neg a => fun k => -execute J a k

theorem execute_correct (J : Nat) (e : Expr) : Represents J (execute J e) (meaning e) := by
  induction e with
  | leaf p => intro k _; rfl
  | add a b ha hb => intro k hk; simp [execute,meaning,ha k hk,hb k hk]
  | mul a b ha hb => exact multiply_preserves J _ _ _ _ ha hb
  | neg a ha => intro k hk; simp [execute,meaning,ha k hk]
#print axioms multiply_preserves
#print axioms execute_correct
end
end R1AssemblyArrays

import GenericSeparation
import FiniteCoefficients
namespace OP04
open scoped BigOperators
open Finset Polynomial P4c
-- All function domains below are explicitly finite; coefficient sequences are lists.
structure FiniteSource where
 groups : Nat
 sizes : Fin groups → Nat
 occurrences : Nat
 clauses : Fin groups → List (List (Fin occurrences))
 vars : Fin occurrences → (Sigma (fun g:Fin groups=>Fin (sizes g))) × Bool
 coefficients : Fin occurrences → (Sigma (fun g:Fin groups=>Fin (sizes g))) → List ℚ
namespace FiniteSource
abbrev Group (s:FiniteSource) := Fin s.groups
abbrev Var (s:FiniteSource) := Sigma (fun g:s.Group=>Fin (s.sizes g))
abbrev Occ (s:FiniteSource) := Fin s.occurrences
noncomputable def forms (s:FiniteSource) (o:s.Occ) (i:s.Var) := polynomial (s.coefficients o i)
noncomputable def cnfSource (s:FiniteSource) := source s.clauses s.vars s.forms

def zeroCheck (s:FiniteSource) : Bool := decide (∀o:s.Occ,∀i:s.Var,evaluate (s.coefficients o i) 0 = if i=(s.vars o).1 then 1 else 0)
def lengthCheck (s:FiniteSource) (R:Nat) : Bool := decide (∀o:s.Occ,∀i:s.Var,(s.coefficients o i).length≤R+1)
end FiniteSource
structure FiniteDesign (s:FiniteSource) where
 measurements : s.Group → Nat
 rows : ∀g:s.Group,Fin (measurements g)→Fin (s.sizes g)→ℚ
 lam : s.Occ→∀h:s.Group,Fin (measurements h)→ℚ
 fibres : ∀g:s.Group,List ((Fin (measurements g)→ℚ) × List (Finset (Fin (s.sizes g))))
namespace FiniteDesign

def rowCheck (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) : Bool := decide
 (∀g:s.Group,∀os∈s.clauses g,∀o∈os,∀h:s.Group,h≠g→∀i:Fin (s.sizes h),
 evaluate (s.coefficients o ⟨h,i⟩) t = ∑k:Fin (d.measurements h),d.lam o h k*d.rows h k i)

def measure (s:FiniteSource) (d:FiniteDesign s) (g:s.Group) (u:Finset (Fin (s.sizes g))) (k:Fin (d.measurements g)) : ℚ := ∑i∈u,d.rows g k i

def fibreCheck (s:FiniteSource) (d:FiniteDesign s) : Bool := decide (∀g:s.Group,
 ((d.fibres g).map Prod.fst).Nodup ∧
 ((d.fibres g).map Prod.fst).toFinset = (univ:Finset (Finset (Fin (s.sizes g)))).image (d.measure s g) ∧
 ∀entry∈d.fibres g,entry.2.Nodup ∧ entry.2.toFinset = (univ:Finset (Finset (Fin (s.sizes g)))).filter (fun u=>d.measure s g u=entry.1))

theorem rowCheck_sound (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (h:d.rowCheck s t=true) :
 ∀g:s.Group,∀os∈s.clauses g,∀o∈os,∀h:s.Group,h≠g→∀i:Fin (s.sizes h),
 (s.forms o ⟨h,i⟩).eval t = ∑k:Fin (d.measurements h),d.lam o h k*d.rows h k i := by
 simpa only [rowCheck,decide_eq_true_eq,FiniteSource.forms,eval_polynomial] using h

theorem checked_separation (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (h:d.rowCheck s t=true)
 (E U:Finset s.Var) :
 separated s.clauses s.vars s.forms t d.rows d.lam E U =
 ∑x∈(univ:Finset s.Var).powerset.filter (fun x=>E⊆x),
 R1Support.eval (R1Circuit.translate t x (P4c.cnf s.cnfSource)) U :=
 separation s.clauses s.vars s.forms t d.rows d.lam (rowCheck_sound s d t h) E U
end FiniteDesign
end OP04

import GenericSubstitution
namespace OP04
open scoped BigOperators
open Classical Finset Polynomial P4c R1Circuit
noncomputable section
variable {G:Type*} [Fintype G] [DecidableEq G]
variable {V:G→Type*} [∀g,Fintype (V g)] [∀g,DecidableEq (V g)]
variable {M:G→Type*} [∀g,Fintype (M g)] [∀g,DecidableEq (M g)]
variable {O:Type*}
def literal (lit:O→Sigma V×Bool) (p:O→Sigma V→Polynomial ℚ) (o:O) : SourceLit (Sigma V) :=
 ((lit o).1,(lit o).2,canonicalForm univ (p o))
def source (cls:G→List (List O)) (lit:O→Sigma V×Bool) (p:O→Sigma V→Polynomial ℚ) : List (List (SourceLit (Sigma V))) :=
 (univ:Finset G).toList.flatMap (fun g=>(cls g).map (List.map (literal lit p)))
def localClause (os:List O) (lit:O→Sigma V×Bool) (input:O→Polynomial ℚ) : Polynomial ℚ :=
 1-(os.map (fun o=>if (lit o).2 then 1-input o else input o)).prod
def localFactor (cls:G→List (List O)) (lit:O→Sigma V×Bool) (p:O→Sigma V→Polynomial ℚ)
 (t:ℚ) (lam:O→∀h,M h→ℚ) (y:∀h,M h→ℚ) (g:G) (u:Finset (V g)) (U:Finset (Sigma V)) : Polynomial ℚ :=
 ((cls g).map (fun os=>localClause os lit (fun o=>ownedInput (p o) t g (lam o) y u U))).prod

theorem localFactor_source (cls:G→List (List O)) (lit:O→Sigma V×Bool) (p:O→Sigma V→Polynomial ℚ)
 (t:ℚ) (rows:∀g,M g→V g→ℚ) (lam:O→∀h,M h→ℚ)
 (hr:∀g,∀os∈cls g,∀o∈os,∀h,h≠g→∀i:V h,(p o ⟨h,i⟩).eval t=∑k,lam o h k*rows h k i)
 (u:∀g,Finset (V g)) (U:Finset (Sigma V)) :
 (∏g,localFactor cls lit p t lam (fun h=>measurement rows h (u h)) g (u g) U) =
 R1Support.eval (translate t (glue u) (cnf (source cls lit p))) U := by
 rw [cnf_translated]
 have flatProd (ls:List G) (f:G→List (Polynomial ℚ)) :
  (ls.flatMap f).prod=(ls.map (fun g=>(f g).prod)).prod := by
  induction ls with
  | nil=>rfl
  | cons a ls ih=>simp [List.flatMap_cons,List.prod_append,ih]
 simp only [source,List.map_flatMap,List.map_map]
 rw [flatProd]
 simp only [Finset.prod_map_toList]
 apply prod_congr rfl;intro g _
 unfold localFactor
 congr 1
 apply List.map_congr_left;intro os hos
 dsimp only [Function.comp_apply]
 unfold localClause clausePoly
 rw [List.map_map]
 congr 2
 apply List.map_congr_left;intro o ho
 have hx:=row_space_substitution (p o) t g rows (lam o) (hr g os hos o ho) u U (lit o).1 (lit o).2
 simp only [literal] at *
 rw [hx]
 rfl

-- Finite images of local assignments, not an assumed list of valid keys.
def keySet (rows:∀g,M g→V g→ℚ) (g:G) : Finset (M g→ℚ) :=
 (univ:Finset (Finset (V g))).image (measurement rows g)
def key (rows:∀g,M g→V g→ℚ) (g:G) (u:Finset (V g)) : ↥(keySet rows g) :=
 ⟨measurement rows g u,mem_image.mpr ⟨u,mem_univ _,rfl⟩⟩
def separated (cls:G→List (List O)) (lit:O→Sigma V×Bool) (p:O→Sigma V→Polynomial ℚ)
 (t:ℚ) (rows:∀g,M g→V g→ℚ) (lam:O→∀h,M h→ℚ) (E U:Finset (Sigma V)) : Polynomial ℚ :=
 factored (key rows) (fun y g u=>if restrict E g⊆u then localFactor cls lit p t lam (fun h=>(y h).val) g u U else 0)

theorem separation (cls:G→List (List O)) (lit:O→Sigma V×Bool) (p:O→Sigma V→Polynomial ℚ)
 (t:ℚ) (rows:∀g,M g→V g→ℚ) (lam:O→∀h,M h→ℚ)
 (hr:∀g,∀os∈cls g,∀o∈os,∀h,h≠g→∀i:V h,(p o ⟨h,i⟩).eval t=∑k,lam o h k*rows h k i)
 (E U:Finset (Sigma V)) :
 separated cls lit p t rows lam E U = ∑x∈(univ:Finset (Sigma V)).powerset.filter (fun x=>E⊆x),
 R1Support.eval (translate t x (cnf (source cls lit p))) U := by
 apply factor_restricted univ E _ t U decode (key rows)
 intro u
 simp only [Fintype.prod_ite_zero]
 change (if ∀g,restrict E g⊆u g then ∏g,localFactor cls lit p t lam (fun h=>measurement rows h (u h)) g (u g) U else 0) = _
 simp only [←restriction_iff,localFactor_source cls lit p t rows lam hr u U,decode]
 rfl
end
end OP04

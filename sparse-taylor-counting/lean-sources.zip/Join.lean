import Circuit
import Mathlib.Algebra.BigOperators.GroupWithZero.Finset

open scoped BigOperators
namespace R1Join
noncomputable section
open Classical Finset

-- Coupled measurements are allowed: weights can depend on the entire tuple y.
-- Fibre enumeration counts each original assignment exactly once.
theorem measurement_fibres {G : Type*} [Fintype G] [DecidableEq G]
    {X Y : G → Type*} [∀ g, Fintype (X g)] [∀ g, Fintype (Y g)]
    [∀ g, DecidableEq (Y g)] {K : Type*} [CommSemiring K]
    (key : ∀ g, X g → Y g) (w : (∀ g,Y g) → ∀ g,X g → K) :
    (∑ y : (∀ g,Y g), ∏ g, ∑ x : X g, if key g x = y g then w y g x else 0) =
    ∑ x : (∀ g,X g), ∏ g, w (fun g => key g (x g)) g (x g) := by
  simp_rw [← R1.separated_join]
  rw [sum_comm]
  apply sum_congr rfl
  intro x _
  simp_rw [Fintype.prod_ite_zero]
  have he : ∀ y : (∀ g,Y g), (∀ g, key g (x g)=y g) ↔ y=(fun g => key g (x g)) := by
    intro y
    constructor
    · intro h; funext g; exact (h g).symm
    · intro h; subst y; intro g; rfl
  simp_rw [he]
  simp

set_option pp.fullNames true
#print axioms measurement_fibres
end
end R1Join

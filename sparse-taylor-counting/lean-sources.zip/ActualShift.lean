import ShiftSource
namespace R1ActualShift
noncomputable section
open R1ShiftSource R1Shift R1FormDelta Polynomial
-- Emitted only after exact AST recognition and whole-engine pin validation.
def extractedShift : ShiftOp := .coefficients (.skipZero (.orders .addTerm))
def extractedForm : FormOp := .freshShift (.resetConstant .emit)
theorem actual_pshift (cs : List ℚ) (t : ℚ) (J j : Nat) (hJ:0<J) (hj:j<J) :
    executeShift cs t J extractedShift (fun _ => 0) j =
      (taylor t (polynomial (enumerate cs))).coeff j := by
  exact shift_program_correct cs t J j hJ hj

theorem actual_form_delta {K : Type*} [DecidableEq K]
    (rows : List (K × List ℚ)) (key : K) (cs : List ℚ)
    (h : inputMap rows key=some cs) (t : ℚ) (J : Nat) (hJ:0<J) :
    ∃ out, executeForms rows t J extractedForm key=some out ∧
      ∀ j, j<J → out j=(taylor t (polynomial (enumerate cs))-
        C ((polynomial (enumerate cs)).eval t)).coeff j := by
  exact form_program_correct rows key cs h t J hJ

theorem admitted_truncation_positive (degree points : Nat) : 0<(degree/points+1 : Nat) := Nat.zero_lt_succ _
#print axioms actual_pshift
#print axioms actual_form_delta
#print axioms admitted_truncation_positive
end
end R1ActualShift

import AssemblyPartition
namespace R1AssemblySource
noncomputable section
open R1AssemblyArrays R1Assembly Polynomial
open scoped BigOperators
open Classical Finset

def sumProgram {A : Type*} (xs : List A) (f : A → Expr) (a : Expr) : Expr :=
 xs.foldl (fun a x => .add a (f x)) a
def prodProgram {A : Type*} (xs : List A) (f : A → Expr) (a : Expr) : Expr :=
 xs.foldl (fun a x => .mul a (f x)) a

theorem sum_meaning {A : Type*} (xs : List A) (f : A → Expr) (a : Expr) :
 meaning (sumProgram xs f a)=meaning a+(xs.map (fun x => meaning (f x))).sum := by
 induction xs generalizing a with
 | nil => simp [sumProgram]
 | cons x xs ih =>
   change meaning (sumProgram xs f (.add a (f x))) = _
   rw [ih]; simp [meaning,add_assoc]
theorem prod_meaning {A : Type*} (xs : List A) (f : A → Expr) (a : Expr) :
 meaning (prodProgram xs f a)=meaning a*(xs.map (fun x => meaning (f x))).prod := by
 induction xs generalizing a with
 | nil => simp [prodProgram]
 | cons x xs ih =>
   change meaning (prodProgram xs f (.mul a (f x))) = _
   rw [ih]; simp [meaning,mul_assoc]

def sumAll {A : Type*} [Fintype A] (f : A → Expr) := sumProgram (univ : Finset A).toList f (.leaf 0)
def prodAll {A : Type*} [Fintype A] (f : A → Expr) := prodProgram (univ : Finset A).toList f (.leaf 1)
theorem sumAll_meaning {A : Type*} [Fintype A] (f : A → Expr) :
 meaning (sumAll f)=∑x,meaning (f x) := by
 simp [sumAll,sum_meaning,meaning]
theorem prodAll_meaning {A : Type*} [Fintype A] (f : A → Expr) :
 meaning (prodAll f)=∏x,meaning (f x) := by
 simp [prodAll,prod_meaning,meaning]

def complement (a : Expr) : Expr := .add (.leaf 1) (.neg a)
def clauseProgram (ls : List (Nat × Bool)) (input : Nat → Polynomial ℚ) : Expr :=
 complement (prodProgram ls (fun vb => complement
   (if vb.2 then .leaf (input vb.1) else complement (.leaf (input vb.1)))) (.leaf 1))
theorem clause_meaning (ls : List (Nat × Bool)) (input : Nat → Polynomial ℚ) :
 meaning (clauseProgram ls input)=clause ls input := by
 simp only [clauseProgram,complement,meaning,prod_meaning,one_mul,clause,sub_eq_add_neg]
 congr 3
 apply List.map_congr_left
 intro vb _
 cases vb.2 <;> rfl

variable {G : Type*} [Fintype G] [DecidableEq G] {X Y : G → Type*}
variable [∀g,Fintype (X g)] [∀g,Fintype (Y g)] [∀g,DecidableEq (Y g)]
def factorProgram (key : ∀g,X g → Y g) (cls : G → List (Nat × List (Nat × Bool)))
 (input : (∀g,Y g) → ∀g,X g → Nat → Nat → Polynomial ℚ) : Expr :=
 sumAll (fun y => prodAll (fun g => sumAll (fun x =>
   if key g x=y g then prodProgram (cls g)
     (fun ec => clauseProgram ec.2 (input y g x ec.1)) (.leaf 1) else .leaf 0)))

theorem program_meaning (key : ∀g,X g → Y g) (cls : G → List (Nat × List (Nat × Bool)))
 (input : (∀g,Y g) → ∀g,X g → Nat → Nat → Polynomial ℚ) :
 meaning (factorProgram key cls input)=
 ∑x : (∀g,X g), ∏g,(cls g |>.map (fun ec => clause ec.2 (input (fun g=>key g (x g)) g (x g) ec.1))).prod := by
 unfold factorProgram
 simp_rw [sumAll_meaning,prodAll_meaning]
 have h : ∀ y g (x : X g),
   meaning (if key g x=y g then prodProgram (cls g) (fun ec => clauseProgram ec.2 (input y g x ec.1)) (.leaf 1) else .leaf 0) =
   if key g x=y g then (cls g |>.map (fun ec => clause ec.2 (input y g x ec.1))).prod else 0 := by
   intro y g x
   split_ifs <;> simp only [prod_meaning,meaning,one_mul,clause_meaning]
 simp_rw [sumAll_meaning,h]
 exact R1Join.measurement_fibres key _

theorem program_coefficients (key : ∀g,X g → Y g) (cls : G → List (Nat × List (Nat × Bool)))
 (input : (∀g,Y g) → ∀g,X g → Nat → Nat → Polynomial ℚ) (J k : Nat) (hk:k<J) :
 execute J (factorProgram key cls input) k =
 (∑x : (∀g,X g), ∏g,(cls g |>.map (fun ec => clause ec.2 (input (fun g=>key g (x g)) g (x g) ec.1))).prod).coeff k := by
 rw [execute_correct J _ k hk,program_meaning]
set_option maxHeartbeats 800000 in
theorem wired_program_coefficients
 {I M : G → Type*} [∀g,Fintype (I g)] [∀g,Fintype (M g)]
 (row : ∀ g,M g → I g → ℚ) (vec : ∀ g,X g → I g → ℚ)
 (read : ∀ g,Y g → M g → ℚ) (key : ∀ g,X g → Y g)
 (p : Nat → Nat → ∀ g,I g → ℚ) (lam : Nat → Nat → ∀ g,M g → ℚ)
 (corr : Nat → Nat → Polynomial ℚ) (cls : G → List (Nat × List (Nat × Bool)))
 (hk : ∀ g u m,read g (key g u) m=∑ i,row g m i*vec g u i)
 (hp : ∀ g ec, ec∈cls g → ∀ vb∈ec.2, ∀ h,h≠g → ∀ i,
      p ec.1 vb.1 h i=∑ m,lam ec.1 vb.1 h m*row h m i)
 (J k : Nat) (hbound:k<J) :
 execute J (factorProgram key cls (R1Wiring.inputs row vec read p lam corr)) k =
 (∑ x : (∀g,X g), ∏g,(cls g |>.map (fun ec =>
   clause ec.2 (fun v => C (∑h,∑i,p ec.1 v h i*vec h (x h) i)+corr ec.1 v))).prod).coeff k := by
 rw [execute_correct J _ k hbound]
 have h1 := program_meaning key cls (R1Wiring.inputs row vec read p lam corr)
 have h2 := full_factor_assembly key cls (R1Wiring.inputs row vec read p lam corr)
 have h3 := R1Wiring.assembly_correct row vec read key p lam corr cls hk hp
 exact congrArg (fun a : Polynomial ℚ => a.coeff k) (h1.trans (h2.symm.trans h3))
#print axioms wired_program_coefficients
#print axioms program_meaning
#print axioms program_coefficients
end
end R1AssemblySource

import Support
import Mathlib.Algebra.BigOperators.Group.Finset.Powerset

open scoped BigOperators
namespace R1Loops
open Finset R1Difference R1Support Polynomial
noncomputable section
variable {I : Type*} [DecidableEq I]

-- Same E/U/restricted-x order as the source, before measurement-fibre factoring.
def restrictedLoop (B : Finset I) (e : Finset I → Expr I) (q k : Nat) : ℚ :=
  ∑ E ∈ B.powerset.filter (fun E => E.card ≤ q),
    ∑ x ∈ B.powerset.filter (fun x => E ⊆ x),
      difference E (fun U => (eval (e x) U).coeff k)

-- Move the E loop outside the assignment sum, deriving the restriction x_i=1 on E.
theorem restricted_loop_correct (B : Finset I) (e : Finset I → Expr I)
    (q k : Nat) (hk : k ≤ q) :
    restrictedLoop B e q k = ∑ x ∈ B.powerset, (eval (e x) x).coeff k := by
  unfold restrictedLoop
  simp only [sum_filter]
  have move : ∀ E : Finset I,
      (if E.card ≤ q then ∑ x ∈ B.powerset,
        if E ⊆ x then difference E (fun U => (eval (e x) U).coeff k) else 0 else 0) =
      ∑ x ∈ B.powerset, if E.card ≤ q then
        (if E ⊆ x then difference E (fun U => (eval (e x) U).coeff k) else 0) else 0 := by
    intro E
    by_cases h : E.card ≤ q <;> simp [h]
  simp_rw [move]
  rw [sum_comm]
  apply sum_congr rfl
  intro x hx
  have hxB := mem_powerset.mp hx
  have heq : (B.powerset.filter (fun E => E.card ≤ q ∧ E ⊆ x)) =
      x.powerset.filter (fun E => E.card ≤ q) := by
    ext E
    simp only [mem_filter,mem_powerset]
    constructor
    · rintro ⟨_,hc,hs⟩; exact ⟨hs,hc⟩
    · rintro ⟨hs,hc⟩; exact ⟨hs.trans hxB,hc,hs⟩
  have h : (∑ E ∈ B.powerset, if E.card ≤ q then
      (if E ⊆ x then difference E (fun U => (eval (e x) U).coeff k) else 0) else 0) =
      ∑ E ∈ B.powerset.filter (fun E => E.card ≤ q ∧ E ⊆ x),
        difference E (fun U => (eval (e x) U).coeff k) := by
    simp only [sum_filter]
    apply sum_congr rfl
    intro E _
    by_cases hc : E.card ≤ q <;> by_cases hs : E ⊆ x <;> simp [hc,hs]
  rw [h,heq]
  exact truncated_reconstruction (e x) x q k hk

-- Python's scalar accumulation operation, with arbitrary starting accumulator.
def forSum {A : Type*} (xs : List A) (f : A → ℚ) (z : ℚ) : ℚ :=
  xs.foldl (fun a x => a + f x) z

theorem forSum_correct {A : Type*} (xs : List A) (f : A → ℚ) (z : ℚ) :
    forSum xs f z = z + (xs.map f).sum := by
  induction xs generalizing z with
  | nil => simp [forSum]
  | cons x xs ih =>
    change forSum xs f (z+f x) = _
    rw [ih]
    simp [add_assoc]

-- The two source loops over cardinalities and combinations enumerate this same sum.
theorem cardinal_loop (B : Finset I) (q : Nat) (f : Finset I → ℚ) :
    (∑ j ∈ range (B.card+1), ∑ E ∈ powersetCard j B, if j ≤ q then f E else 0) =
      ∑ E ∈ B.powerset.filter (fun E => E.card ≤ q), f E := by
  rw [sum_filter, sum_powerset]
  apply sum_congr rfl
  intro j hj
  apply sum_congr rfl
  intro E hE
  rw [(mem_powersetCard.mp hE).2]

set_option pp.fullNames true
#print axioms restricted_loop_correct
#print axioms forSum_correct
#print axioms cardinal_loop
end
end R1Loops

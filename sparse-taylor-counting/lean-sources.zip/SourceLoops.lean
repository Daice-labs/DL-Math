import Multiply

namespace R1SourceLoops
open R1PythonLoops R1Multiply
noncomputable section

-- Restricted operation language for the exact zmul loop. These nodes retain
-- the mutable accumulation order and both continue/conditional branches.
inductive Op where
 | addProduct
 | ifBNonzero : Op → Op
 | forJ : Op → Op
 | ifANonzero : Op → Op
 | forI : Op → Op
 deriving Repr, DecidableEq

def execute (a b : Nat → ℚ) (J i j : Nat) : Op → (Nat → ℚ) → (Nat → ℚ)
 | .addProduct, out => addAt out (i+j) (a i*b j)
 | .ifBNonzero body, out => if b j=0 then out else execute a b J i j body out
 | .forJ body, out => (List.range (J-i)).foldl (fun out j => execute a b J i j body out) out
 | .ifANonzero body, out => if a i=0 then out else execute a b J i j body out
 | .forI body, out => (List.range J).foldl (fun out i => execute a b J i 0 body out) out

def program : Op := .forI (.ifANonzero (.forJ (.ifBNonzero .addProduct)))

theorem foldl_congr {A S : Type*} (xs : List A) (f g : S → A → S)
    (h : ∀ s x, f s x=g s x) (s : S) : xs.foldl f s=xs.foldl g s := by
  induction xs generalizing s with
  | nil => rfl
  | cons x xs ih => simp only [List.foldl_cons,h]; exact ih _

theorem add_zero (a : Nat → ℚ) (i : Nat) : addAt a i 0=a := by
  funext k
  simp [addAt]

theorem inner_exec (a b : Nat → ℚ) (J i j : Nat) (out : Nat → ℚ) :
    execute a b J i j (.ifANonzero (.forJ (.ifBNonzero .addProduct))) out =
    (List.range (J-i)).foldl (fun o j => addAt o (i+j) (a i*b j)) out := by
  by_cases ha : a i=0
  · simp only [execute,ha,ite_true,zero_mul,add_zero]
    simp
  · simp only [execute,ha,ite_false]
    apply foldl_congr
    intro o j
    by_cases hb : b j=0 <;> simp [hb,add_zero]

theorem fold_flat {A B S : Type*} (xs : List A) (ys : A → List B)
    (f : S → A × B → S) (s : S) :
    xs.foldl (fun s x => (ys x).foldl (fun s y => f s (x,y)) s) s =
    (xs.flatMap (fun x => (ys x).map (fun y => (x,y)))).foldl f s := by
  induction xs generalizing s with
  | nil => rfl
  | cons x xs ih => simp [List.foldl_append,List.foldl_map,ih]

theorem source_loop_coefficients (a b : Nat → ℚ) (J : Nat) :
    execute a b J 0 0 program (fun _ => 0) = zmulLoop J a b := by
  unfold program
  simp only [execute]
  have he := foldl_congr (List.range J)
    (fun o i => if a i=0 then o else
      (List.range (J-i)).foldl (fun o j => if b j=0 then o else addAt o (i+j) (a i*b j)) o)
    (fun o i => (List.range (J-i)).foldl (fun o j => addAt o (i+j) (a i*b j)) o)
    (fun o i => inner_exec a b J i 0 o) (fun _ => 0)
  rw [he,fold_flat (List.range J) (fun i => List.range (J-i))
    (fun o ij => addAt o (ij.1+ij.2) (a ij.1*b ij.2))]
  unfold zmulLoop accumulation pairs
  simp_rw [zero_skips]

-- No numerical test or oracle premise. The admitted list-length condition
-- allows enumerate(a) to be interpreted by range J; all accesses are in range.
theorem source_program_correct (J : Nat) (p r : Polynomial ℚ) (k : Nat) (hk:k<J) :
    execute p.coeff r.coeff J 0 0 program (fun _ => 0) k = (p*r).coeff k := by
  rw [source_loop_coefficients]
  exact convolution J p r k hk

theorem accesses_in_bounds (J i j : Nat) (hi:i<J) (hj:j<J-i) :
    i<J ∧ j<J ∧ i+j<J := by omega

set_option pp.fullNames true
#print axioms source_program_correct
#print axioms accesses_in_bounds
end
end R1SourceLoops

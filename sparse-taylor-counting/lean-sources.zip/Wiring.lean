import Assembly
open scoped BigOperators
namespace R1Wiring
noncomputable section
set_option maxHeartbeats 800000
open Classical Finset Polynomial R1Assembly
variable {G : Type*} [Fintype G] [DecidableEq G]
variable {I M X Y : G → Type*}
variable [∀ g,Fintype (I g)] [∀ g,Fintype (M g)]
variable [∀ g,Fintype (X g)] [∀ g,Fintype (Y g)] [∀ g,DecidableEq (Y g)]

def inputs (row : ∀ g,M g → I g → ℚ) (vec : ∀ g,X g → I g → ℚ)
    (read : ∀ g,Y g → M g → ℚ) (p : Nat → Nat → ∀ g,I g → ℚ)
    (lam : Nat → Nat → ∀ g,M g → ℚ) (corr : Nat → Nat → Polynomial ℚ)
    (y : ∀ g,Y g) (g : G) (u : X g) (e v : Nat) : Polynomial ℚ :=
  C (∑ h, if h=g then ∑ i,p e v g i*vec g u i
    else ∑ m,lam e v h m*read h (y h) m)+corr e v

theorem occurrence_correct
    (row : ∀ g,M g → I g → ℚ) (vec : ∀ g,X g → I g → ℚ)
    (read : ∀ g,Y g → M g → ℚ) (key : ∀ g,X g → Y g)
    (p : Nat → Nat → ∀ g,I g → ℚ) (lam : Nat → Nat → ∀ g,M g → ℚ)
    (corr : Nat → Nat → Polynomial ℚ)
    (hk : ∀ g u m,read g (key g u) m=∑ i,row g m i*vec g u i)
    (x : ∀ g,X g) (g : G) (e v : Nat)
    (hp : ∀ h,h≠g → ∀ i,p e v h i=∑ m,lam e v h m*row h m i) :
    inputs row vec read p lam corr (fun h => key h (x h)) g (x g) e v =
    C (∑ h,∑ i,p e v h i*vec h (x h) i)+corr e v := by
  unfold inputs
  congr 2
  apply sum_congr rfl
  intro h _
  split_ifs with he
  · subst h; rfl
  · simp_rw [hk]
    exact rowspace_eval (p e v) row (lam e v) (fun h => vec h (x h)) h (hp h he)

-- No assumed equality of counts: only checked row-space equations and the
-- table key's coordinate interpretation. Clause occurrences keep their e index.
theorem assembly_correct
    (row : ∀ g,M g → I g → ℚ) (vec : ∀ g,X g → I g → ℚ)
    (read : ∀ g,Y g → M g → ℚ) (key : ∀ g,X g → Y g)
    (p : Nat → Nat → ∀ g,I g → ℚ) (lam : Nat → Nat → ∀ g,M g → ℚ)
    (corr : Nat → Nat → Polynomial ℚ) (cls : G → List (Nat × List (Nat × Bool)))
    (hk : ∀ g u m,read g (key g u) m=∑ i,row g m i*vec g u i)
    (hp : ∀ g ec, ec∈cls g → ∀ vb∈ec.2, ∀ h,h≠g → ∀ i,
      p ec.1 vb.1 h i=∑ m,lam ec.1 vb.1 h m*row h m i) :
    (∑ y : (∀ g,Y g), ∏ g, ∑ u : X g,
      if key g u=y g then (cls g |>.map (fun ec =>
        1-clauseLoop ec.2 (inputs row vec read p lam corr y g u ec.1) 1)).prod else 0) =
    ∑ x : (∀ g,X g), ∏ g,(cls g |>.map (fun ec =>
      clause ec.2 (fun v => C (∑ h,∑ i,p ec.1 v h i*vec h (x h) i)+corr ec.1 v))).prod := by
  rw [full_factor_assembly key cls (inputs row vec read p lam corr)]
  apply sum_congr rfl
  intro x _
  apply prod_congr rfl
  intro g _
  congr 1
  apply List.map_congr_left
  intro ec he
  unfold clause
  congr 2
  apply List.map_congr_left
  intro vb hv
  rw [occurrence_correct row vec read key p lam corr hk x g ec.1 vb.1 (hp g ec he vb hv)]
#print axioms occurrence_correct
#print axioms assembly_correct
end
end R1Wiring

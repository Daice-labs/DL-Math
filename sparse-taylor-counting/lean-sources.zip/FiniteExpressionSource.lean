import FiniteContract
import FiniteTruncation
namespace OP04
open scoped BigOperators
open Finset Polynomial P4c R1Circuit

def constExpr (q:ℚ) : FiniteExpr := .leaf [q]
def sumExpr (es:List FiniteExpr) : FiniteExpr := es.foldr FiniteExpr.add (constExpr 0)
def prodExpr (es:List FiniteExpr) : FiniteExpr := es.foldr FiniteExpr.mul (constExpr 1)
def subExpr (a b:FiniteExpr) : FiniteExpr := .add a (.neg b)
def shiftExpr (t:ℚ) : List ℚ→FiniteExpr
 | []=>constExpr 0
 | a::cs=>.add (constExpr a) (.mul (.leaf [t,1]) (shiftExpr t cs))
@[simp] theorem meaning_const (q:ℚ) : meaning (constExpr q)=C q := by simp [constExpr,meaning,polynomial]
@[simp] theorem meaning_sum (es:List FiniteExpr) : meaning (sumExpr es)=(es.map meaning).sum := by
 induction es with
 | nil=>simp [sumExpr]
 | cons e es ih=>simp [sumExpr,meaning] at *;exact ih
@[simp] theorem meaning_prod (es:List FiniteExpr) : meaning (prodExpr es)=(es.map meaning).prod := by
 induction es with
 | nil=>simp [prodExpr]
 | cons e es ih=>simp [prodExpr,meaning] at *;exact Or.inl ih
@[simp] theorem meaning_sub (a b:FiniteExpr) : meaning (subExpr a b)=meaning a-meaning b := by simp [subExpr,meaning,sub_eq_add_neg]
theorem meaning_shift (cs:List ℚ) (t:ℚ) : meaning (shiftExpr t cs)=taylor t (polynomial cs) := by
 induction cs with
 | nil=>simp [shiftExpr,polynomial]
 | cons a cs ih=>
  simp [shiftExpr,meaning,polynomial,map_add,taylor_mul,taylor_C,taylor_X] at *
  rw [ih]
  ring

def correctionExpr (s:FiniteSource) (o:s.Occ) (t:ℚ) (U:Finset s.Var) : FiniteExpr :=
 sumExpr (List.ofFn (fun g:s.Group=>sumExpr (List.ofFn (fun i:Fin (s.sizes g)=>
 if Sigma.mk g i∈U then subExpr (shiftExpr t (s.coefficients o ⟨g,i⟩)) (constExpr (evaluate (s.coefficients o ⟨g,i⟩) t)) else constExpr 0))))

theorem meaning_correction (s:FiniteSource) (o:s.Occ) (t:ℚ) (U:Finset s.Var) :
 meaning (correctionExpr s o t U)=R1Support.eval (corrections t (canonicalForm univ (s.forms o))) U := by
 rw [corrections_correct,canonical_value]
 simp only [correctionExpr,meaning_sum,List.map_ofFn,List.sum_ofFn]
 simp [meaning_sum,List.map_ofFn,List.sum_ofFn,Function.comp_apply,apply_ite,meaning_sub,meaning_shift,FiniteSource.forms,←eval_polynomial,Fintype.sum_sigma,map_sum,eval_finsetSum,P4c.eval_ite,Finset.sum_sub_distrib]
 rw [← Fintype.sum_sigma (fun x:s.Var => if x∈U then taylor t (polynomial (s.coefficients o x))-C ((polynomial (s.coefficients o x)).eval t) else 0)]
 simp [Finset.sum_sub_distrib]

def inputExpr (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ)
 (g:s.Group) (u:Finset (Fin (s.sizes g))) (U:Finset s.Var) (o:s.Occ) : FiniteExpr :=
 .add (constExpr ((∑i∈u,evaluate (s.coefficients o ⟨g,i⟩) t)+∑h∈univ.erase g,∑k,d.lam o h k*y h k)) (correctionExpr s o t U)

theorem meaning_input (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ)
 (g:s.Group) (u:Finset (Fin (s.sizes g))) (U:Finset s.Var) (o:s.Occ) :
 meaning (inputExpr s d t y g u U o)=ownedInput (s.forms o) t g (d.lam o) y u U := by
 simp [inputExpr,meaning,meaning_correction,ownedInput,FiniteSource.forms,eval_polynomial]
def clauseExpr (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ)
 (g:s.Group) (u:Finset (Fin (s.sizes g))) (U:Finset s.Var) (os:List s.Occ) : FiniteExpr :=
 subExpr (constExpr 1) (prodExpr (os.map (fun o=>if (s.vars o).2 then subExpr (constExpr 1) (inputExpr s d t y g u U o) else inputExpr s d t y g u U o)))
def factorExpr (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ)
 (g:s.Group) (u:Finset (Fin (s.sizes g))) (U:Finset s.Var) : FiniteExpr :=
 prodExpr ((s.clauses g).map (clauseExpr s d t y g u U))
theorem meaning_clause (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ)
 (g:s.Group) (u:Finset (Fin (s.sizes g))) (U:Finset s.Var) (os:List s.Occ) :
 meaning (clauseExpr s d t y g u U os)=localClause os s.vars (fun o=>ownedInput (s.forms o) t g (d.lam o) y u U) := by
 simp only [clauseExpr,meaning_sub,meaning_const,meaning_prod,localClause,List.map_map,Polynomial.C_1]
 congr 2
 apply List.map_congr_left
 intro o _
 dsimp only [Function.comp_apply]
 split <;> simp [meaning_input]
theorem meaning_factor (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ)
 (g:s.Group) (u:Finset (Fin (s.sizes g))) (U:Finset s.Var) :
 meaning (factorExpr s d t y g u U)=localFactor s.clauses s.vars s.forms t d.lam y g u U := by
 simp only [factorExpr,meaning_prod,localFactor,List.map_map]
 congr 1
 apply List.map_congr_left
 intro os _
 exact meaning_clause s d t y g u U os
theorem checked_factor (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ)
 (g:s.Group) (u:Finset (Fin (s.sizes g))) (U:Finset s.Var) (J:Nat) (recorded:List ℚ)
 (h:expressionCheck J (factorExpr s d t y g u U) recorded=true) :
 Represents J recorded (localFactor s.clauses s.vars s.forms t d.lam y g u U) := by
 rw [←meaning_factor]
 exact expressionCheck_sound J _ recorded h
end OP04

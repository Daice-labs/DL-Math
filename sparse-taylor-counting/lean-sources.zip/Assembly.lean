import Join
import ActualTables
import ActualShift
open scoped BigOperators
namespace R1Assembly
noncomputable section
open Classical Finset Polynomial
variable {G : Type*} [Fintype G] [DecidableEq G]
variable {I M : G → Type*} [∀ g, Fintype (I g)] [∀ g, Fintype (M g)]

def measure (row : ∀ g, M g → I g → ℚ) (x : ∀ g, I g → ℚ)
    (g : G) (m : M g) : ℚ := ∑ i, row g m i * x g i

-- Coefficient-level row-space equations, not an assumed equality of counts.
theorem rowspace_eval (p : ∀ g, I g → ℚ) (row : ∀ g, M g → I g → ℚ)
    (lam : ∀ g, M g → ℚ) (x : ∀ g, I g → ℚ) (h : G)
    (hp : ∀ i, p h i = ∑ m, lam h m * row h m i) :
    (∑ m, lam h m * measure row x h m) = ∑ i, p h i * x h i := by
  simp only [measure, mul_sum]
  rw [sum_comm]
  apply sum_congr rfl
  intro i _
  rw [hp, sum_mul]
  apply sum_congr rfl
  intro m _
  ring

def wiredValue (p : ∀ g, I g → ℚ) (row : ∀ g, M g → I g → ℚ)
    (lam : ∀ g, M g → ℚ) (x : ∀ g, I g → ℚ) (owner : G) : ℚ :=
  ∑ h, if h=owner then ∑ i, p h i*x h i
    else ∑ m, lam h m*measure row x h m

theorem wired_value_correct (p : ∀ g, I g → ℚ) (row : ∀ g, M g → I g → ℚ)
    (lam : ∀ g, M g → ℚ) (x : ∀ g, I g → ℚ) (owner : G)
    (hp : ∀ h, h≠owner → ∀ i, p h i=∑ m,lam h m*row h m i) :
    wiredValue p row lam x owner = ∑ h,∑ i,p h i*x h i := by
  unfold wiredValue
  apply sum_congr rfl
  intro h _
  split_ifs with he
  · rfl
  · exact rowspace_eval p row lam x h (hp h he)

-- The literal signs and both 1-minus operations in clause_poly.
def clause {V : Type*} (ls : List (V × Bool)) (input : V → Polynomial ℚ) : Polynomial ℚ :=
  1 - (ls.map (fun vb => 1 - if vb.2 then input vb.1 else 1-input vb.1)).prod

def clauseLoop {V : Type*} (ls : List (V × Bool))
    (input : V → Polynomial ℚ) (acc : Polynomial ℚ) : Polynomial ℚ :=
  ls.foldl (fun a vb => a*(1-if vb.2 then input vb.1 else 1-input vb.1)) acc

theorem clause_fold {V : Type*} (ls : List (V × Bool)) (input : V → Polynomial ℚ)
    (acc : Polynomial ℚ) :
    clauseLoop ls input acc = acc*(ls.map (fun vb => 1-if vb.2 then input vb.1 else 1-input vb.1)).prod := by
  induction ls generalizing acc with
  | nil => simp [clauseLoop]
  | cons a ls ih =>
    simp only [clauseLoop,List.foldl_cons,List.map_cons,List.prod_cons]
    change clauseLoop ls input (acc * _) = _
    rw [ih,mul_assoc]

theorem clause_loop_correct {V : Type*} (ls : List (V × Bool)) (input : V → Polynomial ℚ) :
    1-clauseLoop ls input 1 = clause ls input := by
  rw [clause_fold]; simp [clause]

-- Polynomial correction is independent of the assignment in each bucket.
theorem input_wiring (p : ∀ g, I g → ℚ) (row : ∀ g, M g → I g → ℚ)
    (lam : ∀ g, M g → ℚ) (x : ∀ g, I g → ℚ) (owner : G)
    (delta : Polynomial ℚ)
    (hp : ∀ h, h≠owner → ∀ i, p h i=∑ m,lam h m*row h m i) :
    C (wiredValue p row lam x owner) + delta = C (∑ h,∑ i,p h i*x h i)+delta := by
  rw [wired_value_correct p row lam x owner hp]

-- y can couple all groups; empty groups/clauses/fibres obey semiring units.
theorem full_factor_assembly {X Y : G → Type*}
    [∀ g, Fintype (X g)] [∀ g, Fintype (Y g)] [∀ g, DecidableEq (Y g)]
    (key : ∀ g, X g → Y g)
    (clauses : G → List (Nat × List (Nat × Bool)))
    (input : (∀ g,Y g) → ∀ g,X g → Nat → Nat → Polynomial ℚ) :
    (∑ y : (∀ g,Y g), ∏ g, ∑ x : X g,
      if key g x=y g then (clauses g |>.map (fun ec => 1-clauseLoop ec.2 (input y g x ec.1) 1)).prod else 0) =
    ∑ x : (∀ g,X g), ∏ g,
      (clauses g |>.map (fun ec => clause ec.2 (input (fun g => key g (x g)) g (x g) ec.1))).prod := by
  simp_rw [clause_loop_correct]
  exact R1Join.measurement_fibres key _
#print axioms rowspace_eval
#print axioms wired_value_correct
#print axioms clause_loop_correct
#print axioms input_wiring
#print axioms full_factor_assembly
end
end R1Assembly

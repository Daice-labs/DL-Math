import RecoveryInterface
namespace OP04
open Polynomial
-- Executable finite coefficient data; no mathematical polynomial in the runtime interface.
def coeffAt (cs:List ℚ) (k:Nat) : ℚ := cs[k]?.getD 0
def evaluate (cs:List ℚ) (t:ℚ) : ℚ := cs.foldr (fun a z=>a+t*z) 0
noncomputable def polynomial : List ℚ → Polynomial ℚ
 | []=>0
 | a::cs=>C a+X*polynomial cs

theorem eval_polynomial (cs:List ℚ) (t:ℚ) : (polynomial cs).eval t = evaluate cs t := by
 induction cs with
 | nil=>simp [polynomial,evaluate]
 | cons a cs ih=>simp [polynomial,evaluate] at *;exact Or.inl ih

theorem coeff_polynomial (cs:List ℚ) (k:Nat) : (polynomial cs).coeff k=coeffAt cs k := by
 induction cs generalizing k with
 | nil=>simp [polynomial,coeffAt]
 | cons a cs ih=>
  cases k with
  | zero=>simp [polynomial,coeffAt]
  | succ k=>simp [polynomial,coeffAt,coeff_X_mul,ih]
end OP04

import SupportCancellation
namespace OP04.Sparse
open scoped BigOperators
open Finset Polynomial P4c R1Circuit

def supportCheck (s : FiniteSource) (S : Finset s.Var) : Bool :=
 decide (∀o:s.Occ, ∀i:s.Var, i∉S → ∀a∈(s.coefficients o i).tail, a=0)

theorem zero_list (cs : List ℚ) (h : ∀a∈cs, a=0) : polynomial cs=0 := by
 induction cs with
 | nil => rfl
 | cons a cs ih =>
   have ha := h a (by simp)
   have hh : ∀b∈cs,b=0 := fun b hb => h b (by simp [hb])
   simp [polynomial,ha,ih hh]

theorem constant_list (cs : List ℚ) (h : ∀a∈cs.tail,a=0) :
 polynomial cs = C ((polynomial cs).eval 0) := by
 cases cs with
 | nil => simp [polynomial]
 | cons a cs =>
   have hz : polynomial cs=0 := zero_list cs h
   simp [polynomial,hz]

theorem failure_supported (S : Finset I) [DecidableEq I] (ls : List (P4c.SourceLit I))
 (h : ∀l∈ls, FormSupported S l.2.2) : CircuitSupported S (P4c.failure ls) := by
 induction ls with
 | nil => trivial
 | cons l ls ih =>
   have hl:=h l (by simp)
   have ht:=ih (fun x hx => h x (by simp [hx]))
   cases hb:l.2.1 <;> simp [P4c.failure,CircuitSupported,hb,hl,ht]

theorem cnf_supported (S : Finset I) [DecidableEq I] (cls : List (List (P4c.SourceLit I)))
 (h : ∀cl∈cls, ∀l∈cl, FormSupported S l.2.2) : CircuitSupported S (P4c.cnf cls) := by
 induction cls with
 | nil => trivial
 | cons cl cls ih =>
   exact ⟨⟨trivial, failure_supported S cl (h cl (by simp))⟩,
     ih (fun cl hc => h cl (by simp [hc]))⟩

theorem checked_source_support (s : FiniteSource) (S : Finset s.Var)
 (h : supportCheck s S=true) : CircuitSupported S (P4c.cnf s.cnfSource) := by
 have hh : ∀o:s.Occ, ∀i:s.Var, i∉S → ∀a∈(s.coefficients o i).tail,a=0 := by
   simpa only [supportCheck,decide_eq_true_eq] using h
 apply cnf_supported
 intro cl hcl l hl
 change cl ∈ (univ:Finset s.Group).toList.flatMap (fun g => (s.clauses g).map (List.map (literal s.vars s.forms))) at hcl
 obtain ⟨g,hg,hcl⟩ := List.mem_flatMap.mp hcl
 obtain ⟨os,hos,rfl⟩ := List.mem_map.mp hcl
 obtain ⟨o,ho,rfl⟩ := List.mem_map.mp hl
 change FormSupported S (canonicalForm univ (s.forms o))
 intro ip hip hn
 obtain ⟨i,hi,rfl⟩ := List.mem_map.mp hip
 exact constant_list (s.coefficients o i) (hh o i hn)

def recordedSparseEntry (s : FiniteSource) (S : Finset s.Var) (q k : Nat)
 (recorded : Finset s.Var → Finset s.Var → List ℚ) : ℚ :=
 ∑j∈range (min q S.card+1), ∑E∈powersetCard j S,
 ∑h∈range (j+1), ∑U∈powersetCard h E, (-1:ℚ)^(j-h)*coeffAt (recorded E U) k

def sparseRowsCheck (s : FiniteSource) (S : Finset s.Var) (d : FiniteDesign s)
 (t : ℚ) (q : Nat) (rows : Finset s.Var → Finset s.Var → RestrictedRow s d)
 (recorded : Finset s.Var → Finset s.Var → List ℚ) : Bool := decide
 (supportCheck s S=true ∧ d.rowCheck s t=true ∧ d.fibreCheck s=true ∧
 ∀j:Fin (min q S.card+1), ∀E:↥(powersetCard j.val S),
 ∀h:Fin (j.val+1), ∀U:↥(powersetCard h.val E.val),
 (rows E.val U.val).tables.length=(rows E.val U.val).tuples.length ∧
 (rows E.val U.val).coverageCheck s d=true ∧
 expressionCheck (q+1) ((rows E.val U.val).program s d t E.val U.val) (recorded E.val U.val)=true)

theorem checked_sparse_taylor (s : FiniteSource) (S : Finset s.Var) (d : FiniteDesign s)
 (t : ℚ) (q : Nat) (rows : Finset s.Var → Finset s.Var → RestrictedRow s d)
 (recorded : Finset s.Var → Finset s.Var → List ℚ)
 (hc : sparseRowsCheck s S d t q rows recorded=true) (k : Nat) (hk : k≤q) :
 recordedSparseEntry s S q k recorded = (taylor t (sourcePolynomial s)).coeff k := by
 have hc' : supportCheck s S=true ∧ d.rowCheck s t=true ∧ d.fibreCheck s=true ∧
  ∀j∈range (min q S.card+1), ∀E∈powersetCard j S,
  ∀h∈range (j+1), ∀U∈powersetCard h E,
  (rows E U).tables.length=(rows E U).tuples.length ∧
  (rows E U).coverageCheck s d=true ∧
  expressionCheck (q+1) ((rows E U).program s d t E U) (recorded E U)=true := by
  simpa only [sparseRowsCheck,decide_eq_true_eq,Fin.forall_iff,Subtype.forall,Finset.mem_range] using hc
 have hj:=sparse_entry_taylor (univ:Finset s.Var) S (subset_univ _)
   (P4c.cnf s.cnfSource) (checked_source_support s S hc'.1) t q k hk
 change _=(taylor t (∑x∈(univ:Finset s.Var).powerset,R1Circuit.original (P4c.cnf s.cnfSource) x)).coeff k
 rw [←hj]
 unfold recordedSparseEntry P4c.traceEntry
 apply sum_congr rfl; intro j hj
 apply sum_congr rfl; intro E hE
 apply sum_congr rfl; intro h hh
 apply sum_congr rfl; intro U hU
 have hr := hc'.2.2.2 j hj E hE h hh U hU
 have hp:=RestrictedRow.checked_restricted s d (rows E U) t E U hr.2.1 hc'.2.1 (q+1) (recorded E U) hr.2.2
 rw [hp k (by omega)]

#print axioms checked_source_support
#print axioms checked_sparse_taylor
end OP04.Sparse

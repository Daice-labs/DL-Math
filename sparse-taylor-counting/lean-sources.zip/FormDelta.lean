import Shift

namespace R1FormDelta
open R1Shift Polynomial
noncomputable section
variable {K : Type*} [DecidableEq K]

def store {A : Type*} (key : K) (value : A) (d : K → Option A) : K → Option A :=
  fun k => if k=key then some value else d k

def inputMap (rows : List (K × List ℚ)) : K → Option (List ℚ) :=
  rows.foldl (fun d entry => store entry.1 entry.2 d) (fun _ => none)

def formDelta (rows : List (K × List ℚ)) (t : ℚ) (J : Nat) : K → Option (Nat → ℚ) :=
  rows.foldl (fun d entry => store entry.1 (correction entry.2 t J) d) (fun _ => none)

theorem store_map {A B : Type*} (f : A → B) (d : K → Option A) (key : K) (value : A) :
    store key (f value) (fun k => (d k).map f) = fun k => (store key value d k).map f := by
  funext k
  by_cases h:k=key <;> simp [store,h]

theorem fold_store_map {A B : Type*} (f : A → B) (rows : List (K × A)) (d : K → Option A) :
    rows.foldl (fun d entry => store entry.1 (f entry.2) d) (fun k => (d k).map f) =
      fun k => ((rows.foldl (fun d entry => store entry.1 entry.2 d) d) k).map f := by
  induction rows generalizing d with
  | nil => rfl
  | cons entry rows ih =>
    simp only [List.foldl_cons,store_map]
    exact ih _

theorem form_delta_map (rows : List (K × List ℚ)) (t : ℚ) (J : Nat) :
    formDelta rows t J = fun k => (inputMap rows k).map (fun cs => correction cs t J) := by
  exact fold_store_map (fun cs => correction cs t J) rows (fun _ => none)

-- This even handles repeated input keys by the dictionary's last-write-wins rule.
-- Python dict.items() supplies distinct keys; no distinctness shortcut is needed.
theorem form_delta_correct (rows : List (K × List ℚ)) (key : K) (cs : List ℚ)
    (h : inputMap rows key = some cs) (t : ℚ) (J : Nat) (hJ:0<J) :
    ∃ out, formDelta rows t J key = some out ∧
      ∀ j, j<J → out j =
       (taylor t (polynomial (enumerate cs)) - C ((polynomial (enumerate cs)).eval t)).coeff j := by
  refine ⟨correction cs t J, ?_, ?_⟩
  · simp only [form_delta_map,h,Option.map_some]
  · intro j hj; exact correction_correct cs t J j hJ hj

theorem absent_preserved (rows : List (K × List ℚ)) (key : K)
    (h : inputMap rows key = none) (t : ℚ) (J : Nat) : formDelta rows t J key = none := by
  simp only [form_delta_map,h,Option.map_none]

set_option pp.fullNames true
#print axioms fold_store_map
#print axioms form_delta_correct
#print axioms absent_preserved
end
end R1FormDelta

import Loops

open scoped BigOperators
namespace R1Circuit
open Finset Polynomial R1Support R1Loops
noncomputable section
variable {I : Type*} [DecidableEq I]

abbrev Form (I : Type*) := List (I × Polynomial ℚ)
def formValue : Form I → Finset I → Polynomial ℚ
 | [], _ => 0
 | (i,p)::xs, x => (if i ∈ x then p else 0) + formValue xs x

def corrections (t : ℚ) : Form I → Expr I
 | [] => .base 0
 | (i,p)::xs => .add (.correction i p t) (corrections t xs)

theorem corrections_correct (t : ℚ) (f : Form I) (x : Finset I) :
    eval (corrections t f) x = taylor t (formValue f x) - C ((formValue f x).eval t) := by
  induction f with
  | nil => simp [corrections,R1Support.eval,formValue]
  | cons ip xs ih =>
    rcases ip with ⟨i,p⟩
    by_cases h : i ∈ x
    · simp [corrections,R1Support.eval,formValue,h,ih,delta]
      ring
    · simp [corrections,R1Support.eval,formValue,h,ih]

inductive Circuit (I : Type*) where
 | constant : ℚ → Circuit I
 | form : Form I → Circuit I
 | add : Circuit I → Circuit I → Circuit I
 | mul : Circuit I → Circuit I → Circuit I
 | neg : Circuit I → Circuit I

def original : Circuit I → Finset I → Polynomial ℚ
 | .constant c, _ => C c
 | .form f, x => formValue f x
 | .add a b, x => original a x + original b x
 | .mul a b, x => original a x * original b x
 | .neg a, x => -original a x

def translate (t : ℚ) (x : Finset I) : Circuit I → Expr I
 | .constant c => .base (C c)
 | .form f => .add (.base (C ((formValue f x).eval t))) (corrections t f)
 | .add a b => .add (translate t x a) (translate t x b)
 | .mul a b => .mul (translate t x a) (translate t x b)
 | .neg a => .neg (translate t x a)

theorem translate_correct (c : Circuit I) (t : ℚ) (x : Finset I) :
    eval (translate t x c) x = taylor t (original c x) := by
  induction c with
  | constant q => simp [translate,R1Support.eval,original]
  | form f => simp [translate,R1Support.eval,original,corrections_correct]
  | add a b ha hb => simp [translate,R1Support.eval,original,ha,hb]
  | mul a b ha hb => simp [translate,R1Support.eval,original,ha,hb,taylor_mul]
  | neg a ha => simp [translate,R1Support.eval,original,ha]

-- Applies to any CNF arithmetization (indeed any circuit over admitted forms).
-- Neither a coefficient-support premise nor an equality of Taylor data is assumed.
theorem generic_taylor_extraction (c : Circuit I) (B : Finset I) (t : ℚ)
    (q k : Nat) (hk : k ≤ q) :
    restrictedLoop B (fun x => translate t x c) q k =
      (taylor t (∑ x ∈ B.powerset, original c x)).coeff k := by
  rw [restricted_loop_correct B _ q k hk]
  simp_rw [translate_correct]
  simp only [map_sum, finset_sum_coeff]

set_option pp.fullNames true
#print axioms corrections_correct
#print axioms translate_correct
#print axioms generic_taylor_extraction
end
end R1Circuit

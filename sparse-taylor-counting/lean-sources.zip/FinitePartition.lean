import LocalSemantics
namespace OP04
open scoped BigOperators
open Classical Finset Polynomial
noncomputable section
variable {G : Type*} [Fintype G] [DecidableEq G]
variable {V : G → Type*} [∀ g, Fintype (V g)] [∀ g, DecidableEq (V g)]
def glue (u : ∀ g, Finset (V g)) : Finset (Sigma V) := univ.sigma u
@[simp] theorem mem_glue (u : ∀ g, Finset (V g)) (g:G) (i:V g) :
 (Sigma.mk g i)∈glue u ↔ i∈u g := by simp [glue]
def restrict (x:Finset (Sigma V)) (g:G) : Finset (V g) := univ.filter (fun i=>Sigma.mk g i∈x)
@[simp] theorem restrict_glue (u:∀g,Finset (V g)) : restrict (glue u)=u := by
 funext g;ext i;simp [restrict]
@[simp] theorem glue_restrict (x:Finset (Sigma V)) : glue (restrict x)=x := by
 ext i;rcases i with ⟨g,i⟩;simp [restrict]
def glueEquiv : (∀g,Finset (V g)) ≃ Finset (Sigma V) where
 toFun:=glue
 invFun:=restrict
 left_inv:=restrict_glue
 right_inv:=glue_restrict

theorem restriction_iff (E:Finset (Sigma V)) (u:∀g,Finset (V g)) :
 E⊆glue u ↔ ∀g,restrict E g⊆u g := by
 constructor
 · intro h g i hi
   exact (mem_glue u g i).mp (h (by simpa [restrict] using hi))
 · intro h i hi
   rcases i with ⟨g,i⟩
   exact (mem_glue u g i).mpr (h g (by simpa [restrict] using hi))

def decode : (∀g,Finset (V g)) ≃ {x:Finset (Sigma V) // x∈(univ:Finset (Sigma V)).powerset} where
 toFun u:=⟨glue u, by simp⟩
 invFun x:=restrict x.val
 left_inv:=restrict_glue
 right_inv x:=by apply Subtype.ext;exact glue_restrict x.val

theorem sum_partition {K:Type*} [AddCommMonoid K] (f:Finset (Sigma V)→K) :
 (∑u:∀g,Finset (V g),f (glue u)) = ∑x:Finset (Sigma V),f x :=
 glueEquiv.sum_comp f
end
end OP04

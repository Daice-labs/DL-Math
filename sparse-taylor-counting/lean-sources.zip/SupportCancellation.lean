import FiniteTaylor
namespace OP04.Sparse
open scoped BigOperators
open Finset Polynomial R1Support R1Circuit R1Difference
noncomputable section
variable {I : Type*} [DecidableEq I]

def ExprSupported (S : Finset I) : Expr I → Prop
 | .base _ => True
 | .correction i p t => i ∉ S → delta p t = 0
 | .add a b => ExprSupported S a ∧ ExprSupported S b
 | .mul a b => ExprSupported S a ∧ ExprSupported S b
 | .neg a => ExprSupported S a

theorem eval_insert_outside (S : Finset I) (e : Expr I) (he : ExprSupported S e)
 (a : I) (ha : a ∉ S) (U : Finset I) : eval e (insert a U) = eval e U := by
 induction e with
 | base p => rfl
 | correction i p t =>
   by_cases hi : i = a
   · subst i; simp [R1Support.eval, he ha]
   · simp [R1Support.eval, hi]
 | add x y hx hy => simp only [R1Support.eval, hx he.1, hy he.2]
 | mul x y hx hy => simp only [R1Support.eval, hx he.1, hy he.2]
 | neg x hx => simp only [R1Support.eval, hx he]

theorem difference_cancel (E : Finset I) (a : I) (ha : a ∈ E)
 (f : Finset I → ℚ) (hf : ∀U, f (insert a U) = f U) : difference E f = 0 := by
 rw [← insert_erase ha, difference_insert a (E.erase a) (notMem_erase a E)]
 simp_rw [hf, sub_self]
 exact difference_zero _

def FormSupported (S : Finset I) (f : Form I) : Prop :=
 ∀ip∈f, ip.1 ∉ S → ip.2 = C (ip.2.eval 0)
def CircuitSupported (S : Finset I) : Circuit I → Prop
 | .constant _ => True
 | .form f => FormSupported S f
 | .add a b => CircuitSupported S a ∧ CircuitSupported S b
 | .mul a b => CircuitSupported S a ∧ CircuitSupported S b
 | .neg a => CircuitSupported S a

theorem corrections_supported (S : Finset I) (f : Form I) (hf : FormSupported S f)
 (t : ℚ) : ExprSupported S (corrections t f) := by
 induction f with
 | nil => trivial
 | cons ip fs ih =>
   refine ⟨?_, ih ?_⟩
   · intro hn
     have hp := hf ip (by simp) hn
     rw [hp]
     simp [delta]
   · intro jp hj; exact hf jp (by simp [hj])

theorem translate_supported (S : Finset I) (c : Circuit I) (hc : CircuitSupported S c)
 (t : ℚ) (x : Finset I) : ExprSupported S (translate t x c) := by
 induction c with
 | constant a => trivial
 | form f => exact ⟨trivial, corrections_supported S f hc t⟩
 | add a b ha hb => exact ⟨ha hc.1, hb hc.2⟩
 | mul a b ha hb => exact ⟨ha hc.1, hb hc.2⟩
 | neg a ha => exact ha hc

theorem block_difference (E : Finset I) (f : Finset I → ℚ) :
 (∑h∈range (E.card+1), ∑U∈powersetCard h E, (-1:ℚ)^(E.card-h)*f U) =
 difference E f := by
 unfold difference
 rw [sum_powerset]
 apply sum_congr rfl; intro h _
 apply sum_congr rfl; intro U hU
 rcases mem_powersetCard.mp hU with ⟨hs,hc⟩
 rw [card_sdiff_of_subset hs,hc]

theorem trace_difference (B : Finset I) (q k : Nat) (z : Finset I → Finset I → Polynomial ℚ) :
 P4c.traceEntry B q k z =
 ∑E∈B.powerset.filter (fun E => E.card≤q), difference E (fun U => (z E U).coeff k) := by
 unfold P4c.traceEntry
 have he : (∑j∈range (min q B.card+1), ∑E∈powersetCard j B,
  ∑h∈range (j+1), ∑U∈powersetCard h E, (-1:ℚ)^(j-h)*(z E U).coeff k) =
  ∑j∈range (min q B.card+1), ∑E∈powersetCard j B, difference E (fun U => (z E U).coeff k) := by
  apply sum_congr rfl; intro j _
  apply sum_congr rfl; intro E hE
  rw [← (mem_powersetCard.mp hE).2]
  exact block_difference E _
 rw [he, R1Enumeration.bounded_cardinal_loop]

theorem trace_reduce (B S : Finset I) (hS : S ⊆ B) (q k : Nat)
 (z : Finset I → Finset I → Polynomial ℚ)
 (hz : ∀E, ¬E⊆S → difference E (fun U => (z E U).coeff k)=0) :
 P4c.traceEntry S q k z = P4c.traceEntry B q k z := by
 rw [trace_difference, trace_difference]
 apply sum_subset
 · intro E hE
   rcases mem_filter.mp hE with ⟨he,hq⟩
   exact mem_filter.mpr ⟨mem_powerset.mpr ((mem_powerset.mp he).trans hS),hq⟩
 · intro E hE hn
   apply hz E
   intro he
   exact hn (mem_filter.mpr ⟨mem_powerset.mpr he,(mem_filter.mp hE).2⟩)

theorem restricted_difference_zero (B S E : Finset I) (c : Circuit I)
 (hc : CircuitSupported S c) (t : ℚ) (k : Nat) (hE : ¬E⊆S) :
 difference E (fun U => (∑x∈B.powerset.filter (fun x => E⊆x),
  eval (translate t x c) U).coeff k) = 0 := by
 obtain ⟨a,ha,hn⟩ := Finset.not_subset.mp hE
 apply difference_cancel E a ha
 intro U
 congr 1
 apply sum_congr rfl; intro x _
 exact eval_insert_outside S _ (translate_supported S c hc t x) a hn U

theorem sparse_entry_taylor (B S : Finset I) (hS : S⊆B) (c : Circuit I)
 (hc : CircuitSupported S c) (t : ℚ) (q k : Nat) (hk : k≤q) :
 P4c.traceEntry S q k (fun E U => ∑x∈B.powerset.filter (fun x => E⊆x),
   eval (translate t x c) U) =
 (taylor t (∑x∈B.powerset, original c x)).coeff k := by
 rw [trace_reduce B S hS q k _ (fun E hE => restricted_difference_zero B S E c hc t k hE)]
 exact P4c.entry_taylor B c t q k hk _ (fun _ _ => rfl)

#print axioms sparse_entry_taylor
end
end OP04.Sparse

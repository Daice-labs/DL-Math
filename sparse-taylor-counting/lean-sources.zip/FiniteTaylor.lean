import FiniteRestricted
import FiniteEndpoint
namespace OP04
open scoped BigOperators
open Finset Polynomial P4c

def recordedEntry (s:FiniteSource) (q k:Nat) (recorded:Finset s.Var→Finset s.Var→List ℚ) : ℚ :=
 ∑j∈range (min q (univ:Finset s.Var).card+1),∑E∈powersetCard j (univ:Finset s.Var),
 ∑h∈range (j+1),∑U∈powersetCard h E,(-1:ℚ)^(j-h)*coeffAt (recorded E U) k

def pointRowsCheck (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (q:Nat)
 (rows:Finset s.Var→Finset s.Var→RestrictedRow s d)
 (recorded:Finset s.Var→Finset s.Var→List ℚ) : Bool := decide
 (d.rowCheck s t=true ∧ d.fibreCheck s=true ∧ ∀j:Fin (min q (univ:Finset s.Var).card+1),
 ∀E:↥(powersetCard j.val (univ:Finset s.Var)),∀h:Fin (j.val+1),∀U:↥(powersetCard h.val E.val),
 (rows E.val U.val).tables.length=(rows E.val U.val).tuples.length ∧ (rows E.val U.val).coverageCheck s d=true ∧ expressionCheck (q+1) ((rows E.val U.val).program s d t E.val U.val) (recorded E.val U.val)=true)

theorem checked_taylor (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (q:Nat)
 (rows:Finset s.Var→Finset s.Var→RestrictedRow s d)
 (recorded:Finset s.Var→Finset s.Var→List ℚ)
 (hc:pointRowsCheck s d t q rows recorded=true) (k:Nat) (hk:k≤q) :
 recordedEntry s q k recorded=(taylor t (sourcePolynomial s)).coeff k := by
 have hc' : d.rowCheck s t=true ∧ d.fibreCheck s=true ∧
  ∀j∈range (min q (univ:Finset s.Var).card+1),∀E∈powersetCard j (univ:Finset s.Var),
  ∀h∈range (j+1),∀U∈powersetCard h E,
  (rows E U).tables.length=(rows E U).tuples.length ∧ (rows E U).coverageCheck s d=true ∧ expressionCheck (q+1) ((rows E U).program s d t E U) (recorded E U)=true := by
  simpa only [pointRowsCheck,decide_eq_true_eq,Fin.forall_iff,Subtype.forall,Finset.mem_range] using hc
 let z := fun E U:Finset s.Var=>∑x∈(univ:Finset s.Var).powerset.filter (fun x=>E⊆x),
   R1Support.eval (R1Circuit.translate t x (P4c.cnf s.cnfSource)) U
 have hj:=P4c.entry_taylor (univ:Finset s.Var) (P4c.cnf s.cnfSource) t q k hk z (fun _ _=>rfl)
 change _=(taylor t (∑x∈(univ:Finset s.Var).powerset,R1Circuit.original (P4c.cnf s.cnfSource) x)).coeff k
 rw [←hj]
 unfold recordedEntry P4c.traceEntry
 apply Finset.sum_congr rfl;intro j hj
 apply Finset.sum_congr rfl;intro E hE
 apply Finset.sum_congr rfl;intro h hh
 apply Finset.sum_congr rfl;intro U hU
 have hrow:=hc'.2.2 j hj E hE h hh U hU
 have hp:=RestrictedRow.checked_restricted s d (rows E U) t E U hrow.2.1 hc'.1 (q+1) (recorded E U) hrow.2.2
 rw [hp k (by omega)]
end OP04

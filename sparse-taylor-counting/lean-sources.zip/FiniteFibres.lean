import FiniteExpressionSource
namespace OP04
open scoped BigOperators
open Finset Polynomial
namespace FiniteDesign

theorem fibreCheck_sound (s:FiniteSource) (d:FiniteDesign s) (h:d.fibreCheck s=true) :
 ∀g:s.Group,
 ((d.fibres g).map Prod.fst).Nodup ∧
 ((d.fibres g).map Prod.fst).toFinset = (univ:Finset (Finset (Fin (s.sizes g)))).image (d.measure s g) ∧
 ∀entry∈d.fibres g,entry.2.Nodup ∧ entry.2.toFinset = (univ:Finset (Finset (Fin (s.sizes g)))).filter (fun u=>d.measure s g u=entry.1) := by
 simpa only [fibreCheck,decide_eq_true_eq] using h

theorem recorded_fibre_sum (s:FiniteSource) (d:FiniteDesign s) (h:d.fibreCheck s=true)
 (g:s.Group) (entry) (he:entry∈d.fibres g) (f:Finset (Fin (s.sizes g))→Polynomial ℚ) :
 (entry.2.map f).sum=∑u∈(univ:Finset (Finset (Fin (s.sizes g)))).filter (fun u=>d.measure s g u=entry.1),f u := by
 have hc:=(fibreCheck_sound s d h g).2.2 entry he
 rw [←List.sum_toFinset f hc.1,hc.2]

def fibreExpr (s:FiniteSource) (d:FiniteDesign s) (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ)
 (g:s.Group) (members:List (Finset (Fin (s.sizes g)))) (E U:Finset s.Var) : FiniteExpr :=
 sumExpr (members.map (fun u=>if restrict E g⊆u then factorExpr s d t y g u U else constExpr 0))

theorem meaning_fibre (s:FiniteSource) (d:FiniteDesign s) (h:d.fibreCheck s=true)
 (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ) (g:s.Group)
 (entry) (he:entry∈d.fibres g) (E U:Finset s.Var) :
 meaning (d.fibreExpr s t y g entry.2 E U)=
 ∑u∈(univ:Finset (Finset (Fin (s.sizes g)))).filter (fun u=>d.measure s g u=entry.1),
 if restrict E g⊆u then localFactor s.clauses s.vars s.forms t d.lam y g u U else 0 := by
 simp only [fibreExpr,meaning_sum,List.map_map]
 have hf: (meaning ∘ (fun u=>if restrict E g⊆u then factorExpr s d t y g u U else constExpr 0))=
  (fun u=>if restrict E g⊆u then localFactor s.clauses s.vars s.forms t d.lam y g u U else 0) := by
  funext u
  dsimp only [Function.comp_apply]
  split <;> simp [meaning_factor]
 rw [hf]
 exact recorded_fibre_sum s d h g entry he _

theorem checked_fibre (s:FiniteSource) (d:FiniteDesign s) (h:d.fibreCheck s=true)
 (t:ℚ) (y:∀h:s.Group,Fin (d.measurements h)→ℚ) (g:s.Group)
 (entry) (he:entry∈d.fibres g) (E U:Finset s.Var) (J:Nat) (recorded:List ℚ)
 (ha:expressionCheck J (d.fibreExpr s t y g entry.2 E U) recorded=true) :
 Represents J recorded (∑u∈(univ:Finset (Finset (Fin (s.sizes g)))).filter (fun u=>d.measure s g u=entry.1),
 if restrict E g⊆u then localFactor s.clauses s.vars s.forms t d.lam y g u U else 0) := by
 rw [←meaning_fibre s d h t y g entry he E U]
 exact expressionCheck_sound J _ _ ha
end FiniteDesign
end OP04

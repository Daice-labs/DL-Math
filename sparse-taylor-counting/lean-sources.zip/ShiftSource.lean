import FormDelta

namespace R1ShiftSource
open R1Shift R1FormDelta R1PythonLoops Polynomial
noncomputable section

inductive OrderBody where
 | addTerm
 deriving Repr, DecidableEq
inductive RowBody where
 | orders : OrderBody → RowBody
 | skipZero : RowBody → RowBody
 deriving Repr, DecidableEq
inductive ShiftOp where
 | coefficients : RowBody → ShiftOp
 deriving Repr, DecidableEq

def executeRow (t : ℚ) (J k : Nat) (c : ℚ) :
    RowBody → (Nat → ℚ) → (Nat → ℚ)
 | .orders .addTerm, out =>
     (List.range (min k (J-1)+1)).foldl
       (fun out j => addAt out j (weight t c k j)) out
 | .skipZero body, out => if c=0 then out else executeRow t J k c body out

def executeShift (cs : List ℚ) (t : ℚ) (J : Nat) :
    ShiftOp → (Nat → ℚ) → (Nat → ℚ)
 | .coefficients body, out =>
     (enumerate cs).foldl (fun out kc => executeRow t J kc.1 kc.2 body out) out

def shiftProgram : ShiftOp := .coefficients (.skipZero (.orders .addTerm))

theorem shift_program_denotation (cs : List ℚ) (t : ℚ) (J : Nat) :
    executeShift cs t J shiftProgram (fun _ => 0) = pshift cs t J := rfl

theorem shift_program_correct (cs : List ℚ) (t : ℚ) (J j : Nat) (hJ:0<J) (hj:j<J) :
    executeShift cs t J shiftProgram (fun _ => 0) j =
      (taylor t (polynomial (enumerate cs))).coeff j := by
  rw [shift_program_denotation]
  exact pshift_correct cs t J j hJ hj

inductive FormOp where
 | emit
 | resetConstant : FormOp → FormOp
 | freshShift : FormOp → FormOp
 deriving Repr, DecidableEq

def executeFormBody (cs : List ℚ) (t : ℚ) (J : Nat) :
    FormOp → (Nat → ℚ) → (Nat → ℚ)
 | .emit, scratch => scratch
 | .resetConstant body, scratch => executeFormBody cs t J body (setZero scratch)
 | .freshShift body, _ => executeFormBody cs t J body
      (executeShift cs t J shiftProgram (fun _ => 0))

def formProgram : FormOp := .freshShift (.resetConstant .emit)

def executeForms {K : Type*} [DecidableEq K] (rows : List (K × List ℚ))
    (t : ℚ) (J : Nat) (op : FormOp) : K → Option (Nat → ℚ) :=
  rows.foldl (fun d entry => store entry.1
    (executeFormBody entry.2 t J op (fun _ => 0)) d) (fun _ => none)

theorem form_program_denotation {K : Type*} [DecidableEq K]
    (rows : List (K × List ℚ)) (t : ℚ) (J : Nat) :
    executeForms rows t J formProgram = formDelta rows t J := rfl

theorem form_program_correct {K : Type*} [DecidableEq K]
    (rows : List (K × List ℚ)) (key : K) (cs : List ℚ)
    (h : inputMap rows key=some cs) (t : ℚ) (J : Nat) (hJ:0<J) :
    ∃ out, executeForms rows t J formProgram key=some out ∧
      ∀ j, j<J → out j=(taylor t (polynomial (enumerate cs))-
        C ((polynomial (enumerate cs)).eval t)).coeff j := by
  rw [form_program_denotation]
  exact form_delta_correct rows key cs h t J hJ

#print axioms shift_program_correct
#print axioms form_program_correct
end
end R1ShiftSource

import Generic
import Difference
import Mathlib.Algebra.BigOperators.Ring.List

open scoped BigOperators
namespace R1Support
open Finset Polynomial R1Difference
noncomputable section
variable {I : Type*} [DecidableEq I]
abbrev Term (I : Type*) := Finset I × Polynomial ℚ

def termEval (t : Term I) (U : Finset I) : Polynomial ℚ := if t.1 ⊆ U then t.2 else 0
def termsEval (ts : List (Term I)) (U : Finset I) : Polynomial ℚ := (ts.map (fun t => termEval t U)).sum
def multiply (ts us : List (Term I)) : List (Term I) :=
  ts.flatMap fun t => us.map fun u => (t.1 ∪ u.1, t.2*u.2)
def Bounded (ts : List (Term I)) : Prop := ∀ t ∈ ts, X ^ t.1.card ∣ t.2

lemma term_multiply (t u : Term I) (U : Finset I) :
    termEval (t.1 ∪ u.1, t.2*u.2) U = termEval t U * termEval u U := by
  simp only [termEval,union_subset_iff]
  by_cases h : t.1 ⊆ U <;> by_cases h' : u.1 ⊆ U <;> simp [h,h']

lemma multiply_eval (ts us : List (Term I)) (U : Finset I) :
    termsEval (multiply ts us) U = termsEval ts U * termsEval us U := by
  induction ts with
  | nil => simp [multiply,termsEval]
  | cons t ts ih =>
    have hu : termsEval (us.map (fun u => (t.1 ∪ u.1,t.2*u.2))) U =
        termEval t U * termsEval us U := by
      simp only [termsEval,List.map_map,Function.comp_def,term_multiply]
      rw [List.sum_map_mul_left]
    change termsEval ((us.map (fun u => (t.1 ∪ u.1,t.2*u.2))) ++ multiply ts us) U = _
    have hadd : ∀ a b : List (Term I), termsEval (a++b) U = termsEval a U + termsEval b U := by
      intro a b; simp [termsEval,List.sum_append]
    rw [hadd,hu,ih]
    simp only [termsEval,List.map_cons,List.sum_cons,add_mul]

lemma bounded_multiply (ts us : List (Term I)) (ht : Bounded ts) (hu : Bounded us) :
    Bounded (multiply ts us) := by
  intro v hv
  simp only [multiply,List.mem_flatMap,List.mem_map] at hv
  obtain ⟨t,ht',u,hu',rfl⟩ := hv
  have h := mul_dvd_mul (ht t ht') (hu u hu')
  rw [← pow_add] at h
  exact (pow_dvd_pow X (card_union_le t.1 u.1)).trans h

inductive Expr (I : Type*) where
 | base : Polynomial ℚ → Expr I
 | correction : I → Polynomial ℚ → ℚ → Expr I
 | add : Expr I → Expr I → Expr I
 | mul : Expr I → Expr I → Expr I
 | neg : Expr I → Expr I

def delta (p : Polynomial ℚ) (t : ℚ) := taylor t p - C (p.eval t)
def eval : Expr I → Finset I → Polynomial ℚ
 | .base p, _ => p
 | .correction i p t, U => if i ∈ U then delta p t else 0
 | .add a b, U => eval a U + eval b U
 | .mul a b, U => eval a U * eval b U
 | .neg a, U => -eval a U

def expand : Expr I → List (Term I)
 | .base p => [(∅,p)]
 | .correction i p t => [({i},delta p t)]
 | .add a b => expand a ++ expand b
 | .mul a b => multiply (expand a) (expand b)
 | .neg a => (expand a).map (fun t => (t.1,-t.2))

theorem expand_correct (e : Expr I) (U : Finset I) : termsEval (expand e) U = eval e U := by
  induction e with
  | base p => simp [expand,termsEval,termEval,eval]
  | correction i p t => simp [expand,termsEval,termEval,eval]
  | add a b ha hb => simp [expand,termsEval,eval,List.sum_append] at *; rw [ha,hb]
  | mul a b ha hb => simp only [expand,multiply_eval,eval,ha,hb]
  | neg a ha =>
    simp only [expand,termsEval,List.map_map,Function.comp_def]
    have h : ∀ t : Term I, termEval (t.1,-t.2) U = -termEval t U := by
      intro t; by_cases h : t.1 ⊆ U <;> simp [termEval,h]
    simp_rw [h]
    change _ = -(eval a U)
    calc
      _ = -termsEval (expand a) U := by
        simpa only [termsEval,List.map_map,Function.comp_def] using
          (List.sum_neg ((expand a).map (fun t => termEval t U))).symm
      _ = _ := congrArg Neg.neg ha

theorem coefficient_support (e : Expr I) : Bounded (expand e) := by
  induction e with
  | base p => simp [Bounded,expand]
  | correction i p t =>
    simp only [Bounded,expand,List.mem_singleton,forall_eq,card_singleton,pow_one]
    exact X_dvd_iff.mpr (R1.correction_zero p t)
  | add a b ha hb =>
    intro t ht
    rcases List.mem_append.mp ht with h | h
    · exact ha t h
    · exact hb t h
  | mul a b ha hb => exact bounded_multiply _ _ ha hb
  | neg a ha =>
    intro t ht
    obtain ⟨u,hu,rfl⟩ := List.mem_map.mp ht
    exact dvd_neg.mpr (ha u hu)

-- No hypothesis about support is supplied: it follows from the actual expression.
theorem coefficient_support_vanishes (e : Expr I) (t : Term I) (ht : t ∈ expand e)
    (k : Nat) (hk : k < t.1.card) : t.2.coeff k = 0 :=
  X_pow_dvd_iff.mp (coefficient_support e t ht) k hk

lemma difference_add (E : Finset I) (f g : Finset I → ℚ) :
    difference E (fun U => f U + g U) = difference E f + difference E g := by
  simp only [difference,mul_add,sum_add_distrib]

lemma difference_scale (E : Finset I) (c : ℚ) (f : Finset I → ℚ) :
    difference E (fun U => c * f U) = c * difference E f := by
  unfold difference
  rw [mul_sum]
  apply sum_congr rfl
  intro U _
  ring

lemma term_difference (E : Finset I) (t : Term I) (k : Nat) :
    difference E (fun U => (termEval t U).coeff k) =
      if t.1 = E then t.2.coeff k else 0 := by
  have h : (fun U => (termEval t U).coeff k) =
      (fun U => t.2.coeff k * R1Difference.monomial t.1 U) := by
    funext U
    by_cases h : t.1 ⊆ U <;> simp [termEval,R1Difference.monomial,h]
  rw [h,difference_scale,difference_monomial]
  by_cases h : t.1 = E <;> simp [h]

lemma terms_difference (E : Finset I) (ts : List (Term I)) (k : Nat) :
    difference E (fun U => (termsEval ts U).coeff k) =
      (ts.map (fun t => if t.1 = E then t.2.coeff k else 0)).sum := by
  induction ts with
  | nil => simp [termsEval,difference]
  | cons t ts ih =>
    have h : (fun U => (termsEval (t::ts) U).coeff k) =
        (fun U => (termEval t U).coeff k + (termsEval ts U).coeff k) := by
      funext U
      simp [termsEval]
    rw [h,difference_add,term_difference,ih]
    rfl

theorem difference_above_order (e : Expr I) (E : Finset I) (k : Nat)
    (hk : k < E.card) : difference E (fun U => (eval e U).coeff k) = 0 := by
  have h : (fun U => (eval e U).coeff k) = (fun U => (termsEval (expand e) U).coeff k) := by
    funext U; rw [expand_correct]
  rw [h,terms_difference]
  apply List.sum_eq_zero
  intro v hv
  obtain ⟨t,ht,rfl⟩ := List.mem_map.mp hv
  by_cases he : t.1 = E
  · simp only [if_pos he]
    exact coefficient_support_vanishes e t ht k (by simpa [he] using hk)
  · simp [he]

-- Full generic truncation theorem. No support or finite-difference hypothesis.
theorem truncated_reconstruction (e : Expr I) (A : Finset I) (q k : Nat)
    (hk : k ≤ q) :
    (∑ E ∈ A.powerset.filter (fun E => E.card ≤ q),
      difference E (fun U => (eval e U).coeff k)) = (eval e A).coeff k := by
  calc
    _ = ∑ E ∈ A.powerset, difference E (fun U => (eval e U).coeff k) := by
      apply sum_subset (filter_subset _ _)
      intro E hE hn
      have hq : ¬ E.card ≤ q := by intro h; exact hn (mem_filter.mpr ⟨hE,h⟩)
      exact difference_above_order e E k (lt_of_le_of_lt hk (Nat.lt_of_not_ge hq))
    _ = _ := reconstruction A _

set_option pp.fullNames true
#print axioms difference_above_order
#print axioms truncated_reconstruction
#print axioms expand_correct
#print axioms coefficient_support
#print axioms coefficient_support_vanishes
end
end R1Support

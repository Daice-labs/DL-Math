import PythonLoops
import Mathlib.Algebra.BigOperators.NatAntidiagonal
import Lean.Elab.Tactic.Omega

open scoped BigOperators
namespace R1Multiply
open Finset Polynomial R1PythonLoops
noncomputable section

theorem list_range (n : Nat) (f : Nat → ℚ) :
    ((List.range n).map f).sum = ∑ i ∈ range n, f i := by
  induction n with
  | zero => simp
  | succ n ih => simp [List.range_succ, ih, sum_range_succ]

theorem flat_sum {A : Type*} (xs : List A) (f : A → List ℚ) :
    (xs.flatMap f).sum = (xs.map (fun a => (f a).sum)).sum := by
  induction xs with
  | nil => simp
  | cons x xs ih => simp [ih]

theorem pairs_sum (J : Nat) (f : Nat × Nat → ℚ) :
    ((pairs J).map f).sum = ∑ i ∈ range J, ∑ j ∈ range (J-i), f (i,j) := by
  simp [pairs, List.map_flatMap, flat_sum, List.map_map, list_range]

theorem inner (J k i : Nat) (a b : Nat → ℚ) (hk : k < J) :
    (∑ j ∈ range (J-i), if k=i+j then a i*b j else 0) =
    if i≤k then a i*b (k-i) else 0 := by
  by_cases hi : i≤k
  · rw [if_pos hi]
    have he : ∀ j, (k=i+j) ↔ j=k-i := by intro j; omega
    simp_rw [he]
    have hb : k-i < J-i := by omega
    simp [hb]
  · rw [if_neg hi]
    apply sum_eq_zero
    intro j _
    have hn : k ≠ i+j := by omega
    simp [hn]

theorem convolution (J : Nat) (p r : Polynomial ℚ) (k : Nat) (hk : k<J) :
    zmulLoop J p.coeff r.coeff k = (p*r).coeff k := by
  rw [zmul_loop_correct,pairs_sum]
  simp_rw [inner J k _ p.coeff r.coeff hk]
  rw [coeff_mul, Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk]
  calc
    _ = ∑ i ∈ range (k+1), (if i≤k then p.coeff i*r.coeff (k-i) else 0) := by
      symm
      apply sum_subset (range_mono (by omega : k+1 ≤ J))
      intro i hi hn
      have h : ¬ i≤k := by simpa using hn
      simp [h]
    _ = _ := by
      apply sum_congr rfl
      intro i hi
      have h : i≤k := by simpa using hi
      simp [h]

set_option pp.fullNames true
#print axioms convolution
end
end R1Multiply

import FiniteCoefficients
namespace OP04
open scoped BigOperators
open Finset Polynomial

def addVec (J:Nat) (a b:List ℚ) : List ℚ := List.ofFn (fun k:Fin J=>coeffAt a k+coeffAt b k)
def negVec (J:Nat) (a:List ℚ) : List ℚ := List.ofFn (fun k:Fin J=> -coeffAt a k)
def mulVec (J:Nat) (a b:List ℚ) : List ℚ := List.ofFn (fun k:Fin J=>∑i∈range (k.val+1),coeffAt a i*coeffAt b (k.val-i))
def Represents (J:Nat) (a:List ℚ) (p:Polynomial ℚ) : Prop := ∀k,k<J→coeffAt a k=p.coeff k

theorem ofFn_at (J:Nat) (f:Fin J→ℚ) (k:Nat) (hk:k<J) : coeffAt (List.ofFn f) k=f ⟨k,hk⟩ := by
 simp [coeffAt,hk]

theorem addVec_sound (J:Nat) (a b:List ℚ) (p q:Polynomial ℚ) (ha:Represents J a p) (hb:Represents J b q) :
 Represents J (addVec J a b) (p+q) := by
 intro k hk;rw [addVec,ofFn_at J _ k hk];simp [ha k hk,hb k hk]
theorem negVec_sound (J:Nat) (a:List ℚ) (p:Polynomial ℚ) (ha:Represents J a p) :
 Represents J (negVec J a) (-p) := by
 intro k hk;rw [negVec,ofFn_at J _ k hk];simp [ha k hk]
theorem mulVec_sound (J:Nat) (a b:List ℚ) (p q:Polynomial ℚ) (ha:Represents J a p) (hb:Represents J b q) :
 Represents J (mulVec J a b) (p*q) := by
 intro k hk
 rw [mulVec,ofFn_at J _ k hk,coeff_mul,Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk]
 dsimp only
 apply sum_congr rfl
 intro i hi
 have hi':i≤k:=by have:=mem_range.mp hi;omega
 rw [ha i (by omega),hb (k-i) (by omega)]

inductive FiniteExpr where
 | leaf : List ℚ→FiniteExpr
 | add : FiniteExpr→FiniteExpr→FiniteExpr
 | mul : FiniteExpr→FiniteExpr→FiniteExpr
 | neg : FiniteExpr→FiniteExpr
 deriving Repr
noncomputable def meaning : FiniteExpr→Polynomial ℚ
 | .leaf cs=>polynomial cs
 | .add a b=>meaning a+meaning b
 | .mul a b=>meaning a*meaning b
 | .neg a=> -meaning a
def execute (J:Nat) : FiniteExpr→List ℚ
 | .leaf cs=>List.ofFn (fun k:Fin J=>coeffAt cs k)
 | .add a b=>addVec J (execute J a) (execute J b)
 | .mul a b=>mulVec J (execute J a) (execute J b)
 | .neg a=>negVec J (execute J a)
theorem execute_sound (J:Nat) (e:FiniteExpr) : Represents J (execute J e) (meaning e) := by
 induction e with
 | leaf cs=>intro k hk;rw [execute,ofFn_at J _ k hk];exact (coeff_polynomial cs k).symm
 | add a b ha hb=>exact addVec_sound J _ _ _ _ ha hb
 | mul a b ha hb=>exact mulVec_sound J _ _ _ _ ha hb
 | neg a ha=>exact negVec_sound J _ _ ha

def expressionCheck (J:Nat) (e:FiniteExpr) (recorded:List ℚ) : Bool := decide (recorded=execute J e)
theorem expressionCheck_sound (J:Nat) (e:FiniteExpr) (recorded:List ℚ) (h:expressionCheck J e recorded=true) :
 Represents J recorded (meaning e) := by
 have he:recorded=execute J e:=by simpa only [expressionCheck,decide_eq_true_eq] using h
 rw [he];exact execute_sound J e
-- A genuine truncation: the discarded quadratic term is nonzero.
example : execute 2 (.mul (.leaf [1,1]) (.leaf [1,1]))=[1,2] := by decide +kernel
example : execute 3 (.mul (.leaf [1,1]) (.leaf [1,1]))=[1,2,1] := by decide +kernel
#print axioms execute_sound
end OP04

import Circuit
import Mathlib.Data.List.Nodup

namespace R1PythonLoops
noncomputable section
open scoped BigOperators

-- A Python for-loop's mutable state is threaded left-to-right.
-- update semantics: write exactly one list element, preserving all others.
def addAt (a : Nat → ℚ) (index : Nat) (v : ℚ) : Nat → ℚ :=
  fun k => if k=index then a k+v else a k

theorem addAt_pointwise (a : Nat → ℚ) (index : Nat) (v : ℚ) (k : Nat) :
    addAt a index v k = a k + if k=index then v else 0 := by
  by_cases h : k=index <;> simp [addAt,h]

def accumulation {A : Type*} (xs : List A) (index : A → Nat) (weight : A → ℚ)
    (a : Nat → ℚ) : Nat → ℚ :=
  xs.foldl (fun a x => addAt a (index x) (weight x)) a

theorem accumulation_correct {A : Type*} (xs : List A) (index : A → Nat)
    (weight : A → ℚ) (a : Nat → ℚ) (k : Nat) :
    accumulation xs index weight a k =
      a k + (xs.map (fun x => if k=index x then weight x else 0)).sum := by
  induction xs generalizing a with
  | nil => simp [accumulation]
  | cons x xs ih =>
    change accumulation xs index weight (addAt a (index x) (weight x)) k = _
    rw [ih,addAt_pointwise]
    simp [add_assoc]

-- The two explicit zero-skipping branches in engine.zmul are algebraically neutral.
theorem zero_skips (ai bj : ℚ) :
    (if ai=0 then 0 else if bj=0 then 0 else ai*bj) = ai*bj := by
  by_cases ha : ai=0 <;> by_cases hb : bj=0 <;> simp [ha,hb]

-- The actual nested range order in zmul, after enumerate(a), when len(a)=J.
def pairs (J : Nat) : List (Nat × Nat) :=
  (List.range J).flatMap (fun i => (List.range (J-i)).map (fun j => (i,j)))

def zmulLoop (J : Nat) (a b : Nat → ℚ) : Nat → ℚ :=
  accumulation (pairs J) (fun ij => ij.1+ij.2)
    (fun ij => if a ij.1=0 then 0 else if b ij.2=0 then 0 else a ij.1*b ij.2) (fun _ => 0)

theorem zmul_loop_correct (J : Nat) (a b : Nat → ℚ) (k : Nat) :
    zmulLoop J a b k = ((pairs J).map
      (fun ij => if k=ij.1+ij.2 then a ij.1*b ij.2 else 0)).sum := by
  unfold zmulLoop
  rw [accumulation_correct]
  simp_rw [zero_skips]
  simp

-- setdefault(key,[]).append(u): values are accumulated without collapsing multiplicity.
def appendBucket {X Y : Type*} [DecidableEq Y] (key : X → Y)
    (table : Y → List X) (x : X) : Y → List X :=
  fun y => if y=key x then table y ++ [x] else table y

def groupTable {X Y : Type*} [DecidableEq Y] (key : X → Y) (xs : List X)
    (table : Y → List X) : Y → List X :=
  xs.foldl (appendBucket key) table

theorem group_table_correct {X Y : Type*} [DecidableEq Y] (key : X → Y)
    (xs : List X) (table : Y → List X) (y : Y) :
    groupTable key xs table y = table y ++ xs.filter (fun x => decide (y=key x)) := by
  induction xs generalizing table with
  | nil => simp [groupTable]
  | cons x xs ih =>
    change groupTable key xs (appendBucket key table x) y = _
    rw [ih]
    by_cases h : y=key x <;> simp [appendBucket,h,List.append_assoc]

set_option pp.fullNames true
#print axioms accumulation_correct
#print axioms zmul_loop_correct
#print axioms group_table_correct
end
end R1PythonLoops

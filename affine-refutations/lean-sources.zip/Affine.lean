import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset

open scoped BigOperators
namespace Affine
-- c is the normalized right-hand side b-a (equal to b+a over GF(2)).
theorem separating_witness_unsat {m n : ℕ}
    (A : Fin m → Fin n → ZMod 2) (c y : Fin m → ZMod 2)
    (hcols : ∀ j, ∑ i, y i * A i j = 0)
    (hrhs : ∑ i, y i * c i = 1) :
    ¬ ∃ x : Fin n → ZMod 2, ∀ i, ∑ j, A i j * x j = c i := by
  rintro ⟨x, hx⟩
  have zero : ∑ i, y i * (∑ j, A i j * x j) = 0 := by
    simp_rw [Finset.mul_sum, ← mul_assoc]
    rw [Finset.sum_comm]
    simp_rw [← Finset.sum_mul, hcols, zero_mul]
    simp
  simp_rw [hx] at zero
  rw [hrhs] at zero
  exact one_ne_zero zero
#print axioms separating_witness_unsat
end Affine

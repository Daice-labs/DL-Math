import UPTheory
import PBComposition
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

def liftPB {u v : Nat} (σ : Fin u → Fin v) (c : PB u) : PB v :=
  ⟨fun j => ∑ i, if σ i=j then c.coeff i else 0,c.rhs⟩

theorem lift_at {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (c : PB u) (i : Fin u) : (liftPB σ c).coeff (σ i)=c.coeff i := by
  simp [liftPB,hinj.eq_iff]

theorem lift_out {u v : Nat} (σ : Fin u → Fin v) (c : PB u) (j : Fin v)
    (hj : ¬ ∃ i, σ i=j) : (liftPB σ c).coeff j=0 := by
  change (∑ i, if σ i=j then c.coeff i else 0)=0
  apply Finset.sum_eq_zero
  intro i _
  have hh : σ i≠j := by intro he; exact hj ⟨i,he⟩
  simp [hh]

theorem sum_transport {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (f : Fin v → Int) (g : Fin u → Int)
    (ha : ∀ i, f (σ i)=g i) (hz : ∀ j, (¬ ∃ i, σ i=j) → f j=0) :
    (∑ j, f j)=∑ i, g i := by
  calc
    (∑ j, f j) = ∑ j∈Finset.univ.image σ, f j := by
      symm
      apply Finset.sum_subset (Finset.subset_univ _)
      intro j _ hj
      apply hz j
      rintro ⟨i,rfl⟩
      exact hj (by simp)
    _ = ∑ i, g i := by
      rw [Finset.sum_image]
      · apply Finset.sum_congr rfl; intro i _; exact ha i
      · intro i _ j _ h; exact hinj h

theorem maximum_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (c : PB u) (p : Partial v) : maximum (liftPB σ c) p=maximum c (p ∘ σ) := by
  apply sum_transport σ hinj
  · intro i
    simp only [lift_at σ hinj,Function.comp_apply]
  · intro j hj
    rw [lift_out σ c j hj]
    cases p j <;> simp
    rename_i b; cases b <;> rfl

theorem lift_negate {u v : Nat} (σ : Fin u → Fin v) (c : PB u) :
    liftPB σ (negate c)=negate (liftPB σ c) := by
  apply pb_ext
  · intro j
    simp only [liftPB,negate]
    rw [← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro i _
    split <;> simp
  · rfl

theorem pull_update {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (p : Partial v) (j : Fin u) (b : Option Bool) :
    (Function.update p (σ j) b) ∘ σ = Function.update (p ∘ σ) j b := by
  funext i
  by_cases h : i=j
  · subst i; simp
  · have hh : σ i≠σ j := fun he => h (hinj he)
    simp [Function.comp_apply,Function.update_of_ne h,Function.update_of_ne hh]

theorem conflict_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (db : List (PB u)) (p : Partial v) :
    conflict (db.map (liftPB σ)) p=conflict db (p ∘ σ) := by
  simp only [conflict,List.any_map,Function.comp_def]
  simp_rw [maximum_lift σ hinj]
  rfl

theorem closed_pullback {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (db : List (PB u)) (p : Partial v) (hc : Closed (db.map (liftPB σ)) p) : Closed db (p ∘ σ) := by
  constructor
  · rw [← conflict_lift σ hinj]; exact hc.1
  · intro j hj
    have hh := hc.2 (σ j) hj
    simpa only [conflict_lift σ hinj,pull_update σ hinj] using hh

theorem rup_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (db : List (PB u)) (c : PB u) (h : rup db c=true) : rup (db.map (liftPB σ)) (liftPB σ c)=true := by
  cases hh : rup (db.map (liftPB σ)) (liftPB σ c)
  · obtain ⟨p,hp,hclosed⟩ := up_false_closed (v+1) _ (fun _ => none) (by omega) hh
    have he : db.map (liftPB σ)++[negate (liftPB σ c)] = (db++[negate c]).map (liftPB σ) := by
      simp [lift_negate]
    rw [he] at hclosed
    have hlocal := closed_pullback σ hinj _ p hclosed
    have hz := up_below_closed (u+1) (db++[negate c]) (db++[negate c]) (fun d hd => hd)
      (fun _ => none) (p ∘ σ) (extends_none _) hlocal
    change up (u+1) (db++[negate c]) (fun _ => none)=true at h
    rw [hz] at h; contradiction
  · rfl

theorem trivial_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (c : PB u) : trivial (liftPB σ c)=trivial c := by
  have hs : (∑ j, min 0 ((liftPB σ c).coeff j)) = ∑ i, min 0 (c.coeff i) := by
    apply sum_transport σ hinj
    · intro i; rw [lift_at σ hinj]
    · intro j hj; simp [lift_out σ c j hj]
  unfold trivial
  rw [hs]
  rfl

theorem weakImplies_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (a b : PB u) : weakImplies (liftPB σ a) (liftPB σ b)=weakImplies a b := by
  have hs : (∑ j, min 0 ((liftPB σ b).coeff j-(liftPB σ a).coeff j)) =
      ∑ i, min 0 (b.coeff i-a.coeff i) := by
    apply sum_transport σ hinj
    · intro i; rw [lift_at σ hinj,lift_at σ hinj]
    · intro j hj; simp [lift_out σ a j hj,lift_out σ b j hj]
  unfold weakImplies
  rw [hs]
  rfl

theorem goal_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (small : List (PB u)) (big : List (PB v)) (hdb : ∀ d∈small, liftPB σ d∈big)
    (hint c : PB u) (h : goal small hint c=true) : goal big (liftPB σ hint) (liftPB σ c)=true := by
  simp only [goal,Bool.or_eq_true] at h ⊢
  rcases h with ((ht | hw) | hd) | hr
  · exact Or.inl (Or.inl (Or.inl (by simpa only [trivial_lift σ hinj] using ht)))
  · exact Or.inl (Or.inl (Or.inr (by simpa only [weakImplies_lift σ hinj] using hw)))
  · obtain ⟨d,hd,he⟩ := List.any_eq_true.mp hd
    have he' : d=c := of_decide_eq_true he
    subst d
    exact Or.inl (Or.inr (List.any_eq_true.mpr ⟨liftPB σ c,hdb c hd,by simp⟩))
  · apply Or.inr
    apply rup_mono ((small++[hint]).map (liftPB σ)) (big++[liftPB σ hint]) ?_ (liftPB σ c)
      (rup_lift σ hinj _ c hr)
    intro d hd
    obtain ⟨d,hdmem,rfl⟩ := List.mem_map.mp hd
    rcases List.mem_append.mp hdmem with hd | hd
    · exact List.mem_append_left _ (hdb d hd)
    · simp only [List.mem_singleton] at hd; subst d; simp

#print axioms rup_lift
#print axioms goal_lift
end OP03.Kernel

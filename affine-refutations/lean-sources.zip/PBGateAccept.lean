import PBGateSource
set_option maxHeartbeats 0
namespace OP03.Kernel

structure GateFit (g : Emit.Gate) (h : Nat) : Prop where
  posX : 0 < g.x
  posV : 0 < g.v
  posZ : 0 < g.z
  boundX : g.x≤h
  boundV : g.v≤h
  boundZ : g.z≤h
  distinct : Emit.DistinctGate g

def Bounded {v : Nat} (db : List (PB v)) (h : Nat) : Prop :=
  ∀ c∈db, ∀ j : Fin v, h < j.val → c.coeff j=0

def gateMap {v : Nat} (g : Emit.Gate) (h : Nat) (hf : GateFit g h) (hv : h+2 < v) : Fin 6 → Fin v :=
  ![⟨0,by omega⟩,⟨g.x,by have := hf.boundX; omega⟩,
    ⟨g.v,by have := hf.boundV; omega⟩,⟨g.z,by have := hf.boundZ; omega⟩,
    ⟨h+1,by omega⟩,⟨h+2,hv⟩]

theorem gateMap_injective {v : Nat} (g : Emit.Gate) (h : Nat) (hf : GateFit g h) (hv : h+2 < v) :
    Function.Injective (gateMap g h hf hv) := by
  intro a b hab
  have he := congrArg Fin.val hab
  have := hf.posX; have := hf.posV; have := hf.posZ
  have := hf.boundX; have := hf.boundV; have := hf.boundZ
  rcases hf.distinct with ⟨hxy,hxz,hyz⟩
  fin_cases a <;> fin_cases b <;> simp [gateMap] at he ⊢ <;> omega

theorem gateMap_positive {v : Nat} (g : Emit.Gate) (h : Nat) (hf : GateFit g h) (hv : h+2 < v) :
    ∀ i, 0 < i.val → 0 < (gateMap g h hf hv i).val := by
  intro i hi
  have := hf.posX; have := hf.posV; have := hf.posZ
  fin_cases i <;> simp [gateMap] at hi ⊢ <;> omega

theorem gateMap_bounded {v : Nat} (g : Emit.Gate) (h : Nat) (hf : GateFit g h) (hv : h+2 < v) :
    ∀ i, (gateMap g h hf hv i).val≤h+2 := by
  intro i
  have := hf.boundX; have := hf.boundV; have := hf.boundZ
  fin_cases i <;> simp [gateMap] <;> omega

theorem gateMap_gate {v : Nat} (g : Emit.Gate) (h : Nat) (hf : GateFit g h) (hv : h+2 < v) :
    liftedGate (gateMap g h hf hv)=g := by cases g; rfl

theorem gate_accepted {v : Nat} (g : Emit.Gate) (h : Nat) (hf : GateFit g h) (hv : h+2 < v)
    (db : List (PB v)) (hb : Bounded db h)
    (hc : ∀ c∈Emit.gateClauses g, fromClause v c∈db) :
    ∃ added, added.length=23 ∧
      run db (Emit.gateBlock g (h+1) (h+2) db.length)=some (db++added) ∧
      lookup (db++added) (db.length+22)=some (gatePB v g (h+1)) ∧
      lookup (db++added) (db.length+23)=some (neg (gatePB v g (h+1))) ∧
      Bounded (db++added) (h+2) := by
  let σ := gateMap g h hf hv
  have hinj := gateMap_injective g h hf hv
  have hpos := gateMap_positive g h hf hv
  have hcl : ∀ c∈Emit.gateClauses (liftedGate σ), fromClause v c∈db := by
    simpa [σ,gateMap_gate] using hc
  have hfr : ∀ c∈db, c.coeff (σ 4)=0 ∧ c.coeff (σ 5)=0 := by
    intro c hc
    exact ⟨hb c hc (σ 4) (by simp [σ,gateMap]),hb c hc (σ 5) (by simp [σ,gateMap])⟩
  obtain ⟨added,hlen,hr,hlo,hhi,hadded⟩ := gate_accepted_embedding σ hinj hpos db hcl hfr
  have hg : liftedGate σ=g := gateMap_gate g h hf hv
  have h4 : (σ 4).val=h+1 := by simp [σ,gateMap]
  have h5 : (σ 5).val=h+2 := by simp [σ,gateMap]
  refine ⟨added,hlen,?_,?_,?_,?_⟩
  · simpa only [hg,h4,h5] using hr
  · simpa only [hg,h4,h5] using hlo
  · simpa only [hg,h4,h5] using hhi
  · intro c hc j hj
    rcases List.mem_append.mp hc with hc | hc
    · exact hb c hc j (by omega)
    · obtain ⟨d,rfl⟩ := hadded c hc
      apply lift_out
      rintro ⟨i,hi⟩
      have hbound := gateMap_bounded g h hf hv i
      change (σ i).val≤h+2 at hbound
      have he : (σ i).val=j.val := congrArg Fin.val hi
      omega

#print axioms gate_accepted
end OP03.Kernel

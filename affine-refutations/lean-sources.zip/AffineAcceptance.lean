import PBCNF
set_option maxHeartbeats 0
namespace OP03.Acceptance
open Kernel

theorem emitted_clauses {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) :
    (Emit.generate A a b y).clauses=(Emit.rows A a b y).flatMap Emit.Row.clauses := by
  unfold Emit.generate
  dsimp only
  split <;> rfl

-- The assignment uses the actual numeric IDs in the emitted source.
theorem encode_correct {m n v : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (hv : n+m*n<v) (x : Fin n → Bool) :
    (∃ X : Fin v → Bool,
      (∀ j : Fin n, X ⟨j.val+1,by have := j.isLt; omega⟩=x j) ∧
      Models ((Emit.generate A a b y).clauses.map (fromClause v)) X) ↔ Solves A a b x := by
  rw [emitted_clauses]
  constructor
  · rintro ⟨X,hx,hm⟩
    let Y : Nat → Bool := fun k => if hk : k<v then X ⟨k,hk⟩ else false
    have he : (fun j : Fin v => Y j.val)=X := by funext j; simp [Y,j.isLt]
    have hc := (source_models_iff A a b y hv Y).mp (by rw [he]; exact hm)
    have hs := Numeric.source_implies_solves A a b y Y hc
    have hxy : (fun j : Fin n => Y (j.val+1))=x := by
      funext j
      have hj : j.val+1<v := by have := j.isLt; omega
      simp only [Y,dif_pos hj]
      exact hx j
    rw [hxy] at hs
    exact hs
  · intro hx
    refine ⟨fun j => Numeric.extension A x j.val,?_,?_⟩
    · intro j; exact Numeric.extension_original A x j
    · exact (source_models_iff A a b y hv _).mpr (Numeric.solves_implies_source A a b y x hx)

theorem emit_accepted {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (hw : Witness A a b y) :
    check (checkerVariables A a b y) (Emit.generate A a b y).clauses
      (Emit.generate A a b y).instructions (Emit.generate A a b y).conclusion=true :=
  generate_accepted A a b y hw

theorem accepted_and_counted {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (hw : Witness A a b y) :
    check (checkerVariables A a b y) (Emit.generate A a b y).clauses
      (Emit.generate A a b y).instructions (Emit.generate A a b y).conclusion=true ∧
    (¬ ∃ X, Models ((Emit.generate A a b y).clauses.map (fromClause (checkerVariables A a b y))) X) ∧
    (Emit.generate A a b y).instructions.length≤23*m*n+3 ∧
    (Emit.proofLines (Emit.generate A a b y)).length≤23*m*n+8 := by
  have ha := emit_accepted A a b y hw
  exact ⟨ha,check_sound _ _ _ _ ha,Emit.generate_size A a b y,Emit.generate_physical_lines A a b y⟩

theorem all_affine_acceptance {m n : Nat} (A : Fin m → Fin n → Bool) (a b : Fin m → Bool)
    (hu : ¬ ∃ x, Solves A a b x) :
    ∃ y, Witness A a b y ∧
      check (checkerVariables A a b y) (Emit.generate A a b y).clauses
        (Emit.generate A a b y).instructions (Emit.generate A a b y).conclusion=true ∧
      (Emit.generate A a b y).instructions.length≤23*m*n+3 ∧
      (Emit.proofLines (Emit.generate A a b y)).length≤23*m*n+8 := by
  obtain ⟨y,hy⟩ := (witness_exists_iff A a b).mp hu
  have ha := accepted_and_counted A a b y hy
  exact ⟨y,hy,ha.1,ha.2.2⟩

#print axioms encode_correct
#print axioms emit_accepted
#print axioms accepted_and_counted
#print axioms all_affine_acceptance
end OP03.Acceptance

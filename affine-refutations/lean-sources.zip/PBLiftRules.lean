import PBEmbedding
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

theorem lift_subst {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (c : PB u) (i : Fin u) (b : Bool) :
    liftPB σ (subst c i b)=subst (liftPB σ c) (σ i) b := by
  apply pb_ext
  · intro j
    by_cases hj : ∃ k, σ k=j
    · obtain ⟨k,rfl⟩ := hj
      rw [lift_at σ hinj]
      simp [subst,lift_at σ hinj,hinj.eq_iff]
    · rw [lift_out σ (subst c i b) j hj]
      have hn : j≠σ i := by intro he; exact hj ⟨i,he.symm⟩
      simp [subst,hn,lift_out σ c j hj]
  · change c.rhs-c.coeff i*ibit b=c.rhs-(liftPB σ c).coeff (σ i)*ibit b
    rw [lift_at σ hinj]

theorem subst_unchanged {v : Nat} (c : PB v) (j : Fin v) (b : Bool) (h : c.coeff j=0) : subst c j b=c := by
  apply pb_ext
  · intro i
    by_cases he : i=j
    · subst i; simp [subst,h]
    · simp [subst,he]
  · simp [subst,h]

theorem goal_self {v : Nat} (db : List (PB v)) (hint c : PB v) (hc : c∈db) : goal db hint c=true := by
  have hh : db.any (fun d => decide (d=c))=true := List.any_eq_true.mpr ⟨c,hc,by simp⟩
  simp [goal,hh]

theorem red_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (small : List (PB u)) (big : List (PB v)) (hdb : ∀ d∈small, liftPB σ d∈big)
    (c : PB u) (i : Fin u) (b : Bool) (h : red small c i b=true)
    (hframe : ∀ d∈big, (∃ e∈small, d=liftPB σ e) ∨ d.coeff (σ i)=0) :
    red big (liftPB σ c) (σ i) b=true := by
  apply List.all_eq_true.mpr
  intro d hd
  rcases List.mem_cons.mp hd with rfl | hd
  · have hh := List.all_eq_true.mp h c (by simp)
    have hl := goal_lift σ hinj small big hdb (negate c) (subst c i b) hh
    simpa only [lift_negate,lift_subst σ hinj] using hl
  · rcases hframe d hd with ⟨e,he,rfl⟩ | hz
    · have hh := List.all_eq_true.mp h e (by simp [he])
      have hl := goal_lift σ hinj small big hdb (negate c) (subst e i b) hh
      simpa only [lift_negate,lift_subst σ hinj] using hl
    · rw [subst_unchanged d (σ i) b hz]
      exact goal_self big _ d hd

theorem lift_plus {u v : Nat} (σ : Fin u → Fin v) (a b : PB u) :
    liftPB σ (plus a b)=plus (liftPB σ a) (liftPB σ b) := by
  apply pb_ext
  · intro j
    simp only [liftPB,plus]
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i _
    split <;> simp
  · rfl

theorem lift_scale {u v : Nat} (σ : Fin u → Fin v) (c : PB u) (k : Nat) :
    liftPB σ (scale c k)=scale (liftPB σ c) k := by
  apply pb_ext
  · intro j
    simp only [liftPB,scale]
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    split <;> simp
  · rfl

theorem lift_literal {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (i : Fin u) (b : Bool) : liftPB σ (literal u i.val b)=literal v (σ i).val b := by
  apply pb_ext
  · intro j
    by_cases hj : ∃ k, σ k=j
    · obtain ⟨k,rfl⟩ := hj
      rw [lift_at σ hinj]
      have he : (σ k).val=(σ i).val ↔ k.val=i.val := by
        constructor
        · intro h; exact congrArg Fin.val (hinj (Fin.ext h))
        · intro h; cases Fin.ext h; rfl
      simp [literal,he]
    · rw [lift_out σ _ j hj]
      have hn : j.val≠(σ i).val := by intro he; exact hj ⟨i,(Fin.ext he).symm⟩
      simp [literal,hn]
  · rfl

theorem lift_exactDiv {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (c r : PB u) (d : Nat) (h : exactDiv c d=some r) :
    exactDiv (liftPB σ c) d=some (liftPB σ r) := by
  unfold exactDiv at h
  split at h
  · contradiction
  · rename_i hd
    split at h
    · rename_i he
      simp only [Option.some.injEq] at h
      subst r
      have hg : ∀ j, (liftPB σ c).coeff j % (d : Int)=0 := by
        intro j
        by_cases hj : ∃ i, σ i=j
        · obtain ⟨i,rfl⟩ := hj; rw [lift_at σ hinj]; exact he i
        · simp [lift_out σ c j hj]
      unfold exactDiv
      rw [if_neg hd,if_pos hg]
      apply congrArg some
      apply pb_ext
      · intro j
        change (liftPB σ c).coeff j / (d : Int) = _
        by_cases hj : ∃ i, σ i=j
        · obtain ⟨i,rfl⟩ := hj; simp only [lift_at σ hinj]
        · rw [lift_out σ c j hj,lift_out σ _ j hj]
          simp
      · rfl
    · contradiction

#print axioms red_lift
#print axioms lift_exactDiv
end OP03.Kernel

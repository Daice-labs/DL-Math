import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Tactic

namespace OP03Parity

def bit (x : Bool) : ℕ := if x then 1 else 0

def gateCNF (a b z : Bool) : Prop :=
  (a = true ∨ b = true ∨ z = false) ∧
  (a = true ∨ b = false ∨ z = true) ∧
  (a = false ∨ b = true ∨ z = true) ∧
  (a = false ∨ b = false ∨ z = false)

theorem gate_correct (a b z : Bool) : gateCNF a b z ↔ z = Bool.xor a b := by
  unfold gateCNF
  cases a <;> cases b <;> cases z <;> decide

theorem gate_integer_parity (a b z : Bool) :
    gateCNF a b z ↔ ∃ carry : Bool, bit a + bit b + bit z = 2 * bit carry := by
  unfold gateCNF bit
  cases a <;> cases b <;> cases z <;> decide

def tailCNF (acc : Bool) : List Bool → Bool → Prop
  | [], rhs => acc = rhs
  | x :: xs, rhs => ∃ z, gateCNF acc x z ∧ tailCNF z xs rhs

theorem tail_correct (xs : List Bool) (acc rhs : Bool) :
    tailCNF acc xs rhs ↔ xs.foldl Bool.xor acc = rhs := by
  induction xs generalizing acc with
  | nil => rfl
  | cons x xs ih =>
    simp only [tailCNF, gate_correct, ih, List.foldl_cons]
    constructor
    · rintro ⟨z, hz, h⟩
      simpa [hz] using h
    · intro h
      exact ⟨Bool.xor acc x, rfl, h⟩

def chainCNF : List Bool → Bool → Prop
  | [], rhs => rhs = false
  | x :: xs, rhs => tailCNF x xs rhs

theorem chain_correct (xs : List Bool) (rhs : Bool) :
    chainCNF xs rhs ↔ xs.foldl Bool.xor false = rhs := by
  cases xs with
  | nil => simp [chainCNF, eq_comm]
  | cons x xs => simpa [chainCNF] using tail_correct xs x rhs

-- Integer equations after selecting and summing rows by a GF(2) witness.
-- This is the arithmetic core of the final divide/add contradiction.
theorem even_coefficients_odd_degree {v : ℕ} (a x : Fin v → ℤ) (k : ℤ) :
    (∑ j, (2 * a j) * x j) ≠ 2*k+1 := by
  rw [show (∑ j, (2*a j)*x j) = 2 * ∑ j, a j*x j by
    simp_rw [mul_assoc]
    rw [Finset.mul_sum]]
  omega

-- G selected gates; each has 23 derived constraints. Three global pol steps.
def derivedCount (G : ℕ) := 23*G+3
def physicalLineCount (G : ℕ) := 23*G+8

theorem derived_count_bound (G m n : ℕ) (h : G ≤ m*n) :
    derivedCount G ≤ 23*m*n+3 := by unfold derivedCount; nlinarith

theorem line_count_bound (G m n : ℕ) (h : G ≤ m*n) :
    physicalLineCount G ≤ 23*m*n+8 := by unfold physicalLineCount; nlinarith

-- The serializer's token/decimal-width estimate is proved separately on paper;
-- this lemma checks the final polynomial majorization, not Python refinement.
theorem byte_majorization (T : ℕ) (h : 2 ≤ T) :
    (23*T+8)*(128*T+64)+2*(T+1)*(64*T+32) ≤ 16384*T^2 := by
  nlinarith [sq_nonneg (T-2 : ℤ)]

end OP03Parity
#print axioms OP03Parity.gate_correct
#print axioms OP03Parity.gate_integer_parity
#print axioms OP03Parity.tail_correct
#print axioms OP03Parity.chain_correct
#print axioms OP03Parity.even_coefficients_odd_degree
#print axioms OP03Parity.derived_count_bound
#print axioms OP03Parity.line_count_bound
#print axioms OP03Parity.byte_majorization

import PBKernel
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

abbrev Partial (v : Nat) := Fin v → Option Bool
@[noinline] def freeze {v : Nat} (p : Partial v) : Partial v :=
  let values := List.ofFn p
  fun j => values[j.val]'(by simpa [values] using j.isLt)
@[simp] theorem freeze_eq {v : Nat} (p : Partial v) : freeze p=p := by
  funext j
  simp [freeze]

def maximum {v : Nat} (c : PB v) (p : Partial v) : Int :=
  ∑ j, match p j with
    | some false => 0
    | some true => c.coeff j
    | none => max 0 (c.coeff j)
def conflict {v : Nat} (db : List (PB v)) (p : Partial v) : Bool :=
  db.any fun c => decide (maximum c p < c.rhs)
def force {v : Nat} (db : List (PB v)) (p : Partial v) (j : Fin v) : Partial v :=
  if (p j).isSome then p
  else if conflict db (Function.update p j (some false)) then freeze (Function.update p j (some true))
  else if conflict db (Function.update p j (some true)) then freeze (Function.update p j (some false))
  else p
def up {v : Nat} : Nat → List (PB v) → Partial v → Bool
  | 0, db, p => conflict db p
  | k+1, db, p => if conflict db p then true else
      up k db ((List.ofFn fun j : Fin v => j).foldl (force db) p)
def negate {v : Nat} (c : PB v) : PB v := ⟨fun j => -c.coeff j,1-c.rhs⟩
def rup {v : Nat} (db : List (PB v)) (c : PB v) : Bool :=
  up (v+1) (db++[negate c]) (fun _ => none)
def trivial {v : Nat} (c : PB v) : Bool := decide (c.rhs ≤ ∑ j, min 0 (c.coeff j))
-- Adding literal bounds to the premise yields this sufficient syntactic implication.
def weakImplies {v : Nat} (a b : PB v) : Bool :=
  decide (b.rhs-a.rhs ≤ ∑ j, min 0 (b.coeff j-a.coeff j))
def subst {v : Nat} (c : PB v) (j : Fin v) (b : Bool) : PB v :=
  ⟨fun i => if i=j then 0 else c.coeff i,c.rhs-c.coeff j*ibit b⟩
def goal {v : Nat} (db : List (PB v)) (hint c : PB v) : Bool :=
  trivial c || weakImplies hint c || db.any (fun d => decide (d=c)) || rup (db++[hint]) c
def red {v : Nat} (db : List (PB v)) (c : PB v) (j : Fin v) (b : Bool) : Bool :=
  (c::db).all fun d => goal db (negate c) (subst d j b)
def wellFormed (v : Nat) (c : Emit.Constraint) : Bool :=
  c.terms.all fun (_,i) => decide (0 < i ∧ i < v)
def step {v : Nat} (db : List (PB v)) (cmd : Emit.Command) : Option (List (PB v)) := do
  let c ← match cmd with
    | .pol e => eval db e
    | .rup c => if wellFormed v c && rup db (fromConstraint v c) then some (fromConstraint v c) else none
    | .red c j b =>
        if h : 0 < j ∧ j < v then
          if wellFormed v c && red db (fromConstraint v c) ⟨j,h.2⟩ b then some (fromConstraint v c) else none
        else none
  return db++[c]
def run {v : Nat} : List (PB v) → List Emit.Command → Option (List (PB v))
  | db, [] => some db
  | db, c::cs => do run (← step db c) cs

def Agrees {v : Nat} (p : Partial v) (x : Fin v → Bool) : Prop :=
  ∀ j b, p j=some b → x j=b
def Models {v : Nat} (db : List (PB v)) (x : Fin v → Bool) : Prop := ∀ c∈db, Holds c x

theorem eval_le_max {v : Nat} (c : PB v) (p : Partial v) (x : Fin v → Bool) (ha : Agrees p x) :
    (∑ j, c.coeff j*ibit (x j)) ≤ maximum c p := by
  apply Finset.sum_le_sum
  intro j _
  cases hh : p j with
  | none => cases hx : x j <;> simp [hh,ibit,hx]
  | some b =>
    have hx := ha j b hh
    cases b <;> simp [hh,hx,ibit]

theorem conflict_sound {v : Nat} (db : List (PB v)) (p : Partial v) (x : Fin v → Bool)
    (ha : Agrees p x) (hm : Models db x) (hc : conflict db p=true) : False := by
  obtain ⟨c,hc,hbad⟩ := List.any_eq_true.mp hc
  have hlt : maximum c p < c.rhs := of_decide_eq_true hbad
  have hle := eval_le_max c p x ha
  have h := hm c hc
  unfold Holds at h
  omega

theorem agrees_update {v : Nat} (p : Partial v) (x : Fin v → Bool) (ha : Agrees p x)
    (j : Fin v) (b : Bool) (hb : x j=b) : Agrees (Function.update p j (some b)) x := by
  intro i c hc
  by_cases he : i=j
  · subst i; simp only [Function.update_self,Option.some.injEq] at hc; exact hb.trans hc
  · rw [Function.update_of_ne he] at hc; exact ha i c hc

theorem force_agrees {v : Nat} (db : List (PB v)) (p : Partial v) (x : Fin v → Bool)
    (ha : Agrees p x) (hm : Models db x) (j : Fin v) : Agrees (force db p j) x := by
  unfold force
  simp only [freeze_eq]
  split
  · exact ha
  · split
    · rename_i hc
      apply agrees_update p x ha j true
      cases hx : x j
      · exact False.elim (conflict_sound db _ x (agrees_update p x ha j false hx) hm hc)
      · rfl
    · split
      · rename_i hc
        apply agrees_update p x ha j false
        cases hx : x j
        · rfl
        · exact False.elim (conflict_sound db _ x (agrees_update p x ha j true hx) hm hc)
      · exact ha

theorem fold_force_agrees {v : Nat} (js : List (Fin v)) (db : List (PB v))
    (p : Partial v) (x : Fin v → Bool) (ha : Agrees p x) (hm : Models db x) :
    Agrees (js.foldl (force db) p) x := by
  induction js generalizing p with
  | nil => exact ha
  | cons j js ih => exact ih _ (force_agrees db p x ha hm j)

theorem up_sound {v : Nat} (fuel : Nat) (db : List (PB v)) (p : Partial v) (x : Fin v → Bool)
    (ha : Agrees p x) (hm : Models db x) (hu : up fuel db p=true) : False := by
  induction fuel generalizing p with
  | zero => exact conflict_sound db p x ha hm hu
  | succ k ih =>
    simp only [up] at hu
    split at hu
    · rename_i hc; exact conflict_sound db p x ha hm hc
    · exact ih _ (fold_force_agrees _ db p x ha hm) hu

theorem negate_iff {v : Nat} (c : PB v) (x : Fin v → Bool) : Holds (negate c) x ↔ ¬ Holds c x := by
  simp only [Holds,negate,neg_mul,Finset.sum_neg_distrib]
  omega

theorem rup_sound {v : Nat} (db : List (PB v)) (c : PB v) (h : rup db c=true)
    (x : Fin v → Bool) (hm : Models db x) : Holds c x := by
  by_contra hc
  apply up_sound (v+1) (db++[negate c]) (fun _ => none) x (by intro j b h; contradiction) ?_ h
  intro d hd
  rcases List.mem_append.mp hd with hd | hd
  · exact hm d hd
  · simp only [List.mem_singleton] at hd; subst d; exact (negate_iff c x).mpr hc

theorem min_le_bit (a : Int) (b : Bool) : min 0 a ≤ a*ibit b := by
  cases b <;> simp [ibit]

theorem trivial_sound {v : Nat} (c : PB v) (h : trivial c=true) (x : Fin v → Bool) : Holds c x := by
  have hh : c.rhs ≤ ∑ j, min 0 (c.coeff j) := of_decide_eq_true h
  exact le_trans hh (Finset.sum_le_sum fun j _ => min_le_bit (c.coeff j) (x j))

theorem weakImplies_sound {v : Nat} (a b : PB v) (h : weakImplies a b=true)
    (x : Fin v → Bool) (ha : Holds a x) : Holds b x := by
  have hh : b.rhs-a.rhs ≤ ∑ j, min 0 (b.coeff j-a.coeff j) := of_decide_eq_true h
  have hl := Finset.sum_le_sum (fun j (_ : j∈(Finset.univ : Finset (Fin v))) =>
    min_le_bit (b.coeff j-a.coeff j) (x j))
  simp only [sub_mul,Finset.sum_sub_distrib] at hl
  unfold Holds at *
  omega

#print axioms rup_sound
#print axioms weakImplies_sound
end OP03.Kernel

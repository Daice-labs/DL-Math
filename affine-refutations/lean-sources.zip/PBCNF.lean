import NumericExtension
import PBGenerated
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

theorem indicator_eval {v : Nat} (X : Nat → Bool) (a : Int) (i : Nat) (hi : i<v) :
    (∑ j : Fin v, (if j.val=i then a else 0)*ibit (X j.val))=a*ibit (X i) := by
  rw [Finset.sum_eq_single ⟨i,hi⟩]
  · simp
  · intro b _ hb
    have hn : b.val≠i := by intro h; exact hb (Fin.ext h)
    simp [hn]
  · simp

theorem terms_eval {v : Nat} (X : Nat → Bool) (terms : List (Int × Nat)) (rhs : Int)
    (hb : ∀ p∈terms, p.2<v) :
    (∑ j : Fin v, (fromTerms v terms rhs).coeff j*ibit (X j.val))=
      (terms.map fun p => p.1*ibit (X p.2)).sum := by
  induction terms with
  | nil => simp [fromTerms]
  | cons p ps ih =>
    simp only [fromTerms,List.map_cons,List.sum_cons,add_mul,Finset.sum_add_distrib]
    rw [indicator_eval X p.1 p.2 (hb p (by simp))]
    have hh := ih (by intro p hp; exact hb p (by simp [hp]))
    exact congrArg (fun z => p.1*ibit (X p.2)+z) hh

def satisfiedWeight (X : Nat → Bool) (l : Int) : Int :=
  if l<0 then 1-ibit (X l.natAbs) else ibit (X l.natAbs)

theorem weight_nonneg (X : Nat → Bool) (l : Int) : 0≤satisfiedWeight X l := by
  unfold satisfiedWeight
  split <;> cases X l.natAbs <;> simp [ibit]
theorem weight_positive (X : Nat → Bool) (l : Int) :
    0 < satisfiedWeight X l ↔ Numeric.Lit X l := by
  unfold satisfiedWeight Numeric.Lit
  split <;> cases X l.natAbs <;> simp [ibit]

theorem weight_sum (X : Nat → Bool) (cs : List Int) :
    (cs.map (satisfiedWeight X)).sum=
      (cs.map fun l => (if l<0 then (-1 : Int) else 1)*ibit (X l.natAbs)).sum+
      (cs.map fun l => if l<0 then (1 : Int) else 0).sum := by
  induction cs with
  | nil => rfl
  | cons l ls ih =>
    simp only [List.map_cons,List.sum_cons,ih,satisfiedWeight]
    split <;> ring

theorem weight_clause (X : Nat → Bool) (cs : List Int) :
    0 < (cs.map (satisfiedWeight X)).sum ↔ Numeric.Clause X cs := by
  induction cs with
  | nil => simp [Numeric.Clause]
  | cons l ls ih =>
    have hn := weight_nonneg X l
    have hs : 0≤(ls.map (satisfiedWeight X)).sum := List.sum_nonneg (by
      intro z hz; obtain ⟨k,_,rfl⟩ := List.mem_map.mp hz; exact weight_nonneg X k)
    have hpos : 0 < satisfiedWeight X l+(ls.map (satisfiedWeight X)).sum ↔
        0 < satisfiedWeight X l ∨ 0 < (ls.map (satisfiedWeight X)).sum := by omega
    simpa [Numeric.Clause,weight_positive,ih] using hpos

theorem clause_holds_iff {v : Nat} (X : Nat → Bool) (c : List Int) (hb : ∀ l∈c, l.natAbs<v) :
    Holds (fromClause v c) (fun j => X j.val) ↔ Numeric.Clause X c := by
  have ht := terms_eval (v:=v) X (c.map fun l => (if l<0 then (-1 : Int) else 1,l.natAbs))
    (1-(c.map fun l => if l<0 then (1 : Int) else 0).sum) (by
      intro p hp; obtain ⟨l,hl,rfl⟩ := List.mem_map.mp hp; exact hb l hl)
  unfold Holds fromClause
  rw [ht]
  simp only [fromClause,fromTerms,List.map_map,Function.comp_def]
  rw [← weight_clause X c,weight_sum]
  omega

theorem source_models_iff {m n v : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (hv : n+m*n<v) (X : Nat → Bool) :
    Models (((Emit.rows A a b y).flatMap Emit.Row.clauses).map (fromClause v)) (fun j => X j.val) ↔
      Numeric.CNF X ((Emit.rows A a b y).flatMap Emit.Row.clauses) := by
  constructor
  · intro hm c hc
    exact (clause_holds_iff X c (fun l hl => lt_of_le_of_lt (source_clause_bounds A a b y c hc l hl).2 hv)).mp
      (hm _ (List.mem_map.mpr ⟨c,hc,rfl⟩))
  · intro hm c hc
    obtain ⟨ls,hls,rfl⟩ := List.mem_map.mp hc
    exact (clause_holds_iff X ls (fun l hl => lt_of_le_of_lt (source_clause_bounds A a b y ls hls l hl).2 hv)).mpr (hm ls hls)

#print axioms source_models_iff
end OP03.Kernel

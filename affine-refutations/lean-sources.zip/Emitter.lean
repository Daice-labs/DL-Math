import LocalRUP
import Mathlib.Algebra.BigOperators.Fin
set_option maxHeartbeats 0
namespace OP03.Emit
open scoped BigOperators
structure Gate where
  x : Nat
  v : Nat
  z : Nat
  deriving Repr

structure Constraint where
  terms : List (Int × Nat)
  rhs : Int
  deriving Repr, DecidableEq

inductive Expr where
  | ref : Nat → Expr
  | lit : Nat → Bool → Expr
  | add : Expr → Expr → Expr
  | mul : Expr → Nat → Expr
  | div : Expr → Nat → Expr
  deriving Repr, DecidableEq

inductive Command where
  | red : Constraint → Nat → Bool → Command
  | rup : Constraint → Command
  | pol : Expr → Command
  deriving Repr, DecidableEq

open Expr Command

def renderTerms (terms : List (Int × Nat)) : String :=
  String.intercalate " " (terms.map fun (a,v) => s!"{a} x{v}")

def renderExpr : Expr → String
  | .ref i => toString i
  | .lit v true => s!"x{v}"
  | .lit v false => s!"~x{v}"
  | .add a b => renderExpr a ++ " " ++ renderExpr b ++ " +"
  | .mul a k => renderExpr a ++ s!" {k} *"
  | .div a k => renderExpr a ++ s!" {k} d"

def renderCommand : Command → String
  | .red c v b => "red " ++ renderTerms c.terms ++ s!" >= {c.rhs} : x{v} -> {if b then 1 else 0} ;"
  | .rup c => "rup " ++ renderTerms c.terms ++ s!" >= {c.rhs} ;"
  | .pol e => "pol " ++ renderExpr e ++ " ;"

def gateBlock (g : Gate) (t u k : Nat) : List Command :=
  let pos := [(1,g.x),(1,g.v),(1,g.z)]
  let neg := [(-1,g.x),(-1,g.v),(-1,g.z)]
  [.red ⟨pos ++ [(-2,t)],0⟩ t false,
   .red ⟨neg ++ [(2,t)],-1⟩ t true,
   .red ⟨pos ++ [(-2,t),(-3,u)],-2⟩ u false,
   .red ⟨neg ++ [(2,t),(3,u)],0⟩ u true,
   .pol (.div (.add (.ref (k+3)) (.mul (.ref (k+1)) 2)) 3),
   .pol (.div (.add (.ref (k+4)) (.mul (.ref (k+2)) 2)) 3)] ++
  (Local.prefixes.map fun bits =>
    let terms := (bits.zip [g.x,g.v,g.z]).map (fun (b,v) => (if b then (-1 : Int) else 1,v))
    .rup ⟨terms ++ [(-1,u)],-(bits.map fun b => if b then (1 : Int) else 0).sum⟩) ++
  [.pol (.add (.ref (k+5)) (.lit u true)), .pol (.add (.ref (k+6)) (.ref (k+21)))]

theorem gateBlock_length (g : Gate) (t u k : Nat) : (gateBlock g t u k).length = 23 := by
  simp [gateBlock, Local.prefixes]

def blocks : List Gate → Nat → Nat → List Command
  | [], _, _ => []
  | g::gs, nextVar, nextId => gateBlock g (nextVar+1) (nextVar+2) nextId ++ blocks gs (nextVar+2) (nextId+23)

theorem blocks_length (gs : List Gate) (v k : Nat) : (blocks gs v k).length = 23*gs.length := by
  induction gs generalizing v k with
  | nil => rfl
  | cons g gs ih => simp [blocks, gateBlock_length, ih]; omega

def aggregate (tokens : List Expr) : Expr :=
  match tokens with
  | [] => .ref 0
  | t::ts => ts.foldl Expr.add t

def finish (gs : List Gate) (v k : Nat) (payments : List (Expr × Expr)) : List Command :=
  let ls := (gs.zipIdx.map fun (_,i) => Expr.ref (k+23*i+22)) ++ payments.map Prod.fst
  let hs := (gs.zipIdx.map fun (_,i) => Expr.ref (k+23*i+23)) ++ payments.map Prod.snd
  let total := k+23*gs.length
  blocks gs v k ++ [.pol (aggregate ls),.pol (aggregate hs),
    .pol (.add (.div (.ref (total+1)) 2) (.div (.ref (total+2)) 2))]

theorem finish_length (gs : List Gate) (v k : Nat) (p : List (Expr × Expr)) :
    (finish gs v k p).length = 23*gs.length+3 := by simp [finish, blocks_length]

def rowVars {n : Nat} (row : Fin n → Bool) : List Nat :=
  ((List.ofFn fun j : Fin n => j).filter fun j => row j).map fun j => j.val+1

def tailGates (cur : Nat) : List Nat → Nat → List Gate
  | [], _ => []
  | v::vs, base => ⟨cur,v,base+1⟩ :: tailGates (base+1) vs (base+1)

def lastTail (cur : Nat) : List Nat → Nat → Nat
  | [], _ => cur
  | _::vs, base => lastTail (base+1) vs (base+1)

def gates (vs : List Nat) (base : Nat) : List Gate :=
  match vs with
  | [] => []
  | x::xs => tailGates x xs base


def gateClauses (g : Gate) : List (List Int) :=
  [[g.x,g.v,-(g.z : Int)],[g.x,-(g.v : Int),g.z],[-(g.x : Int),g.v,g.z],[-(g.x : Int),-(g.v : Int),-(g.z : Int)]]

def lastVar (vs : List Nat) (base : Nat) : Option Nat :=
  match vs with
  | [] => none
  | x::xs => some (lastTail x xs base)

def rowClauses (vs : List Nat) (base : Nat) (rhs : Bool) : List (List Int) :=
  (gates vs base).flatMap gateClauses ++
  match lastVar vs base with
  | none => if rhs then [[]] else []
  | some z => [[if rhs then (z : Int) else -(z : Int)]]

structure Row where
  vars : List Nat
  base : Nat
  rhs : Bool
  clauses : List (List Int)
  terminal : Nat
  selected : Bool

structure RawRow where
  vars : List Nat
  base : Nat
  rhs : Bool
  clauses : List (List Int)
  selected : Bool

def annotate : List RawRow → Nat → List Row
  | [], _ => []
  | r::rs, k => ⟨r.vars,r.base,r.rhs,r.clauses,k+r.clauses.length,r.selected⟩ ::
      annotate rs (k+r.clauses.length)

def rawRows {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) : List RawRow :=
  List.ofFn fun i : Fin m =>
    let vs := rowVars (A i)
    let base := n+i.val*n
    let rhs := Bool.xor (a i) (b i)
    ⟨vs,base,rhs,rowClauses vs base rhs,y i⟩

def rows {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) : List Row :=
  annotate (rawRows A a b y) 0

def payment (r : Row) : List (Expr × Expr) :=
  match lastVar r.vars r.base with
  | none => []
  | some z =>
    let plus := if r.rhs then Expr.ref r.terminal else Expr.lit z true
    let minus := if r.rhs then Expr.lit z false else Expr.ref r.terminal
    if r.vars.length=1 then [(plus,minus)] else [(minus,plus)]

structure Output where
  clauses : List (List Int)
  variableCount : Nat
  instructions : List Command
  conclusion : Nat
  deriving Repr

def generate {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) : Output :=
  let rs := rows A a b y
  let cs := rs.flatMap Row.clauses
  let selected := rs.filter Row.selected
  match selected.find? (fun r => r.vars.isEmpty && r.rhs) with
  | some r => ⟨cs,n+m*n,[],r.terminal⟩
  | none =>
    let gs := selected.flatMap fun r => gates r.vars r.base
    let payments := selected.flatMap payment
    ⟨cs,n+m*n,finish gs (n+m*n) cs.length payments,cs.length+23*gs.length+3⟩

def renderOPB (out : Output) : String :=
  s!"* #variable= {max 1 out.variableCount} #constraint= {out.clauses.length}\n" ++
  String.join (out.clauses.map fun c =>
    (if c.isEmpty then "0 x1" else String.intercalate " " (c.map fun l =>
      if l<0 then s!"1 ~x{l.natAbs}" else s!"1 x{l.natAbs}")) ++ " >= 1 ;\n")

def proofLines (out : Output) : List String :=
  ["pseudo-Boolean proof version 3.0",s!"f {out.clauses.length} ;"] ++ out.instructions.map renderCommand ++
  ["output NONE ;",s!"conclusion UNSAT : {out.conclusion} ;","end pseudo-Boolean proof ;"]

def renderProof (out : Output) : String := String.join ((proofLines out).map fun s => s ++ "\n")

theorem rowVars_length {n : Nat} (r : Fin n → Bool) : (rowVars r).length ≤ n := by
  simp only [rowVars, List.length_map]
  calc
    _ ≤ (List.ofFn fun j : Fin n => j).length := List.length_filter_le ..
    _ = n := List.length_ofFn ..

theorem tailGates_length (vs : List Nat) (cur base : Nat) : (tailGates cur vs base).length = vs.length := by
  induction vs generalizing cur base with
  | nil => rfl
  | cons v vs ih => simp [tailGates, ih]

theorem gates_length (vs : List Nat) (base : Nat) : (gates vs base).length = vs.length-1 := by
  cases vs <;> simp [gates, tailGates_length]

def selectedGates (rs : List Row) := (rs.filter Row.selected).flatMap fun r => gates r.vars r.base

theorem annotate_gates_bound (rs : List RawRow) (k : Nat) :
    (selectedGates (annotate rs k)).length ≤ (rs.map fun r => r.vars.length).sum := by
  induction rs generalizing k with
  | nil => simp [annotate, selectedGates]
  | cons r rs ih =>
    simp only [annotate, selectedGates, List.filter_cons, List.map_cons, List.sum_cons]
    have hh := ih (k+r.clauses.length)
    simp [selectedGates, gates_length] at hh
    cases hs : r.selected <;> simp [hs, gates_length] <;> omega

theorem selected_gates_bound {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) :
    (selectedGates (rows A a b y)).length ≤ m*n := by
  apply le_trans (annotate_gates_bound (rawRows A a b y) 0)
  simp only [rawRows, List.map_ofFn, List.sum_ofFn, Function.comp_apply]
  calc
    _ ≤ ∑ _i : Fin m, n := Finset.sum_le_sum (fun i _ => rowVars_length (A i))
    _ = m*n := by simp

theorem generate_size {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) :
    (generate A a b y).instructions.length ≤ 23*m*n+3 := by
  unfold generate
  dsimp only
  split
  · simp
  · simp only [finish_length]
    have h := selected_gates_bound A a b y
    unfold selectedGates at h
    nlinarith

theorem generate_physical_lines {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) :
    (proofLines (generate A a b y)).length ≤ 23*m*n+8 := by
  have h := generate_size A a b y
  simp only [proofLines, List.length_append, List.length_cons, List.length_nil, List.length_map]
  omega

#print axioms generate_size
#print axioms generate_physical_lines

#print axioms gateBlock_length
#print axioms blocks_length
#print axioms finish_length
end OP03.Emit

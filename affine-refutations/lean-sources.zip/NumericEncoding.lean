import PBSource
set_option maxHeartbeats 0
namespace OP03.Numeric
open OP03.Emit

def Lit (X : Nat → Bool) (l : Int) : Prop := if l<0 then X l.natAbs=false else X l.natAbs=true
def Clause (X : Nat → Bool) (c : List Int) : Prop := ∃ l∈c, Lit X l
def CNF (X : Nat → Bool) (cs : List (List Int)) : Prop := ∀ c∈cs, Clause X c

@[simp] theorem cnf_append (X : Nat → Bool) (a b : List (List Int)) : CNF X (a++b) ↔ CNF X a ∧ CNF X b := by
  simp [CNF]; aesop
@[simp] theorem cnf_flatMap {α : Type} (X : Nat → Bool) (xs : List α) (f : α → List (List Int)) :
    CNF X (xs.flatMap f) ↔ ∀ a∈xs, CNF X (f a)  := by simp [CNF]; aesop

theorem gate_cnf (X : Nat → Bool) (g : Gate) (hx : 0 < g.x) (hv : 0 < g.v) (hz : 0 < g.z) :
    CNF X (gateClauses g) ↔ X g.z=Bool.xor (X g.x) (X g.v) := by
  have hxi : ¬ (g.x : Int)<0 := by omega
  have hvi : ¬ (g.v : Int)<0 := by omega
  have hzi : ¬ (g.z : Int)<0 := by omega
  rw [← OP03Parity.gate_correct]
  simp [CNF,Clause,Lit,gateClauses,hxi,hvi,hzi,hx,hv,hz,OP03Parity.gateCNF]

theorem unit_cnf (X : Nat → Bool) (z : Nat) (hp : 0 < z) (rhs : Bool) :
    CNF X [[if rhs then (z : Int) else -(z : Int)]] ↔ X z=rhs := by
  have hz : ¬ (z : Int)<0 := by omega
  cases rhs <;> simp [CNF,Clause,Lit,hp,hz]

def parity (X : Nat → Bool) (xs : List Nat) : Bool := (xs.map X).foldl Bool.xor false

theorem parity_append_one (X : Nat → Bool) (xs : List Nat) (x : Nat) :
    parity X (xs++[x])=Bool.xor (parity X xs) (X x) := by simp [parity,List.foldl_append]

theorem tail_sound (X : Nat → Bool) (xs : List Nat) (cur base : Nat)
    (hp : 0 < cur) (hx : ∀ x∈xs, 0 < x)
    (hc : CNF X ((tailGates cur xs base).flatMap gateClauses)) :
    X (lastTail cur xs base)=(xs.map X).foldl Bool.xor (X cur) := by
  induction xs generalizing cur base with
  | nil => rfl
  | cons x xs ih =>
    have hg : CNF X (gateClauses ⟨cur,x,base+1⟩) := by
      intro c hcc; exact hc c (by simp [tailGates,hcc])
    have hv : X (base+1)=Bool.xor (X cur) (X x) :=
      (gate_cnf X _ hp (hx x (by simp)) (by change 0 < base+1; omega)).mp hg
    have ht : CNF X ((tailGates (base+1) xs (base+1)).flatMap gateClauses) := by
      intro c hcc; exact hc c (by simp [tailGates,hcc])
    have hh := ih (base+1) (base+1) (by omega) (fun x hx' => hx x (by simp [hx'])) ht
    simpa [lastTail,hv] using hh

theorem row_sound (X : Nat → Bool) (vs : List Nat) (base : Nat) (rhs : Bool)
    (hp : ∀ x∈vs, 0 < x) (hc : CNF X (rowClauses vs base rhs)) : parity X vs=rhs := by
  cases vs with
  | nil => cases rhs <;> simp_all [parity,rowClauses,gates,lastVar,CNF,Clause]
  | cons x xs =>
    have hh := (cnf_append X _ _).mp hc
    have ht := tail_sound X xs x base (hp x (by simp)) (fun x hx => hp x (by simp [hx])) hh.1
    have hz : 0 < lastTail x xs base := by
      induction xs generalizing x base with
      | nil => exact hp x (by simp)
      | cons z zs ih =>
        exact (Kernel.lastTail_bounds zs (base+1) (base+1) (by omega) (by omega)).1
    have hu := (unit_cnf X (lastTail x xs base) hz rhs).mp hh.2
    simpa [parity,ht] using hu

theorem parity_rowVars {n : Nat} (A : Fin n → Bool) (X : Nat → Bool) :
    bitF (parity X (rowVars A))=∑ j, bitF (A j)*bitF (X (j.val+1)) := by
  rw [parity,fold_sum]
  simp only [show bitF false=0 from rfl,zero_add]
  simp only [rowVars,List.map_map,Function.comp_def]
  have hm : (((List.ofFn fun j : Fin n => j).filter fun j => A j).map (fun j => bitF (X (j.val+1)))).sum =
      ((List.ofFn fun j : Fin n => j).map fun j => bitF (A j)*bitF (X (j.val+1))).sum := by
    generalize List.ofFn (fun j : Fin n => j)=js
    induction js with
    | nil => rfl
    | cons j js ih => cases hj : A j <;> simp only [List.filter_cons,hj,Bool.false_eq_true,if_false,if_true,
        List.map_cons,List.sum_cons,show bitF false=0 from rfl,show bitF true=1 from rfl,zero_mul,one_mul,zero_add,ih]
  simpa [List.map_ofFn,List.sum_ofFn] using hm

theorem source_implies_solves {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (X : Nat → Bool) (hc : CNF X ((rows A a b y).flatMap Row.clauses)) :
    Solves A a b (fun j => X (j.val+1)) := by
  intro i
  have hraw : (rawRows A a b y)[i.val]'(by simp [rawRows])∈rawRows A a b y := by simp
  obtain ⟨r,hr,hvars,hrhs,_⟩ := annotate_member (rawRows A a b y) 0 _ hraw
  have hv : r.vars=rowVars (A i) := by simpa [rawRows] using hvars
  have hh : r.rhs=Bool.xor (a i) (b i) := by simpa [rawRows] using hrhs
  have hrow := (cnf_flatMap X (rows A a b y) Row.clauses).mp hc r hr
  rw [rows_good A a b y r hr] at hrow
  have hp : ∀ x∈r.vars, 0 < x := by rw [hv]; exact fun x hx => (rowVars_mem_bound (A i) x hx).1
  have he := congrArg bitF (row_sound X r.vars r.base r.rhs hp hrow)
  rw [hv,hh,parity_rowVars,bitF_xor] at he
  exact he

end OP03.Numeric

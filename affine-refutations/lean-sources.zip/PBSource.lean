import PBBlocks
set_option maxHeartbeats 0
namespace OP03.Kernel
open OP03.Emit

theorem annotate_origin (rs : List RawRow) (k : Nat) (r : Row) (hr : r∈annotate rs k) :
    ∃ s∈rs, r.vars=s.vars ∧ r.base=s.base ∧ r.rhs=s.rhs := by
  induction rs generalizing k with
  | nil => simp [annotate] at hr
  | cons s ss ih =>
    simp only [annotate,List.mem_cons] at hr
    rcases hr with rfl | hr
    · exact ⟨s,by simp,rfl,rfl,rfl⟩
    · obtain ⟨a,ha,h⟩ := ih _ hr
      exact ⟨a,by simp [ha],h⟩

theorem row_origin {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (r : Row) (hr : r∈rows A a b y) :
    ∃ i : Fin m, r.vars=rowVars (A i) ∧ r.base=n+i.val*n ∧ r.rhs=Bool.xor (a i) (b i) := by
  obtain ⟨s,hs,h⟩ := annotate_origin (rawRows A a b y) 0 r hr
  simp only [rawRows,List.mem_ofFn] at hs
  obtain ⟨i,rfl⟩ := hs
  exact ⟨i,h⟩

theorem tail_positive (xs : List Nat) (cur base : Nat) (hp : 0 < cur)
    (hx : ∀ x∈xs, 0 < x) :
    ∀ g∈tailGates cur xs base, 0 < g.x ∧ 0 < g.v ∧ 0 < g.z := by
  induction xs generalizing cur base with
  | nil => simp [tailGates]
  | cons x xs ih =>
    intro g hg
    simp only [tailGates,List.mem_cons] at hg
    rcases hg with rfl | hg
    · exact ⟨hp,hx x (by simp),by change 0 < base+1; omega⟩
    · exact ih (base+1) (base+1) (by omega) (fun x hx' => hx x (by simp [hx'])) g hg

theorem rows_gate_fit {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (r : Row) (hr : r∈rows A a b y) (g : Gate) (hg : g∈gates r.vars r.base) :
    GateFit g (n+m*n) := by
  obtain ⟨i,hvars,hbase,_⟩ := row_origin A a b y r hr
  rw [hvars,hbase] at hg
  have hbounds := row_gate_bounds A i g hg
  have hdist := row_gates_distinct (A i) (n+i.val*n) (by omega) g hg
  have hpos : 0 < g.x ∧ 0 < g.v ∧ 0 < g.z := by
    have hv := rowVars_mem_bound (A i)
    cases hh : rowVars (A i) with
    | nil => simp [hh,gates] at hg
    | cons x xs =>
      rw [hh] at hv hg
      exact tail_positive xs x _ (hv x (by simp)).1 (fun x hx => (hv x (by simp [hx])).1) g hg
  exact ⟨hpos.1,hpos.2.1,hpos.2.2,hbounds.1,hbounds.2.1,hbounds.2.2,hdist⟩

theorem lastTail_bounds (xs : List Nat) (cur base : Nat) (hp : 0 < cur) (hb : cur≤base) :
    0 < lastTail cur xs base ∧ lastTail cur xs base≤base+xs.length := by
  induction xs generalizing cur base with
  | nil => simpa [lastTail] using And.intro hp hb
  | cons x xs ih =>
    have h := ih (base+1) (base+1) (by omega) (by omega)
    simpa [lastTail,List.length_cons,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using h

theorem rows_last_bounds {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (r : Row) (hr : r∈rows A a b y) (z : Nat) (hz : lastVar r.vars r.base=some z) :
    0 < z ∧ z≤n+m*n := by
  obtain ⟨i,hvars,hbase,_⟩ := row_origin A a b y r hr
  rw [hvars,hbase] at hz
  have hlen := rowVars_length (A i)
  have hv := rowVars_mem_bound (A i)
  have hi : (i.val+1)*n≤m*n := Nat.mul_le_mul_right n (by omega)
  cases hh : rowVars (A i) with
  | nil => simp [lastVar,hh] at hz
  | cons x xs =>
    rw [hh] at hv hlen
    simp only [hh,lastVar,Option.some.injEq] at hz
    have hx := hv x (by simp)
    have h := lastTail_bounds xs x (n+i.val*n) hx.1 (by omega)
    rw [hz] at h
    exact ⟨h.1,by simp only [List.length_cons] at hlen; nlinarith [h.2]⟩

theorem gate_clause_bounds (g : Gate) (h : Nat) (hf : GateFit g h)
    (c : List Int) (hc : c∈gateClauses g) (l : Int) (hl : l∈c) : 0 < l.natAbs ∧ l.natAbs≤h := by
  simp only [gateClauses,List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl | rfl | rfl | rfl <;>
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hl <;>
    rcases hl with rfl | rfl | rfl <;>
    simp only [Int.natAbs_neg,Int.natAbs_natCast] <;>
    first | exact ⟨hf.posX,hf.boundX⟩ | exact ⟨hf.posV,hf.boundV⟩ | exact ⟨hf.posZ,hf.boundZ⟩

theorem source_clause_bounds {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (c : List Int) (hc : c∈(rows A a b y).flatMap Row.clauses) (l : Int) (hl : l∈c) :
    0 < l.natAbs ∧ l.natAbs≤n+m*n := by
  obtain ⟨r,hr,hc⟩ := List.mem_flatMap.mp hc
  rw [rows_good A a b y r hr] at hc
  simp only [rowClauses] at hc
  rcases List.mem_append.mp hc with hc | hc
  · obtain ⟨g,hg,hc⟩ := List.mem_flatMap.mp hc
    exact gate_clause_bounds g _ (rows_gate_fit A a b y r hr g hg) c hc l hl
  · cases hz : lastVar r.vars r.base with
    | none => cases ht : r.rhs <;> simp_all
    | some z =>
      simp only [hz,List.mem_singleton] at hc
      subst c
      simp only [List.mem_singleton] at hl
      subst l
      cases r.rhs <;> simpa using rows_last_bounds A a b y r hr z hz

theorem source_bounded {m n v : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) :
    Bounded (((rows A a b y).flatMap Row.clauses).map (fromClause v)) (n+m*n) := by
  intro c hc j hj
  obtain ⟨ls,hls,rfl⟩ := List.mem_map.mp hc
  simp only [fromClause,fromTerms,List.map_map,Function.comp_def]
  apply List.sum_eq_zero
  intro z hz
  obtain ⟨l,hl,rfl⟩ := List.mem_map.mp hz
  have hb := (source_clause_bounds A a b y ls hls l hl).2
  have hn : j.val≠l.natAbs := by omega
  simp [hn]

theorem source_wellFormed {m n v : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (hv : n+m*n < v) : sourceWellFormed v ((rows A a b y).flatMap Row.clauses)=true := by
  apply List.all_eq_true.mpr
  intro c hc
  apply List.all_eq_true.mpr
  intro l hl
  have hb := source_clause_bounds A a b y c hc l hl
  apply decide_eq_true
  exact ⟨hb.1,lt_of_le_of_lt hb.2 hv⟩

theorem source_has_gate {m n v : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (r : Row) (hr : r∈rows A a b y) (g : Gate) (hg : g∈gates r.vars r.base)
    (c : List Int) (hc : c∈gateClauses g) :
    fromClause v c∈(((rows A a b y).flatMap Row.clauses).map (fromClause v)) := by
  apply List.mem_map.mpr
  refine ⟨c,?_,rfl⟩
  apply List.mem_flatMap.mpr
  refine ⟨r,hr,?_⟩
  rw [rows_good A a b y r hr]
  apply List.mem_append_left
  exact List.mem_flatMap.mpr ⟨g,hg,hc⟩

theorem lookup_clause_position (v : Nat) (before after : List (List Int)) (c : List Int) :
    lookup ((before++[c]++after).map (fromClause v)) (before.length+1)=some (fromClause v c) := by
  simp [lookup,List.map_append,List.getElem?_append]

theorem source_unit_lookup {m n v : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (r : Row) (hr : r∈rows A a b y) (z : Nat) (hz : lastVar r.vars r.base=some z) :
    lookup (((rows A a b y).flatMap Row.clauses).map (fromClause v)) r.terminal =
      some (fromClause v [if r.rhs then (z : Int) else -(z : Int)]) := by
  obtain ⟨before,after,hcs,ht⟩ := terminal_is_source_unit A a b y r hr z hz
  rw [hcs,ht]
  exact lookup_clause_position v before after _

theorem source_empty_lookup {m n v : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (r : Row) (hr : r∈rows A a b y) (he : r.vars=[]) (ho : r.rhs=true) :
    lookup (((rows A a b y).flatMap Row.clauses).map (fromClause v)) r.terminal = some (bottom v) := by
  obtain ⟨before,after,hcs,ht⟩ := annotate_decompose (rawRows A a b y) 0 r hr
  have hc : r.clauses=[[]] := by rw [rows_good A a b y r hr]; simp [rowClauses,he,ho,gates,lastVar]
  change (rows A a b y).flatMap Row.clauses= _ at hcs
  rw [hc] at hcs ht
  simp only [Nat.zero_add,List.length_singleton] at ht
  rw [hcs,ht,lookup_clause_position]
  rfl

#print axioms source_bounded
#print axioms source_wellFormed
end OP03.Kernel

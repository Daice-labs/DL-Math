import PBBlocks
set_option maxHeartbeats 0
namespace OP03.Kernel

theorem plus_assoc {v : Nat} (a b c : PB v) : plus (plus a b) c=plus a (plus b c) := by
  apply pb_ext <;> simp [plus,Int.add_assoc]
@[simp] theorem plus_zero {v : Nat} (a : PB v) : plus a (zero v)=a := by
  apply pb_ext <;> simp [plus,zero]
@[simp] theorem zero_plus {v : Nat} (a : PB v) : plus (zero v) a=a := by
  apply pb_ext <;> simp [plus,zero]
theorem sumPB_append {v : Nat} (a b : List (PB v)) : sumPB (a++b)=plus (sumPB a) (sumPB b) := by
  induction a with
  | nil => simp [sumPB]
  | cons c cs ih => simp [sumPB,ih,plus_assoc]
theorem sumPB_neg {v : Nat} (cs : List (PB v)) : sumPB (cs.map neg)=neg (sumPB cs) := by
  induction cs with
  | nil => apply pb_ext <;> simp [sumPB,neg,zero]
  | cons c cs ih =>
    rw [List.map_cons,sumPB,ih]
    apply pb_ext <;> simp [sumPB,plus,neg,Int.add_comm]

abbrev Values {v : Nat} (db : List (PB v)) (es : List Emit.Expr) (cs : List (PB v)) :=
  List.Forall₂ (fun e c => eval db e=some c) es cs

theorem eval_fold_add {v : Nat} (db : List (PB v)) (es : List Emit.Expr) (cs : List (PB v))
    (h : Values db es cs) (e : Emit.Expr) (c : PB v) (he : eval db e=some c) :
    eval db (es.foldl Emit.Expr.add e)=some (plus c (sumPB cs)) := by
  induction h generalizing e c with
  | nil => simpa [sumPB] using he
  | cons hhead htail ih =>
    rename_i ehead chead etail ctail
    simp only [List.foldl_cons]
    have hh : eval db (.add e ehead) = some (plus c chead) := by simp [eval,he,hhead]
    rw [ih _ _ hh]
    simp [sumPB,plus_assoc]

theorem eval_aggregate {v : Nat} (db : List (PB v)) (es : List Emit.Expr) (cs : List (PB v))
    (h : Values db es cs) (hne : es≠[]) : eval db (Emit.aggregate es)=some (sumPB cs) := by
  cases h with
  | nil => contradiction
  | cons hhead htail => exact eval_fold_add db _ _ htail _ _ hhead

theorem eval_refs_safe {v : Nat} (db : List (PB v)) (e : Emit.Expr) (c : PB v)
    (h : eval db e=some c) : Emit.ExprSafe db.length e := by
  induction e generalizing c with
  | ref i =>
    intro j hj
    simp only [Emit.exprRefs,List.mem_singleton] at hj
    subst j
    exact lookup_bound db i c h
  | lit i b => simp [Emit.ExprSafe,Emit.exprRefs]
  | add a b ia ib =>
    cases ha : eval db a <;> cases hb : eval db b <;> simp [eval,ha,hb] at h
    rename_i ca cb
    intro i hi
    rcases List.mem_append.mp hi with hi | hi
    · exact ia ca ha i hi
    · exact ib cb hb i hi
  | mul a k ia =>
    cases ha : eval db a <;> simp [eval,ha] at h
    exact ia _ ha
  | div a d ia =>
    cases ha : eval db a <;> simp [eval,ha] at h
    exact ia _ ha

def rowValues (v : Nat) (r : Emit.Row) : List (PB v) :=
  match Emit.lastVar r.vars r.base with
  | none => []
  | some _ => [rowPay v r]

theorem rowValues_sum (v : Nat) (r : Emit.Row) : sumPB (rowValues v r)=rowPay v r := by
  unfold rowValues
  split
  · rename_i h; simp [sumPB,rowPay,h]
  · simp [sumPB]

theorem rowsValues_sum (v : Nat) (rs : List Emit.Row) :
    sumPB (rs.flatMap (rowValues v))=sumPB (rs.map (rowPay v)) := by
  induction rs with
  | nil => rfl
  | cons r rs ih => simp [List.flatMap_cons,sumPB_append,rowValues_sum,ih,sumPB]

theorem payment_values {v : Nat} (db : List (PB v)) (r : Emit.Row)
    (hb : ∀ z, Emit.lastVar r.vars r.base=some z → 0 < z ∧ z < v)
    (hu : ∀ z, Emit.lastVar r.vars r.base=some z →
      lookup db r.terminal=some (fromClause v [if r.rhs then (z : Int) else -(z : Int)])) :
    Values db ((Emit.payment r).map Prod.fst) (rowValues v r) ∧
    Values db ((Emit.payment r).map Prod.snd) ((rowValues v r).map neg) := by
  cases hz : Emit.lastVar r.vars r.base with
  | none => simp [Emit.payment,rowValues,hz]
  | some z =>
    obtain ⟨hp,hv⟩ := hb z hz
    have hl := hu z hz
    have hzneg : ¬ (z : Int)<0 := by omega
    by_cases hlen : r.vars.length=1 <;> cases hr : r.rhs <;>
      simp [Emit.payment,rowValues,rowPay,hz,hlen,hr,Values] <;>
      constructor <;>
      simp only [eval,hl,hr,Bool.false_eq_true,if_false,if_true] <;>
      simp [hp,hv,fromClause,hzneg,fromTerms,literal,neg,ibit,PB.mk.injEq,funext_iff] <;>
      intro j <;> split <;> simp_all

#print axioms payment_values
#print axioms eval_aggregate
end OP03.Kernel

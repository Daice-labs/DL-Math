import PBFinish
import PBSource
import PBSelected
set_option maxHeartbeats 0
namespace OP03.Kernel
open OP03.Emit

def selectedRows {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) :=
  (rows A a b y).filter Row.selected
def selectedGates {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) :=
  (selectedRows A a b y).flatMap fun r => gates r.vars r.base
def checkerVariables {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) : Nat :=
  n+m*n+2*(selectedGates A a b y).length+1

theorem selected_payment_nonempty {m n : Nat} (A : Fin m → Fin n → Bool)
    (a b y : Fin m → Bool) (hw : Witness A a b y)
    (hn : (selectedRows A a b y).find? (fun r => r.vars.isEmpty && r.rhs)=none) :
    (selectedRows A a b y).flatMap payment≠[] := by
  obtain ⟨r,hr,hs,ho⟩ := selected_odd_row A a b y hw
  have hsel : r∈selectedRows A a b y := by simp [selectedRows,hr,hs]
  have hv : r.vars≠[] := by
    intro hv
    have hfalse := List.find?_eq_none.mp hn r hsel
    simp [hv,ho] at hfalse
  have hp : payment r≠[] := by
    cases he : r.vars with
    | nil => exact False.elim (hv he)
    | cons x xs => by_cases hh : xs=[] <;> simp [payment,lastVar,he,hh]
  intro he
  exact hp (List.flatMap_eq_nil_iff.mp he r hsel)

theorem generated_finish_run {m n v : Nat} (A : Fin m → Fin n → Bool)
    (a b y : Fin m → Bool) (hw : Witness A a b y)
    (hn : (selectedRows A a b y).find? (fun r => r.vars.isEmpty && r.rhs)=none)
    (hv : n+m*n+2*(selectedGates A a b y).length < v) :
    let cs := (rows A a b y).flatMap Row.clauses
    let gs := selectedGates A a b y
    ∃ finalDB, run (cs.map (fromClause v)) (finish gs (n+m*n) cs.length ((selectedRows A a b y).flatMap payment))=some finalDB ∧
      lookup finalDB (cs.length+23*gs.length+3)=some (bottom v) := by
  dsimp only
  let rs := selectedRows A a b y
  let gs := selectedGates A a b y
  let cs := (rows A a b y).flatMap Row.clauses
  let db := cs.map (fromClause v)
  have hfit : ∀ g∈gs, GateFit g (n+m*n) := by
    intro g hg
    obtain ⟨r,hr,hg⟩ := List.mem_flatMap.mp hg
    exact rows_gate_fit A a b y r (List.mem_filter.mp hr).1 g hg
  have hclauses : ∀ g∈gs, ∀ c∈gateClauses g, fromClause v c∈db := by
    intro g hg c hc
    obtain ⟨r,hr,hg⟩ := List.mem_flatMap.mp hg
    exact source_has_gate A a b y r (List.mem_filter.mp hr).1 g hg c hc
  obtain ⟨added,hlen,hblocks,houtputs,hbound⟩ := blocks_accepted gs (n+m*n) hfit hv db
    (source_bounded A a b y) hclauses
  have hdblen : db.length=cs.length := by simp [db]
  have htotal : (db++added).length=cs.length+23*gs.length := by simp [hlen,hdblen]
  have hvar : ∀ r∈rs, ∀ z, lastVar r.vars r.base=some z → 0 < z ∧ z < v := by
    intro r hr z hz
    have h := rows_last_bounds A a b y r (List.mem_filter.mp hr).1 z hz
    exact ⟨h.1,by omega⟩
  have hunit : ∀ r∈rs, ∀ z, lastVar r.vars r.base=some z →
      lookup (db++added) r.terminal=some (fromClause v [if r.rhs then (z : Int) else -(z : Int)]) := by
    intro r hr z hz
    have hr' := (List.mem_filter.mp hr).1
    have hb := (terminal_bound A a b y r hr').2
    rw [lookup_append db added r.terminal (by simpa [db,cs] using hb)]
    exact source_unit_lookup A a b y r hr' z hz
  have hevals := aggregate_evaluations (db++added) rs (n+m*n) db.length houtputs hvar hunit
    (Or.inr (selected_payment_nonempty A a b y hw hn))
  have hpar := emitted_aggregate_even_odd (v:=v) (n+m*n) A a b y hw hn
  dsimp only at hevals
  have hfinish := finish_run (db++added) _ _ (aggregatePB v (n+m*n) rs)
    hevals.1 hevals.2 (eval_refs_safe _ _ _ hevals.2) hpar.1 hpar.2
  refine ⟨(db++added)++[aggregatePB v (n+m*n) rs,neg (aggregatePB v (n+m*n) rs),bottom v],?_,?_⟩
  · change run db (finish gs (n+m*n) cs.length (rs.flatMap payment))=_
    rw [finish,run_append]
    rw [← hdblen,hblocks]
    simpa only [Option.bind_some,htotal,hdblen,gs,rs,selectedGates] using hfinish
  · have hh : lookup ((db++added)++[aggregatePB v (n+m*n) rs,neg (aggregatePB v (n+m*n) rs),bottom v])
        ((db++added).length+3)=some (bottom v) := by
      have hx := lookup_last ((db++added)++[aggregatePB v (n+m*n) rs,neg (aggregatePB v (n+m*n) rs)]) (bottom v)
      simpa only [List.length_append,List.length_cons,List.length_nil,List.append_assoc,List.cons_append,List.nil_append,Nat.add_assoc,Nat.zero_add,Nat.reduceAdd] using hx
    simpa only [htotal] using hh

theorem generate_accepted {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (hw : Witness A a b y) :
    check (checkerVariables A a b y) (generate A a b y).clauses
      (generate A a b y).instructions (generate A a b y).conclusion=true := by
  have hsource := source_wellFormed (v:=checkerVariables A a b y) A a b y
    (by unfold checkerVariables; omega)
  unfold generate
  dsimp only
  split
  · rename_i r hr
    have hmem := List.mem_of_find?_eq_some hr
    have hpred := List.find?_some hr
    have he : r.vars=[] ∧ r.rhs=true := by simpa only [Bool.and_eq_true,List.isEmpty_iff] using hpred
    have hlookup := source_empty_lookup (v:=checkerVariables A a b y) A a b y r
      (List.mem_filter.mp hmem).1 he.1 he.2
    simp [check,hsource,checkUnchecked,run,hlookup,bottom_contradiction]
  · rename_i hn
    obtain ⟨db,hr,hc⟩ := generated_finish_run (v:=checkerVariables A a b y) A a b y hw hn
      (by unfold checkerVariables; omega)
    simp only [selectedGates,selectedRows] at hr hc
    simp only [check,hsource,checkUnchecked,hr,hc,bottom_contradiction,Bool.true_and]

#print axioms generated_finish_run
#print axioms generate_accepted
end OP03.Kernel

import PBLiftRules
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

def renVar {u v : Nat} (σ : Fin u → Fin v) (i : Nat) : Nat :=
  if h : i<u then (σ ⟨i,h⟩).val else 0
@[simp] theorem renVar_fin {u v : Nat} (σ : Fin u → Fin v) (i : Fin u) : renVar σ i.val=(σ i).val := by
  simp [renVar,i.isLt]

def renameExpr {u v : Nat} (σ : Fin u → Fin v) (ρ : Nat → Nat) : Emit.Expr → Emit.Expr
  | .ref i => .ref (ρ i)
  | .lit i b => .lit (renVar σ i) b
  | .add a b => .add (renameExpr σ ρ a) (renameExpr σ ρ b)
  | .mul a k => .mul (renameExpr σ ρ a) k
  | .div a d => .div (renameExpr σ ρ a) d
def renameConstraint {u v : Nat} (σ : Fin u → Fin v) (c : Emit.Constraint) : Emit.Constraint :=
  ⟨c.terms.map fun (a,i) => (a,renVar σ i),c.rhs⟩
def renameCommand {u v : Nat} (σ : Fin u → Fin v) (ρ : Nat → Nat) : Emit.Command → Emit.Command
  | .pol e => .pol (renameExpr σ ρ e)
  | .rup c => .rup (renameConstraint σ c)
  | .red c i b => .red (renameConstraint σ c) (renVar σ i) b

def DBRel {u v : Nat} (σ : Fin u → Fin v) (ρ : Nat → Nat)
    (small : List (PB u)) (big : List (PB v)) : Prop :=
  ∀ i c, lookup small i=some c → lookup big (ρ i)=some (liftPB σ c)

theorem dbrel_mem {u v : Nat} (σ : Fin u → Fin v) (ρ : Nat → Nat)
    (small : List (PB u)) (big : List (PB v)) (h : DBRel σ ρ small big) :
    ∀ c∈small, liftPB σ c∈big := by
  intro c hc
  obtain ⟨i,hi⟩ := List.mem_iff_getElem?.mp hc
  have hl : lookup small (i+1)=some c := by simpa [lookup] using hi
  exact lookup_mem big (ρ (i+1)) _ (h (i+1) c hl)

theorem fromConstraint_rename {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (c : Emit.Constraint) (hb : ∀ p∈c.terms, p.2<u) :
    fromConstraint v (renameConstraint σ c)=liftPB σ (fromConstraint u c) := by
  apply pb_ext
  · intro j
    by_cases hj : ∃ i, σ i=j
    · obtain ⟨i,rfl⟩ := hj
      rw [lift_at σ hinj]
      simp only [fromConstraint,renameConstraint,fromTerms,List.map_map,Function.comp_def]
      apply congrArg List.sum
      apply List.map_congr_left
      intro p hp
      have hk := hb p hp
      have he : (σ i).val=renVar σ p.2 ↔ i.val=p.2 := by
        rw [show renVar σ p.2=(σ ⟨p.2,hk⟩).val from renVar_fin σ ⟨p.2,hk⟩]
        constructor
        · intro hh; exact congrArg Fin.val (hinj (Fin.ext hh))
        · intro hh
          have heq : i=⟨p.2,hk⟩ := Fin.ext hh
          cases heq; rfl
      simp only [he]
    · rw [lift_out σ _ j hj]
      simp only [fromConstraint,renameConstraint,fromTerms,List.map_map,Function.comp_def]
      apply List.sum_eq_zero
      intro a ha
      obtain ⟨p,hp,rfl⟩ := List.mem_map.mp ha
      have hk := hb p hp
      have hn : j.val≠renVar σ p.2 := by
        rw [show renVar σ p.2=(σ ⟨p.2,hk⟩).val from renVar_fin σ ⟨p.2,hk⟩]
        intro hh
        exact hj ⟨⟨p.2,hk⟩,(Fin.ext hh).symm⟩
      simp [hn]
  · rfl

theorem wellFormed_rename {u v : Nat} (σ : Fin u → Fin v)
    (hpos : ∀ i, 0 < i.val → 0 < (σ i).val) (c : Emit.Constraint) (h : wellFormed u c=true) :
    wellFormed v (renameConstraint σ c)=true := by
  apply List.all_eq_true.mpr
  intro p hp
  obtain ⟨⟨a,i⟩,hi,rfl⟩ := List.mem_map.mp hp
  have hb : 0 < i ∧ i < u := of_decide_eq_true (List.all_eq_true.mp h (a,i) hi)
  have hr : renVar σ i=(σ ⟨i,hb.2⟩).val := renVar_fin σ ⟨i,hb.2⟩
  apply decide_eq_true
  exact ⟨by rw [hr]; exact hpos ⟨i,hb.2⟩ hb.1,by rw [hr]; exact (σ ⟨i,hb.2⟩).isLt⟩

theorem eval_rename {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (hpos : ∀ i, 0 < i.val → 0 < (σ i).val) (ρ : Nat → Nat)
    (small : List (PB u)) (big : List (PB v)) (hdb : DBRel σ ρ small big)
    (e : Emit.Expr) (c : PB u) (h : eval small e=some c) :
    eval big (renameExpr σ ρ e)=some (liftPB σ c) := by
  induction e generalizing c with
  | ref i => exact hdb i c h
  | lit i b =>
    simp only [eval] at h
    split at h
    · rename_i hi
      cases h
      have hr : renVar σ i=(σ ⟨i,hi.2⟩).val := renVar_fin σ ⟨i,hi.2⟩
      have hp := hpos ⟨i,hi.2⟩ hi.1
      have hv := (σ ⟨i,hi.2⟩).isLt
      simp only [renameExpr,eval,hr,hp,hv,and_self,if_true]
      rw [lift_literal σ hinj ⟨i,hi.2⟩ b]
    · contradiction
  | add a b ia ib =>
    cases ha : eval small a with
    | none => simp [eval,ha] at h
    | some ca =>
      cases hb : eval small b with
      | none => simp [eval,ha,hb] at h
      | some cb =>
        simp [eval,ha,hb] at h
        subst c
        simp [renameExpr,eval,ia ca ha,ib cb hb,lift_plus]
  | mul a k ia =>
    cases ha : eval small a with
    | none => simp [eval,ha] at h
    | some ca =>
      simp [eval,ha] at h
      subst c
      simp [renameExpr,eval,ia ca ha,lift_scale]
  | div a d ia =>
    cases ha : eval small a with
    | none => simp [eval,ha] at h
    | some ca =>
      simp [eval,ha] at h
      simpa [renameExpr,eval,ia ca ha] using lift_exactDiv σ hinj ca c d h

#print axioms fromConstraint_rename
#print axioms eval_rename
end OP03.Kernel

import Emitter
set_option maxHeartbeats 0
namespace OP03.Emit

def DistinctGate (g : Gate) : Prop := g.x≠g.v ∧ g.x≠g.z ∧ g.v≠g.z

theorem rowVars_mem_bound {n : Nat} (r : Fin n → Bool) (v : Nat) (hv : v∈rowVars r) : 0 < v ∧ v ≤ n := by
  simp only [rowVars, List.mem_map] at hv
  obtain ⟨j,hj,rfl⟩ := hv
  exact ⟨by omega,by omega⟩

theorem rowVars_nodup {n : Nat} (r : Fin n → Bool) : (rowVars r).Nodup := by
  have hb : (List.ofFn fun j : Fin n => j).Nodup := List.nodup_ofFn.mpr Function.injective_id
  have hf := hb.filter (fun j => r j)
  apply hf.map
  intro a b h
  apply Fin.ext
  change a.val+1=b.val+1 at h
  omega

theorem tail_distinct (xs : List Nat) (cur base n : Nat)
    (hn : n≤base) (hc : cur≤base) (hx : ∀ x∈xs, x≤n) (hne : cur∉xs) :
    ∀ g∈tailGates cur xs base, DistinctGate g := by
  induction xs generalizing cur base with
  | nil => simp [tailGates]
  | cons x xs ih =>
    intro g hg
    simp only [tailGates, List.mem_cons] at hg
    rcases hg with rfl | hg
    · have hb := hx x (by simp)
      have he : cur≠x := by intro h; apply hne; simp [h]
      simp only [DistinctGate]
      exact ⟨he,by omega,by omega⟩
    · apply ih (base+1) (base+1) (by omega) (by omega) (fun x h => hx x (by simp [h])) ?_ g hg
      intro h
      have hmax := hx (base+1) (by simp [h])
      omega

theorem row_gates_distinct {n : Nat} (r : Fin n → Bool) (base : Nat) (hb : n≤base) :
    ∀ g∈gates (rowVars r) base, DistinctGate g := by
  have hn := rowVars_nodup r
  have hv : ∀ x∈rowVars r, x≤n := fun x h => (rowVars_mem_bound r x h).2
  cases hh : rowVars r with
  | nil => simp [hh,gates]
  | cons x xs =>
    rw [hh] at hn hv
    apply tail_distinct xs x base n hb (le_trans (hv x (by simp)) hb)
    · exact fun v h => hv v (by simp [h])
    · exact (List.nodup_cons.mp hn).1

theorem tail_bounds (xs : List Nat) (cur base n : Nat)
    (hn : n≤base) (hc : cur≤base) (hx : ∀ x∈xs, x≤n) :
    ∀ g∈tailGates cur xs base, g.x≤base+xs.length ∧ g.v≤base+xs.length ∧ g.z≤base+xs.length := by
  induction xs generalizing cur base with
  | nil => simp [tailGates]
  | cons x xs ih =>
    intro g hg
    simp only [tailGates, List.mem_cons] at hg
    rcases hg with rfl | hg
    · have h := hx x (by simp)
      simp only [List.length_cons]
      exact ⟨by omega,by omega,by omega⟩
    · have h := ih (base+1) (base+1) (by omega) (by omega) (fun x h => hx x (by simp [h])) g hg
      simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using h

theorem row_gate_bounds {m n : Nat} (A : Fin m → Fin n → Bool) (i : Fin m) :
    ∀ g∈gates (rowVars (A i)) (n+i.val*n),
      g.x≤n+m*n ∧ g.v≤n+m*n ∧ g.z≤n+m*n := by
  have hv := rowVars_length (A i)
  have hx : ∀ x∈rowVars (A i), x≤n := fun x h => (rowVars_mem_bound (A i) x h).2
  have hi : (i.val+1)*n≤m*n := Nat.mul_le_mul_right n (by omega)
  cases hh : rowVars (A i) with
  | nil => simp [hh,gates]
  | cons x xs =>
    rw [hh] at hv hx
    intro g hg
    have hc : x≤n+i.val*n := le_trans (hx x (by simp)) (Nat.le_add_right ..)
    have h := tail_bounds xs x (n+i.val*n) n (by omega) hc (fun x h => hx x (by simp [h])) g hg
    simp only [List.length_cons] at hv
    constructor
    · nlinarith [h.1]
    constructor <;> nlinarith [h.2.1,h.2.2]

theorem helper_fresh (header k : Nat) : header<header+2*k+1 ∧ header<header+2*k+2 := by omega

theorem helper_injective (header i j s t : Nat) (hs : s<2) (ht : t<2)
    (h : header+2*i+s+1=header+2*j+t+1) : i=j ∧ s=t := by omega

#print axioms row_gate_bounds
#print axioms helper_injective

#print axioms row_gates_distinct
end OP03.Emit

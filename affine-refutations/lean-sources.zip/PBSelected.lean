import PBAggregate
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

theorem annotate_selected_sum (raw : List Emit.RawRow) (k : Nat)
    (f : List Nat → Nat → Bool → F) :
    (((Emit.annotate raw k).filter Emit.Row.selected).map fun r => f r.vars r.base r.rhs).sum =
      (raw.map fun r => if r.selected then f r.vars r.base r.rhs else 0).sum := by
  induction raw generalizing k with
  | nil => rfl
  | cons r rs ih =>
    cases hs : r.selected <;> simp [Emit.annotate,hs,ih]

theorem rows_selected_sum {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (f : List Nat → Nat → Bool → F) :
    (((Emit.rows A a b y).filter Emit.Row.selected).map fun r => f r.vars r.base r.rhs).sum =
      ∑ i, bitF (y i)*f (Emit.rowVars (A i)) (n+i.val*n) (Bool.xor (a i) (b i)) := by
  rw [Emit.rows,annotate_selected_sum]
  simp only [Emit.rawRows,List.map_ofFn,List.sum_ofFn,Function.comp_def]
  apply Finset.sum_congr rfl
  intro i _
  cases hy : y i <;> simp [hy,bitF]

theorem selected_empty_rhs {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (hn : ((Emit.rows A a b y).filter Emit.Row.selected).find? (fun r => r.vars.isEmpty && r.rhs)=none) :
    ∀ r∈(Emit.rows A a b y).filter Emit.Row.selected, r.vars=[] → r.rhs=false := by
  intro r hr hv
  have hh := List.find?_eq_none.mp hn r hr
  simpa [hv] using hh

theorem emitted_aggregate_even_odd {m n v : Nat} (header : Nat)
    (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) (hw : Witness A a b y)
    (hn : ((Emit.rows A a b y).filter Emit.Row.selected).find? (fun r => r.vars.isEmpty && r.rhs)=none) :
    (∀ j, ((aggregatePB v header ((Emit.rows A a b y).filter Emit.Row.selected)).coeff j : F)=0) ∧
      ((aggregatePB v header ((Emit.rows A a b y).filter Emit.Row.selected)).rhs : F)=1 := by
  constructor
  · intro j
    rw [aggregatePB_mod,rows_selected_sum A a b y (fun vs base _ => Emit.rowValue vs base (delta j))]
    exact Emit.emitted_coefficient_parity A a b y hw (delta j)
  · rw [aggregatePB_rhs_mod v header _ (selected_empty_rhs A a b y hn)]
    rw [rows_selected_sum A a b y (fun _ _ rhs => bitF rhs)]
    simpa only [bitF_xor] using hw.2

#print axioms emitted_aggregate_even_odd
end OP03.Kernel

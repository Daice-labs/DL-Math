import Parity
import Separation
import Mathlib.Algebra.BigOperators.Fin
set_option maxHeartbeats 0
namespace OP03
open scoped BigOperators
open OP03Parity

def bitF (b : Bool) : F := if b then 1 else 0

theorem bitF_injective : Function.Injective bitF := by
  intro a b h
  cases a <;> cases b <;> simp_all [bitF]

theorem bitF_xor (a b : Bool) : bitF (Bool.xor a b) = bitF a + bitF b := by
  cases a <;> cases b <;> decide

theorem fold_sum (xs : List Bool) (acc : Bool) :
    bitF (xs.foldl Bool.xor acc) = bitF acc + (xs.map bitF).sum := by
  induction xs generalizing acc with
  | nil => simp
  | cons x xs ih => simp only [List.foldl_cons, ih, bitF_xor, List.map_cons, List.sum_cons]; ring

def rowValues {n : ℕ} (row : Fin n → Bool) (x : Fin n → Bool) : List Bool :=
  (List.ofFn fun j : Fin n => j).filterMap fun j => if row j then some (x j) else none

theorem sum_selected {n : ℕ} (row x : Fin n → Bool) (is : List (Fin n)) :
    ((is.filterMap fun j => if row j then some (x j) else none).map bitF).sum =
      (is.map fun j => bitF (row j) * bitF (x j)).sum := by
  induction is with
  | nil => rfl
  | cons j js ih => cases h : row j <;> simp [h, bitF, ih]

theorem sum_rowValues {n : ℕ} (row x : Fin n → Bool) :
    ((rowValues row x).map bitF).sum = ∑ j, bitF (row j) * bitF (x j) := by
  rw [rowValues, sum_selected]
  simp [List.map_ofFn, List.sum_ofFn]

-- Explicit row-local auxiliary assignments, not an assumed parity constraint.
def tailHolds (acc : Bool) : List Bool → List Bool → Bool → Prop
  | [], [], rhs => acc = rhs
  | x :: xs, z :: zs, rhs => gateCNF acc x z ∧ tailHolds z xs zs rhs
  | _, _, _ => False

def rowHolds : List Bool → List Bool → Bool → Prop
  | [], zs, rhs => zs = [] ∧ rhs = false
  | x :: xs, zs, rhs => tailHolds x xs zs rhs

theorem tailHolds_iff (xs : List Bool) (acc rhs : Bool) :
    (∃ zs, tailHolds acc xs zs rhs) ↔ tailCNF acc xs rhs := by
  induction xs generalizing acc with
  | nil =>
    simp only [tailCNF]
    constructor
    · rintro ⟨zs,h⟩; cases zs <;> simpa [tailHolds] using h
    · intro h; exact ⟨[],h⟩
  | cons x xs ih =>
    constructor
    · rintro ⟨zs,h⟩
      cases zs with
      | nil => exact False.elim h
      | cons z zs => exact ⟨z,h.1,(ih z).mp ⟨zs,h.2⟩⟩
    · rintro ⟨z,hg,ht⟩
      obtain ⟨zs,hzs⟩ := (ih z).mpr ht
      exact ⟨z::zs,hg,hzs⟩

theorem rowHolds_correct (xs : List Bool) (rhs : Bool) :
    (∃ zs, rowHolds xs zs rhs) ↔ xs.foldl Bool.xor false = rhs := by
  cases xs with
  | nil => simp [rowHolds, eq_comm]
  | cons x xs =>
    simpa [rowHolds, chainCNF] using (tailHolds_iff xs x rhs).trans (tail_correct xs x rhs)

def Enc {m n : ℕ} (A : Fin m → Fin n → Bool) (a b : Fin m → Bool)
    (x : Fin n → Bool) (aux : Fin m → List Bool) : Prop :=
  ∀ i, rowHolds (rowValues (A i) x) (aux i) (Bool.xor (a i) (b i))

theorem encode_correct {m n : ℕ} (A : Fin m → Fin n → Bool) (a b : Fin m → Bool)
    (x : Fin n → Bool) :
    (∃ aux, Enc A a b x aux) ↔
      ∀ i, (∑ j, bitF (A i j) * bitF (x j)) = bitF (a i) + bitF (b i) := by
  have hrow (i : Fin m) :
      (∃ zs, rowHolds (rowValues (A i) x) zs (Bool.xor (a i) (b i))) ↔
      (∑ j, bitF (A i j) * bitF (x j)) = bitF (a i) + bitF (b i) := by
    rw [rowHolds_correct]
    constructor
    · intro h
      have hb := congrArg bitF h
      simpa only [fold_sum, bitF_xor, show bitF false = 0 from rfl, zero_add, sum_rowValues] using hb
    · intro h
      apply bitF_injective
      simpa only [fold_sum, bitF_xor, show bitF false = 0 from rfl, zero_add, sum_rowValues] using h
  constructor
  · rintro ⟨aux,h⟩ i
    exact (hrow i).mp ⟨aux i,h i⟩
  · intro h
    have hx : ∀ i, ∃ zs, rowHolds (rowValues (A i) x) zs (Bool.xor (a i) (b i)) :=
      fun i => (hrow i).mpr (h i)
    choose aux ha using hx
    exact ⟨aux,ha⟩

theorem rowValues_length {n : ℕ} (row x : Fin n → Bool) : (rowValues row x).length ≤ n := by
  calc
    _ ≤ (List.ofFn fun j : Fin n => j).length := List.length_filterMap_le ..
    _ = n := List.length_ofFn ..

#print axioms encode_correct
#print axioms rowValues_length
end OP03

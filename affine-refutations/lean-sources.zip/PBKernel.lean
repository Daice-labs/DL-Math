import FinalCut
import Freshness
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

-- Signed variable form. Coordinates are the actual numeric IDs in the log.
structure PB (v : Nat) where
  coeff : Fin v → Int
  rhs : Int

instance {v : Nat} : DecidableEq (PB v) := fun a b =>
  decidable_of_iff ((∀ j, a.coeff j=b.coeff j) ∧ a.rhs=b.rhs) (by
    constructor
    · rintro ⟨hc,hr⟩
      cases a with
      | mk ac ar =>
        cases b with
        | mk bc br =>
          dsimp only at hc hr
          have hh : ac=bc := funext hc
          subst bc; subst br; rfl
    · intro h; subst b; exact ⟨fun _ => rfl,rfl⟩)

def zero (v : Nat) : PB v := ⟨fun _ => 0,0⟩
def plus {v : Nat} (a b : PB v) : PB v := ⟨fun i => a.coeff i+b.coeff i,a.rhs+b.rhs⟩
def scale {v : Nat} (a : PB v) (k : Nat) : PB v := ⟨fun i => k*a.coeff i,k*a.rhs⟩
def neg {v : Nat} (a : PB v) : PB v := ⟨fun i => -a.coeff i,-a.rhs⟩
def literal (v i : Nat) (positive : Bool) : PB v :=
  ⟨fun j => if j.val=i then (if positive then 1 else -1) else 0,if positive then 0 else -1⟩
def fromTerms (v : Nat) (terms : List (Int × Nat)) (rhs : Int) : PB v :=
  ⟨fun j => (terms.map fun (a,i) => if j.val=i then a else 0).sum,rhs⟩
def fromConstraint (v : Nat) (c : Emit.Constraint) : PB v := fromTerms v c.terms c.rhs
def fromClause (v : Nat) (c : List Int) : PB v :=
  fromTerms v (c.map fun i => (if i<0 then -1 else 1,i.natAbs))
    (1-(c.map fun i => if i<0 then (1 : Int) else 0).sum)

def Holds {v : Nat} (c : PB v) (x : Fin v → Bool) : Prop :=
  c.rhs ≤ ∑ j, c.coeff j * ibit (x j)

def exactDiv {v : Nat} (c : PB v) (d : Nat) : Option (PB v) :=
  if d=0 then none else if ∀ j, c.coeff j % (d : Int)=0 then
    some ⟨fun j => c.coeff j / (d : Int), (c.rhs+(d : Int)-1)/(d : Int)⟩ else none

-- Restricted to exact coefficient division; this is a valid subset of the
-- normalized-form PB division rule used in every emitted division.
theorem exactDiv_sound {v : Nat} (c r : PB v) (d : Nat)
    (hd : exactDiv c d=some r) (x : Fin v → Bool) (hc : Holds c x) : Holds r x := by
  unfold exactDiv at hd
  split at hd
  · contradiction
  · rename_i hd0
    split at hd
    · rename_i he
      simp only [Option.some.injEq] at hd
      subst r
      have hdpos : (0 : Int) < d := by omega
      have hs : (∑ j, c.coeff j*ibit (x j)) =
          (d : Int)*(∑ j, (c.coeff j/(d : Int))*ibit (x j)) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro j _
        have hh := Int.ediv_mul_add_emod (c.coeff j) (d : Int)
        rw [he j] at hh
        calc
          c.coeff j * ibit (x j) = (c.coeff j / (d : Int) * (d : Int))*ibit (x j) := by simpa using congrArg (fun z : Int => z*ibit (x j)) hh.symm
          _ = _ := by ring
      unfold Holds at *
      rw [hs] at hc
      apply (Int.ediv_le_iff_le_mul hdpos).mpr
      nlinarith
    · contradiction

theorem plus_sound {v : Nat} (a b : PB v) (x : Fin v → Bool)
    (ha : Holds a x) (hb : Holds b x) : Holds (plus a b) x := by
  simp only [Holds,plus,add_mul,Finset.sum_add_distrib] at *
  omega

theorem scale_sound {v : Nat} (c : PB v) (k : Nat) (x : Fin v → Bool)
    (hc : Holds c x) : Holds (scale c k) x := by
  simp only [Holds,scale,mul_assoc,← Finset.mul_sum] at *
  exact mul_le_mul_of_nonneg_left hc (by omega)

theorem literal_sound {v i : Nat} (b : Bool) (hi : i<v) (x : Fin v → Bool) :
    Holds (literal v i b) x := by
  simp only [Holds,literal]
  have hs (k : Int) : (∑ j : Fin v, (if j.val=i then k else 0)*ibit (x j)) = k*ibit (x ⟨i,hi⟩) := by
    simp_rw [ite_mul,zero_mul]
    rw [Finset.sum_eq_single ⟨i,hi⟩]
    · simp
    · intro j _ hj
      have hh : j.val≠i := by intro he; apply hj; exact Fin.ext he
      simp [hh]
    · simp
  rw [hs]
  cases b <;> cases h : x ⟨i,hi⟩ <;> simp [ibit]

def lookup {v : Nat} (db : List (PB v)) (i : Nat) : Option (PB v) :=
  if i=0 then none else db[i-1]?

def eval {v : Nat} (db : List (PB v)) : Emit.Expr → Option (PB v)
  | .ref i => lookup db i
  | .lit i b => if 0 < i ∧ i < v then some (literal v i b) else none
  | .add a b => do return plus (← eval db a) (← eval db b)
  | .mul a k => do return scale (← eval db a) k
  | .div a d => do exactDiv (← eval db a) d

theorem lookup_mem {v : Nat} (db : List (PB v)) (i : Nat) (c : PB v)
    (h : lookup db i=some c) : c∈db := by
  unfold lookup at h
  split at h
  · contradiction
  · exact List.mem_of_getElem? h

theorem eval_sound {v : Nat} (db : List (PB v)) (e : Emit.Expr) (c : PB v)
    (h : eval db e=some c) (x : Fin v → Bool) (hm : ∀ p∈db, Holds p x) : Holds c x := by
  induction e generalizing c with
  | ref i => exact hm c (lookup_mem db i c h)
  | lit i b =>
    simp only [eval] at h
    split at h
    · rename_i hi
      cases h
      exact literal_sound b hi.2 x
    · contradiction
  | add a b ia ib =>
    simp only [eval,Option.bind_eq_bind] at h
    cases ha : eval db a with
    | none => simp [ha] at h
    | some ca =>
      cases hb : eval db b with
      | none => simp [ha,hb] at h
      | some cb =>
        simp [ha,hb] at h
        subst c
        exact plus_sound ca cb x (ia ca ha) (ib cb hb)
  | mul a k ia =>
    cases ha : eval db a with
    | none => simp [eval,ha] at h
    | some ca =>
      simp [eval,ha] at h
      subst c
      exact scale_sound ca k x (ia ca ha)
  | div a d ia =>
    cases ha : eval db a with
    | none => simp [eval,ha] at h
    | some ca =>
      simp [eval,ha] at h
      exact exactDiv_sound ca c d h x (ia ca ha)

#print axioms eval_sound
end OP03.Kernel

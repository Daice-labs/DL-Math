import PBComposition
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

def sumPB {v : Nat} : List (PB v) → PB v
  | [] => zero v
  | c::cs => plus c (sumPB cs)

theorem sumPB_coeff {v : Nat} (cs : List (PB v)) (j : Fin v) :
    (sumPB cs).coeff j=(cs.map fun c => c.coeff j).sum := by
  induction cs with
  | nil => rfl
  | cons c cs ih => simp [sumPB,plus,ih]

theorem sumPB_rhs {v : Nat} (cs : List (PB v)) :
    (sumPB cs).rhs=(cs.map PB.rhs).sum := by
  induction cs with
  | nil => rfl
  | cons c cs ih => simp [sumPB,plus,ih]

def gatePB (v : Nat) (g : Emit.Gate) (carry : Nat) : PB v :=
  fromTerms v [(1,g.x),(1,g.v),(1,g.z),(-2,carry)] 0
def rowPay (v : Nat) (r : Emit.Row) : PB v :=
  match Emit.lastVar r.vars r.base with
  | none => zero v
  | some z =>
    if r.vars.length=1 then fromTerms v [(1,z)] (ibit r.rhs)
    else fromTerms v [(-1,z)] (-ibit r.rhs)
def delta {v : Nat} (j : Fin v) (k : Nat) : F := if j.val=k then 1 else 0

theorem gatePB_mod {v : Nat} (g : Emit.Gate) (carry : Nat) (j : Fin v) :
    ((gatePB v g carry).coeff j : F)=Emit.gateValue (delta j) g := by
  simp only [gatePB,fromTerms,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,
    Int.cast_add,Int.cast_ite,Int.cast_one,Int.cast_zero,Int.cast_neg,Int.cast_ofNat,
    Emit.gateValue,delta]
  have h2 : (2 : F)=0 := by decide
  simp [h2,add_assoc]

theorem rowPay_mod {v : Nat} (r : Emit.Row) (j : Fin v) :
    ((rowPay v r).coeff j : F) =
      match Emit.lastVar r.vars r.base with
      | none => 0
      | some z => delta j z := by
  unfold rowPay
  split
  · rfl
  · rename_i z hz
    split <;> simp [fromTerms,delta,Emit.negate_eq_self]

theorem row_gates_pay_mod {v : Nat} (r : Emit.Row) (j : Fin v) :
    (((Emit.gates r.vars r.base).map (Emit.gateValue (delta j))).sum +
      ((rowPay v r).coeff j : F)) = Emit.rowValue r.vars r.base (delta j) := by
  rw [rowPay_mod]
  cases hv : r.vars <;> simp [Emit.gates,Emit.lastVar,Emit.rowValue,hv]

theorem rowPay_rhs_mod (v : Nat) (r : Emit.Row)
    (h : r.vars=[] → r.rhs=false) : ((rowPay v r).rhs : F)=bitF r.rhs := by
  unfold rowPay
  cases hv : r.vars with
  | nil => simp [Emit.lastVar,hv,h hv,zero,bitF]
  | cons x xs =>
    simp only [Emit.lastVar,hv]
    split <;> simp [fromTerms,Emit.ibit_cast,Emit.negate_eq_self]

def aggregatePB (v header : Nat) (rs : List Emit.Row) : PB v :=
  let gs := rs.flatMap fun r => Emit.gates r.vars r.base
  plus (sumPB (gs.zipIdx.map fun (g,i) => gatePB v g (header+2*i+1)))
    (sumPB (rs.map (rowPay v)))

theorem aggregatePB_mod {v : Nat} (header : Nat) (rs : List Emit.Row) (j : Fin v) :
    ((aggregatePB v header rs).coeff j : F) =
      (rs.map fun r => Emit.rowValue r.vars r.base (delta j)).sum := by
  simp only [aggregatePB,plus,sumPB_coeff,List.map_map,Function.comp_def,Int.cast_add]
  push_cast
  simp only [List.map_map,Function.comp_def]
  simp_rw [gatePB_mod]
  have hz (gs : List Emit.Gate) :
      (gs.zipIdx.map fun p => Emit.gateValue (delta j) p.1).sum = (gs.map (Emit.gateValue (delta j))).sum := by
    change (gs.zipIdx.map ((Emit.gateValue (delta j)) ∘ Prod.fst)).sum = _
    rw [← List.map_map]
    simp
  rw [hz]
  induction rs with
  | nil => simp
  | cons r rs ih =>
    simp only [List.flatMap_cons,List.map_append,List.sum_append,List.map_cons,List.sum_cons] at *
    rw [← row_gates_pay_mod r j,← ih]
    ring

theorem aggregatePB_rhs_mod (v header : Nat) (rs : List Emit.Row)
    (h : ∀ r∈rs, r.vars=[] → r.rhs=false) :
    ((aggregatePB v header rs).rhs : F) = (rs.map fun r => bitF r.rhs).sum := by
  simp only [aggregatePB,plus,sumPB_rhs,List.map_map,Function.comp_def,Int.cast_add]
  simp only [gatePB,fromTerms,List.map_const',List.sum_replicate,mul_zero,zero_add]
  push_cast
  simp only [List.map_map,Function.comp_def]
  simp only [nsmul_zero,Int.cast_zero,zero_add]
  apply congrArg List.sum
  apply List.map_congr_left
  intro r hr
  exact rowPay_rhs_mod v r (h r hr)

#print axioms aggregatePB_mod
#print axioms aggregatePB_rhs_mod
end OP03.Kernel

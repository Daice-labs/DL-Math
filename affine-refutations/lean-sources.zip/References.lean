import Emitter
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace OP03.Emit

def exprRefs : Expr → List Nat
  | .ref i => [i]
  | .lit _ _ => []
  | .add a b => exprRefs a ++ exprRefs b
  | .mul a _ => exprRefs a
  | .div a _ => exprRefs a

def commandRefs : Command → List Nat
  | .pol e => exprRefs e
  | _ => []

def ExprSafe (k : Nat) (e : Expr) : Prop := ∀ i ∈ exprRefs e, 0 < i ∧ i ≤ k

def RefsSafe : Nat → List Command → Prop
  | _, [] => True
  | k, c::cs => (∀ i ∈ commandRefs c, 0 < i ∧ i ≤ k) ∧ RefsSafe (k+1) cs

theorem gate_refs (g : Gate) (t u k : Nat) : RefsSafe k (gateBlock g t u k) := by
  simp [gateBlock, Local.prefixes, RefsSafe, commandRefs, exprRefs] <;> omega

theorem refs_append (k : Nat) (xs ys : List Command) :
    RefsSafe k (xs++ys) ↔ RefsSafe k xs ∧ RefsSafe (k+xs.length) ys := by
  induction xs generalizing k with
  | nil => simp [RefsSafe]
  | cons x xs ih => simp [RefsSafe, ih, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm, and_assoc]

theorem blocks_refs (gs : List Gate) (v k : Nat) : RefsSafe k (blocks gs v k) := by
  induction gs generalizing v k with
  | nil => trivial
  | cons g gs ih =>
    rw [blocks,refs_append,gateBlock_length]
    exact ⟨gate_refs g _ _ k,ih _ _⟩

theorem exprSafe_mono {k l : Nat} {e : Expr} (h : ExprSafe k e) (hkl : k≤l) : ExprSafe l e := by
  intro i hi
  exact ⟨(h i hi).1, le_trans (h i hi).2 hkl⟩

theorem exprSafe_add {k : Nat} {a b : Expr} (ha : ExprSafe k a) (hb : ExprSafe k b) :
    ExprSafe k (.add a b) := by
  intro i hi
  rcases List.mem_append.mp hi with h | h
  · exact ha i h
  · exact hb i h

theorem fold_add_safe (es : List Expr) (e : Expr) (k : Nat)
    (he : ExprSafe k e) (hs : ∀ a∈es, ExprSafe k a) : ExprSafe k (es.foldl Expr.add e) := by
  induction es generalizing e with
  | nil => exact he
  | cons a as ih =>
    apply ih _ (exprSafe_add he (hs a (by simp)))
    intro a ha
    exact hs a (by simp [ha])

theorem aggregate_safe (es : List Expr) (k : Nat) (hne : es≠[])
    (h : ∀ e∈es, ExprSafe k e) : ExprSafe k (aggregate es) := by
  cases es with
  | nil => contradiction
  | cons e es => exact fold_add_safe es e k (h e (by simp)) (fun a ha => h a (by simp [ha]))

#print axioms gate_refs
#print axioms blocks_refs
#print axioms aggregate_safe
end OP03.Emit

import NumericEncoding
set_option maxHeartbeats 0
namespace OP03.Numeric
open OP03.Emit

theorem tail_complete (X : Nat → Bool) (pre xs : List Nat) (cur base : Nat)
    (hp : 0 < cur) (hx : ∀ x∈xs, 0 < x)
    (hcur : X cur=parity X pre)
    (haux : ∀ j, j<xs.length → X (base+j+1)=parity X (pre++xs.take (j+1))) :
    CNF X ((tailGates cur xs base).flatMap gateClauses) ∧
      X (lastTail cur xs base)=parity X (pre++xs) := by
  induction xs generalizing pre cur base with
  | nil => exact ⟨by simp [tailGates,CNF],by simpa [lastTail] using hcur⟩
  | cons x xs ih =>
    have hfirst : X (base+1)=parity X (pre++[x]) := by simpa using haux 0 (by simp)
    have hg : CNF X (gateClauses ⟨cur,x,base+1⟩) := by
      apply (gate_cnf X _ hp (hx x (by simp)) (by change 0 < base+1; omega)).mpr
      simpa [hcur,parity_append_one] using hfirst
    have hnext : ∀ j, j<xs.length → X (base+1+j+1)=parity X ((pre++[x])++xs.take (j+1)) := by
      intro j hj
      have hh := haux (j+1) (by simp; omega)
      simpa [List.take_succ_cons,List.append_assoc,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hh
    have hh := ih (pre++[x]) (base+1) (base+1) (by omega) (fun x hx' => hx x (by simp [hx'])) hfirst hnext
    constructor
    · simpa only [tailGates,List.flatMap_cons,cnf_append] using And.intro hg hh.1
    · simpa [lastTail,List.append_assoc] using hh.2

theorem row_complete (X : Nat → Bool) (vs : List Nat) (base : Nat) (rhs : Bool)
    (hp : ∀ x∈vs, 0 < x ∧ x≤base) (hpar : parity X vs=rhs)
    (haux : ∀ j, j+1<vs.length → X (base+j+1)=parity X (vs.take (j+2))) :
    CNF X (rowClauses vs base rhs) := by
  cases vs with
  | nil => have hr : rhs=false := by simpa [parity] using hpar.symm
           simp [rowClauses,gates,lastVar,hr,CNF]
  | cons x xs =>
    have ht := tail_complete X [x] xs x base (hp x (by simp)).1
      (fun x hx => (hp x (by simp [hx])).1) (by simp [parity]) (by
        intro j hj
        simpa [List.take_succ_cons,Nat.add_assoc] using haux j (by simp; omega))
    have hz := (Kernel.lastTail_bounds xs x base (hp x (by simp)).1 (hp x (by simp)).2).1
    have hu : CNF X [[if rhs then (lastTail x xs base : Int) else -(lastTail x xs base : Int)]] := by
      apply (unit_cnf X _ hz rhs).mpr
      simpa using ht.2.trans hpar
    exact (cnf_append X _ _).mpr ⟨ht.1,hu⟩

def inputValue {n : Nat} (x : Fin n → Bool) (k : Nat) : Bool :=
  if h : 0 < k ∧ k≤n then x ⟨k-1,by omega⟩ else false

def extension {m n : Nat} (A : Fin m → Fin n → Bool) (x : Fin n → Bool) (k : Nat) : Bool :=
  if k≤n then inputValue x k else
    if hi : (k-n-1)/n<m then
      parity (inputValue x) ((rowVars (A ⟨(k-n-1)/n,hi⟩)).take ((k-n-1)%n+2))
    else false

theorem inputValue_original {n : Nat} (x : Fin n → Bool) (j : Fin n) : inputValue x (j.val+1)=x j := by
  simp [inputValue,j.isLt]
theorem extension_original {m n : Nat} (A : Fin m → Fin n → Bool) (x : Fin n → Bool) (j : Fin n) :
    extension A x (j.val+1)=x j := by
  simp [extension,inputValue_original,show j.val+1≤n from by omega]

theorem extension_aux {m n : Nat} (A : Fin m → Fin n → Bool) (x : Fin n → Bool)
    (i : Fin m) (j : Nat) (hj : j<n) :
    extension A x (n+i.val*n+j+1)=parity (inputValue x) ((rowVars (A i)).take (j+2)) := by
  have hn : 0 < n := by omega
  have hk : ¬ n+i.val*n+j+1≤n := by omega
  have hs : n+i.val*n+j+1-n-1=i.val*n+j := by omega
  have hd : (i.val*n+j)/n=i.val := by simp [Nat.add_div,Nat.div_eq_of_lt hj,Nat.mul_div_left,hn,Nat.mod_eq_of_lt hj,hj]
  have hm : (i.val*n+j)%n=j := by simp [Nat.add_mod,Nat.mod_eq_of_lt hj]
  simp [extension,hk,hs,hd,hm,i.isLt]

theorem extension_parity {m n : Nat} (A : Fin m → Fin n → Bool) (x : Fin n → Bool)
    (vs : List Nat) (hb : ∀ k∈vs, k≤n) : parity (extension A x) vs=parity (inputValue x) vs := by
  unfold parity
  congr 1
  apply List.map_congr_left
  intro k hk
  simp [extension,hb k hk]

theorem solves_implies_source {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (x : Fin n → Bool) (hx : Solves A a b x) :
    CNF (extension A x) ((rows A a b y).flatMap Row.clauses) := by
  apply (cnf_flatMap _ _ _).mpr
  intro r hr
  obtain ⟨i,hvars,hbase,hrhs⟩ := Kernel.row_origin A a b y r hr
  rw [rows_good A a b y r hr,hvars,hbase,hrhs]
  apply row_complete
  · intro k hk
    have h := rowVars_mem_bound (A i) k hk
    exact ⟨h.1,by omega⟩
  · apply bitF_injective
    rw [parity_rowVars,bitF_xor]
    simpa only [extension_original] using hx i
  · intro j hj
    have hlen := rowVars_length (A i)
    have hjn : j<n := by omega
    rw [extension_aux A x i j hjn]
    symm
    apply extension_parity
    intro k hk
    exact (rowVars_mem_bound (A i) k (List.mem_of_mem_take hk)).2

theorem emitted_encode_correct {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (x : Fin n → Bool) :
    (∃ X : Nat → Bool, (∀ j : Fin n, X (j.val+1)=x j) ∧
      CNF X ((rows A a b y).flatMap Row.clauses)) ↔ Solves A a b x := by
  constructor
  · rintro ⟨X,hx,hc⟩
    have h := source_implies_solves A a b y X hc
    simpa only [hx] using h
  · intro hx
    exact ⟨extension A x,extension_original A x,solves_implies_source A a b y x hx⟩

#print axioms emitted_encode_correct
end OP03.Numeric

import PBCheck
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

theorem subst_holds {v : Nat} (c : PB v) (j : Fin v) (b : Bool) (x : Fin v → Bool) :
    Holds (subst c j b) x ↔ Holds c (Function.update x j b) := by
  have he : (∑ i, c.coeff i*ibit (Function.update x j b i)) =
      (∑ i, (if i=j then 0 else c.coeff i)*ibit (x i)) + c.coeff j*ibit b := by
    have ht (i : Fin v) : c.coeff i*ibit (Function.update x j b i) =
        (if i=j then 0 else c.coeff i)*ibit (x i)+(if i=j then c.coeff j*ibit b else 0) := by
      by_cases h : i=j
      · subst i; simp
      · simp [h,Function.update_of_ne h]
    simp_rw [ht]
    simp [Finset.sum_add_distrib]
  simp only [Holds,subst]
  rw [he]
  omega

theorem goal_sound {v : Nat} (db : List (PB v)) (hint c : PB v) (h : goal db hint c=true)
    (x : Fin v → Bool) (hm : Models db x) (hh : Holds hint x) : Holds c x := by
  simp only [goal,Bool.or_eq_true] at h
  rcases h with ((ht | hw) | hd) | hr
  · exact trivial_sound c ht x
  · exact weakImplies_sound hint c hw x hh
  · obtain ⟨d,hd,he⟩ := List.any_eq_true.mp hd
    have he' : d=c := of_decide_eq_true he
    subst d; exact hm c hd
  · apply rup_sound (db++[hint]) c hr x
    intro d hd
    rcases List.mem_append.mp hd with hd | hd
    · exact hm d hd
    · simp only [List.mem_singleton] at hd; subst d; exact hh

theorem red_sound {v : Nat} (db : List (PB v)) (c : PB v) (j : Fin v) (b : Bool)
    (h : red db c j b=true) (x : Fin v → Bool) (hm : Models db x) :
    ∃ z, Models (db++[c]) z := by
  by_cases hc : Holds c x
  · refine ⟨x,?_⟩
    intro d hd
    rcases List.mem_append.mp hd with hd | hd
    · exact hm d hd
    · simp only [List.mem_singleton] at hd; subst d; exact hc
  · refine ⟨Function.update x j b,?_⟩
    intro d hd
    have hmem : d∈c::db := by simpa [or_comm] using hd
    have hg := List.all_eq_true.mp h d hmem
    exact (subst_holds d j b x).mp (goal_sound db (negate c) (subst d j b) hg x hm
      ((negate_iff c x).mpr hc))

theorem step_sound {v : Nat} (db out : List (PB v)) (cmd : Emit.Command)
    (hs : step db cmd=some out) (hm : ∃ x, Models db x) : ∃ x, Models out x := by
  obtain ⟨x,hx⟩ := hm
  cases cmd with
  | pol e =>
    cases he : eval db e with
    | none => simp [step,he] at hs
    | some c =>
      simp [step,he] at hs
      subst out
      refine ⟨x,?_⟩
      intro d hd
      rcases List.mem_append.mp hd with hd | hd
      · exact hx d hd
      · simp only [List.mem_singleton] at hd; subst d
        exact eval_sound db e c he x hx
  | rup c =>
    simp only [step] at hs
    split at hs
    · rename_i hh
      simp at hs
      subst out
      refine ⟨x,?_⟩
      intro d hd
      rcases List.mem_append.mp hd with hd | hd
      · exact hx d hd
      · simp only [List.mem_singleton] at hd; subst d
        exact rup_sound db (fromConstraint v c) (by simpa only [Bool.and_eq_true] using hh : wellFormed v c=true ∧ _).2 x hx
    · simp at hs
  | red c j b =>
    simp only [step] at hs
    split at hs
    · rename_i hj
      split at hs
      · rename_i hh
        simp at hs
        subst out
        exact red_sound db (fromConstraint v c) ⟨j,hj.2⟩ b (by simpa only [Bool.and_eq_true] using hh : wellFormed v c=true ∧ _).2 x hx
      · simp at hs
    · simp at hs

theorem run_sound {v : Nat} (cmds : List Emit.Command) (db out : List (PB v))
    (h : run db cmds=some out) (hm : ∃ x, Models db x) : ∃ x, Models out x := by
  induction cmds generalizing db with
  | nil => simp only [run,Option.some.injEq] at h; subst out; exact hm
  | cons c cs ih =>
    cases hs : step db c with
    | none => simp [run,hs] at h
    | some next =>
      simp [run,hs] at h
      exact ih next h (step_sound db next c hs hm)

def contradiction {v : Nat} (c : PB v) : Bool := decide (maximum c (fun _ => none)<c.rhs)
def sourceWellFormed (v : Nat) (source : List (List Int)) : Bool :=
  source.all fun c => c.all fun i => decide (0 < i.natAbs ∧ i.natAbs < v)

def checkUnchecked (v : Nat) (source : List (List Int)) (cmds : List Emit.Command) (conclusion : Nat) : Bool :=
  match run (source.map (fromClause v)) cmds with
  | none => false
  | some db => match lookup db conclusion with
    | none => false
    | some c => contradiction c

def check (v : Nat) (source : List (List Int)) (cmds : List Emit.Command) (conclusion : Nat) : Bool :=
  sourceWellFormed v source && checkUnchecked v source cmds conclusion

theorem check_sound (v : Nat) (source : List (List Int)) (cmds : List Emit.Command) (conclusion : Nat)
    (h : check v source cmds conclusion=true) : ¬ ∃ x, Models (source.map (fromClause v)) x := by
  intro hm
  have hh : sourceWellFormed v source=true ∧ checkUnchecked v source cmds conclusion=true := by simpa only [check,Bool.and_eq_true] using h
  have h := hh.2
  unfold checkUnchecked at h
  split at h
  · contradiction
  · rename_i db hr
    split at h
    · contradiction
    · rename_i c hc
      obtain ⟨x,hx⟩ := run_sound cmds _ db hr hm
      have he := hx c (lookup_mem db conclusion c hc)
      have hm := eval_le_max c (fun _ => none) x (by intro j b hh; contradiction)
      have hh : maximum c (fun _ => none) < c.rhs := of_decide_eq_true h
      unfold Holds at he
      omega

#print axioms run_sound
#print axioms check_sound
end OP03.Kernel

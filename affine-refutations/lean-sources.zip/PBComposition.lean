import PBTraceSound
import GeneratedReferences
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

@[ext] theorem pb_ext {v : Nat} {a b : PB v}
    (hc : ∀ j, a.coeff j=b.coeff j) (hr : a.rhs=b.rhs) : a=b := by
  cases a with
  | mk ac ar =>
    cases b with
    | mk bc br =>
      have hh : ac=bc := funext hc
      dsimp only at hr
      subst bc; subst br; rfl

theorem lookup_append {v : Nat} (db more : List (PB v)) (i : Nat)
    (hi : i≤db.length) : lookup (db++more) i=lookup db i := by
  unfold lookup
  by_cases h : i=0
  · simp [h]
  · simp only [h,if_false]
    exact List.getElem?_append_left (by omega)

theorem eval_append {v : Nat} (db more : List (PB v)) (e : Emit.Expr)
    (he : Emit.ExprSafe db.length e) : eval (db++more) e=eval db e := by
  induction e with
  | ref i => exact lookup_append db more i (he i (by simp [Emit.exprRefs])).2
  | lit i b => rfl
  | add a b ia ib =>
    have ha : Emit.ExprSafe db.length a := fun i hi => he i (by simp [Emit.exprRefs,hi])
    have hb : Emit.ExprSafe db.length b := fun i hi => he i (by simp [Emit.exprRefs,hi])
    simp [eval,ia ha,ib hb]
  | mul a k ia => simpa only [eval,ia he]
  | div a k ia => simpa only [eval,ia he]

theorem run_append {v : Nat} (db : List (PB v)) (xs ys : List Emit.Command) :
    run db (xs++ys) = (run db xs).bind (fun next => run next ys) := by
  induction xs generalizing db with
  | nil => simp [run]
  | cons c cs ih =>
    cases hs : step db c <;> simp [run,hs,ih]

def half {v : Nat} (c : PB v) : PB v := ⟨fun j => c.coeff j/2,(c.rhs+1)/2⟩
def bottom (v : Nat) : PB v := ⟨fun _ => 0,1⟩

theorem exactDiv_two {v : Nat} (c : PB v) (he : ∀ j, (c.coeff j : F)=0) :
    exactDiv c 2=some (half c) := by
  have hz : ∀ j, c.coeff j % (2 : Int)=0 := by
    intro j
    obtain ⟨k,hk⟩ := even_from_cast (c.coeff j) (he j)
    omega
  have hh : c.rhs+2-1=c.rhs+1 := by omega
  simp [exactDiv,hz,half,hh]

theorem halves_bottom {v : Nat} (c : PB v) (he : ∀ j, (c.coeff j : F)=0)
    (ho : (c.rhs : F)=1) : plus (half c) (half (neg c))=bottom v := by
  have h := final_divide_add (⟨c.coeff,c.rhs⟩ : IntegerPB v) he ho
  apply pb_ext
  · exact h.1
  · exact h.2

theorem neg_even {v : Nat} (c : PB v) (he : ∀ j, (c.coeff j : F)=0) :
    ∀ j, ((neg c).coeff j : F)=0 := by
  intro j
  simp [neg,he j]

theorem lookup_last {v : Nat} (db : List (PB v)) (c : PB v) :
    lookup (db++[c]) (db.length+1)=some c := by
  simp [lookup]

theorem eval_final {v : Nat} (db : List (PB v)) (c : PB v)
    (he : ∀ j, (c.coeff j : F)=0) (ho : (c.rhs : F)=1) :
    eval (db++[c,neg c])
      (.add (.div (.ref (db.length+1)) 2) (.div (.ref (db.length+2)) 2)) = some (bottom v) := by
  have h1 : lookup (db++[c,neg c]) (db.length+1)=some c := by simp [lookup]
  have h2 : lookup (db++[c,neg c]) (db.length+2)=some (neg c) := by simp [lookup]
  simp only [eval,h1,h2]
  simp [exactDiv_two c he,exactDiv_two (neg c) (neg_even c he),halves_bottom c he ho]

theorem finish_run {v : Nat} (db : List (PB v)) (lo hi : Emit.Expr) (c : PB v)
    (hlo : eval db lo=some c) (hhi : eval db hi=some (neg c))
    (href : Emit.ExprSafe db.length hi)
    (he : ∀ j, (c.coeff j : F)=0) (ho : (c.rhs : F)=1) :
    run db [.pol lo,.pol hi,
      .pol (.add (.div (.ref (db.length+1)) 2) (.div (.ref (db.length+2)) 2))] =
      some (db++[c,neg c,bottom v]) := by
  have hh : eval (db++[c]) hi=some (neg c) := by rw [eval_append db [c] hi href,hhi]
  have hf := eval_final db c he ho
  simp only [run,step,hlo]
  simp only [Option.bind_eq_bind,Option.bind_some,Option.pure_def]
  simp only [hh]
  simp only [Option.bind_some,Option.pure_def,List.append_assoc]
  simp [hf,run,List.append_assoc]

theorem bottom_contradiction (v : Nat) : contradiction (bottom v)=true := by
  simp [contradiction,maximum,bottom]

#print axioms eval_final
#print axioms finish_run
end OP03.Kernel

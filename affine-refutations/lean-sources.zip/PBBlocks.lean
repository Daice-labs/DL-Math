import PBGateAccept
set_option maxHeartbeats 0
namespace OP03.Kernel

theorem GateFit.mono {g : Emit.Gate} {h k : Nat} (hf : GateFit g h) (hk : h≤k) : GateFit g k :=
  ⟨hf.posX,hf.posV,hf.posZ,le_trans hf.boundX hk,le_trans hf.boundV hk,le_trans hf.boundZ hk,hf.distinct⟩

def GateOutputs {v : Nat} (db : List (PB v)) (gs : List Emit.Gate) (h k : Nat) : Prop :=
  ∀ i g, gs[i]?=some g →
    lookup db (k+23*i+22)=some (gatePB v g (h+2*i+1)) ∧
    lookup db (k+23*i+23)=some (neg (gatePB v g (h+2*i+1)))

theorem blocks_accepted {v : Nat} (gs : List Emit.Gate) (h : Nat)
    (hf : ∀ g∈gs, GateFit g h) (hv : h+2*gs.length < v)
    (db : List (PB v)) (hb : Bounded db h)
    (hc : ∀ g∈gs, ∀ c∈Emit.gateClauses g, fromClause v c∈db) :
    ∃ added, added.length=23*gs.length ∧
      run db (Emit.blocks gs h db.length)=some (db++added) ∧
      GateOutputs (db++added) gs h db.length ∧ Bounded (db++added) (h+2*gs.length) := by
  induction gs generalizing h db with
  | nil =>
    refine ⟨[],by simp,by simp [Emit.blocks,run],?_,?_⟩
    · intro i g hi; simp at hi
    · simpa using hb
  | cons g gs ih =>
    have hfit := hf g (by simp)
    have hroom : h+2 < v := by simp only [List.length_cons] at hv; omega
    obtain ⟨first,hlen,hr,hlo,hhi,hbound⟩ := gate_accepted g h hfit hroom db hb (hc g (by simp))
    have htailfit : ∀ g∈gs, GateFit g (h+2) := by
      intro g hg; exact (hf g (by simp [hg])).mono (by omega)
    have htailroom : h+2+2*gs.length < v := by simp only [List.length_cons] at hv; omega
    have htailclauses : ∀ g∈gs, ∀ c∈Emit.gateClauses g, fromClause v c∈db++first := by
      intro g hg c hcc
      exact List.mem_append_left _ (hc g (by simp [hg]) c hcc)
    obtain ⟨rest,rlen,rr,rout,rbound⟩ := ih (h+2) htailfit htailroom (db++first) hbound htailclauses
    have dblen : (db++first).length=db.length+23 := by simp [hlen]
    refine ⟨first++rest,?_,?_,?_,?_⟩
    · simp [hlen,rlen]; omega
    · rw [Emit.blocks,run_append,hr]
      simpa [dblen,List.append_assoc] using rr
    · intro i g' hi
      cases i with
      | zero =>
        simp only [List.getElem?_cons_zero,Option.some.injEq] at hi
        subst g'
        have hl : db.length+22≤(db++first).length := by rw [dblen]; omega
        have hh : db.length+23≤(db++first).length := by rw [dblen]
        simp only [Nat.mul_zero,Nat.add_zero]
        rw [← List.append_assoc,lookup_append (db++first) rest _ hl,lookup_append (db++first) rest _ hh]
        exact ⟨hlo,hhi⟩
      | succ i =>
        have hh := rout i g' (by simpa using hi)
        simpa [dblen,List.append_assoc,Nat.mul_add,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hh
    · simpa [List.append_assoc,Nat.mul_add,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using rbound

#print axioms blocks_accepted
end OP03.Kernel

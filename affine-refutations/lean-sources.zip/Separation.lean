import Affine
import Mathlib.LinearAlgebra.Dual.Lemmas
import Mathlib.LinearAlgebra.Matrix.ToLin
import Mathlib.Tactic
set_option maxHeartbeats 0
namespace OP03
open scoped BigOperators
abbrev F := ZMod 2

theorem dual_coordinates {m : ℕ} (f : (Fin m → F) →ₗ[F] F) (v : Fin m → F) :
    f v = ∑ i, f (Pi.single i 1) * v i := by
  conv_lhs => rw [← LinearMap.sum_single_apply (fun _ : Fin m => F) v]
  rw [map_sum]
  apply Finset.sum_congr rfl
  intro i _
  have hs : Pi.single i (v i) = v i • (Pi.single i (1 : F)) := by
    ext j
    by_cases h : j = i
    · subst j; simp
    · simp [Pi.single_apply, h, Ne.symm h]
  rw [hs, map_smul]
  simp [smul_eq_mul, mul_comm]

theorem nonzero_one (z : F) (h : z ≠ 0) : z = 1 := by
  fin_cases z
  · exact (h rfl).elim
  · rfl

theorem separating_vector {m n : ℕ} (A : Matrix (Fin m) (Fin n) F) (c : Fin m → F) :
    (¬ ∃ x : Fin n → F, ∀ i, ∑ j, A i j * x j = c i) ↔
      ∃ y : Fin m → F, (∀ j, ∑ i, y i * A i j = 0) ∧ ∑ i, y i * c i = 1 := by
  constructor
  · intro h
    have hc : c ∉ (Matrix.mulVecLin A).range := by
      rintro ⟨x, hx⟩
      apply h
      exact ⟨x, fun i => congrFun hx i⟩
    obtain ⟨f, hf, hz⟩ := Submodule.exists_dual_map_eq_bot_of_notMem hc inferInstance
    refine ⟨fun i => f (Pi.single i 1), ?_, ?_⟩
    · intro j
      have mem : A.col j ∈ (Matrix.mulVecLin A).range := by
        refine ⟨Pi.single j 1, ?_⟩
        ext i
        simp [Matrix.mulVecLin_apply, Matrix.mulVec, dotProduct, Matrix.col, Pi.single_apply, mul_ite]
      have hm : f (A.col j) ∈ Submodule.map f (Matrix.mulVecLin A).range :=
        Submodule.mem_map.mpr ⟨A.col j, mem, rfl⟩
      rw [hz, Submodule.mem_bot] at hm
      rw [dual_coordinates] at hm
      exact hm
    · rw [← dual_coordinates]
      exact nonzero_one _ hf
  · rintro ⟨y, hy, hc⟩
    exact Affine.separating_witness_unsat A c y hy hc
#print axioms separating_vector
end OP03

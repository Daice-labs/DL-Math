import LocalRUP
set_option maxHeartbeats 0
namespace OP03.Local

def eval (c : PB) (x : Nat → Bool) : Int :=
  (c.coeff.zipIdx.map fun (a,i) => a * ibit (x i)).sum

def Agrees (p : Partial) (x : Nat → Bool) : Prop := ∀ i b, p i = some b → x i = b

def Models (db : List PB) (x : Nat → Bool) : Prop := ∀ c ∈ db, c.rhs ≤ eval c x

theorem term_le_max (p : Partial) (x : Nat → Bool) (h : Agrees p x) (a : Int) (i : Nat) :
    a * ibit (x i) ≤ (match p i with | some false => 0 | some true => a | none => max 0 a) := by
  cases hp : p i with
  | none => cases hx : x i <;> simp [hp, hx, ibit]
  | some b =>
    have hx := h i b hp
    cases b <;> simp [hp, hx, ibit]

theorem eval_le_maximum (c : PB) (p : Partial) (x : Nat → Bool) (h : Agrees p x) :
    eval c x ≤ maximum c p := by
  unfold eval maximum
  generalize c.coeff.zipIdx = terms
  induction terms with
  | nil => simp
  | cons term rest ih =>
    simp only [List.map_cons, List.sum_cons]
    exact add_le_add (term_le_max p x h term.1 term.2) ih

theorem conflict_sound (db : List PB) (p : Partial) (x : Nat → Bool)
    (hs : Models db x) (ha : Agrees p x) (hc : conflict db p = true) : False := by
  obtain ⟨c,hc,hbad⟩ := List.any_eq_true.mp hc
  have bad : maximum c p < c.rhs := of_decide_eq_true hbad
  exact (not_lt_of_ge (le_trans (hs c hc) (eval_le_maximum c p x ha))) bad

theorem agrees_update (p : Partial) (x : Nat → Bool) (ha : Agrees p x)
    (v : Nat) (b : Bool) (hb : x v = b) : Agrees (Function.update p v (some b)) x := by
  intro i c h
  by_cases hi : i = v
  · subst i
    simp only [Function.update_self, Option.some.injEq] at h
    exact hb.trans h
  · apply ha i c
    simpa [Function.update_of_ne hi] using h

theorem force_agrees (db : List PB) (p : Partial) (x : Nat → Bool)
    (hs : Models db x) (ha : Agrees p x) (v : Nat) : Agrees (force db p v) x := by
  unfold force
  split
  · exact ha
  · split
    · rename_i hconf
      apply agrees_update p x ha v true
      cases hx : x v
      · exact (conflict_sound db _ x hs (agrees_update p x ha v false hx) hconf).elim
      · rfl
    · split
      · rename_i hconf
        apply agrees_update p x ha v false
        cases hx : x v
        · rfl
        · exact (conflict_sound db _ x hs (agrees_update p x ha v true hx) hconf).elim
      · exact ha

theorem force_list_agrees (vars : List Nat) (db : List PB) (p : Partial) (x : Nat → Bool)
    (hs : Models db x) (ha : Agrees p x) : Agrees (vars.foldl (force db) p) x := by
  induction vars generalizing p with
  | nil => exact ha
  | cons v vs ih => exact ih _ (force_agrees db p x hs ha v)

theorem up_sound (fuel : Nat) (db : List PB) (p : Partial) (x : Nat → Bool)
    (hs : Models db x) (ha : Agrees p x) (hc : up fuel db p = true) : False := by
  induction fuel generalizing p with
  | zero => exact conflict_sound db p x hs ha hc
  | succ fuel ih =>
    simp only [up] at hc
    split at hc
    · rename_i h
      exact conflict_sound db p x hs ha h
    · exact ih _ (force_list_agrees _ db p x hs ha) hc

#print axioms up_sound
end OP03.Local

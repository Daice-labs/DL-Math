import GlobalParity
set_option maxHeartbeats 0
namespace OP03
open scoped BigOperators

-- Signed exact-coefficient division is the special case used by this emitter.
structure IntegerPB (v : Nat) where
  coeff : Fin v → Int
  rhs : Int

def halve {v : Nat} (c : IntegerPB v) : IntegerPB v :=
  ⟨fun j => c.coeff j / 2, (c.rhs+1)/2⟩

def opposite {v : Nat} (c : IntegerPB v) : IntegerPB v :=
  ⟨fun j => -c.coeff j, -c.rhs⟩

def addPB {v : Nat} (a b : IntegerPB v) : IntegerPB v :=
  ⟨fun j => a.coeff j+b.coeff j, a.rhs+b.rhs⟩

theorem even_from_cast (z : Int) (h : (z : F)=0) : ∃ k : Int, z=2*k := by
  obtain ⟨k,hk⟩ := (ZMod.intCast_zmod_eq_zero_iff_dvd z 2).mp h
  exact ⟨k,hk⟩

theorem odd_from_cast (z : Int) (h : (z : F)=1) : ∃ k : Int, z=2*k+1 := by
  have hz : ((z-1 : Int) : F)=0 := by push_cast; rw [h]; simp
  obtain ⟨k,hk⟩ := even_from_cast (z-1) hz
  exact ⟨k,by omega⟩

theorem final_divide_add {v : Nat} (c : IntegerPB v)
    (he : ∀ j, (c.coeff j : F)=0) (ho : (c.rhs : F)=1) :
    (∀ j, (addPB (halve c) (halve (opposite c))).coeff j=0) ∧
      (addPB (halve c) (halve (opposite c))).rhs=1 := by
  obtain ⟨k,hk⟩ := odd_from_cast c.rhs ho
  constructor
  · intro j
    obtain ⟨a,ha⟩ := even_from_cast (c.coeff j) (he j)
    simp only [addPB,halve,opposite]
    rw [ha]
    omega
  · simp only [addPB,halve,opposite]
    rw [hk]
    omega

-- Soundness of the same exact-coefficient half step for integer assignments.
theorem halve_sound {v : Nat} (c : IntegerPB v) (x : Fin v → Int)
    (he : ∀ j, (c.coeff j : F)=0)
    (h : c.rhs ≤ ∑ j, c.coeff j*x j) :
    (halve c).rhs ≤ ∑ j, (halve c).coeff j*x j := by
  have eqn : (∑ j, c.coeff j*x j) = 2*(∑ j, (c.coeff j/2)*x j) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    obtain ⟨k,hk⟩ := even_from_cast (c.coeff j) (he j)
    rw [hk]
    have hd : 2*k/2=k := by omega
    rw [hd]; ring
  simp only [halve]
  rw [eqn] at h
  omega

#print axioms final_divide_add
#print axioms halve_sound
end OP03

import PBGateLift
set_option maxHeartbeats 0
namespace OP03.Kernel

def gateConstraints (g : Emit.Gate) : List Emit.Constraint :=
  [⟨[(1,g.x),(1,g.v),(-1,g.z)],0⟩,
   ⟨[(1,g.x),(-1,g.v),(1,g.z)],0⟩,
   ⟨[(-1,g.x),(1,g.v),(1,g.z)],0⟩,
   ⟨[(-1,g.x),(-1,g.v),(-1,g.z)],-2⟩]

theorem clause_gate_normalize (v : Nat) (g : Emit.Gate)
    (hx : 0 < g.x) (hy : 0 < g.v) (hz : 0 < g.z) :
    (Emit.gateClauses g).map (fromClause v)=(gateConstraints g).map (fromConstraint v) := by
  have hxi : (0 : Int) < g.x := by omega
  have hyi : (0 : Int) < g.v := by omega
  have hzi : (0 : Int) < g.z := by omega
  simp [Emit.gateClauses,gateConstraints,fromClause,fromConstraint,hx,hy,hz,not_lt_of_ge (le_of_lt hxi),not_lt_of_ge (le_of_lt hyi),not_lt_of_ge (le_of_lt hzi)]

theorem gate_constraints_rename {v : Nat} (σ : Fin 6 → Fin v) :
    (gateConstraints ⟨1,2,3⟩).map (renameConstraint σ)=gateConstraints (liftedGate σ) := by
  simp [gateConstraints,renameConstraint,renVar,liftedGate]

theorem gate_source_lift {v : Nat} (σ : Fin 6 → Fin v) (hinj : Function.Injective σ)
    (hpos : ∀ i, 0 < i.val → 0 < (σ i).val) :
    localDB.map (liftPB σ)=(Emit.gateClauses (liftedGate σ)).map (fromClause v) := by
  rw [clause_gate_normalize v _ (hpos 1 (by decide)) (hpos 2 (by decide)) (hpos 3 (by decide))]
  rw [← gate_constraints_rename σ]
  have hlocal : localDB=(gateConstraints ⟨1,2,3⟩).map (fromConstraint 6) :=
    clause_gate_normalize 6 _ (by decide) (by decide) (by decide)
  rw [hlocal]
  simp only [List.map_map,Function.comp_def]
  apply List.map_congr_left
  intro c hc
  symm
  apply fromConstraint_rename σ hinj c
  simp only [gateConstraints,List.mem_cons,List.not_mem_nil,or_false] at hc
  rcases hc with rfl | rfl | rfl | rfl <;> simp

theorem member_lookup {v : Nat} (db : List (PB v)) (c : PB v) (hc : c∈db) :
    ∃ i, lookup db i=some c := by
  obtain ⟨i,hi⟩ := List.mem_iff_getElem?.mp hc
  exact ⟨i+1,by simpa [lookup] using hi⟩
noncomputable def findRef {v : Nat} (db : List (PB v)) (c : PB v) : Nat :=
  if h : c∈db then Classical.choose (member_lookup db c h) else 0
theorem lookup_findRef {v : Nat} (db : List (PB v)) (c : PB v) (hc : c∈db) :
    lookup db (findRef db c)=some c := by
  simp only [findRef,dif_pos hc]
  exact Classical.choose_spec (member_lookup db c hc)
noncomputable def gateRef {v : Nat} (σ : Fin 6 → Fin v) (db : List (PB v)) (i : Nat) : Nat :=
  if 4 < i then db.length+(i-4) else
  match lookup localDB i with
  | none => 0
  | some c => findRef db (liftPB σ c)

theorem gateRef_rel {v : Nat} (σ : Fin 6 → Fin v) (db : List (PB v))
    (hmem : ∀ c∈localDB, liftPB σ c∈db) : DBRel σ (gateRef σ db) localDB db := by
  intro i c hc
  have hi := (lookup_bound localDB i c hc).2
  have h4 : localDB.length=4 := rfl
  have hn : ¬ 4 < i := by omega
  simp only [gateRef,if_neg hn,hc]
  exact lookup_findRef db _ (hmem c (lookup_mem localDB i c hc))

theorem gate_accepted_embedding {v : Nat} (σ : Fin 6 → Fin v) (hinj : Function.Injective σ)
    (hpos : ∀ i, 0 < i.val → 0 < (σ i).val) (db : List (PB v))
    (hclauses : ∀ c∈Emit.gateClauses (liftedGate σ), fromClause v c∈db)
    (hfresh : ∀ c∈db, c.coeff (σ 4)=0 ∧ c.coeff (σ 5)=0) :
    ∃ added, added.length=23 ∧
      run db (Emit.gateBlock (liftedGate σ) (σ 4).val (σ 5).val db.length)=some (db++added) ∧
      lookup (db++added) (db.length+22)=some (gatePB v (liftedGate σ) (σ 4).val) ∧
      lookup (db++added) (db.length+23)=some (neg (gatePB v (liftedGate σ) (σ 4).val)) ∧
      ∀ c∈added, ∃ d : PB 6, c=liftPB σ d := by
  refine gate_run_lift σ hinj hpos (gateRef σ db) db ?_ hfresh ?_
  · apply gateRef_rel
    intro c hc
    have hm : liftPB σ c∈localDB.map (liftPB σ) := List.mem_map.mpr ⟨c,hc,rfl⟩
    rw [gate_source_lift σ hinj hpos] at hm
    obtain ⟨d,hd,he⟩ := List.mem_map.mp hm
    rw [← he]
    exact hclauses d hd
  · intro i hi; simp [gateRef,hi]

#print axioms gate_accepted_embedding
end OP03.Kernel

import PBRename
set_option maxHeartbeats 0
namespace OP03.Kernel

def derive {v : Nat} (db : List (PB v)) : Emit.Command → Option (PB v)
  | .pol e => eval db e
  | .rup c => if wellFormed v c && rup db (fromConstraint v c) then some (fromConstraint v c) else none
  | .red c j b =>
    if h : 0 < j ∧ j < v then
      if wellFormed v c && red db (fromConstraint v c) ⟨j,h.2⟩ b then some (fromConstraint v c) else none
    else none

theorem step_derive {v : Nat} (db : List (PB v)) (cmd : Emit.Command) :
    step db cmd=(derive db cmd).map (fun c => db++[c]) := by
  cases cmd with
  | pol e => simp only [step, derive]; cases eval db e <;> rfl
  | rup c => simp only [step, derive]; split <;> rfl
  | red c j b => simp only [step, derive]; split <;> simp_all <;> split <;> rfl

def RedIn (cmd : Emit.Command) (targets : List Nat) : Prop :=
  match cmd with
  | .red _ j _ => j∈targets
  | _ => True
def Frame {u v : Nat} (σ : Fin u → Fin v) (targets : List Nat)
    (small : List (PB u)) (big : List (PB v)) : Prop :=
  ∀ d∈big, (∃ e∈small, d=liftPB σ e) ∨ (∀ i : Fin u, i.val∈targets → d.coeff (σ i)=0)

theorem wellFormed_bounds {u : Nat} (c : Emit.Constraint) (h : wellFormed u c=true) :
    ∀ p∈c.terms, p.2<u := by
  intro p hp
  have hh : 0 < p.2 ∧ p.2 < u := of_decide_eq_true (List.all_eq_true.mp h p hp)
  exact hh.2

theorem derive_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (hpos : ∀ i, 0 < i.val → 0 < (σ i).val) (ρ : Nat → Nat) (targets : List Nat)
    (small : List (PB u)) (big : List (PB v)) (hrel : DBRel σ ρ small big)
    (hframe : Frame σ targets small big) (cmd : Emit.Command) (ht : RedIn cmd targets)
    (c : PB u) (hc : derive small cmd=some c) :
    derive big (renameCommand σ ρ cmd)=some (liftPB σ c) := by
  have hmem := dbrel_mem σ ρ small big hrel
  cases cmd with
  | pol e => exact eval_rename σ hinj hpos ρ small big hrel e c hc
  | rup d =>
    simp only [derive] at hc
    split at hc
    · rename_i hh
      have hpair : wellFormed u d=true ∧ rup small (fromConstraint u d)=true := by simpa only [Bool.and_eq_true] using hh
      cases hc
      have hnorm := fromConstraint_rename σ hinj d (wellFormed_bounds d hpair.1)
      have hwr := wellFormed_rename σ hpos d hpair.1
      have hr := rup_mono (small.map (liftPB σ)) big (by
        intro e he
        obtain ⟨e,hem,rfl⟩ := List.mem_map.mp he
        exact hmem e hem) (liftPB σ (fromConstraint u d))
          (rup_lift σ hinj small _ hpair.2)
      simp [renameCommand,derive,hnorm,hwr,hr]
    · contradiction
  | red d j b =>
    simp only [derive] at hc
    split at hc
    · rename_i hj
      split at hc
      · rename_i hh
        have hpair : wellFormed u d=true ∧ red small (fromConstraint u d) ⟨j,hj.2⟩ b=true := by
          simpa only [Bool.and_eq_true] using hh
        cases hc
        have hnorm := fromConstraint_rename σ hinj d (wellFormed_bounds d hpair.1)
        have hwr := wellFormed_rename σ hpos d hpair.1
        have hf : ∀ e∈big, (∃ f∈small, e=liftPB σ f) ∨ e.coeff (σ ⟨j,hj.2⟩)=0 := by
          intro e he
          rcases hframe e he with h | h
          · exact Or.inl h
          · exact Or.inr (h ⟨j,hj.2⟩ ht)
        have hr := red_lift σ hinj small big hmem (fromConstraint u d) ⟨j,hj.2⟩ b hpair.2 hf
        have hvar : renVar σ j=(σ ⟨j,hj.2⟩).val := renVar_fin σ ⟨j,hj.2⟩
        have hp := hpos ⟨j,hj.2⟩ hj.1
        have hv := (σ ⟨j,hj.2⟩).isLt
        simp [renameCommand,derive,hvar,hp,hv,hnorm,hwr,hr]
      · contradiction
    · contradiction

theorem lookup_bound {v : Nat} (db : List (PB v)) (i : Nat) (c : PB v)
    (h : lookup db i=some c) : 0 < i ∧ i≤db.length := by
  unfold lookup at h
  split at h
  · contradiction
  · rename_i hi
    constructor
    · omega
    · by_contra hh
      have he : db[i-1]?=none := List.getElem?_eq_none_iff.mpr (by omega)
      rw [he] at h; contradiction

theorem dbrel_append {u v : Nat} (σ : Fin u → Fin v) (ρ : Nat → Nat)
    (small : List (PB u)) (big : List (PB v)) (hrel : DBRel σ ρ small big)
    (c : PB u) (hρ : ρ (small.length+1)=big.length+1) :
    DBRel σ ρ (small++[c]) (big++[liftPB σ c]) := by
  intro i d hd
  by_cases hi : i≤small.length
  · rw [lookup_append small [c] i hi] at hd
    have hbig := hrel i d hd
    rw [lookup_append big [liftPB σ c] (ρ i) (lookup_bound big (ρ i) _ hbig).2]
    exact hbig
  · have hb := lookup_bound (small++[c]) i d hd
    have he : i=small.length+1 := by simp only [List.length_append,List.length_singleton] at hb; omega
    subst i
    rw [lookup_last] at hd
    cases hd
    rw [hρ,lookup_last]

theorem frame_append {u v : Nat} (σ : Fin u → Fin v) (targets : List Nat)
    (small : List (PB u)) (big : List (PB v)) (hframe : Frame σ targets small big) (c : PB u) :
    Frame σ targets (small++[c]) (big++[liftPB σ c]) := by
  intro d hd
  rcases List.mem_append.mp hd with hd | hd
  · rcases hframe d hd with ⟨e,he,hde⟩ | h
    · exact Or.inl ⟨e,List.mem_append_left _ he,hde⟩
    · exact Or.inr h
  · simp only [List.mem_singleton] at hd
    exact Or.inl ⟨c,by simp,hd⟩

theorem run_lift {u v : Nat} (σ : Fin u → Fin v) (hinj : Function.Injective σ)
    (hpos : ∀ i, 0 < i.val → 0 < (σ i).val) (ρ : Nat → Nat) (targets : List Nat)
    (cmds : List Emit.Command) (ht : ∀ cmd∈cmds, RedIn cmd targets)
    (small : List (PB u)) (big : List (PB v)) (hrel : DBRel σ ρ small big)
    (hframe : Frame σ targets small big)
    (hρ : ∀ k, ρ (small.length+k+1)=big.length+k+1)
    (out : List (PB u)) (h : run small cmds=some out) :
    ∃ added, out=small++added ∧
      run big (cmds.map (renameCommand σ ρ))=some (big++added.map (liftPB σ)) ∧
      DBRel σ ρ out (big++added.map (liftPB σ)) ∧
      Frame σ targets out (big++added.map (liftPB σ)) := by
  induction cmds generalizing small big with
  | nil =>
    simp only [run,Option.some.injEq] at h
    subst out
    exact ⟨[],by simp,by simp [run],by simpa using hrel,by simpa using hframe⟩
  | cons cmd cmds ih =>
    cases hc : derive small cmd with
    | none => simp [run,step_derive,hc] at h
    | some c =>
      have hstep : step small cmd=some (small++[c]) := by simp [step_derive,hc]
      have hbig : step big (renameCommand σ ρ cmd)=some (big++[liftPB σ c]) := by
        simp [step_derive,derive_lift σ hinj hpos ρ targets small big hrel hframe cmd (ht cmd (by simp)) c hc]
      have hrun : run (small++[c]) cmds=some out := by simpa [run,hstep] using h
      have hnext : ∀ k, ρ ((small++[c]).length+k+1)=(big++[liftPB σ c]).length+k+1 := by
        intro k
        simpa [List.length_append,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hρ (k+1)
      obtain ⟨added,hout,haccepted,hrel',hframe'⟩ := ih (by intro cmd hc; exact ht cmd (by simp [hc]))
        (small++[c]) (big++[liftPB σ c])
        (dbrel_append σ ρ small big hrel c (by simpa using hρ 0))
        (frame_append σ targets small big hframe c) hnext hrun
      refine ⟨c::added,?_,?_,?_,?_⟩
      · simpa [List.append_assoc] using hout
      · simpa [run,hbig,List.append_assoc] using haccepted
      · simpa [List.append_assoc] using hrel'
      · simpa [List.append_assoc] using hframe'

#print axioms derive_lift
#print axioms run_lift
end OP03.Kernel

import GateRules
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace OP03.Local
structure PB where
  coeff : List Int
  rhs : Int
  deriving DecidableEq, Repr
abbrev Partial := Nat → Option Bool

def maximum (c : PB) (p : Partial) : Int :=
  (c.coeff.zipIdx.map fun (a,i) => match p i with
    | some false => 0
    | some true => a
    | none => max 0 a).sum

def conflict (db : List PB) (p : Partial) : Bool := db.any fun c => decide (maximum c p < c.rhs)

def force (db : List PB) (p : Partial) (v : Nat) : Partial :=
  if (p v).isSome then p
  else if conflict db (Function.update p v (some false)) then Function.update p v (some true)
  else if conflict db (Function.update p v (some true)) then Function.update p v (some false)
  else p

def up : Nat → List PB → Partial → Bool
  | 0, db, p => conflict db p
  | k+1, db, p => if conflict db p then true else up k db ((List.range 5).foldl (force db) p)

-- Coordinates: the three gate inputs a,b,z, then fresh carry t and parity u.
def base : List PB := [
  ⟨[1,1,-1,0,0],0⟩,
  ⟨[1,-1,1,0,0],0⟩,
  ⟨[-1,1,1,0,0],0⟩,
  ⟨[-1,-1,-1,0,0],-2⟩,
  ⟨[1,1,1,-2,-1],0⟩,
  ⟨[-1,-1,-1,2,1],0⟩]

def clause (bits : List Bool) : PB :=
  ⟨(List.range 5).map (fun i => if i < bits.length then
      if bits[i]! then -1 else 1 else if i = 4 then -1 else 0),
    -(bits.map fun b => if b then (1 : Int) else 0).sum⟩

def negated (bits : List Bool) : Partial := fun i =>
  if i < bits.length then some bits[i]! else if i = 4 then some true else none

def prefixes : List (List Bool) :=
  [[false,false,false],[false,false,true],[false,true,false],[false,true,true],
   [true,false,false],[true,false,true],[true,true,false],[true,true,true],
   [false,false],[false,true],[true,false],[true,true],[false],[true],[]]

def checkTrace : List PB → List (List Bool) → Bool
  | _, [] => true
  | db, bits::rest => up 6 db (negated bits) && checkTrace (db ++ [clause bits]) rest

theorem all_fifteen_rup_steps_checked : checkTrace base prefixes = true := by decide

theorem prefix_count : prefixes.length = 15 := by decide

theorem last_clause_is_not_u : clause [] = ⟨[0,0,0,0,-1],0⟩ := by decide

#print axioms all_fifteen_rup_steps_checked
end OP03.Local

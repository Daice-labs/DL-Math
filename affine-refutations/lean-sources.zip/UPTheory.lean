import PBTraceSound
set_option maxHeartbeats 0
namespace OP03.Kernel
open scoped BigOperators

def Extends {v : Nat} (p q : Partial v) : Prop := ∀ j b, p j=some b → q j=some b
theorem extends_refl {v : Nat} (p : Partial v) : Extends p p := by intro j b h; exact h
theorem extends_trans {v : Nat} {p q r : Partial v} (h : Extends p q) (g : Extends q r) : Extends p r :=
  fun j b hb => g j b (h j b hb)
theorem extends_none {v : Nat} (q : Partial v) : Extends (fun _ => none) q := by intro j b h; contradiction
theorem extends_antisymm {v : Nat} {p q : Partial v} (h : Extends p q) (g : Extends q p) : p=q := by
  funext j
  cases hp : p j with
  | some b => exact (h j b hp).symm
  | none =>
    cases hq : q j with
    | none => rfl
    | some b => have hh := g j b hq; rw [hp] at hh; contradiction

theorem extends_update_none {v : Nat} (p : Partial v) (j : Fin v) (b : Bool) (hj : p j=none) :
    Extends p (Function.update p j (some b)) := by
  intro i c hc
  by_cases he : i=j
  · subst i; rw [hj] at hc; contradiction
  · simp [Function.update_of_ne he,hc]

theorem force_extends {v : Nat} (db : List (PB v)) (p : Partial v) (j : Fin v) : Extends p (force db p j) := by
  unfold force
  simp only [freeze_eq]
  split
  · exact extends_refl p
  · rename_i hn
    have hj : p j=none := by cases h : p j <;> simp_all
    split
    · exact extends_update_none p j true hj
    · split
      · exact extends_update_none p j false hj
      · exact extends_refl p

theorem fold_extends {v : Nat} (js : List (Fin v)) (db : List (PB v)) (p : Partial v) :
    Extends p (js.foldl (force db) p) := by
  induction js generalizing p with
  | nil => exact extends_refl p
  | cons j js ih => exact extends_trans (force_extends db p j) (ih _)

theorem maximum_antitone {v : Nat} (c : PB v) (p q : Partial v) (h : Extends p q) : maximum c q≤maximum c p := by
  apply Finset.sum_le_sum
  intro j _
  cases hp : p j with
  | none => cases hq : q j with
    | none => rfl
    | some b => cases b <;> simp [hp,hq]
  | some b => have hq := h j b hp; simp [hp,hq]

theorem conflict_mono {v : Nat} (small big : List (PB v)) (hdb : ∀ c∈small, c∈big)
    (p q : Partial v) (h : Extends p q) (hc : conflict small p=true) : conflict big q=true := by
  obtain ⟨c,hc,hh⟩ := List.any_eq_true.mp hc
  apply List.any_eq_true.mpr
  refine ⟨c,hdb c hc,?_⟩
  apply decide_eq_true
  have hh' : maximum c p<c.rhs := of_decide_eq_true hh
  exact lt_of_le_of_lt (maximum_antitone c p q h) hh'

def Closed {v : Nat} (db : List (PB v)) (p : Partial v) : Prop :=
  conflict db p=false ∧ ∀ j, p j=none →
    conflict db (Function.update p j (some false))=false ∧
    conflict db (Function.update p j (some true))=false

theorem extends_updates {v : Nat} (p q : Partial v) (h : Extends p q) (j : Fin v) (b : Bool) :
    Extends (Function.update p j (some b)) (Function.update q j (some b)) := by
  intro i c hc
  by_cases he : i=j
  · subst i; simpa using hc
  · rw [Function.update_of_ne he] at hc ⊢; exact h i c hc

theorem extends_update_to {v : Nat} (p q : Partial v) (h : Extends p q) (j : Fin v) (b : Bool)
    (hj : q j=some b) : Extends (Function.update p j (some b)) q := by
  intro i c hc
  by_cases he : i=j
  · subst i; simp only [Function.update_self,Option.some.injEq] at hc; simpa [hc] using hj
  · rw [Function.update_of_ne he] at hc; exact h i c hc

theorem conflict_force_value {v : Nat} (small big : List (PB v)) (hdb : ∀ c∈small, c∈big)
    (p q : Partial v) (hpq : Extends p q) (hq : Closed big q) (j : Fin v) (b : Bool)
    (hc : conflict small (Function.update p j (some b))=true) : q j=some (!b) := by
  cases hqj : q j with
  | none =>
    have hh := conflict_mono small big hdb _ _ (extends_updates p q hpq j b) hc
    have hclosed := hq.2 j hqj
    cases b <;> simp_all
  | some c =>
    by_cases he : c=b
    · subst c
      have hh := conflict_mono small big hdb _ q (extends_update_to p q hpq j b hqj) hc
      rw [hq.1] at hh; contradiction
    · cases b <;> cases c <;> simp_all

theorem force_below_closed {v : Nat} (small big : List (PB v)) (hdb : ∀ c∈small, c∈big)
    (p q : Partial v) (hpq : Extends p q) (hq : Closed big q) (j : Fin v) :
    Extends (force small p j) q := by
  unfold force
  simp only [freeze_eq]
  split
  · exact hpq
  · split
    · rename_i hc
      exact extends_update_to p q hpq j true (conflict_force_value small big hdb p q hpq hq j false hc)
    · split
      · rename_i hc
        exact extends_update_to p q hpq j false (conflict_force_value small big hdb p q hpq hq j true hc)
      · exact hpq

theorem fold_below_closed {v : Nat} (js : List (Fin v)) (small big : List (PB v)) (hdb : ∀ c∈small, c∈big)
    (p q : Partial v) (hpq : Extends p q) (hq : Closed big q) : Extends (js.foldl (force small) p) q := by
  induction js generalizing p with
  | nil => exact hpq
  | cons j js ih => exact ih _ (force_below_closed small big hdb p q hpq hq j)

theorem up_below_closed {v : Nat} (fuel : Nat) (small big : List (PB v)) (hdb : ∀ c∈small, c∈big)
    (p q : Partial v) (hpq : Extends p q) (hq : Closed big q) : up fuel small p=false := by
  have hc : conflict small p=false := by
    cases hh : conflict small p
    · rfl
    · have hb := conflict_mono small big hdb p q hpq hh; rw [hq.1] at hb; contradiction
  induction fuel generalizing p with
  | zero => exact hc
  | succ k ih =>
    simp only [up,hc,Bool.false_eq_true,if_false]
    apply ih _ (fold_below_closed _ small big hdb p q hpq hq)
    cases hh : conflict small ((List.ofFn fun j : Fin v => j).foldl (force small) p)
    · rfl
    · have hb := conflict_mono small big hdb _ q (fold_below_closed _ small big hdb p q hpq hq) hh
      rw [hq.1] at hb; contradiction

def assigned {v : Nat} (p : Partial v) : Finset (Fin v) := Finset.univ.filter fun j => (p j).isSome
def count {v : Nat} (p : Partial v) := (assigned p).card
theorem count_le {v : Nat} (p : Partial v) : count p≤v := by
  exact le_trans (Finset.card_filter_le ..) (by simp)

theorem assigned_subset {v : Nat} (p q : Partial v) (h : Extends p q) : assigned p⊆assigned q := by
  intro j hj
  simp only [assigned,Finset.mem_filter,Finset.mem_univ,true_and] at hj ⊢
  cases hp : p j with
  | none => simp [hp] at hj
  | some b => simp [h j b hp]

theorem eq_of_count {v : Nat} (p q : Partial v) (h : Extends p q) (hc : count q≤count p) : p=q := by
  have he : assigned p=assigned q := Finset.eq_of_subset_of_card_le (assigned_subset p q h) hc
  apply extends_antisymm h
  intro j b hj
  have hmem : j∈assigned p := by rw [he]; simp [assigned,hj]
  cases hp : p j with
  | none => simp [assigned,hp] at hmem
  | some a => have hh := h j a hp; rw [hj] at hh; cases hh; rfl

theorem fold_fixed {v : Nat} (js : List (Fin v)) (db : List (PB v)) (p : Partial v)
    (h : js.foldl (force db) p=p) : ∀ j∈js, force db p j=p := by
  induction js generalizing p with
  | nil => simp
  | cons j js ih =>
    have he : force db p j=p := by
      apply extends_antisymm
      · have hh := fold_extends js db (force db p j)
        have hfold : js.foldl (force db) (force db p j)=p := h
        rw [hfold] at hh
        exact hh
      · exact force_extends db p j
    intro i hi
    rcases List.mem_cons.mp hi with rfl | hi
    · exact he
    · apply ih p ?_ i hi
      simpa [he] using h

theorem closed_of_fixed {v : Nat} (db : List (PB v)) (p : Partial v)
    (hc : conflict db p=false) (hf : (List.ofFn fun j : Fin v => j).foldl (force db) p=p) : Closed db p := by
  refine ⟨hc,?_⟩
  intro j hj
  have he := fold_fixed _ db p hf j (by simp)
  have hh := congrFun he j
  simp only [force,hj,Option.isSome_none,Bool.false_eq_true,if_false,freeze_eq] at hh
  cases h0 : conflict db (Function.update p j (some false)) <;>
    cases h1 : conflict db (Function.update p j (some true)) <;> simp_all

theorem up_false_closed {v : Nat} (fuel : Nat) (db : List (PB v)) (p : Partial v)
    (hsize : v<count p+fuel) (hu : up fuel db p=false) : ∃ q, Extends p q ∧ Closed db q := by
  induction fuel generalizing p with
  | zero => have hh := count_le p; omega
  | succ k ih =>
    have hc : conflict db p=false := by cases hh : conflict db p <;> simp_all [up]
    have hn : up k db ((List.ofFn fun j : Fin v => j).foldl (force db) p)=false := by
      simpa [up,hc] using hu
    by_cases hf : (List.ofFn fun j : Fin v => j).foldl (force db) p=p
    · exact ⟨p,extends_refl p,closed_of_fixed db p hc hf⟩
    · have he := fold_extends (List.ofFn fun j : Fin v => j) db p
      have hlt : count p < count ((List.ofFn fun j : Fin v => j).foldl (force db) p) := by
        by_contra hh
        have heq := eq_of_count p _ he (by omega)
        exact hf heq.symm
      obtain ⟨q,hq,hclosed⟩ := ih _ (by omega) hn
      exact ⟨q,extends_trans he hq,hclosed⟩

theorem rup_mono {v : Nat} (small big : List (PB v)) (hdb : ∀ c∈small, c∈big)
    (c : PB v) (h : rup small c=true) : rup big c=true := by
  cases hh : rup big c
  · obtain ⟨q,hq,hclosed⟩ := up_false_closed (v+1) (big++[negate c]) (fun _ => none) (by omega) hh
    have hsub : ∀ d∈small++[negate c], d∈big++[negate c] := by
      intro d hd
      rcases List.mem_append.mp hd with hd | hd
      · exact List.mem_append_left _ (hdb d hd)
      · exact List.mem_append_right _ hd
    have hz := up_below_closed (v+1) _ _ hsub (fun _ => none) q hq hclosed
    change up (v+1) (small++[negate c]) (fun _ => none)=true at h
    rw [hz] at h; contradiction
  · rfl

#print axioms rup_mono
end OP03.Kernel

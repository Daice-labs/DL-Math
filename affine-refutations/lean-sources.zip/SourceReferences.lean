import References
set_option maxHeartbeats 0
namespace OP03.Emit

def rawCount (rs : List RawRow) : Nat := (rs.map fun r => r.clauses.length).sum

theorem annotate_clause_count (rs : List RawRow) (k : Nat) :
    ((annotate rs k).flatMap Row.clauses).length = rawCount rs := by
  induction rs generalizing k with
  | nil => rfl
  | cons r rs ih => simp [annotate, rawCount, ih]

theorem annotate_bounds (rs : List RawRow) (k : Nat) (r : Row) (hr : r∈annotate rs k) :
    r.clauses.length ≤ r.terminal ∧ r.terminal ≤ k+rawCount rs := by
  induction rs generalizing k with
  | nil => simp [annotate] at hr
  | cons a rs ih =>
    simp only [annotate, List.mem_cons] at hr
    rcases hr with rfl | hr
    · simp [rawCount]
    · have h := ih (k+a.clauses.length) hr
      simp only [rawCount, List.map_cons, List.sum_cons] at *
      omega

def RowGood (r : Row) : Prop := r.clauses = rowClauses r.vars r.base r.rhs

theorem annotate_good (rs : List RawRow) (k : Nat)
    (h : ∀ r∈rs, r.clauses=rowClauses r.vars r.base r.rhs) :
    ∀ r∈annotate rs k, RowGood r := by
  induction rs generalizing k with
  | nil => simp [annotate]
  | cons a rs ih =>
    intro r hr
    simp only [annotate, List.mem_cons] at hr
    rcases hr with rfl | hr
    · exact h a (by simp)
    · exact ih _ (fun r hr => h r (by simp [hr])) r hr

theorem rows_good {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) :
    ∀ r∈rows A a b y, RowGood r := by
  apply annotate_good
  intro r hr
  simp only [rawRows, List.mem_ofFn] at hr
  obtain ⟨i,rfl⟩ := hr
  rfl

theorem terminal_bound {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (r : Row) (hr : r∈rows A a b y) :
    r.clauses.length ≤ r.terminal ∧ r.terminal ≤ ((rows A a b y).flatMap Row.clauses).length := by
  have h := annotate_bounds (rawRows A a b y) 0 r hr
  simpa only [rows, annotate_clause_count, Nat.zero_add] using h

theorem payment_safe (r : Row) (k : Nat) (hg : RowGood r)
    (hlo : r.clauses.length≤r.terminal) (hhi : r.terminal≤k) :
    ∀ p∈payment r, ExprSafe k p.1 ∧ ExprSafe k p.2 := by
  unfold payment
  split
  · simp
  · rename_i z hz
    have hcs : 1 ≤ r.clauses.length := by
      rw [hg]
      simp [rowClauses,hz]
    have ht : 0 < r.terminal := by omega
    by_cases hw : r.vars.length = 1 <;> cases hr : r.rhs <;>
      simp [hw,hr,ExprSafe,exprRefs,ht,hhi]

theorem annotate_decompose (rs : List RawRow) (k : Nat) (r : Row) (hr : r∈annotate rs k) :
    ∃ before after : List (List Int),
      ((annotate rs k).flatMap Row.clauses) = before ++ r.clauses ++ after ∧
      r.terminal = k+before.length+r.clauses.length := by
  induction rs generalizing k with
  | nil => simp [annotate] at hr
  | cons a rs ih =>
    simp only [annotate,List.mem_cons] at hr
    rcases hr with rfl | hr
    · refine ⟨[],(annotate rs (k+a.clauses.length)).flatMap Row.clauses,?_,?_⟩ <;> simp [annotate]
    · obtain ⟨before,after,hcs,hid⟩ := ih (k+a.clauses.length) hr
      refine ⟨a.clauses++before,after,?_,?_⟩
      · simp only [annotate,List.flatMap_cons]
        rw [hcs]
        simp [List.append_assoc]
      · simp only [List.length_append]
        omega

theorem terminal_is_source_unit {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (r : Row) (hr : r∈rows A a b y) (z : Nat) (hz : lastVar r.vars r.base = some z) :
    ∃ before after : List (List Int),
      ((rows A a b y).flatMap Row.clauses) =
        before ++ [[if r.rhs then (z : Int) else -(z : Int)]] ++ after ∧
      r.terminal = before.length+1 := by
  obtain ⟨before,after,hcs,hid⟩ := annotate_decompose (rawRows A a b y) 0 r hr
  have hrow : r.clauses = (gates r.vars r.base).flatMap gateClauses ++ [[if r.rhs then (z : Int) else -(z : Int)]] := by
    rw [rows_good A a b y r hr]
    simp [rowClauses,hz]
  refine ⟨before++(gates r.vars r.base).flatMap gateClauses,after,?_,?_⟩
  · change (annotate (rawRows A a b y) 0).flatMap Row.clauses = _
    rw [hcs,hrow]
    simp [List.append_assoc]
  · rw [hrow] at hid
    simpa [List.length_append,Nat.add_assoc] using hid

#print axioms terminal_is_source_unit

#print axioms terminal_bound
#print axioms payment_safe
end OP03.Emit

import Telescope
import Composition
set_option maxHeartbeats 0
namespace OP03.Emit
open scoped BigOperators

theorem sum_filter_values {n : Nat} (row : Fin n → Bool) (v : Fin n → F) (is : List (Fin n)) :
    ((is.filter row).map v).sum = (is.map fun j => bitF (row j)*v j).sum := by
  induction is with
  | nil => rfl
  | cons j js ih => cases h : row j <;> simp [h,bitF,ih]

theorem row_variables_sum {n : Nat} (row : Fin n → Bool) (v : Nat → F) :
    ((rowVars row).map v).sum = ∑ j, bitF (row j)*v (j.val+1) := by
  simp only [rowVars, List.map_map]
  rw [sum_filter_values]
  simp [List.map_ofFn, List.sum_ofFn]

theorem emitted_coefficient_parity {m n : Nat} (A : Fin m → Fin n → Bool)
    (a b y : Fin m → Bool) (h : Witness A a b y) (v : Nat → F) :
    (∑ i, bitF (y i) * rowValue (rowVars (A i)) (n+i.val*n) v) = 0 := by
  simp_rw [row_telescope, row_variables_sum, Finset.mul_sum, ← mul_assoc]
  rw [Finset.sum_comm]
  simp_rw [← Finset.sum_mul, h.1, zero_mul]
  simp

-- Signed singleton/multi-input row payments have the same value modulo two.
theorem negate_eq_self (x : F) : -x=x := by fin_cases x <;> rfl

def rowDegree {n : Nat} (row : Fin n → Bool) (rhs : Bool) : Int :=
  if (rowVars row).length=1 then ibit rhs else -ibit rhs

theorem ibit_cast (b : Bool) : (ibit b : F) = bitF b := by cases b <;> rfl

theorem row_degree_mod_two {n : Nat} (row : Fin n → Bool) (rhs : Bool) :
    (rowDegree row rhs : F) = bitF rhs := by
  unfold rowDegree
  split <;> simp [ibit_cast, negate_eq_self]

theorem emitted_degree_odd {m n : Nat} (A : Fin m → Fin n → Bool)
    (a b y : Fin m → Bool) (h : Witness A a b y) :
    (((∑ i, ibit (y i)*rowDegree (A i) (Bool.xor (a i) (b i))) : Int) : F) = 1 := by
  push_cast
  simpa only [ibit_cast,row_degree_mod_two,bitF_xor] using h.2

#print axioms emitted_coefficient_parity
#print axioms emitted_degree_odd
end OP03.Emit

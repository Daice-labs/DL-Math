import PBTraceSound
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
namespace OP03.Kernel

def localDB : List (PB 6) := (Emit.gateClauses ⟨1,2,3⟩).map (fromClause 6)
def localCommands := Emit.gateBlock ⟨1,2,3⟩ 4 5 4

theorem local_trace_accepted : (run localDB localCommands).isSome=true := by decide +kernel

#print axioms local_trace_accepted
end OP03.Kernel

import Emitter
set_option maxHeartbeats 0
namespace OP03.Emit

theorem twice_zero (x : F) : x+x=0 := by fin_cases x <;> rfl

def gateValue (v : Nat → F) (g : Gate) := v g.x + v g.v + v g.z

theorem tail_telescope (xs : List Nat) (cur base : Nat) (v : Nat → F) :
    ((tailGates cur xs base).map (gateValue v)).sum + v (lastTail cur xs base) =
      v cur + (xs.map v).sum := by
  induction xs generalizing cur base with
  | nil => simp [tailGates, lastTail]
  | cons x xs ih =>
    simp only [tailGates, lastTail, List.map_cons, List.sum_cons, gateValue]
    calc
      (v cur+v x+v (base+1)) + ((tailGates (base+1) xs (base+1)).map (gateValue v)).sum + v (lastTail (base+1) xs (base+1))
          = v cur+v x+ (((tailGates (base+1) xs (base+1)).map (gateValue v)).sum + v (lastTail (base+1) xs (base+1)))+v (base+1) := by ring
      _ = v cur+v x+(v (base+1)+(xs.map v).sum)+v (base+1) := by rw [ih]
      _ = v cur+(v x+(xs.map v).sum) := by
        have hz := twice_zero (v (base+1))
        calc
          _ = v cur+(v x+(xs.map v).sum)+(v (base+1)+v (base+1)) := by ring
          _ = _ := by rw [hz]; simp

def rowValue (vs : List Nat) (base : Nat) (v : Nat → F) : F :=
  match vs with
  | [] => 0
  | x::xs => ((tailGates x xs base).map (gateValue v)).sum + v (lastTail x xs base)

theorem row_telescope (vs : List Nat) (base : Nat) (v : Nat → F) :
    rowValue vs base v = (vs.map v).sum := by
  cases vs with
  | nil => rfl
  | cons x xs => simpa [rowValue] using tail_telescope xs x base v

-- This applies to the exact recursive gates in the executable emitter, not
-- a different row-parity assumption. Minus and plus agree after reduction mod 2.
#print axioms tail_telescope
#print axioms row_telescope
end OP03.Emit

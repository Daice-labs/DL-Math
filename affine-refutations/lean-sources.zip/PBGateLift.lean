import PBStepLift
import LocalKernel
import PBAggregate
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
namespace OP03.Kernel

def localOut : List (PB 6) := (run localDB localCommands).getD []
theorem local_run : run localDB localCommands=some localOut := by
  have h := local_trace_accepted
  cases hr : run localDB localCommands with
  | none => simp [hr] at h
  | some out => simp [localOut,hr]
theorem local_out_facts : localOut.length=27 ∧
    lookup localOut 26=some (gatePB 6 ⟨1,2,3⟩ 4) ∧
    lookup localOut 27=some (neg (gatePB 6 ⟨1,2,3⟩ 4)) := by decide +kernel

def liftedGate {v : Nat} (σ : Fin 6 → Fin v) : Emit.Gate :=
  ⟨(σ 1).val,(σ 2).val,(σ 3).val⟩

theorem rename_gate_commands {v : Nat} (σ : Fin 6 → Fin v) (ρ : Nat → Nat)
    (k : Nat) (hρ : ∀ i, 4 < i → ρ i=k+(i-4)) :
    localCommands.map (renameCommand σ ρ)=
      Emit.gateBlock (liftedGate σ) (σ 4).val (σ 5).val k := by
  simp [localCommands,Emit.gateBlock,Local.prefixes,renameCommand,renameExpr,
    renameConstraint,renVar,liftedGate,hρ]

theorem gatePB_lift {v : Nat} (σ : Fin 6 → Fin v) (hinj : Function.Injective σ) :
    liftPB σ (gatePB 6 ⟨1,2,3⟩ 4)=gatePB v (liftedGate σ) (σ 4).val := by
  symm
  exact fromConstraint_rename σ hinj ⟨[(1,1),(1,2),(1,3),(-2,4)],0⟩ (by simp)

theorem lift_neg {u v : Nat} (σ : Fin u → Fin v) (c : PB u) :
    liftPB σ (neg c)=neg (liftPB σ c) := by
  apply pb_ext
  · intro j
    simp only [liftPB,neg]
    rw [← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro i _; split <;> simp_all
  · rfl

-- The first four IDs refer to the actual XOR clauses; all later IDs are
-- the actual append positions in the surrounding proof database.
theorem gate_run_lift {v : Nat} (σ : Fin 6 → Fin v) (hinj : Function.Injective σ)
    (hpos : ∀ i, 0 < i.val → 0 < (σ i).val) (ρ : Nat → Nat) (db : List (PB v))
    (hrel : DBRel σ ρ localDB db) (hfresh : ∀ c∈db, c.coeff (σ 4)=0 ∧ c.coeff (σ 5)=0)
    (hρ : ∀ i, 4 < i → ρ i=db.length+(i-4)) :
    ∃ added, added.length=23 ∧
      run db (Emit.gateBlock (liftedGate σ) (σ 4).val (σ 5).val db.length)=some (db++added) ∧
      lookup (db++added) (db.length+22)=some (gatePB v (liftedGate σ) (σ 4).val) ∧
      lookup (db++added) (db.length+23)=some (neg (gatePB v (liftedGate σ) (σ 4).val)) ∧
      ∀ c∈added, ∃ d : PB 6, c=liftPB σ d := by
  have ht : ∀ cmd∈localCommands, RedIn cmd [4,5] := by
    simp [localCommands,Emit.gateBlock,Local.prefixes,RedIn]
  have hframe : Frame σ [4,5] localDB db := by
    intro c hc
    apply Or.inr
    intro i hi
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hi
    rcases hi with hi | hi
    · have he : i=4 := Fin.ext hi
      rw [he]; exact (hfresh c hc).1
    · have he : i=5 := Fin.ext hi
      rw [he]; exact (hfresh c hc).2
  have hfuture : ∀ k, ρ (localDB.length+k+1)=db.length+k+1 := by
    intro k
    have h := hρ (4+k+1) (by omega)
    simpa [localDB,Emit.gateClauses,Nat.add_assoc] using h
  obtain ⟨added,hout,hr,hrel',_⟩ := run_lift σ hinj hpos ρ [4,5]
    localCommands ht localDB db hrel hframe hfuture localOut local_run
  have hlen : added.length=23 := by
    have h := congrArg List.length hout
    simp only [List.length_append] at h
    have h4 : localDB.length=4 := rfl
    rw [local_out_facts.1,h4] at h
    omega
  have hlo := hrel' 26 _ local_out_facts.2.1
  have hhi := hrel' 27 _ local_out_facts.2.2
  rw [hρ 26 (by omega),gatePB_lift σ hinj] at hlo
  rw [hρ 27 (by omega),lift_neg,gatePB_lift σ hinj] at hhi
  refine ⟨added.map (liftPB σ),by simpa using hlen,?_,hlo,hhi,?_⟩
  · rw [rename_gate_commands σ ρ db.length hρ] at hr
    exact hr
  · intro c hc
    obtain ⟨d,_,rfl⟩ := List.mem_map.mp hc
    exact ⟨d,rfl⟩

#print axioms gate_run_lift
end OP03.Kernel

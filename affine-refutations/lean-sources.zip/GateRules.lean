import Encoding
set_option maxHeartbeats 0
namespace OP03
open OP03Parity

def ibit (b : Bool) : ℤ := if b then 1 else 0

def P (a b z t : Bool) : Prop := 0 ≤ ibit a + ibit b + ibit z - 2*ibit t
def Q (a b z t : Bool) : Prop := -1 ≤ -(ibit a + ibit b + ibit z) + 2*ibit t
def R (a b z t u : Bool) : Prop := -2 ≤ ibit a + ibit b + ibit z - 2*ibit t - 3*ibit u
def S (a b z t u : Bool) : Prop := 0 ≤ -(ibit a + ibit b + ibit z) + 2*ibit t + 3*ibit u

-- Explicit RED witness repair checks, including preservation of earlier rows.
theorem red_p (a b z : Bool) : P a b z false := by
  simp only [P, ibit]
  cases a <;> cases b <;> cases z <;> decide

theorem red_q (a b z t : Bool) (hp : P a b z t) (hn : ¬ Q a b z t) :
    P a b z true ∧ Q a b z true := by
  simp only [P, Q, ibit] at *
  cases a <;> cases b <;> cases z <;> cases t <;> revert hp hn <;> decide

theorem red_r (a b z t : Bool) (hp : P a b z t) : R a b z t false := by
  simp only [P, R, ibit] at *
  cases a <;> cases b <;> cases z <;> cases t <;> revert hp <;> decide

theorem red_s (a b z t u : Bool) (hp : P a b z t) (hq : Q a b z t)
    (hr : R a b z t u) (hn : ¬ S a b z t u) : R a b z t true ∧ S a b z t true := by
  simp only [P, Q, R, S, ibit] at *
  cases a <;> cases b <;> cases z <;> cases t <;> cases u <;>
    revert hp hq hr hn <;> decide

-- These are exactly the two integer cutting-plane add/divide steps.
theorem pol_low (s t u : ℤ) (hp : 0 ≤ s-2*t) (hr : -2 ≤ s-2*t-3*u) :
    0 ≤ s-2*t-u := by omega

theorem pol_high (s t u : ℤ) (hq : -1 ≤ -s+2*t) (hs : 0 ≤ -s+2*t+3*u) :
    0 ≤ -s+2*t+u := by omega

-- Local propositional consequence underlying the eight initial RUP clauses.
theorem gate_forces_u_zero (a b z t u : Bool)
    (hg : gateCNF a b z)
    (hl : 0 ≤ ibit a+ibit b+ibit z-2*ibit t-ibit u)
    (hh : 0 ≤ -(ibit a+ibit b+ibit z)+2*ibit t+ibit u) : u = false := by
  unfold gateCNF ibit at *
  cases a <;> cases b <;> cases z <;> cases t <;> cases u <;> simp_all

-- Prefix-resolution step used seven times after the eight complete assignments.
theorem prefix_resolution (C x u : Bool)
    (h0 : C = true ∨ x = true ∨ u = false)
    (h1 : C = true ∨ x = false ∨ u = false) : C = true ∨ u = false := by
  cases x <;> simp_all

theorem eliminate_u (s t u : ℤ) (h0 : u = 0)
    (hl : 0 ≤ s-2*t-u) (hh : 0 ≤ -s+2*t+u) : s = 2*t := by omega

-- The final pair of exact-coefficient divisions rounds odd opposite degrees up.
theorem rounded_halves_contradict (v k : ℤ)
    (hl : k+1 ≤ v) (hh : -k ≤ -v) : False := by omega

#print axioms red_p
#print axioms red_q
#print axioms red_r
#print axioms red_s
#print axioms pol_low
#print axioms pol_high
#print axioms gate_forces_u_zero
#print axioms prefix_resolution
#print axioms eliminate_u
#print axioms rounded_halves_contradict
end OP03

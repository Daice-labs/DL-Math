import Emitter
import RUPSound
set_option maxHeartbeats 0
namespace OP03
open scoped BigOperators

def fromF (z : F) : Bool := decide (z = 1)

theorem bitF_fromF (z : F) : bitF (fromF z) = z := by
  fin_cases z <;> rfl

def Witness {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool) : Prop :=
  (∀ j, ∑ i, bitF (y i)*bitF (A i j) = 0) ∧
    ∑ i, bitF (y i)*(bitF (a i)+bitF (b i)) = 1

def Solves {m n : Nat} (A : Fin m → Fin n → Bool) (a b : Fin m → Bool) (x : Fin n → Bool) : Prop :=
  ∀ i, (∑ j, bitF (A i j)*bitF (x j)) = bitF (a i)+bitF (b i)

theorem witness_sound {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (h : Witness A a b y) : ¬ ∃ x, Solves A a b x := by
  rintro ⟨x,hx⟩
  exact Affine.separating_witness_unsat (fun i j => bitF (A i j))
    (fun i => bitF (a i)+bitF (b i)) (fun i => bitF (y i)) h.1 h.2 ⟨fun j => bitF (x j),hx⟩

theorem witness_exists_iff {m n : Nat} (A : Fin m → Fin n → Bool) (a b : Fin m → Bool) :
    (¬ ∃ x, Solves A a b x) ↔ ∃ y, Witness A a b y := by
  constructor
  · intro h
    have hh : ¬ ∃ x : Fin n → F, ∀ i, ∑ j, bitF (A i j)*x j = bitF (a i)+bitF (b i) := by
      rintro ⟨x,hx⟩
      apply h
      refine ⟨fun j => fromF (x j),?_⟩
      simpa [Solves, bitF_fromF] using hx
    obtain ⟨y,hy,hc⟩ := (separating_vector (fun i j => bitF (A i j))
      (fun i => bitF (a i)+bitF (b i))).mp hh
    refine ⟨fun i => fromF (y i),?_⟩
    simpa [Witness, bitF_fromF] using And.intro hy hc
  · rintro ⟨y,hy⟩
    exact witness_sound A a b y hy

-- A composed source-semantic theorem. Deliberately not named emit_accepted:
-- an UNSAT source theorem alone does not prove native proof-log acceptance.
theorem encoded_refutation {m n : Nat} (A : Fin m → Fin n → Bool) (a b y : Fin m → Bool)
    (h : Witness A a b y) : ¬ ∃ x aux, Enc A a b x aux := by
  rintro ⟨x,aux,ha⟩
  exact witness_sound A a b y h ⟨x,(encode_correct A a b x).mp ⟨aux,ha⟩⟩

theorem all_output_semantic_composition {m n : Nat} (A : Fin m → Fin n → Bool) (a b : Fin m → Bool)
    (h : ¬ ∃ x, Solves A a b x) :
    ∃ y, Witness A a b y ∧ (¬ ∃ x aux, Enc A a b x aux) ∧
      (Emit.generate A a b y).instructions.length ≤ 23*m*n+3 ∧
      (Emit.proofLines (Emit.generate A a b y)).length ≤ 23*m*n+8 := by
  obtain ⟨y,hy⟩ := (witness_exists_iff A a b).mp h
  exact ⟨y,hy,encoded_refutation A a b y hy,Emit.generate_size A a b y,
    Emit.generate_physical_lines A a b y⟩

#print axioms witness_exists_iff
#print axioms encoded_refutation
#print axioms all_output_semantic_composition
end OP03

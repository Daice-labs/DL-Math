import SourceReferences
import Composition
set_option maxHeartbeats 0
namespace OP03.Emit
open scoped BigOperators

theorem finish_refs (gs : List Gate) (v k : Nat) (p : List (Expr × Expr))
    (hne : gs ≠ [] ∨ p ≠ [])
    (hp : ∀ e∈p, ExprSafe k e.1 ∧ ExprSafe k e.2) :
    RefsSafe k (finish gs v k p) := by
  have side (offset : Nat) (ho : offset=22 ∨ offset=23) (f : (Expr × Expr) → Expr)
      (hf : ∀ e∈p, ExprSafe k (f e)) :
      ExprSafe (k+23*gs.length)
        (aggregate ((gs.zipIdx.map fun (_,i) => Expr.ref (k+23*i+offset)) ++ p.map f)) := by
    apply aggregate_safe
    · intro h
      have he : gs=[] ∧ p=[] := by simpa using h
      rcases hne with hn | hn
      · exact hn he.1
      · exact hn he.2
    · intro e he
      rcases List.mem_append.mp he with he | he
      · obtain ⟨⟨g,i⟩,hi,rfl⟩ := List.mem_map.mp he
        have hib : i < gs.length := by simpa using List.snd_lt_of_mem_zipIdx hi
        intro j hj
        simp only [exprRefs,List.mem_singleton] at hj
        subst j
        rcases ho with rfl | rfl <;> constructor <;> omega
      · obtain ⟨e,hep,rfl⟩ := List.mem_map.mp he
        exact exprSafe_mono (hf e hep) (by omega)
  have hl := side 22 (Or.inl rfl) Prod.fst (fun e he => (hp e he).1)
  have hh := side 23 (Or.inr rfl) Prod.snd (fun e he => (hp e he).2)
  unfold finish
  rw [refs_append,blocks_length]
  refine ⟨blocks_refs gs v k,?_,?_,?_,trivial⟩
  · exact hl
  · exact exprSafe_mono hh (by omega)
  · simp [commandRefs,exprRefs] <;> omega

theorem annotate_member (rs : List RawRow) (k : Nat) (r : RawRow) (hr : r∈rs) :
    ∃ s∈annotate rs k, s.vars=r.vars ∧ s.rhs=r.rhs ∧ s.selected=r.selected := by
  induction rs generalizing k with
  | nil => simp at hr
  | cons a rs ih =>
    rcases List.mem_cons.mp hr with rfl | hr
    · exact ⟨⟨r.vars,r.base,r.rhs,r.clauses,k+r.clauses.length,r.selected⟩,by simp [annotate],rfl,rfl,rfl⟩
    · obtain ⟨s,hs,hv,hrhs,hsel⟩ := ih (k+a.clauses.length) hr
      exact ⟨s,by simp [annotate,hs],hv,hrhs,hsel⟩

theorem selected_odd_row {m n : Nat} (A : Fin m → Fin n → Bool)
    (a b y : Fin m → Bool) (hw : Witness A a b y) :
    ∃ r∈rows A a b y, r.selected=true ∧ r.rhs=true := by
  have hex : ∃ i, y i=true ∧ Bool.xor (a i) (b i)=true := by
    by_contra h
    push_neg at h
    have hz : (∑ i, bitF (y i)*(bitF (a i)+bitF (b i)))=0 := by
      apply Finset.sum_eq_zero
      intro i _
      have hi := h i
      cases hy : y i <;> cases ha : a i <;> cases hb : b i <;>
        simp_all [bitF] <;> decide
    have hc := hw.2
    rw [hz] at hc
    exact zero_ne_one hc
  obtain ⟨i,hy,hrhs⟩ := hex
  obtain ⟨r,hr,hv,hrhs',hy'⟩ := annotate_member (rawRows A a b y) 0
    ((rawRows A a b y)[i.val]'(by simp [rawRows])) (by simp)
  refine ⟨r,hr,?_,?_⟩
  · simpa [rawRows,hy] using hy'
  · simpa [rawRows,hrhs] using hrhs'

theorem generate_refs {m n : Nat} (A : Fin m → Fin n → Bool)
    (a b y : Fin m → Bool) (hw : Witness A a b y) :
    RefsSafe (generate A a b y).clauses.length (generate A a b y).instructions := by
  unfold generate
  dsimp only
  split
  · trivial
  · rename_i hnone
    apply finish_refs
    · right
      obtain ⟨r,hr,hs,ho⟩ := selected_odd_row A a b y hw
      have hsel : r∈(rows A a b y).filter Row.selected := by simp [hr,hs]
      have hv : r.vars≠[] := by
        intro hv
        have hfalse := List.find?_eq_none.mp hnone r hsel
        simp [hv,ho] at hfalse
      have hp : payment r ≠ [] := by
        cases he : r.vars with
        | nil => exact False.elim (hv he)
        | cons x xs => by_cases hh : xs=[] <;> simp [payment,lastVar,he,hh]
      intro he
      have hh := List.flatMap_eq_nil_iff.mp he r hsel
      exact hp hh
    · intro p hp
      obtain ⟨r,hr,hp⟩ := List.mem_flatMap.mp hp
      have hr' := (List.mem_filter.mp hr).1
      have hb := terminal_bound A a b y r hr'
      exact payment_safe r _ (rows_good A a b y r hr') hb.1 hb.2 p hp

#print axioms finish_refs
#print axioms generate_refs
end OP03.Emit

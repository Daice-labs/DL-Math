import PBPayments
set_option maxHeartbeats 0
namespace OP03.Kernel

theorem values_map {α : Type} {v : Nat} (db : List (PB v)) (xs : List α)
    (e : α → Emit.Expr) (c : α → PB v) (h : ∀ x∈xs, eval db (e x)=some (c x)) :
    Values db (xs.map e) (xs.map c) := by
  induction xs with
  | nil => exact .nil
  | cons x xs ih => exact .cons (h x (by simp)) (ih (by intro x hx; exact h x (by simp [hx])))

theorem values_append {v : Nat} {db : List (PB v)} {es fs : List Emit.Expr} {cs ds : List (PB v)}
    (h : Values db es cs) (k : Values db fs ds) : Values db (es++fs) (cs++ds) := by
  induction h with
  | nil => exact k
  | cons hh ht ih => exact .cons hh ih

theorem payments_values {v : Nat} (db : List (PB v)) (rs : List Emit.Row)
    (hb : ∀ r∈rs, ∀ z, Emit.lastVar r.vars r.base=some z → 0 < z ∧ z < v)
    (hu : ∀ r∈rs, ∀ z, Emit.lastVar r.vars r.base=some z →
      lookup db r.terminal=some (fromClause v [if r.rhs then (z : Int) else -(z : Int)])) :
    Values db ((rs.flatMap Emit.payment).map Prod.fst) (rs.flatMap (rowValues v)) ∧
    Values db ((rs.flatMap Emit.payment).map Prod.snd) ((rs.flatMap (rowValues v)).map neg) := by
  induction rs with
  | nil => exact ⟨.nil,.nil⟩
  | cons r rs ih =>
    have hr := payment_values db r (hb r (by simp)) (hu r (by simp))
    have ht := ih (by intro r hr; exact hb r (by simp [hr])) (by intro r hr; exact hu r (by simp [hr]))
    constructor
    · simpa using values_append hr.1 ht.1
    · simpa using values_append hr.2 ht.2

theorem aggregate_evaluations {v : Nat} (db : List (PB v)) (rs : List Emit.Row) (h k : Nat)
    (ho : GateOutputs db (rs.flatMap fun r => Emit.gates r.vars r.base) h k)
    (hb : ∀ r∈rs, ∀ z, Emit.lastVar r.vars r.base=some z → 0 < z ∧ z < v)
    (hu : ∀ r∈rs, ∀ z, Emit.lastVar r.vars r.base=some z →
      lookup db r.terminal=some (fromClause v [if r.rhs then (z : Int) else -(z : Int)]))
    (hne : rs.flatMap (fun r => Emit.gates r.vars r.base)≠[] ∨ rs.flatMap Emit.payment≠[]) :
    let gs := rs.flatMap fun r => Emit.gates r.vars r.base
    let ps := rs.flatMap Emit.payment
    eval db (Emit.aggregate ((gs.zipIdx.map fun (_,i) => Emit.Expr.ref (k+23*i+22))++ps.map Prod.fst))=
      some (aggregatePB v h rs) ∧
    eval db (Emit.aggregate ((gs.zipIdx.map fun (_,i) => Emit.Expr.ref (k+23*i+23))++ps.map Prod.snd))=
      some (neg (aggregatePB v h rs)) := by
  dsimp only
  let gs := rs.flatMap fun r => Emit.gates r.vars r.base
  let ps := rs.flatMap Emit.payment
  have houtputs (p : Emit.Gate × Nat) (hp : p∈gs.zipIdx) :
      lookup db (k+23*p.2+22)=some (gatePB v p.1 (h+2*p.2+1)) ∧
      lookup db (k+23*p.2+23)=some (neg (gatePB v p.1 (h+2*p.2+1))) := by
    apply ho p.2 p.1
    exact List.mem_zipIdx_iff_getElem?.mp hp
  have hl := values_map db gs.zipIdx (fun p => Emit.Expr.ref (k+23*p.2+22))
    (fun p => gatePB v p.1 (h+2*p.2+1)) (fun p hp => (houtputs p hp).1)
  have hh := values_map db gs.zipIdx (fun p => Emit.Expr.ref (k+23*p.2+23))
    (fun p => neg (gatePB v p.1 (h+2*p.2+1))) (fun p hp => (houtputs p hp).2)
  have hp := payments_values db rs hb hu
  have hn (off : Nat) (f : (Emit.Expr × Emit.Expr) → Emit.Expr) :
      (gs.zipIdx.map (fun p => Emit.Expr.ref (k+23*p.2+off))++ps.map f)≠[] := by
    intro he
    have hz : gs=[] ∧ ps=[] := by simpa using he
    rcases hne with hn | hn
    · exact hn hz.1
    · exact hn hz.2
  constructor
  · have he := eval_aggregate db _ _ (values_append hl hp.1) (hn 22 Prod.fst)
    simpa [sumPB_append,rowsValues_sum,aggregatePB,gs] using he
  · have he := eval_aggregate db _ _ (values_append hh hp.2) (hn 23 Prod.snd)
    have heq :
        (gs.zipIdx.map (fun p => neg (gatePB v p.1 (h+2*p.2+1))))++(rs.flatMap (rowValues v)).map neg =
        ((gs.zipIdx.map fun p => gatePB v p.1 (h+2*p.2+1))++rs.flatMap (rowValues v)).map neg := by simp
    rw [heq,sumPB_neg,sumPB_append,rowsValues_sum] at he
    exact he

#print axioms aggregate_evaluations
end OP03.Kernel
